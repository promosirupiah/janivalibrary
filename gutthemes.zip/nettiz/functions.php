<?php
/**
 * Theme Functions
 *
 * @author Jegtheme
 * @package nettiz
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'NETTIZ_VERSION' ) || define( 'NETTIZ_VERSION', '1.0.3' );
defined( 'NETTIZ_DIR' ) || define( 'NETTIZ_DIR', trailingslashit( get_template_directory() ) );
defined( 'NETTIZ_URI' ) || define( 'NETTIZ_URI', trailingslashit( get_template_directory_uri() ) );

require get_parent_theme_file_path( 'inc/autoload.php' );

Nettiz\Init::instance();
