<?php
/**
 * Block Pattern Class
 *
 * @author Jegstudio
 * @package nettiz
 */

namespace Nettiz;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Block_Pattern_Categories_Registry;

/**
 * Init Class
 *
 * @package nettiz
 */
class Block_Patterns {

	/**
	 * Instance variable
	 *
	 * @var $instance
	 */
	private static $instance;

	/**
	 * Class instance.
	 *
	 * @return BlockPatterns
	 */
	public static function instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * Class constructor.
	 */
	public function __construct() {
		$this->register_block_patterns();
	}

	/**
	 * Register Block Patterns
	 */
	private function register_block_patterns() {
		$block_pattern_categories = array(
			'nettiz-basic' => array( 'label' => __( 'Nettiz Basic Patterns', 'nettiz' ) ),
		);

		if ( defined( 'GUTENVERSE' ) ) {
			$block_pattern_categories['nettiz-gutenverse'] = array( 'label' => __( 'Nettiz Gutenverse Patterns', 'nettiz' ) );
		}

		$block_pattern_categories = apply_filters( 'nettiz_block_pattern_categories', $block_pattern_categories );

		foreach ( $block_pattern_categories as $name => $properties ) {
			if ( ! WP_Block_Pattern_Categories_Registry::get_instance()->is_registered( $name ) ) {
				register_block_pattern_category( $name, $properties );
			}
		}

		$block_patterns = array(
			'nettiz-core-header',
			'nettiz-core-footer',
			'nettiz-core-index-hero',
			'nettiz-core-post-blog',
			'nettiz-core-page-hero',
			'nettiz-core-page-content',
			'nettiz-core-single-hero',
			'nettiz-core-single-content',
			'nettiz-core-archive-hero',
			'nettiz-core-post-blog',
			'nettiz-core-404',
			'nettiz-core-search-hero',
			'nettiz-core-search',
			'nettiz-core-post-blog',
			'nettiz-core-home-hero',
			'nettiz-core-home-about',
			'nettiz-core-quotes',
			'nettiz-core-project',
			'nettiz-core-service',
			'nettiz-core-testimonial',
			'nettiz-core-blog',
		);

		if ( defined( 'GUTENVERSE' ) ) {
			$block_patterns[] = 'nettiz-gutenverse-about-hero';
			$block_patterns[] = 'nettiz-gutenverse-about-aboutme';
			$block_patterns[] = 'nettiz-gutenverse-about-choose';
			$block_patterns[] = 'nettiz-gutenverse-about-ourteam';
			$block_patterns[] = 'nettiz-gutenverse-about-rtg';
			$block_patterns[] = 'nettiz-gutenverse-blog';
			$block_patterns[] = 'nettiz-gutenverse-service-hero';
			$block_patterns[] = 'nettiz-gutenverse-service';
			$block_patterns[] = 'nettiz-gutenverse-quotes';
			$block_patterns[] = 'nettiz-gutenverse-testimonial';
			$block_patterns[] = 'nettiz-gutenverse-pricing';
			$block_patterns[] = 'nettiz-gutenverse-cta';
			$block_patterns[] = 'nettiz-gutenverse-pricing-hero';
			$block_patterns[] = 'nettiz-gutenverse-pricing';
			$block_patterns[] = 'nettiz-gutenverse-project';
			$block_patterns[] = 'nettiz-gutenverse-faq';
			$block_patterns[] = 'nettiz-gutenverse-cta';
			$block_patterns[] = 'nettiz-gutenverse-team-hero';
			$block_patterns[] = 'nettiz-gutenverse-our-team';
			$block_patterns[] = 'nettiz-gutenverse-about-rtg';
			$block_patterns[] = 'nettiz-gutenverse-about-aboutme';
			$block_patterns[] = 'nettiz-gutenverse-faq-hero';
			$block_patterns[] = 'nettiz-gutenverse-faq';
			$block_patterns[] = 'nettiz-gutenverse-project';
			$block_patterns[] = 'nettiz-gutenverse-blog';
			$block_patterns[] = 'nettiz-gutenverse-blog-hero';
			$block_patterns[] = 'nettiz-gutenverse-blog-articles';
			$block_patterns[] = 'nettiz-gutenverse-contact-hero';
			$block_patterns[] = 'nettiz-gutenverse-contact';
			$block_patterns[] = 'nettiz-gutenverse-cta';
			$block_patterns[] = 'nettiz-gutenverse-header';
			$block_patterns[] = 'nettiz-gutenverse-footer';
			$block_patterns[] = 'nettiz-gutenerse-page-hero';
			$block_patterns[] = 'nettiz-gutenverse-page-content';
			$block_patterns[] = 'nettiz-gutenverse-single-hero';
			$block_patterns[] = 'nettiz-gutenverse-single-content';
			$block_patterns[] = 'nettiz-gutenverse-archive-hero';
			$block_patterns[] = 'nettiz-gutenverse-blog-2';
			$block_patterns[] = 'nettiz-gutenverse-search-hero';
			$block_patterns[] = 'nettiz-gutenverse-search';
			$block_patterns[] = 'nettiz-gutenverse-blog-2';
			$block_patterns[] = 'nettiz-gutenverse-404';
			$block_patterns[] = 'nettiz-gutenerse-page-hero';
			$block_patterns[] = 'nettiz-gutenverse-blog-2';
			$block_patterns[] = 'nettiz-gutenverse-home-hero';
			$block_patterns[] = 'nettiz-gutenverse-popup';
			$block_patterns[] = 'nettiz-gutenverse-home-about';
			$block_patterns[] = 'nettiz-gutenverse-quotes';
			$block_patterns[] = 'nettiz-gutenverse-project';
			$block_patterns[] = 'nettiz-gutenverse-service';
			$block_patterns[] = 'nettiz-gutenverse-testimonial';
			$block_patterns[] = 'nettiz-gutenverse-blog';
		}

		$block_patterns = apply_filters( 'nettiz_block_patterns', $block_patterns );

		if ( function_exists( 'register_block_pattern' ) ) {
			foreach ( $block_patterns as $block_pattern ) {
				$pattern_file = get_theme_file_path( '/inc/patterns/' . $block_pattern . '.php' );

				register_block_pattern(
					'nettiz/' . $block_pattern,
					require $pattern_file
				);
			}
		}
	}
}
