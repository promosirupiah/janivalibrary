<?php
/**
 * Block Pattern Class
 *
 * @author Jegstudio
 * @package nettiz
 */
namespace Nettiz;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Init Class
 *
 * @package nettiz
 */
class Asset_Enqueue {
	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_scripts' ) );
	}

	/**
	 * Enqueue scripts and styles.
	 */
	public function enqueue_scripts() {
		wp_enqueue_style( 'nettiz-style', get_stylesheet_uri(), array(), NETTIZ_VERSION );

		wp_enqueue_style( 'nettiz-preset-styling', NETTIZ_URI . '/assets/css/nettiz-preset-styling.css', array(), NETTIZ_VERSION );
		wp_enqueue_style( 'nettiz-custom-styling', NETTIZ_URI . '/assets/css/nettiz-custom-styling.css', array(), NETTIZ_VERSION );
		wp_enqueue_script( 'nettiz-animation-script', NETTIZ_URI . '/assets/js/nettiz-animation-script.js', array(), NETTIZ_VERSION, true );
		wp_enqueue_style( 'nettiz-animation-styling', NETTIZ_URI . '/assets/css/nettiz-animation-styling.css', array(), NETTIZ_VERSION );

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
}
