<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core 404', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp","id":4215,"dimRatio":0,"isDark":false,"className":"nettiz-margin-top-n180"} -->
<div class="wp-block-cover is-light nettiz-margin-top-n180"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4215" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"margin":{"top":"300px","bottom":"170px"}}},"className":"nettiz-animate nettiz-move-up nettiz-delay-1","layout":{"type":"constrained","contentSize":"700px"}} -->
<div class="wp-block-group nettiz-animate nettiz-move-up nettiz-delay-1" style="margin-top:300px;margin-bottom:170px"><!-- wp:columns {"style":{"border":{"width":"2px"},"spacing":{"padding":{"top":"50px","right":"20px","bottom":"70px","left":"20px"}}},"borderColor":"black","className":"is-style-customboxshadow"} -->
<div class="wp-block-columns is-style-customboxshadow has-border-color has-black-border-color" style="border-width:2px;padding-top:50px;padding-right:20px;padding-bottom:70px;padding-left:20px"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"160px","lineHeight":"1","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"40px"}}},"textColor":"black","className":"font-not-found","fontFamily":"mulish"} -->
<h1 class="wp-block-heading has-text-align-center font-not-found has-black-color has-text-color has-mulish-font-family" style="margin-bottom:40px;font-size:160px;font-style:normal;font-weight:700;line-height:1">404</h1>
<!-- /wp:heading -->

<!-- wp:search {"label":"Search","showLabel":false,"width":90,"widthUnit":"%","buttonText":"Search","align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700","lineHeight":"1.5"},"border":{"radius":"0px","width":"2px"}},"borderColor":"black","backgroundColor":"theme-1","textColor":"black","fontFamily":"mulish"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->',
);
