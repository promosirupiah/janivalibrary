<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse Archive Hero', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"600"},"gap":"no","elementId":"guten-ro5YsC","background":{"type":"default","image":{"Desktop":{"id":4215,"image":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-120"}},"Tablet":{"unit":"px","dimension":{"top":"-150"}},"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"180","bottom":"130"}},"Tablet":[],"Mobile":{"unit":"px","dimension":{"right":"30","left":"20","top":"190","bottom":"80"}}},"animation":{"type":{"Desktop":"none"},"duration":"normal","delay":""}} -->
	<div class="section-wrapper" data-id="ro5YsC"><section class="wp-block-gutenverse-section guten-element guten-section guten-ro5YsC layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-rlGi8T","horizontalAlign":{"Desktop":"center","Tablet":"center","Mobile":"center"},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"all":{"type":"solid","width":"2","color":{"type":"variable","id":"black"}}},"boxShadow":{"color":{"type":"variable","id":"black"},"horizontal":"10","vertical":"10"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}},"Mobile":{}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"30","right":"40","bottom":"40","left":"40"}},"Mobile":{"unit":"px","dimension":{"top":"40","right":"40","bottom":"40","left":"40"}}},"animation":{"type":{"Desktop":"fadeIn"},"duration":"normal","delay":"100"}} -->
	<div class="wp-block-gutenverse-column guten-element guten-column guten-rlGi8T animated guten-element-hide desktop-fadeIn"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="rlGi8T"><div class="guten-column-wrapper"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
	<div class="wp-block-group"><!-- wp:columns -->
	<div class="wp-block-columns"><!-- wp:column -->
	<div class="wp-block-column"><!-- wp:query-title {"type":"archive","textAlign":"center","showPrefix":false,"style":{"typography":{"fontSize":"64px","fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","fontFamily":"mulish"} /--></div>
	<!-- /wp:column --></div>
	<!-- /wp:columns --></div>
	<!-- /wp:group --></div></div></div>
	<!-- /wp:gutenverse/column --></div></section></div>
	<!-- /wp:gutenverse/section -->',
);
