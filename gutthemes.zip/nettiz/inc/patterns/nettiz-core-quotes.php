<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Quotes', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"blockGap":"0px","padding":{"bottom":"100px","top":"0px","right":"20px","left":"20px"}},"color":{"background":"#fefcfa"}},"layout":{"contentSize":"1180px","type":"constrained"}} -->
<div class="wp-block-group has-background" style="background-color:#fefcfa;padding-top:0px;padding-right:20px;padding-bottom:100px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"blockGap":"0px"}}} -->
<div class="wp-block-columns"><!-- wp:column {"style":{"spacing":{"padding":{"right":"0px","top":"0px","bottom":"0px","left":"0px"},"blockGap":"0px"}},"layout":{"inherit":false}} -->
<div class="wp-block-column" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:columns {"style":{"spacing":{"blockGap":"0px"}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"black","className":"heading-2 nettiz-animate nettiz-move-right nettiz-delay-3","fontFamily":"mulish"} -->
<h2 class="wp-block-heading heading-2 nettiz-animate nettiz-move-right nettiz-delay-3 has-black-color has-text-color has-mulish-font-family" style="margin-bottom:20px;font-style:normal;font-weight:700;line-height:1.1">We Provide Creative Solutions For Your <span class="custom-highlight">Creative Idea.</span></h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"100px"} -->
<div class="wp-block-column" style="flex-basis:100px"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"70px","style":{"spacing":{"padding":{"right":"0px","top":"0px","bottom":"0px","left":"0px"},"blockGap":"0px"}},"layout":{"inherit":false}} -->
<div class="wp-block-column" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;flex-basis:70px"></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"left":"0px"}}}} -->
<div class="wp-block-column" style="padding-left:0px"><!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"30px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","className":"nettiz-animate nettiz-move-up nettiz-delay-5","fontFamily":"heebo"} -->
<p class="nettiz-animate nettiz-move-up nettiz-delay-5 has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:30px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">“At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.”</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"className":"nettiz-animate nettiz-move-up nettiz-delay-5"} -->
<div class="wp-block-columns nettiz-animate nettiz-move-up nettiz-delay-5"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":5491,"width":68,"height":69,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/ambitious-attractive-boss-business-businessman-challenge-1652043.webp" alt="" class="wp-image-5491" width="68" height="69"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.4"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="font-style:normal;font-weight:700;line-height:1.4">William Hardy</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"5px"}}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-top:5px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">CEO &amp; Founder Nettiz</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
