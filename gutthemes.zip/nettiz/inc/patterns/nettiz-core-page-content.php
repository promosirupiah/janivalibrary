<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Page Content', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:post-content /-->',
);
