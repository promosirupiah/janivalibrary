<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Footer', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"100px","bottom":"40px","right":"20px","left":"20px"}}},"backgroundColor":"black","layout":{"type":"constrained","contentSize":"1180px"}} -->
<div class="wp-block-group has-black-background-color has-background" style="padding-top:100px;padding-right:20px;padding-bottom:40px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"padding":{"bottom":"80px"}},"border":{"bottom":{"color":"var:preset|color|theme-2","width":"1px"}}}} -->
<div class="wp-block-columns" style="border-bottom-color:var(--wp--preset--color--theme-2);border-bottom-width:1px;padding-bottom:80px"><!-- wp:column {"width":"50%","style":{"spacing":{"padding":{"top":"0px","bottom":"20px"}}}} -->
<div class="wp-block-column" style="padding-top:0px;padding-bottom:20px;flex-basis:50%"><!-- wp:site-title {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-1"}}},"spacing":{"margin":{"bottom":"40px","top":"0px"}},"typography":{"fontSize":"40px","fontStyle":"normal","fontWeight":"700","lineHeight":"1"}},"textColor":"white","fontFamily":"mulish"} /-->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"right":"50px","bottom":"50px"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-heebo-font-family" style="padding-right:50px;padding-bottom:50px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet elit sit amet.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"theme-2","iconColorValue":"#fefcfa","size":"has-small-icon-size","style":{"spacing":{"blockGap":{"top":"30px","left":"30px"},"margin":{"bottom":"20px"}}},"className":"is-style-logos-only "} -->
<ul class="wp-block-social-links has-small-icon-size has-icon-color is-style-logos-only" style="margin-bottom:20px"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"twitter"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"bottom":"20px"}}}} -->
<div class="wp-block-column" style="padding-bottom:20px;flex-basis:25%"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"bottom":"20px","top":"0px"}},"typography":{"fontStyle":"normal","fontWeight":"700"}},"textColor":"white","className":"is-style-customheadingstyle heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading is-style-customheadingstyle heading-3 has-white-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:20px;font-style:normal;font-weight:700">Quick Links</h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"blockGap":"20px","padding":{"top":"10px","bottom":"20px"}}}} -->
<div class="wp-block-group" style="padding-top:10px;padding-bottom:20px"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"400"},"elements":{"link":{"color":{"text":"var:preset|color|theme-2"}}}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-link-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5"><a href="#">About Us</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"elements":{"link":{"color":{"text":"var:preset|color|theme-2"}}}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-link-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5"><a href="#">Services</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"elements":{"link":{"color":{"text":"var:preset|color|theme-2"}}}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-link-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5"><a href="#">Projects</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"elements":{"link":{"color":{"text":"var:preset|color|theme-2"}}}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-link-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5"><a href="#">Pricing</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"elements":{"link":{"color":{"text":"var:preset|color|theme-2"}}}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-link-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5"><a href="#">Contact</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"bottom":"20px"}}}} -->
<div class="wp-block-column" style="padding-bottom:20px;flex-basis:25%"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"bottom":"20px","top":"0px"}},"typography":{"fontStyle":"normal","fontWeight":"700"}},"textColor":"white","className":"is-style-customheadingstyle heading-3"} -->
<h3 class="wp-block-heading is-style-customheadingstyle heading-3 has-white-color has-text-color" style="margin-top:0px;margin-bottom:20px;font-style:normal;font-weight:700">Office</h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":4219,"width":10,"height":16,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/pin.png" alt="" class="wp-image-4219" width="10" height="16"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"left":"18px","top":"8px"}}},"textColor":"theme-2"} -->
<p class="has-theme-2-color has-text-color" style="margin-top:8px;margin-left:18px">Jl. Raya Kuta, Badung Bali</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":4220,"width":16,"height":16,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/phone.png" alt="" class="wp-image-4220" width="16" height="16"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"left":"15px","top":"8px"}}},"textColor":"theme-2"} -->
<p class="has-theme-2-color has-text-color" style="margin-top:8px;margin-left:15px">+62 361 8765432</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4221,"width":16,"height":12,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/envelope.png" alt="" class="wp-image-4221" width="16" height="12"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"left":"15px","top":"8px"}}},"textColor":"theme-2"} -->
<p class="has-theme-2-color has-text-color" style="margin-top:8px;margin-left:15px">nettiz@gmail.com</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"0px"},"margin":{"top":"50px"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="margin-top:50px;padding-top:0px"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"white","fontFamily":"heebo"} -->
<p class="has-white-color has-text-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Copyright © 2023 Nettiz By Jegtstudio.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"hide-in-mobile","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group hide-in-mobile"><!-- wp:image {"align":"right","id":4218,"width":36,"height":48,"sizeSlug":"full","linkDestination":"custom","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}},"className":"nettiz-to-top  hide-in-mobile"} -->
<figure class="wp-block-image alignright size-full is-resized nettiz-to-top  hide-in-mobile"><a href="#"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/arrow.png" alt="" class="wp-image-4218" width="36" height="48"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
