<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Blog', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"100px","bottom":"80px","right":"20px","left":"20px"}}},"layout":{"contentSize":"1180px","type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:100px;padding-right:20px;padding-bottom:80px;padding-left:20px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"top":"10px","bottom":"20px"}},"typography":{"lineHeight":"1.1","fontStyle":"normal","fontWeight":"700","fontSize":"44px"}},"textColor":"black","className":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-text-align-center heading-2 has-black-color has-text-color has-mulish-font-family" style="margin-top:10px;margin-bottom:20px;font-size:44px;font-style:normal;font-weight:700;line-height:1.1">Latest News and <span class="custom-highlight">Articles.</span> </h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"60px"}}},"layout":{"type":"constrained","contentSize":"550px"}} -->
<div class="wp-block-group" style="margin-bottom:60px"><!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"bottom":"30px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-text-align-center has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:30px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut sed do eiusmod dolore magna aliqua.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:query {"queryId":22,"query":{"perPage":"3","pages":0,"offset":0,"postType":"post","order":"asc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"exclude","inherit":false},"displayLayout":{"type":"flex","columns":3},"className":"nettiz-post-template-gap nettiz-animate nettiz-move-up nettiz-delay-1"} -->
<div class="wp-block-query nettiz-post-template-gap nettiz-animate nettiz-move-up nettiz-delay-1"><!-- wp:post-template {"textColor":"theme-6"} -->
<!-- wp:post-featured-image /-->

<!-- wp:post-title {"level":3,"isLink":true,"style":{"typography":{"fontSize":"24px","lineHeight":"1.4","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"top":"20px"}}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} /-->

<!-- wp:post-excerpt {"moreText":"Read More","style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"},"elements":{"link":{"color":{"text":"var:preset|color|theme-1"}}}},"textColor":"theme-0","fontFamily":"heebo"} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
