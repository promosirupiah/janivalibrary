<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Home Hero', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"},"blockGap":"0px"}},"layout":{"type":"constrained","contentSize":""}} -->
<div class="wp-block-group" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/Background-home-hero.webp","id":4214,"dimRatio":0,"minHeight":1128,"minHeightUnit":"px","isDark":false,"className":"nettiz-margin-top-n180","style":{"spacing":{"padding":{"top":"60px"}}}} -->
<div class="wp-block-cover is-light nettiz-margin-top-n180" style="padding-top:60px;min-height:1128px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4214" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/Background-home-hero.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"margin":{"bottom":"20px"}}},"layout":{"contentSize":"900px","type":"constrained"}} -->
<div class="wp-block-group" style="margin-bottom:20px"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.2"},"spacing":{"margin":{"top":"220px","bottom":"40px"}}},"textColor":"black","className":"heading-1 nettiz-animate nettiz-move-down nettiz-delay-1","fontFamily":"mulish"} -->
<h1 class="wp-block-heading has-text-align-center heading-1 nettiz-animate nettiz-move-down nettiz-delay-1 has-black-color has-text-color has-mulish-font-family" style="margin-top:220px;margin-bottom:40px;font-style:normal;font-weight:700;line-height:1.2">We Create Unique and Efficient <span class="custom-highlight">Digital Service</span></h1>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"120px"}}},"layout":{"contentSize":"550px","type":"constrained"}} -->
<div class="wp-block-group" style="margin-bottom:120px"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"18px"}},"textColor":"theme-0","className":"nettiz-animate nettiz-move-down nettiz-delay-3","fontFamily":"heebo"} -->
<p class="has-text-align-center nettiz-animate nettiz-move-down nettiz-delay-3 has-theme-0-color has-text-color has-heebo-font-family" style="font-size:18px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained","wideSize":"1180px","contentSize":"1180px"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/action-african-american-african-descent-american-beverage-black-1448363.webp","id":5490,"dimRatio":0,"minHeight":518,"minHeightUnit":"px","isDark":false,"align":"center","className":"nettiz-animate nettiz-move-up nettiz-delay-7"} -->
<div class="wp-block-cover aligncenter is-light nettiz-animate nettiz-move-up nettiz-delay-7" style="min-height:518px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-5490" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/action-african-american-african-descent-american-beverage-black-1448363.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:columns {"className":"nettiz-margin-top-n340"} -->
<div class="wp-block-columns nettiz-margin-top-n340"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"align":"center","id":4229,"width":168,"height":168,"sizeSlug":"full","linkDestination":"custom","style":{"color":{"duotone":"unset"}},"className":"nettiz-margin-top-n120 nettiz-animate nettiz-move-up nettiz-delay-5"} -->
<figure class="wp-block-image aligncenter size-full is-resized nettiz-margin-top-n120 nettiz-animate nettiz-move-up nettiz-delay-5"><a href="#"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/button-circle.png" alt="" class="wp-image-4229" width="168" height="168"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->',
);
