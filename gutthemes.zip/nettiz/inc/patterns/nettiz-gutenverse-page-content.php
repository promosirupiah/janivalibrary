<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse Page Content', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/post-content {"elementId":"guten-IrNZW7"} -->
<div class="guten-element guten-post-content guten-IrNZW7"></div>
<!-- /wp:gutenverse/post-content -->',
);
