<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Index Hero', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp","id":4215,"dimRatio":0,"focalPoint":{"x":0.5,"y":0.49},"isDark":false,"className":"nettiz-margin-top-n180","style":{"spacing":{"padding":{"top":"250px","bottom":"100px"}}}} -->
<div class="wp-block-cover is-light nettiz-margin-top-n180" style="padding-top:250px;padding-bottom:100px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4215" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp" style="object-position:50% 49%" data-object-fit="cover" data-object-position="50% 49%"/><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"nettiz-animate nettiz-move-up nettiz-delay-1","layout":{"type":"constrained","contentSize":"600px"}} -->
<div class="wp-block-group nettiz-animate nettiz-move-up nettiz-delay-1"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"border":{"width":"2px"},"spacing":{"padding":{"top":"30px","right":"40px","bottom":"30px","left":"40px"}}},"borderColor":"black","className":"is-style-customboxshadow"} -->
<div class="wp-block-column is-style-customboxshadow has-border-color has-black-border-color" style="border-width:2px;padding-top:30px;padding-right:40px;padding-bottom:30px;padding-left:40px"><!-- wp:post-title {"textAlign":"center","level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-hero","fontFamily":"mulish"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->',
);
