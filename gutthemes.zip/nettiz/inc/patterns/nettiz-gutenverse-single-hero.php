<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse Single Hero', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1100"},"gap":"no","elementId":"guten-SDvtAn","background":{"type":"default","image":{"Desktop":{"id":4215,"image":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-100"}},"Tablet":{"unit":"px","dimension":{"top":"-150"}},"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"180","bottom":"120"}},"Tablet":{"unit":"px","dimension":{"top":"200","bottom":"100"}},"Mobile":{"unit":"px","dimension":{"top":"200","bottom":"80","right":"20","left":"20"}}}} -->
<div class="section-wrapper" data-id="SDvtAn"><section class="wp-block-gutenverse-section guten-element guten-section guten-SDvtAn layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-y8pZBO"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-y8pZBO"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="y8pZBO"><div class="guten-column-wrapper"><!-- wp:gutenverse/post-title {"elementId":"guten-xGz26x","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"Epnwe1","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"64","unit":"px"},"Tablet":{"point":"64","unit":"px"},"Mobile":{"point":"38","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1"},"Tablet":{"unit":"em","point":"1.2"},"Mobile":{"unit":"em","point":"1.2"}},"weight":"700"},"color":{"type":"variable","id":"black"},"colorHover":{"type":"variable","id":"black"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"40"}},"Mobile":{"unit":"px","dimension":{"bottom":"30"}},"Tablet":[]},"padding":{"Desktop":[],"Mobile":[]},"animation":{"type":{"Desktop":"fadeIn"},"duration":"normal","delay":"100"}} -->
<div class="guten-element guten-post-title guten-xGz26x animated guten-element-hide desktop-fadeIn"></div>
<!-- /wp:gutenverse/post-title -->

<!-- wp:gutenverse/section {"width":{"Desktop":"380"},"isChild":true,"gap":"no","elementId":"guten-hsGwac","margin":{"Desktop":[]},"padding":{"Desktop":[]}} -->
<div class="section-wrapper" data-id="hsGwac"><section class="wp-block-gutenverse-section guten-element guten-section guten-hsGwac layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-065UHG","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"center","Tablet":"center","Mobile":"center"},"margin":{"Desktop":{"unit":"px","dimension":{"right":"15"}}},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-065UHG"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="065UHG"><div class="guten-column-wrapper"><!-- wp:gutenverse/icon {"elementId":"guten-DTJK8o","icon":"fas fa-user","iconColorOne":{"r":0,"g":0,"b":0,"a":0},"iconSize":{"Desktop":{"point":"16","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"black"},"margin":{"Desktop":{"unit":"px","dimension":{"right":"10"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-DTJK8o guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-user"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-author {"elementId":"guten-JK8FDL","typography":{"type":"variable","id":"lFjpsI","font":{"label":"Heebo","value":"Heebo","type":"google"},"size":{"Desktop":{"point":"14","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.5"}}},"color":{"type":"variable","id":"theme-6"},"colorHover":{"type":"variable","id":"theme-6"},"authorBorder":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"15"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-author guten-JK8FDL"></div>
<!-- /wp:gutenverse/post-author -->

<!-- wp:gutenverse/icon {"elementId":"guten-T91H23","icon":"fas fa-clock","iconColorOne":{"r":0,"g":0,"b":0,"a":0},"iconSize":{"Desktop":{"point":"16","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"black"},"margin":{"Desktop":{"unit":"px","dimension":{"right":"10"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-T91H23 guten-icon"><span class="guten-icon-wrapper rounded stacked"><i class="fas fa-clock"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-date {"elementId":"guten-YSzvB3","positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-date guten-YSzvB3"></div>
<!-- /wp:gutenverse/post-date --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
