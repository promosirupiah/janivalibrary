<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse 404', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"700"},"gap":"no","elementId":"guten-KZ4xx2","background":{"type":"default","image":{"Desktop":{"id":4215,"image":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-120"}},"Tablet":{"unit":"px","dimension":{"top":"-150"}},"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"220","bottom":"170"}},"Tablet":{"unit":"px","dimension":{"right":"50","left":"50","top":"200","bottom":"120"}},"Mobile":{"unit":"px","dimension":{"right":"20","left":"20","bottom":"100","top":"200"}}}} -->
<div class="section-wrapper" data-id="KZ4xx2"><section class="wp-block-gutenverse-section guten-element guten-section guten-KZ4xx2 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-ovARXW","horizontalAlign":{"Desktop":"center","Tablet":"center"},"border":{"radius":{"Desktop":[]},"all":{"type":"solid","width":"2","color":{"type":"variable","id":"black"}}},"boxShadow":{"color":{"type":"variable","id":"black"},"horizontal":"10","vertical":"10"},"margin":{"Desktop":{},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"50","right":"50","bottom":"70","left":"50"}},"Tablet":{"unit":"px","dimension":{"top":"100","right":"100","bottom":"100","left":"100"}},"Mobile":{"unit":"px","dimension":{"top":"10","right":"20","bottom":"30","left":"20"}}},"animation":{"type":{"Desktop":"fadeIn"},"duration":"normal","delay":"100"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-ovARXW animated guten-element-hide desktop-fadeIn"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="ovARXW"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-Gy2CRZ","type":1,"textAlign":{"Desktop":"center"},"color":{"type":"variable","id":"black"},"typography":{"type":"variable","id":"8seM0M","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"140","unit":"px"}},"weight":"700","lineHeight":{"Desktop":{"unit":"em","point":"1"}}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"40"}},"Tablet":[],"Mobile":{"unit":"px","dimension":{"bottom":"20"}}},"padding":{"Desktop":[],"Mobile":[]}} -->
<h1 class="wp-block-gutenverse-heading guten-element guten-Gy2CRZ">404</h1>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-AKOoE3","positioningType":{"Desktop":"custom","Tablet":"custom"},"positioningWidth":{"Desktop":{"unit":"%","point":"70"},"Tablet":{"unit":"%","point":"100"}}} -->
<div class="guten-element gutenverse-text-editor guten-AKOoE3"><div class="text-content-inner"><!-- wp:search {"label":"Search","showLabel":false,"width":100,"widthUnit":"%","buttonText":"Search","align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700","lineHeight":"1.5"},"border":{"radius":"0px","width":"2px"}},"borderColor":"black","backgroundColor":"theme-1","textColor":"black","fontFamily":"mulish"} /--></div></div>
<!-- /wp:gutenverse/text-editor --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
