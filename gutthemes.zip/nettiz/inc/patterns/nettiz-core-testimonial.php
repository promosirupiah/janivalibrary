<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Testimonial', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-core.webp","id":4244,"dimRatio":0,"minHeight":430,"minHeightUnit":"px","isDark":false,"style":{"spacing":{"padding":{"bottom":"180px","top":"280px"}}}} -->
<div class="wp-block-cover is-light" style="padding-top:280px;padding-bottom:180px;min-height:430px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4244" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/background-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"nettiz-margin-top-n180","layout":{"type":"constrained","contentSize":"1180px"}} -->
<div class="wp-block-group nettiz-margin-top-n180"><!-- wp:columns {"style":{"spacing":{"margin":{"bottom":"50px"}}}} -->
<div class="wp-block-columns" style="margin-bottom:50px"><!-- wp:column {"style":{"spacing":{"padding":{"bottom":"50px"}}}} -->
<div class="wp-block-column" style="padding-bottom:50px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4245,"width":92,"height":92,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":"unset"}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-star.png" alt="" class="wp-image-4245" width="92" height="92"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"30px","top":"5px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-top:5px;padding-left:30px"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"0px"}}},"textColor":"black","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-black-color has-text-color has-mulish-font-family" style="margin-bottom:0px;font-size:36px;font-style:normal;font-weight:700">1,245 +</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"5px"}}},"textColor":"theme-6","fontFamily":"heebo"} -->
<p class="has-theme-6-color has-text-color has-heebo-font-family" style="margin-top:5px;font-size:16px;font-style:normal;font-weight:400">Client Satisfaction</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"bottom":"50px"}}}} -->
<div class="wp-block-column" style="padding-bottom:50px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4246,"width":92,"height":92,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-user.png" alt="" class="wp-image-4246" width="92" height="92"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"30px","top":"5px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-top:5px;padding-left:30px"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"0px"}}},"textColor":"black","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-black-color has-text-color has-mulish-font-family" style="margin-bottom:0px;font-size:36px;font-style:normal;font-weight:700">100 +</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"5px"}}},"textColor":"theme-6","fontFamily":"heebo"} -->
<p class="has-theme-6-color has-text-color has-heebo-font-family" style="margin-top:5px;font-size:16px;font-style:normal;font-weight:400">Profesional Team</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"bottom":"50px"}}}} -->
<div class="wp-block-column" style="padding-bottom:50px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4247,"width":92,"height":92,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-bag.png" alt="" class="wp-image-4247" width="92" height="92"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"30px","top":"5px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-top:5px;padding-left:30px"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"0px"}}},"textColor":"black","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-black-color has-text-color has-mulish-font-family" style="margin-bottom:0px;font-size:36px;font-style:normal;font-weight:700">15 +</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"5px"}}},"textColor":"theme-6","fontFamily":"heebo"} -->
<p class="has-theme-6-color has-text-color has-heebo-font-family" style="margin-top:5px;font-size:16px;font-style:normal;font-weight:400">Year Of Experience</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"bottom":"50px"}}}} -->
<div class="wp-block-column" style="padding-bottom:50px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4248,"width":92,"height":92,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-wink.png" alt="" class="wp-image-4248" width="92" height="92"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"30px","top":"5px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-top:5px;padding-left:30px"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"0px"}}},"textColor":"black","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-black-color has-text-color has-mulish-font-family" style="margin-bottom:0px;font-size:36px;font-style:normal;font-weight:700">3,452 +</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"5px"}}},"textColor":"theme-6","fontFamily":"heebo"} -->
<p class="has-theme-6-color has-text-color has-heebo-font-family" style="margin-top:5px;font-size:16px;font-style:normal;font-weight:400">Project Complete</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --><!-- wp:group {"style":{"spacing":{"padding":{"right":"20px","left":"20px","top":"0px"}}},"className":"nettiz-animate nettiz-move-up nettiz-delay-1","layout":{"type":"constrained","wideSize":"1180px","contentSize":"1180px","justifyContent":"center"}} -->
<div class="wp-block-group nettiz-animate nettiz-move-up nettiz-delay-1" style="padding-top:0px;padding-right:20px;padding-left:20px"><!-- wp:columns {"style":{"border":{"width":"2px","radius":"0px"}},"borderColor":"black","className":"nettiz-margin-top-n180"} -->
<div class="wp-block-columns nettiz-margin-top-n180 has-border-color has-black-border-color" style="border-width:2px;border-radius:0px"><!-- wp:column {"style":{"border":{"right":{"color":"var:preset|color|black","width":"2px"}}}} -->
<div class="wp-block-column" style="border-right-color:var(--wp--preset--color--black);border-right-width:2px"><!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/american-blond-caucasian-cellphone-chat-chatting-1431567.webp","id":5492,"dimRatio":0,"focalPoint":{"x":0.23,"y":0.5},"minHeight":540,"minHeightUnit":"px","isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:540px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-5492" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/american-blond-caucasian-cellphone-chat-chatting-1431567.webp" style="object-position:23% 50%" data-object-fit="cover" data-object-position="23% 50%"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…"} -->
<p class="has-text-align-center"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column {"backgroundColor":"white"} -->
<div class="wp-block-column has-white-background-color has-background"><!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-core.webp","id":4244,"dimRatio":0,"minHeight":540,"minHeightUnit":"px","isDark":false,"style":{"spacing":{"padding":{"top":"60px","bottom":"60px","right":"30px","left":"20px"}}}} -->
<div class="wp-block-cover is-light" style="padding-top:60px;padding-right:30px;padding-bottom:60px;padding-left:20px;min-height:540px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4244" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/background-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"constrained","contentSize":"500px"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"0px","bottom":"30px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.1","fontSize":"44px"}},"textColor":"black","className":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading heading-2 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:30px;font-size:44px;font-style:normal;font-weight:700;line-height:1.1">Clients <span class="custom-highlight">Reviews.</span></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-6","fontFamily":"heebo"} -->
<p class="has-theme-6-color has-text-color has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem aperiam.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"40px","right":"40px","bottom":"40px","left":"40px"},"margin":{"top":"30px","bottom":"0px"}},"border":{"radius":"0px","width":"2px"}},"borderColor":"black","backgroundColor":"theme-1","className":"is-style-customboxshadow","layout":{"type":"constrained"}} -->
<div class="wp-block-group is-style-customboxshadow has-border-color has-black-border-color has-theme-1-background-color has-background" style="border-width:2px;border-radius:0px;margin-top:30px;margin-bottom:0px;padding-top:40px;padding-right:40px;padding-bottom:40px;padding-left:40px"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:image {"id":30,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none","style":{"layout":{"selfStretch":"fixed","flexSize":null}},"className":"is-style-rounded"} -->
<figure class="wp-block-image size-full is-resized is-style-rounded"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/StockSnap_JSDMDDA208_circle.png" alt="" class="wp-image-30" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1","fontSize":"22px"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h4 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="font-size:22px;font-style:normal;font-weight:700;line-height:1">Emelie Brookes</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"5px"}}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-top:5px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Entrepreneur</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:image {"id":4251,"width":45,"height":37,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["rgb(0, 0, 0)","rgb(0, 0, 0)"]}},"className":"hide-in-mobile"} -->
<figure class="wp-block-image size-full is-resized hide-in-mobile"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/line-quotes.png" alt="" class="wp-image-4251" width="45" height="37"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"20px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-6","fontFamily":"heebo"} -->
<p class="has-theme-6-color has-text-color has-heebo-font-family" style="margin-top:20px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna  amet consectetur adipiscing aliqua.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
