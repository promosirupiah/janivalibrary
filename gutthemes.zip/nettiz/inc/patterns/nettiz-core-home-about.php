<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Home About', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"blockGap":"0px","padding":{"top":"90px","bottom":"100px","right":"20px","left":"20px"}}},"backgroundColor":"theme-2","layout":{"contentSize":"1180px","type":"constrained"}} -->
<div class="wp-block-group has-theme-2-background-color has-background" style="padding-top:90px;padding-right:20px;padding-bottom:100px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"90px","left":"90px"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"top":"0px","bottom":"30px"}}},"textColor":"black","className":"heading-2 nettiz-animate nettiz-move-right nettiz-delay-1","fontFamily":"mulish"} -->
<h2 class="wp-block-heading heading-2 nettiz-animate nettiz-move-right nettiz-delay-1 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:30px;font-style:normal;font-weight:700;line-height:1.2">Boost Your Business With These <span class="custom-highlight">Proven Strategies.</span></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"30px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","className":"nettiz-animate nettiz-move-right nettiz-delay-1","fontFamily":"heebo"} -->
<p class="nettiz-animate nettiz-move-right nettiz-delay-1 has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:30px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"style":{"spacing":{"padding":{"bottom":"40px"},"margin":{"bottom":"40px"},"blockGap":{"top":"50px","left":"50px"}},"border":{"bottom":{"color":"var:preset|color|theme-4","width":"1px"}}}} -->
<div class="wp-block-columns" style="border-bottom-color:var(--wp--preset--color--theme-4);border-bottom-width:1px;margin-bottom:40px;padding-bottom:40px"><!-- wp:column {"verticalAlignment":"top","className":"nettiz-animate nettiz-move-flip nettiz-delay-3"} -->
<div class="wp-block-column is-vertically-aligned-top nettiz-animate nettiz-move-flip nettiz-delay-3"><!-- wp:group {"style":{"spacing":{"padding":{"left":"0px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:0px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4233,"width":52,"height":52,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-bulb.png" alt="" class="wp-image-4233" width="52" height="52"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.4"},"spacing":{"margin":{"left":"15px"}}},"textColor":"black","className":"heading-4","fontFamily":"mulish"} -->
<h4 class="wp-block-heading heading-4 has-black-color has-text-color has-mulish-font-family" style="margin-left:15px;font-style:normal;font-weight:700;line-height:1.4">Best Solutions</h4>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"20px"}}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-top:20px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","className":"nettiz-animate nettiz-move-flip nettiz-delay-5"} -->
<div class="wp-block-column is-vertically-aligned-top nettiz-animate nettiz-move-flip nettiz-delay-5"><!-- wp:group {"style":{"spacing":{"padding":{"left":"0px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:0px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4232,"width":52,"height":52,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/thumb.png" alt="" class="wp-image-4232" width="52" height="52"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.4"},"spacing":{"margin":{"left":"15px"}}},"textColor":"black","className":"heading-4","fontFamily":"mulish"} -->
<h4 class="wp-block-heading heading-4 has-black-color has-text-color has-mulish-font-family" style="margin-left:15px;font-style:normal;font-weight:700;line-height:1.4">Quality Service</h4>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"20px"}}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-top:20px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:buttons {"className":"nettiz-animate nettiz-move-right nettiz-delay-5"} -->
<div class="wp-block-buttons nettiz-animate nettiz-move-right nettiz-delay-5"><!-- wp:button {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700"}},"className":"is-style-custombuttonstyle2","fontFamily":"mulish"} -->
<div class="wp-block-button has-custom-font-size is-style-custombuttonstyle2 has-mulish-font-family" style="font-size:16px;font-style:normal;font-weight:700"><a class="wp-block-button__link wp-element-button" href="#">More About Us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"left":"0px","bottom":"0px","top":"0px","right":"0px"}}},"className":"is-style-customboxshadow nettiz-animate nettiz-move-up nettiz-delay-1"} -->
<div class="wp-block-column is-style-customboxshadow nettiz-animate nettiz-move-up nettiz-delay-1" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/StockSnap_WPFJXLWIZ7.webp","id":4234,"dimRatio":0,"minHeight":480,"minHeightUnit":"px","isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:480px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4234" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/StockSnap_WPFJXLWIZ7.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","placeholder":"Write title…","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
