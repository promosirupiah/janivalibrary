<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Single Content', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"100px","bottom":"100px","right":"20px","left":"20px"}}},"backgroundColor":"theme-2","layout":{"type":"constrained","contentSize":"800px"}} -->
<div class="wp-block-group has-theme-2-background-color has-background" style="padding-top:100px;padding-right:20px;padding-bottom:100px;padding-left:20px"><!-- wp:post-content {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"fontFamily":"heebo"} /-->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"50px","bottom":"50px"},"padding":{"bottom":"80px"}},"border":{"top":{"width":"0px","style":"none"},"right":{"width":"0px","style":"none"},"bottom":{"color":"var:preset|color|black","width":"2px"},"left":{"width":"0px","style":"none"}}}} -->
<div class="wp-block-columns" style="border-top-style:none;border-top-width:0px;border-right-style:none;border-right-width:0px;border-bottom-color:var(--wp--preset--color--black);border-bottom-width:2px;border-left-style:none;border-left-width:0px;margin-top:50px;margin-bottom:50px;padding-bottom:80px"><!-- wp:column {"verticalAlignment":"top"} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":5,"style":{"spacing":{"margin":{"right":"20px"}},"typography":{"lineHeight":"1","fontStyle":"normal","fontWeight":"600"}},"textColor":"black","className":"heading-5","fontFamily":"heebo"} -->
<h5 class="wp-block-heading heading-5 has-black-color has-text-color has-heebo-font-family" style="margin-right:20px;font-style:normal;font-weight:600;line-height:1">Tags :</h5>
<!-- /wp:heading -->

<!-- wp:post-terms {"term":"post_tag","style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"500"}},"textColor":"theme-6","fontFamily":"mulish"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group" style="margin-bottom:0"><!-- wp:heading {"level":5,"style":{"spacing":{"margin":{"top":"0","right":"20px","bottom":"0","left":"0"}},"typography":{"lineHeight":"1","fontStyle":"normal","fontWeight":"600"}},"textColor":"black","className":"heading-5","fontFamily":"heebo"} -->
<h5 class="wp-block-heading heading-5 has-black-color has-text-color has-heebo-font-family" style="margin-top:0;margin-right:20px;margin-bottom:0;margin-left:0;font-style:normal;font-weight:600;line-height:1">Share This :</h5>
<!-- /wp:heading -->

<!-- wp:social-links {"iconColor":"black","iconColorValue":"#000000","iconBackgroundColor":"theme-1","iconBackgroundColorValue":"#fecb5b","size":"has-small-icon-size","style":{"spacing":{"blockGap":{"top":"20px","left":"20px"}},"layout":{"selfStretch":"fit","flexSize":null}},"className":"is-style-default","layout":{"type":"flex","justifyContent":"space-between"}} -->
<ul class="wp-block-social-links has-small-icon-size has-icon-color has-icon-background-color is-style-default"><!-- wp:social-link {"url":"#","service":"facebook","label":"#"} /-->

<!-- wp:social-link {"url":"#","service":"whatsapp","label":"#"} /-->

<!-- wp:social-link {"url":"#","service":"twitter","label":"#"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:post-comments-form {"style":{"elements":{"link":{"color":{"text":"var:preset|color|theme-1"}}}},"textColor":"black","className":"wp-block-post-comments "} /--></div>
<!-- /wp:group -->',
);
