<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Single Hero', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:cover {"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp","id":4215,"dimRatio":0,"isDark":false,"className":"nettiz-margin-top-n180","style":{"spacing":{"padding":{"top":"280px","bottom":"120px"}}}} -->
<div class="wp-block-cover is-light nettiz-margin-top-n180" style="padding-top:280px;padding-bottom:120px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-4215" alt="" src="' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"constrained","wideSize":"1100px","contentSize":"1100px"}} -->
<div class="wp-block-group"><!-- wp:post-title {"textAlign":"center","level":1,"style":{"spacing":{"margin":{"bottom":"40px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.2"}},"textColor":"black","className":"heading-hero nettiz-animate nettiz-move-up nettiz-delay-1","fontFamily":"mulish"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained","contentSize":"300px"}} -->
<div class="wp-block-group"><!-- wp:columns {"isStackedOnMobile":false} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4262,"width":20,"height":20,"sizeSlug":"large","linkDestination":"none","style":{"color":{"duotone":["rgb(0, 0, 0)","rgb(1, 1, 1)"]}}} -->
<figure class="wp-block-image size-large is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-admin.svg" alt="" class="wp-image-4262" width="20" height="20"/></figure>
<!-- /wp:image -->

<!-- wp:post-author-name {"style":{"spacing":{"margin":{"left":"20px","top":"10px"}},"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.2"}},"textColor":"theme-6","fontFamily":"heebo"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4263,"width":20,"height":20,"sizeSlug":"large","linkDestination":"none","style":{"color":{"duotone":["rgb(0, 0, 0)","rgb(0, 0, 0)"]}}} -->
<figure class="wp-block-image size-large is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-clock.svg" alt="" class="wp-image-4263" width="20" height="20"/></figure>
<!-- /wp:image -->

<!-- wp:post-date {"style":{"spacing":{"margin":{"left":"20px","top":"10px"}},"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.2"}},"textColor":"theme-6","fontFamily":"heebo"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover -->',
);
