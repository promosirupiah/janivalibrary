<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse Footer', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"sticky":{"Desktop":false},"topSticky":{"Desktop":{"point":"0","unit":"px"}},"bottomSticky":{"Desktop":{"point":"0","unit":"px"}},"width":{"Desktop":"1170"},"gap":"no","elementId":"guten-fs4BEB","background":{"type":"default","color":{"type":"variable","id":"black"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":""}},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"100","bottom":"30"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20","top":"80","bottom":"20"}},"Mobile":{"unit":"px","dimension":{"top":"50"}}},"wrapColumn":{"Desktop":false,"Tablet":false,"Mobile":true}} -->
<div class="section-wrapper" data-id="fs4BEB"><section class="wp-block-gutenverse-section guten-element guten-section guten-fs4BEB layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-7Lb58Z"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-7Lb58Z"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="7Lb58Z"><div class="guten-column-wrapper"><!-- wp:gutenverse/section {"width":{"Desktop":"1170"},"isChild":true,"gap":"no","elementId":"guten-7fDeQy","margin":{"Desktop":{"unit":"px","dimension":{"bottom":"100"}},"Mobile":{"unit":"px","dimension":{"bottom":"30"}}},"padding":{"Desktop":[],"Mobile":[]}} -->
<div class="section-wrapper" data-id="7fDeQy"><section class="wp-block-gutenverse-section guten-element guten-section guten-7fDeQy layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50},"elementId":"guten-WEby3n"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-WEby3n"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="WEby3n"><div class="guten-column-wrapper"><!-- wp:gutenverse/image {"elementId":"guten-LFjORK","imgSrc":{"media":{"imageId":4307,"sizes":{"thumbnail":{"height":150,"width":150,"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/logo-putih-150x150.png","orientation":"landscape"},"medium":{"height":73,"width":300,"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/logo-putih-300x73.png","orientation":"landscape"},"full":{"url":"' . esc_url( NETTIZ_URI ) . 'assets/img/logo-putih.png","height":244,"width":1000,"orientation":"landscape"}}},"size":"full"},"altOriginal":"","captionOriginal":"","width":{"Desktop":{"point":"240","unit":"px"},"Mobile":{"point":"176","unit":"px"},"Tablet":{"point":"200","unit":"px"}},"height":{"Desktop":{"point":"","unit":"px"}},"url":"#","imgBorder":{"radius":{"Desktop":[],"Tablet":[],"Mobile":[]}},"align":{"Desktop":"left"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"20"}},"Tablet":{"unit":"px","dimension":{"bottom":"30"}}},"padding":{"Desktop":[],"Tablet":[]}} -->
<div class="wp-block-gutenverse-image guten-element guten-image guten-LFjORK"><a class="guten-image-wrapper" href="#"><img class="gutenverse-image-box-filled" src="' . esc_url( NETTIZ_URI ) . 'assets/img/logo-putih.png" height="244" width="1000"/></a></div>
<!-- /wp:gutenverse/image -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-spfMK2","textColor":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"7AdsQe","font":{"label":"Heebo","value":"Heebo","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"14","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"},"Tablet":{"unit":"em","point":"1.5"},"Mobile":{"unit":"em","point":"1.5"}},"weight":"400"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"50"}},"Mobile":{"unit":"px","dimension":{"right":"0","bottom":"30"}}},"padding":{"Desktop":[],"Mobile":[]}} -->
<div class="guten-element gutenverse-text-editor guten-spfMK2"><div class="text-content-inner"><!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"fontFamily":"heebo"} -->
<p class="has-heebo-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur elit.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->

<!-- wp:gutenverse/social-icons {"elementId":"guten-6eeoCn","iconSize":{"Desktop":{"point":"18","unit":"px"}},"gap":{"Desktop":"30"},"alignment":{"Desktop":"flex-start"},"shape":"circle","color":"custom","iconColor":{"type":"variable","id":"theme-2"},"bgColor":{"r":0,"g":0,"b":0,"a":0},"iconBorder":{"radius":{"Desktop":[]}},"itemPadding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"hoverIconColor":{"type":"variable","id":"theme-1"}} -->
<div class="guten-element guten-social-icons guten-6eeoCn circle horizontal custom"><!-- wp:gutenverse/social-icon {"elementId":"guten-TE0EH3"} -->
<div class="guten-element guten-social-icon guten-TE0EH3 facebook"><a id="guten-TE0EH3" href="#"><i class="gtn gtn-facebook-f"></i><span></span></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-LfiBjj"} -->
<div class="guten-element guten-social-icon guten-LfiBjj twitter"><a id="guten-LfiBjj" href="#"><i class="gtn gtn-twitter-light"></i><span></span></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-cHz67h"} -->
<div class="guten-element guten-social-icon guten-cHz67h instagram"><a id="guten-cHz67h" href="#"><i class="fab fa-instagram"></i><span></span></a></div>
<!-- /wp:gutenverse/social-icon -->

<!-- wp:gutenverse/social-icon {"elementId":"guten-0LWKos"} -->
<div class="guten-element guten-social-icon guten-0LWKos link"><a id="guten-0LWKos" href="#"><i class="gtn gtn-linkedin-light"></i><span></span></a></div>
<!-- /wp:gutenverse/social-icon --></div>
<!-- /wp:gutenverse/social-icons --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":25,"Mobile":null},"elementId":"guten-yLpSux","margin":{"Mobile":{"unit":"px","dimension":{"top":"30"}}},"padding":{"Mobile":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-yLpSux"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="yLpSux"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-20x6Qu","type":3,"color":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"UyffT5","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"20","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.4"}},"weight":"700"},"border":{"radius":{"Desktop":[]},"bottom":{"type":"solid","width":"2","color":{"type":"variable","id":"theme-2"}}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"30"}},"Mobile":{"unit":"px","dimension":{"bottom":"20"}},"Tablet":{"unit":"px","dimension":{"bottom":"30"}}},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"20"}},"Mobile":[],"Tablet":[]},"positioningType":{"Desktop":"inline"}} -->
<h3 class="wp-block-gutenverse-heading guten-element guten-20x6Qu">Quick Links</h3>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-vn1VzI","spaceBetween":{"Desktop":"20"},"iconColor":{"type":"variable","id":"theme-1"},"iconSize":{"Desktop":"15"},"textColor":{"type":"variable","id":"theme-2"},"textColorHover":{"type":"variable","id":"theme-1"},"textIndent":{"Desktop":"10"},"textTypography":{"type":"variable","id":"fYWuaq","font":{"label":"Heebo","value":"Heebo","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"},"Tablet":{"unit":"em","point":"1.5"},"Mobile":{"unit":"em","point":"1.5"}},"weight":"400"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"5"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"default"}} -->
<div class="guten-element guten-icon-list guten-vn1VzI"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-ano7d2","hideIcon":true} -->
<div class="guten-element guten-icon-list-item guten-ano7d2"><a id="guten-ano7d2" href="#"><span class="list-text no-icon">About Us</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-Bgbzvy","hideIcon":true} -->
<div class="guten-element guten-icon-list-item guten-Bgbzvy"><a id="guten-Bgbzvy" href="#"><span class="list-text no-icon">Services</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-D9kjHx","hideIcon":true} -->
<div class="guten-element guten-icon-list-item guten-D9kjHx"><a id="guten-D9kjHx" href="#"><span class="list-text no-icon">Projects</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-E0ziii","hideIcon":true} -->
<div class="guten-element guten-icon-list-item guten-E0ziii"><a id="guten-E0ziii" href="#"><span class="list-text no-icon">Pricing</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-HCMxgP","hideIcon":true} -->
<div class="guten-element guten-icon-list-item guten-HCMxgP"><a id="guten-HCMxgP" href="#"><span class="list-text no-icon">Contact</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div>
<!-- /wp:gutenverse/icon-list --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":25,"Mobile":null},"elementId":"guten-MKzIbD","margin":{"Mobile":{"unit":"px","dimension":{"top":"30"}}},"padding":{"Mobile":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-MKzIbD"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="MKzIbD"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-zhTIMY","type":3,"color":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"UyffT5","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"20","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.4"}},"weight":"700"},"border":{"radius":{"Desktop":[]},"bottom":{"type":"solid","width":"2","color":{"type":"variable","id":"theme-2"}}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"30"}},"Mobile":{"unit":"px","dimension":{"bottom":"20"}},"Tablet":{"unit":"px","dimension":{"bottom":"30"}}},"padding":{"Desktop":{"unit":"px","dimension":{"bottom":"20"}},"Mobile":[],"Tablet":[]},"positioningType":{"Desktop":"inline"}} -->
<h3 class="wp-block-gutenverse-heading guten-element guten-zhTIMY">Office</h3>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-wTlELj","spaceBetween":{"Desktop":"20"},"iconColor":{"type":"variable","id":"theme-1"},"iconColorHover":{"type":"variable","id":"theme-1"},"iconSize":{"Desktop":"16","Mobile":"14"},"textColor":{"type":"variable","id":"theme-2"},"textColorHover":{"type":"variable","id":"theme-1"},"textIndent":{"Desktop":"15"},"textTypography":{"type":"variable","id":"fYWuaq","font":{"label":"Heebo","value":"Heebo","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"}},"weight":"400"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"20","top":"5"}},"Tablet":[]},"padding":{"Desktop":[],"Tablet":[]}} -->
<div class="guten-element guten-icon-list guten-wTlELj"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-Jgb7qT"} -->
<div class="guten-element guten-icon-list-item guten-Jgb7qT"><a id="guten-Jgb7qT"><i class="fas fa-map-pin"></i><span class="list-text ">Jl. Raya Kuta, Badung Bali</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-hkZHfg"} -->
<div class="guten-element guten-icon-list-item guten-hkZHfg"><a id="guten-hkZHfg"><i class="fas fa-phone-alt"></i><span class="list-text ">+62 361 8765432</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-z4SKON"} -->
<div class="guten-element guten-icon-list-item guten-z4SKON"><a id="guten-z4SKON"><i class="fas fa-envelope"></i><span class="list-text ">nettiz@gmail.com</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div>
<!-- /wp:gutenverse/icon-list --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->

<!-- wp:gutenverse/section {"width":{"Desktop":"1170"},"isChild":true,"gap":"no","elementId":"guten-0e0k85","border":{"radius":{"Desktop":[]},"top":{"type":"solid","width":"2","color":{"type":"variable","id":"theme-2"}}},"margin":{"Desktop":[],"Mobile":[],"Tablet":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"30","bottom":"0"}},"Mobile":{"unit":"px","dimension":{"top":"20","bottom":"0"}},"Tablet":{"unit":"px","dimension":{"bottom":"5"}}}} -->
<div class="section-wrapper" data-id="0e0k85"><section class="wp-block-gutenverse-section guten-element guten-section guten-0e0k85 layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":null},"elementId":"guten-Ka2ulZ","verticalAlign":{"Desktop":"center","Tablet":"center"},"margin":{"Tablet":[]},"padding":{"Tablet":{"unit":"px","dimension":{"bottom":"10","top":"","right":"","left":""}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-Ka2ulZ"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="Ka2ulZ"><div class="guten-column-wrapper"><!-- wp:gutenverse/text-editor {"elementId":"guten-CP2EL5","alignment":{"Mobile":"center"},"textColor":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"fYWuaq","font":{"label":"Heebo","value":"Heebo","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.5"}},"weight":"400"},"margin":{"Mobile":{"unit":"px","dimension":{"bottom":"10"}},"Tablet":[]},"padding":{"Mobile":[],"Tablet":[]}} -->
<div class="guten-element gutenverse-text-editor guten-CP2EL5"><div class="text-content-inner"><!-- wp:paragraph -->
<p>Copyright © 2023 Nettiz By Jegtstudio.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":null,"Mobile":null},"elementId":"guten-Kqck49","verticalAlign":{"Desktop":"default","Tablet":"center"},"horizontalAlign":{"Desktop":"flex-end"},"margin":{"Tablet":[]},"padding":{"Tablet":{"unit":"px","dimension":{"bottom":"10"}}},"hideMobile":true} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-Kqck49 hide-mobile"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="Kqck49"><div class="guten-column-wrapper"><!-- wp:gutenverse/icon {"elementId":"guten-efTDXw","icon":"gtn gtn-up-arrow-light","iconAlign":{"Desktop":"right"},"iconColorOne":{"r":0,"g":0,"b":0,"a":0},"iconSize":{"Desktop":{"point":"48","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-1"},"iconColorHoverOne":{"r":0,"g":0,"b":0,"a":0},"iconColorHoverTwo":{"type":"variable","id":"theme-1"},"url":"#header","margin":{"Desktop":{"unit":"px","dimension":{"top":"10"}}},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-icon guten-element guten-efTDXw guten-icon"><a class="guten-icon-wrapper rounded stacked" href="#header"><i class="gtn gtn-up-arrow-light"></i></a></div>
<!-- /wp:gutenverse/icon --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
