<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Service', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"color":{"background":"#fefcfa"},"spacing":{"blockGap":"0px","padding":{"top":"100px","bottom":"100px","right":"20px","left":"20px"}}},"layout":{"contentSize":"1180px","type":"constrained"}} -->
<div class="wp-block-group has-background" style="background-color:#fefcfa;padding-top:100px;padding-right:20px;padding-bottom:100px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"margin":{"bottom":"60px"}}}} -->
<div class="wp-block-columns" style="margin-bottom:60px"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"66.66%","style":{"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"},"blockGap":"0px"}}} -->
<div class="wp-block-column" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;flex-basis:66.66%"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"10px","bottom":"20px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.1","fontSize":"44px"}},"textColor":"black","className":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading heading-2 has-black-color has-text-color has-mulish-font-family" style="margin-top:10px;margin-bottom:20px;font-size:44px;font-style:normal;font-weight:700;line-height:1.1">Service Options <span class="custom-highlight">Available.</span></h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"0px"}}},"layout":{"type":"constrained","justifyContent":"left","contentSize":"500px"}} -->
<div class="wp-block-group" style="margin-bottom:0px"><!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"0px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:0px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:buttons {"layout":{"type":"flex","justifyContent":"right","verticalAlignment":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700","lineHeight":"1"}},"className":"is-style-custombuttonstyle2","fontFamily":"mulish"} -->
<div class="wp-block-button has-custom-font-size is-style-custombuttonstyle2 has-mulish-font-family" style="font-size:16px;font-style:normal;font-weight:700;line-height:1"><a class="wp-block-button__link wp-element-button" href="#">Discover More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"40px","left":"40px"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"style":{"border":{"width":"2px"},"spacing":{"padding":{"top":"30px","right":"30px","bottom":"30px","left":"30px"}}},"borderColor":"black","backgroundColor":"theme-2","className":"is-style-customboxshadowhover1 nettiz-animate nettiz-move-up nettiz-1"} -->
<div class="wp-block-column is-style-customboxshadowhover1 nettiz-animate nettiz-move-up nettiz-1 has-border-color has-black-border-color has-theme-2-background-color has-background" style="border-width:2px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4238,"width":112,"height":112,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["rgb(9, 9, 9)","rgb(255, 255, 255)"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/light-chart.png" alt="" class="wp-image-4238" width="112" height="112"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"0px","bottom":"5px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:5px;font-style:normal;font-weight:700;line-height:1.3">SEO Booster</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"placeholder":"Content…","style":{"spacing":{"margin":{"bottom":"10px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:10px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectet adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"30px","right":"30px","bottom":"30px","left":"30px"}},"border":{"width":"2px"}},"borderColor":"black","backgroundColor":"theme-2","className":"is-style-customboxshadow is-style-customboxshadowhover2 nettiz-2 nettiz-animate nettiz-move-up"} -->
<div class="wp-block-column is-style-customboxshadow is-style-customboxshadowhover2 nettiz-2 nettiz-animate nettiz-move-up has-border-color has-black-border-color has-theme-2-background-color has-background" style="border-width:2px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4239,"width":112,"height":112,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/light-graphic.png" alt="" class="wp-image-4239" width="112" height="112"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"0px","bottom":"5px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:5px;font-style:normal;font-weight:700;line-height:1.3">Business Growth</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"placeholder":"Content…","style":{"spacing":{"margin":{"bottom":"10px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:10px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectet adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"30px","right":"25px","bottom":"30px","left":"30px"}},"border":{"width":"2px"}},"borderColor":"black","backgroundColor":"theme-2","className":"is-style-customboxshadowhover1 nettiz-animate nettiz-move-up nettiz-3"} -->
<div class="wp-block-column is-style-customboxshadowhover1 nettiz-animate nettiz-move-up nettiz-3 has-border-color has-black-border-color has-theme-2-background-color has-background" style="border-width:2px;padding-top:30px;padding-right:25px;padding-bottom:30px;padding-left:30px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4240,"width":112,"height":112,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/light-market.png" alt="" class="wp-image-4240" width="112" height="112"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"0px","bottom":"5px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:5px;font-style:normal;font-weight:700;line-height:1.3">Digital Marketing</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"placeholder":"Content…","style":{"spacing":{"margin":{"bottom":"10px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:10px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectet adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"40px","left":"40px"},"margin":{"top":"30px"}}}} -->
<div class="wp-block-columns" style="margin-top:30px"><!-- wp:column {"style":{"spacing":{"padding":{"top":"30px","right":"30px","bottom":"30px","left":"30px"}},"border":{"width":"2px"}},"borderColor":"black","backgroundColor":"theme-2","className":"is-style-customboxshadow is-style-customboxshadowhover2 nettiz-1 nettiz-animate nettiz-move-up"} -->
<div class="wp-block-column is-style-customboxshadow is-style-customboxshadowhover2 nettiz-1 nettiz-animate nettiz-move-up has-border-color has-black-border-color has-theme-2-background-color has-background" style="border-width:2px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group"><!-- wp:image {"id":4241,"width":112,"height":112,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-brain.png" alt="" class="wp-image-4241" width="112" height="112"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"0px","bottom":"5px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:5px;font-style:normal;font-weight:700;line-height:1.3">Branding Identity</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"placeholder":"Content…","style":{"spacing":{"margin":{"bottom":"10px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:10px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectet adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"30px","right":"30px","bottom":"30px","left":"30px"}},"border":{"width":"2px"}},"borderColor":"black","backgroundColor":"theme-2","className":"is-style-customboxshadowhover1 nettiz-animate nettiz-move-up nettiz-2"} -->
<div class="wp-block-column is-style-customboxshadowhover1 nettiz-animate nettiz-move-up nettiz-2 has-border-color has-black-border-color has-theme-2-background-color has-background" style="border-width:2px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px"><!-- wp:group {"style":{"spacing":{"padding":{"left":"1px"}}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group" style="padding-left:1px"><!-- wp:image {"id":4242,"width":112,"height":112,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/solid-file.png" alt="" class="wp-image-4242" width="112" height="112"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"0px","bottom":"5px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:5px;font-style:normal;font-weight:700;line-height:1.3">Data Analysis</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"placeholder":"Content…","style":{"spacing":{"margin":{"bottom":"10px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:10px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectet adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"30px","right":"30px","bottom":"30px","left":"30px"}},"border":{"width":"2px"}},"borderColor":"black","backgroundColor":"theme-2","className":"is-style-customboxshadow is-style-customboxshadowhover2 nettiz-3 nettiz-animate nettiz-move-up"} -->
<div class="wp-block-column is-style-customboxshadow is-style-customboxshadowhover2 nettiz-3 nettiz-animate nettiz-move-up has-border-color has-black-border-color has-theme-2-background-color has-background" style="border-width:2px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px"><!-- wp:group {"style":{"spacing":{"padding":{"left":"3px"}}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group" style="padding-left:3px"><!-- wp:image {"id":4243,"width":112,"height":112,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/light-laptop.png" alt="" class="wp-image-4243" width="112" height="112"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"padding":{"left":"20px"}}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group" style="padding-left:20px"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"0px","bottom":"5px"}},"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"}},"textColor":"black","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-black-color has-text-color has-mulish-font-family" style="margin-top:0px;margin-bottom:5px;font-style:normal;font-weight:700;line-height:1.3">Content Writing</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"placeholder":"Content…","style":{"spacing":{"margin":{"bottom":"10px"}},"typography":{"fontStyle":"normal","fontWeight":"400","lineHeight":"1.5","fontSize":"16px"}},"textColor":"theme-0","fontFamily":"heebo"} -->
<p class="has-theme-0-color has-text-color has-heebo-font-family" style="margin-bottom:10px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectet adipiscing elit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
