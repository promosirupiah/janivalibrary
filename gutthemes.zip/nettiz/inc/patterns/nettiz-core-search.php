<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Search', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"right":"20px","left":"20px","top":"100px","bottom":"0px"}}},"layout":{"type":"constrained","contentSize":"1180px"}} -->
<div class="wp-block-group" style="padding-top:100px;padding-right:20px;padding-bottom:0px;padding-left:20px"><!-- wp:search {"label":"Search","showLabel":false,"width":100,"widthUnit":"%","buttonText":"Search","align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700","lineHeight":"1.5"},"border":{"radius":"0px","width":"2px"}},"borderColor":"black","backgroundColor":"theme-1","textColor":"black","fontFamily":"mulish"} /--></div>
<!-- /wp:group -->',
);
