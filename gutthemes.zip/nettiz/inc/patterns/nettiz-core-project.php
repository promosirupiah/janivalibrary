<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Project', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"blockGap":"0px","padding":{"top":"100px","bottom":"100px","right":"20px","left":"20px"}}},"backgroundColor":"black","layout":{"contentSize":"1180px","type":"constrained"}} -->
<div class="wp-block-group has-black-background-color has-background" style="padding-top:100px;padding-right:20px;padding-bottom:100px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"100px","left":"100px"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"top","width":""} -->
<div class="wp-block-column is-vertically-aligned-top"><!-- wp:group {"layout":{"type":"constrained","contentSize":"","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"28px","fontStyle":"normal","fontWeight":"500","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"mulish"} -->
<p class="has-theme-2-color has-text-color has-mulish-font-family" style="font-size:28px;font-style:normal;font-weight:500;line-height:1.5">We’ve completed various long and short-term projects for customers worldwide, delivering excellent results that made a significant impact on their businesses</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"140px"} -->
<div style="height:140px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"0px"}}}} -->
<div class="wp-block-buttons" style="margin-top:0px"><!-- wp:button {"backgroundColor":"theme-1","textColor":"black","style":{"spacing":{"padding":{"top":"15px","bottom":"15px","left":"30px","right":"30px"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700"}},"className":"is-style-custombuttonstyle3","fontFamily":"mulish"} -->
<div class="wp-block-button has-custom-font-size is-style-custombuttonstyle3 has-mulish-font-family" style="font-size:16px;font-style:normal;font-weight:700"><a class="wp-block-button__link has-black-color has-theme-1-background-color has-text-color has-background wp-element-button" href="#" style="padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px">View More Project</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"left":"0px","bottom":"0px","top":"0px","right":"0px"},"blockGap":"0px"}}} -->
<div class="wp-block-column" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:columns {"verticalAlignment":"center","style":{"border":{"bottom":{"color":"var:preset|color|theme-6","width":"1px"}},"spacing":{"padding":{"bottom":"30px"},"margin":{"bottom":"30px"}}},"className":"nettiz-animate nettiz-move-up nettiz-delay-1"} -->
<div class="wp-block-columns are-vertically-aligned-center nettiz-animate nettiz-move-up nettiz-delay-1" style="border-bottom-color:var(--wp--preset--color--theme-6);border-bottom-width:1px;margin-bottom:30px;padding-bottom:30px"><!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:heading {"level":3,"style":{"typography":{"lineHeight":"1.3","fontStyle":"normal","fontWeight":"700"},"spacing":{"margin":{"bottom":"10px"}}},"textColor":"theme-2","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-theme-2-color has-text-color has-mulish-font-family" style="margin-bottom:10px;font-style:normal;font-weight:700;line-height:1.3">Branding Strategy</h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"66.66%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:66.66%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"spacing":{"margin":{"right":"35px"}},"typography":{"fontSize":"16px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"400"}},"textColor":"theme-2","fontFamily":"heebo"} -->
<p class="has-theme-2-color has-text-color has-heebo-font-family" style="margin-right:35px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet, consecte adipiscing elit sed do eiusmod tempor incididunt.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":4236,"width":36,"height":28,"sizeSlug":"full","linkDestination":"custom","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}}} -->
<figure class="wp-block-image size-full is-resized"><a href="#"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/right-arrow-icon.png" alt="" class="wp-image-4236" width="36" height="28"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"center","style":{"border":{"bottom":{"color":"var:preset|color|theme-6","width":"1px"}},"spacing":{"padding":{"bottom":"30px"},"margin":{"top":"30px","bottom":"30px"}}},"className":"nettiz-animate nettiz-move-up nettiz-delay-3"} -->
<div class="wp-block-columns are-vertically-aligned-center nettiz-animate nettiz-move-up nettiz-delay-3" style="border-bottom-color:var(--wp--preset--color--theme-6);border-bottom-width:1px;margin-top:30px;margin-bottom:30px;padding-bottom:30px"><!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:heading {"level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"},"spacing":{"margin":{"bottom":"10px","right":"20px"}}},"textColor":"theme-2","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-theme-2-color has-text-color has-mulish-font-family" style="margin-right:20px;margin-bottom:10px;font-style:normal;font-weight:700;line-height:1.3">Data Analysis</h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"66.66%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:66.66%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"spacing":{"margin":{"right":"35px"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"heebo"} -->
<p class="has-theme-2-color has-text-color has-heebo-font-family" style="margin-right:35px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet, consecte adipiscing elit sed do eiusmod tempor incididunt.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":4236,"width":36,"height":28,"sizeSlug":"full","linkDestination":"custom","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}}} -->
<figure class="wp-block-image size-full is-resized"><a href="#"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/right-arrow-icon.png" alt="" class="wp-image-4236" width="36" height="28"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"center","style":{"border":{"bottom":{"color":"var:preset|color|theme-6","width":"1px"}},"spacing":{"padding":{"bottom":"30px"}}},"className":"nettiz-animate nettiz-move-up nettiz-delay-5"} -->
<div class="wp-block-columns are-vertically-aligned-center nettiz-animate nettiz-move-up nettiz-delay-5" style="border-bottom-color:var(--wp--preset--color--theme-6);border-bottom-width:1px;padding-bottom:30px"><!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"><!-- wp:heading {"level":3,"style":{"typography":{"fontStyle":"normal","fontWeight":"700","lineHeight":"1.3"},"spacing":{"margin":{"bottom":"10px","right":"40px"}}},"textColor":"theme-2","className":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading heading-3 has-theme-2-color has-text-color has-mulish-font-family" style="margin-right:40px;margin-bottom:10px;font-style:normal;font-weight:700;line-height:1.3">SEO Booster</h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"66.66%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:66.66%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"spacing":{"margin":{"right":"35px"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"heebo"} -->
<p class="has-theme-2-color has-text-color has-heebo-font-family" style="margin-right:35px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet, consecte adipiscing elit sed do eiusmod tempor incididunt.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":4236,"width":36,"height":28,"sizeSlug":"full","linkDestination":"custom","style":{"color":{"duotone":["rgb(254, 203, 91)","rgb(254, 203, 91)"]}}} -->
<figure class="wp-block-image size-full is-resized"><a href="#"><img src="' . esc_url( NETTIZ_URI ) . 'assets/img/right-arrow-icon.png" alt="" class="wp-image-4236" width="36" height="28"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
