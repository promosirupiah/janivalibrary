<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse Page Hero', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"600"},"gap":"no","elementId":"guten-y7dxGi","background":{"type":"default","image":{"Desktop":{"id":4215,"image":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-120"}},"Tablet":{"unit":"px","dimension":{"top":"-150"}},"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"180","bottom":"130"}},"Tablet":[],"Mobile":{"unit":"px","dimension":{"top":"190","right":"20","left":"20","bottom":"80"}}}} -->
<div class="section-wrapper" data-id="y7dxGi"><section class="wp-block-gutenverse-section guten-element guten-section guten-y7dxGi layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-VAdtnA","horizontalAlign":{"Desktop":"center"},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"all":{"type":"solid","width":"2","color":{"type":"variable","id":"black"}}},"boxShadow":{"color":{"type":"variable","id":"black"},"horizontal":"10","vertical":"10"},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"40","bottom":"40","left":"40"}}},"animation":{"type":{"Desktop":"fadeIn"},"duration":"normal","delay":"100"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-VAdtnA animated guten-element-hide desktop-fadeIn"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="VAdtnA"><div class="guten-column-wrapper"><!-- wp:gutenverse/post-title {"elementId":"guten-xZcEvX","alignment":{"Desktop":"center"},"typography":{"type":"variable","id":"Epnwe1","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"64","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.2"}},"weight":"700"},"color":{"type":"variable","id":"black"}} -->
<div class="guten-element guten-post-title guten-xZcEvX"></div>
<!-- /wp:gutenverse/post-title --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
