<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Core Header', 'nettiz' ),
	'categories' => array( 'nettiz-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"right":"20px","left":"20px","top":"20px"}}},"className":"nettiz-z-index-10","layout":{"type":"constrained","contentSize":"1180px"}} -->
<div class="wp-block-group nettiz-z-index-10" style="padding-top:20px;padding-right:20px;padding-left:20px"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:site-title {"style":{"typography":{"fontSize":"28px","fontStyle":"normal","fontWeight":"700"}},"textColor":"theme-3","fontFamily":"mulish"} /-->

<!-- wp:navigation {"textColor":"black","className":"is-style-customnav","layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"blockGap":"40px"},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"700"}},"fontFamily":"mulish"} -->
<!-- wp:navigation-link {"label":"Home","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"About","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-submenu {"label":"Pages","url":"#","kind":"custom","isTopLevelItem":true} -->

<!-- wp:navigation-link {"label":"Service","url":"#","kind":"custom","isTopLevelLink":false} /-->

<!-- wp:navigation-link {"label":"Our Team","url":"#","kind":"custom","isTopLevelLink":false} /-->

<!-- wp:navigation-link {"label":"Pricing","url":"#","kind":"custom","isTopLevelLink":false} /-->

<!-- wp:navigation-link {"label":"FAQ","url":"#","kind":"custom","isTopLevelLink":false} /-->

<!-- /wp:navigation-submenu -->

<!-- wp:navigation-link {"label":"Blog","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Contact","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- /wp:navigation -->

<!-- wp:buttons {"className":"hide-in-tablet hide-in-mobile","layout":{"type":"flex","justifyContent":"right"}} -->
<div class="wp-block-buttons hide-in-tablet hide-in-mobile"><!-- wp:button {"backgroundColor":"theme-1","textColor":"black","style":{"spacing":{"padding":{"top":"15px","bottom":"15px","left":"30px","right":"30px"}},"typography":{"fontStyle":"normal","fontWeight":"500"}},"className":"is-style-custombuttonstyle1 is-style-outline"} -->
<div class="wp-block-button is-style-custombuttonstyle1 is-style-outline" style="font-style:normal;font-weight:500"><a class="wp-block-button__link has-black-color has-theme-1-background-color has-text-color has-background wp-element-button" href="#" style="padding-top:15px;padding-right:30px;padding-bottom:15px;padding-left:30px">Contact Us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);
