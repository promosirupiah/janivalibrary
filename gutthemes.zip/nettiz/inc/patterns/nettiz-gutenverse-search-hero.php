<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Nettiz Gutenverse Search Hero', 'nettiz' ),
	'categories' => array( 'nettiz-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"600"},"gap":"no","elementId":"guten-CT0uxi","background":{"type":"default","image":{"Desktop":{"id":4215,"image":"' . esc_url( NETTIZ_URI ) . 'assets/img/background-hero.webp"}},"position":{"Desktop":"center center"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"cover"}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-120"}},"Tablet":{"unit":"px","dimension":{"top":"-150"}},"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"200","bottom":"130"}},"Tablet":[],"Mobile":{"unit":"px","dimension":{"right":"20","left":"20","top":"190","bottom":"80"}}}} -->
<div class="section-wrapper" data-id="CT0uxi"><section class="wp-block-gutenverse-section guten-element guten-section guten-CT0uxi layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-hh38mR","horizontalAlign":{"Desktop":"center","Tablet":"center"},"border":{"radius":{"Desktop":[]},"all":{"type":"solid","width":"2","color":{"type":"variable","id":"black"}}},"boxShadow":{"color":{"type":"variable","id":"black"},"horizontal":"10","vertical":"10"},"margin":{"Desktop":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"30","right":"40","bottom":"40","left":"40"}},"Mobile":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}},"animation":{"type":{"Desktop":"fadeIn"},"duration":"normal","delay":"100"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-hh38mR animated guten-element-hide desktop-fadeIn"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="hh38mR"><div class="guten-column-wrapper"><!-- wp:query-title {"type":"search","textAlign":"center","showSearchTerm":false,"style":{"typography":{"fontSize":"64px","lineHeight":"1.2","fontStyle":"normal","fontWeight":"700"}},"textColor":"black","fontFamily":"mulish"} /--></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
