=== Nettiz ===
Contributors: Jegtheme
Requires at least: 6.1
Tested up to: 6.2
Requires PHP: 7.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Nettiz is a WordPress theme that looks great on any device and works with the Gutenverse plugin. It's customizable, making it perfect for SEO & Internet Marketing Agency, Social Media Marketing, and Digital Agency. You can use the included core and Gutenverse versions to make it easy to create the website you want. We want to make sure you have the best experience using WordPress to edit your site.

== Copyright ==

Nettiz, 2023 Jegstudio
Nettiz is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Self designed images,
* Logo 1 : nettiz/assets/img/logo-hitam.png
* Logo 2 : nettiz/assets/img/logo-putih.png
* Button : nettiz/assets/img/button-circle.png
* Background Home : nettiz/assets/img/Background-home-hero.webp
* Background Hero : nettiz/assets/img/background-hero.webp
* Background Core : nettiz/assets/img/background-core.webp
Declaring these self designed images under GPL license version 2.0 =
License URL: http://www.gnu.org/licenses/gpl-2.0.html

Edited Image StockSnap_JSDMDDA208_circle.png, Original image by Bruce Mars
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/man-music-JSDMDDA208

Icon for theme screenshot,
License: (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
License URL: https://fontawesome.com/license/free

Icons and Icon Images for block pattern,
License: (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
License URL: https://fontawesome.com/license/free

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-people-BTNAYJYPRX

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-people-NS0TW3LSDM

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-people-AKSM11WW9N

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-people-JVU7DG266D

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-women-BOWOZQBREK

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/women-working-EVIDLDTDO3

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-team-MMVZMKKRU8

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-team-CZVXLM4SH2

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-team-BXVO5YWHDY

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/women-working-2VU3XNN1MA

Image for theme screenshot and block pattern, Credit Allef Vinicius
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/people-woman-C9Z2H1GO4N

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-ACDUZXSZWG 

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-H9TNFM5SFG

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-FPQIEQBMPA 

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/senior-business-UTEZRDTKPP

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-S81ZPXJZUU 

Image for theme screenshot and block pattern, Credit Candace McDaniel
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/male-model-6KOCQ5VD8H

Image for theme screenshot and block pattern, Credit Kristin Hardwick
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/woman-business-LERRJPTMHP

Image for theme screenshot and block pattern, Credit Bruce Mars
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/man-music-JSDMDDA208

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-people-PAQJGIXNYI

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-7BQNRHB6EX

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-IVZBYWKEFM

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-team-V8NHXQVQ70

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-people-WPFJXLWIZ7

Image for block pattern
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/16363

Image for block pattern, Credit K Doc
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1652043

Image for block pattern, Credit Rawpixel.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1449941

Image for block pattern, Credit Rawpixel.com
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1652043 

== Changelog ==

= 1.0.3 - 2024-03-21 =
* Update notice design

= 1.0.2 - 2023-07-11 =
* Update theme dashboard
* Fix post content inherit layout
* Add blank canvas template

= 1.0.1 - 2023-06-09 =
* Fix theme URI

= 1.0.0 - 2023-06-02 =
* Initial release