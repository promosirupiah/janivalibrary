<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-components', 'wp-data', 'wp-edit-site', 'wp-hooks', 'wp-i18n', 'wp-plugins'), 'version' => '294aed733f085d3eb088');
