<?php return array('dependencies' => array(), 'version' => '50920cd8eb03eb0d62be');
