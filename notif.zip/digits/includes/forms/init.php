<?php

if (!defined('ABSPATH')) {
    exit;
}
require_once plugin_dir_path(__FILE__) . 'signup_field.php';
require_once plugin_dir_path(__FILE__) . 'signup.php';
require_once plugin_dir_path(__FILE__) . 'render.php';
require_once plugin_dir_path(__FILE__) . 'render_extras.php';
require_once plugin_dir_path(__FILE__) . 'admin.php';
require_once plugin_dir_path(__FILE__) . 'handler/handler.php';
require_once plugin_dir_path(__FILE__) . 'email_handler.php';
require_once plugin_dir_path(__FILE__) . 'render_approval.php';
require_once plugin_dir_path(__FILE__) . 'fonts.php';
