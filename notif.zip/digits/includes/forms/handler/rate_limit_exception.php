<?php

if (!defined('ABSPATH')) {
    exit;
}

class DigitsRateLimitException extends Exception
{
}