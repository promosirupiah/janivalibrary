<?php

if (!defined('ABSPATH')) {
    exit;
}

class DigitsFireBaseException extends Exception
{
}