<?php

if (!defined('ABSPATH')) {
    exit;
}

class DigitsNoticeException extends Exception
{
}