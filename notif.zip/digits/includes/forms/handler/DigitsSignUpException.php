<?php

if (!defined('ABSPATH')) {
    exit;
}

class DigitsSignUpException extends Exception
{
}