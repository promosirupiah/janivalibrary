<?php


namespace Twilio\Exceptions;


use Exception;

class TwilioException extends Exception {

}