<?php

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'newsletter.php';
require_once plugin_dir_path(__FILE__) . 'user_groups.php';
require_once plugin_dir_path(__FILE__) . 'handler.php';
