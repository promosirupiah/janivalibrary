<?php

namespace WPNotif_Compatibility;

if (!defined('ABSPATH')) {
    exit;
}


require_once 'gravityforms/handler.php';
require_once 'contactform7/handler.php';
require_once 'buddypress/handler.php';

require_once 'madxartwork/handler.php';
require_once 'edd/ini.php';
require_once 'woocommerce/cart.php';
//require_once 'wpforms/handler.php';