<?php

namespace Firebase\Dig_Firebase;

class ExpiredException extends \UnexpectedValueException {

}
