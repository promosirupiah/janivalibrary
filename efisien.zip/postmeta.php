<?php
/**
 * Plugin Name: Compact Postmeta Manager
 * Description: Menyimpan postmeta tertentu dalam satu baris JSON untuk menghemat database, tetap kompatibel dengan fungsi WP.
 * Version: 1.0
 * Author: Qwen3.7
 */

if (!defined('ABSPATH')) exit;

class Compact_Postmeta_Manager {
    
    private $table_name;
    private $option_name = 'cpm_compact_keys';
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'compact_postmeta';
        
        // Hooks
        register_activation_hook(__FILE__, array($this, 'create_table'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Intercept Core Meta Functions
        add_filter('get_post_metadata', array($this, 'intercept_get'), 10, 4);
        add_filter('add_post_metadata', array($this, 'intercept_add'), 10, 5);
        add_filter('update_post_metadata', array($this, 'intercept_update'), 10, 5);
        add_filter('delete_post_metadata', array($this, 'intercept_delete'), 10, 5);
        
        // Action untuk migrasi data
        add_action('admin_post_cpm_migrate_data', array($this, 'handle_migration'));
    }

    /**
     * 1. Buat Tabel Database Custom
     */
    public function create_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            post_id bigint(20) UNSIGNED NOT NULL,
            meta_payload longtext NOT NULL,
            PRIMARY KEY (post_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * 2. Helper: Cek apakah meta key termasuk dalam daftar compact
     */
    private function is_compact_key($meta_key) {
        $keys = get_option($this->option_name, '_thumbnail_id, _wp_old_slug, _wp_old_date');
        $allowed_keys = array_map('trim', explode(',', $keys));
        return in_array($meta_key, $allowed_keys);
    }

    /**
     * 3. Helper: Ambil payload JSON untuk sebuah post
     */
    private function get_payload($post_id) {
        global $wpdb;
        $payload = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_payload FROM {$this->table_name} WHERE post_id = %d",
            $post_id
        ));
        return $payload ? json_decode($payload, true) : array();
    }

    /**
     * 4. Helper: Simpan payload JSON
     */
    private function save_payload($post_id, $data) {
        global $wpdb;
        $json_data = json_encode($data);
        
        $wpdb->replace(
            $this->table_name,
            array(
                'post_id' => $post_id,
                'meta_payload' => $json_data
            ),
            array('%d', '%s')
        );
    }

    /**
     * 5. Intercept GET Post Meta
     */
    public function intercept_get($check, $object_id, $meta_key, $single) {
        if (!$this->is_compact_key($meta_key)) {
            return $check; // Biarkan WordPress menangani secara default
        }

        $payload = $this->get_payload($object_id);
        
        if (!array_key_exists($meta_key, $payload)) {
            return $check; // Fallback ke wp_postmeta jika belum ada di tabel compact
        }

        $value = $payload[$meta_key];

        // Meniru perilaku asli WordPress untuk parameter $single
        if (!$single && !is_array($value)) {
            return array($value);
        }
        
        return $value;
    }

    /**
     * 6. Intercept ADD Post Meta
     */
    public function intercept_add($check, $object_id, $meta_key, $meta_value, $unique) {
        if (!$this->is_compact_key($meta_key)) {
            return $check;
        }

        $payload = $this->get_payload($object_id);

        if ($unique && array_key_exists($meta_key, $payload)) {
            return false; // Gagal karena sudah ada dan $unique = true
        }

        // Menangani multiple values (jika add dipanggil berkali-kali untuk key yang sama)
        if (array_key_exists($meta_key, $payload)) {
            if (!is_array($payload[$meta_key])) {
                $payload[$meta_key] = array($payload[$meta_key], $meta_value);
            } else {
                $payload[$meta_key][] = $meta_value;
            }
        } else {
            $payload[$meta_key] = $meta_value;
        }

        $this->save_payload($object_id, $payload);
        return true; // Beritahu WP kita sudah menanganinya
    }

    /**
     * 7. Intercept UPDATE Post Meta
     */
    public function intercept_update($check, $object_id, $meta_key, $meta_value, $prev_value) {
        if (!$this->is_compact_key($meta_key)) {
            return $check;
        }

        $payload = $this->get_payload($object_id);

        // Jika prev_value ditentukan, cek kecocokan dulu
        if ($prev_value !== '') {
            $current_val = isset($payload[$meta_key]) ? $payload[$meta_key] : null;
            if ($current_val != $prev_value) {
                return false; // Abort update
            }
        }

        $payload[$meta_key] = $meta_value;
        $this->save_payload($object_id, $payload);
        return true;
    }

    /**
     * 8. Intercept DELETE Post Meta
     */
    public function intercept_delete($check, $object_id, $meta_key, $meta_value, $delete_all) {
        if (!$this->is_compact_key($meta_key)) {
            return $check;
        }

        $payload = $this->get_payload($object_id);

        if (!array_key_exists($meta_key, $payload)) {
            return false; // Tidak ada yang dihapus
        }

        // Jika meta_value ditentukan, cek kecocokan dulu
        if ($meta_value !== '') {
            if ($payload[$meta_key] != $meta_value) {
                return false; // Abort delete
            }
        }

        unset($payload[$meta_key]);
        $this->save_payload($object_id, $payload);
        return true;
    }

    /**
     * 9. Admin Menu & Settings
     */
    public function add_admin_menu() {
        add_options_page(
            'Compact Postmeta Settings',
            'Compact Meta',
            'manage_options',
            'compact-postmeta',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('cpm_settings_group', $this->option_name);
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) return;
        
        // Handle notifikasi
        if (isset($_GET['cpm_migrated'])) {
            echo '<div class="notice notice-success"><p>Data berhasil dimigrasi ke tabel compact!</p></div>';
        }
        ?>
        <div class="wrap">
            <h1>Pengaturan Compact Postmeta</h1>
            <form method="post" action="options.php">
                <?php settings_fields('cpm_settings_group'); ?>
                <?php do_settings_sections('cpm_settings_group'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Daftar Meta Keys (Pisahkan dengan koma)</th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>" value="<?php echo esc_attr(get_option($this->option_name)); ?>" class="regular-text" />
                            <p class="description">Contoh: <code>_thumbnail_id, _wp_old_slug, _wp_old_date, my_custom_cache</code></p>
                            <p class="description" style="color: red;"><strong>Peringatan:</strong> Meta key yang dimasukkan di sini TIDAK akan bisa digunakan dalam <code>WP_Query</code> (<code>meta_query</code>). Gunakan hanya untuk data yang diakses langsung per-post.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Simpan Pengaturan'); ?>
            </form>

            <hr>
            <h2>Migrasi Data</h2>
            <p>Gunakan tombol ini untuk memindahkan data yang sudah ada dari <code>wp_postmeta</code> ke tabel compact berdasarkan daftar key di atas.</p>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <input type="hidden" name="action" value="cpm_migrate_data">
                <?php wp_nonce_field('cpm_migrate_nonce', 'cpm_nonce'); ?>
                <button type="submit" class="button button-primary" onclick="return confirm('Yakin ingin memigrasi data? Proses ini akan menghapus data lama dari wp_postmeta setelah berhasil disalin.');">Migrasi Data Sekarang</button>
            </form>
        </div>
        <?php
    }

    /**
     * 10. Handle Migrasi Data dari wp_postmeta ke Tabel Compact
     */
    public function handle_migration() {
        if (!current_user_can('manage_options') || !wp_verify_nonce($_POST['cpm_nonce'], 'cpm_migrate_nonce')) {
            wp_die('Aksi tidak diizinkan.');
        }

        global $wpdb;
        $keys = get_option($this->option_name, '');
        $allowed_keys = array_map('trim', explode(',', $keys));
        
        if (empty($allowed_keys) || $allowed_keys[0] === '') {
            wp_redirect(add_query_arg('cpm_error', 'no_keys', wp_get_referer()));
            exit;
        }

        $placeholders = implode(',', array_fill(0, count($allowed_keys), '%s'));
        
        // Ambil semua data dari wp_postmeta yang sesuai dengan key
        $query = $wpdb->prepare(
            "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ($placeholders)",
            $allowed_keys
        );
        $results = $wpdb->get_results($query, ARRAY_A);

        $grouped_data = array();
        foreach ($results as $row) {
            $pid = $row['post_id'];
            $mkey = $row['meta_key'];
            $mval = $row['meta_value'];

            if (!isset($grouped_data[$pid])) {
                $grouped_data[$pid] = $this->get_payload($pid); // Ambil data existing jika ada
            }

            // Handle multiple values untuk key yang sama
            if (isset($grouped_data[$pid][$mkey])) {
                if (!is_array($grouped_data[$pid][$mkey])) {
                    $grouped_data[$pid][$mkey] = array($grouped_data[$pid][$mkey], maybe_unserialize($mval));
                } else {
                    $grouped_data[$pid][$mkey][] = maybe_unserialize($mval);
                }
            } else {
                $grouped_data[$pid][$mkey] = maybe_unserialize($mval);
            }
        }

        // Simpan ke tabel compact
        foreach ($grouped_data as $pid => $payload) {
            $this->save_payload($pid, $payload);
        }

        // Hapus dari wp_postmeta asli agar benar-benar hemat space
        $delete_query = $wpdb->prepare(
            "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ($placeholders)",
            $allowed_keys
        );
        $wpdb->query($delete_query);

        wp_redirect(add_query_arg('cpm_migrated', '1', wp_get_referer()));
        exit;
    }
}

// Inisialisasi Plugin
new Compact_Postmeta_Manager();