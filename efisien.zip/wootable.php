<?php
/**
 * Plugin Name: WC Product Flat Meta (Exact Keys)
 * Description: Mirror semua metadata produk WooCommerce ke tabel flat dengan nama kolom SAMA PERSIS seperti postmeta (_sku, _price, dll). Optimized query & tetap 100% kompatibel.
 * Version: 2.0.0
 * Author: Your Name
 * WC requires at least: 6.0.0
 * Requires PHP: 7.4
 * License: GPL2+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

final class WC_Product_Flat_Exact_Keys {
    private static $instance = null;
    private $table_name;
    
    // Daftar key meta standar WooCommerce yang akan jadi kolom dedicated
    private $standard_keys = [
        '_sku', '_price', '_regular_price', '_sale_price', '_date_on_sale_from', '_date_on_sale_to',
        '_manage_stock', '_stock', '_stock_status', '_backorders', '_sold_individually', '_total_sales',
        '_weight', '_length', '_width', '_height', '_shipping_class_id',
        '_virtual', '_downloadable', '_download_limit', '_download_expiry',
        '_tax_status', '_tax_class', '_average_rating', '_rating_count',
        '_menu_order', '_parent_id', '_visibility', '_featured', '_download_count', '_wc_review_count'
    ];

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'wc_product_flat_exact';

        add_action( 'plugins_loaded', [ $this, 'init' ] );
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        add_action( 'admin_notices', [ $this, 'admin_notice' ] );
        add_action( 'wp_ajax_wc_flat_exact_bulk_sync', [ $this, 'bulk_sync' ] );
    }

    public function init() {
        if ( ! class_exists( 'WooCommerce' ) ) return;

        add_action( 'woocommerce_update_product', [ $this, 'sync_product' ], 10, 1 );
        add_action( 'woocommerce_new_product',   [ $this, 'sync_product' ], 10, 1 );
        add_action( 'save_post_product',         [ $this, 'sync_via_post' ], 20, 2 );
        add_action( 'before_delete_post',        [ $this, 'delete_product' ] );
        add_action( 'wp_trash_post',             [ $this, 'delete_product' ] );
    }

    /**
     * Buat tabel dengan nama kolom SAMA PERSIS seperti postmeta
     */
    public function activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $cols = "`product_id` BIGINT(20) UNSIGNED NOT NULL PRIMARY KEY";
        $idx  = [];

        foreach ( $this->standard_keys as $key ) {
            $type = 'VARCHAR(255) NULL';
            
            if ( in_array( $key, ['_price', '_regular_price', '_sale_price', '_stock', '_weight', '_length', '_width', '_height', '_average_rating'] ) ) {
                $type = 'DECIMAL(10,2) NULL';
                $idx[] = "INDEX idx_{$key} (`{$key}`)";
            } elseif ( in_array( $key, ['_manage_stock', '_virtual', '_downloadable', '_sold_individually', '_featured'] ) ) {
                $type = "ENUM('yes','no') NULL";
            } elseif ( $key === '_stock_status' ) {
                $type = "ENUM('instock','outofstock','onbackorder') NULL";
                $idx[] = "INDEX idx_stock_status (`_stock_status`)";
            } elseif ( $key === '_backorders' ) {
                $type = "ENUM('no','notify','yes') NULL";
            } elseif ( in_array( $key, ['_menu_order', '_parent_id', '_shipping_class_id', '_total_sales', '_download_limit', '_download_expiry', '_rating_count'] ) ) {
                $type = 'BIGINT(20) NULL DEFAULT 0';
            } elseif ( in_array( $key, ['_date_on_sale_from', '_date_on_sale_to'] ) ) {
                $type = 'DATETIME NULL';
            } elseif ( $key === '_sku' ) {
                $idx[] = "INDEX idx_sku (`_sku`)";
            } elseif ( $key === '_status' ) {
                $idx[] = "INDEX idx_status (`_status`)";
            }

            $cols .= ", `{$key}` {$type}";
        }

        // Tambah kolom status post & custom meta
        $cols .= ", `post_status` VARCHAR(20) DEFAULT 'draft'";
        $cols .= ", `custom_meta` JSON NULL";
        $cols .= ", `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";
        
        $idx_sql = ! empty( $idx ) ? ', ' . implode( ', ', $idx ) : '';

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            {$cols}
        ) {$charset} ENGINE=InnoDB {$idx_sql};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'wc_flat_exact_version', '2.0.0' );
    }

    /**
     * Sinkronisasi produk ke tabel flat
     */
    public function sync_product( $product_id ) {
        $product = wc_get_product( $product_id );
        if ( ! $product || $product->is_type( 'variation' ) ) return;

        global $wpdb;
        $all_meta = get_post_meta( $product_id, '', false );
        $data     = [ 'product_id' => $product_id, 'post_status' => $product->get_status() ];

        // 1. Map standard keys
        foreach ( $this->standard_keys as $key ) {
            if ( isset( $all_meta[ $key ][0] ) ) {
                $val = $all_meta[ $key ][0];
                $data[ $key ] = $this->format_value( $key, $val );
            } else {
                $data[ $key ] = null;
            }
        }

        // 2. Tangkap meta custom lain ke JSON
        $custom = [];
        foreach ( $all_meta as $k => $v ) {
            if ( ! in_array( $k, $this->standard_keys, true ) && strpos( $k, '_' ) === 0 ) {
                $custom[ $k ] = count( $v ) === 1 ? $v[0] : $v;
            }
        }
        $data['custom_meta'] = empty( $custom ) ? null : wp_json_encode( $custom, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        // 3. Insert / Update
        $cols       = array_keys( $data );
        $vals       = array_values( $data );
        $formats    = array_fill( 0, count( $vals ), '%s' ); // %s aman untuk semua tipe di MySQL modern
        $columns    = '`' . implode( '`,`', $cols ) . '`';
        $placehold  = implode( ',', $formats );
        $updates    = '`' . implode( '`=VALUES(`', $cols ) . '`';

        $sql = "INSERT INTO {$this->table_name} ({$columns}) VALUES ({$placehold}) 
                ON DUPLICATE KEY UPDATE {$updates}";

        $wpdb->query( $wpdb->prepare( $sql, ...$vals ) );
        $this->clear_cache( $product_id );
    }

    public function sync_via_post( $post_id, $post ) {
        if ( $post->post_type !== 'product' ) return;
        $this->sync_product( $post_id );
    }

    public function delete_product( $post_id ) {
        if ( get_post_type( $post_id ) !== 'product' ) return;
        global $wpdb;
        $wpdb->delete( $this->table_name, [ 'product_id' => $post_id ], [ '%d' ] );
        $this->clear_cache( $post_id );
    }

    /**
     * Format value sesuai tipe kolom
     */
    private function format_value( $key, $val ) {
        if ( $val === '' || $val === null ) return null;
        
        $decimal_keys = ['_price', '_regular_price', '_sale_price', '_stock', '_weight', '_length', '_width', '_height', '_average_rating'];
        if ( in_array( $key, $decimal_keys, true ) ) {
            return wc_format_decimal( $val, 2 );
        }
        
        $int_keys = ['_menu_order', '_parent_id', '_shipping_class_id', '_total_sales', '_download_limit', '_download_expiry', '_rating_count'];
        if ( in_array( $key, $int_keys, true ) ) {
            return (int) $val;
        }

        return $val;
    }

    /**
     * Clear cache WC & Object Cache
     */
    private function clear_cache( $product_id ) {
        wc_delete_product_transients( $product_id );
        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $product_id, 'wc_flat_exact' );
            wp_cache_delete( $product_id, 'products' );
        }
    }

    /**
     * Helper: Ambil data flat (auto cache)
     */
    public static function get( $product_id ) {
        global $wpdb;
        $cached = wp_cache_get( $product_id, 'wc_flat_exact' );
        if ( false !== $cached ) return $cached;

        $row = $wpdb->get_row( $wpdb->prepare( 
            "SELECT * FROM {$wpdb->prefix}wc_product_flat_exact WHERE product_id = %d", $product_id 
        ), ARRAY_A );

        if ( $row ) {
            if ( ! empty( $row['custom_meta'] ) && is_string( $row['custom_meta'] ) ) {
                $row['custom_meta'] = json_decode( $row['custom_meta'], true );
            }
            wp_cache_set( $product_id, $row, 'wc_flat_exact', 3600 );
        }
        return $row ?: [];
    }

    /**
     * Admin Notice & Bulk Sync
     */
    public function admin_notice() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) return;
        if ( isset( $_GET['wc_flat_exact_done'] ) ) {
            echo '<div class="notice notice-success"><p>? Sinkronisasi batch selesai.</p></div>';
        }
        echo '<div class="notice notice-info"><p>
            <strong>WC Flat Exact Keys:</strong> 
            <a href="' . wp_nonce_url( admin_url( 'admin-ajax.php?action=wc_flat_exact_bulk_sync&batch=1' ), 'wc_flat_exact' ) . '" 
               class="button button-secondary">Sync All Products</a> 
            <span style="margin-left:10px;color:#666;font-size:12px;">Proses 100 produk/klik agar tidak timeout.</span>
        </p></div>';
    }

    public function bulk_sync() {
        check_ajax_referer( 'wc_flat_exact', false, true );
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'Unauthorized' );

        $batch  = isset( $_GET['batch'] ) ? (int) $_GET['batch'] : 1;
        $offset = ( $batch - 1 ) * 100;

        $products = wc_get_products( [
            'limit'  => 100, 'offset' => $offset, 'status' => 'any', 'return' => 'ids'
        ] );

        if ( empty( $products ) ) {
            wp_safe_redirect( add_query_arg( 'wc_flat_exact_done', '1' ) );
            exit;
        }

        foreach ( $products as $pid ) $this->sync_product( $pid );

        $next = $batch + 1;
        wp_safe_redirect( wp_nonce_url( admin_url( 'admin-ajax.php?action=wc_flat_exact_bulk_sync&batch=' . $next ), 'wc_flat_exact' ) );
        exit;
    }
}

// Inisialisasi
WC_Product_Flat_Exact_Keys::instance();