<?php
/**
 * Plugin Name: madxartwork Flat Meta Sync
 * Description: Mirror metadata madxartwork ke tabel MySQL flat dengan nama kolom SAMA PERSIS seperti postmeta. Optimized storage & query, tetap kompatibel 100%.
 * Version: 1.0.0
 * Requires Plugins: madxartwork
 * Requires PHP: 7.4
 * License: GPL2+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

final class madxartwork_Flat_Meta_Sync {
    private static $instance = null;
    private $table_name;
    
    // Key postmeta standar madxartwork yang akan jadi kolom dedicated
    private $madxartwork_keys = [
        '_madxartwork_edit_mode',
        '_madxartwork_data',
        '_madxartwork_page_settings',
        '_madxartwork_template_type',
        '_madxartwork_version',
        '_madxartwork_css',
        '_madxartwork_conditions',
        '_madxartwork_popup_settings',
        '_madxartwork_maintenance_mode'
    ];

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'madxartwork_flat_meta';

        register_activation_hook( __FILE__, [ $this, 'create_table' ] );
        add_action( 'plugins_loaded', [ $this, 'init' ], 20 );
        add_action( 'admin_notices', [ $this, 'admin_notice' ] );
        add_action( 'wp_ajax_madxartwork_flat_bulk_sync', [ $this, 'bulk_sync' ] );
    }

    public function init() {
        if ( ! defined( 'madxartwork_VERSION' ) ) return;

        // Real-time sync saat editor menyimpan
        add_action( 'madxartwork/document/save', [ $this, 'sync_document' ], 10, 2 );
        
        // Fallback sync saat post di-save/update
        add_action( 'save_post', [ $this, 'sync_post' ], 100, 2 );
        
        // Hapus saat post dihapus/trash
        add_action( 'before_delete_post', [ $this, 'delete_document' ] );
        add_action( 'wp_trash_post', [ $this, 'delete_document' ] );
    }

    /**
     * Buat tabel dengan nama kolom SAMA PERSIS seperti postmeta madxartwork
     */
    public function create_table() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $cols = "`post_id` BIGINT(20) UNSIGNED NOT NULL PRIMARY KEY";
        
        foreach ( $this->madxartwork_keys as $key ) {
            $type = 'TEXT NULL';
            
            if ( $key === '_madxartwork_edit_mode' ) {
                $type = "ENUM('builder','maintenance','') NULL";
            } elseif ( $key === '_madxartwork_template_type' ) {
                $type = "VARCHAR(50) NULL";
            } elseif ( $key === '_madxartwork_version' ) {
                $type = "VARCHAR(20) NULL";
            } elseif ( in_array( $key, ['_madxartwork_data', '_madxartwork_css'] ) ) {
                // LONGTEXT aman untuk JSON besar madxartwork (>1MB)
                $type = 'LONGTEXT NULL';
            } elseif ( in_array( $key, ['_madxartwork_page_settings', '_madxartwork_conditions', '_madxartwork_popup_settings'] ) ) {
                $type = 'JSON NULL';
            }

            $cols .= ", `{$key}` {$type}";
        }

        // Kolom untuk meta custom lain & timestamp
        $cols .= ", `custom_meta` JSON NULL";
        $cols .= ", `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} ({$cols}) {$charset} ENGINE=InnoDB;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'madxartwork_flat_version', '1.0.0' );
    }

    /**
     * Sinkronisasi saat document madxartwork di-save
     */
    public function sync_document( $post_id, $document ) {
        $this->sync_to_flat( $post_id );
    }

    /**
     * Sinkronisasi fallback saat post di-save
     */
    public function sync_post( $post_id, $post ) {
        if ( ! $post || in_array( $post->post_type, ['revision', 'auto-draft'] ) ) return;
        $this->sync_to_flat( $post_id );
    }

    /**
     * Core logic: ambil semua meta, map ke kolom flat, simpan
     */
    private function sync_to_flat( $post_id ) {
        global $wpdb;
        
        // Cek apakah post ini memiliki data madxartwork
        $has_madxartwork = get_post_meta( $post_id, '_madxartwork_data', true ) !== '' 
                      || get_post_meta( $post_id, '_madxartwork_edit_mode', true ) !== '';
        if ( ! $has_madxartwork ) return;

        $all_meta = get_post_meta( $post_id, '', false );
        $data     = [ 'post_id' => $post_id ];
        $custom   = [];

        // 1. Map key standar ke kolom dedicated
        foreach ( $this->madxartwork_keys as $key ) {
            $data[ $key ] = isset( $all_meta[ $key ][0] ) ? $all_meta[ $key ][0] : null;
        }

        // 2. Tangkap meta custom lain (dimulai dengan _madxartwork_) ke JSON
        foreach ( $all_meta as $k => $v ) {
            if ( ! in_array( $k, $this->madxartwork_keys, true ) && strpos( $k, '_madxartwork_' ) === 0 ) {
                $custom[ $k ] = count( $v ) === 1 ? $v[0] : $v;
            }
        }
        $data['custom_meta'] = empty( $custom ) ? null : wp_json_encode( $custom, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        // 3. INSERT ... ON DUPLICATE KEY UPDATE (atomik & cepat)
        $cols      = array_keys( $data );
        $vals      = array_values( $data );
        $formats   = array_fill( 0, count( $vals ), '%s' );
        $columns   = '`' . implode( '`,`', $cols ) . '`';
        $placehold = implode( ',', $formats );
        $updates   = '`' . implode( '`=VALUES(`', $cols ) . '`';

        $sql = "INSERT INTO {$this->table_name} ({$columns}) VALUES ({$placehold}) 
                ON DUPLICATE KEY UPDATE {$updates}";

        $wpdb->query( $wpdb->prepare( $sql, ...$vals ) );

        // 4. Bersihkan cache madxartwork & Object Cache
        $this->clear_madxartwork_cache( $post_id );
    }

    /**
     * Hapus baris saat post dihapus/trash
     */
    public function delete_document( $post_id ) {
        global $wpdb;
        $wpdb->delete( $this->table_name, [ 'post_id' => $post_id ], [ '%d' ] );
        $this->clear_madxartwork_cache( $post_id );
    }

    /**
     * Bersihkan cache
     */
    private function clear_madxartwork_cache( $post_id ) {
        if ( class_exists( '\madxartwork\Plugin' ) ) {
            \madxartwork\Plugin::$instance->files_manager->clear_cache( $post_id );
        }
        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'madxartwork_flat' );
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    /**
     * Helper: Ambil data flat (auto cache)
     */
    public static function get( $post_id ) {
        global $wpdb;
        $cached = wp_cache_get( $post_id, 'madxartwork_flat' );
        if ( false !== $cached ) return $cached;

        $row = $wpdb->get_row( $wpdb->prepare( 
            "SELECT * FROM {$wpdb->prefix}madxartwork_flat_meta WHERE post_id = %d", $post_id 
        ), ARRAY_A );

        if ( $row ) {
            // Decode JSON columns jika perlu
            foreach ( ['_madxartwork_page_settings', '_madxartwork_conditions', '_madxartwork_popup_settings', 'custom_meta'] as $json_col ) {
                if ( ! empty( $row[ $json_col ] ) && is_string( $row[ $json_col ] ) ) {
                    $row[ $json_col ] = json_decode( $row[ $json_col ], true );
                }
            }
            wp_cache_set( $post_id, $row, 'madxartwork_flat', 86400 ); // 24 jam
        }
        return $row ?: [];
    }

    /**
     * Admin Notice & Bulk Sync UI
     */
    public function admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_GET['madxartwork_flat_done'] ) ) {
            echo '<div class="notice notice-success"><p>? Sinkronisasi metadata madxartwork selesai.</p></div>';
        }
        echo '<div class="notice notice-info"><p>
            <strong>madxartwork Flat Meta Sync:</strong> 
            <a href="' . wp_nonce_url( admin_url( 'admin-ajax.php?action=madxartwork_flat_bulk_sync&batch=1' ), 'madxartwork_flat' ) . '" 
               class="button button-secondary">Sync All madxartwork Data</a> 
            <span style="margin-left:10px;color:#666;font-size:12px;">Proses 50 post/klik agar tidak timeout.</span>
        </p></div>';
    }

    public function bulk_sync() {
        check_ajax_referer( 'madxartwork_flat', false, true );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        $batch  = isset( $_GET['batch'] ) ? (int) $_GET['batch'] : 1;
        $offset = ( $batch - 1 ) * 50;

        // Ambil semua post yang kemungkinan pakai madxartwork
        $posts = get_posts( [
            'post_type'      => ['page', 'post', 'madxartwork_library'],
            'post_status'    => 'any',
            'numberposts'    => 50,
            'offset'         => $offset,
            'fields'         => 'ids',
            'meta_query'     => [
                'relation' => 'OR',
                [ 'key' => '_madxartwork_data', 'compare' => 'EXISTS' ],
                [ 'key' => '_madxartwork_edit_mode', 'compare' => 'EXISTS' ]
            ]
        ] );

        if ( empty( $posts ) ) {
            wp_safe_redirect( add_query_arg( 'madxartwork_flat_done', '1' ) );
            exit;
        }

        foreach ( $posts as $pid ) $this->sync_to_flat( $pid );

        $next = $batch + 1;
        wp_safe_redirect( wp_nonce_url( admin_url( 'admin-ajax.php?action=madxartwork_flat_bulk_sync&batch=' . $next ), 'madxartwork_flat' ) );
        exit;
    }
}

// Inisialisasi
madxartwork_Flat_Meta_Sync::instance();