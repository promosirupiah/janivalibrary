<?php
/**
 * Plugin Name: Elementor Flat Meta Sync
 * Description: Mirror metadata Elementor ke tabel MySQL flat dengan nama kolom SAMA PERSIS seperti postmeta. Optimized storage & query, tetap kompatibel 100%.
 * Version: 1.0.0
 * Requires Plugins: elementor
 * Requires PHP: 7.4
 * License: GPL2+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

final class Elementor_Flat_Meta_Sync {
    private static $instance = null;
    private $table_name;
    
    // Key postmeta standar Elementor yang akan jadi kolom dedicated
    private $elementor_keys = [
        '_elementor_edit_mode',
        '_elementor_data',
        '_elementor_page_settings',
        '_elementor_template_type',
        '_elementor_version',
        '_elementor_css',
        '_elementor_conditions',
        '_elementor_popup_settings',
        '_elementor_maintenance_mode'
    ];

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'elementor_flat_meta';

        register_activation_hook( __FILE__, [ $this, 'create_table' ] );
        add_action( 'plugins_loaded', [ $this, 'init' ], 20 );
        add_action( 'admin_notices', [ $this, 'admin_notice' ] );
        add_action( 'wp_ajax_elementor_flat_bulk_sync', [ $this, 'bulk_sync' ] );
    }

    public function init() {
        if ( ! defined( 'ELEMENTOR_VERSION' ) ) return;

        // Real-time sync saat editor menyimpan
        add_action( 'elementor/document/save', [ $this, 'sync_document' ], 10, 2 );
        
        // Fallback sync saat post di-save/update
        add_action( 'save_post', [ $this, 'sync_post' ], 100, 2 );
        
        // Hapus saat post dihapus/trash
        add_action( 'before_delete_post', [ $this, 'delete_document' ] );
        add_action( 'wp_trash_post', [ $this, 'delete_document' ] );
    }

    /**
     * Buat tabel dengan nama kolom SAMA PERSIS seperti postmeta Elementor
     */
    public function create_table() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $cols = "`post_id` BIGINT(20) UNSIGNED NOT NULL PRIMARY KEY";
        
        foreach ( $this->elementor_keys as $key ) {
            $type = 'TEXT NULL';
            
            if ( $key === '_elementor_edit_mode' ) {
                $type = "ENUM('builder','maintenance','') NULL";
            } elseif ( $key === '_elementor_template_type' ) {
                $type = "VARCHAR(50) NULL";
            } elseif ( $key === '_elementor_version' ) {
                $type = "VARCHAR(20) NULL";
            } elseif ( in_array( $key, ['_elementor_data', '_elementor_css'] ) ) {
                // LONGTEXT aman untuk JSON besar Elementor (>1MB)
                $type = 'LONGTEXT NULL';
            } elseif ( in_array( $key, ['_elementor_page_settings', '_elementor_conditions', '_elementor_popup_settings'] ) ) {
                $type = 'JSON NULL';
            }

            $cols .= ", `{$key}` {$type}";
        }

        // Kolom untuk meta custom lain & timestamp
        $cols .= ", `custom_meta` JSON NULL";
        $cols .= ", `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP";

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} ({$cols}) {$charset} ENGINE=InnoDB;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( 'elementor_flat_version', '1.0.0' );
    }

    /**
     * Sinkronisasi saat document Elementor di-save
     */
    public function sync_document( $post_id, $document ) {
        $this->sync_to_flat( $post_id );
    }

    /**
     * Sinkronisasi fallback saat post di-save
     */
    public function sync_post( $post_id, $post ) {
        if ( ! $post || in_array( $post->post_type, ['revision', 'auto-draft'] ) ) return;
        $this->sync_to_flat( $post_id );
    }

    /**
     * Core logic: ambil semua meta, map ke kolom flat, simpan
     */
    private function sync_to_flat( $post_id ) {
        global $wpdb;
        
        // Cek apakah post ini memiliki data Elementor
        $has_elementor = get_post_meta( $post_id, '_elementor_data', true ) !== '' 
                      || get_post_meta( $post_id, '_elementor_edit_mode', true ) !== '';
        if ( ! $has_elementor ) return;

        $all_meta = get_post_meta( $post_id, '', false );
        $data     = [ 'post_id' => $post_id ];
        $custom   = [];

        // 1. Map key standar ke kolom dedicated
        foreach ( $this->elementor_keys as $key ) {
            $data[ $key ] = isset( $all_meta[ $key ][0] ) ? $all_meta[ $key ][0] : null;
        }

        // 2. Tangkap meta custom lain (dimulai dengan _elementor_) ke JSON
        foreach ( $all_meta as $k => $v ) {
            if ( ! in_array( $k, $this->elementor_keys, true ) && strpos( $k, '_elementor_' ) === 0 ) {
                $custom[ $k ] = count( $v ) === 1 ? $v[0] : $v;
            }
        }
        $data['custom_meta'] = empty( $custom ) ? null : wp_json_encode( $custom, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

        // 3. INSERT ... ON DUPLICATE KEY UPDATE (atomik & cepat)
        $cols      = array_keys( $data );
        $vals      = array_values( $data );
        $formats   = array_fill( 0, count( $vals ), '%s' );
        $columns   = '`' . implode( '`,`', $cols ) . '`';
        $placehold = implode( ',', $formats );
        $updates   = '`' . implode( '`=VALUES(`', $cols ) . '`';

        $sql = "INSERT INTO {$this->table_name} ({$columns}) VALUES ({$placehold}) 
                ON DUPLICATE KEY UPDATE {$updates}";

        $wpdb->query( $wpdb->prepare( $sql, ...$vals ) );

        // 4. Bersihkan cache Elementor & Object Cache
        $this->clear_elementor_cache( $post_id );
    }

    /**
     * Hapus baris saat post dihapus/trash
     */
    public function delete_document( $post_id ) {
        global $wpdb;
        $wpdb->delete( $this->table_name, [ 'post_id' => $post_id ], [ '%d' ] );
        $this->clear_elementor_cache( $post_id );
    }

    /**
     * Bersihkan cache
     */
    private function clear_elementor_cache( $post_id ) {
        if ( class_exists( '\Elementor\Plugin' ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache( $post_id );
        }
        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( $post_id, 'elementor_flat' );
            wp_cache_delete( $post_id, 'post_meta' );
        }
    }

    /**
     * Helper: Ambil data flat (auto cache)
     */
    public static function get( $post_id ) {
        global $wpdb;
        $cached = wp_cache_get( $post_id, 'elementor_flat' );
        if ( false !== $cached ) return $cached;

        $row = $wpdb->get_row( $wpdb->prepare( 
            "SELECT * FROM {$wpdb->prefix}elementor_flat_meta WHERE post_id = %d", $post_id 
        ), ARRAY_A );

        if ( $row ) {
            // Decode JSON columns jika perlu
            foreach ( ['_elementor_page_settings', '_elementor_conditions', '_elementor_popup_settings', 'custom_meta'] as $json_col ) {
                if ( ! empty( $row[ $json_col ] ) && is_string( $row[ $json_col ] ) ) {
                    $row[ $json_col ] = json_decode( $row[ $json_col ], true );
                }
            }
            wp_cache_set( $post_id, $row, 'elementor_flat', 86400 ); // 24 jam
        }
        return $row ?: [];
    }

    /**
     * Admin Notice & Bulk Sync UI
     */
    public function admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_GET['elementor_flat_done'] ) ) {
            echo '<div class="notice notice-success"><p>? Sinkronisasi metadata Elementor selesai.</p></div>';
        }
        echo '<div class="notice notice-info"><p>
            <strong>Elementor Flat Meta Sync:</strong> 
            <a href="' . wp_nonce_url( admin_url( 'admin-ajax.php?action=elementor_flat_bulk_sync&batch=1' ), 'elementor_flat' ) . '" 
               class="button button-secondary">Sync All Elementor Data</a> 
            <span style="margin-left:10px;color:#666;font-size:12px;">Proses 50 post/klik agar tidak timeout.</span>
        </p></div>';
    }

    public function bulk_sync() {
        check_ajax_referer( 'elementor_flat', false, true );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );

        $batch  = isset( $_GET['batch'] ) ? (int) $_GET['batch'] : 1;
        $offset = ( $batch - 1 ) * 50;

        // Ambil semua post yang kemungkinan pakai Elementor
        $posts = get_posts( [
            'post_type'      => ['page', 'post', 'elementor_library'],
            'post_status'    => 'any',
            'numberposts'    => 50,
            'offset'         => $offset,
            'fields'         => 'ids',
            'meta_query'     => [
                'relation' => 'OR',
                [ 'key' => '_elementor_data', 'compare' => 'EXISTS' ],
                [ 'key' => '_elementor_edit_mode', 'compare' => 'EXISTS' ]
            ]
        ] );

        if ( empty( $posts ) ) {
            wp_safe_redirect( add_query_arg( 'elementor_flat_done', '1' ) );
            exit;
        }

        foreach ( $posts as $pid ) $this->sync_to_flat( $pid );

        $next = $batch + 1;
        wp_safe_redirect( wp_nonce_url( admin_url( 'admin-ajax.php?action=elementor_flat_bulk_sync&batch=' . $next ), 'elementor_flat' ) );
        exit;
    }
}

// Inisialisasi
Elementor_Flat_Meta_Sync::instance();