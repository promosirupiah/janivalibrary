<?php
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Bulk_Postmeta_Edior
 * @subpackage Bulk_Postmeta_Edior/includes
 * @author     PSD to Final <info@psdtofinal.com>
 */
class Bulk_Postmeta_Edior_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
