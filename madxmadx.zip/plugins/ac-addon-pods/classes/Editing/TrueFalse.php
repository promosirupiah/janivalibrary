<?php

namespace ACA\Pods\Editing;

use ACA\Pods\Editing;

class TrueFalse extends Editing {

	public function get_view_settings() {
		return [
			'type'    => 'togglable',
			'options' => [
				'0' => __( 'False', 'codepress-admin-columns' ),
				'1' => __( 'True', 'codepress-admin-columns' ),
			],
		];
	}

}