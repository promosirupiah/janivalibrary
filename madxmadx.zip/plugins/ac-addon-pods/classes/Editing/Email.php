<?php

namespace ACA\Pods\Editing;

use ACA\Pods\Editing;

class Email extends Editing {

	public function get_view_settings() {
		$field = $this->column->get_field();
		$data = [
			'type' => 'email',
		];

		if ( $field->get_option( 'email_max_length' ) ) {
			$data['maxlength'] = $field->get_option( 'email_max_length' );
		}

		return $data;
	}

}