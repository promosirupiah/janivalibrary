<?php

namespace ACA\Pods\Editing;

use ACA\Pods\Editing;

class Website extends Editing {

	public function get_view_settings() {
		$field = $this->column->get_field();
		$data = parent::get_view_settings();
		$data['type'] = $field->get_option( 'website_html5' ) ? 'url' : 'text';

		if ( $field->get_option( 'website_max_length' ) ) {
			$data['maxlength'] = $field->get_option( 'website_max_length' );
		}

		return $data;
	}

}