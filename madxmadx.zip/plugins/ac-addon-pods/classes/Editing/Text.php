<?php

namespace ACA\Pods\Editing;

use ACA\Pods\Editing;

class Text extends Editing {

	public function get_view_settings() {
		$field = $this->column->get_field();
		$data = parent::get_view_settings();
		$data['type'] = 'text';

		if ( $field->get_option( 'text_max_length' ) ) {
			$data['maxlength'] = $field->get_option( 'text_max_length' );
		}

		return $data;
	}

}