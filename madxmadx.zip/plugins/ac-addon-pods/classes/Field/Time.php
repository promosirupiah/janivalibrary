<?php

namespace ACA\Pods\Field;

use ACA\Pods\Editing;
use ACA\Pods\Field;
use ACP;
use ACP\Search;

class Time extends Field {

	public function editing() {
		return new Editing( $this->column );
	}

	public function sorting() {
		return ( new ACP\Sorting\Model\MetaFactory() )->create( $this->get_meta_type(), $this->get_meta_key() );
	}

	public function search() {
		return new Search\Comparison\Meta\Text( $this->get_meta_key(), $this->column->get_meta_type() );
	}

}