<?php

namespace ACA\Pods\Field\Pick;

use AC\Collection;
use AC\Settings;
use AC\Settings\Column\Post;
use ACA\Pods\Editing;
use ACA\Pods\Field;
use ACA\Pods\Filtering;
use ACA\Pods\Search;
use ACP\Sorting\FormatValue\SerializedSettingFormatter;
use ACP\Sorting\FormatValue\SettingFormatter;
use ACP\Sorting\Model\MetaFormatFactory;
use ACP\Sorting\Model\MetaRelatedPostFactory;

class PostType extends Field\Pick {

	public function get_value( $id ) {
		return $this->column->get_formatted_value( new Collection( $this->get_raw_value( $id ) ) );
	}

	public function get_raw_value( $id ) {
		return $this->get_db_value( $id );
	}

	public function editing() {
		return new Editing\PickPosts( $this->column );
	}

	public function filtering() {
		return new Filtering\PickPosts( $this->column );
	}

	public function search() {
		return new Search\PickPost( $this->column()->get_meta_key(), $this->column()->get_meta_type(), $this->get( 'pick_val' ) );
	}

	public function sorting() {
		$setting = $this->column->get_setting( Post::NAME );

		if ( ! $this->is_multiple() ) {
			$model = ( new MetaRelatedPostFactory() )->create( $this->get_meta_type(), $setting->get_value(), $this->get_meta_key() );

			if ( $model ) {
				return $model;
			}
		}

		$formatter = $this->is_multiple()
			? new SerializedSettingFormatter( new SettingFormatter( $setting ) )
			: new SettingFormatter( $setting );

		return ( new MetaFormatFactory() )->create( $this->get_meta_type(), $this->get_meta_key(), $formatter );
	}

	public function get_dependent_settings() {
		return [
			new Settings\Column\Post( $this->column ),
		];
	}

}
