<?php

namespace ACA\Pods\Sorting;

use ACP;

/**
 * @deprecated
 */
class Disabled extends ACP\Sorting\Model\Disabled {

	public function __construct( $column ) {
		parent::__construct();
	}

}