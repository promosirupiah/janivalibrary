<?php

namespace ACA\Pods\Column;

use ACA\Pods\Column;

class User extends Column {

	protected function get_pod_name() {
		return 'user';
	}

}