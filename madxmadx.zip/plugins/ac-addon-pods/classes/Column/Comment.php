<?php

namespace ACA\Pods\Column;

use ACA\Pods\Column;

class Comment extends Column {

	protected function get_pod_name() {
		return 'comment';
	}

}