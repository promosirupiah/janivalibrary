<?php
/**
 * Template for site footer.
 * 
 * @package madxFlow
 * @since 1.0.0
 */
do_action( 'tf_template_render_footer', basename( __FILE__ ) );