<?php
/**
 * Template for site header.
 * 
 * @package madxFlow
 * @since 1.0.0
 */
do_action( 'tf_template_render_header', basename( __FILE__ ) );