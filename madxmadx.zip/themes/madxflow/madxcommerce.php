<?php
/**
 * Template for madxcommerce pages
 * 
 * @package madxFlow
 * @since 1.0.0
 */

add_action( 'tf_template_render_content', 'madxcommerce_content' );

do_action( 'tf_template_render', basename( __FILE__ ) );