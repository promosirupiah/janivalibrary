<?php
/**
 * Post Pagination Template.
 * 
 * @package madxFlow
 * @since 1.0.0
 */
tf_pagenav();