(function($){

	'use strict';

	TF.Collections.Controls = Backbone.Collection.extend({
		model: TF.Models.Control
	});
	
})(jQuery);