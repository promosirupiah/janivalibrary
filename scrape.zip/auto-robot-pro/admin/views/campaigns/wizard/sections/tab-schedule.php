<div id="schedule" class="robot-box-tab" data-nav="schedule" >

	<div class="robot-box-header">
		<h2 class="robot-box-title"><?php esc_html_e( 'Schedule', Auto_Robot::DOMAIN ); ?></h2>
	</div>


    <div class="robot-box-body">
		<?php $this->template( 'campaigns/wizard/components/schedule-settings', $settings ); ?>
	</div>


</div>


