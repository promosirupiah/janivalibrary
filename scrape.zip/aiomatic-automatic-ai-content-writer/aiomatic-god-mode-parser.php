<?php
defined('ABSPATH') or die();
add_filter('aiomatic_ai_reply_raw', 'aiomatic_handle_god_mode_response', 10, 2);
function aiomatic_handle_god_mode_response($reply, $query) 
{
    if (isset($reply->tool_calls) && !empty($reply->tool_calls)) 
    {
        if ( current_user_can( 'manage_options' ) ) 
        {
            require_once(__DIR__ . '/res/amazon-direct.php');
            foreach($reply->tool_calls as $tool_call)
            {
                if (isset($tool_call->type) && $tool_call->type == 'function')
                {
                    $result = false;
                    if (isset($tool_call->function->arguments) && is_string($tool_call->function->arguments)) 
                    {
                        $targs = json_decode($tool_call->function->arguments);
                        if($targs !== null)
                        {
                            $tool_call->function->arguments = $targs;
                        }
                        else
                        {
                            $strips = stripslashes($tool_call->function->arguments);
                            $targs = json_decode($strips);
                            if($targs !== null)
                            {
                                $tool_call->function->arguments = $targs;
                            }
                        }
                    }
                    if ($tool_call->function->name === 'aiomatic_wp_god_mode') 
                    {
                        if(isset($tool_call->function->arguments->called_function_name))
                        {
                            $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
                            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                            $function_name = $tool_call->function->arguments->called_function_name;
                            $params = $tool_call->function->arguments->parameter_array;
                            if (isset($aiomatic_Chatbot_Settings['god_whitelisted_functions']) && trim($aiomatic_Chatbot_Settings['god_whitelisted_functions']) != '')
                            {
                                $white = trim($aiomatic_Chatbot_Settings['god_whitelisted_functions']);
                                $white = preg_split('/\r\n|\r|\n/', trim($white));
                                $white = array_filter($white);
                                if(!in_array($function_name, $white))
                                {
                                    if(isset($reply->choices[0]->message))
                                    {
                                        $as_mes = $reply->choices[0]->message;
                                    }
                                    else
                                    {
                                        $as_mes = '';
                                    }
                                    if(isset($reply->choices[0]))
                                    {
                                        $reply->choices[0]->text = '';
                                        $reply->choices[0]->message->content = '';
                                    }
                                    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
                                    {
                                        aiomatic_log_to_file('Function call not allowed, not whitelisted: ' . $function_name);
                                    }
                                    $reply->aiomatic_tool_results[] = array(
                                        "tool_call_id" => $tool_call->id,
                                        "role" => "tool",
                                        "content" => 'You are not allowed to call this function (not on the whitelisted functions list)',
                                        'assistant_message' => $as_mes
                                    );
                                    continue;
                                }
                            }
                            if (isset($aiomatic_Chatbot_Settings['god_blacklisted_functions']) && trim($aiomatic_Chatbot_Settings['god_blacklisted_functions']) != '')
                            {
                                $black = trim($aiomatic_Chatbot_Settings['god_blacklisted_functions']);
                                $black = preg_split('/\r\n|\r|\n/', trim($black));
                                $black = array_filter($black);
                                if(in_array($function_name, $black))
                                {
                                    if(isset($reply->choices[0]->message))
                                    {
                                        $as_mes = $reply->choices[0]->message;
                                    }
                                    else
                                    {
                                        $as_mes = '';
                                    }
                                    if(isset($reply->choices[0]))
                                    {
                                        $reply->choices[0]->text = '';
                                        $reply->choices[0]->message->content = '';
                                    }
                                    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
                                    {
                                        aiomatic_log_to_file('Function call not allowed, blacklisted: ' . $function_name);
                                    }
                                    $reply->aiomatic_tool_results[] = array(
                                        "tool_call_id" => $tool_call->id,
                                        "role" => "tool",
                                        "content" => 'You are not allowed to call this function (on the blacklisted functions list)',
                                        'assistant_message' => $as_mes
                                    );
                                    continue;
                                }
                            }
                            if(function_exists($function_name))
                            {
                                if(!is_array($params))
                                {
                                    $jsony = json_decode($params, true);
                                    if($jsony !== null && is_array($jsony))
                                    {
                                        $params = $jsony;
                                    }
                                    else
                                    {
                                        if(empty($params))
                                        {
                                            $params = array();
                                        }
                                        else
                                        {
                                            $params = array($params);
                                        }
                                    }
                                }
                                if(isset($params['post_title']) && $function_name == 'wp_insert_post')
                                {
                                    $params = array($params);
                                }
                                $paramsAsString = aiomatic_format_function_params($params);
                                $reflection = new ReflectionFunction($function_name);
                                $requiredParamsCount = $reflection->getNumberOfRequiredParameters();
                                if(is_numeric($requiredParamsCount) && $requiredParamsCount > 0 && count($params) < $requiredParamsCount)
                                {
                                    $result = $function_name . ' function has ' . $requiredParamsCount .' required parameters, but only ' . count($params) . ' were passed to it.';
                                }
                                else
                                {
                                    if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
                                    {
                                        aiomatic_log_to_file('Calling function ' . $function_name . '(' . $paramsAsString . ')...');
                                    }
                                    $result = call_user_func_array($function_name, $params);
                                }
                                
                            }
                            else
                            {
                                $result = $function_name . ' function was not found on the system.';
                            }
                            if(isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on')
                            {
                                $paramsAsString = aiomatic_format_function_params($params);
                                if($result === false)
                                {
                                    aiomatic_log_to_file('Function ' . $function_name . '(' . $paramsAsString . ') - returned false');
                                    $result = $function_name . ' returned false';
                                }
                                elseif(empty($result))
                                {
                                    aiomatic_log_to_file('Function ' . $function_name . '(' . $paramsAsString . ') - returned an empty response: ' . print_r($result, true));
                                    $result = $function_name . ' returned an empty response';
                                }
                                else
                                {
                                    aiomatic_log_to_file('Function ' . $function_name . '(' . $paramsAsString . ') - result: ' . print_r($result, true));
                                }
                            }
                            if(isset($reply->choices[0]))
                            {
                                $reply->choices[0]->text = '';
                                $reply->choices[0]->message->content = '';
                            }
                            if(is_object($result) || is_array($result))
                            {
                                $result = json_encode($result);
                            }
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            if(isset($reply->aiomatic_tool_results) && is_array($reply->aiomatic_tool_results))
                            {
                                $reply->aiomatic_tool_results[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $result,
                                    'assistant_message' => $as_mes
                                );
                            }
                            else
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $result,
                                    'assistant_message' => $as_mes
                                ));
                            }
                        }
                        else
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $reply->aiomatic_tool_results = array(array(
                                "tool_call_id" => $tool_call->id,
                                "role" => "tool",
                                "content" => 'called_function_name parameter not found',
                                'assistant_message' => $as_me
                            ));
                            aiomatic_log_to_file('Failed to decode function calling: ' . print_r($tool_call, true));
                        }
                    }
                    elseif ($tool_call->function->name === 'aiomatic_image') 
                    {
                        if(isset($tool_call->function->arguments->prompt))
                        {
                            $result = '';
                            $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
                            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                            $prompt = $tool_call->function->arguments->prompt;
                            if (!isset($aiomatic_Main_Settings['app_id'])) 
                            {
                                $aiomatic_Main_Settings['app_id'] = '';
                            }
                            $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                            $appids = array_filter($appids);
                            $token = $appids[array_rand($appids)];
                            if (empty($token))
                            {
                                aiomatic_log_to_file('You need to enter an OpenAI API key for this to work!');
                                if (isset($aiomatic_Chatbot_Settings['god_mode_dalle_failed']) && trim($aiomatic_Chatbot_Settings['god_mode_dalle_failed']) != '')
                                {
                                    $result = trim($aiomatic_Chatbot_Settings['god_mode_dalle_failed']);
                                }
                                else
                                {
                                    $result = 'Image creation failed, please try again later.';
                                }
                                continue;
                            }
                            if (isset($aiomatic_Chatbot_Settings['ai_image_size']) && trim($aiomatic_Chatbot_Settings['ai_image_size']) != '')
                            {
                                $image_size = trim($aiomatic_Chatbot_Settings['ai_image_size']);
                            }
                            else
                            {
                                $image_size = '512x512';
                            }
                            if (isset($aiomatic_Chatbot_Settings['ai_image_model']) && trim($aiomatic_Chatbot_Settings['ai_image_model']) != '')
                            {
                                $model = trim($aiomatic_Chatbot_Settings['ai_image_model']);
                            }
                            else
                            {
                                $model = 'dalle2';
                            }
                            if(empty($result))
                            {
                                $aierror = '';
                                $airesult = aiomatic_generate_ai_image($token, 1, $prompt, $image_size, 'chatFunctionDalleImage', false, 0, $aierror, $model);
                                if($airesult !== false && is_array($airesult))
                                {
                                    foreach($airesult as $tmpimg)
                                    {
                                        $result = '<img src="' . $tmpimg . '">';
                                        break;
                                    }
                                }
                                else
                                {
                                    aiomatic_log_to_file('Failed to generate Dall-E image in AI chatbot: ' . $aierror);
                                    if (isset($aiomatic_Chatbot_Settings['god_mode_dalle_failed']) && trim($aiomatic_Chatbot_Settings['god_mode_dalle_failed']) != '')
                                    {
                                        $result = trim($aiomatic_Chatbot_Settings['god_mode_dalle_failed']);
                                    }
                                    else
                                    {
                                        $result = 'Image creation failed, please try again later.';
                                    }
                                    continue;
                                }
                            }
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            if(isset($reply->aiomatic_tool_direct_message) && is_array($reply->aiomatic_tool_direct_message))
                            {
                                $reply->aiomatic_tool_direct_message[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $result,
                                    'assistant_message' => $as_mes
                                );
                            }
                            else
                            {
                                $reply->aiomatic_tool_direct_message = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $result,
                                    'assistant_message' => $as_mes
                                ));
                            }
                        }
                        else
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $reply->aiomatic_tool_results = array(array(
                                "tool_call_id" => $tool_call->id,
                                "role" => "tool",
                                "content" => 'prompt parameter not found',
                                'assistant_message' => $as_me
                            ));
                            aiomatic_log_to_file('Failed to decode function calling: ' . print_r($tool_call, true));
                        }
                    }
                    elseif ($tool_call->function->name === 'aiomatic_stable_image') 
                    {
                        if(isset($tool_call->function->arguments->prompt))
                        {
                            $result = '';
                            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                            $prompt = $tool_call->function->arguments->prompt;
                            if (isset($aiomatic_Chatbot_Settings['ai_image_size_stable']) && trim($aiomatic_Chatbot_Settings['ai_image_size_stable']) != '')
                            {
                                $image_size = trim($aiomatic_Chatbot_Settings['ai_image_size_stable']);
                            }
                            else
                            {
                                $image_size = '512x512';
                            }
                            if($image_size == '512x512')
                            {
                                $width = '512';
                                $height = '512';
                            }
                            elseif($image_size == '1024x1024')
                            {
                                $width = '1024';
                                $height = '1024';
                            }
                            else
                            {
                                $width = '512';
                                $height = '512';
                            }
                            if (isset($aiomatic_Chatbot_Settings['stable_model']) && trim($aiomatic_Chatbot_Settings['stable_model']) != '')
                            {
                                $model = trim($aiomatic_Chatbot_Settings['stable_model']);
                            }
                            else
                            {
                                $model = 'stable-diffusion-512-v2-1';
                            }
                            $aierror = '';
                            $airesult = aiomatic_generate_stability_image($prompt, $height, $width, 'chatFunctionStableImage', 0, false, $aierror, false, $model);
                            if($airesult !== false && isset($airesult[1]))
                            {
                                $result = '<img src="' . $airesult[1] . '">';
                            }
                            else
                            {
                                aiomatic_log_to_file('Failed to generate Dall-E image in AI chatbot: ' . $aierror);
                                if (isset($aiomatic_Chatbot_Settings['god_mode_dalle_failed']) && trim($aiomatic_Chatbot_Settings['god_mode_dalle_failed']) != '')
                                {
                                    $result = trim($aiomatic_Chatbot_Settings['god_mode_dalle_failed']);
                                }
                                else
                                {
                                    $result = 'Image creation failed, please try again later.';
                                }
                                continue;
                            }
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            if(isset($reply->aiomatic_tool_direct_message) && is_array($reply->aiomatic_tool_direct_message))
                            {
                                $reply->aiomatic_tool_direct_message[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $result,
                                    'assistant_message' => $as_mes
                                );
                            }
                            else
                            {
                                $reply->aiomatic_tool_direct_message = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $result,
                                    'assistant_message' => $as_mes
                                ));
                            }
                        }
                        else
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $reply->aiomatic_tool_results = array(array(
                                "tool_call_id" => $tool_call->id,
                                "role" => "tool",
                                "content" => 'prompt parameter not found',
                                'assistant_message' => $as_mes
                            ));
                            aiomatic_log_to_file('Failed to decode function calling: ' . print_r($tool_call, true));
                        }
                    }
                    elseif ($tool_call->function->name === 'aiomatic_amazon_listing') 
                    {
                        if(isset($tool_call->function->arguments->query))
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $result = '';
                            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                            $asin = $tool_call->function->arguments->query;
                            if (empty($asin)) 
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'Empty search query provided',
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            if (isset($aiomatic_Chatbot_Settings['affiliate_id']) && trim($aiomatic_Chatbot_Settings['affiliate_id']) != '')
                            {
                                $aff_id = trim($aiomatic_Chatbot_Settings['affiliate_id']);
                            }
                            else
                            {
                                $aff_id = '';
                            }
                            if (isset($aiomatic_Chatbot_Settings['target_country']) && trim($aiomatic_Chatbot_Settings['target_country']) != '')
                            {
                                $target_country = trim($aiomatic_Chatbot_Settings['target_country']);
                            }
                            else
                            {
                                $target_country = 'com';
                            }
                            if (isset($aiomatic_Chatbot_Settings['max_products']) && trim($aiomatic_Chatbot_Settings['max_products']) != '')
                            {
                                $max_product_count = trim($aiomatic_Chatbot_Settings['max_products']);
                            }
                            else
                            {
                                $max_product_count = '3-4';
                            }
                            if (isset($aiomatic_Chatbot_Settings['sort_results']) && trim($aiomatic_Chatbot_Settings['sort_results']) != '')
                            {
                                $amaz_sort_results = trim($aiomatic_Chatbot_Settings['sort_results']);
                            }
                            else
                            {
                                $amaz_sort_results = 'none';
                            }
                            if (isset($aiomatic_Chatbot_Settings['listing_template']) && trim($aiomatic_Chatbot_Settings['listing_template']) != '')
                            {
                                $listing_template = trim($aiomatic_Chatbot_Settings['listing_template']);
                            }
                            else
                            {
                                $listing_template = '%%product_counter%%. %%product_title%% - Desciption: %%product_description%% - Link: %%product_url%% - Price: %%product_price%%';
                            }
                            
                            if(strstr($max_product_count, '-') !== false)
                            {
                                $pr_arr = explode('-', $max_product_count);
                                $minx = trim($pr_arr[0]);
                                $maxx = trim($pr_arr[1]);
                                if(is_numeric($minx) && is_numeric($maxx))
                                {
                                    $max_product_count = rand(intval($minx), intval($maxx));
                                }
                                else
                                {
                                    if(is_numeric($minx))
                                    {
                                        $max_product_count = intval($minx);
                                    }
                                    elseif(is_numeric($maxx))
                                    {
                                        $max_product_count = intval($maxx);
                                    }
                                    else
                                    {
                                        $max_product_count = 100;
                                    }
                                }
                            }
                            if(!empty($max_product_count) && is_numeric($max_product_count))
                            {
                                $max_prod = intval($max_product_count);
                            }
                            else
                            {
                                $max_prod = 100;
                            }
                            $amazresult = aiomatic_amazon_get_post($asin, trim($aff_id), $target_country, '', '', $amaz_sort_results, $max_prod, '1', array());
                            if(is_array($amazresult) && ((isset($amazresult['status']) && $amazresult['status'] == 'nothing') || count($amazresult) == 0))
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'No Amazon products found for query: ' . $asin,
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            if(!is_array($amazresult))
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'An error occurred while search Amazon for: ' . $asin,
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            
                            $final_result = '';
                            $counter = 1;
                            foreach($amazresult as $myprod)
                            {
                                $copy_template = $listing_template;
                                $copy_template = str_replace('%%product_counter%%', $counter, $copy_template);
                                $copy_template = str_replace('%%product_title%%', trim(preg_replace('/\s+/', ' ', $myprod->offer_title)), $copy_template);
                                $copy_template = str_replace('%%product_description%%', trim(preg_replace('/\s+/', ' ', $myprod->offer_desc)), $copy_template);
                                $copy_template = str_replace('%%product_url%%', trim(preg_replace('/\s+/', ' ', $myprod->offer_url)), $copy_template);
                                $copy_template = str_replace('%%product_price%%', trim(preg_replace('/\s+/', ' ', $myprod->offer_price)), $copy_template);
                                $copy_template = str_replace('%%product_list_price%%', trim(preg_replace('/\s+/', ' ', $myprod->product_list_price)), $copy_template);
                                $copy_template = str_replace('%%product_image%%', trim(preg_replace('/\s+/', ' ', $myprod->offer_img)), $copy_template);
                                $copy_template = str_replace('%%product_cart_url%%', trim(preg_replace('/\s+/', ' ', $myprod->cart_url)), $copy_template);
                                $copy_template = str_replace('%%product_images_urls%%', trim(preg_replace('/\s+/', ' ', $myprod->product_imgs)), $copy_template);
                                $copy_template = str_replace('%%product_images%%', trim(preg_replace('/\s+/', ' ', $myprod->product_imgs_html)), $copy_template);
                                $copy_template = str_replace('%%product_reviews%%', trim(preg_replace('/\s+/', ' ', implode(PHP_EOL, $myprod->item_reviews))), $copy_template);
                                $counter++;
                                $final_result .= $copy_template . '\r\n'; 
                            }
                            $final_result = trim($final_result);
                            if(!empty($final_result))
                            {
                                $reply->aiomatic_tool_results[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $final_result,
                                    'assistant_message' => $as_mes
                                );
                            }
                            else
                            {
                                $reply->aiomatic_tool_results[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'Amazon did not return info for this query: ' . $asin,
                                    'assistant_message' => $as_mes
                                );
                            }
                        }
                        else
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $reply->aiomatic_tool_results = array(array(
                                "tool_call_id" => $tool_call->id,
                                "role" => "tool",
                                "content" => 'query parameter not found',
                                'assistant_message' => $as_mes
                            ));
                            aiomatic_log_to_file('Failed to decode function calling: ' . print_r($tool_call, true));
                        }
                    }
                    elseif ($tool_call->function->name === 'aiomatic_amazon_product_details') 
                    {
                        if(isset($tool_call->function->arguments->query))
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $result = '';
                            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                            $asin = $tool_call->function->arguments->query;
                            if (empty($asin)) 
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'Empty search query provided',
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            if (isset($aiomatic_Chatbot_Settings['affiliate_id']) && trim($aiomatic_Chatbot_Settings['affiliate_id']) != '')
                            {
                                $aff_id = trim($aiomatic_Chatbot_Settings['affiliate_id']);
                            }
                            else
                            {
                                $aff_id = '';
                            }
                            if (isset($aiomatic_Chatbot_Settings['target_country']) && trim($aiomatic_Chatbot_Settings['target_country']) != '')
                            {
                                $target_country = trim($aiomatic_Chatbot_Settings['target_country']);
                            }
                            else
                            {
                                $target_country = 'com';
                            }
                            $max_prod = 1;
                            $amazresult = aiomatic_amazon_get_post($asin, trim($aff_id), $target_country, '', '', '', $max_prod, '1', array());
                            if(is_array($amazresult) && ((isset($amazresult['status']) && $amazresult['status'] == 'nothing') || count($amazresult) == 0))
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'No Amazon products found for query: ' . $asin,
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            if(!is_array($amazresult))
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'An error occurred while search Amazon for: ' . $asin,
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            else
                            {
                                $final_result = 'Product title: ' . $amazresult[0]->offer_title . '\n';
                                $final_result .= 'Description: ' . $amazresult[0]->offer_desc . '\n';
                                $final_result .= 'URL: ' . $amazresult[0]->offer_url . '\n';
                                $final_result .= 'Price: ' . $amazresult[0]->offer_price . '\n';
                                $final_result .= 'Listing Price: ' . $amazresult[0]->product_list_price . '\n';
                                $final_result .= 'Image: ' . $amazresult[0]->offer_img . '\n';
                                $final_result .= 'Add to cart URL: ' . $amazresult[0]->cart_url . '\n';
                                $final_result .= 'Other images: ' . $amazresult[0]->product_imgs . '\n';
                                $final_result .= 'Reviews: ' . implode(PHP_EOL, $amazresult[0]->item_reviews) . '\n';
                                $reply->aiomatic_tool_results[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $final_result,
                                    'assistant_message' => $as_mes
                                );
                            }
                        }
                        else
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $reply->aiomatic_tool_results = array(array(
                                "tool_call_id" => $tool_call->id,
                                "role" => "tool",
                                "content" => 'query parameter not found',
                                'assistant_message' => $as_mes
                            ));
                            aiomatic_log_to_file('Failed to decode function calling: ' . print_r($tool_call, true));
                        }
                    }
                    elseif ($tool_call->function->name === 'aiomatic_website_scraper') 
                    {
                        if(isset($tool_call->function->arguments->url))
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $result = '';
                            $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                            $scurl = $tool_call->function->arguments->url;
                            if (empty($scurl)) 
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'Empty scrape url provided',
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            if (isset($aiomatic_Chatbot_Settings['scrape_method']) && trim($aiomatic_Chatbot_Settings['scrape_method']) != '')
                            {
                                $scrape_method = trim($aiomatic_Chatbot_Settings['scrape_method']);
                            }
                            else
                            {
                                $scrape_method = '0';
                            }
                            if (isset($aiomatic_Chatbot_Settings['max_chars']) && trim($aiomatic_Chatbot_Settings['max_chars']) != '')
                            {
                                $max_chars = trim($aiomatic_Chatbot_Settings['max_chars']);
                            }
                            else
                            {
                                $max_chars = '';
                            }
                            $scrape_selector = 'auto';
                            $scrape_string = '';
                            if (isset($aiomatic_Chatbot_Settings['strip_tags']) && trim($aiomatic_Chatbot_Settings['strip_tags']) != '')
                            {
                                $strip_tags = trim($aiomatic_Chatbot_Settings['strip_tags']);
                            }
                            else
                            {
                                $strip_tags = '0';
                            }
                            $scraped_data = aiomatic_scrape_page($scurl, $scrape_method, $scrape_selector, $scrape_string);
                            if($scraped_data === false)
                            {
                                $reply->aiomatic_tool_results = array(array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => 'Failed to scrape website URL: ' . $scurl,
                                    'assistant_message' => $as_mes
                                ));
                                continue;
                            }
                            else
                            {
                                if($strip_tags == '1')
                                {
                                    $scraped_data = wp_strip_all_tags($scraped_data);
                                }
                                else
                                {
                                    $scraped_data = aiomatic_fix_relative_links($scraped_data, $scurl);
                                }
                                if(!empty($max_chars) && is_numeric($max_chars))
                                {
                                    $scraped_data = (strlen($scraped_data) > intval($max_chars)) ? substr($scraped_data, 0, intval($max_chars)) : $scraped_data;
                                }
                                $reply->aiomatic_tool_results[] = array(
                                    "tool_call_id" => $tool_call->id,
                                    "role" => "tool",
                                    "content" => $scraped_data,
                                    'assistant_message' => $as_mes
                                );
                            }
                        }
                        else
                        {
                            if(isset($reply->choices[0]->message))
                            {
                                $as_mes = $reply->choices[0]->message;
                            }
                            else
                            {
                                $as_mes = '';
                            }
                            $reply->aiomatic_tool_results = array(array(
                                "tool_call_id" => $tool_call->id,
                                "role" => "tool",
                                "content" => 'url parameter not found',
                                'assistant_message' => $as_mes
                            ));
                            aiomatic_log_to_file('Failed to decode function calling: ' . print_r($tool_call, true));
                        }
                    }
                }
            }
        }
    }
    return $reply;
}
?>