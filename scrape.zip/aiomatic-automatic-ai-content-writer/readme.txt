=== AIomatic - Automatic AI Content Writer ===
Contributors: coderevolution
Donate link: https://www.patreon.com/coderevolution
Tags: popup, subscribers
Requires at least: 4.0
Tested up to: 6.4
Stable tag: 6.4
License: Regular/Extended License

Another plugin made by CodeRevolution.

== Description ==

Nice to meet you! My name is Szabi from CodeRevolution. We are a team of a few people who work FULL TIME as freelancers, making plugins and scripts for Envato Market. Because we dedicate all our time to this, our items are filled with passion, and we can offer premium support to our customers all the time! Feel free to ask in advance any question you might have about our items! If you buy any of our items, you will have support in case something is not working as specified, related to our item, according to Envato Support Policy. 
Hope that you enjoy my work!

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Plugin Name screen to configure the plugin


== Frequently Asked Questions ==

= How do I update this plugin? =

This plugin supports automatical updating. Please click "Check for updates" for this plugin in the WordPress plugins control panel. If a new version is available you will be prompted. Click "Update now" to finish the updating process.

== Changelog ==

= 1.0 =
For a detailed changelog, please check the plugin's CodeCanyon page, from here (search for the plugin, from our portfolio): //1.envato.market/coderevolutionplugins