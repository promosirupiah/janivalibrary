<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="aiomatic-modal-content">
    <table class="wp-list-table widefat fixed striped table-view-list comments">
        <thead>
        <tr>
            <th>ID</th>
            <th>Purpose</th>
            <th>Size</th>
            <th>Created At</th>
            <th>Filename</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
            <tr>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td><?php echo esc_html($aiomatic_data)?></td>
                <td>-</td>
            </tr>
        </tbody>
    </table>
</div>
