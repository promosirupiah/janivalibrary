<?php
$aiomatic_simulated = false;
if(!class_exists('AiomaticObj'))
{
	#[AllowDynamicProperties]
	class AiomaticObj
	{
		public $link_url = '';
		public $link_keyword = '';
		public $link_status = '';
		public $link_desc = '';
	}
}
if(!class_exists('AiomaticProductObj'))
{
	#[AllowDynamicProperties]
	class AiomaticProductObj
	{
		public $product_author = '';
		public $product_brand = '';
		public $product_isbn = '';
		public $product_upc = '';
		public $offer_title = '';
		public $offer_desc = '';
		public $offer_url = '';
		public $source_link = '';
		public $offer_price = '';
		public $product_price = '';
		public $product_list_price = '';
		public $offer_img = '';
		public $product_img = '';
		public $price_numeric = '';
		public $price_currency = '';
		public $review_link = '';
		public $product_asin = '';
		public $cart_url = '';
		public $list_price_numeric = '';
		public $product_imgs = '';
		public $product_imgs_html = '';
		public $price_with_discount_fixed = '';
		public function getBrand()
		{
			return $this->product_brand;
		}
		public function getAuthor()
		{
			return $this->product_author;
		}
		public function getPrice()
		{
            return $this->price_numeric . $this->price_currency;
		}
		public function getPricePlain()
		{
            return $this->price_numeric;
		}
		public function getCurrency()
		{
			return $this->price_currency;
		}
		public function getISBN()
		{
			return $this->product_isbn;
		}
		public function getASIN()
		{
			return $this->product_asin;
		}
		public function getDetailPageURL()
		{
			return $this->offer_url;
		}
		public function getImage()
		{
			return $this->product_img;
		}
		public function getImages()
		{
			return $this->product_imgs;
		}
		public function getItemInfo()
		{
			return $this->offer_desc;
		}
		public function getScore()
		{
			return '';
		}
		public function getBrowseNodeInfo()
		{
			return null;
		}
		public function getTitle()
		{
			return $this->offer_title;
		}
	}
}

function aiomatic_amazon_get_post($keyword, $affiliateID, $region, $low_price, $high_price, $order, $max, $page, $posted_items) 
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '')
    {
        $prx = explode(',', $aiomatic_Main_Settings['proxy_url']);
        $randomness = array_rand($prx);
        curl_setopt($ch, CURLOPT_PROXY , trim($prx[$randomness]));
        if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') 
        {
            $prx_auth = explode(',', $aiomatic_Main_Settings['proxy_auth']);
            if(isset($prx_auth[$randomness]) && trim($prx_auth[$randomness]) != '')
            {
                curl_setopt($ch, CURLOPT_PROXYUSERPWD , trim($prx_auth[$randomness]));
            }
        }
    }
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    if (isset($aiomatic_Main_Settings['max_timeout']) && $aiomatic_Main_Settings['max_timeout'] != '')
    {
        $ztime = intval($aiomatic_Main_Settings['max_timeout']);
    }
    else
    {
        $ztime = 300;
    }
    curl_setopt($ch, CURLOPT_TIMEOUT, $ztime);
	curl_setopt($ch, CURLOPT_REFERER, "https://www.amazon." . $region . "/");
	curl_setopt($ch, CURLOPT_COOKIEFILE, 'amazcookie.txt');
	curl_setopt($ch, CURLOPT_COOKIEJAR, 'amazcookie.txt');	
	$keyword = trim($keyword);
	if (trim($keyword) != '') 
	{
		$res = aiomatic_amazon_fetch_links($keyword, $region, $affiliateID, $ch, $low_price, $high_price, $order, $max, $page, $posted_items);
		if($res === false)
		{
			return array('status' => 'nothing');
		}
		$res_count = count($res);
		for($i = 0; $i < $res_count; $i ++) 
		{
			$t_row = $res[$i];
			$t_link_url = $t_row->link_url;
			$possible_full_link = $t_link_url;
			if (! stristr($t_link_url, 'http')) 
			{
				$possible_full_link = 'https://amazon.' . $region . '/dp/' . $t_link_url;
			} 
			else 
			{
				$link_parts = explode('/dp/', $t_link_url);
				$asin = $link_parts [1];
			}			
			if (! stristr($t_link_url, 'http')) 
			{
				$asin = $t_link_url;
				require_once (dirname(__FILE__) . '/aiomatic-noapi.php');
				$obj = new aiomatic_no_amazon_api($ch, $region);
				try 
				{
					aiomatic_simulate_location($region);
					curl_setopt($ch, CURLOPT_USERAGENT, aiomatic_get_random_user_agent());
					$item = $obj->getItemByAsin($asin, $t_row->link_desc, $affiliateID);
				} 
				catch(Exception $e) 
				{
					aiomatic_log_to_file('Amazon reading error:' . $e->getMessage ());
					return false;
				}
				if (isset($item ['link_title']) && trim($item ['item_price']) != '') 
				{
					$desc = '';
					if(isset($item ['item_description']))
					{
						$desc = $item ['item_description'];
					}
					if (count($item ['item_features']) > 0) 
					{
						$desc .= '<br>' . implode('<br>', $item ['item_features']);
					}
					$title = $item ['link_title'];
					if (isset($Item->ItemAttributes->Author)) {
						$title .= '**' . $Item->ItemAttributes->Author;
					} else {
						$title .= '** ';
					}
					if (isset($Item->ItemAttributes->Brand)) {
						$title .= '**' . $Item->ItemAttributes->Brand;
					} else {
						$title .= '** ';
					}
					if (isset($Item->ItemAttributes->ISBN)) {
						$title .= '**' . $Item->ItemAttributes->ISBN;
					} else {
						$title .= '** ';
					}
					if (isset($Item->ItemAttributes->UPC)) {
						$title .= '**' . $Item->ItemAttributes->UPC;
					} else {
						$title .= '** ';
					}
					$t_link_url = $linkUrl = $item ['item_link'];
					$price = '';
					$price = $item ['item_price'] . '-' . $item ['item_pre_price'];
					$imgurl = '';
					$imgurl = implode(',', $item ['item_images']);
					$review = $item ['item_reviews'];
					$t_row->link_url = $linkUrl;
					$t_row->link_title = $title;
					$t_row->link_desc = $desc;
					$t_row->link_price = $price;
					$t_row->link_img = $imgurl;
					$t_row->item_features_html = $item ['item_features_html'];
					$t_row->item_reviews_text = $item ['item_reviews_text'];
					$t_row->link_review =(string) $review;
					$res [$i] = $t_row;
				}
				else 
				{
					unset($res [$i]);
				}
			}
		}
		$temp_rez = array();
		if (count($res) > 0) 
		{
			for($i = 0; $i < count($res); $i ++) 
			{
				$temp = new AiomaticProductObj();
                if(!isset($res [$i]))
                {
                    continue;
                }
				$ret = $res [$i];
				if (stristr($ret->link_price, '-')) 
				{
					$priceParts = explode('-', $ret->link_price);
					$ret->link_price = $priceParts [0];
					$salePrice = $priceParts [1];
				} else {
					$salePrice = $ret->link_price;
				}
				$offer_title = $ret->link_title;
				$temp->product_author = '';
				$temp->product_brand = '';
				$temp->product_isbn = '';
				if (stristr($offer_title, '**')) 
				{
					$titleParts = explode('**', $offer_title);
					$offer_title = $titleParts [0];
					$temp->product_author = $titleParts [1];
					$temp->product_brand = $titleParts [2];
					if (isset($titleParts [3]))
						$temp->product_isbn = $titleParts [3];
					if (isset($titleParts [4])) {
						$temp->product_upc = $titleParts [4];
					} else {
						$temp->product_upc = '';
					}
				}
				$offer_desc = $ret->link_desc;
				$offer_desc = str_replace('View larger.', '', $offer_desc);
				$offer_desc = str_replace('To report an issue with this product, click here. ', '', $offer_desc);
				$offer_desc = str_replace('Show more', '', $offer_desc);
				$offer_desc = str_replace('From the Publisher', '', $offer_desc);
				$offer_desc = str_replace('See more product details', '', $offer_desc);
				$offer_desc = str_replace('To calculate the overall star rating and percentage breakdown by star, we don’t use a simple average. Instead, our system considers things like how recent a review is and if the reviewer bought the item on Amazon. It also analyzed reviews to verify trustworthiness. ', '', $offer_desc);
				$offer_url = $ret->link_url . '?tag=' . $affiliateID;
				$offer_price = trim($ret->link_price);
				$offer_img = $ret->link_img;
				$temp->offer_title = $offer_title;
				$temp->offer_desc = wp_strip_all_tags($offer_desc, true);
				$temp->offer_url = $offer_url;
				$temp->source_link = $ret->link_url;
				$temp->offer_price = $offer_price;
				$temp->product_price = $offer_price;
				$temp->product_list_price = $salePrice;
				$temp->offer_img = $offer_img;
				$temp->product_img = $offer_img;
				$temp->price_numeric = '00.00';
				$temp->price_currency = '$';
				$temp->offer_desc .= '<br>' . str_replace('About this item ', '', wp_strip_all_tags(trim($ret->item_features_html), true));
				$temp->item_reviews = $ret->item_reviews_text;
				$ret->link_review = preg_replace('{exp\=20\d\d}', 'exp=2030', $ret->link_review);
				$ret->link_review = str_replace('http://', '//', $ret->link_review);
				$temp->review_link = $ret->link_review;
				$tag = '';
				$subscription = '';
				if (stristr($offer_url, 'creativeASIN')) 
				{
					$enc_url = urldecode($offer_url);
					$enc_url = explode('?', $enc_url);
					$enc_parms = $enc_url [1];
					$enc_parms_arr = explode('&', $enc_parms);
					foreach($enc_parms_arr as $param) 
					{
						if (stristr($param, 'creativeASIN')) {
							$asin = str_replace('creativeASIN=', '', $param);
						} elseif (stristr($param, 'tag=')) {
							$tag = str_replace('tag=', '', $param);
						} elseif (stristr($param, 'SubscriptionId')) {
							$subscription = str_replace('SubscriptionId=', '', $param);
						}
					}
				} 
				else 
				{
					$tag = $affiliateID;
				}
				$temp->product_asin = $asin;
				$cart_url = "https://www.amazon.$region/gp/aws/cart/add.html?AssociateTag=$tag&ASIN.1=$asin&Quantity.1=1&SubscriptionId=$subscription";
				$temp->cart_url = $cart_url;
				if (trim($ret->link_price) != '') {
					$thousandSeparator = ',';
					if ($region == 'es' || $region == 'de' || $region == 'fr' || $region == 'it' || $region == 'com.br') {
						$thousandSeparator = '.';
					}
					$price_no_commas = str_replace($thousandSeparator, '', $offer_price);
					preg_match('{\d.*\d}is', $price_no_commas, $price_matches);
                    if(isset($price_matches [0]))
                    {
						$temp->price_numeric = $price_matches [0];
                    }
                    else
                    {
                        $temp->price_numeric = '';
                    }
                    $temp->price_currency = preg_replace('{[\d .,]*}', '', $offer_price);
					$price_no_commas = str_replace($thousandSeparator, '', $salePrice);
					preg_match('{\d.*\d}is', $price_no_commas, $price_matches);
                    if(isset($price_matches [0]))
                    {
						$temp->list_price_numeric = $price_matches [0];
                    }
                    else
                    {
                        $temp->list_price_numeric = '';
                    }
				}
				$temp->product_imgs = $temp->product_img;
				if (stristr($temp->product_img, ',')) {
					$imgs = explode(',', $temp->product_imgs);
					$temp->product_img = $temp->offer_img = $imgs [0];
				}
				$cg_am_full_img_t = @$camp_general ['cg_am_full_img_t'];
				if (empty($cg_am_full_img_t) || trim($cg_am_full_img_t) == '') {
					$cg_am_full_img_t = '<img src="[img_src]" class="amazon_gallery" />';
				}
				$product_imgs_html = '';
				$allImages = explode(',', $temp->product_imgs);
				$allImages_html = '';
				foreach($allImages as $singleImage) {
					$singleImageHtml = $cg_am_full_img_t;
					$singleImageHtml = str_replace('[img_src]', $singleImage, $singleImageHtml);
					$allImages_html .= $singleImageHtml;
				}
				$temp->product_imgs_html = $allImages_html;
				if ($temp->product_price == $temp->product_list_price) {
					$temp->price_with_discount_fixed = $temp->product_price;
				} else {
					$temp->price_with_discount_fixed = '<del>' . $temp->product_list_price . '</del> - ' . $temp->product_price;
				}
				if (trim($temp->product_price) == '')
					$temp->product_price = $temp->price_numeric;
				if (trim($temp->product_list_price) == '')
					$temp->product_list_price = $temp->price_numeric;
				$temp_rez[] = $temp;
			}
		} else {
			aiomatic_log_to_file('Amazon no results found.');
			return false;
		}
		return $temp_rez;
	}
	aiomatic_log_to_file('No usable keywords found.');
	return array();
}
function aiomatic_amazon_fetch_links($keyword, $region, $affiliateID, $ch, $low_price, $high_price, $order, $max, $page, $posted_items) {
	$scrapeURL = "https://www.amazon.{$region}/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=" . urlencode(trim($keyword));
	if($low_price != '' && is_numeric($low_price))
	{
		$scrapeURL .= '&low-price=' . $low_price / 100;
	}
	if($high_price != '' && is_numeric($high_price))
	{
		$scrapeURL .= '&high-price=' . $high_price / 100;
	}
	if($order != '' && $order != 'none')
	{
		$scrapeURL .= '&sort=' . $order;
	}
	if($page != '' && is_numeric($page) && $page > 1)
	{
		$scrapeURL .= '&page=' . $page;
	}
	require_once (dirname(__FILE__) . '/aiomatic-noapi.php');
	$obj = new aiomatic_no_amazon_api($ch, $region);	
	try 
	{
		curl_setopt($ch, CURLOPT_USERAGENT, aiomatic_get_random_user_agent());
		aiomatic_simulate_location($region);
		$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
		if (preg_match('!^B0!', $keyword)) 
		{		
			$ASINs = explode('|', $keyword);
			$ASINs = array_map('trim', $ASINs);
		} 
		else 
		{
			if (isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on') {
				aiomatic_log_to_file('Scraping: ' . $scrapeURL);
			}
			$ASINs = $obj->getASINs($scrapeURL);
			if (isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on') {
				aiomatic_log_to_file('Returned product count: ' . count($ASINs));
			}
		}	
		$slugs = $obj->slugs;
		$i = 0;
		$results = array();
		foreach($ASINs as $ASIN) {
			if(in_array($ASIN, $posted_items))
			{
				if (isset($aiomatic_Main_Settings['enable_detailed_logging']) && $aiomatic_Main_Settings['enable_detailed_logging'] == 'on') {
					aiomatic_log_to_file('Skipping product, already published: ' . $ASIN);
				}
				continue;
			}
			$slug = '';
			if (isset($slugs [$i]))
				$slug = $slugs [$i];
			$mobj = new AiomaticObj();
			$mobj->link_url = $ASIN;
			$mobj->link_keyword = $keyword;
			$mobj->link_status = '0';
			$mobj->link_desc = $slug;
			$results[] = $mobj;
			$i ++;
		}
		if(count($results) == 0 && count($ASINs) > 0)
		{
			return false;
		}
		$results = array_slice($results, 0, $max, true);
		return $results;
	} 
	catch(Exception $e) 
	{
		aiomatic_log_to_file('Exception during Amazon scraping: ' . $e->getMessage ());
		return array();
	}
}

function aiomatic_simulate_location($region) 
{
	if (!isset($GLOBALS['aiomatic_simulated']) || $GLOBALS['aiomatic_simulated'] == false) 
	{
		$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
		$curlpost = '';
		if ($region == 'com') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=10001&storeContext=gateway&deviceType=web&pageType=Search&actionSource=glow";
		} elseif ($region == 'co.uk') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=E1+7EF&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'ca') {
			$curlpost = 'locationType=LOCATION_INPUT&zipCode=V5K+0A1&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow';
		} elseif ($region == 'de') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=10178&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'fr') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=75000&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'it') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=00127&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'es') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=08005&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'co.jp') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=100-0000&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'in') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=110001&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'com.br') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=20010-000&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		} elseif ($region == 'com.mx') {
			$curlpost = "locationType=LOCATION_INPUT&zipCode=44100&storeContext=generic&deviceType=web&pageType=Gateway&actionSource=glow";
		}
		if($curlpost != '')
		{
			$curlurl = "https://www.amazon.$region/gp/delivery/ajax/address-change.html";
			$ch = curl_init();
			if (isset($aiomatic_Main_Settings['proxy_url']) && $aiomatic_Main_Settings['proxy_url'] != '')
			{
				$prx = explode(',', $aiomatic_Main_Settings['proxy_url']);
				$randomness = array_rand($prx);
				curl_setopt($ch, CURLOPT_PROXY , trim($prx[$randomness]));
				if (isset($aiomatic_Main_Settings['proxy_auth']) && $aiomatic_Main_Settings['proxy_auth'] != '') 
				{
					$prx_auth = explode(',', $aiomatic_Main_Settings['proxy_auth']);
					if(isset($prx_auth[$randomness]) && trim($prx_auth[$randomness]) != '')
					{
						curl_setopt($ch, CURLOPT_PROXYUSERPWD , trim($prx_auth[$randomness]));
					}
				}
			}
			curl_setopt ( $ch, CURLOPT_URL, $curlurl );
			curl_setopt ( $ch, CURLOPT_POST, true );
			curl_setopt ( $ch, CURLOPT_POSTFIELDS, $curlpost );
			curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, 10);
			if (isset($aiomatic_Main_Settings['max_timeout']) && $aiomatic_Main_Settings['max_timeout'] != '')
			{
				$ztime = intval($aiomatic_Main_Settings['max_timeout']);
			}
			else
			{
				$ztime = 300;
			}
			curl_setopt($ch, CURLOPT_TIMEOUT, $ztime);
			$exec = curl_exec ( $ch );
			curl_close($ch);
			$GLOBALS['aiomatic_simulated'] = true;
		}
	}
}
?>