<?php

namespace fivefilters\Readability\Nodes\DOM;

use fivefilters\Readability\Nodes\NodeTrait;

class DOMDocumentFragment extends \DOMDocumentFragment
{
    use NodeTrait;
}
