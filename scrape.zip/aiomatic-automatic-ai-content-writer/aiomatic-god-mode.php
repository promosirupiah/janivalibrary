<?php
defined('ABSPATH') or die();
function aiomatic_return_god_function_assistants($god_mode, $dalle, $stable, $amazon, $amazon_details, $scraper)
{
    $return_arr = array();
    if ($god_mode === true)
    {
        $return_arr[] = aiomatic_get_god_mode_object();
    }
    if ($dalle === true)
    {
        $return_arr[] = aiomatic_get_dalle_object();
    }
    if ($stable === true)
    {
        $return_arr[] = aiomatic_get_stable_object();
    }
    if ($amazon === true)
    {
        $return_arr[] = aiomatic_get_amazon_object();
    }
    if ($amazon_details === true)
    {
        $return_arr[] = aiomatic_get_amazon_details_object();
    }
    if ($scraper === true)
    {
        $return_arr[] = aiomatic_get_scraper_object();
    }
    return $return_arr;
}
function aiomatic_get_god_mode_object()
{
    return new Aiomatic_Query_Function(
        'aiomatic_wp_god_mode',
        'Call any WordPress function using this wrapper function. Add the WP function name which needs to be called in the first parameter, and the parameters which needs to be sent to the function, in an array, sent as the second parameter for the wrapper function. Parameters will be processed using call_user_func_array, use parameters accordingly.',
        [
            new Aiomatic_Query_Parameter('called_function_name', 'The name of the WP function which needs to be called.', 'string', true),
            new Aiomatic_Query_Parameter('parameter_array', 'An array of parameters which should be sent to the function. Return parameters which can be parsed by call_user_func_array, as this is how the function will be called.', 'string', true)
        ]
        );
}
function aiomatic_get_dalle_object()
{
    return new Aiomatic_Query_Function(
        'aiomatic_image',
        'Call Dall-E AI to generate an image.',
        [
            new Aiomatic_Query_Parameter('prompt', 'The prompt which will be used for the AI image generator.', 'string', true)
        ]
        );
}
function aiomatic_get_amazon_object()
{
    return new Aiomatic_Query_Function(
        'aiomatic_amazon_listing',
        'Get an Amazon product listing based on a search keyword phrase.',
        [
            new Aiomatic_Query_Parameter('query', 'The keyword phrase for which the Amazon product listing should be returned.', 'string', true)
        ]
        );
}
function aiomatic_get_amazon_details_object()
{
    return new Aiomatic_Query_Function(
        'aiomatic_amazon_product_details',
        'Get details for a specific Amazon product, by ASIN or by keyword phrase.',
        [
            new Aiomatic_Query_Parameter('query', 'The ASIN or keyword phrase for which the Amazon product details should be returned.', 'string', true)
        ]
        );
}
function aiomatic_get_stable_object()
{
    return new Aiomatic_Query_Function(
        'aiomatic_stable_image',
        'Call Stable Diffusion AI to generate an image.',
        [
            new Aiomatic_Query_Parameter('prompt', 'The prompt which will be used for the AI image generator.', 'string', true)
        ]
        );
}
function aiomatic_get_scraper_object()
{
    return new Aiomatic_Query_Function(
        'aiomatic_website_scraper',
        'Scrape any website URL and get the resulting content.',
        [
            new Aiomatic_Query_Parameter('url', 'The URL of the website which will be scraped.', 'string', true)
        ]
        );
}
function aiomatic_return_god_function()
{
    $return_arr = array();
    $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
    if (isset($aiomatic_Chatbot_Settings['god_mode_enable_wp']) && trim($aiomatic_Chatbot_Settings['god_mode_enable_wp']) == 'on')
    {
        $return_arr[] = array('type' => 'function', 'function' => aiomatic_get_god_mode_object());
    }
    if (isset($aiomatic_Chatbot_Settings['god_mode_enable_dalle']) && trim($aiomatic_Chatbot_Settings['god_mode_enable_dalle']) == 'on')
    {
        $return_arr[] = array('type' => 'function', 'function' => aiomatic_get_dalle_object());
    }
    if (isset($aiomatic_Chatbot_Settings['god_mode_enable_amazon']) && trim($aiomatic_Chatbot_Settings['god_mode_enable_amazon']) == 'on')
    {
        $return_arr[] = array('type' => 'function', 'function' => aiomatic_get_amazon_object());
    }
    if (isset($aiomatic_Chatbot_Settings['god_mode_enable_amazon_details']) && trim($aiomatic_Chatbot_Settings['god_mode_enable_amazon_details']) == 'on')
    {
        $return_arr[] = array('type' => 'function', 'function' => aiomatic_get_amazon_details_object());
    }
    if (isset($aiomatic_Chatbot_Settings['god_mode_enable_stable']) && trim($aiomatic_Chatbot_Settings['god_mode_enable_stable']) == 'on')
    {
        $return_arr[] = array('type' => 'function', 'function' => aiomatic_get_stable_object());
    }
    if (isset($aiomatic_Chatbot_Settings['god_mode_enable_scraper']) && trim($aiomatic_Chatbot_Settings['god_mode_enable_scraper']) == 'on')
    {
        $return_arr[] = array('type' => 'function', 'function' => aiomatic_get_scraper_object());
    }
    return $return_arr;
}
add_filter('aiomatic_ai_functions', 'aiomatic_add_god_mode', 999, 1);
function aiomatic_add_god_mode($query) 
{
    if(is_array($query))
    {
        $functions = $query;
    }
    else
    {
        $functions = array();
    }
    if ( current_user_can( 'manage_options' ) ) 
    {
        $functions['functions'] = aiomatic_return_god_function();
        $functions['message'] = '';
    }
    return $functions;
}
?>