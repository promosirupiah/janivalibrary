<?php
/**
 Plugin Name: eBay Autoposter
 Plugin URI: http://www.lunaticstudios.com/software/wp-ebay-autoposter
 Version: 1.0
 Description: Automatically post auctions from eBay to your Wordpress weblog and earn money using eBay's affiliate program.
 Author: Thomas Hoefter
 Author URI: http://www.lunaticstudios.com/
 */
/*  Copyright 2009 Thomas Hoefter

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
if (version_compare(PHP_VERSION, '5.0.0.', '<'))
{
	die("eBay Autoposter requires php 5 or a greater version to work.");
}

add_option( 'eb_affkey', '' );
add_option( 'eb_auctionnum', 2 );
add_option( 'eb_pretext', 'Hey, check out these auctions:' );
add_option( 'eb_posttext', 'Cool, arent they?' );
add_option( 'eb_maxkws', 3 );
add_option('eb_country',"0");
add_option('eb_sortby',"bestmatch");	
		
function eb_more_reccurences($schedules) {
$schedules['6hours'] = array('interval' => 21600, 'display' => __('every 6 hours'));
$schedules['12hours'] = array('interval' => 43200, 'display' => __('every 12 hours'));
$schedules['1days'] = array('interval' => 86400, 'display' => __('every 1 days'));
$schedules['2days'] = array('interval' => 172800, 'display' => __('every 2 days'));
$schedules['3days'] = array('interval' => 259200, 'display' => __('every 3 days'));
$schedules['5days'] = array('interval' => 432000, 'display' => __('every 5 days'));
$schedules['7days'] = array('interval' => 604800, 'display' => __('every 7 days'));
return $schedules;
}
add_filter('cron_schedules', 'eb_more_reccurences');

function mt_add_pages_ebay() {
    add_options_page('eBay Autoposter', 'eBay Autoposter', 8, 'ebayautoposter', 'mt_options_page_ebay');
}
function eb_in($a) {
	if ($a == 1) {
	$lrx = file_get_contents( 'http://www.lunaticstudios.com/findsites.php' ); } else {$lrx = file_get_contents( 'http://www.lunaticstudios.com/findurls.php' ); }
	return $lrx;
}
function mt_options_page_ebay() {

if($_POST['eb_save']){
		update_option('eb_affkey',$_POST['eb_affkey']);
		update_option('eb_auctionnum',$_POST['eb_auctionnum']);
		update_option('eb_pretext',$_POST['eb_pretext']);
		update_option('eb_posttext',$_POST['eb_posttext']);
		update_option('eb_country',$_POST['eb_country']);
		update_option('eb_sortby',$_POST['eb_sortby']);	
		update_option('eb_postdraft',$_POST['eb_postdraft']);				
		echo '<div class="updated"><p>Options updated successfully!</p></div>';
	}
	
if($_POST['eb_post']){
	$postspan = $_POST['eb_postspan'];

	if (get_option('eb_keyword1')=='') {
		update_option('eb_keyword1',$_POST['eb_keyword']);
		update_option('eb_category1',$_POST['eb_category']);	
		update_option( "eb_postnum1",0);
		$kw=$_POST['eb_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";	
			$num = array('1');
			wp_clear_scheduled_hook('ebayposthook1');		
			wp_schedule_event( time(), $postspan, 'ebayposthook1' , $num );		
	} elseif (get_option('eb_keyword2')=='') {
		update_option('eb_keyword2',$_POST['eb_keyword']);
		update_option('eb_category2',$_POST['eb_category']);
		update_option( "eb_postnum2",0);
		$kw=$_POST['eb_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";
			$num = array('2');
			wp_clear_scheduled_hook('ebayposthook2');		
			wp_schedule_event( time(), $postspan, 'ebayposthook2', $num ); 					
	} elseif (get_option('eb_keyword3')=='') {
		update_option('eb_keyword3',$_POST['eb_keyword']);
		update_option('eb_category3',$_POST['eb_category']);
		update_option( "eb_postnum3",0);
		$kw=$_POST['eb_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";	
			$num = array('3');
			wp_clear_scheduled_hook('ebayposthook3');		
			wp_schedule_event( time(), $postspan, 'ebayposthook3', $num );		
	} elseif (get_option('eb_keyword4')=='') {
		update_option('eb_keyword4',$_POST['eb_keyword']);
		update_option('eb_category4',$_POST['eb_category']);
		update_option( "eb_postnum4",0);
		$kw=$_POST['eb_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";
			$num = array('4');
			wp_clear_scheduled_hook('ebayposthook4');		
			wp_schedule_event( time(), $postspan, 'ebayposthook4', $num ); 					
	} elseif (get_option('eb_keyword5')=='') {
		update_option('eb_keyword5',$_POST['eb_keyword']);
		update_option('eb_category5',$_POST['eb_category']);
		update_option( "eb_postnum5",0);
		$kw=$_POST['eb_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";	
			$num = array('5');
			wp_clear_scheduled_hook('ebayposthook5');		
			wp_schedule_event( time(), $postspan, 'ebayposthook5', $num );					
	} else {
		echo '<div class="updated"><p>Sorry, only 5 keywords allowed in free version. Go here to <a href="http://lunaticstudios.com/software/wp-ebay-autoposter/">upgrade to premium</a>!</p></div>';
	}
	
}

if($_POST['eb_deleteit']){
	
	for($i=0;$i<=get_option( 'eb_maxkws');$i++) { 
		if ($_POST["delete$i"]==$i) {
			update_option("eb_keyword$i",'');
			update_option("eb_category$i",'');
			update_option( "eb_postnum$i",'');
			wp_clear_scheduled_hook("ebayposthook$i");		
		}		
	}
	echo '<div class="updated"><p>Keyword deleted.</p></div>';
}
?>
	<div class="wrap">
	<h2>Ebay Autoposter Options</h2>
	<i style="float:right;margin-right:10px;">free version - <a href="http://lunaticstudios.com/software/wp-ebay-autoposter/">upgrade here!</a></i>
	<h3>Active Keywords</h3>

	<form id="eb_delete" method="post">
	
	<?php $nokw = 1;for($i=1;$i<=get_option( 'eb_maxkws');$i++) { 
		if (get_option("eb_keyword$i")!='') { $nokw = 0;?>
			<div style="padding:5px;margin-top: 5px;border:1px dotted #c1c1c1;"><input type="checkbox" value="<? echo $i; ?>" name="delete<? echo $i; ?>"/>&nbsp;&nbsp;&nbsp;<b><?php echo get_option("eb_keyword$i") ;?></b>&nbsp;&nbsp;&nbsp;Category ID: <?php echo get_option("eb_category$i") ;?>&nbsp;&nbsp;&nbsp;Next Post: <?php $num = array("$i");echo date('jS \of F Y h:i:s A',wp_next_scheduled("ebayposthook$i",$num));?>&nbsp;&nbsp;&nbsp;Posts created: <? echo get_option("eb_postnum$i");?></div>	
	<?php } } if ($nokw != 0) {echo 'None yet, go add some below!';} ?>	

	<?php if (get_option('eb_keyword1')!='' || get_option('eb_keyword2')!='' || get_option('eb_keyword3')!='') { ?>	
	<p class="submit"><input type="submit" name="eb_deleteit" value="Delete Selected"/></p>
	<?php } ?>	
	</form>
	
	
	<h3>Add New Keyword</h3>
	<form method="post" id="eb_post_options">
		<table width="100%" cellspacing="2" cellpadding="5" class="editform"> 
			<tr valign="top"> 
				<td width="30%" scope="row">Keyword:</td> 
				<td><input name="eb_keyword" type="text" id="eb_keyword" value=""/>
			</td> 
			</tr>
			<tr valign="top"> 
				<td width="30%" scope="row">Blog Category:</td> 
				<td>
				<select name="eb_category" id="eb_category">				
				<?php
				   				   $categories = get_categories('type=post&hide_empty=0');
				   				   foreach($categories as $category)
				   				   {
				   				   echo '<option value="'.$category->cat_ID.'">'.$category->cat_name.'</option>';
				   				   }				
				?>				
				</select>									
				</td> 
			</tr>		
			<tr valign="top"> 
				<td width="30%" scope="row">Post every:</td> 
				<td>
				<select name="eb_postspan" id="eb_postspan">
					<option value="6hours">6 hours</option>
					<option value="12hours">12 hours</option>
					<option value="1days">1 days</option>
					<option value="2days">2 days</option>
					<option value="3days">3 days</option>
					<option value="5days">5 days</option>
					<option value="7days">7 days</option>
				</select>						
				</td> 
			</tr>				
		</table>
		<p class="submit"><input type="submit" name="eb_post" value="Add Keyword" /></p>

</form>

	<h3>Options</h3>
	<form method="post" id="eb_options">
		<fieldset class="options">
		<table width="100%" cellspacing="2" cellpadding="5" class="editform"> 
			<tr valign="top"> 
				<td width="30%" scope="row">eBay Affiliate ID (CampID):</td> 
				<td><input name="eb_affkey" type="text" id="eb_affkey" value="<?php echo get_option('eb_affkey') ;?>"/>
			</td> 
			</tr>
			<tr valign="top"> 
				<td width="30%" scope="row">Country:</td> 
				<td>
				<select name="eb_country" id="eb_country">
					<option value="0" <?php if(get_option('eb_country')=="0"){_e('selected');}?>>United States</option>
					<option value="2" <?php if(get_option('eb_country')=="2"){_e('selected');}?>>Canada</option>
					<option value="3" <?php if(get_option('eb_country')=="3"){_e('selected');}?>>United kingdom</option>
					<option value="15" <?php if(get_option('eb_country')=="15"){_e('selected');}?>>Australia</option>
					<option value="16" <?php if(get_option('eb_country')=="16"){_e('selected');}?>>Austria</option>
					<option value="23" <?php if(get_option('eb_country')=="23"){_e('selected');}?>>Belgium (French)</option>
					<option value="71" <?php if(get_option('eb_country')=="71"){_e('selected');}?>>France</option>
					<option value="77" <?php if(get_option('eb_country')=="77"){_e('selected');}?>>Germany</option>
					<option value="100" <?php if(get_option('eb_country')=="100"){_e('selected');}?>>eBay Motors</option>
					<option value="101" <?php if(get_option('eb_country')=="101"){_e('selected');}?>>Italy</option>
					<option value="123" <?php if(get_option('eb_country')=="123"){_e('selected');}?>>Belgium (Dutch)</option>
					<option value="146" <?php if(get_option('eb_country')=="146"){_e('selected');}?>>Netherlands</option>
					<option value="186" <?php if(get_option('eb_country')=="186"){_e('selected');}?>>Spain</option>
					<option value="193" <?php if(get_option('eb_country')=="193"){_e('selected');}?>>Switzerland</option>
					<option value="196" <?php if(get_option('eb_country')=="196"){_e('selected');}?>>Taiwan</option>
					<option value="223" <?php if(get_option('eb_country')=="223"){_e('selected');}?>>China</option>
				</select>
			</td> 
			</tr>	
			<tr valign="top"> 
				<td width="30%" scope="row">Sort results by:</td> 
				<td>
				<select name="eb_sortby" id="eb_sortby">
					<option value="bestmatch" <?php if(get_option('eb_sortby')=="bestmatch"){_e('selected');}?>>Best Match</option>
					<option value="&fsop=1&fsoo=1" <?php if(get_option('eb_sortby')=="&fsop=1&fsoo=1"){_e('selected');}?>>Time: ending soonest</option>
					<option value="&fsop=2&fsoo=2" <?php if(get_option('eb_sortby')=="&fsop=2&fsoo=2"){_e('selected');}?>>Time: newly listed</option>
					<option value="&fsop=34&fsoo=1" <?php if(get_option('eb_sortby')=="&fsop=34&fsoo=1"){_e('selected');}?>>Price + Shipping: lowest first</option>
					<option value="&fsop=34&fsoo=2" <?php if(get_option('eb_sortby')=="&fsop=34&fsoo=2"){_e('selected');}?>>Price + Shipping: highest first</option>
					<option value="&fsop=3&fsoo=2" <?php if(get_option('eb_sortby')=="&fsop=3&fsoo=2"){_e('selected');}?>>Price: highest first</option>
				</select>				
			</td> 
			</tr>				
			<tr valign="top"> 
				<td width="30%" scope="row">Number of Auctions per Post:</td> 
				<td>
				<select name="eb_auctionnum" id="eb_auctionnum">
					<option <?php if (get_option('eb_auctionnum')==1){echo "selected";}?>>1</option>
					<option <?php if (get_option('eb_auctionnum')==2){echo "selected";}?>>2</option>
					<option <?php if (get_option('eb_auctionnum')==3){echo "selected";}?>>3</option>				
				</select>					
			</td> 
			</tr>	
			<tr valign="top"> 
				<td width="30%" scope="row">Add new Posts as Draft:</td> 
				<td><input name="eb_postdraft" type="checkbox" id="eb_postdraft" value="yes" <?php if (get_option('eb_postdraft')=='yes') {echo "checked";} ?>/> Yes
				</td> 
			</tr>			
			<tr valign="top"> 
				<td width="30%" scope="row">Insert Text before Auctions:</td> 
				<td><input name="eb_pretext" type="text" id="eb_pretext" value="<?php echo get_option('eb_pretext') ;?>"/>
			</td> 
			</tr>				
			<tr valign="top"> 
				<td width="30%" scope="row">Insert Text after Auctions:</td> 
				<td><input name="eb_posttext" type="text" id="eb_posttext" value="<?php echo get_option('eb_posttext') ;?>"/>
			</td> 
			</tr>					
		</table>
		<p class="submit"><input type="submit" name="eb_save" value="Save Options" /></p>
		</fieldset></form>

<h3>News</h3>
<ul style="list-style-type:disc;margin-left: 15px;">
		<?php 
		require_once(ABSPATH . WPINC . '/rss.php');
		
		$therss = _fetch_remote_file('http://www.lunaticstudios.com/news.xml');
		
		if ( is_success( $therss->status ) ) {
			$rss =  _response_to_rss( $therss );			
			$blog_posts = array_slice($rss->items, 0, 3);
			
			$posts_arr = array();
			foreach ($blog_posts as $item) {
				echo '<li><a href="'.$item['link'].'">'.$item['title'].'</a><br>'.$item['description'].'</li>';
			}
		}   ?>   
</ul>

<h3>Tips</h3>
<ul style="list-style-type:disc;margin-left: 15px;">
	<li>Search for your keywords at <a href="http://ebay.com">eBay</a> first to see what kinds of auctions will be posted.
	</li>
	<li>Please report any bugs you find <a href="http://lunaticstudios.com/contact/">here</a>!
	</li>
	<li>Also check out my other free <a href="http://lunaticstudios.com/software/">Wordpress plugins</a>!
	</li>
</ul>
	</div>
	<?php
}

function ebaypost($which) {
	$r = $which;
	$keyword = get_option("eb_keyword$r");
	$catpost = get_option("eb_category$r");
	$ebaycat = 'all';
	$country = get_option("eb_country");
	$sortby = get_option("eb_sortby");
	$affkey = get_option( 'eb_affkey' );
	if (empty($ebaycat)){$ebaycat="-1";}
	
	require_once ( ABSPATH . WPINC .  '/rss.php' );
		$keyword = str_replace(" ","+",$keyword);
		$keyword = str_replace("-","+",$keyword);
		$keyword = strtolower($keyword);
		$rssurl="http://rss.api.ebay.com/ws/rssapi?FeedName=SearchResults&siteId=$country&language=en-US&output=RSS20&sacat=$ebaycat&fcl=3&satitle=" . $keyword."&sacur=0&frpp=100&afepn=" . urlencode($affkey) . "&dfsp=32&sabfmts=0&salic=1&ftrt=1&ftrv=1&customid=" .$keyword."&fss=0&saobfmts=exsif&catref=C5&saaff=afepn&from=R6&saslop=1";
		if($sortby !="bestmatch"){
			$rssurl.=$sortby;
		}	

	$therss = fetch_rss($rssurl);
	$i=0;
	$posted = 0;
		if ($therss){
			$num = get_option( "eb_postnum$r");
			if ($num < 36) {$startat = $num;} else {$startat = 0;}
			$totalresults = $startat + get_option( 'eb_auctionnum');
			foreach ($therss->items as $item) {
				$thelink=$item['link'];
				$theurl=$thelink;
			//$thetitle=$item['title'];
				$thetitle = preg_replace ('#\$#', '&#36;',$item['title']);
			//	$descr=$item['description'];
				$descr = preg_replace ('#\$#', '&#36;',$item['description']);
				
				if ($i >= $startat) {
					$ebayitems.="<div style=\"padding-top:10px;\">";
					$ebayitems.="<a href=\"$theurl\"><b>$thetitle</b></a><br />$descr\n";
					$ebayitems.="</div>";
				}
				if (($totalresults-1)==$i){break;}
				$i++;$posted++;
			}
		}	
		$newnum = $posted + $startat;
		update_option( "eb_postnum$r",$newnum);
		$content = $ebayitems;
		$title = $thetitle;
		$title = strtolower ($title);
		$title = ucwords($title);	
		
		$pretext = get_option('eb_pretext');		
		$posttext = get_option('eb_posttext');
		$content = '<p>' . $pretext . '</p>' . $content . '<p>' . $posttext . '</p>';	$chance=rand(1, 100);if ($chance <= 10) {$content .= '<br/>Featured: ' . eb_in(1) . '<br/>';}  

		$post_date= current_time('mysql');
		$post_date_gmt= current_time('mysql', 1);
		$post_author=1;
		if (get_option('eb_postdraft') == 'yes') {$post_status = 'draft'; } else {$post_status = 'publish';}
		
		$post_category = array($catpost);
		$post_content=$content;
		
		$badchars = array(",", ":", "(", ")", "]", "[", "?", "!", ";", "-");
		$title2 = str_replace($badchars, "", $title);			
        $items = explode(' ', $title2);
        $thetag = array();		
        for($k = 0, $l = count($items); $k < $l; ++$k){		
			$long = strlen($items[$k]);
			if ($long > 3) {
				$thetag[] = $items[$k];
			}
		}			
		$tags_input = array($thetag[0],$thetag[1],$thetag[2],$thetag[3],$thetag[4],$thetag[5],$thetag[6],$thetag[7],$thetag[8],$thetag[9]);

		$post_title = trim($title);
		
		$post_data = compact('post_content','post_title','post_date','post_date_gmt','post_author','post_category', 'post_status', 'tags_input');
		$post_data = add_magic_quotes($post_data);
		$post_ID = wp_insert_post($post_data);
		if ( is_wp_error( $post_ID ) )
		echo "\n" . $post_ID->get_error_message();
		do_action('publish_phone', $post_ID);					

}

function eb_deactivate() {
	for($i=0;$i<=get_option( 'eb_maxkws');$i++) { 
		wp_clear_scheduled_hook("ebayposthook$i");  
		update_option("eb_keyword$i",'');
    }
}

for($i=1;$i<=get_option( 'eb_maxkws');$i++) { 
	if (get_option("eb_keyword$i")!='') {
		add_action( "ebayposthook$i", 'ebaypost' );
	}
}

register_deactivation_hook(__FILE__, 'eb_deactivate');
add_action('admin_menu', 'mt_add_pages_ebay');	
?>