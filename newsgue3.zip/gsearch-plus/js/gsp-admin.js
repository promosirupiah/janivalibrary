(function( $ ) {

$(document).ready(function() {
		
	/** set color picker */
	$('.wp-color-picker-field').wpColorPicker();

}); // document ready end

}(jQuery));