<?php
/*
Plugin Name: Affomatic
Plugin URI: http://www.affomatic.com/
Description: Ebay for wordpress.  Yeah!  You have no right to sell or redistribute this plugin but you may use it for personal use on your sites all day long.
Version: 2
Author: Affomatic.com
Author URI: http://www.affomatic.com/
*/

//COPYRIGHT Affomatic.com.  You have no right to sell or redistribute this plugin but you may use it for personal use on your sites all day long.
function AffomaticEbay ($text){
		$campid=get_option("campid");
		if (strlen($campid < 2)){$campid="5335808953";}
		
		$totalresults=get_option("totalresults");
		if ($totalresults > 100 || $totalresults < 1 || empty($totalresults)){$totalresults=100;}

		$country=get_option("country");
		if (empty($country)){$country=0;}
		
		$category=get_option("category");
		if (empty($category)){$category="-1";}
		
		$sortby=get_option("sortby");
		if (empty($sortby)){$sortby="bestmatch";}

	$thetag=BetweenTags($text,"AffomaticEbay");

	if ($thetag){
		require_once ( ABSPATH . WPINC .  '/rss.php' );
		$SafeQuery = str_replace(" ","+",$thetag);
		$SafeQuery = str_replace("-","+",$SafeQuery);
		$SafeQuery = strtolower($SafeQuery);
		$thelink="http://rss.api.ebay.com/ws/rssapi?FeedName=SearchResults";
		$thelink.="&siteId=$country";
		$thelink.="&language=en-US";
		$thelink.="&output=RSS20";
		$thelink.="&sacat=$category";
		$thelink.="&fcl=3";
		$thelink.="&satitle=" . urlencode ($SafeQuery);
		$thelink.="&sacur=0";
		$thelink.="&frpp=100";
		$thelink.="&afepn=" . urlencode($campaignid) . "&dfsp=32&sabfmts=0&salic=1&ftrt=1&ftrv=1";
		$thelink.="&customid=" .urlencode($thetag);
		$thelink.="&fss=0&saobfmts=exsif&catref=C5&saaff=afepn&from=R6&saslop=1";
		if($sortby !="bestmatch"){
		$thelink.=$sortby;
		}
		
		$resp = fetch_rss($thelink);

	$i=0;
		if ($resp){
		foreach ($resp->items as $item) {
		$afflink=$item['link'];
		$affurl=$afflink;
		$afftitle=$item['title'];
        $afftitle = preg_replace ('#\$#', '&#36;',$item['title']);//kill the dollar
		$affdesc=$item['description'];
        $affdesc = preg_replace ('#\$#', '&#36;',$item['description']);//kill the dollar
		
		$ebaystuff.="<div style=\"float:left;width:49%;margin-right:1%;\">";
		$ebaystuff.="<a href=\"$affurl\">$afftitle</a><br />$affdesc\n";
		$ebaystuff.="</div>";
		if(($i % 2)==1){$ebaystuff.="<div style=\"border-top:1px solid #f1f1f1;margin-bottom:10px;clear:both\"></div>";}
		if (($totalresults-1)==$i){break;}
		$i++;
		}
		$ebaystuff.="<div style=\"border-top:1px solid #f1f1f1;margin-bottom:10px;clear:both\"></div>";//do just in case 1 left over
		}

	$newcontent= preg_replace("/\[AffomaticEbay\](.*?)\[\/AffomaticEbay\]/",$ebaystuff,$text);
	}else{
	$newcontent=$text;
	}
	
return $newcontent;

}

function BetweenTags($string, $tagname)
{
    $pattern = "/\[$tagname\](.*?)\[\/$tagname\]/";
    preg_match($pattern, $string, $matches);
    return $matches[1];
}

function my_plugin_menuAffomaticEbay() {
  add_options_page('AffomaticEbay', 'AffomaticEbay', 8, __FILE__, 'my_plugin_optionsAffomaticEbay');
}






function my_plugin_optionsAffomaticEbay() {
$go="http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"] . "&action=update";

?>

<div class="wrap">
<h2>AffomaticEbay - Free Ebay Wordpress Plugin</h2>

<form method="post" action="<?php echo $go;?>">
<?php wp_nonce_field('update-options');




if($_REQUEST['action']=="update"){
        //Get form data
        $campid = $_POST['campid'];
		if (strlen($campid < 2)){$campid="5335808953";}
        $totalresults = $_POST['totalresults'];
		if ($totalresults > 100 || $totalresults < 1 || empty($totalresults)){$totalresults=100;}
		$country=$_POST['country'];
		$category=$_POST['category'];
		$sortby=$_POST['sortby'];

        //Update plugin options
        update_option("campid", $campid);
        update_option("totalresults", $totalresults);
        update_option("country", $country);
        update_option("category", $category);
        update_option("sortby", $sortby);
		
		echo "<div id=\"message\" class=\"updated fade\"><p><strong>AffomaticEbay plugin options updated.</strong></p></div>";
}else{
		$campid=get_option("campid");
		if (strlen($campid < 2)){$campid="5335808953";}
		
		$totalresults=get_option("totalresults");
		if ($totalresults > 100 || $totalresults < 1 || empty($totalresults)){$totalresults=100;}
		
		$country=get_option("country");
		if (empty($country)){$country=0;}
		
		$category=get_option("category");
		if (empty($category)){$category="all";}
		
		$sortby=get_option("sortby");
		if (empty($sortby)){$sortby="bestmatch";}
		
}
	
	



?>

<table class="form-table">

<tr valign="top">
<th scope="row">Ebay Campid (affiliateID)</th>
<td><input type="text" name="campid" id="campid" value="<?php echo $campid;?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Total Results To Return Per Page</th>
<td><input type="text" name="totalresults" value="<?php echo $totalresults;?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Choose Ebay Country</th>
<td>
<select name="country">
<option value="0" <?php if($country=="0"){_e('selected');}?>>United States</option>
<option value="2" <?php if($country=="2"){_e('selected');}?>>Canada</option>
<option value="3" <?php if($country=="3"){_e('selected');}?>>United kingdom</option>
<option value="15" <?php if($country=="15"){_e('selected');}?>>Australia</option>
<option value="16" <?php if($country=="16"){_e('selected');}?>>Austria</option>
<option value="23" <?php if($country=="23"){_e('selected');}?>>Belgium (French)</option>
<option value="71" <?php if($country=="71"){_e('selected');}?>>France</option>
<option value="77" <?php if($country=="77"){_e('selected');}?>>Germany</option>
<option value="100" <?php if($country=="100"){_e('selected');}?>>eBay Motors</option>
<option value="101" <?php if($country=="101"){_e('selected');}?>>Italy</option>
<option value="123" <?php if($country=="123"){_e('selected');}?>>Belgium (Dutch)</option>
<option value="146" <?php if($country=="146"){_e('selected');}?>>Netherlands</option>
<option value="186" <?php if($country=="186"){_e('selected');}?>>Spain</option>
<option value="193" <?php if($country=="193"){_e('selected');}?>>Switzerland</option>
<option value="196" <?php if($country=="196"){_e('selected');}?>>Taiwan</option>
<option value="223" <?php if($country=="223"){_e('selected');}?>>China</option>
</select>
</td>
</tr>



<tr valign="top">
<th scope="row">Choose Ebay Category</th>
<td>
<select name="category">
<option value="all" <?php if($category=="all"){_e('selected');}?>>All Categories</option>
<option value="20081" <?php if($category=="20081"){_e('selected');}?>>Antiques</option>
<option value="550" <?php if($category=="550"){_e('selected');}?>>Art</option>
<option value="2984" <?php if($category=="2984"){_e('selected');}?>>Baby</option>
<option value="267" <?php if($category=="267"){_e('selected');}?>>Books</option>
<option value="12576" <?php if($category=="12576"){_e('selected');}?>>Business &amp; Industrial</option>
<option value="625" <?php if($category=="625"){_e('selected');}?>>Cameras &amp; Photo</option>
<option value="15032" <?php if($category=="15032"){_e('selected');}?>>Cell Phones &amp; PDAs</option>
<option value="11450" <?php if($category=="11450"){_e('selected');}?>>Clothing, Shoes &amp; Accessories</option>
<option value="11116" <?php if($category=="11116"){_e('selected');}?>>Coins &amp; Paper Money</option>
<option value="1" <?php if($category=="1"){_e('selected');}?>>Collectibles</option>
<option value="58058" <?php if($category=="58058"){_e('selected');}?>>Computers &amp; Networking</option>
<option value="14339" <?php if($category=="14339"){_e('selected');}?>>Crafts</option>
<option value="237" <?php if($category=="237"){_e('selected');}?>>Dolls &amp; Bears</option>
<option value="11232" <?php if($category=="11232"){_e('selected');}?>>DVDs &amp; Movies</option>
<option value="6000" <?php if($category=="6000"){_e('selected');}?>>eBay Motors</option>
<option value="293" <?php if($category=="293"){_e('selected');}?>>Electronics</option>
<option value="45100" <?php if($category=="45100"){_e('selected');}?>>Entertainment Memorabilia</option>
<option value="31411" <?php if($category=="31411"){_e('selected');}?>>Gift Certificates</option>
<option value="26395" <?php if($category=="26395"){_e('selected');}?>>Health &amp; Beauty</option>
<option value="11700" <?php if($category=="11700"){_e('selected');}?>>Home &amp; Garden</option>
<option value="281" <?php if($category=="281"){_e('selected');}?>>Jewelry &amp; Watches</option>
<option value="11233" <?php if($category=="11233"){_e('selected');}?>>Music</option>
<option value="619" <?php if($category=="619"){_e('selected');}?>>Musical Instruments</option>
<option value="870" <?php if($category=="870"){_e('selected');}?>>Pottery &amp; Glass</option>
<option value="10542" <?php if($category=="10542"){_e('selected');}?>>Real Estate</option>
<option value="316" <?php if($category=="316"){_e('selected');}?>>Specialty Services</option>
<option value="382" <?php if($category=="382"){_e('selected');}?>>Sporting Goods</option>
<option value="64482" <?php if($category=="64482"){_e('selected');}?>>Sports Mem, Cards &amp; Fan Shop</option>
<option value="260" <?php if($category=="260"){_e('selected');}?>>Stamps</option>
<option value="1305" <?php if($category=="1305"){_e('selected');}?>>Tickets</option>
<option value="220" <?php if($category=="220"){_e('selected');}?>>Toys &amp; Hobbies</option>
<option value="3252" <?php if($category=="3252"){_e('selected');}?>>Travel</option>
<option value="1249 <?php if($category=="1249"){_e('selected');}?>>Video Games</option>
<option value="99" <?php if($category=="99"){_e('selected');}?>>Everything Else</option>
</select>
</td>
</tr>

<tr valign="top">
<th scope="row">Sort Results by</th>
<td>
<select name="sortby">
<option value="bestmatch" <?php if($sortby=="bestmatch"){_e('selected');}?>>Best Match</option>
<option value="&fsop=1&fsoo=1" <?php if($sortby=="&fsop=1&fsoo=1"){_e('selected');}?>>Time: ending soonest</option>
<option value="&fsop=2&fsoo=2" <?php if($sortby=="&fsop=2&fsoo=2"){_e('selected');}?>>Time: newly listed</option>
<option value="&fsop=34&fsoo=1" <?php if($sortby=="&fsop=34&fsoo=1"){_e('selected');}?>>Price + Shipping: lowest first</option>
<option value="&fsop=34&fsoo=2" <?php if($sortby=="&fsop=34&fsoo=2"){_e('selected');}?>>Price + Shipping: highest first</option>
<option value="&fsop=3&fsoo=2" <?php if($sortby=="&fsop=3&fsoo=2"){_e('selected');}?>>Price: highest first</option>

</select>
</td>
</tr>


<td>
<p class="submit">
<input type="submit" name="Submit" value="Update AffomaticEbay Options &raquo;" />
</p>
</td>

</table>
</form>
</div>
<?php
}


add_filter ('the_content', 'AffomaticEbay');
add_action('admin_menu', 'my_plugin_menuAffomaticEbay');

?>