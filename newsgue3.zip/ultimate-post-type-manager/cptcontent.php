<?php

function xydac_cpt_content()
{
	
}



?>