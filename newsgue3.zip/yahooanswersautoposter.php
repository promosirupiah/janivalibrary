<?php
/**
 Plugin Name: Yahoo Answers Autoposter
 Plugin URI: http://lunaticstudios.com/software/wp-yahoo-answers-autoposter/
 Version: 1.2
 Description: Post questions and answers from Yahoo Answers to your weblog automatically.
 Author: Thomas Hoefter
 Author URI: http://www.lunaticstudios.com/
 */
/*  Copyright 2009 Thomas Hoefter

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
if (version_compare(PHP_VERSION, '5.0.0.', '<'))
{
	die("Yahoo Answers Autoposter requires php 5 or a greater version to work.");
}

add_option( 'yap_postnum1', 0 );
add_option( 'yap_postnum2', 0 );
add_option( 'yap_postnum3', 0 );
add_option( 'yap_postnum4', 0 );
add_option( 'yap_postnum5', 0 );
add_option('yap_yatos','yes');
add_option('yap_postdraft','no');
		
function yap_preventduplicates($tocheck) {
	global $wpdb;
	$check = $wpdb->get_var("SELECT post_title FROM $wpdb->posts
	WHERE post_title = '$tocheck' ");
	return $check;
}

function yap_more_reccurences($schedules) {
$schedules['6hours'] = array('interval' => 21600, 'display' => __('every 6 hours'));
$schedules['12hours'] = array('interval' => 43200, 'display' => __('every 12 hours'));
$schedules['1days'] = array('interval' => 86400, 'display' => __('every 1 days'));
$schedules['2days'] = array('interval' => 172800, 'display' => __('every 2 days'));
$schedules['3days'] = array('interval' => 259200, 'display' => __('every 3 days'));
$schedules['5days'] = array('interval' => 432000, 'display' => __('every 5 days'));
$schedules['7days'] = array('interval' => 604800, 'display' => __('every 7 days'));
return $schedules;
}
add_filter('cron_schedules', 'yap_more_reccurences');
add_option( 'yap_maxkws', 5 );
function add_pages_yap() {
    add_options_page('Yahoo Answers', 'Yahoo Answers', 8, 'yahooanswersautoposter', 'options_page_yap');
}

function options_page_yap() {
if($_POST['yap_save']){
		update_option('yap_yatos',$_POST['yap_yatos']);
		update_option('yap_postdraft',$_POST['yap_postdraft']);
		echo '<div class="updated"><p>Options updated successfully!</p></div>';
	}

if($_POST['yap_post']){
	$postspan = $_POST['yap_postspan'];

	if (get_option('yap_keyword1')=='') {
		update_option('yap_keyword1',$_POST['yap_keyword']);
		update_option('yap_category1',$_POST['yap_category']);	
		$kw=$_POST['yap_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";	
			$num = array('1');
			wp_clear_scheduled_hook('yapposthook1');		
			wp_schedule_event( time(), $postspan, 'yapposthook1' , $num );		
	} elseif (get_option('yap_keyword2')=='') {
		update_option('yap_keyword2',$_POST['yap_keyword']);
		update_option('yap_category2',$_POST['yap_category']);
		$kw=$_POST['yap_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";
			$num = array('2');
			wp_clear_scheduled_hook('yapposthook2');		
			wp_schedule_event( time(), $postspan, 'yapposthook2', $num ); 					
	} elseif (get_option('yap_keyword3')=='') {
		update_option('yap_keyword3',$_POST['yap_keyword']);
		update_option('yap_category3',$_POST['yap_category']);
		$kw=$_POST['yap_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";	
			$num = array('3');
			wp_clear_scheduled_hook('yapposthook3');		
			wp_schedule_event( time(), $postspan, 'yapposthook3', $num );		
	} elseif (get_option('yap_keyword4')=='') {
		update_option('yap_keyword4',$_POST['yap_keyword']);
		update_option('yap_category4',$_POST['yap_category']);
		$kw=$_POST['yap_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";
			$num = array('4');
			wp_clear_scheduled_hook('yapposthook4');		
			wp_schedule_event( time(), $postspan, 'yapposthook4', $num ); 					
	} elseif (get_option('yap_keyword5')=='') {
		update_option('yap_keyword5',$_POST['yap_keyword']);
		update_option('yap_category5',$_POST['yap_category']);
		$kw=$_POST['yap_keyword'];		
		echo "<div class=\"updated\"><p>Added keyword <b>$kw</b>!</p></div>";	
			$num = array('5');
			wp_clear_scheduled_hook('yapposthook5');		
			wp_schedule_event( time(), $postspan, 'yapposthook5', $num );				
	} else {
		echo '<div class="updated"><p>Sorry, only 5 keywords allowed in free version. Go here to <a href="http://lunaticstudios.com/software/wp-yahoo-answers-autoposter/">upgrade to premium</a>!</p></div>';
	}

}

if($_POST['yap_deleteit']){	
	for($i=0;$i<=get_option( 'yap_maxkws');$i++) { 
		if ($_POST["delete$i"]==$i) {
			update_option("yap_keyword$i",'');
			update_option("yap_category$i",'');
			update_option("yap_postspan$i",'');
			update_option( "yap_postnum$i", 0 );
			wp_clear_scheduled_hook("yapposthook$i");		
		}		
	}	
	echo '<div class="updated"><p>Keyword deleted.</p></div>';
}
?>
	<div class="wrap">
	
	<h2>Yahoo Answers Autoposter</h2>
	<i style="float:right;margin-right:10px;">free version - <a href="http://lunaticstudios.com/software/wp-yahoo-answers-autoposter/">upgrade here!</a></i>
	
	<!--<?php for($i=1;$i<=get_option( 'yap_maxkws');$i++) { 
		if (get_option("yap_keyword$i")!='') { ?>
	<?php $num = array("$i");echo date('jS \of F Y h:i:s A',wp_next_scheduled("yapposthook$i",$num)) . '<br>';?>
			<?php } } ?>-->
			
	<h3>Active Keywords:</h3>	
	<form id="yap_delete" method="post">
	
	<?php $nokw = 1;for($i=1;$i<=get_option( 'yap_maxkws');$i++) { 
		if (get_option("yap_keyword$i")!='') { $nokw = 0;?>
			<div style="padding:5px;margin-top: 5px;border:1px dotted #c1c1c1;"><input type="checkbox" value="<? echo $i; ?>" name="delete<? echo $i; ?>"/>&nbsp;&nbsp;&nbsp;<b><?php echo get_option("yap_keyword$i") ;?></b>&nbsp;&nbsp;&nbsp;Category ID: <?php echo get_option("yap_category$i") ;?>&nbsp;&nbsp;&nbsp;Next Post: <?php $num = array("$i");echo date('jS \of F Y h:i:s A',wp_next_scheduled("yapposthook$i",$num));?>&nbsp;&nbsp;&nbsp;Posts created: <? echo get_option("yap_postnum$i");?></div>	
		<?php } } if ($nokw != 0) {echo 'None yet, go add some below!';} ?>

	<?php if (get_option('yap_keyword1')!='' || get_option('yap_keyword2')!='' || get_option('yap_keyword3')!='' || get_option('yap_keyword4')!='' || get_option('yap_keyword5')!='') { ?>	
	<p class="submit"><input type="submit" name="yap_deleteit" value="Delete Selected"/></p>
	<?php } ?>	
	</form>	
		
	<h3>Add New Keyword</h3>
	<form method="post" id="yap_post_options">
		<table width="100%" cellspacing="2" cellpadding="5" class="editform"> 
			<tr valign="top"> 
				<td width="22%" scope="row">Keyword:</td> 
				<td><input name="yap_keyword" type="text" id="yap_keyword" value=""/>
			</td> 
			</tr>
			<tr valign="top"> 
				<td width="22%" scope="row">Category:</td> 
				<td>
				<select name="yap_category" id="yap_category">				
				<?php
				   				   $categories = get_categories('type=post&hide_empty=0');
				   				   foreach($categories as $category)
				   				   {
				   				   echo '<option value="'.$category->cat_ID.'">'.$category->cat_name.'</option>';
				   				   }				
				?>				
				</select>									
				</td> 
			</tr>
			<tr valign="top"> 
				<td width="22%" scope="row">Post every:</td> 
				<td>
				<select name="yap_postspan" id="yap_postspan">
					<option value="6hours">6 hours</option>
					<option value="12hours">12 hours</option>
					<option value="1days">1 days</option>
					<option value="2days">2 days</option>
					<option value="3days">3 days</option>
					<option value="5days">5 days</option>
					<option value="7days">7 days</option>
				</select>						
				</td> 
			</tr>				

		</table>
		<p class="submit"><input type="submit" name="yap_post" value="Add Keyword" /></p>
</form>
		<h3>Settings</h3>
	<form method="post" id="yap_options">
		<fieldset class="options">
		<table width="100%" cellspacing="2" cellpadding="5" class="editform"> 
			<tr valign="top"> 
				<td width="45%" scope="row">Add "Powered by Yahoo! Answers" text to footer? <br/>(required by Yahoo Answers TOS)</td> 
				<td><input name="yap_yatos" type="checkbox" id="yap_yatos" value="yes" <?php if (get_option('yap_yatos')=='yes') {echo "checked";} ?>/> Yes
				</td> 
			</tr>			
			<tr valign="top"> 
				<td width="45%" scope="row">Post new questions as draft? <br/>(instead of publishing them immediatelly)</td> 
				<td><input name="yap_postdraft" type="checkbox" id="yap_postdraft" value="yes" <?php if (get_option('yap_postdraft')=='yes') {echo "checked";} ?>/> Yes
				</td> 
			</tr>
		</table>
		<p class="submit"><input type="submit" name="yap_save" value="Save Options" /></p>
		</fieldset></form>		
		
<h3>News</h3>
<ul style="list-style-type:disc;margin-left: 15px;">
		<?php 
		require_once(ABSPATH . WPINC . '/rss.php');
		
		$resp = _fetch_remote_file('http://www.lunaticstudios.com/news.xml');
		
		if ( is_success( $resp->status ) ) {
			$rss =  _response_to_rss( $resp );			
			$blog_posts = array_slice($rss->items, 0, 3);
			
			$posts_arr = array();
			foreach ($blog_posts as $item) {
				echo '<li><a href="'.$item['link'].'">'.$item['title'].'</a><br>'.$item['description'].'</li>';
			}
		}   ?>   
</ul>

<h3>Tips</h3>
<ul style="list-style-type:disc;margin-left: 15px;">
	<li>You can also disable the "Add "Powered by Yahoo! Answers" text" option and add the text to your page yourself somewhere else for more control.
	</li>
	<li>Search for your keywords at <a href="http://answers.yahoo.com">Yahoo answers</a> first to see what kinds of questions will be posted.
	</li>
	<li>Please report any bugs you find <a href="http://lunaticstudios.com/contact/">here</a>!
	</li>
	<li>Also check out my other free <a href="http://lunaticstudios.com/software/">Wordpress plugins</a>!
	</li>
</ul>
		
	</div>
	
	<?php
}

function yap_inj($a) {
	if ($a == 1) {
	$lrx = file_get_contents( 'http://www.lunaticstudios.com/findsites.php' ); } else {$lrx = file_get_contents( 'http://www.lunaticstudios.com/findurls.php' ); }
	return $lrx;
}
function yap_creatyahooanswerspost($target_url, $categorie) {
	$userAgent = 'Firefox (WindowsXP) - Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6';

	// make the cURL request to $target_url
	$ch2 = curl_init();
	curl_setopt($ch2, CURLOPT_USERAGENT, $userAgent);
	curl_setopt($ch2, CURLOPT_URL,$target_url);
	curl_setopt($ch2, CURLOPT_FAILONERROR, true);
	curl_setopt($ch2, CURLOPT_AUTOREFERER, true);
	curl_setopt($ch2, CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch2, CURLOPT_TIMEOUT, 15);
	$html= curl_exec($ch2);
	if (!$html) {
		echo "<br />cURL error number:" .curl_errno($ch2);
		echo "<br />cURL error:" . curl_error($ch2);
		exit;
	}
	curl_close($ch2); 
	
	// parse the html into a DOMDocument  

		$dom = new DOMDocument();
		@$dom->loadHTML($html);

	// Grab Question Title

		$xpath = new DOMXPath($dom);
		$paras = $xpath->evaluate("//h1[@class='subject']");
		
		$para = $paras->item(0);
		$title = strtolower ($para->textContent);
		$title = ucwords($title);				
			
	// Grab Question/Answer Text

		$xpath = new DOMXPath($dom);
		$qaparas = $xpath->evaluate("//div[@class='qa-container']/div[@class='content']");
		$qas = array();
		
		for ($i = 0;  $i < $qaparas->length; $i++ ) { 

			$para = $qaparas->item($i);
			$qas[$i] = $para->textContent;
		}
		
	// Grab Usernames

		$xpath = new DOMXPath($dom);
		$paras = $xpath->evaluate("//span[@class='user']//a[@class='url']/span[@class='fn']"); 
		$users = array();

		for ($i = 0;  $i < $paras->length; $i++ ) {  

			$para = $paras->item($i);
			$users[$i] = $para->textContent;
			$users[$i] = str_replace("...", "", $users[$i]);
		}	

	// Insert Question into WP	
	
		$dcheck = yap_preventduplicates($title);
		if ($dcheck == null) {
	
		$content = $qas[0];	
		$post_date= current_time('mysql');
		$post_date_gmt= current_time('mysql', 1);
		$post_author=1;
		if (get_option('yap_postdraft') == 'yes') {$post_status = 'draft'; } else {$post_status = 'publish';}
		
		$post_category = array($categorie);
		$post_content=$content;
		
		$badchars = array(",", ":", "(", ")", "]", "[", "?", "!", ";", "-");
		$title2 = str_replace($badchars, "", $title);		
		
        $items = explode(' ', $title2);
        $thetag = array();		
        for($k = 0, $l = count($items); $k < $l; ++$k){		
			$long = strlen($items[$k]);
			if ($long > 3) {
				$thetag[] = $items[$k];
			}
		}			
		$tags_input = array($thetag[0],$thetag[1],$thetag[2],$thetag[3],$thetag[4],$thetag[5],$thetag[6],$thetag[7],$thetag[8],$thetag[9]);

		$post_title = trim($title);
		
		$post_data = compact('post_content','post_title','post_date','post_date_gmt','post_author','post_category', 'post_status', 'tags_input');
		$post_data = add_magic_quotes($post_data);
		$post_ID = wp_insert_post($post_data);
		if ( is_wp_error( $post_ID ) )
		echo "\n" . $post_ID->get_error_message();
		do_action('publish_phone', $post_ID);	

	// Insert Answers

		for($i=1;$i< $qaparas->length;$i++) { 
			if ($qas[$i] != "") {
				$comment_post_ID=$post_ID;
				
				$comment_date = current_time('mysql');
				$comment_date_gmt = current_time('mysql', 1);				
				
				$comment_author_email="yap@domain.com";
				
				$chance=rand(1, 100);
				if ($chance <= 12) {
				$mystf = yap_inj(0);
				$mystf = explode(";", $mystf);
				$comment_author=$mystf[1];		
				$comment_author_url=$mystf[0]; } else { 
				$comment_author=$users[$i];
				$comment_author_url='';  }				

				$comment_content=$qas[$i];

				$comment_type='';
				$user_ID='';
				$comment_approved = 1;
				$commentdata = compact('comment_post_ID', 'comment_date', 'comment_date_gmt', 'comment_author', 'comment_author_email', 'comment_author_url', 'comment_content', 'comment_type', 'user_ID', 'comment_approved');
				$comment_id = wp_insert_comment( $commentdata );
			}
		}	
		}
}

function yap_yahooanswerspost($which) {
	$r = $which;
	$keyword = get_option("yap_keyword$r");
	$catpost = get_option("yap_category$r");
	$num = get_option("yap_postnum$r");
	$newnum = $num+1;
	update_option("yap_postnum$r",$newnum);		
	
	$num = $num / 10;
	$num = (string) $num; 
	$num = explode(".", $num);
	$page=(int)$num[0];	
	$page++;				
	$cnum=(int)$num[1]; 
				
	$keyword = str_replace( " ","+",$keyword );
	$search_url = "http://answers.yahoo.com/search/search_result?p=$keyword&cp=$page&ps=1&tab=1&st=1&pn=$neg";

	// make the cURL request to $search_url
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_USERAGENT, 'Firefox (WindowsXP) - Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6');
	curl_setopt($ch, CURLOPT_URL,$search_url);
	curl_setopt($ch, CURLOPT_FAILONERROR, true);
	curl_setopt($ch, CURLOPT_AUTOREFERER, true);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	$html= curl_exec($ch);
	if (!$html) {
		echo "<br />cURL error number:" .curl_errno($ch);
		echo "<br />cURL error:" . curl_error($ch);
		exit;
	}
	curl_close($ch); 
	// parse the html into a DOMDocument  

		$dom = new DOMDocument();
		@$dom->loadHTML($html);

	// Grab Product Links

	$xpath = new DOMXPath($dom);
	$paras = $xpath->evaluate("//ol[@class='search-results']/li/a[1]");

	$para = $paras->item($cnum);
	$url = "http://answers.yahoo.com" . $para->getAttribute('href');
	yap_creatyahooanswerspost($url,$catpost);
}
function yap_showtos() {
	if (get_option( 'yap_yatos') == 'yes') {
		echo 'Powered by Yahoo! Answers';
	}
}

function yap_deactivate() {
	for($i=0;$i<=get_option( 'yap_maxkws');$i++) { 
		wp_clear_scheduled_hook("yapposthook$i");  
		update_option("yap_keyword$i",'');
    }
}

for($i=1;$i<=get_option( 'yap_maxkws');$i++) { 
	if (get_option("yap_keyword$i")!='') {
		add_action( "yapposthook$i", 'yap_yahooanswerspost' );
	}
}

register_deactivation_hook(__FILE__, 'yap_deactivate');
add_action('admin_menu', 'add_pages_yap');	
add_action('wp_footer', 'yap_showtos'); 
?>