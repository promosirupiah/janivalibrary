<?php if (!defined ('ABSPATH')) die ('No direct access allowed'); ?>

<p style="text-align: center; font-size: 0.9em; color: #555; border: 1px dotted #ccc; background-color: #efefef; padding: 2px; -moz-border-radius: 5px">
	<?php printf (__ ('This great search was powered by <a href="%s"><strong>Search Unleashed</strong></a>.', 'search-unleashed'), 'http://urbangiraffe.com/plugins/search-unleashed/'); ?>
	<br/>
	<?php _e ('Help to remove this message by getting the site owner to support this software.', 'search-unleashed'); ?>
</p>
