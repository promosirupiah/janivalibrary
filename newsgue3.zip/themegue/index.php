<?php get_header(); ?>

		<div id="main">
		<?php get_sidebar(); ?>
	   <div id="content">

	<?php if (have_posts()) : ?> 

		
	<?php while (have_posts()) : the_post(); ?>
				
			<div class="post" id="post-<?php the_ID(); ?>">
				<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry-meta">Posted in <span class="catposted"><?php the_category(', ') ?></span> <strong>|</strong> <span class="comments"> 	</span>		</div> 
				
				<div class="entry-content">
				<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "image";
google_ad_channel = "";
google_ui_features = "rc:6";
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
					<?php the_content('Read the rest of this entry &raquo;'); ?>
					<?php if ( function_exists('the_tags') ) { the_tags(); } ?>
					<?php edit_post_link('Edit','<p>','</p>'); ?> 
				</div>
		      <?php wp_link_pages();?>

	
  	</div>                  <!-- end the post div-->
	<?php endwhile; ?>

		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Previous Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Next Entries &raquo;') ?></div>
		</div>
		
	<?php else : ?>

		<h2 class="center">Not Found</h2>
		<p class="center">Sorry, but you are looking for something that isn't here.</p>
		<?php include (TEMPLATEPATH . "/searchform.php"); ?>
    <div class="navigation"><?php posts_nav_link();?></div>
	<?php endif; ?>


    </div> <!-- end content div-->
     	   	
<?php include (TEMPLATEPATH . "/sidebar-right.php"); ?>
  </div>                  <!-- end the main div-->
<?php get_footer(); ?>
