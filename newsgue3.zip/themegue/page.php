<?php get_header(); ?>

		<div id="main">
		<?php get_sidebar(); ?>
	   <div id="content">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
		<h3><?php the_title(); ?></h3>
			<div class="entry-text">
			<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "image";
google_ad_channel = "";
google_ui_features = "rc:6";
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
	
				<?php wp_link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
	
			</div>
		</div>
	  <?php endwhile; endif; ?>	<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
	  	  	<?php comments_template(); ?>


 </div> <!-- end content div-->
 
  	  
 
<?php include (TEMPLATEPATH . "/sidebar-right.php"); ?>
  </div>                  <!-- end the main div-->
<?php get_footer(); ?>
