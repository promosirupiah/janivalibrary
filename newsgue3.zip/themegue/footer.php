<div id="footer">
<div id="menu"><ul>
<?php if ( !function_exists('dynamic_sidebar')
|| !dynamic_sidebar(bottom) ) : ?>
			<?php endif; ?>
			</ul>
  <p>
    <?php bloginfo('name'); ?> 
  </p> 
  
</div><!-- end footer div -->

</div><!-- end wrapper div -->



</body>
</html>
