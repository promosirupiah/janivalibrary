<?php
if ( function_exists('register_sidebar') ){
register_sidebar(array('name'=>'Left'));register_sidebar(array('name'=>'Left1'));register_sidebar(array('name'=>'Left2'));
register_sidebar(array('name'=>'Right'));register_sidebar(array('name'=>'Right1'));register_sidebar(array('name'=>'Right2'));
register_sidebar(array('name'=>'top'));register_sidebar(array('name'=>'bottom'));}
?>
