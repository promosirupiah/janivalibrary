<?php
/*
Plugin Name: SEO SearchTerms Tagging 2
Plugin URI: http://exclusivewordpress.com/searchterms-tagging-2-plugin/
Description:  The purpose of this plugin is to strengthen our On Page SEO by adding new internal linking to the blog post using the most popular keywords used by search engine visitors to find the blog post from a search engine ( incoming search terms ).
Version: 1.3
Author: Purwedi Kurniawan
Author URI: http://exclusivewordpress.com
*/

/**
* default values for the plugin settings
**/
define('PK_MAX_SEARCH_TERMS','10');
define('PK_AUTO_ADD','1');
define('PK_AUTO_LINK','1');
define('PK_SHOW_COUNT','0');
define('PK_BEFORE_KEYWORD','<li>');
define('PK_AFTER_KEYWORD','</li>');
define('PK_BEFORE_LIST','<ul>');
define('PK_AFTER_LIST','</ul>');
define('PK_LIST_HEADER','<h4>Incoming search terms for the article:</h4>');
define('PK_AUTO_CLEANUP','0');
define('PK_AUTO_TAG','0');
define('PK_BADWORDS','http,sex,porn,gamble,xxx,nude');

/**
* plugin action & filter
**/
register_activation_hook(__file__,'pk_stt2_admin_activation');
register_deactivation_hook(__file__,'pk_stt2_admin_deactivation');

add_action('admin_menu','pk_stt2_admin_menu_hook');
add_action('admin_notices', 'pk_stt2_admin_notices');	
add_action('pk_stt2_admin_event_hook', 'pk_stt2_admin_scheduled_event'); 
add_filter('the_content','pk_stt2_admin_content_filter');
add_action('wp_head', 'pk_stt2_function_wp_head_hook');

/**
* keep compatibility with PHP 4
**/
if( !function_exists('str_ireplace') ){
  function str_ireplace($search,$replace,$subject){
    $token = chr(1);
    $haystack = strtolower($subject);
    $needle = strtolower($search);
    while (($pos=strpos($haystack,$needle))!==FALSE){
      $subject = substr_replace($subject,$token,$pos,strlen($search));
      $haystack = substr_replace($haystack,$token,$pos,strlen($search));
    }
    $subject = str_replace($token,$replace,$subject);
    return $subject;
  }
}

if ( !function_exists('htmlspecialchars_decode') ){
   function htmlspecialchars_decode($text){
       return strtr($text,array_flip(get_html_translation_table(HTML_SPECIALCHARS)));
   }
}

/**
* == ADMIN SECTION ==
* wordpress admin setting for searchterms tagging 2 plugin
**/

/**
 * install the plugin and set stt2 settings with the initial values
 * */ 
function pk_stt2_admin_activation(){
	pk_stt2_db_create_table();  
	$options = get_option('pk_stt2_settings');
	if (!empty($options)){
	  $max = ( array_key_exists('max',$options)) ? $options['max'] : PK_MAX_SEARCH_TERMS ;
	  $auto_add = ( array_key_exists('auto_add',$options)) ? $options['auto_add'] : $auto_add = PK_AUTO_ADD ;
	  $auto_link = ( array_key_exists('auto_link',$options)) ? $options['auto_link'] : $auto_link = PK_AUTO_LINK ;
      $show_count = ( array_key_exists('show_count',$options)) ? $options['show_count'] : PK_SHOW_COUNT ;	  
      $before_keyword = ( array_key_exists('before_keyword',$options) ) ? $options['before_keyword'] : PK_BEFORE_KEYWORD ;
      $after_keyword = ( array_key_exists('after_keyword',$options)) ? $options['after_keyword'] : PK_AFTER_KEYWORD ;
      $before_list = ( array_key_exists('before_list',$options)) ? $options['before_list'] : PK_BEFORE_LIST ;
      $after_list = ( array_key_exists('after_list',$options)) ? $options['after_list'] : PK_AFTER_LIST ;  
      $list_header = ( array_key_exists('list_header',$options)) ? $options['list_header'] : PK_LIST_HEADER ;
   } else {
      $max = PK_MAX_SEARCH_TERMS;
      $auto_add = PK_AUTO_ADD;
      $auto_link = PK_AUTO_LINK;
      $show_count = PK_SHOW_COUNT;
      $before_keyword = PK_BEFORE_KEYWORD;
      $after_keyword = PK_AFTER_KEYWORD;
      $before_list = PK_BEFORE_LIST;
      $after_list = PK_AFTER_LIST;	  
      $list_header = PK_LIST_HEADER;	  	  
   }  			
	
	$plugin_settings = array( 'max' => $max, 'auto_add' => $auto_add, 'auto_link' => $auto_link,
		'show_count' => $show_count, 'before_keyword' => $before_keyword, 'after_keyword' => $after_keyword,
		'before_list' => $before_list, 'after_list' => $after_list,'list_header' => $list_header );
	
	update_option( 'pk_stt2_settings', $plugin_settings );

	$auto_tag = ( get_option( 'pk_stt2_auto_tag' ) ) ? '1' : PK_AUTO_TAG;
	update_option ( 'pk_stt2_auto_tag', $auto_tag );
	
	$auto_cleanup = get_option( 'pk_stt2_auto_cleanup' );
	$auto_cleanup = ( $auto_cleanup ) ? $auto_cleanup : PK_AUTO_CLEANUP;
	update_option ( 'pk_stt2_auto_cleanup', $auto_cleanup );

	$badwords = get_option( 'pk_stt2_badwords' );
	$badwords = ( $badwords ) ? $badwords : PK_BADWORDS;
	update_option ( 'pk_stt2_badwords', $badwords );	
	
	if ( pk_stt2_db_is_previous_exist() && !pk_stt2_db_is_last_modified_column_exist() ){ 
		update_option('pk_stt2_enabled', '0'); 
	} else {
		update_option('pk_stt2_enabled', '1'); 
	};	
		
	if (!wp_next_scheduled('pk_stt2_admin_event_hook')) {
		wp_schedule_event( time(), 'daily', 'pk_stt2_admin_event_hook' );
	}
}
/**
* uninstall the plugin
**/
function pk_stt2_admin_deactivation(){
	remove_filter('the_content','pk_stt2_admin_content_filter');
	wp_clear_scheduled_hook('pk_stt2_admin_event_hook');
	remove_action('pk_stt2_admin_event_hook', 'pk_stt2_admin_scheduled_event');
}
/**
* scheduled event to delete unpopular searchterms
**/
function pk_stt2_admin_scheduled_event(){
	$days = get_option('pk_stt2_auto_cleanup');
	if ( 0 < $days ) {
		$result = pk_stt2_db_cleanup( $days );
		$last_clean_up = date('F j, Y, g:i A').', '.$result.' search terms deleted.';
		update_option('pk_stt2_last_clean_up',$last_clean_up);
	}
}
/*
* display admin notice to upgrade the database when previous format of database exist
*/
function pk_stt2_admin_notices() {
	if ( !pk_stt2_db_is_previous_exist() && pk_stt2_db_is_last_modified_column_exist() )
		return;
	update_option('pk_stt2_enabled', '0'); 
	echo "<div class='updated' style='background-color:#f66;'><p>" . sprintf(__('<a href="%s">SEO searchTerms Tagging 2</a> plugin need to upgrade their database before you can use it.'), "options-general.php?page=".basename(plugin_basename(__FILE__))). "</p></div>";
} 

/**
 * framework to handle the admin form
 * */ 
function pk_stt2_create_admin_menu(){	
	?>
	<style type="text/css">.stt2-table{ margin: 14px; } .stt2-table tr{ height: 28px; } .inside p{ margin: 14px; } .inside .frame { margin: 10px; } .inside .list li { font-size: 11px; }
	</style>
	<div class = "wrap">
		<div class="icon32" id="icon-options-general"><br></div>
		<h2>SEO SearchTerms Tagging 2</h2>
		<div><p>        If you think this plugin useful, please consider making a
			<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=10748556" target="_blank">donation</a> or write a review about it or at least give it a good rating on
			<a href="http://wordpress.org/extend/plugins/searchterms-tagging-2/" target="_blank">WordPress.org</a>.</p></div>
			<div style="float:right;margin-top:-60px;">
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
				<input type="hidden" name="cmd" value="_s-xclick">
				<input type="hidden" name="hosted_button_id" value="TZ24AM4WJPJ7J">
				<input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">
				<img alt="" border="0" src="https://www.paypal.com/id_ID/i/scr/pixel.gif" width="1" height="1">
				</form>
			</div>
	<?php
		/* intercept form submit */
		if (isset($_POST['submit']))
			pk_stt2_admin_update_options();
		elseif ( isset($_POST['upgrade']) )
			pk_stt2_admin_upgrade_db();
		elseif ( isset($_POST['delete']) || isset($_POST['delete_all']) )
			pk_stt2_admin_delete_searchterms();
			
		/* check whether we need to perform db upgrade or not */
		if ( !pk_stt2_db_is_previous_exist() && pk_stt2_db_is_last_modified_column_exist() )
			pk_stt2_admin_print_admin_page();
		else
			pk_stt2_admin_print_upgrade_form();	
	?>
	</div>
	<?php
}

/*
* delete unwanted searchterms from admin menu
*/
function pk_stt2_admin_delete_searchterms(){
	global $wpdb;
	if ( isset($_POST['delete_terms']) && !empty($_POST['delete_terms']) ){
		$msg = 'Search term containing "'.$_POST['delete_terms'].'"';
		$success = pk_stt2_db_delete_searchterms( $_POST['delete_terms'] );
	} elseif ( isset($_POST['delete_all']) ){
		$msg = 'All search terms';
		$success = pk_stt2_db_delete_searchterms( 'delete_all_terms' );	
	} else {
		?>
		<div id="message" class="updated fade">
			<p>        Please enter the search terms to be deleted, separate them with a comma.
			</p>
		</div>
		<?php	
	}
	if ( $success ){
		?>
		<div id="message" class="updated fade">
			<p>        <?php echo $msg; ?> have been deleted.
			</p>
		</div>
		<?php
				} else {
		?>
		<div id="message" class="updated fade">
			<p>        Failed to delete search terms.
			</p>
		</div>
		<?php
	}	
}
/*
* upgrade database into the most current format
*/
function pk_stt2_admin_upgrade_db(){ 
	 
	global $wpdb;
	if ( pk_stt2_db_is_previous_exist() ){ 
		pk_stt2_db_create_table();
		pk_stt2_db_upgrade();
	}	
	
	if ( !pk_stt2_db_is_last_modified_column_exist() ){
		pk_stt2_db_alter_table();
	}	
	
	if ( pk_stt2_db_get_number_of_searchterms() > 0 && pk_stt2_db_is_last_modified_column_exist() ){
		update_option('pk_stt2_enabled', '1'); 
		?>
		<div id="message" class="updated fade">
			<p>        SEO SearchTerms Tagging 2 database was succesfully upgraded.
			</p>
		</div>
		<?php 
			} else {
		?>
		<div id="message" class="updated fade" style='background-color:#f66;'>
			<p>        Failed to upgrade SEO SearchTerms Tagging 2 database!
			</p>
		</div>
		<p class="submit">
			<input type = "submit" name="upgrade" value="Upgrade Now" />
		</p>
		<?php 
	}					
}  
/**
 * display list of search terms, used only in the admin page
 * */ 
function pk_stt2_admin_print_searchterms( $type = 'popular' ){
	$searchterms = ( 'popular' == $type ) ? pk_stt2_db_get_popular_terms( 50 ) : pk_stt2_db_get_recent_terms( 50 );
	if(!empty($searchterms)) {
		$toReturn .= "<ol>";
		foreach($searchterms as $term){		
			$permalink = get_permalink($term->post_id);		// permalink to each posts		
			$toReturn .= "<li><a href=\"$permalink\" target=\"_blank\">$term->meta_value</a>";	
			$toReturn .= " ($term->meta_count)</li>";
		}
		$toReturn = trim($toReturn,', ');		
		$toReturn .= "</ol>";
		$toReturn = htmlspecialchars_decode($toReturn);
		return $toReturn;
    } else {
    	return false;
    }
}

/**
 *  print the admin form
 *  */ 
function pk_stt2_admin_print_admin_page(){
	$options = get_option('pk_stt2_settings');	
	$auto_cleanup = get_option('pk_stt2_auto_cleanup');
	$badwords = get_option('pk_stt2_badwords');
	if ( empty($badwords) ){
	   $badwords = PK_BADWORDS;
     update_option ( 'pk_stt2_badwords', $badwords );	
  };
	?>
	<div class="postbox-container" style="width: 70%;">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">    				
				<div id="stt2settings" class="postbox">
					<div class="handlediv" title="Click to toggle">
						<br/>
					</div>
					<h3 class="hndle">
						<span>                        General Settings:
						</span></h3>
					<div class="inside">
						<form id="stt2-options" method="post" action="">
							<table class="stt2-table">
								<tr>
									<td width="350px">
										<label>                                        Enabled:
										</label>
									</td>
									<td>
										<input type="checkbox" <?php if( 1 == get_option('pk_stt2_enabled') ){ echo 'checked'; }; ?> value="1" name="enabled"/>
									</td>
								</tr>
								<tr>
									<td width="350px">
										<label>                                        Max number of search terms:
										</label>
									</td>
									<td>
										<input type = "text" name = "max" value = "<?php echo $options['max']; ?>" size="10"/>
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Text and code for list header:
										</label>
									</td>
									<td>
										<input type = "text" name = "list_header" value = "<?php echo htmlspecialchars(stripslashes($options['list_header'])); ?>" size="50"/>
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Text and code before and after the list:
										</label>
									</td>
									<td>                                    Before:
										<input type = "text" name = "before_list" value = "<?php echo htmlspecialchars(stripslashes($options['before_list'])); ?>" size="10"/>                                    &nbsp;&nbsp;After:
										<input type = "text" name = "after_list" value = "<?php echo htmlspecialchars(stripslashes($options['after_list'])); ?>" size="10"/>
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Text and code before and after each keyword:
										</label>
									</td>
									<td>                                    Before:
										<input type = "text" name = "before_keyword" value = "<?php echo htmlspecialchars(stripslashes($options['before_keyword'])); ?>" size="10"/>                                    &nbsp;&nbsp;After:
										<input type = "text" name = "after_keyword" value = "<?php echo htmlspecialchars(stripslashes($options['after_keyword'])); ?>" size="10"/>
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Convert search terms into links:
										</label>
									</td>
									<td>
										<Input type="radio" name="auto_link" value="1" <?php if ($options['auto_link'] == 1){ echo 'checked'; } ;?> />                                    Yes, link to post content&nbsp;&nbsp;
										<Input type="radio" name="auto_link" value="2" <?php if ($options['auto_link'] == 2){ echo 'checked'; } ;?> />                                    Yes, link to search page&nbsp;&nbsp;
										<Input type="radio" name="auto_link"  value="0" <?php if ($options['auto_link'] == 0){ echo 'checked'; } ;?> />                                    No
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Display search counts for each search term:
										</label>
									</td>
									<td>
										<Input type="radio" name="show_count" value="1" <?php if ($options['show_count'] == 1){ echo 'checked'; } ;?> />                                    Yes&nbsp;&nbsp;
										<Input type="radio" name="show_count"  value="0" <?php if ($options['show_count'] == 0){ echo 'checked'; } ;?> />                                    No
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Add list automatically right after post content:
										</label>
									</td>
									<td>
										<Input type="radio" name="auto_add" value="1" <?php if ($options['auto_add'] == 1){ echo 'checked'; } ;?> />                                    Yes&nbsp;&nbsp;
										<Input type="radio" name="auto_add" value="0" <?php if ($options['auto_add'] == 0){ echo 'checked'; } ;?> />                                    No
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Save popular search terms as tags ( monthly ):
										</label>
									</td>
									<td>
										<Input type="radio" name="auto_tag" value="1" <?php if (get_option('pk_stt2_auto_tag') == 1){ echo 'checked'; } ;?> />                                    Yes&nbsp;&nbsp;
										<Input type="radio" name="auto_tag" value="0" <?php if (get_option('pk_stt2_auto_tag') == 0){ echo 'checked'; } ;?> />                                    No
									</td>
								</tr>
								<tr>
									<td>
										<label>                                        Auto clean up unused search terms after:
										</label>
									</td>
									<td>
										<input type = "text" name = "auto_cleanup" value = "<?php echo $auto_cleanup; ?>" size="10"/> days ( 0 = unlimited, disable auto cleanup )
									</td>
								</tr>								
								<tr>
									<td valign="top" style="padding-top:10px;">
										<label>Block the following terms:</label>
									</td>
									<td>
										<textarea name = "badwords" cols="45" rows="3" ><?php echo $badwords; ?></textarea>
									</td>
								</tr>								
								<tr>
									<td colspan=2>
										<br />
										<span class="submit" style="margin-top:14px;">
											<input class="button-primary" type = "submit" name="submit" value="Save Changes" />
										</span>
									</td>
								</tr>
							</table>
						</form>
					</div>
				</div>
				<?php if ( 0 < $auto_cleanup ) { ?>
				<div id="stt2-cleanup" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Database Clean Up
						</span></h3>
					<div class="inside">
						<p>                        In daily basis, we perform database clean up by deleting search terms that have not been used in <?php echo $auto_cleanup; ?> days.
						</p>
						<ul style="margin: 0pt 0pt 14px 30px; list-style-type: circle;">
							<li>                        Last database cleaned up on
							<?php echo get_option('pk_stt2_last_clean_up'); ?></li>
							<li>                        Next scheduled database clean up on
							<?php echo date('F j, Y, g:i A',wp_next_scheduled('pk_stt2_admin_event_hook')); ?>.</li>
						</ul>
					</div>
				</div>
				<?php }; ?>
				<div id="stt2-del" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Delete Search Terms:
						</span></h3>
					<div class="inside">
						<form id="stt2-delete" method="post" action="">
							<p>                            Enter the search terms to be deleted, separate them with a comma ( e.g.: keyword1,keyword2,keyword3 ): 
								<br />
								<input type="text" name="delete_terms" value="" size="125">
								<br /><br />
								<span class="submit">
									<input type = "submit" name="delete" value="Delete" /><br /><br /> &nbsp;&nbsp;&nbsp;OR <br /><br />
									<input type = "submit" name="delete_all" value="Delete All Search Terms ( Reset )" />
								</span>
							</p>
						</form>
					</div>
				</div>
				<div id="stt2-manual" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Manual Usage Instructions:
						</span></h3>
					<div class="inside">
						<div class="frame">
							<ol>
								<li>                            To display incoming search terms to the article:
								<p>
									<span style="color:blue">                                    &lt;?php if(function_exists('stt_terms_list')) echo stt_terms_list() ;?&gt;
									</span>
								</p></li>
								<li>                            To display most popular search terms for all articles:
								<p>
									<span style="color:blue">                                    &lt;?php if(function_exists('stt_popular_terms')) echo stt_popular_terms(10) ;?&gt;
									</span>
								</p>
								<p>                                If your theme supports widgets, it is better to use the "Popular Search Terms" widget.
								</p></li>
								<li>                            To display most recent search terms:
								<p>
									<span style="color:blue">                                    &lt;?php if(function_exists('stt_recent_terms')) echo stt_recent_terms(10) ;?&gt;
									</span>
								</p>
								<p>                                If your theme supports widgets, it is better to use the "Recent Search Terms" widget.
								</p></li>
                                <li>                            To display most popular search terms in category archive:
								<p>
									<span style="color:blue">                                    &lt;?php if(function_exists('stt_popular_terms_in_category')) echo stt_popular_terms_in_category(10) ;?&gt;
									</span>
								</p>
								<p>                                If your theme supports widgets, it is better to use the "Popular Terms in Category" widget.
								</p></li>
							</ol>
							<small>* Replace '10' with the number of search terms to display.</small>
						</div>
					</div>
				</div>
				<div id="stt2-faq" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Frequently Asked Questions:
						</span></h3>
					<div class="inside">
						<div class="frame">
							<ol>
								<li>                            Do I still need to edit the template and add the plugin code manually if I choose to add the search terms list automatically after post content?
								<p>                                No, the list of search terms will automatically be added right after the post content. 
								</p></li>
								<li>                            Where do I need to add the plugin code manually?
								<p>                                You can put the plugin code into the current template that you use in file index.php or single.php and page.php. The most common place is under the post content or below the comment form.
								</p></li>
								<li>                            I prefer to display the search terms in the form of paragraphs, separated by commas, not in the form of a list like the plugin default format. How can I get results like that?
								<p>                               * Go to 'WordPress Admin &gt; Settings &gt; SEO searchTerms 2' menu,
									<br />                                * Empty columns 'Text and code After and Before the list',
									<br />                                * Empty columns 'Text and code before each keyword',
									<br />                                * And type `','` (a comma followed by a space) in the 'Text and code after each keyword',
									<br />                                * Save.
								</p></li>
								<li>                            I can't see any changes on the single post page. How do I know that this plugin works well?
								<p>                                This plugin will not display the list of search terms until there were visitors who come from search engines into the blog posts. Until then, no search terms will be displayed.
								</p>
								<p>                                So please wait until the plugin logs any visitors coming from search engines. Alternatively, you can search your own blog post from search engines to do a test.
								</p></li>
								<li>                           It seems the plugin won't work with my theme, what is wrong?
								<p>                                Like many others SEO plugins, this plugin requires your theme to call wp_head() hook on the HTML header. Put &lt;?php wp_header(); ?&gt; code between your &lt;head&gt;...&lt;/head&gt; tag, usually on file header.php. Open header file of the Default Theme if you need any references.
								</p>
							</ol>
						</div>
					</div>
				</div>
				<div id="stt2-copyright" class="postbox">
					<div class="handlediv" title="Click to toggle">
						<br />
					</div>
					<h3 class="hndle">
						<span>                        Copyright
						</span></h3>
					<div class="inside">
						<div class="frame">                        Copyright &copy; 2010 by Purwedi Kurniawan. Feel free to
							<a href="http://exclusivewordpress.com/contact/" target="_blank">contact me</a> if you need help with the plugin.
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="postbox-container" style="width: 29%;">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="featured" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Latest SEO Plugin:
						</span></h3>
					<div class="inside">
						<div class="frame list">
							<a href="http://3e99bbleuspodw9lilroml6b3v.hop.clickbank.net/?tid=STT2" target="_blank"><img src="http://plugins.svn.wordpress.org/searchterms-tagging-2/image6.png" /></a>
						</div>
					</div>
				</div>
				<div id="stt2-top" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Popular Search Terms:
						</span></h3>
					<div class="inside">
						<div class="frame list">
							<?php echo pk_stt2_admin_print_searchterms( 'popular' ); ?>
						</div>
					</div>
				</div>
				<div id="stt2-recent" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Recent Search Terms:
						</span></h3>
					<div class="inside">
						<div class="frame list">
							<?php echo pk_stt2_admin_print_searchterms( 'recent' ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
/** 
 * filter the content and add the search terms right after the post content ( on single and page only )
 * */ 
function pk_stt2_admin_content_filter($content){	
	if ( !is_home() ){
		$options = get_option('pk_stt2_settings');
		if($options['auto_add'])
			$content .= stt_terms_list();			
	}
	return $content;
}
/**
 * update options and save it to db
 * */ 
function pk_stt2_admin_update_options(){	
	if ( isset($_POST['max']) && isset($_POST['before_keyword']) && isset($_POST['after_keyword']) && 
	isset($_POST['auto_add']) && isset($_POST['auto_link']) && isset($_POST['show_count']) && isset($_POST['before_list']) 
	&& isset($_POST['after_list']) && isset($_POST['list_header']) ){	
	
		$options['max'] = intval($_POST['max']);
		$options['before_keyword'] = $_POST['before_keyword'];
		$options['after_keyword'] = $_POST['after_keyword'];
		$options['before_list'] = $_POST['before_list'];
		$options['after_list'] = $_POST['after_list'];		
		$options['list_header'] = $_POST['list_header'];				
		$options['auto_add'] = intval($_POST['auto_add']);
		$options['auto_link'] = intval($_POST['auto_link']);
		$options['show_count'] = intval($_POST['show_count']);		
		if ( intval($options['max']) < 2 ) $options['max'] = 2;						
		update_option( 'pk_stt2_settings', $options );			
		update_option( 'pk_stt2_enabled', $_POST['enabled'] );
		update_option( 'pk_stt2_auto_cleanup', intval($_POST['auto_cleanup']) );	
		update_option( 'pk_stt2_auto_tag', intval($_POST['auto_tag']) );	
		update_option ( 'pk_stt2_badwords', $_POST['badwords'] );
		?>
		<div id="message" class="updated fade">
			<p>        Options saved.
			</p>
		</div>
		<?php
	} else {
		?>
		<div id="message" class="updated fade">
			<p>        Failed to save options.
			</p>
		</div>
		<?php
	}
}
/**
 * add the menu into WordPress admin menu
 * */ 
function pk_stt2_admin_menu_hook(){
    if (function_exists('add_options_page')) {
		add_options_page(
			'SEO SearchTerms 2',
			'SEO SearchTerms 2',
			'manage_options',
			'searchterms-tagging2.php',
			'pk_stt2_create_admin_menu'
		);
	}
}

/**
 * display upgrade database form
 * */ 
function pk_stt2_admin_print_upgrade_form() {
	?>
	<div class="postbox-container" style="width: 100%;">
		<div class="metabox-holder">
			<div class="meta-box-sortables ui-sortable">
				<div id="stt2-upgradedb" class="postbox">
					<div class="handlediv" title="Click to toggle">
					</div>
					<h3 class="hndle">
						<span>                        Database upgrade needed before you can use the new version!
						</span></h3>
					<div class="inside">
						<form method = "post">
							<p>                            To be able to add features such as the
								<i>recent search terms</i>, we are forced to change the structure of existing databases. We apologize for the inconveniences.
							</p>
							<p>                            Possibility for error is very small, but
								<i>creating a database backup is highly recommended before doing the upgrade</i>. Complete information on how to backup a WordPress database can be found
								<a href="http://codex.wordpress.org/Backing_Up_Your_Database" target="_blank">here</a>.
							</p>
							<p class="submit">
								<input type = "submit" name="upgrade" value="Upgrade Now" />
							</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php        
}

/**
* == DATABASE SECTION ==
* all main database related functions of searchterms tagging 2 plugin
**/

/**
 * get 10 popular search terms for the posts, will be used as tags
 * @param $id: post id
 * @return: comma separated text of popular search terms 
 **/
function pk_stt2_db_get_popular_tags( $id ){
	global $wpdb;
	$sql = "SELECT meta_value FROM ".$wpdb->prefix."stt2_meta WHERE ( post_id = '".$id."' AND meta_count > 25 AND meta_value NOT LIKE '%http%' ) ORDER BY meta_count DESC LIMIT 5;";
	$a_results = $wpdb->get_results( $sql );
	 if ( $a_results ){
		foreach ( $a_results as $value ){
			$result .= $value->meta_value.',';
		}
		$result = trim($result,',');
	} 
	return $result;
}

/**
 * get popular search terms
 * @param $count: max number of search terms
 **/
function pk_stt2_db_get_popular_terms( $count ){
	global $wpdb;
	$result = $wpdb->get_results( "SELECT `meta_value`,`meta_count`,`post_id` FROM `".$wpdb->prefix."stt2_meta` ORDER BY `meta_count` DESC LIMIT ".$count.";" );			
	return $result;
}

/**
 * get list of search terms
 * @param $max: max number of search terms
 **/
function pk_stt2_db_get_search_terms( $max ){
	global $wpdb, $post;	   
	$result = $wpdb->get_results( "SELECT `meta_value`,`meta_count` FROM `".$wpdb->prefix."stt2_meta` WHERE `post_id` = $post->ID ORDER BY `meta_count` DESC LIMIT ".$max.";" );			
	return $result;
}

/**
 * get recent search terms
 * @param $count: max number of search terms
 **/
function pk_stt2_db_get_recent_terms( $count ){
	global $wpdb;
	$result = $wpdb->get_results( "SELECT `meta_value`,`meta_count`,`post_id` FROM `".$wpdb->prefix."stt2_meta` ORDER BY `last_modified` DESC LIMIT ".$count.";" );			
	return $result;
}

/**
 * get random search terms
 * @param $count: max number of search terms
 **/
function pk_stt2_db_get_random_terms( $count ){
	global $wpdb;
	$result = $wpdb->get_results( "SELECT `meta_value`,`meta_count`,`post_id` FROM `".$wpdb->prefix."stt2_meta` WHERE `meta_count` > 10  ORDER BY RAND() LIMIT ".$count.";" );			
	return $result;
}

/**
 * get the number of searchterms
 **/
function pk_stt2_db_get_number_of_searchterms(){
	global $wpdb;
	$result = $wpdb->get_var("SELECT COUNT(`meta_value`) FROM ".$wpdb->prefix."stt2_meta;");
	return $result;
}
/** 
 * alter table and add the timestamp
 **/
function pk_stt2_db_alter_table(){
	global $wpdb;
	$sql = "ALTER TABLE ".$wpdb->prefix."stt2_meta 
		ADD last_modified TIMESTAMP 
		DEFAULT CURRENT_TIMESTAMP 
		ON UPDATE CURRENT_TIMESTAMP";
	
	$result = $wpdb->query($sql);			
	
	$sql = "UPDATE ".$wpdb->prefix."stt2_meta SET last_modified=CURRENT_TIMESTAMP";
	$result = $wpdb->query($sql);
	return $result;
}
/**
 * delete searchterms from the database
 * @param $searchterms: comma separated search terms or 'delete_all_terms'
 * @output: number of rows effected by the delete query
 **/
function pk_stt2_db_delete_searchterms( $searchterms ){
	global $wpdb;
	if ( 'delete_all_terms' !== $searchterms ) {
		$arr_searchterms = explode(',',$searchterms);		
		foreach ($arr_searchterms as $value) {
			$sql .= "'".$value."',";
		}
		$sql = trim( $sql ,',' );		
		$success = $wpdb->query( "DELETE FROM ".$wpdb->prefix."stt2_meta WHERE meta_value IN ( $sql )" );	
	} else {
		$success = $wpdb->query( "DELETE FROM ".$wpdb->prefix."stt2_meta" );	
	}
	return $success;
}
/**
 * move db from previous version of database
 **/
function pk_stt2_db_upgrade(){
	global $wpdb;
	$result = $wpdb->query( 'INSERT IGNORE INTO '.$wpdb->prefix.'stt2_meta (post_id, meta_value, meta_count) 
			SELECT post_id, meta_value, meta_count FROM '.$wpdb->prefix.'stt2meta;' );			
	
	$result = $wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'stt2meta;');	
}

/**
* clean the database in daily basis
**/
function pk_stt2_db_cleanup( $days ){
	global $wpdb;
	$result = $wpdb->query('DELETE FROM '.$wpdb->prefix.'stt2_meta WHERE (meta_count < 10) AND (date(last_modified) < date(now()-interval '.$days.' day));');
	return $result;
}
/**
 * create stt2 database
 * */ 
function pk_stt2_db_create_table() {
   global $wpdb;  
   $table_name = $wpdb->prefix.'stt2_meta';
   if($wpdb->get_var("SHOW TABLES LIKE '$table_name';") != $table_name) {      
        $sql = "CREATE TABLE `".$wpdb->prefix."stt2_meta` (
    		`post_id` INT( 20 ) NOT NULL ,
    		`meta_value` VARCHAR ( 255 ) NOT NULL ,
    		`meta_count` INT( 20 ) NOT NULL DEFAULT '1',
    		`last_modified` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    		PRIMARY KEY ( `post_id` , `meta_value` )
    		);";	
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
   } else {
        $sql = "DELETE FROM ".$wpdb->prefix."stt2_meta WHERE CHAR_LENGTH(meta_value) < 3;";
        $result = $wpdb->query($sql);
   }
}
/**
 * check whether the previous db exist
 * */ 
function pk_stt2_db_is_previous_exist() {
	global $wpdb;
   	$table_name = $wpdb->prefix.'stt2meta';
	$result = ( $wpdb->get_var("SHOW TABLES LIKE '$table_name';") == $table_name ) ? true : false; 
	return $result;
}
/**
 * check whether the last modified column exist
 * */ 
function pk_stt2_db_is_last_modified_column_exist() {
	global $wpdb;
	$result = ( $wpdb->get_var("SHOW COLUMNS FROM ".$wpdb->prefix."stt2_meta LIKE 'last_modified';") == 'last_modified' ) ? true : false;
	return $result;
}
/**
 * save search terms into database
 **/ 
function pk_stt2_db_save_searchterms($post_id, $meta_value) {
	if ( '1' == get_option('pk_stt2_enabled') ) {
		global $wpdb;   	
		if ( strlen($meta_value) > 3 ){
			$success = $wpdb->query( $wpdb->prepare( "INSERT INTO ".$wpdb->prefix."stt2_meta ( `post_id`,`meta_value`,`meta_count` ) VALUES ( %s, %s, 1 )
				ON DUPLICATE KEY UPDATE `meta_count` = `meta_count` + 1", $post_id, $meta_value ) );				
		}
	}
	return $success;
}
/**
* get popular search terms in category
* @author: pile ( http://pile.web.id )
**/
function pk_stt2_db_get_popular_searchterms_in_category( $count ){
    global $wpdb;
	$cat_ID = get_query_var('cat');
	$sql = " SELECT wps.post_id, wps.meta_value, wps.meta_count
		FROM ".$wpdb->prefix."terms
		INNER JOIN ".$wpdb->prefix."term_taxonomy ON ".$wpdb->prefix."terms.term_id = ".$wpdb->prefix."term_taxonomy.term_id
		INNER JOIN ".$wpdb->prefix."term_relationships wpr ON wpr.term_taxonomy_id = ".$wpdb->prefix."term_taxonomy.term_taxonomy_id
		INNER JOIN ".$wpdb->prefix."posts p ON p.ID = wpr.object_id
		INNER JOIN ".$wpdb->prefix."stt2_meta wps ON wps.post_id = p.ID
		WHERE taxonomy = 'category'
		AND p.post_type = 'post'
		AND p.post_status = 'publish'
		AND ( ".$wpdb->prefix."terms.term_id = '".$cat_ID."' )
		ORDER BY `wps`.`meta_count` DESC
		LIMIT ".$count.";";	
	$results = $wpdb->get_results($sql);
	return $results;
}

/**
* == MAIN SECTION ==
* all main functions of searchterms tagging 2 plugin
**/

/**
* get popular search terms on coresponding category
* @param $count: number of search terms to be displayed
**/
function stt_popular_terms_in_category( $count=10 ){
	if (is_category()) {
		$start_time = round(microtime(),3);
		$options = get_option('pk_stt2_settings');		
		$searchterms = pk_stt2_db_get_popular_searchterms_in_category( $count );		
		if(!empty($searchterms)) {
		  $result = pk_stt2_function_prepare_searchterms($searchterms,$options,true);		
		  $result .= "<!-- SEO SearchTerms Tagging 2 plugin took ". round(1000 * (microtime() - $start_time),3) . " ms -->";
		  return $result;	  
		} else {
			return false;
		}
	}
}

/**
 * save popular search terms as tags in monthly basis
  **/
function pk_stt2_function_save_tags(){
	if ( '1' == get_option('pk_stt2_auto_tag') ) {		
		$diff = strtotime(date('F j, Y')) - strtotime( get_post_meta( $id,'stt2_update_tags',true ) ) + 1; 
		$day_diff = ceil($diff / (60*60*24)) ;  
		if ( 30 < $day_diff ){
			global $post;
			$tags = pk_stt2_db_get_popular_tags( $post->ID );
			wp_set_post_tags( $post->ID, $tags, true );
			update_post_meta( $post->ID,'stt2_update_tags', date('F j, Y') );		
		}
	}
}

/**
 * hooked to wp-head()
 * */ 
function pk_stt2_function_wp_head_hook() {
	if( is_single()||is_page() ){
		$referer = pk_stt2_function_get_referer();
		if (!$referer) return false;
		$delimiter = pk_stt2_function_get_delimiter($referer);
		if( $delimiter ){
			$term = pk_stt2_function_get_terms($delimiter);		
			if (!pk_stt2_is_contain_bad_word( $term )) {
				global $post;						 			
				pk_stt2_db_save_searchterms( $post->ID, $term );
			}
		}
		pk_stt2_function_save_tags();
	}
}

/**
 * display the search terms below post content
 * */ 
function stt_terms_list(){
	$start_time = round(microtime(),3);
	$options = get_option('pk_stt2_settings');	
	$searchterms = pk_stt2_db_get_search_terms( $options['max'] );			
	if(!empty( $searchterms )) {
      $result = pk_stt2_function_prepare_searchterms( $searchterms, $options );
	  $result .= "<!-- SEO SearchTerms Tagging 2 plugin took ". round(1000 * (microtime() - $start_time),3) . " ms -->";
	  return $result;
    } else {
    	return false;
    }	
}

/**
 * strip the slash from each search terms
 * */ 
function pk_stt2_function_stripslashes_options($options){
   foreach($options as $i=>$row){       
       $row = stripslashes($row);
       $options[$i]=$row;
   }
   return $options;
}

/**
 * common function to print the search terms
 * */ 
function pk_stt2_function_prepare_searchterms( $searchterms, $options, $popular=false ){
	global $post;
	$options = pk_stt2_function_stripslashes_options($options);
	$popular == false ? $toReturn .= $options['list_header'].$options['before_list'] : $toReturn .= $options['before_list'];		
	foreach($searchterms as $term){
		if ( 0 == $options['auto_link'] ){
			$toReturn .= $options['before_keyword'].$term->meta_value;
		} else {		
			if( !$popular ){
				if ( 1 == $options['auto_link'] ){									   
				   $permalink = get_permalink( $post->ID );		// permalink to the current post
				} elseif ( 2 == $options['auto_link']){			// permalink to search page 
					global $wp_version;
					if (strpos($wp_version,'3.0') !== false)
						$permalink = get_bloginfo( 'url' ).'/search/'.user_trailingslashit(pk_stt2_function_sanitize_search_link($term->meta_value));
					else
						$permalink = get_bloginfo( 'url' ).'?s='.user_trailingslashit(pk_stt2_function_sanitize_search_link($term->meta_value));
				}
			} else {
				$permalink = get_permalink($term->post_id);		// permalink to each posts
			}		
			$toReturn .= $options['before_keyword']."<a href=\"$permalink\" title=\"$term->meta_value\">$term->meta_value</a>";
		}		
		$options['show_count'] == true ? $toReturn .= " ($term->meta_count)".$options['after_keyword'] : $toReturn .= $options['after_keyword'];
	}
	$toReturn = trim($toReturn,', ');		
	$toReturn .= $options['after_list'];
	$toReturn = htmlspecialchars_decode($toReturn);
	return $toReturn;
}

/**
 * display popular search terms manually 
 * @param $count: number of search terms to be displayed
 * */ 
function stt_popular_terms( $count=10 ){
	$start_time = round(microtime(),3);
	$options = get_option('pk_stt2_settings');	
	$searchterms = pk_stt2_db_get_popular_terms($count);
	if(!empty($searchterms)) {
      $result = pk_stt2_function_prepare_searchterms($searchterms,$options,true);		
	  $result .= "<!-- SEO SearchTerms Tagging 2 plugin took ". round(1000 * (microtime() - $start_time),3) . " ms -->";
	  return $result;	  
    } else {
    	return false;
    }
}

/** 
 * display recent search terms manually
 * @param $count: number of search terms to be displayed 
 * */ 
function stt_recent_terms( $count=10 ){
	global $wpdb;	   
	$start_time = round(microtime(),3);
	$options = get_option('pk_stt2_settings');			
	$searchterms = pk_stt2_db_get_recent_terms( $count );
	if(!empty($searchterms)) {
      $result = pk_stt2_function_prepare_searchterms($searchterms,$options,true);		
	  $result .= "<!-- SEO SearchTerms Tagging 2 plugin took ". round(1000 * (microtime() - $start_time),3) . " ms -->";
	  return $result;	  
    } else {
    	return false;
    }
}

/** 
 * display random search terms manually
 * @param $count: number of search terms to be displayed 
 * */ 
function stt_random_terms( $count=10 ){
	global $wpdb;	   
	$start_time = round(microtime(),3);
	$options = get_option('pk_stt2_settings');			
	$searchterms = pk_stt2_db_get_random_terms( $count );
	if(!empty($searchterms)) {
      $result = pk_stt2_function_prepare_searchterms($searchterms,$options,true);		
	  $result .= "<!-- SEO SearchTerms Tagging 2 plugin took ". round(1000 * (microtime() - $start_time),3) . " ms -->";
	  return $result;	  
    } else {
    	return false;
    }
}

/**
 * get search delimiter for each search engine
 * base on the original searchterms tagging plugin
 * */ 
function pk_stt2_function_get_delimiter($ref) {
    $search_engines = array('google.com' => 'q',
			'go.google.com' => 'q',
			'images.google.com' => 'q',
			'video.google.com' => 'q',
			'news.google.com' => 'q',
			'blogsearch.google.com' => 'q',
			'maps.google.com' => 'q',
			'local.google.com' => 'q',
			'search.yahoo.com' => 'p',
			'search.msn.com' => 'q',
			'bing.com' => 'q',
			'msxml.excite.com' => 'qkw',
			'search.lycos.com' => 'query',
			'alltheweb.com' => 'q',
			'search.aol.com' => 'query',
			'search.iwon.com' => 'searchfor',
			'ask.com' => 'q',
			'ask.co.uk' => 'ask',
			'search.cometsystems.com' => 'qry',
			'hotbot.com' => 'query',
			'overture.com' => 'Keywords',
			'metacrawler.com' => 'qkw',
			'search.netscape.com' => 'query',
			'looksmart.com' => 'key',
			'dpxml.webcrawler.com' => 'qkw',
			'search.earthlink.net' => 'q',
			'search.viewpoint.com' => 'k',
			'mamma.com' => 'query');
    $delim = false;
    if (isset($search_engines[$ref])) {
        $delim = $search_engines[$ref];
    } else {
        if (strpos('ref:'.$ref,'google'))
            $delim = "q";
		elseif (strpos('ref:'.$ref,'search.atomz.'))
            $delim = "sp-q";
		elseif (strpos('ref:'.$ref,'search.msn.'))
            $delim = "q";
		elseif (strpos('ref:'.$ref,'search.yahoo.'))
            $delim = "p";
        elseif (preg_match('/home\.bellsouth\.net\/s\/s\.dll/i', $ref))
            $delim = "bellsouth";
    }
    return $delim;
}

/**
 * retrieve the search terms from search engine query
 * */ 
function pk_stt2_function_get_terms($d) {
    $terms       = null;
    $query_array = array();
    $query_terms = null;
    $query = explode($d.'=', $_SERVER['HTTP_REFERER']);
    $query = explode('&', $query[1]);
    $query = urldecode($query[0]);
    $query = str_replace("'", '', $query);
    $query = str_replace('"', '', $query);
    $query_array = preg_split('/[\s,\+\.]+/',$query);
    $query_terms = implode(' ', $query_array);
    $terms = htmlspecialchars(urldecode(trim($query_terms)));
    return $terms;
}

/**
 * get the referer
 * */ 
function pk_stt2_function_get_referer() {
    if (!isset($_SERVER['HTTP_REFERER']) || ($_SERVER['HTTP_REFERER'] == '')) return false;
    $referer_info = parse_url($_SERVER['HTTP_REFERER']);
    $referer = $referer_info['host'];
    if(substr($referer, 0, 4) == 'www.')
        $referer = substr($referer, 4);
    return $referer;
}

/**
* sanitize link to search page
* @param $title: search engine terms
* @output: search terms in form of web safe url slug
**/
function pk_stt2_function_sanitize_search_link($title) {
	$title = strip_tags($title);
	// Preserve escaped octets.
	$title = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '---$1---', $title);
	// Remove percent signs that are not part of an octet.
	$title = str_replace('%', '', $title);
	// Restore octets.
	$title = preg_replace('|---([a-fA-F0-9][a-fA-F0-9])---|', '%$1', $title);

	$title = remove_accents($title);
	if (seems_utf8($title)) {
	   if (function_exists('mb_strtolower')) {
		   $title = mb_strtolower($title, 'UTF-8');
	   }
	   $title = utf8_uri_encode($title);
	}

	$title = strtolower($title);
	$title = preg_replace('/&.+?;/', '', $title); // kill entities
	$title = preg_replace('/[^%a-z0-9 _-]/', '', $title);
	$title = preg_replace('/\s+/', '+', $title);
	$title = preg_replace('|-+|', '+', $title);
	$title = trim($title, '+');

	return $title;
 }
/**
* check whether the search term contain forbidden word
**/
function pk_stt2_is_contain_bad_word( $term ){
  $option = get_option('pk_stt2_badwords');
  $option = ( empty($option) ) ? PK_BADWORDS : $option;
	$badwords = explode( ',',$option );
	$term = str_ireplace( $badwords,'***',$term );

	if( false === strpos( $term, '***' ) )
		return false;
	else
		return true;
}
/**
* add widget for recent searchterms and popular searchterms
**/
include_once ( 'widget.php' );
?>