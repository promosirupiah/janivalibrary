=== Plugin Name ===
Contributors: poer
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=10748556
Tags: seo, widget, links, google, widget, post, sidebar, internal linking, incoming search terms, auto tags
Requires at least: 2.5
Tested up to: 3.0
Stable tag: 1.3

Strengthen our On Page SEO by adding new internal linking to the blog post using the most popular keywords used by search engine visitors.

== Description ==

The purpose of this plugin is to strengthen our On Page SEO by adding new internal linking to the blog post using the most popular keywords used by search engine visitors to find the blog post from a search engine ( incoming search terms ).

We can also display the most popular & recent search terms in the sidebar to get a side wide internal linking to the corresponding blog post.

New since version 1.25: Automatically convert popular search terms into Post Tags.

SEO Search Terms Tagging 2 plugin main features: 

1. Display the search terms/keywords used by visitors from search engines for each blog post.
1. Display the most popular search term for the entire blog posts.
1. Display the most recent search terms for the entire blog posts.
1. Add the list of search terms automatically after the post content or manually by editing the template.
1. Limit the search terms to be displayed.
1. Display the search terms only or automatically change it into internal linking to the blog post or search page.
1. Display popularity ( search counter ) after each keyword.
1. Automatically delete unused search terms after X days.
1. Automatically convert popular search terms into Post Tags.
1. Display most popular search terms in the archive category ( courtesy of Pile )
1. Delete unwanted search engine terms & delete all search terms ( reset ).
1. Popular, Popular in Category & Recent Search Terms widgets ( you can find it on page Appearance &gt; Widgets ).
1. Block unwanted keywords/bad words.

== Installation ==

1. Download it here. or search from WordPress Admin � Plugin &gt; Add New.
1. Install and activate from WordPress Admin &gt; Plugins page.
1. Go to the WordPress Admin Options page &gt; SearchTerms Tagging 2, and set the options as you wish.
1. Go to the WordPress Admin &gt; Appearance &gt; Widgets to use the Popular & Recent Search Terms Widget.

== Frequently Asked Questions ==

= Do I still need to edit the template and add the plugin code manually if I choose to add the search terms list automatically after post content? =

No, the list of search terms will automatically be added right after the post content. 

= Where do I need to add the plugin code manually? =

You can put the plugin code into the current template that you use in file index.php or single.php and page.php. The most common place is under the post content or below the comment form.

= I prefer to display the search terms in the form of paragraphs, separated by commas, not in the form of a list like the plugin default format. How can I get results like that? =

* Go to 'WordPress Admin &gt; Settings &gt; SEO searchTerms 2' menu,
* Empty columns 'Text and code After and Before the list',
* Empty columns 'Text and code before each keyword',
* And type `','` (a comma followed by a space) in the 'Text and code after each keyword',
* Save.

= I can't see any changes on the single post page. How do I know that this plugin works well? =

This plugin will not display the list of search terms until there were visitors who come from search engines into the blog posts. Until then, no search terms will be displayed.

So please wait until the plugin logs any visitors coming from search engines. Alternatively, you can search your own blog post from search engines to do a test.

= It seems the plugin won't work with my theme, what is wrong? =

Like many others SEO plugins, this plugin requires your theme to call wp_head() hook on the HTML header. Put &lt;?php wp_header(); ?&gt; code between your &lt;head&gt;...&lt;/head&gt; tag, usually on file header.php. Open header file of the Default Theme if you need any references.

== Screenshots ==

1. Plugin admin page.
2. The internal linking created base on users search terms.
3. Popular Search Terms and Recent Search Terms Widget

== Changelog ==
= 1.3 =
* keep compatibily with PHP 4 web hosting

= 1.29 =
* Add bad words filter

= 1.28 =
* Fix: Parse error on PHP 5.3x
* Prevent the plugin to automatically add the searchterms in home page.

= 1.27 =
* Fix: Visitor coming from Google regional tld ( .co.id, .co.uk, .com.sg etc ) is not recorded.

= 1.26 =
* Add a display format option ( list or comma separated ) on popular & recent search terms widget.
* Record search terms used by visitors from all Google services, including Google image, blog search, products, maps and books.
* Fix: Prevent the search terms containing 'http' converted into post tag ( result in error 404 ).

= 1.25 =
* Automatically delete unused search terms after X days.
* Automatically convert popular search terms into Post Tags.
* Popular Search Terms in Category function and widget.
* Sanitize link to search results from a search terms.

= 1.1 =
* Automatically delete unused search terms after 30 days.

= 1.0 =
* Recent Search Terms feature ( need to update the database structure ).
* Delete unwanted search terms.
* Additional option to convert search terms into a link to search page.
* Popular & Recent Search Terms widgets ( you can find it on page Appearance &gt; Widgets ).