=== Shortcode Widget ===
Contributors: gagan0123
Tags: Shortcode, Widget
Requires at least: 3.3
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a text-like widget that allows you to write shortcode in it.

== Description ==

Adds a text-like widget that allows you to write shortcode in it. (Just whats missing in the default text widget)
To test the widget you can add the widget and use the shortcode "[shortcode_widget_test]", it will display "It works" on the fronte
nd and this will confirm the widget does work.

== Installation ==

1. Add the plugin's folder in the WordPress' plugin directory.
1. Activate the plugin.
1. You are now ready to use the Shortcode Widget from the Widgets section.
1. To test the widget you can add the widget and use the shortcode "[shortcode_widget_test]", it will display "It works" on the frontend and this will confirm the widget does work.

== Changelog ==

= 0.1 =
* Added the shortcode widget

= 0.2 =
* Added translation support

= 0.3 =
* Added a shortcode for testing the plugin '[shortcode_widget_test]'

= 1.0 = 
* Tested with WP 4.0
