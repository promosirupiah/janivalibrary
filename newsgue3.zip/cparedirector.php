<?php
/*
Plugin Name: CPA Redirector
Plugin URI: http://www.contentgeneration.org/
Description: CPA Redirector
Author: Brad
Version: 1.2
Author URI: http://www.contentgeneration.org/
*/ 

function prc_plugin_install() {		

	delete_option('wp_redmeth');

	delete_option('wp_magicnumber');

	delete_option('wp_formmethod');

	add_option('wp_redmeth', 0);

	add_option('wp_formmethod', 0);

	add_option('wp_magicnumber', 0);

}


if (isset ($_GET['activate']) && $_GET['activate'] == 'true') {	
	add_action('init', 'prc_plugin_install');
}



function prc_red() {   	

    if ( is_home() || is_category() || is_archive()) return false;
	
	global $post;

	if ($_GET['mn']==get_option('wp_magicnumber')){		

		echo '<html><head></head><body><form action="' . get_permalink($post->ID) . '" method="post" id="form1">

<input type="hidden"  name="mn" value="' . get_option('wp_magicnumber') . '" /></form>

<script language="JavaScript"> 
	document.getElementById(\'form1\').submit();</script></body></html>';
		return true; 
		exit();
}
	
	global $post;

	if (strlen(get_post_meta($post->ID, "theurl", true)) < 5) return false;

    if ($_POST['mn']==get_option('wp_magicnumber')){		

		if(get_option('wp_redmeth')==0) {

			if(get_option('wp_formmethod')==0)
				$formmethod = "POST";
			else
				$formmethod = "GET";
 	  	 
			echo '<html><head></head><body><form action="' . get_post_meta($post->ID, "theurl", true) .  '" method="' . $formmethod . '" id="form1"></form>
<script language="JavaScript"> 

	document.getElementById(\'form1\').submit(); 

</script></body></html>';
		}

			else if(get_option('wp_redmeth')==1)

	echo 	'<HEAD>
<SCRIPT language="JavaScript">
<!--
window.location="' . get_post_meta($post->ID, "theurl", true) . '";
//-->
</SCRIPT>
</HEAD>';



		else if(get_option('wp_redmeth')==2)

			echo '<meta http-equiv="refresh" content=0;url=' . get_post_meta($post->ID, "theurl", true)  . '>';

		else 
			echo "";	

	  }
	else  return false;

	return true;
} 


function cpa_red_editor() { 

	if (isset ($_POST['update'])) {		

		update_option('wp_redmeth', $_POST['redmeth']);	

		update_option('wp_magicnumber', $_POST['magicnumber']);	

		update_option('wp_formmethod', $_POST['formmethod']);	

		update_option('wp_redrate', $_POST['redrate']);	
		
		for($i = 1; $i <= $_POST['post_count']; $i++) {
			$url = 'url_' . $i;
			$post_id = "id_" . $i;
		
			delete_post_meta($_POST[$post_id], 'theurl');
			add_post_meta($_POST[$post_id], 'theurl', $_POST[$url]);
			
		}

	}
	
	global $wpdb; 
	$links='';
	$posts_columns = array(
		//'ID'      => __('ID'),
		'title'      => __('Post Title'),
		'post URL'      => __('Post URL'),
		'URL'     => __('Affiliate URL')
	);
	$posts_columns = apply_filters('manage_posts_columns', $posts_columns);

	

	echo '<div class="wrap">';
		echo '<center><h2>CPA Redirector</h2></center>';
	echo '<style type="text/css">';
	echo '#thecenter { text-align:center; }';
	echo '</style>';
	echo '<table class="widefat">';

	echo '<form action="options-general.php?page=' . $_GET['page'] . '" method="post">';
	echo '<input type="hidden" name="update" value="yes" />';

	echo 'Redirection Method: ';
	echo '<select name="redmeth">';
	echo '<option value="0"' . ((get_option('wp_redmeth') == 0)?' selected':'') .   ' />Java Script Form';
	echo '<option value="1"' . ((get_option('wp_redmeth') == 1)?' selected':'') .   ' />Java Script';
	echo '<option value="2"' . ((get_option('wp_redmeth') == 2)?' selected':'') .   ' />Meta Refresh';
	echo '</select><br><br>';

	echo 'Form Method: ';
	echo '<select name="formmethod">';
	echo '<option value="0"' . ((get_option('wp_formmethod') == 0)?' selected':'') .   ' />POST';
	echo '<option value="1"' . ((get_option('wp_formmethod') == 1)?' selected':'') .   ' />GET';
	echo '</select><br><br>';

	echo '<label for="magicnumber">Magic Number: <//label>';

	echo '<input name="magicnumber" type="text"  id="keyword_count" value="' .  get_option('wp_magicnumber')  . '"  size="20" />';

	echo '<br><br>';


	echo '<thead><tr>';

	
	
	foreach($posts_columns as $column_display_name) {
		echo '<th scope="col">';
		echo $column_display_name . '</th>';		
	}
	echo '</tr> </thead> <tbody id="the-list">';	
	
        $time_difference = get_settings('gmt_offset'); 
        $now = gmdate("Y-m-d H:i:s",time()); 
    $request = "SELECT ID, post_title, post_excerpt FROM $wpdb->posts WHERE post_status = 'publish' "; 
        if($hide_pass_post) $request .= "AND post_password ='' "; 
        $request .= "AND post_date_gmt < '$now' ORDER BY post_date"; 
    $posts = $wpdb->get_results($request); 
        $links[] = ''; 
		$i = 0;
	$bgcolor = '';

    if($posts) { 
         foreach ($posts as $post) { 
                $post_title = stripslashes($post->post_title); 
                $permalink = get_permalink($post->ID); 
                $links[$i] = '<a href="' . $permalink . '" rel="bookmark" title="Permanent Link: ' . htmlspecialchars($post_title, ENT_COMPAT) . '">' . strtolower(htmlspecialchars($post_title)) . '</a>'; 
				$i++;                        
				$class = ('alternate' == $class) ? '' : 'alternate';
				echo '<input type="hidden" name="id_' . $i .'" value="' . $post->ID . '"/>';
				echo '<tr class="' . $class  . '"><th scope="row" style="text-align: left">' . $post_title . '</th>';
				echo '<input type="hidden" name="id_' . $i .'" value="' . $post->ID . '"/>';
				//echo '<th scope="row" style="text-align: left">' . $permalink . '</th>';
				echo '<th scope="row" style="text-align: left"><input name="perma" type="text" id="perma" value="' . $permalink . '"  size="70" />';		
				echo '<th scope="row" style="text-align: left"><input name="url_' . $i . '" type="text" id="url_' . $i . '" value="' . get_post_meta($post->ID, "theurl", true) . '" size="40" /></th>';
				echo '</tr>';
				
         } 
	
		echo '</table>';
		echo '<div style="clear:both;"></div>';
		echo '<input type="hidden" name="post_count" value="' . $i . '"/>';
		echo '<br>';
		echo '<div id="thecenter">';
		echo '<input type="submit" value="Save Settings" />';
		echo '</form>';
		echo '</div></div>';
     }
	
} 

function prc_add_options_to_admin() { 
   add_options_page('CPA Redirector', 'CPA Redirector', 8, __FILE__, 'cpa_red_editor'); 
} 

if (function_exists('add_action')) { 
   add_action('admin_menu', 'prc_add_options_to_admin'); 

} 

?>