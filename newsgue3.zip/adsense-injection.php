<?php
/*
Plugin Name: Adsense Injection
Plugin URI: http://wordpress-plugins.biggnuts.com/adsense-injection/
Description: Inserts Adsense into your blog without a log of fucking around.
Version: 2.0
Author: Dax "The Hammer" Herrera
Author URI: http://www.biggnuts.com
*/

/* UPDATES

12/20/06 2.0
Put in a Not Me checkbox so admins don't have to look at their ads.
Put multiple Ads in the same post
checkbox for admin google_adtest=�on�;
Put Yahoo Code in it
randomized network

11/2 Put <br in as an alternative tag (<p) for people who don't use the wsywig editor

10/12 Paragraph overwriting bug fixed, fixed thanks to Ste, http://www.stefanocislaghi.it/

10/11 added a new ad unit and the ability to selectively remove adsense from posts and pages with the <!--noadsense--> tag.
Thanks to k2xl.com for that idea! 

If you want to selectively prohibit AdSense from displaying on a post or page, just put <!--noadsense--> somewhere in the post ^_^

10/9  fixed a bug that messed up paragraph tags with classes assigned to them

10/2 Added the 200x200 unit.  Made the ads not show on your feeds.  Apparently that's against the TOS.

9/14 Added a Do NOT SHOW ON PAGES checklist in the admin panel.
You can select not to show ads on certain pages

9/13 Added a testing mode for Admins to see the ads only!


TODO:

*/

function ai_add_options(){
  if(function_exists('add_options_page')){
    add_options_page('Adsense', 'Adsense', 9, basename(__FILE__), 'ai_options_subpanel');
  }
}

switch($_POST['action']){
case 'Save':

  update_option('ai_network', $_POST['ai_network']);

  if(isset($_POST['betatest'])) update_option('ai_betatest', "yes");
  else delete_option('ai_betatest');
  if(isset($_POST['notme'])) update_option('ai_notme', "yes");
  else delete_option('ai_notme');
  if(isset($_POST['googtestmode'])) update_option('ai_googtestmode', "yes");
  else delete_option('ai_googtestmode');
  
  if(isset($_POST['dontshowinstr'])) update_option('ai_dontshowinstr', "yes");
  
  update_option('ai_color_border', $_POST['ai_color_border']);
  update_option('ai_color_link', $_POST['ai_color_link']);
  update_option('ai_color_bg', $_POST['ai_color_bg']);
  update_option('ai_color_text', $_POST['ai_color_text']);
  update_option('ai_color_url', $_POST['ai_color_url']);

  update_option('ai_lra', $_POST['ai_pos']);
  update_option('ai_nads', $_POST['nads']);
  update_option('ai_nadspp', $_POST['nadspp']);
  update_option('ai_text_only', false);

  update_option('ai_client', $_POST['ai_client']);
  update_option('ai_channel', $_POST['ai_channel']);
  update_option('ai_client_ypn', $_POST['ai_client_ypn']);
  update_option('ai_channel_ypn', $_POST['ai_channel_ypn']);
  
  if($_POST['234x60'] == "on") update_option('ai_234x60', "checked=on");
  else update_option('ai_234x60', "");
  if($_POST['200x200'] == "on") update_option('ai_200x200', "checked=on");
  else update_option('ai_200x200', "");
  if($_POST['125x125'] == "on") update_option('ai_125x125', "checked=on");
  else update_option('ai_125x125', "");
  if($_POST['180x150'] == "on") update_option('ai_180x150', "checked=on");
  else update_option('ai_180x150', "");
  if($_POST['120x240'] == "on") update_option('ai_120x240', "checked=on");
  else update_option('ai_120x240', "");
  if($_POST['300x250'] == "on") update_option('ai_300x250', "checked=on");
  else update_option('ai_300x250', "");
  if($_POST['250x250'] == "on") update_option('ai_250x250', "checked=on");
  else update_option('ai_250x250', "");
  if($_POST['336x280'] == "on") update_option('ai_336x280', "checked=on");
  else update_option('ai_336x280', "");
  if($_POST['468x60'] == "on") update_option('ai_468x60', "checked=on");
  else update_option('ai_468x60', "");


  if($_POST['home'] == "on") update_option('ai_home', "checked=on");
  else update_option('ai_home', "");
  if($_POST['page'] == "on") update_option('ai_page', "checked=on");
  else update_option('ai_page', "");
  if($_POST['post'] == "on") update_option('ai_post', "checked=on");
  else update_option('ai_post', "");
  if($_POST['cat'] == "on") update_option('ai_cat', "checked=on");
  else update_option('ai_cat', "");
  if($_POST['archive'] == "on") update_option('ai_archive', "checked=on");
  else update_option('ai_archive', "");

  break;
}

function ai_options_subpanel(){
  if(get_option("ai_network", "") == "")
    update_option("ai_network", "Adsense");

  $ad_client = get_option('ai_client');
  $ad_channel = get_option('ai_channel');
  $ad_client_ypn = get_option('ai_client_ypn');
  $ad_channel_ypn = get_option('ai_channel_ypn');
  $adnetwork = get_option("ai_network", "Adsense");

  $lra = get_option('ai_lra');
  $nads = get_option('ai_nads');
  $nadspp = get_option('ai_nadspp');
  $text_only = get_option('ai_text_only');

  $ai_color_border = get_option('ai_color_border');
  $ai_color_link = get_option('ai_color_link');
  $ai_color_bg = get_option('ai_color_bg');
  $ai_color_text = get_option('ai_color_text');
  $ai_color_url = get_option('ai_color_url');
  
?>
<div class="wrap"> 
  <h2><?php _e('Adsense Injection!', 'wpai') ?></h2> 
  <form name="form1" method="post">
	<input type="hidden" name="stage" value="process" />

	<fieldset class="options">
		<legend><?php _e('Options', 'wpai') ?></legend>
<?php if(get_option('ai_dontshowinstr', "no") != "yes"){ ?>
	<b>How to Use</b><br>
	<ul>
	<li>Get a Google Adsense account, a Yahoo Publisher's Network account, or both.</li>
	<li>Select which Ad Network you want to run on your blog.</li>
	<li>Enter your account details in the boxes below.</li>
  <li><input name=dontshowinstr type=checkbox>Don't show these instructions anymore.</li>
  <?php } ?>
		<table width="100%" cellspacing="2" cellpadding="5" class="editform" > 
		  <tr align="left" valign="top">
    <tr valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('Ad Network', 'wpai') ?></th>
      <td>
      <select name='ai_network'>
      <option value="random" <?php if($adnetwork == 'random') echo "SELECTED"; ?> >random
      <option value="YPN" <?php if($adnetwork == 'YPN') echo "SELECTED"; ?> >YPN
      <option value="Adsense" <?php if($adnetwork == 'Adsense') echo "SELECTED"; ?> >Adsense
      </select></td> 
      <td align=right colspan=5>
      <input type="submit" name="action" value="<?php _e('Save', 'wpai') ?>" />
      </td>
    <tr>
			<th width="30%" scope="row" style="text-align: left"><?php _e('Adsense ID', 'wpai') ?></th>
			<td><input type="text" name="ai_client" id="ai_client" style="width: 80%;" cols="50" value="<?php echo $ad_client; ?>"></td></tr>
		  <tr align="left" valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('Adsense Channel', 'wpai') ?></th>
			<td><input type="text" name="ai_channel" id="ai_channel" style="width: 80%;" cols="50" value="<?php echo $ad_channel ; ?>"></td></tr>
		  <tr align="left" valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('YPN Partner ID', 'wpai') ?></th>
			<td><input type="text" name="ai_client_ypn" id="ai_client_ypn" style="width: 80%;" cols="50" value="<?php echo $ad_client_ypn; ?>"> (Optional)</td></tr>
		  <tr align="left" valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('YPN Section (Channel)', 'wpai') ?></th>
			<td><input type="text" name="ai_channel_ypn" id="ai_channel_ypn" style="width: 80%;" cols="50" value="<?php echo $ad_channel_ypn ; ?>"> (Optional)</td></tr>
		  <tr valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('Ad Formats To Randomize', 'wpai') ?></th>

			<td>
			<INPUT TYPE=CHECKBOX NAME="125x125" <?php echo get_option('ai_125x125'); ?>>125x125<BR>
			<INPUT TYPE=CHECKBOX NAME="180x150" <?php echo get_option('ai_180x150'); ?>>180x150<BR>
			<INPUT TYPE=CHECKBOX NAME="120x240" <?php echo get_option('ai_120x240'); ?>>120x240<BR>
			<INPUT TYPE=CHECKBOX NAME="234x60" <?php echo get_option('ai_234x60'); ?>>234x60<BR>
			<INPUT TYPE=CHECKBOX NAME="200x200" <?php echo get_option('ai_200x200'); ?>>200x200<BR>
			<INPUT TYPE=CHECKBOX NAME="250x250" <?php echo get_option('ai_250x250'); ?>>250x250<BR>
			<INPUT TYPE=CHECKBOX NAME="300x250" <?php echo get_option('ai_300x250'); ?>>300x250<BR>
			<INPUT TYPE=CHECKBOX NAME="336x280" <?php echo get_option('ai_336x280'); ?>>336x280<BR>
			<INPUT TYPE=CHECKBOX NAME="468x60" <?php echo get_option('ai_468x60'); ?>>468x60<BR>
      </td>
      </tr>
      
      <tr align="left" valign="top">
        <th width="30%" scope="row" style="text-align: left"><?php _e('Colors', 'wpai') ?></th>
            <td>
			<table><tr><td>Color Border:</td><td><input type="text" name="ai_color_border" id="ai_color_border" cols="50" value="<?php echo $ai_color_border; ?>"></td></tr>
			<tr><td>Color Link:</td><td><input type="text" name="ai_color_link" id="ai_color_link" cols="50" value="<?php echo $ai_color_link; ?>"></td></tr>
			<tr><td>Color Background:</td><td><input type="text" name="ai_color_bg" id="ai_color_bg" cols="50" value="<?php echo $ai_color_bg; ?>"></td></tr>
			<tr><td>Color Text:</td><td><input type="text" name="ai_color_text" id="ai_color_text" cols="50" value="<?php echo $ai_color_text; ?>"></td></tr>
			<tr><td>Color URL:</td><td><input type="text" name="ai_color_url" id="ai_color_url" cols="50" value="<?php echo $ai_color_url; ?>"></td></tr>
			</tr></table>
			</td></tr>
	
		<tr valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('Number of Ads to Show', 'wpai') ?></th>
      <td>
      <select name='nads'>
      <option value="0" <?php if($nads == 0) echo "SELECTED"; ?> >0
      <option value="1" <?php if($nads == 1) echo "SELECTED"; ?> >1
      <option value="2" <?php if($nads == 2) echo "SELECTED"; ?> >2
      <option value="3" <?php if($nads == 3) echo "SELECTED"; ?> >3
      </select>

      </td> 
    </tr>
		<tr valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('Number of Ads Per Post', 'wpai') ?></th>
      <td>
      <select name='nadspp'>
      <option value="0" <?php if($nadspp == 0) echo "SELECTED"; ?> >0
      <option value="1" <?php if($nadspp == 1) echo "SELECTED"; ?> >1
      <option value="2" <?php if($nadspp == 2) echo "SELECTED"; ?> >2
      <option value="3" <?php if($nadspp == 3) echo "SELECTED"; ?> >3
      </select> &nbsp;&nbsp;(This is for multiple ads displayed on single post pages)

      </td> 
    </tr>

    <tr valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e('Ad Positioning', 'wpai') ?></th>
      <td>
      <select name='ai_pos'>
      <option value="random" <?php if($lra == 'random') echo "SELECTED"; ?> >random
      <option value="left" <?php if($lra == 'left') echo "SELECTED"; ?> >left
      <option value="right" <?php if($lra == 'right') echo "SELECTED"; ?> >right
      <option value="center" <?php if($lra == 'center') echo "SELECTED"; ?> >center
      </select></td> 
		  <tr valign="top">
			<th width="30%" scope="row" style="text-align: left"><?php _e("Don't Show On These Pages", 'wpai') ?></th>

			<td>
			<INPUT TYPE=CHECKBOX NAME="home" <?php echo get_option('ai_home'); ?>>home page<BR>
			<INPUT TYPE=CHECKBOX NAME="page" <?php echo get_option('ai_page'); ?>>static pages<BR>
			<INPUT TYPE=CHECKBOX NAME="post" <?php echo get_option('ai_post'); ?>>post pages<BR>
			<INPUT TYPE=CHECKBOX NAME="cat" <?php echo get_option('ai_cat'); ?>>category pages<BR>
			<INPUT TYPE=CHECKBOX NAME="archive" <?php echo get_option('ai_archive'); ?>>archive pages<BR>
      </td>
      </tr>
    <tr>
    <td colspan=5><input name=betatest type=checkbox <?php if(get_option("ai_betatest") == "yes") echo "checked"; ?>>Only let me see the ads!</td>
    </tr><tr>
    <td colspan=5><input name=notme type=checkbox <?php if(get_option("ai_notme") == "yes") echo "checked"; ?>>Don't make me see the ads! (What am I, a reader?)</td>
    </tr><tr>
    <td colspan=5><input name=googtestmode type=checkbox <?php if(get_option("ai_googtestmode") == "yes") echo "checked"; ?>>Insert google_adtest="on"; when I'm looking at my own blog.</td>
    </tr>

    <tr>
      <td align=right colspan=5>
      <input type="submit" name="action" value="<?php _e('Save', 'wpai') ?>" />
      </td>
    </tr>
    <tr>
    <td colspan=5>
	<b>Notes</b><br>
	<ul><li>If you don't want to show any ads on a specific post, put &lt;!--noadsense--&gt; in the post.</li>
	<li>If you want ads to start below a certain point, put &lt;!--adsensestart--&gt; at that point.  It's just like the &lt;!--more--&gt; deal except for ads.</li>
	</ul>
    </td>
    </tr>
    
		</table>
	</fieldset>
	
	 
  </form> 
</div>
<?php 

}

add_action('admin_menu', 'ai_add_options');

function ai_install() {

  if(get_option('ai_client') == "") {
    update_option('ai_network', "Adsense");
    update_option('ai_lra', "random");
    update_option('ai_nads', 3);
    update_option('ai_nadspp', 1);
    update_option('ai_text_only', false);
  }
}
if (isset($_GET['activate']) && $_GET['activate'] == 'true') {
   add_action('init', 'ai_install');
}

function ai_pickalign($tag){
  if($tag == "left")
    return '<div style="float: left;">';
  if($tag == "right")
    return '<div style="float: right;">';
  if($tag == "center")
    return '<div style="text-align: center;">';
  else
    return ai_pickalign(rand(0,10)<5?"left":"right");
}

function ai_picksize(){
  $sizes = array();
  if(strlen(get_option('ai_234x60'))) $sizes[] = "234x60";
  if(strlen(get_option('ai_200x200'))) $sizes[] = "200x200";
  if(strlen(get_option('ai_125x125')))
    $sizes[] = "125x125";
  if(strlen(get_option('ai_180x150')))
    $sizes[] = "180x150";
  if(strlen(get_option('ai_120x240')))
    $sizes[] = "120x240";
  if(strlen(get_option('ai_300x250')))
    $sizes[] = "300x250";
  if(strlen(get_option('ai_250x250')))
    $sizes[] = "250x250";
  if(strlen(get_option('ai_468x60')))
    $sizes[] = "468x60";
  if(strlen(get_option('ai_336x280')))
    $sizes[] = "336x280"; // addition by K2xL.com

  return $sizes[rand(0, sizeof($sizes)-1)];
}

//you can only show one network at a time.
$ai_loadnetwork = "";

function ai_genadcode(){
  global $user_level, $ai_loadnetwork;
  $size = ai_picksize();
  $width = substr($size, 0, 3);
  $height = substr($size, 4, 3);
    
  $client = get_option('ai_client');
  $channel = get_option('ai_channel');
  $client_ypn = get_option('ai_client_ypn');
  $channel_ypn = get_option('ai_channel_ypn');
  
  $color_border = get_option('ai_color_border');
  $color_link = get_option('ai_color_link');
  $color_bg = get_option('ai_color_bg');
  $color_text = get_option('ai_color_text');
  $color_url = get_option('ai_color_url');
  
  $retstr = "";
  $adnetwork = $ai_loadnetwork;
  if($adnetwork == "")
    $adnetwork = get_option("ai_network", "Adsense");
  if($adnetwork == "random"){
    $adnetwork = (rand(0,1)==0?"YPN":"Adsense");
  }
  $ai_loadnetwork = $adnetwork;
  if($adnetwork == "YPN"){
    $retstr = '<script language="JavaScript">
<!--
ctxt_ad_partner = "'.$client_ypn.'";
ctxt_ad_section = "'.$channel_ypn.'";
ctxt_ad_bg = "";
ctxt_ad_width = '.$width.';
ctxt_ad_height = '.$height.';
ctxt_ad_bc = "'.$color_bg.'";
ctxt_ad_cc = "'.$color_border.'";
ctxt_ad_lc = "'.$color_link.'";
ctxt_ad_tc = "'.$color_text.'";
ctxt_ad_uc = "'.$color_url.'";
// -->
</script>
<script language="JavaScript" src="http://ypn-js.overture.com/partner/js/ypn.js">

</script>';

  }
  else{
    $retstr = '<script type="text/javascript"><!--
';
  if(get_option('ai_googtestmode') == "yes" && $user_level > 8)
    $retstr .= 'google_adtest="on";
';

  $retstr .= 'google_ad_client = "'.$client.'";
google_alternate_color = "FFFFFF";
google_ad_width = '.$width.';
google_ad_height = '.$height.';
google_ad_format = "'.$size.'_as";
google_ad_type = "text_image";
google_ad_channel ="'.$channel.'";
google_color_border = "'.$color_border.'";
google_color_link = "'.$color_link.'";
google_color_bg = "'.$color_bg.'";
google_color_text = "'.$color_text.'";
google_color_url = "'.$color_url.'";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>';
  }

  return $retstr;
}

$ai_adsused = 0;

function ai_the_content($content){
  global $doing_rss;
  if(is_feed() || $doing_rss)
    return $content;
  if(strpos($content, "<!--noadsense-->") !== false) return $content;
  
  if(is_home() && get_option('ai_home') == "checked=on") return $content;
  if(is_page() && get_option('ai_page') == "checked=on") return $content;
  if(is_single() && get_option('ai_post') == "checked=on") return $content;
  if(is_category() && get_option('ai_cat') == "checked=on") return $content;
  if(is_archive() && get_option('ai_archive') == "checked=on") return $content;
  
  global $ai_adsused, $user_level;
  if(get_option('ai_betatest') == "yes" && $user_level < 8)
    return $content;
  if(get_option('ai_notme') == "yes" && $user_level > 8)
    return $content;

  $numads = get_option('ai_nads');
  if(is_single())
    $numads = get_option('ai_nadspp');

  $content_hold = "";
  if(strpos($content, "<!--adsensestart-->") !== false){
    $content_hold = substr($content, 0, strpos($content, "<!--adsensestart-->"));
    $content = substr_replace($content, "", 0, strpos($content, "<!--adsensestart-->"));
  }

  while($ai_adsused < $numads)
  {
    $poses = array();
    $lastpos = -1;
    $repchar = "<p";
    if(strpos($content, "<p") === false)
      $repchar = "<br";

    while(strpos($content, $repchar, $lastpos+1) !== false){
      $lastpos = strpos($content, $repchar, $lastpos+1);
      $poses[] = $lastpos;
    }
    
    //cut the doc in half so the ads don't go past the end of the article.  It could still happen, but what the hell
    $half = sizeof($poses);
    $adsperpost = $ai_adsused+1;
    if(!is_single())
      $half = sizeof($poses)/2;

    while(sizeof($poses) > $half)
      array_pop($poses);

    $pickme = $poses[rand(0, sizeof($poses)-1)];
    
    $replacewith = ai_pickalign(get_option('ai_lra'));
    $replacewith .= ai_genadcode()."</div>";
    
    $content = substr_replace($content, $replacewith.$repchar, $pickme, 2);
    $ai_adsused++;
    if(!is_single())
      break;
  }

  return $content_hold.$content;
}

add_filter('the_content', 'ai_the_content');

?>