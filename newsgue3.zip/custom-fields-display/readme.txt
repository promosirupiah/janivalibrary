=== Custom Fields Display ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: custom fields display,meta filter,custom fields,display custom fields,meta-data,display meta-data,the_meta,post meta data,display post meta
Requires at least: 2.9
Tested up to: 4.4
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom fields display in post content.You have option to specific custom filds display in post content in any theme.
== Description ==

Custom fields display in post content.You have option to specific custom filds display in post content in any theme.

**features**

- Custom fields display in front end without edit existing theme.
- Select which filed visible.
- customizes display order.

More Detail : http://socialcms.wordpress.com/

== Installation ==


1. Upload the **custom-fields-display** folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go **Custom Fields Display** in admin menu and set custom field which you want to dispaly in front end


== Frequently Asked Questions ==

N/A

== Screenshots ==

1. screenshot-1.png  : screen shot admin custom field post section.
2. screenshot-2.png  : screen shot admin custom fields display  plugin section.
3. screenshot-3.png  : screen shot admin custom fields display  plugin section with select custom field for dispaly.
4. screenshot-4.png  : screen shot admin custom fields display  plugin section with select custom field for dispaly and change display order.
5. screenshot-5.png  : screen shot front end section.


== Changelog ==

= 1.1 =
* Add custom field display order setting option.

= 1.0 =
* Initial release

== Upgrade Notice ==

N/A