=== Invisible Captcha ===
Contributors: Andrey Sorvin
Tags: comments, spam, spammer, anti-spam, captcha, protect, bot, robot, invisible, human
Tested up to: 3.5.1
Stable tag: 0.6.7
Requires at least: 2.0.2
License: GPL version 2

Smart invisible captcha for wordpress comments

== Description ==
Smart invisible captcha for wordpress comments. 
Visitors of your website don't need to enter letters and numbers. This small plugin automatically 100% protects your website from spam in comments.

== Upgrade Notice ==

= 0.6.7 =
fixed http://wordpress.org/support/topic/invisible_captcha_draw-returns-either-way

== Changelog ==

= 0.6.7 =
fixed http://wordpress.org/support/topic/invisible_captcha_draw-returns-either-way

= 0.6.6 =
Some minor bugs fixed

= 0.6.3 =
Fixed this: http://wordpress.org/support/topic/plugin-invisible-captcha-display-message-can-not-be-edited

= 0.6.2 =
Fixed "delete spam comment" action

= 0.6.1 =
Some minor bugs fixed with activation of the plugin.

= 0.6 =
Some settings added
Algorithm modified

= 0.5 =
Few small fixes
Now a valid xhtml code

= 0.4 =
Some bugs fixed

= 0.3 =
Some bugs fixed

= 0.1 = 
Creation of plugin

== Installation ==

1. Upload file `invisible-captcha.zip` to the `/wp-content/plugins/` directory and decompress all files from archive.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. Configure settings in Wordpress menu `Plugins` --> `Invisible Captcha`
4. Relax and forget about spam in your blog.

NB:
The Identifier (id) of the button for comment sending in your comment-page should be "submit".
Your theme must include file `footer.php`

== How to uninstall Invisible Captcha ==

Almost all you have to do is deactivate the plugin on the plugins page. 

== Frequently Asked Questions ==

= How can I check if invisible-captcha is working? =
- Just check out the `Spam-comments` section on WordPress-admin page.

== Screenshots ==

No screenshots. This plugin is invisible. 
It just works and marks spam-comments as spam-comments. 