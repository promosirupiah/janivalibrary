<?php
/*
Plugin Name: Vox Crossposter
Plugin URI: http://www.acedanger.com/vox-crossposter/
Description: Automatically copies new posts to Vox as they are published. Editing or deleting a post will NOT be replicated on the Vox post.  This is due to the fact that there is no Vox API yet.
Version: 0.4
Author: <a href="http://www.acedanger.com">Pete Wood</a>
Author Blog: http://www.acedanger.com/
Author Company: http://www.platinumgrade.com/
**********************************************************************************
Copyright (c) 2008 Pete Wood   petewood@platinumgrade.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
********************************************************************************** 
	
NOTE: This uses the vox mobile blogging email address until the SixApart group creates an 
API for VOX like they have for LiveJournal.
*/
// this emails the details to Vox; this is where the "magic" actually happens
function pw_email_vox($post_id = 0) {
	//$db_link = mysql_connect('db_server','db_user','db_pw') or die(mysql_error());
	//$db_name = mysql_select_db('db_name', $db_link) or die(mysql_error());
	
	// no post id, can't do anything
	if(!$post_id) { return $post_id; }
	
	// test to see if user chose the 'Do Not Crosspost' option in the sidebar
	if($_POST['vox_crosspost'] == 0) { return $post_id; }
	
	$email_address = get_vox_email(); 	                    //write_log('email address: '.addslashes($email_address));
	$email_headers = create_email_headers();                //write_log('email header: '.addslashes($email_headers));
	$email_subject = get_subject($post_id);                 //write_log('email subject: '.addslashes($email_subject));
	$email_body = get_body($post_id, $_POST['vox_header']); //write_log('email body: '.addslashes($email_body));
	
	if(isset($email_address) && isset($email_headers) && isset($email_subject) && isset($email_body)) {
		if(!mail($email_address, $email_subject, $email_body, $email_headers)) { /*write_log('mail not sent');*/}
		/*else { write_log('mail sent'); } */
	}
	/* else { write_log('something not set, no email sent'); }*/
	
	return $post_id;
}

function get_vox_email() {
	return get_settings('vox_moblog');
}

function get_subject($post_id) {
	$post = get_post($post_id);
	
	if($post->post_title) {	return $post->post_title; }
	else { return 'No Subject Found'; }
}

function create_email_headers() {
	$email_headers  = 'From: '.get_settings('blogname').' <'.get_settings('admin_email').'>'."\r\n"; 
	$email_headers .= 'X-Mailer: PHP/'.phpversion()."\r\n";
	$email_headers .= 'MIME-Version: 1.0'."\r\n";
	$email_headers .= 'Content-type: text/html; charset=utf-8'."\r\n";
	
	return $email_headers;
}

function get_body($post_id, $header_loc) {
	$blog_name = get_settings('blogname');
	$permalink = get_permalink($post_id);
	$post = get_post($post_id);	
	$post_content = $post->post_content;
	
	$post_header  = '<p style="border: 1px solid black; padding: 3px;"><strong>';
	$post_header .= 'Originally published at <a href="'.$permalink.'">'.$blog_name.'</a>. ';
	$post_header .= 'You can comment here or <a href="'.$permalink.'#comments">there</a>.';
	$post_header .= '</strong></p>';

	//write_log('post#: '.$post_id.' post content: '.$post_content);
	switch ($header_loc) {
    case 'TOP':
      $email_body = $post_header.$post_content;
      break;
    case 'BOTTOM':
      $email_body = $post_content.$post_header;
      break;
    case 'OFF':
      $email_body = $post_content;
      break;
  }
      
	return $email_body;
}

//to create a logging feature, create a connection to whatever database and call this function
function write_log($message){
	$sql = "INSERT INTO log VALUES (NULL, NOW(), '".addslashes($message)."')";
	mysql_query($sql) or die(mysql_error());	
}

// Now we set that function up to execute when the admin_footer action is called
add_action('publish_post', 'pw_email_vox');

// Hook the admin_menu display to add admin page
add_action('admin_menu', 'vox_admin_menu');
function vox_admin_menu() {
	add_submenu_page('options-general.php', 'Vox X-Poster', 'Vox X-Poster', 8, 'Vox X-Poster', 'vox_submenu');
}

// Admin page header
add_action('admin_head', 'vox_admin_head');
	function vox_admin_head() {
}
if(get_option('vox_moblog') != "") {
	add_action('dbx_post_sidebar', 'vox_sidebar');
}

// The admin page; form for user to set Vox Moblog address
function vox_submenu() {
	if ($_REQUEST['save']) { 
		// if option does not exist, create it, else update the value
		if(!get_settings('vox_moblog')) {
			//delete, just in case :P
			delete_option('vox_moblog');
			delete_option('vox_post_header');
			add_option('vox_moblog', $_POST['vox_moblog'], 'Vox Mobile Blogging Email Address', 'yes');
			add_option('vox_post_header', $_POST['vox_post_header'], 'Vox Post Header', 'yes');
		}
		else {
			update_option('vox_moblog', $_POST['vox_moblog']);
			update_option('vox_post_header', $_POST['vox_post_header']);
			echo '<div id="message" class="updated fade"><p><strong>';
			_e('Options saved.');
			echo '</strong></p></div>';
		}
	}
?>
<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">

<div class="wrap" id="vox_options">
<fieldset id="vox_sites">
<h3>Vox Crossposter Options</h3>
		<p>Put Vox Moblog email address here <input type="input" name="vox_moblog" value="<? echo get_settings('vox_moblog'); ?>"/></p>
		<label>Post header</label>
		  <input type="radio" name="vox_post_header" value="TOP" <? if(get_settings('vox_post_header') == 'TOP') { echo 'checked="checked"'; } ?> /> Top
      <input type="radio" name="vox_post_header" value="BOTTOM" <? if(get_settings('vox_post_header') == 'BOTTOM') { echo 'checked="checked"'; } ?> /> Bottom
      <input type="radio" name="vox_post_header" value="OFF" <? if(get_settings('vox_post_header') == 'OFF') { echo 'checked="checked"'; } ?> /> Off
		<p class="submit"><input name="save" id="save" tabindex="3" value="Save Changes" type="submit" /></p>
</fieldset>
</div>

<div class="wrap">
<p>
<a href="http://www.acedanger.com/vox-crossposter/">Vox Crossposter</a> is copyright &copy;2006 by <a
href="http://www.acedanger.com/">Pete Wood</a>, released under the GNU GPL version 2
or later. If you like the Vox Crossposter, please send a link my way so other folks can
find out about it. If you have any problems or good ideas, <a
href="mailto:petewood@platinumgrade.com">mail me</a>.
</p>
</div>

</form>
<?php
}

//sidebar options - crosspost entry or don't; will be on the post creation screen
function vox_sidebar() {
	global $post;
?>
	<fieldset class="dbx-box">
		<h3 class="dbx-handle"><?php _e('Vox', Vox); ?>:</h3>
		<div class="dbx-content">
			<label for="vox_crosspost_go" class="selectit">
			<input id="vox_crosspost_go" type="radio" name="vox_crosspost" value="1"<? checked(get_post_meta($post->ID, 'no_vox', true), 0); ?>/>
			<?php _e('Crosspost'); ?>
			</label>
			<label for="vox_crosspost_nogo" class="selectit">
			<input id="vox_crosspost_nogo" type="radio" name="vox_crosspost" value="0"<? checked(get_post_meta($post->ID, 'vox', true), 1); ?>/>
			<?php _e('Do not crosspost'); ?>
			</label><br />
			<label for="vox_crosspost_header_top" class="selectit">
			<input id="vox_crosspost_header_top" type="radio" name="vox_header" value="TOP" <? if(get_settings('vox_post_header') == 'TOP') { echo 'checked="checked"'; } ?> />
			<?php _e('Header on top'); ?>
			</label>
			<label for="vox_crosspost_header_bottom" class="selectit">
			<input id="vox_crosspost_header_bottom" type="radio" name="vox_header" value="BOTTOM" <? if(get_settings('vox_post_header') == 'BOTTOM') { echo 'checked="checked"'; } ?> />
			<?php _e('Header on bottom'); ?>
			</label>
			<label for="vox_crosspost_header_off" class="selectit">
			<input id="vox_crosspost_header_off" type="radio" name="vox_header" value="OFF" <? if(get_settings('vox_post_header') == 'OFF') { echo 'checked="checked"'; } ?> />
			<?php _e('No header'); ?>
			</label>
		</div>
	</fieldset>
<?php
}
?>