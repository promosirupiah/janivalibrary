<?php
/*
Plugin Name: TanTanNoodles Version Checker
Plugin URI: http://tantannoodles.com/toolkit/version-check/
Description: Checks for updates to plugins released by TanTanNoodles. Note: Compatible only with WordPress 2.1.
Version: 0.1
Author: Joe Tan
Author URI: http://tantannoodles.com/

$Revision: 14 $
$Date: 2007-03-08 23:57:24 -0500 (Thu, 08 Mar 2007) $
*/
class TanTanVersionCheck {
    function TanTanVersionCheck() {
        add_action('admin_menu', array(&$this, 'addhooks'));
        add_action('load-plugins_page_tantan/version-check', array(&$this, 'load_scripts'), -1);
        add_action('load-index.php', array(&$this, 'load_scripts_dashboard'), -1);
        
    }
    function addhooks() {
        add_submenu_page('plugins.php', 'TanTanNoodles Toolkit Updates', 'TanTanNoodles Toolkit Updates', 10, __FILE__, array(&$this, 'admin'));
        
    }
    function load_scripts_dashboard() {
        wp_enqueue_script("prototype");
        add_action('admin_print_scripts', array(&$this, 'print_scripts_dashboard'));
    }
    function print_scripts_dashboard() {
        ?>
        <script type="text/javascript">
        function printUpdateNotice(project, title, link, installed, latest) {
            if (window._tantanChecked == null) window._tantanChecked = 0;
            else window._tantanChecked++;
            var div = document.getElementById('tantan-check-'+project);
            var html = '';
            if (window._tantanChecked <= 0) {
                html = '<h3>Plugin Updates</h3>' +
                '<p>There is an update available to one or more of the following plugins. <a href="plugins.php?page=tantan/version-check.php">More details &gt;</a></p>';
            }
            
            html += '<p style="margin-left:10px;"><a href="'+link+'">'+title+'</a><br />' +
                'Installed: '+installed+' &nbsp; Latest: '+latest+'</p>';
            div.innerHTML = html
        }
        function printNoUpdates() {
        }
        </script>
        <?php        
    }
    function load_scripts() {
        wp_enqueue_script("prototype");
        add_action('admin_print_scripts', array(&$this, 'print_scripts'));
    }
    function print_scripts() {
        ?>
        <script type="text/javascript">
        function printUpdateNotice(project, title, link, installed, latest, download) {
            if (window._tantanChecked == null) window._tantanChecked = 0;
            else window._tantanChecked++;
            
            var html = '';
            
            html += '<p style="margin-left:10px;border:1px solid red;padding:5px;"><a href="'+link+'">'+title+'</a><br />' +
                'Installed: <strong>'+installed+'</strong><br />Latest: <strong>'+latest+ '</strong> (<a href="'+download+'">download</a>)</p>';
            $('tantan-check-'+project).innerHTML = html
            $('tantan-checking').style.display='none';
            $('tantan-update-avail').style.display='block';
        }
        function printNoUpdates(project, title, link, installed, latest) {
            var html = '';
            html += '<p style="margin-left:10px;"><a href="'+link+'">'+title+'</a><br />'+
            '<em>No updates available</em></p>' 
            
            $('tantan-check-'+project).innerHTML = html;
            $('tantan-checking').style.display='none';
        }
        </script>
        <style type="text/css">
        fieldset.options { clear:left; border:1px solid #ccc; }
        fieldset.options legend { font-family: Georgia,"Times New Roman",Times,serif; font-size: 22px; }
        div.updates { width:200px; min-height:300px; margin-left:15px; float:right; }
        #tantan-update-avail { display:none; }
        </style>
        <?php        
    }
    function admin () {
        ?>
        <div class="wrap">
        <h2>TanTanNoodles Toolkit Updates</h2>
        <div class="updates">
            <h3>Installed Plugins</h3>
            <div id="tantan-checking">Now checking for updates...</div>
            <p id="tantan-update-avail">There is an update to one or more of the following plugins released by <a href="http://tantannoodles.com/toolkit/">Tan Tan Noodles</a>:</p>
            
            <?php do_action('tantan_update_notices'); ?>
            <h3>More Plugins</h3>
            <p>
                Want more WordPress goodness? Check out the <a href="http://tantannoodles.com/toolkit/" style="white-space:nowrap">TanTanNoodles Toolkit &gt;</a>
            </p>
            <h3>Subscribe</h3>
            <p>
            <a href="http://feeds.feedburner.com/TanTanToolkit" rel="alternate" type="application/rss+xml"><img src="http://www.feedburner.com/fb/images/pub/feed-icon16x16.png" alt="" style="vertical-align:middle;border:0"/></a>&nbsp;<a href="http://feeds.feedburner.com/TanTanToolkit" rel="alternate" type="application/rss+xml">Subscribe to updates with your RSS Reader</a><br />
            <small>feeds.feedburner.com/TanTanToolkit</small>
            </p>
            
            <h3>Support</h3>
            <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
            <p>
            <input type="image" align="right" src="https://www.paypal.com/en_US/i/btn/x-click-but04.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
            If you find these plugins helpful, please consider donating a few dollars to help support their development. Thanks!
            </p>
            <input type="hidden" name="cmd" value="_s-xclick">
            <input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHRwYJKoZIhvcNAQcEoIIHODCCBzQCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBkW0XfGZbagp/PWqgvKh7s4nD3xMUnnv9i84qO8o/3ZUT4X/rZsZZ/2v0KF1iViatR7woW9g/rXc+jR4ZxRiMsfV3uJogRj9UPq0x31XVfhk+XmBwwJQNryzEDKmgTQz1+XBxIU3FO8cHn2VmFt5WDHbCndOWMxAEi/xl/JS2XwjELMAkGBSsOAwIaBQAwgcQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIfghXYl7K5LGAgaCAdm2TDmA02p48jumOq0PHluOtlno3YSlY854r1TvzBJsh8IwXsKIWfvyG2XoDmp/398/bpKD+LYLsy30yHPbgJoKq16QHCfw6kMIOaidrkNixIf2a4u3w+nnPNMvNZRP7+gMsaBGvTZ9yZ9smhRGDgBqpHZvV38Rl0JF69yl5BxhWApjj7j5L/wlizRobC6AmHn24H/BjORFrCInYSB6toIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDUxMjA3MDIzMTM1WjAjBgkqhkiG9w0BCQQxFgQU/EtXLlgTwKepwiUAKUMtHtwNVl8wDQYJKoZIhvcNAQEBBQAEgYBhIbCW+2saICynd5IbBMO1Ykr0vTDav1gO7FF8jermCkGcvoxLmOQOOXpKH9VPHj3a56SP8xS27lzbDvZ8TPFvcv0Afd7gGtjWYG1QkuKqs78ARtzIbSPuVngCqriAq4rZteJjWvMh4NIoL4qzXiOXdw5VId+QLUf0yVy2KLGIbw==-----END PKCS7-----">
            </form>
        </div>
        <form>
        <fieldset class="options">
            <input type="hidden" name="action" value="saveoptions">
            <input type="checkbox" id="doVersionCheck" name="options[doVersionCheck]" value="1" checked="checked" disabled="disabled" />
            <label for="doVersionCheck">Automatically check for updates to TanTanNoodles Toolkit WordPress plugins</label><br />
            <p style="font-size:0.9em">
            To disable, simply de-activate the <b>TanTanNoodles Version Checker</b> plugin from your installed <a href="plugins.php">plugin's list</a>.
            </p>
        </fieldset>
        </form>
        
        <h3>Latest News...</h3>
        <div id="tantan-news">
        <?php $this->getNewsUpdates();?>
        </div>
        <br style="clear:both;">
        </div>
        <?php
    }

    function versionCheck($projectID, $version) {
        $func = 'global $TanTanVersionCheck; $TanTanVersionCheck->printAJAXCall(\''.$projectID.'\', \''.$version.'\');';
        add_action('activity_box_end', create_function('', $func));
        add_action('tantan_update_notices',  create_function('', $func));
    }
    function printAJAXCall($projectID, $version) {
        ?>
        <div id="tantan-check-<?php echo $projectID?>"></div>
        <?php
        $version = trim($version);
        if (version_compare(get_bloginfo('version'), '2.1', '>=')) {
            $this->printAJAXCallProtoType($projectID, $version);
        } else {
            $this->printAJAXCallSack($projectID, $version);
        }
    }
    function printAJAXCallProtoType($projectID, $version) {
        ?>
            <script type="text/javascript">
                Event.observe( window, 'load', function () { new Ajax.Updater( 'tantan-check-<?php echo $projectID?>', '../wp-content/plugins/tantan/version-check.php?projectID=<?php echo $projectID;?>&version=<?php echo $version;?>&mode=AJAX', {evalScripts:true} ); }, false );
            </script>
        <?php
    }
    function getNewsUpdates() {
        //require_once(dirname(__FILE__).'/../../../wp-config.php');
        require_once(ABSPATH . WPINC . '/rss.php');
        $rss = @fetch_rss('http://feeds.feedburner.com/TanTanToolkit');
        if ( isset($rss->items) && 0 != count($rss->items) ):
        foreach (array_slice($rss->items, 0, 3) as $item ): ?>
        <a href="<?php echo wp_filter_kses($item['link']); ?>"><strong><?php echo wp_specialchars($item['title']); ?></strong></a> &#8212; <?php printf(__('%s ago'), human_time_diff(strtotime($item['pubdate'], time() ) ) ); ?><br />
        <p><?php echo $item['description']; ?></p>
        <?php
        endforeach;
        endif;
    }
    function getUpdateNotice($projectID, $version) {
        if (!$projectID) return;
        $cache = @file_get_contents(dirname(__FILE__).'/version-check.cache');
        if ($cache) $cache = unserialize($cache);
        else $cache = array();

        $response = '';
        if (!is_array($cache[$projectID]) || ($cache[$projectID]['time'] < (time() - 86400))) {
            require_once(dirname(__FILE__).'/lib/curl.php');
            $req = new TanTanCurl('http://tantannoodles.com/code/version-check.php?mode=JS&projectID='.$projectID.'&version='.$version);
            $req->setMethod('GET');
            $req->sendRequest();
            if ($req->response['code'] < 400) {
                $response = $req->getResponseBody();
            }
            $cache[$projectID] = array( 'time' => time(), 'cached' => $response);
            $fp = @fopen(dirname(__FILE__).'/version-check.cache', 'w');
            if ($fp) {
                @fwrite($fp, serialize($cache));
                @fclose($fp);
            }
        } else {
            $response = $cache[$projectID]['cached'];
        }
        echo $response;
    }
}
if (($_GET['mode'] == 'AJAX') && $_GET['projectID'] && $_GET['version']) {
    // called directly
    TanTanVersionCheck::getUpdateNotice($_GET['projectID'], $_GET['version']);
} elseif (ereg('/wp-admin/', $_SERVER['REQUEST_URI'])) { // only admin
    // called in plugin's page
    if (version_compare(get_bloginfo('version'), '2.1', '>=')) {
        $TanTanVersionCheck = new TanTanVersionCheck();
    }
}
?>