<?php
/*
Plugin Name: Xanga Cross Post
Plugin URI: http://tantannoodles.com/toolkit/xanga-crosspost/
Description: Cross post your blog entries to a Xanga account
Version: 0.6
Author: Joe Tan
Author URI: http://tantannoodles.com/
*/
if (ereg('/wp-admin/', $_SERVER['REQUEST_URI'])) { // just load in admin
    require_once(dirname(__FILE__).'/xanga/class-admin.php');
    $TanTanXangaPlugin =& new TanTanXangaPlugin();
}
function xanga_publish_future_post($post_ID) {
    require_once(dirname(__FILE__).'/xanga/class-admin.php');
    TanTanXangaPlugin::publish_post($post_ID);
}
add_action('publish_future_post', 'xanga_publish_future_post', 11, 1);
?>