#!/usr/bin/perl

use Getopt::Long;
use Net::Jaiku;
use DBI;
use Data::Dumper;

my $USAGE = qq|USAGE:\n$0 [--host localhost] --name wordpress --user username --pass password [--prefix wp_]\n|;

GetOptions (
	"prefix:s" => \my $table_prefix,
	"host:s"   => \my $db_host,
	"name=s"   => \my $db_name,
	"user=s"   => \my $db_user,
	"pass=s"   => \my $db_pass,
	"help"     => sub{ print $USAGE; exit },
);

die("Check the options and try again\n\n$USAGE") unless $db_name && $db_user && $db_pass;

$table_prefix ||= '';
$db_host      ||= 'localhost';


# Connect to the database
#======================================================================
my $dbh = DBI->connect(
	"dbi:mysql:database=$db_name;host=$db_host",
	$db_user,$db_pass,
	{mysql_auto_reconnect => 1}
);


# Set up some queries
#======================================================================
my $insert = $dbh->prepare("
	INSERT IGNORE INTO
		${table_prefix}jaiku_feed
		(jaiku_id, title, url, icon, avatar, created_at_gmt)
	VALUES
		(?, ?, ?, ?, ?, ?)
");

# Get our login information
#======================================================================
my ($jaiku_userkey) = $dbh->selectrow_array(
	"SELECT option_value FROM ${table_prefix}options WHERE option_name = 'jaiku_userkey'"
);

my ($jaiku_username) = $dbh->selectrow_array(
	"SELECT option_value FROM ${table_prefix}options WHERE option_name = 'jaiku_username'"
);


# Connect to Jaiku
#======================================================================
my $jaiku = new Net::Jaiku(
	username => $jaiku_username,
	userkey  => $jaiku_userkey
);


# Retrieve the feed
#======================================================================
my $feed = $jaiku->getMyFeed;
exit unless $feed;

my @stream = @{ $feed->stream };
foreach(@stream){

	(my $gmt = $_->created_at) =~ s/\s+GMT//;

	$insert->execute(
		$_->id, $_->title, $_->url, $_->icon, $_->user->avatar, $gmt
	);

}

