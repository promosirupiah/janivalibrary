<?php
/*
Plugin Name: JaikuPost
Plugin URI: http://wp-jaiku.googlecode.com/
Description: Cross-post your stories to Jaiku
Author: Rick Measham
Version: 0.05.00
Author URI: http://rick.measham.id.au/
*/


# Installation routine
#======================================================================
function jaiku_install(){
	global $wpdb;

	add_option('jaiku_username', '', 'Jaiku.com username', 0);
	add_option('jaiku_userkey',  '', 'Jaiku.com API key', 0);
	add_option('jaiku_default',  '', 'Cross-post to Jaiku.com by default', 0);

	# Create the table for mapping categories to icons
	#==================================================================
	$wpdb->query("
		CREATE TABLE
			".$wpdb->prefix."jaiku_cat2icon
		(
			rel_id int
				auto_increment,
			category_id int
				NOT NULL
				DEFAULT 0,
			icon_id int
				NOT NULL
				DEFAULT 0,

			PRIMARY KEY(rel_id)
		)
	");

	# Create the table for holding onto our jaikus
	#==================================================================
	$wpdb->query("
		CREATE TABLE
			".$wpdb->prefix."jaiku_feed
		(
			jaiku_id int
				NOT NULL
				DEFAULT 0,
			title varchar(255)
				NOT NULL
				DEFAULT '',
			url varchar(255)
				NOT NULL
				DEFAULT '',
			icon varchar(255)
				NOT NULL
				DEFAULT '',
			avatar varchar(255)
				NOT NULL
				DEFAULT '',
			created_at_gmt datetime
				NOT NULL
				DEFAULT '0000-00-00 00:00:00',

			PRIMARY KEY(jaiku_id)
		)
	");

}
add_action('activate_jaikupost/jaiku.php', 'jaiku_install');


# Admin Menu
#======================================================================
function jaiku_addadminmenus(){
	add_submenu_page('plugins.php', 'JaikuPost', 'JaikuPost', 5, 'jaiku_preferences', 'jaiku_preferences');
}
add_action('admin_menu', 'jaiku_addadminmenus');



# Admin Screen
#======================================================================
function jaiku_preferences(){

	if( isset( $_POST['jaiku_username'] ) ){
		update_option('jaiku_username', $_POST['jaiku_username']);
	}

	if( isset( $_POST['jaiku_userkey'] ) ){
		update_option('jaiku_userkey', $_POST['jaiku_userkey']);
	}

	# We deliberately check if jaiku_username is set rather than
	# jaiku_default because jaiku_default is only set when it is
	# true. And if we don't check, it gets set to 'no' every time.
	if( isset( $_POST['jaiku_username'] ) ){
		update_option('jaiku_default', (isset($_POST['jaiku_default']) && $_POST['jaiku_default'] == 'yes') ? 'yes' : 'no' );
	}

	?>
	<?php if ( !empty($_POST ) ) : ?>
		<div id="message" class="updated fade"><p><strong><?php _e('Options saved.') ?></strong></p></div>
	<?php endif; ?>

		<div class="wrap">
			<h2><?php _e('JaikuPost Configuration'); ?></h2>

			<form method="post" action="" id="jaiku-conf" style="margin: auto; width: 400px; ">

				<table class="editform" cellpadding="5" cellspacing="2" width="100%">
					<tbody>

						<tr>
							<th scope="row" valign="top" width="20%">
								<label for="jaiku_username">Jaiku Username:</label>
							</th>
							<td>
								<input type="text" name="jaiku_username" value="<?php echo get_option('jaiku_username'); ?>" />
							</td>
							<td></td>
						</tr>

						<tr>
							<th scope="row" valign="top" width="20%">
								<label for="jaiku_userkey">Jaiku API Key:</label>
							</th>
							<td>
								<input type="text" name="jaiku_userkey" value="<?php echo get_option('jaiku_userkey'); ?>" />
							</td>
							<td>
								<button type="button" onclick="window.open('http://jaiku.com/api/key', 'jaiku_api', 'width=300,height=100'); return false">Get API key from Jaiku</button>
							</td>
						</tr>

						<tr><td colspan="3"><hr /></td></tr>

						<tr>
							<th scope="row" valign="top" width="20%">
								<label for="jaiku_userkey">Default Behaviour:</label>
							</th>
							<td>
								<input type="checkbox" name="jaiku_default" value="yes"<?php if(get_option('jaiku_default') == 'yes'){ print " checked"; }?> />
								By default, send my new posts to Jaiku (<?php echo get_option('jaiku_default') ?>)
							</td>
							<td></td>
						</tr>
					</tbody>
				</table>

				<p class="submit">
					<input type="submit" name="Submit" value="<?php _e('Update Options �') ?>" />
				</p>

			</form>
		</div>
	<?php
}



# Post editing screen widget
#======================================================================
function jaiku_publishoption($post) {
	global $post_ID;

?>
<fieldset id="sendtojaiku" class="dbx-box">
	<h3 class="dbx-handle">Jaiku</h3>
	<div class="dbx-content">
		<?php $jaiku_sent = get_post_meta($post_ID, 'Sent to Jaiku', true); if($jaiku_sent != 'no' && $jaiku_sent != 'failed') : ?>

			<i>Sent to Jaiku</i><br>

			<label class="selectit">
				<input name="jaiku_send" type="radio" value="yes"> Resend on Publish
			</label>

			<label class="selectit">
				<input name="jaiku_send" type="radio" value="no" checked> Don't resend<br>
			</label>

		<?php else : ?>

			<label class="selectit">
				<input name="jaiku_send" type="radio" value="yes"<?php if(get_option('jaiku_default') == 'yes' && ! $jaiku_sent){ print " checked"; }?>> Send on Publish
			</label>

			<label class="selectit">
				<input name="jaiku_send" type="radio" value="no"<?php if(get_option('jaiku_default') != 'yes'){ print " checked"; }?>> Don't send
			</label>

		<?php endif ?>

	</div>
</fieldset>

<?php
}
add_action('dbx_post_sidebar', 'jaiku_publishoption');



# Business End: Cross post to Jaiku.com
#======================================================================
function jaiku_sendnow($post_id){
	global $wpdb;

	# Step 1: Check if we actually want/can publish this post
	#==================================================================

	if( get_option('jaiku_username') && get_option('jaiku_userkey') && $_POST['jaiku_send'] == 'yes' ){

		# Step 2: Generate a short URL
		#==============================================================
		$long_url = get_permalink($post_id);
		$short_url = $long_url;

		if( strlen($message . ' - ' . $short_url) > 140 ){
			$session = curl_init('http://metamark.net/api/rest/simple?long_url='.$long_url);
			curl_setopt($session, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($session, CURLOPT_HEADER, FALSE);
			$short_url = curl_exec($session);
			curl_close($session);
		}

		# Step 3: See if there's an icon we should use
		#==============================================================
		$cats = &get_the_category($post_id);
		$icon = '';
        foreach ( $cats as $cat ) {
			$icon = _getCategoryIcon( $cat->cat_ID );
			if( $icon ) break;
        }

		# Step 3: See if there's a location we should use
		#==============================================================
		$location = get_post_meta($post_ID, 'Location', true);

		# Step 4: Send to Jaiku
		#==============================================================
		$query = '';

		$message = $_POST['post_title'];
		if( stristr($short_url, 'ERROR') === FALSE ){
			while( strlen($message . ' - ' . $short_url) > 140 ){
				$message = substr($message,0,-1);
			}
			$message = $message . ' - ' . $short_url;
		}

		$query .= ($query ? '&' : '') . 'message=' . urlencode( $message );
		$query .= ($query ? '&' : '') . 'user=' . urlencode( get_option('jaiku_username') );
		$query .= ($query ? '&' : '') . 'personal_key=' . urlencode( get_option('jaiku_userkey') );

		$query .= ($query ? '&' : '') . 'method=presence.send';
		if($icon){
			$query .= ($query ? '&' : '') . 'icon='.$icon;
		}
		if($location){
			$query .= ($query ? '&' : '') . 'location='.$location;
		}

		$session = curl_init('http://api.jaiku.com/json');
		curl_setopt($session, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($session, CURLOPT_HEADER, FALSE);
		curl_setopt($session, CURLOPT_POST, TRUE);
		curl_setopt($session, CURLOPT_POSTFIELDS, $query);
		$jaiku_result = curl_exec($session);
		curl_close($session);

		# Step 5: Check the result
		#==============================================================

		$jaiku_result = (stristr($jaiku_result, '"ok"') !== FALSE)
			? $message
			: 'failed';
	} else {
		$jaiku_result = 'no';
	}

	# Step 6: Update the database
	#==================================================================
	$rv = $wpdb->query("
		DELETE FROM
			$wpdb->postmeta
		WHERE
			post_id = $post_id
			AND
			meta_key = 'Sent to Jaiku'
	");

	$rv = $wpdb->query("
		INSERT INTO
			$wpdb->postmeta
			(post_id, meta_key, meta_value)
		VALUES
			($post_id, 'Sent to Jaiku', '$jaiku_result')
	");

}
add_action('publish_post', 'jaiku_sendnow');



# Add icon selector to category editor
#======================================================================
function jaiku_categoryicon(){
	global $cat_ID;
	$category_id = $cat_ID;

	$jaikuIconById = Array(
		301 => 'car', 302 => 'alarmclock', 303 => 'loudspeaker', 304 => 'tram', 305 => 'casette', 306 => 'underware', 307 => 'rollerblade', 308 => 'uzi', 309 => 'scoop', 310 => 'bomb', 311 => 'bra', 312 => 'videotape', 313 => 'cigarettes', 314 => 'vinyl', 315 => 'champaign', 316 => 'airplain', 317 => 'bus', 318 => 'grumpy', 319 => 'coffee', 320 => 'camera', 321 => 'basketball', 322 => 'beer', 323 => 'binoculars', 324 => 'boiler', 325 => 'walk', 326 => 'wallclock', 327 => 'trashcan', 328 => 'tv', 329 => 'computing', 330 => 'videocamera', 331 => 'game', 332 => 'cone', 333 => 'driller', 334 => 'popcorn', 335 => 'playshirt', 336 => 'disc', 337 => 'event', 338 => 'exclamationmark', 339 => 'football', 340 => 'footballshoe', 341 => 'eat', 342 => 'gameboy', 343 => 'grenade', 344 => 'hand', 345 => 'hanger', 346 => 'hearingprotector', 347 => 'love', 348 => 'balloons', 349 => 'clock', 350 => 'barrier', 351 => 'laptop', 352 => 'megaphone', 353 => 'microwave', 354 => 'book', 355 => 'middlefinger', 356 => 'notes', 357 => 'question', 358 => 'rollator', 359 => 'shuttlecock', 360 => 'salt', 361 => 'scull', 362 => 'sk8', 363 => 'sleep', 364 => 'snorkeling', 365 => 'snowflake', 366 => 'soda', 367 => 'song', 368 => 'spraycan', 369 => 'sticks', 370 => 'storm', 371 => 'straitjacket', 372 => 'metro', 373 => 'luggage', 374 => 'sun', 375 => 'taxi', 376 => 'technics', 377 => 'toaster', 378 => 'train', 379 => 'wheelchair', 380 => 'zippo', 381 => 'icecream', 382 => 'movie', 383 => 'makeup', 384 => 'bandaid', 385 => 'wine', 386 => 'clean', 387 => 'blading', 388 => 'bike', 389 => 'pils', 390 => 'picnic', 391 => 'lifejacket', 392 => 'home', 393 => 'happy', 394 => 'toiletpaper', 395 => 'theatre', 396 => 'shop', 397 => 'search', 398 => 'cloudy', 399 => 'hurry', 400 => 'morning', 401 => 'car', 402 => 'baby-boy', 403 => 'baby-girl'
	);
	?>
		<script type="text/javascript">
			function showIcons(fld, onoff, offset){
				var select = document.getElementById(fld + 'select');
				select.style.display = (
					(onoff !== undefined && onoff) ||
					(onoff === undefined && select.style.display == 'none')
				) ? '' : 'none';
				if((onoff !== undefined && onoff || onoff == undefined) && offset) {
					select.style.postion = 'absolute';
					select.style.left = (offset.offsetLeft + 38) + 'px';
					select.style.top = (offset.offsetTop) + 'px';
				}
			}
			function setIcon(icon, icon_id, fld, frm){
				var preview = document.getElementById(fld + 'preview');
				while(preview.firstChild) preview.removeChild(preview.firstChild);
				if(icon_id > 0){
					var img = document.createElement('img');
					img.src = "http://jaiku.com/images/icons/web-"+icon+".gif";
					preview.appendChild(img);
				}
				document.getElementById(fld).value = icon_id;
				showIcons(fld, false);
			}

			// Try to move the icon selector back into the main form
			function addEvent(el,ev,fn){ if(el.addEventListener) el.addEventListener(ev,fn,false); else el.attachEvent('on'+ev, fn) }
			addEvent(window, 'load', function(){
				try {
					var catDiv = document.getElementById('editcat') || document.getElementById('addcat');
					var targetTable = catDiv.getElementsByTagName('table')[0];
					var sourceTbody = document.getElementById('iconSelector');
					if(targetTable && sourceTbody)
						targetTable.appendChild( sourceTbody );
					var jaikupost_icon = document.getElementById('jaikupost_icon');
					if(jaikupost_icon)
						jaikupost_icon.parentNode.removeChild(jaikupost_icon);
				} catch(e){
					// console.log(e)
				}
			});
		</script>
		<div id="jaikupost_icon">
			<h3>JaikuPost Icon</h3>
			<table class="editform" cellpadding="5" cellspacing="2" width="100%">
				<tbody id="iconSelector">
					<tr>
						<th scope="row" valign="top" width="33%"><label for="jaiku_categoryicon">Associated Jaiku icon:</label></th>
						<td width="67%">

							<div style="position:relative">
								<input name="jaiku_categoryicon" id="jaiku_categoryicon" value="" size="40" type="hidden">

								<div style="width: 36px; height: 36px; margin:0; padding: 0; border: 1px solid #b2b2b2; background-color: #f4f4f4; position:relative" id="jaiku_categoryiconpreview" onclick="showIcons('jaiku_categoryicon', undefined, this)">
									<?php $category_icon = $jaikuIconById[ _getCategoryIcon( $category_id ) ]; if( $category_icon ) : ?>
										<img src="http://jaiku.com/images/icons/web-<?php echo $category_icon ?>.gif" width="36" height="36" />
									<?php endif ?>
								</div>

								<div class="icons" id="jaiku_categoryiconselect" style="display: none; position: absolute; border: 5px solid #bbb; width: 518px">

								<img src="http://jaikugadget.googlecode.com/svn/trunk/images/icon-remove-icon.gif" width="36" height="36" style="display: inline; border-right: 1px solid #ccc; border-bottom: 1px solid #ccc; background-color: #fff" onclick="setIcon('', 0, 'jaiku_categoryicon')" /><?php foreach( $jaikuIconById as $id => $name ){
									print '<img src="http://jaiku.com/images/icons/web-'.$name.'.gif" width="36" height="36" style="display: inline; border-right: 1px solid #ccc; border-bottom: 1px solid #ccc; background-color: #fff" onclick="setIcon(\''.$name.'\', '.$id.', \'jaiku_categoryicon\')" />';
								} ?>
							</div>

						</td>
					</tr>
				</tbody>
			</table>
		</div>
	<?php
}
add_action('edit_category_form', 'jaiku_categoryicon');


# Save category icon
#======================================================================
function jaiku_categorysave($category_id){
	global $wpdb;

	$current_icon_id = _getCategoryIcon($category_id);

	if(isset($_POST['jaiku_categoryicon']) && $_POST['jaiku_categoryicon'] != $current_icon_id){

		$wpdb->query("
			DELETE FROM
				".$wpdb->prefix."jaiku_cat2icon
			WHERE
				category_id = $category_id
		");
		if(isset($_POST['jaiku_categoryicon'])){
			$icon_id = (int) $_POST['jaiku_categoryicon'];
			if($icon_id){
				$wpdb->query("
					INSERT INTO
						".$wpdb->prefix."jaiku_cat2icon
						(category_id, icon_id)
					VALUES (
						$category_id,
						$icon_id
					)
				");
			}
		}

	}
}
add_action('edited_category', 'jaiku_categorysave');
add_action('created_category', 'jaiku_categorysave');



# Utility routine to get the category icon -- not a callback
#======================================================================
function _getCategoryIcon($category_id){
	global $wpdb;

	return ($category_id > 0)
		? $wpdb->get_var("
			SELECT
				icon_id
			FROM
				".$wpdb->prefix."jaiku_cat2icon
			WHERE
				category_id = $category_id
			")
		: 0;

}



# Template functions -- see the docs re "Intermingle"
#======================================================================
$jaiku_intermingle = '';
function jaiku_can_intermingle(){
	global $post, $wpdb, $jaiku_intermingle;

	if($jaiku_intermingle && $jaiku_intermingle > $post->post_date_gmt){

		$clean_title = $wpdb->escape($post->post_title);
		$rv = $wpdb->get_var("
			SELECT
				COUNT(*)
			FROM
				".$wpdb->prefix."jaiku_feed
			WHERE
				created_at_gmt <= '".$jaiku_intermingle."'
				AND
				created_at_gmt > '".$post->post_date_gmt."'
				AND
				title NOT LIKE '".$clean_title."%'
		");

		return $rv;
	}

	$jaiku_intermingle = $post->post_date_gmt;
	return false;

}
function jaiku_intermingle($max = -1){
	global $post, $wpdb, $jaiku_intermingle;

	$site_url = get_option('siteurl');

	if($jaiku_intermingle && $jaiku_intermingle > $post->post_date_gmt){

		$clean_title = $wpdb->escape($post->post_title);
		$limit = ($max >= 0) ? "LIMIT $max" : '';

		$rv = $wpdb->get_results("
			SELECT
				avatar,
				title,
				url,
				icon,
				DATE_FORMAT( created_at_gmt, '%a %d %b %Y, %k:%i' ) as created_at
			FROM
				".$wpdb->prefix."jaiku_feed
			WHERE
				created_at_gmt <= '".$jaiku_intermingle."'
				AND
				created_at_gmt > '".$post->post_date_gmt."'
				AND
				title NOT LIKE '".$clean_title."%'
			$limit
		");


		if (sizeof($rv) > 0){
			print '<div class="jaiku">';
			foreach( $rv as $jaiku ){

// 				if( strpos( $jaiku->title, $post->post_title ) === 0 ){
// 					continue;
// 				}

?>
<table style="width: 100%">
	<tr>
		<td valign="top" width="50" style="width: 50px"><img src="<?php print $jaiku->avatar ?>" width="50" height="50" /></td>
		<td width="100%">
			<div style="border: 1px solid #c7e5e9; background: #f9fdfd url(<?php echo $site_url ?>/wp-content/plugins/jaikupost/blend.gif) repeat-x bottom; padding: 6px; -moz-border-radius: 8px;">

<?php
				if($jaiku->icon){
					printf('<img src="%s" width="36" height="36" align="left" /> ', $jaiku->icon);
				}
				print '<p class="jaiku-title">' . $jaiku->title . '</p>';

				printf(' <p class="jaiku-meta">%s <a href="%s"><img src="'.$site_url.'/wp-content/plugins/jaikupost/comment.gif" /> Comments</a></p>', $jaiku->created_at, $jaiku->url);

?>
			</div>

		</td>
	</tr>
</table>
<?php

			}
			print "</div>";
		}
	}

	$jaiku_intermingle = $post->post_date_gmt;
}






