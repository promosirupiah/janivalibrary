jQuery(document).ready(function($){
	$(".networkpubre").bind("click", function(e) {
		var key = $(this).attr("id");
		if(key) {
			var blog_url = $("#networkpub_plugin_url").val();
			$.post(blog_url+"networkpub_ajax.php", {key:key}, function(data) {
				if(data == '500') {
					$("#networkpub_msg").html('<div class="msg_error">Error occured while removing the API Key. As a workaround, you can remove this publishing at the following link: <a href="http://www.linksalpha.com/user/publish">LinksAlpha Publisher</a> </div>');
				} else {
					var dr = data.split("_");
					$("#r_key_"+dr[1]).remove();
					$("#networkpub_msg").html('<div class="msg_success">API Key has been removed successfully</div>');	
				}
		    });
		} 
		return false;
	});
})