<?php
/*
Plugin Name: Network Publisher
Plugin URI: http://wordpress.org/extend/plugins/network-publisher/
Description: Automatically publish your blog posts to multiple Social Networks including Twitter, Facebook Profile, Facebook Pages, LinkedIn, MySpace, Yammer, Yahoo, Identi.ca, and <a href="http://www.linksalpha.com/user/networks" target="_blank">more</a>. Click <a href="http://help.linksalpha.com/wordpress-plugin-network-publisher">here</a> for instructions. Email us at post@linksalpha.com if you have any queries.
Version: 2.0.0
Author: LinksAlpha
Author URI: http://www.linksalpha.com
*/

/*
    Copyright (C) 2010 LinksAlpha.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

define('NETWORKPUB_WP_PLUGIN_URL', networkpub_get_plugin_dir());
define('NETWORKPUB_WIDGET_NAME', 'Network Publisher');
define('NETWORKPUB_WIDGET_NAME_INTERNAL', 'networkpub');
define('NETWORKPUB_WIDGET_PREFIX', 'networkpub');
define('NETWORKPUB', 'Automatically publish your blog posts to 20+ Social Networks including Facebook,Twitter,LinkedIn,Yahoo,Yammer,MySpace,Identi.ca');
define('NETWORKPUB_ERROR_INTERNAL', 'internal error');
define('NETWORKPUB_ERROR_INVALID_URL', 'invalid url');
define('NETWORKPUB_ERROR_INVALID_KEY', 'invalid key');

$networkpub_settings['api_key'] = array('label'=>'API Key:', 'type'=>'text', 'default'=>'');
$networkpub_settings['id'] = array('label'=>'id', 'type'=>'text', 'default'=>'');
$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);

function networkpub_init() {
	wp_enqueue_script('jquery');
	wp_register_script('networkpubjs', NETWORKPUB_WP_PLUGIN_URL .'networkpub.js');
	wp_enqueue_script('networkpubjs');
	wp_register_style('networkpubcss', NETWORKPUB_WP_PLUGIN_URL . 'networkpub.css');
	wp_enqueue_style('networkpubcss');
	add_action('admin_menu', 'networkpub_pages');
	add_action('{$new_status}_{$post->post_type}', 'networkping');
	add_action('publish_post', 'networkping');
}
add_action('init', 'networkpub_init');
add_action('init', 'networkpub_remove');
register_activation_hook( __FILE__, 'networkpub_activate' );
add_action('admin_notices', 'networkpub_warning');
function networkpub_activate() {
$networkpub_eget = get_bloginfo('admin_email'); $networkpub_uget = get_bloginfo('url'); $networkpub_nget = get_bloginfo('name');
$networkpub_dget = get_bloginfo('description'); $networkpub_cget = get_bloginfo('charset'); $networkpub_vget = get_bloginfo('version');
$networkpub_lget = get_bloginfo('language'); $link='http://www.linksalpha.com/a/bloginfo';
$networkpub_bloginfo = array('email'=>$networkpub_eget, 'url'=>$networkpub_uget, 'name'=>$networkpub_nget, 'desc'=>$networkpub_dget, 'charset'=>$networkpub_cget, 'version'=>$networkpub_vget, 'lang'=>$networkpub_lget,  'plugin'=>'nw');
networkpub_http_post($link, $networkpub_bloginfo);
}
function networkpub_warning() {
	$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);
	if(empty($options['api_key'])) {
		if (!isset($_POST['submit'])) {
			echo "
			<div id='Network Publisher warning' class='updated fade' style='width:80%;'>
				<p>
					<strong>".__('<a href="http://wordpress.org/extend/plugins/network-publisher/" target="_blank">Network Publisher</a> plugin is almost ready.')."</strong> ".
					sprintf(__('You must <a href="%1$s">enter API key</a> (under Plugins->Network Publisher) for automatic posting of your blog articles to 20+ Social Networks including Twitter, Facebook Profile, Facebook Pages, LinkedIn, MySpace, Yammer, Yahoo, Identi.ca, etc. to work.'),
					"plugins.php?page=networkpub")."
				</p>
			</div>
			";
		}
	}
}

function networkping($id) {
	if(!$id) {
		return FALSE;
	}
	$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);
	$link = 'http://www.linksalpha.com/a/ping?id='.$options['id'];
	$response_full = networkpub_http($link);
	$response_code = $response_full[0];
	if ($response_code === 200) {
		return TRUE;
	}
	return FALSE;
}
function networkpub_pages() {
	if ( function_exists('add_submenu_page') ) {
		$page = add_submenu_page('plugins.php', NETWORKPUB_WIDGET_NAME, NETWORKPUB_WIDGET_NAME, 'manage_options', 'networkpub', 'networkpub_conf');
	}
}
function networkpub_conf() {
	global $networkpub_settings;

	if ( isset($_POST['submit']) ) {
		if ( function_exists('current_user_can') && !current_user_can('manage_options') ) {
			die(__('Cheatin&#8217; uh?'));
		}
		$field_name = sprintf('%s_%s', NETWORKPUB_WIDGET_PREFIX, 'api_key');
		$value = strip_tags(stripslashes($_POST[$field_name]));
		if($value) {
			$networkadd = networkpub_add($value);
		}
	}
	$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);
	$html  = '<div id="networkpub_msg"></div>';
	$html .= '<div class="rts_header"><h2><img class="la_image" src="http://www.linksalpha.com/favicon.ico" />&nbsp;'.NETWORKPUB_WIDGET_NAME.'</h2></div>';
	$html .= '<table style="width:100%;"><tr><td style="width:800px;"><table style="width:800px;"><tr><td style="padding-bottom:40px;">';
	$html .= '<div style="padding:0px 0px 10px 0px;">Network Publisher makes it easy and painless to Publish your Blog Posts to Social Networks. All you need to do is connect to your Social Networks at <a target="_blank" href="http://www.linksalpha.com/user/networks">LinksAlpha.com</a>, grab API Key for each enabled Network and enter it below. Once setup, your Blog posts content appears on the social networks as soon as you hit the Publish button.</div>';
	$html .= '<div style="padding:0px 0px 20px 0px;"><a href="http://www.linksalpha.com/user/networks" style="font-weight:bold;" target="_blank">Click Here</a> to get API Keys for your Social Networks. You can <a href="http://help.linksalpha.com/wordpress-plugin-network-publisher" target="_blank">read more about this process at LinksAlpha.com.</a></div>';
	$html .= '<div class="rts_header2"><big><strong>Setup</strong></big></div><div style="padding-left:0px;">';
	$html .= '<div class="la_content_box">';
	$html .= '<form action="" method="post" id="networkpubadd" name="networkpubadd" style="width:90%;">';
	$html .= '<fieldset class="rts_fieldset">';
	$html .= '<legend>Additional API Key</legend>';

	$curr_field = 'api_key';
	$field_name = sprintf('%s_%s', NETWORKPUB_WIDGET_PREFIX, $curr_field);
	$html .= '<div><label for="'.$field_name.'">'.$networkpub_settings[$curr_field]['label'].'&nbsp;</label></div>';
	$html .= '<div>
				<a href="http://www.linksalpha.com/user/networks" target="_blank" style="color:red">Click here</a> <b>to get API Key</b> and enter it in the box below.
			  </div>';

	$html .= '<div style="padding-bottom:10px"><input style="width:400px;  border-width:1px;border-color:gray;border-style:solid" class="widefat" id="'.$field_name.'" name="'.$field_name.'" type="text" /></div>';
	$html .= '<div>
				You need to get key from LinksAlpha and copy it here. You CANNOT generate your own key.
				<a href="http://help.linksalpha.com/wordpress-plugin-network-publisher" target="_blank">Read more about the simple and quick process here</a>.
			  </div>';
	$html .= '<div><br/><span style="color:#d12424;">Getting Errors?</span> See help page <a href="http://help.linksalpha.com/errors" target="_blank">here</a></div>';
	$html .= '</fieldset>';
	$html .= '<div style="padding-top:20px;"><input type="submit" name="submit" class="button-primary" value="Add API Key" /></div>';
	$html .= '<input type="hidden" value="'.NETWORKPUB_WP_PLUGIN_URL.'" id="networkpub_plugin_url" /></form></div></td></tr><tr><td style="padding:0px 0px 0px 0px;vertical-align:top;">';
	$html .= '<div class="rts_header2"><big><strong>Currently Publishing</strong></big></div>';
	$html .= '<div class="la_content_box">'.networkpub_load().'</div>';
	$html .= '</div></td></tr></table></td>
			 <td style="width:250px;vertical-align:top;">
			 <div class="rts_header2"><big><strong>Supported Networks</strong></big></div>
			 <div class="la_content_box_3">
			 <a href="http://www.linksalpha.com/user/networks" target="_blank"><img border="0" style="vertical-align:middle; border:1px solid #C0C0C0" src="'.NETWORKPUB_WP_PLUGIN_URL.'screenshot-3.png"></a>
			 </div></td></tr></table>';
	$html .= '<div style="font-size:14px; margin: 50px 10px 10px 10px;">
 			  Note: If you decide to stop using this plugin permanently, pls also remove your blog URL by logging into <a href="http://www.linksalpha.com/publish" target="_blank">http://www.linksalpha.com/publish</a>.
 			  Otherwise, your blog posts may continue to get posted even after you remove this plugin.
			  </div>';

	echo $html;
}

function more_plugins() {
	$html = '<div><big><strong>Setup</strong></big></div>';
	echo $html;
}

function networkpub_add($api_key) {
	if (!$api_key) {
		echo '<div class="msg_error">Error occured while processing your request. Error Code 100</div>';
		return FALSE;
	}

	$url = get_bloginfo('url');
	$desc = get_bloginfo('description');

	if (!$url) {
		$errdesc = networkpub_error_msgs('invalid url');
		echo $errdesc;
		return FALSE;
	}

	$link   = 'http://www.linksalpha.com/a/networkpubadd';


	$params = array('url'=>urlencode($url), 'key'=>$api_key, 'plugin'=>'nw');
	$response_full = networkpub_http_post($link,$params);

	$response_code = $response_full[0];
	if ($response_code != 200) {
		$errdesc = networkpub_error_msgs($response_full[1]);
		echo $errdesc;
		return FALSE;
	}

	$response = networkpub_json_decode($response_full[1]);
	if ($response->errorCode > 0) {
		$errdesc = networkpub_error_msgs($response->errorMessage);
		echo $errdesc;
		return FALSE;
	}

	$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);
	if(empty($options['api_key'])) {
		$options['api_key'] = $api_key;
	} else {
		$options_array = explode(',', $options['api_key']);
		if(!in_array($api_key, $options_array)) {
			$options['api_key'] = $options['api_key'].','.$api_key;
		}
	}
	$options['id'] = $response->results->id;
	update_option(NETWORKPUB_WIDGET_NAME_INTERNAL, $options);
	echo '<div class="msg_success">API Key has been added successfully</div>';
	return TRUE;
}

function networkpub_load() {
	$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);

	if (empty($options['api_key'])) {
		$html = '<div class="msg_error">You have not added any API Key</div>';
		return $html;
	}

	$link = 'http://www.linksalpha.com/a/networkpubget';

	$body = array('key'=>$options['api_key'], 'version'=>2);

	$response_full = networkpub_http_post($link, $body);
	$response_code = $response_full[0];

	if ($response_code != 200) {
		$errdeschtml = networkpub_error_msgs($response_full[1]);
		return $errdeschtml;
	}

	$response = networkpub_json_decode($response_full[1]);
	if($response->errorCode > 0) {
		$html = '<div class="msg_error">Error occured while trying to load the API Keys. Please try again later.</div>';
		return $html;
	}

	$html = '<div style="padding-bottom:10px;">You are currently Publishing your Blog to '.count($response->results).' Social Networks</div>';
	$html .= '<table class="networkpub_added"><tr><th>API Key</th><th>Network</th><th>Option</th></tr>';
	if (count($response->results)) {
		foreach($response->results as $row) {
			$html .= '<tr id="r_key_'.$row->api_key.'">';
			$html  .= '<td>'.$row->api_key.'</td><td><a href="'.$row->profile_url.'">'.$row->name.'</a></td>';
			$html .= '<td><a href="#" id="key_'.$row->api_key.'" class="networkpubre">Remove</a></td></tr>';
		}
	} else {
		$html .= '<tr><td colspan="3" style="text-align:center;padding:5px 0px 5px 0px;">No API Keys have been added</td></tr>';
	}
	$html .= '</table>';
	return $html;
}

function networkpub_remove() {
	$options = get_option(NETWORKPUB_WIDGET_NAME_INTERNAL);
	if (!empty($_POST['key'])) {
		$key_full = $_POST['key'];
		$key_only = substr($key_full, 4);
		$link = 'http://www.linksalpha.com/a/networkpubremove?id='.$options['id'].'&key='.$key_only;
		$response_full = networkpub_http($link);
		$response_code = $response_full[0];
		if ($response_code != 200) {
			$errdesc = networkpubnw_error_msgs($response_full[1]);
			echo $errdesc;
			return;
		}
		$api_key = $options['api_key'];
		$api_key_array = explode(',', $api_key);
		$loc = array_search($key_only, $api_key_array);
		if($loc !== FALSE) {
			unset($api_key_array[$loc]);
		}
		$api_key = implode(",", $api_key_array);
		$options['api_key'] = $api_key;
		update_option(NETWORKPUB_WIDGET_NAME_INTERNAL, $options);
		echo $key_full;
		return;
	}
}

function networkpub_json_decode($str) {
	if (function_exists("json_decode")) {
	    return json_decode($str);
	} else {
		if (!class_exists('Services_JSON')) {
			require_once("JSON.php");
		}
	    $json = new Services_JSON();
	    return $json->decode($str);
	}
}

function networkpub_http($link) {
	if (!$link) {
		return array(500, 'invalid url');
	}
	require_once(ABSPATH.WPINC.'/class-snoopy.php');
	$snoop = new Snoopy;
	$snoop->agent = NETWORKPUB_WIDGET_NAME.' - '.get_bloginfo('url');
	if($snoop->fetchtext($link)){
		if (strpos($snoop->response_code, '200')) {
			$response = $snoop->results;
			return array(200, $response);
		}
	}
	if( !class_exists( 'WP_Http' ) ) {
		include_once( ABSPATH . WPINC. '/class-http.php' );
	}
	if (!class_exists('WP_Http')) {
		return array(500, 'internal error');
	}
	$request = new WP_Http;
	$headers = array( 'Agent' => NETWORKPUB_WIDGET_NAME.' - '.get_bloginfo('url') );
	$response_full = $request->request( $link );
	$response_code = $response_full['response']['code'];
	if ($response_code === 200) {
		$response = $response_full['body'];
		return array($response_code, $response);
	}
	$response_msg = $response_full['response']['message'];
	return array($response_code, $response_msg);
}

function networkpub_http_post($link, $body) {
	if (!$link) {
		return array(500, 'invalid url');
	}
	require_once(ABSPATH.WPINC.'/class-snoopy.php');
	$snoop = new Snoopy;
	$snoop->agent = NETWORKPUB_WIDGET_NAME.' - '.get_bloginfo('url');
	if($snoop->submit($link, $body)){
		if (strpos($snoop->response_code, '200')) {
			$response = $snoop->results;
			return array(200, $response);
		}
	}
	if( !class_exists( 'WP_Http' ) ) {
		include_once( ABSPATH . WPINC. '/class-http.php' );
	}
    if (!class_exists('WP_Http')) {
		return array(500, 'internal error');
	}
	$request = new WP_Http;
	$headers = array( 'Agent' => NETWORKPUB_WIDGET_NAME.' - '.get_bloginfo('url') );
	$response_full = $request->request( $link, array( 'method' => 'POST', 'body' => $body, 'headers'=>$headers) );

	if(isset($response_full->errors)) {
		return array(500, 'internal error');
	}

	$response_code = $response_full['response']['code'];
	if ($response_code === 200) {
		$response = $response_full['body'];
		return array($response_code, $response);
	}
	$response_msg = $response_full['response']['message'];
	return array($response_code, $response_msg);
}


function networkpub_error_msgs($errMsg) {

	$arr_errCodes  = explode(";", $errMsg);
	$errCodesCount = count($arr_errCodes);

	switch (trim($arr_errCodes[0])) {

		case 'internal error':
			$html = '<div class="msg_error">
							<b>Unknown Error.</b> There was an error. We will keep re-trying and send you an email when the request is successful.
							You can also email us at <a href="mailto:support@linksalpha.com">support@linksalpha.com</a> with error description (your blog URL and the error).
					</div>';
			return $html;
			break;

		case 'invalid url':
			$html  = '<div class="msg_error"> <b>Your blog URL is invalid: </b>'.$arr_errCodes[$errCodesCount-1];
			if($errCodesCount == 3) {
				$html .= '. Error Code='.$arr_errCodes[$errCodesCount-2];
			}
			$html .= '<br/> You can also <a href="http://www.linksalpha.com/user/siteadd" target="_blank">Click here</a> to enter blog URL on LinksAlpha manually.
					  Also ensure that in <b>Settings->General->"Blog address (URL)"</b> the URL is filled-in correctly.
					  <br/>If you still face issues then email us at <a href="mailto:support@linksalpha.com">support@linksalpha.com</a> with error description.
					  </div>';
			return $html;
			break;

		case 'remote url error':
			$html  = '<div class="msg_error"> <b>Remote URL error: </b>'.$arr_errCodes[$errCodesCount-1];
			if($errCodesCount == 3) {
				$html .= '. Error Code='.$arr_errCodes[$errCodesCount-2];
			}
			$html .= '<br/> <b>Description: </b>
							Your site either did not respond (it is extremely slow) or it is not operational. We will keep re-trying
							and send you an email when the request is successful.
							<br/> You can also <a href="http://www.linksalpha.com/user/siteadd" target="_blank">Click here</a> to enter blog URL on LinksAlpha manually.
							Also ensure that in <b>Settings->General->"Blog address (URL)"</b> the URL is filled-in correctly.
							<br/>If you still face issues then email us at <a href="mailto:support@linksalpha.com">support@linksalpha.com</a> with error description.
					</div>';
			return $html;
			break;

		case 'feed parsing error':
			$html  = '<div class="msg_error"> <b>Feed parsing error: </b>'.$arr_errCodes[$errCodesCount-1];
			if($errCodesCount == 3) {
				$html .= '. Error Code='.$arr_errCodes[$errCodesCount-2];
			}
			$html .= '<br/> <b>Description: </b>
							Your RSS feed has errors. Pls go to <a href=http://beta.feedvalidator.org/ target="_blank">href=http://beta.feedvalidator.org/</a>
							to validate your RSS feed.
							<br/>If it comes out to be correct, email as at <a href="mailto:support@linksalpha.com">support@linksalpha.com</a> with your blog URL and error description.
					</div>';
			return $html;
			break;

		case 'feed not found':
			$html = '<div class="msg_error">
							<b>We could not find feed URL for your blog.</b>
							<br/><a href="http://www.linksalpha.com/user/siteadd" target="_blank">Click here</a> to enter feed URL on LinksAlpha manually.
							Also ensure that in <b>Settings->General->"Blog address (URL)"</b> the URL is filled-in correctly.
							<br/>If you still face issues then email us at <a href="mailto:support@linksalpha.com">support@linksalpha.com</a> with error description.
					</div>';
			return $html;
			break;

		case 'invalid key':
			$html = '<div class="msg_error">
							<b>Invalid Key: </b>the key that you entered is incorrect. Please try again.
							<br/><span style="color:#d12424;">Getting Errors?</span> See help page <a href="http://help.linksalpha.com/errors" target="_blank">here</a>
							<br/>Or, <a href="http://www.linksalpha.com/user/siteadd" target="_blank">Click here</a> to enter your blog URL on LinksAlpha manually.
							If you still face issues then email us at <a href="mailto:support@linksalpha.com">support@linksalpha.com</a> with error description.
					</div>';
			return $html;
			break;

		case 'subscription upgrade required':
			$html = '<div class="msg_error">
							<b>Upgrade account.</b> Please <a href="http://www.linksalpha.com/account" target="_blank">upgrade your subscription</a> to add more networks.
					</div>';
			return $html;
			break;

		default:
			$html = '<div class="msg_error">
							This is embarrassing :-(. Sorry we are undergoing maintenance at this time - this happens very rarely but is critical to ensure continued availability. We apologize for the inconvenience.
							This can take upto 2 hours maximum. Please try again after sometime and it is guaranteed to work.
							You can also email us at <a href="mailto:discuss@linksalpha.com">discuss@linksalpha.com</a> if issue persists. Thanks for your understanding.
					</div>';
			return $html;
			break;
	}
}

function networkpub_get_plugin_dir() {
	if ( version_compare($wp_version, '2.8', '<') ) {
		$path = dirname(plugin_basename(__FILE__));
		if ( $path == '.' )
		$path = '';
		$plugin_path = trailingslashit( plugins_url( $path ) );
	}
	else {
		$plugin_path = trailingslashit( plugins_url( '', _FILE_) );
	}

	return $plugin_path;
}

function networkpub_deactivate() {
	echo "<div id='Network Publisher-warning' class='updated fade' style='width:80%;'>
			<div style='font-size:14px'>
 			<span style='color:#d12424;'><b>Please read:</b></span>
 			If you have <u><b>permanently</b> deactivated</u> <b>'Network Publisher'</b> plugin and you were using this plugin (i.e., added API key), pls also remove your blog URL by logging-into <a href='http://www.linksalpha.com/publish' target='_blank'>http://www.linksalpha.com/publish</a>. Otherwise, your blog posts may continue to get posted even after you remove this plugin. If you have questions, pls email us at post@linksalpha.com.
			<br/><br/>
			<span style='color:#d12424;'>If you are just upgrading to a newer version, then pls ignore the above message.</span>
  		    </div>
	      </div>";
}

register_deactivation_hook( __FILE__, 'networkpub_deactivate' );

?>
