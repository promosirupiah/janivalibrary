=== Plugin Name ===
Contributors: LinksAlpha
Tags: twitter, page, widgets, widget, linkedin, Post, facebook, facebook page, facebook profile, facebook wall, yammer, google, sidebar, myspace, yahoo, comments, rss, identi.ca, plugin, identica, news, posts, publish, distribute, status, update, status update, twitter oauth, oauth, admin, links, auto posts, auto, Blogger, Brightkite, Delicious, Diigo, Foursquare, Google Buzz, Plurk, Posterous, Sonico, Tumblr, Typepad, Windows Live, Yahoo, Yahoo Meme, Yammer.
Requires at least: 1.0.0
Tested up to: 3.0.1
Stable tag: 2.0.0

== Description ==

Plugin enables you to `Automatically Publish` your `Blog Posts to 20+ Social Networks`. Currently Supported Networks include:

1. Facebook Profile
1. Facebook Pages
1. Twitter
1. LinkedIn
1. MySpace
1. Yammer
1. Yahoo
1. Identi.ca
1. Blogger
1. Brightkite
1. Delicious
1. Diigo
1. Foursquare
1. Google Buzz
1. Plurk
1. Posterous
1. Sonico
1. Tumblr
1. Typepad
1. Windows Live
1. Yahoo
1. Yahoo Meme
1. Yammer

Plugin also supports `Publishing your Blog Posts to Twitter` via `OAuth`


**Additional Features**

* View Weekly Stats to track total number of Blog Posts, Tweets, Bitly Clicks, Facebook Comments, Facebook Likes, and Facebook Shares.
* View status of your blog posts to each social network - whether the blog post has been published, when it was published, etc. 


**Benefits**

* Keep your fans, followers, and connections automatically updated on your blog posts.
* Enable your users to retweet, share and like your blog articles to their Twitter followers and Facebook friends.
* Expand your blog reach and save time by letting the plugin publish your blog posts - automatically.


**Miscellaneous:**

* Get Support: post@linksalpha.com


== Installation ==

1. Upload network-publisher.zip to '/wp-content/plugins/' directory and unzip it.
1. Activate the "Network Publisher" Plugin from "Manage Plugins" window
1. Setup: Add LinksALpha.com API Keys to start Publishing. Click on the following link for instructions on how to get API Keys from LinksAlpha.com - http://help.linksalpha.com/wordpress-plugin-network-publisher

== Screenshots ==

1. Networks enabled by a User at LinksAlpha.com
2. Network Publisher Plugin Setup window
3. List of Supported Networks

== Changelog ==

= 2.0.0 =
* Must upgrade - added 10+ more networks for Automatic Publishing of your Blog Posts to multiple networks.