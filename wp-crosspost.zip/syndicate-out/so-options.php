<script type="text/javascript">
	function toggleTriggerCategories(groupid, checkboxStatus) {
		if (checkboxStatus == true) {
			document.getElementById('triggercategory-' + groupid).disabled = true;
		} else {
			document.getElementById('triggercategory-' + groupid).disabled = false;
		}
	}
	function toggleIgnoreServer(groupid, serverid, checkboxStatus) {
		if (checkboxStatus == true) {
			document.getElementById('serverserver-' + groupid + '-' + serverid).disabled = true;
			document.getElementById('serverusername-' + groupid + '-' + serverid).disabled = true;
			document.getElementById('serverpassword-' + groupid + '-' + serverid).disabled = true;
		} else {
			document.getElementById('serverserver-' + groupid + '-' + serverid).disabled = false;
			document.getElementById('serverusername-' + groupid + '-' + serverid).disabled = false;
			document.getElementById('serverpassword-' + groupid + '-' + serverid).disabled = false;
		}
	}
</script>
<div class="wrap">
	<h2>Syndicate Out</h2>
	<form method="post" action="options.php">
	<?php settings_fields( 'syndicate-out-options' ); ?>
		<h3>Syndication Groups</h3>
		<p>
		   A group is a set of remote blogs that posts in the specified category
			will be syndicated to when posted on this blog.
		</p>
		<p>
			Each category may be syndicated to as many blogs as required, and a
			remote blog may appear in as many groups as needed.  Posts which match
			multiple groups with duplicate servers will only be syndicated to the
			remote blog once but will use the least restrictive 'transmit
			categories' setting.  There is no limit to the number of
			groups which may be added.
		</p>
		<hr />

<?php
	if ( isset( $syndicateOutOptions['group'] ) && is_array( $syndicateOutOptions['group'] ) ) {
		foreach ( $syndicateOutOptions['group'] AS $groupKey => $syndicationGroup ) {
?>
		<div style="padding-bottom: 15px;">
			<h4>Group <?php echo ($groupKey + 1); ?></h4>
			<table class="form-table">
				<tr>
				   <th scope="row">Category</th>
				   <td>
						<select id="triggercategory-<?php echo $groupKey; ?>" name="so_options[<?php echo $groupKey ?>][category]" <?php if ( -1 == $syndicationGroup['category'] ) { echo 'disabled="true"'; } ?>>
<?php
			foreach ( get_categories( array ( 'hide_empty' => 0 ) ) AS $blogCategory ) {
				echo '<option value="'.$blogCategory->cat_ID.'"'.( ( $syndicationGroup['category'] == $blogCategory->cat_ID ) ? ' selected="selected"' : '' ).'>'.$blogCategory->cat_name.'</option>';
			}
?>
						</select>
						or <b>all posts</b> <input type="checkbox" name="so_options[<?php echo $groupKey ?>][allcats]" value="true" <?php if ( -1 == $syndicationGroup['category'] ) { echo 'checked="true"'; } ?> onclick="toggleTriggerCategories(<?php echo $groupKey; ?>, this.checked);" />
					</td>
				</tr>
				<tr valign="top">
					<th scope="row">Transmit categories *</th>
					<td>
						<input type="radio" name="so_options[<?php echo $groupKey ?>][syndicate_category]" value="none" <?php echo ( 'none' == $syndicationGroup['syndicate_category'] ) ? 'checked="checked"' : '' ?>/> None
						<input type="radio" name="so_options[<?php echo $groupKey ?>][syndicate_category]" value="syndication" <?php echo ( 'syndication' == $syndicationGroup['syndicate_category'] ) ? 'checked="checked"' : '' ?>/> Syndication category only
						<input type="radio" name="so_options[<?php echo $groupKey ?>][syndicate_category]" value="all" <?php echo ( 'all' == $syndicationGroup['syndicate_category'] ) ? 'checked="checked"' : '' ?>/> All
					</td>
				</tr>
			</table>
			<table class="form-table">
				<tr>
					<th><b>Address</b></th>
					<th><b>Username</b></th>
					<th><b>Password</b></th>
					<th><b>Delete</b></th>
				</tr>
<?php
			if ( count( $syndicationGroup['servers'] ) == 0 || isset( $_POST['addrow'][$groupKey] ) ) {
				$syndicationGroup['servers'][] = array( 'server' => '', 'username' => '', 'password' => '');
			}
			foreach ( $syndicationGroup['servers'] AS $serverKey => $soServer ) {
?>
				<tr>
					<td><input id="serverserver-<?php echo $serverKey ?>-<?php echo $groupKey ?>" type="text" name="so_options[<?php echo $groupKey ?>][servers][<?php echo htmlentities2( $serverKey ); ?>][server]" value="<?php echo htmlentities2( $soServer['server'] ); ?>" /></td>
					<td><input id="serverusername-<?php echo $serverKey ?>-<?php echo $groupKey ?>" type="text" name="so_options[<?php echo $groupKey ?>][servers][<?php echo htmlentities2( $serverKey ); ?>][username]" value="<?php echo htmlentities2( $soServer['username'] ); ?>" /></td>
					<td><input id="serverpassword-<?php echo $serverKey ?>-<?php echo $groupKey ?>" type="password" name="so_options[<?php echo $groupKey ?>][servers][<?php echo htmlentities2( $serverKey ); ?>][password]" value="<?php echo htmlentities2( $soServer['password'] ); ?>" /></td>
					<td><input type="checkbox" name="so_options[<?php echo $groupKey ?>][servers][<?php echo htmlentities2( $serverKey ); ?>][delete]" value="1" onclick="toggleIgnoreServer(<?php echo $serverKey ?>, <?php echo $groupKey ?>, this.checked);" /></td>
				</tr>
<?php
			}
?>
				<tr>
					<td colspan="3">
						<input type="submit" name="so_options[addrow][<?php echo $groupKey; ?>]" class="button" value="<?php _e( 'Add new server' ) ?>" />
						or <input type="submit" name="so_options[deletegroup][<?php echo $groupKey; ?>]" class="button" value="<?php _e( 'Delete group' ) ?>" />
					</td>
				</tr>
			</table>
		</div>
		<hr />
<?php
		}
	}
?>
		<p class="submit">
			<input type="submit" name="save" class="button-primary" value="<?php _e( 'Save settings' ) ?>" />
			<input type="submit" name="so_options[addgroup]" class="button" value="<?php _e( 'Add new group' ) ?>" />
		</p>
		<span>
			* There is currently a bug in the WordPress implementation of the metaWeblog.newPost XML-RPC call which may cause
			problems when transmitting category data.  See bug <a href="http://core.trac.wordpress.org/ticket/11430">#11430</a> for more information.
			If unsure select 'None'.
		</span>
	</form>
</div>