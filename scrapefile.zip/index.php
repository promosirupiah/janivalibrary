<?php

$source_check = 'homeunix.com';
$source_domain = array('anymanga.com','mfcdn.net','mangafox.com','unixmanga.com','homeunix.com');
$target_domain = array('anymanga.localhost','mfcdn.localhost','mangafox.localhost','unixmanga.localhost','homeunix.localhost');
$final_domain = array('anymanga.localhost','mfcdn.localhost','mangafox.localhost','unixmanga.localhost','homeunix.localhost');
$main_domain = 'localhost';


$scrape = 'http://'.str_ireplace($target_domain,$source_domain,$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"]);

function SureRemoveDir($dir, $DeleteMe) {
    if(!$dh = @opendir($dir)) return;
    while (false !== ($obj = readdir($dh))) {
        if($obj=='.' || $obj=='..') continue;
        if (!@unlink($dir.'/'.$obj)) SureRemoveDir($dir.'/'.$obj, true);
    }

    closedir($dh);
    if ($DeleteMe){
        @rmdir($dir);
    }
}
if ($_SERVER["REQUEST_URI"] =='/index.php?clearapi'){SureRemoveDir('apicache',false);echo 'apicache clear';exit;} //*use http://yourdomain.com/index.php?clearapi to clear api cache
if ($_SERVER["REQUEST_URI"] =='/index.php?clearcache'){SureRemoveDir('cache',false);echo 'cache clear';exit;} //*use http://yourdomain.com/index.php?clearcache to clear cache file
if ($_SERVER["REQUEST_URI"] =='/index.php?clearscrape'){SureRemoveDir('scrapefiles',false);echo 'cache clear';exit;} //*use http://yourdomain.com/index.php?clearcache to clear cache file


function ubah_tanda($result) { //change all special character to "-"
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
	$result = str_replace(array('___','__','_'),'-',$result);
	$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
} 
$scrapefile = 'scrapefiles/'.ubah_tanda(substr(base64_encode($scrape),0,220)).'.txt';

preg_match('@/[0-9/]+/@siu',$_SERVER["REQUEST_URI"],$numbercheck);
preg_match('@[a-zA-Z]+@siu',$_SERVER["REQUEST_URI"],$wordscheck);
if (strpos($_SERVER["REQUEST_URI"],'/category/') !== false){$cachetime = 30 * 60;}
else if (strpos($_SERVER["REQUEST_URI"],'/?cat=') !== false){$cachetime = 30 * 60;}
else if (strpos($_SERVER["REQUEST_URI"],'/tag/') !== false){$cachetime = 30 * 60;}
else if (strpos($_SERVER["REQUEST_URI"],'/?tag=') !== false){$cachetime = 30 * 60;}
else if (strpos($_SERVER["REQUEST_URI"],'/feed/') !== false){$cachetime = 5 * 60;}
else if (strpos($_SERVER["REQUEST_URI"],'/?feed=') !== false){$cachetime = 5 * 60;}
else if (strpos($_SERVER["REQUEST_URI"],'/search') !== false){$cachetime = 12 * 60 * 60;}
else if ($numbercheck[0] && !$wordscheck[0] ){$cachetime = 5 * 60;} //for date archive like /2011/12/25/
else if ($_SERVER["REQUEST_URI"] == '/'){$cachetime = 5 * 60;} // for frontpage
else{$cachetime = 12 * 60 * 60; // cache valid in seconds
}
if (file_exists($scrapefile) && (time() - $cachetime < filemtime($scrapefile))){
header('Content-Type: text/html; charset=utf-8'); 
$html = file_get_contents($scrapefile);
echo $html;
//echo '<cache>';
exit;
}

include_once('./simple_html_dom.php');
//$scrape = 'http://'.$source_domain.$_SERVER["REQUEST_URI"];

function strpos_arr($haystack, $needle) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $what) {
        if($haystack == $what) return $pos;
    }
    return false;
}

function strpos_arrx($haystack, $needle) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $what) {
        if(($pos = strpos($haystack, $what))!==false) return $pos;
    }
    return false;
}


//file checker
$exceptextension[]='rpm';
$exceptextension[]='pdf';
$exceptextension[]='sig';
$exceptextension[]='spl';
$exceptextension[]='class';
$exceptextension[]='torrent';
$exceptextension[]='dvi';
$exceptextension[]='gz';
$exceptextension[]='pac';
$exceptextension[]='swf';
$exceptextension[]='tgz';
$exceptextension[]='tar';
$exceptextension[]='zip';
$exceptextension[]='mp3';
$exceptextension[]='m3u';
$exceptextension[]='wma';
$exceptextension[]='wax';
$exceptextension[]='ogg';
$exceptextension[]='wav';
$exceptextension[]='gif';
$exceptextension[]='jar';
$exceptextension[]='jpg';
$exceptextension[]='jpeg';
$exceptextension[]='png';
$exceptextension[]='xbm';
$exceptextension[]='xpm';
$exceptextension[]='xwd';
$exceptextension[]='css';
$exceptextension[]='js';
$exceptextension[]='asc';
$exceptextension[]='cpp';
$exceptextension[]='log';
$exceptextension[]='conf';
$exceptextension[]='text';
//$exceptextension[]='txt';
$exceptextension[]='dtd';
//$exceptextension[]='xml';
$exceptextension[]='mpeg';
$exceptextension[]='mpg';
$exceptextension[]='mov';
$exceptextension[]='qt';
$exceptextension[]='exe';
$exceptextension[]='ico';

$file_ext = explode(".",$_SERVER["REQUEST_URI"]); 
$ext = $file_ext[count($file_ext)-1];
$except = strpos_arr($ext, $exceptextension);
if ($except !== false){
$file_path = explode("/",$_SERVER["REQUEST_URI"]); 
$filename = $file_path[count($file_path)-1];
$path = $file_path;
unset ($path[count($path)-1]);
$path = implode("/",$path);
if ($path ==''){$path = '/';}
//echo 'src = '.$src.'<br>';
//echo 'path = '.$path .'<br>';
//echo 'filename = '.$filename.'<br>';
//echo 'ext = '.$ext.'<br>';
$path = str_ireplace($source_domain,$target_domain,$path);
$path = str_ireplace($target_domain,$final_domain,$path);
$filename = str_ireplace($source_domain,$target_domain,$filename);
$filename = str_ireplace($target_domain,$final_domain,$filename);

if(!is_dir('.'.$path)){mkdir('.'.$path, 0777, true);}


if($ext == 'gz'){
$zd = gzopen($scrape, "r");
$contents = gzread($zd,10000);
gzclose($zd);
$contents = str_ireplace($source_domain,$target_domain,$contents);
$contents = str_ireplace($target_domain,$final_domain,$contents);
$string = $contents;
$gz = gzopen(dirname(__FILE__).$path.'/'.$filename,'w9');
gzwrite($gz, $string);
gzclose($gz);
//$fcache = fopen($scrapefile, 'w');
//fwrite($fcache, $contents);
//fclose($fcache);
echo $contents;
exit;
}
else{
$fp = fopen(dirname(__FILE__).$path.'/'.$filename, 'w');
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_URL, $scrape);
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );

//$datarewrite = file_get_contents($scrape);
//echo $datarewrite;
}
exit;

}

$exceptextension2[]='txt';
$exceptextension2[]='xml';
//$except2 = strpos_arr($ext, $exceptextension2);
//if ($except2 !== false){
//$file_path = explode("/",$_SERVER["REQUEST_URI"]); 
//$filename = $file_path[count($file_path)-1];
//$path = $file_path;
//unset ($path[count($path)-1]);
//$path = implode("/",$path);
//if ($path ==''){$path = '/';}
//echo 'src = '.$src.'<br>';
//echo 'path = '.$path .'<br>';
//echo 'filename = '.$filename.'<br>';
//echo 'ext = '.$ext.'<br>';
//$path = str_ireplace($source_domain,$target_domain,$path);
//$path = str_ireplace($target_domain,$final_domain,$path);
//$filename = str_ireplace($source_domain,$target_domain,$filename);
//$filename = str_ireplace($target_domain,$final_domain,$filename);
//if(!is_dir('.'.$path)){mkdir('.'.$path, 0777, true);}
//$fp = fopen(dirname(__FILE__).$path.'/'.$filename, 'w');
//$datarewrite = file_get_contents($scrape);
//$datarewrite = str_ireplace($source_domain,$target_domain,$datarewrite);
//$datarewrite = str_ireplace($target_domain,$final_domain,$datarewrite);
//echo $datarewrite;
//fwrite($fp, $datarewrite);
//fclose($fp);
//exit;
//}
//


header('Content-Type: text/html; charset=utf-8'); 
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $scrape);
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
//echo $response;

//$savefirst = str_ireplace($source_domain,$target_domain,$response);
//$savefirst = str_ireplace($target_domain,$final_domain,$savefirst);
//$fcache = fopen($scrapefile, 'w');
//fwrite($fcache, $savefirst);
//fclose($fcache);

$except2 = strpos_arr($ext, $exceptextension2);
if ($except2 !== false){
$response = str_ireplace($source_domain,$target_domain,$response);
$response = str_ireplace($target_domain,$final_domain,$response);
}






$html = str_get_html($response);
$maindomain = $responseinfo['url'];
if (strpos($responseinfo['url'],'http://') !== false){$serverdomain = 'http://';}
if (strpos($responseinfo['url'],'https://') !== false){$serverdomain = 'https://';}
if (strpos($responseinfo['url'],'ftp://') !== false){$serverdomain = 'ftp://';}
$maindomain = str_ireplace('http://','',$maindomain);
$maindomain = str_ireplace('https://','',$maindomain);
$maindomain = str_ireplace('ftp://','',$maindomain);
$maindomainx = explode("/",$maindomain); 
$maindomainy = explode('?',$maindomainx[0]);
unset ($maindomainx[count($maindomainx)-1]);
$maindomainz = implode("/",$maindomainx); 
$maindomain = $maindomainy[0];

foreach ($html->find('script') as $ascript){
if (stripos($ascript->innertext,'document.write') !== false){
$scriptrewrite = str_replace(array('<!--','//-->','document.write',"('","');"),'',$ascript->innertext);
$ascript->outertext = $scriptrewrite;}
if (stripos($ascript->src,'doubleclick') !== false){$ascript->outertext = '';}
if (stripos($ascript->src,'google') !== false){$ascript->outertext = '';}
if (stripos($ascript->innertext,'doubleclick') !== false){$ascript->outertext = '';}
if (stripos($ascript->innertext,'google') !== false){$ascript->outertext = '';}
;}

$html = str_get_html($html->innertext);



foreach ($html->find('a[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'//') === false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$alink->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$keepurl = 1; }
}

if ($keepurl !== 1){
$file_ext = explode(".",$alink->href); 
$ext = $file_ext[count($file_ext)-1];
$except = strpos_arr($ext, $exceptextension);
if ($except !== false)$keepurl = 1;

$domain_path = str_replace(array('http://','https://','ftp://'),'',$alink->href);
$domain_path = explode("/",$domain_path); 
$domain_path = $domain_path[0];
if($domain_path){
if(stripos($domain_path, $source_check) === false) {$keepurl = 1;};}
}

if ($keepurl !== 1){
//$alink->title = $alink->href;
//$alink->class = 'gotogo';
$alink->href = str_replace($source_domain,$target_domain,$alink->href);
$alink->href = str_replace($target_domain,$final_domain,$alink->href);

$file_path = explode("/",$alink->title); 
$filename = $file_path[count($file_path)-1];
//if (strpos($filename,'?') !== false) {$alink->title = $alink->title.'&t=newstuf-20&tag=newstuf-20';$alink->href = $alink->href.'&t=newstuf-20&tag=newstuf-20';} 
//else {$alink->title = $alink->title.'?t=newstuf-20&tag=newstuf-20';$alink->href = $alink->href.'?t=newstuf-20&tag=newstuf-20';}
}

//else {
//if (strpos($alink->href,'//') !== false){
//$alink->target = "_blank"; $alink->rel = "nofollow";}
//}

if (stripos($alink->innertext,'next') !==false){
$nextpage = $alink->href;
if (stripos($alink->href,'javascript:void') !==false){
$divchnav = $html->find('div[id=chnav]',0);
$pnext = $divchnav->find('p',1);
$anext = $pnext->find('a',0);
if (isset($anext->href)){$nextpage = $anext->href;}}
$nextpage = str_replace($source_domain,$target_domain,$nextpage);
$nextpage = str_replace($target_domain,$final_domain,$nextpage);
$metarefresh = '<meta http-equiv="refresh" content="10;url='.$nextpage.'">';
$html->find('head',0)->innertext = $metarefresh.$html->find('head',0)->innertext;
$gonext = 1;}



}



if ($gonext !== 1){
$metarefresh = '<meta http-equiv="refresh" content="10">';
if (isset($html->find('head',0)->innertext)) {
$html->find('head',0)->innertext = $metarefresh.$html->find('head',0)->innertext;}
else {echo '<head>'.$metarefresh.'</head>';}
}



foreach ($html->find('*[src]') as $alink) {
if (strpos($alink->src,'//') === false){
preg_match('/[a-zA-Z]+:/',$alink->src,$specialurl);
if (strpos($alink->src,'/') === 0) {$alink->src = $serverdomain.$maindomain.$alink->src;}
else if (strpos($alink->src,$maindomain) === 0 ){$alink->src = $serverdomain.$alink->src;  } 
else {$alink->src = $serverdomain.$maindomainz.'/'.$alink->src; }
}
$alink->src = str_replace($source_domain,$target_domain,$alink->src);
$alink->src = str_replace($target_domain,$final_domain,$alink->src);
}




if (strpos($html->innertext,'<body') === false){
$html->innertext = str_ireplace($source_domain,$target_domain,$html->innertext);
$html->innertext = str_ireplace($target_domain,$final_domain,$html->innertext);
}


echo $html->innertext;
//$fcache = fopen($scrapefile, 'w');
//fwrite($fcache, $html->innertext);
//fclose($fcache);

$termstring = str_ireplace($source_domain,$target_domain,html_entity_decode($html->find('title',0)->innertext));
//echo $termstring;
$html->clear(); 
unset($html);
?>