<div class='wpcfs-search-preset wpcfs-search-preset-<?php echo $id?>'>
<?php
        WPCFSSearchForm::show_form($preset,"preset-$id");
?>
</div>
