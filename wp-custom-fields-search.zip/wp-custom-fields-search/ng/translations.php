<?php /** Auto-generated translation file */

        $translations = array( "Cannot restrict by type {type} in {comparison}" => __("Cannot restrict by type {type} in {comparison}","wp_custom_fields_search"),/*ng//js/app.js */
 "Show All Post Types" => __("Show All Post Types","wp_custom_fields_search"),/*ng//js/app.js */
 "Untitled Preset" => __("Untitled Preset","wp_custom_fields_search"),/*ng//js/app.js */
 "Are you sure you want to delete this preset '%s'?" => __("Are you sure you want to delete this preset '%s'?","wp_custom_fields_search"),/*ng//js/app.js */
 "There is currently no import functionality, the settings export is for debug use only" => __("There is currently no import functionality, the settings export is for debug use only","wp_custom_fields_search"),/*ng//js/app.js */
 "Alphabetical" => __("Alphabetical","wp_custom_fields_search"),/*ng//partials/comparisons/numeric.html */
 "Numeric" => __("Numeric","wp_custom_fields_search"),/*ng//partials/comparisons/numeric.html */
 "Exclusive" => __("Exclusive","wp_custom_fields_search"),/*ng//partials/comparisons/numeric.html */
 "Inclusive" => __("Inclusive","wp_custom_fields_search"),/*ng//partials/comparisons/numeric.html */
 "Only show items from a subtree" => __("Only show items from a subtree","wp_custom_fields_search"),/*ng//partials/datatypes/taxonomy.html */
 "Config" => __("Config","wp_custom_fields_search"),/*ng//partials/form.html */
 "Close" => __("Close","wp_custom_fields_search"),/*ng//partials/form.html, ng//partials/presets.html */
 "Remove" => __("Remove","wp_custom_fields_search"),/*ng//partials/form.html, ng//partials/presets.html */
 "Edit" => __("Edit","wp_custom_fields_search"),/*ng//partials/form.html, ng//partials/presets.html */
 "Add" => __("Add","wp_custom_fields_search"),/*ng//partials/form.html, ng//partials/inputs/select.html */
 "Add Field" => __("Add Field","wp_custom_fields_search"),/*ng//partials/form.html */
 "What should this field be called?" => __("What should this field be called?","wp_custom_fields_search"),/*ng//partials/form.html */
 "How would you like this field to appear?" => __("How would you like this field to appear?","wp_custom_fields_search"),/*ng//partials/form.html */
 "What do you want to search?" => __("What do you want to search?","wp_custom_fields_search"),/*ng//partials/form.html */
 "How do you want to match the search to the data?" => __("How do you want to match the search to the data?","wp_custom_fields_search"),/*ng//partials/form.html */
 "Matches If" => __("Matches If","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html, ng//partials/inputs/textbox.html */
 "Any" => __("Any","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html */
 "All" => __("All","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html */
 "Present" => __("Present","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html, ng//partials/inputs/textbox.html */
 "Data Source:" => __("Data Source:","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html */
 "Auto" => __("Auto","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html, ng//partials/inputs/select.html, js//wp-handlers.js */
 "Manual" => __("Manual","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html, ng//partials/inputs/select.html, js//wp-handlers.js */
 "Value" => __("Value","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html, ng//partials/inputs/hidden.html, ng//partials/inputs/select.html */
 "Label" => __("Label","wp_custom_fields_search"),/*ng//partials/inputs/checkbox.html, ng//partials/inputs/select.html */
 "Data Source" => __("Data Source","wp_custom_fields_search"),/*ng//partials/inputs/select.html */
 "Blank Prompt (e.g. Any)" => __("Blank Prompt (e.g. Any)","wp_custom_fields_search"),/*ng//partials/inputs/select.html */
 "Split Words?" => __("Split Words?","wp_custom_fields_search"),/*ng//partials/inputs/textbox.html */
 "No" => __("No","wp_custom_fields_search"),/*ng//partials/inputs/textbox.html */
 "Yes" => __("Yes","wp_custom_fields_search"),/*ng//partials/inputs/textbox.html */
 "Instantiate this preset in any post or page by entering the shortcode:" => __("Instantiate this preset in any post or page by entering the shortcode:","wp_custom_fields_search"),/*ng//partials/presets.html */
 "Or in your theme files with the PHP code:" => __("Or in your theme files with the PHP code:","wp_custom_fields_search"),/*ng//partials/presets.html */
 "Export Settings" => __("Export Settings","wp_custom_fields_search"),/*ng//partials/presets.html */
 "Allow Blank" => __("Allow Blank","wp_custom_fields_search"),/*js//wp-handlers.js */
); ?>