ai_dummy = true;
