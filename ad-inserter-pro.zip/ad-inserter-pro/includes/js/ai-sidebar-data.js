var sticky_widget_mode   = AI_FUNC_GET_STICKY_WIDGET_MODE;
var sticky_widget_margin = AI_FUNC_GET_STICKY_WIDGET_MARGIN;
var ai_block_class_def = 'AI_FUNCT_GET_BLOCK_CLASS_NAME';

