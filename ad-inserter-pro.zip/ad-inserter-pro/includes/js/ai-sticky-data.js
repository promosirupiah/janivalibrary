var ai_process_sticky_elements_on_ready = true;
var ai_main_content_element = 'AI_FUNCH_GET_MAIN_CONTENT_ELEMENT';

