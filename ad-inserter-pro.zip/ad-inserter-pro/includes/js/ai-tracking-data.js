var ai_internal_tracking = AI_INTERNAL_TRACKING;
var ai_external_tracking = AI_EXTERNAL_TRACKING;

var ai_external_tracking_category  = "AI_EXT_CATEGORY";
var ai_external_tracking_action    = "AI_EXT_ACTION";
var ai_external_tracking_label     = "AI_EXT_LABEL";
var ai_external_tracking_username  = "WP_USERNAME";

var ai_track_pageviews = AI_TRACK_PAGEVIEWS;
var ai_advanced_click_detection = AI_ADVANCED_CLICK_DETECTION;
var ai_viewport_widths = AI_VIEWPORT_WIDTHS;
var ai_viewport_indexes = AI_VIEWPORT_INDEXES;
var ai_viewport_names_string = "AI_VIEWPORT_NAMES";
var ai_data_id = "AI_NONCE";
var ai_ajax_url = 'AI_AJAXURL';
var ai_debug_tracking = AI_DEBUG_TRACKING;
var ai_adb_attribute = AI_ADB_ATTR_NAME;
