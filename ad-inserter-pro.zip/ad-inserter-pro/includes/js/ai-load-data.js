var ai_recaptcha_threshold = "AI_FUNC_GET_RECAPTCHA_THRESHOLD";
var ai_recaptcha_site_key = "AI_FUNC_GET_RECAPTCHA_SITE_KEY";
var ai_lazy_loading_offset = AI_FUNC_GET_LAZY_LOADING_OFFSET;
var ai_ajax_url = 'AI_AJAXURL';

