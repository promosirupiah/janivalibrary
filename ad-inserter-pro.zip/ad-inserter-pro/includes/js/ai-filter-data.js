var ai_filter = true;
var ai_data_id = "AI_NONCE";
var ai_ajax_url = 'AI_AJAXURL';
var ai_block_class_def = 'AI_FUNCT_GET_BLOCK_CLASS_NAME';

