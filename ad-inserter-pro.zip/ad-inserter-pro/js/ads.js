var e=document.createElement("div");e.id="dqwpediwqswqma";e.style.display="none";document.body.appendChild(e);
