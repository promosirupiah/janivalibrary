window.ad_300x250=true;
