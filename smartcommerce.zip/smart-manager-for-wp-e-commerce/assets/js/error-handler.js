class SMErrorHandler {
    static log(msg, error){
        console.log(msg, error)
    }
}