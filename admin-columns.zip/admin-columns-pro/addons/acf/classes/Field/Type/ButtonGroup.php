<?php

declare(strict_types=1);

namespace ACA\ACF\Field\Type;

use ACA\ACF\Field;

class ButtonGroup extends Field implements Field\Choices
{

    use ChoicesTrait;
}