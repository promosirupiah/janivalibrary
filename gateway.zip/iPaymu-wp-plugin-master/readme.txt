=== iPaymu&nbsp; Wordpress Payment Gateway Plugin ===
Contributors: iPaymu Development Team
Tags: iPaymu, payment gateway, payment processor, payment gateway indonesia, pembayaran virtual account, pembayaran qris, pembayaran indomaret, pembayaran alfamart, pembayaran kartu kredit.
Requires at least: 6.3
Tested up to: 8.6.1
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
