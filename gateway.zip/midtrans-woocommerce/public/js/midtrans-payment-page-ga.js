window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
ga('create', wc_midtrans.ganalytics_id, 'auto');
ga('send', 'pageview');