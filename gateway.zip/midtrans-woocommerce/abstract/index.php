<?php
// Silence is golden. Output nothing to avoid exposing directory listing
