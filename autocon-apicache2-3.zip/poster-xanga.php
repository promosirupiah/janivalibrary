<?php

//multiple xanga account
$xncount .= 1;
$xn[$xncount]['username'] = "username";
$xn[$xncount]['password'] = "password";
$xn[$xncount]['url'] = "http://api.xanga.com/metaweblogapi";
$xncount .= 1;
$xn[$xncount]['username'] = "username";
$xn[$xncount]['password'] = "password";
$xn[$xncount]['url'] = "http://api.xanga.com/metaweblogapi";


foreach ($xn as $wpx) {
$BLOGURL = $wpx['url'];
$USERNAME = $wpx['username'];
$PASSWORD = $wpx['password'];


  $title = $posters[$counter]['title'];
 $description = '<a href="'.$posters[$counter]['url'].'">'.$posters[$counter]['title'].'</a><br>'.$posters[$counter]['desc'];
  


  $content['title'] = $title;
  $content['description'] = $description;
  $toPublish = true;
  $request = xmlrpc_encode_request("metaWeblog.newPost",array('1',$USERNAME, $PASSWORD, $content, $toPublish));

  $xmlresponse = get_response($BLOGURL, $request);

  $response = xmlrpc_decode($xmlresponse);
  /*Printing the response on to the console*/
 // print_r($response);
// echo "\n";

}
  ?>