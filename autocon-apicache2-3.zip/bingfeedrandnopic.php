<div class="postx">
<?php 
require_once './magpie/rss_fetch.inc';

$url = 'http://www.bing.com/search?q='.urlencode($termstring).urlencode($addsearch).'&form=OSDSRC&format=rss';
$rss = fetch_rss($url);
if ($rss) {
foreach ( $rss->items as $item ) { ?>

<?php
$bingtitles []= '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
if (rand(0,4)== 0 ) {
$bingdescs .= '</p>'.clean_desc(ucfirst($item['description'])).'<p>';
} else {$bingdescs .= clean_desc(ucfirst($item['description']));}


 }
echo '<p>'.clean_desc($bingdescs).'</p>';
foreach (array_unique($bingtitles) as $bingtitle) {
echo $bingtitle;
}
}
 ?>
</div>

