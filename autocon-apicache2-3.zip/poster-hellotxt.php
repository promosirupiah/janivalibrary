<?php
require_once('./simple_html_dom.php');
if(!function_exists('ubah_tanda')) {
function ubah_tanda($result) { //fungsi ubah spasi jadi plus pada permalink title
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
		$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
}
}
$hellotxtlogins[] = array ('nick'=>'amazishop@gmail.com','pwd'=>'Madx812812');
//$pinglogins[] = array ('email'=>'xxx','password'=>'xxx');

foreach ($hellotxtlogins as $hellotxtlogin){
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1A543a Safari/419.3 ");
curl_setopt($ch, CURLOPT_COOKIEJAR, ubah_tanda($hellotxtlogin['nick']).'_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, ubah_tanda($hellotxtlogin['nick']).'_cookies.txt');



curl_setopt($ch, CURLOPT_URL, 'http://m.hellotxt.com/');
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
$html = str_get_html($response);
$authz = $html->find('input[id="nick"]',0)->name;
//echo $responseinfo['url'].'<br>';
//echo $response.'<br style="clear:both">';
if ($authz == 'nick')
{
//$html = str_get_html($response);
//$authz = $html->find('input[name="authenticity_token"]',0)->value;
//$pinglogin['authenticity_token'] = $html->find('input[name="authenticity_token"]',0)->value;
$hellotxtlogin['redirect'] = 'Lw==';
$hellotxtlogin['login'] = 'Sign In';
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $hellotxtlogin);
curl_setopt($ch, CURLOPT_URL, 'http://m.hellotxt.com/');
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
echo $responseinfo['url'].'<br>';
echo $response.'<br style="clear:both">';
$html = str_get_html($response);
}
//$html = str_get_html($response);
//$authz = $html->find('input[name="authenticity_token"]',0)->value;
//foreach ($postings as $posting) {

//$pingposter = array("service" => '', "message"=>$posting['url'].' '.$posting['title']);

$hellotxtposter['textarea_update'] = 'love';
$hellotxtposter['user_token'] = $html->find('input[name="user_token"]',0)->value;
//$hellotxtposter['media'] = 'pic';
$hellotxtposter['update'] = 'Post';
$hellotxtposter['group']['tags'] = 'tags';

$helloservices = $html->find('input[name="social_services[]"]'); foreach ($helloservices as $helloservice) {
$hellotxtposter['social_services'][] = $helloservice->value;
$hellotxtposter['social_services[]'][] = $helloservice->value;
//echo $helloservice->value.'<br>';
}

//echo serialize($hellotxtposter);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $hellotxtposter);
curl_setopt($ch, CURLOPT_URL, 'http://m.hellotxt.com/update-status');
$response = curl_exec($ch);
echo $response.'<br style="clear:both">';
//}
//$html->clear(); 
//unset($html);
}
?>