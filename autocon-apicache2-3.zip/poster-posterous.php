<?php 



$posterouscount .= 1;
$posterous[$posterouscount]['username'] = "xxx@xxx.xxx";
$posterous[$posterouscount]['password'] = "xxx";
$posterouscount .= 1;
$posterous[$posterouscount]['username'] = "xxx@xxx.xxx";
$posterous[$posterouscount]['password'] = "xxx";

$title = $posters[$counter]['title'];
$description = '<a href="'.$posters[$counter]['url'].'">'.$posters[$counter]['title'].'</a><br>'.$posters[$counter]['desc'];
  
foreach ($posterous as $postr){
$tokencache = './tokencache/postr_'.base64_encode($postr['username']).'.txt';
if (file_exists($tokencache))
{$posterous_token = file_get_contents($tokencache);
//echo '<br>using cache<br>';
}
else {
//echo '<br>request<br>';
$request = poster_pass('http://posterous.com/api/2/auth/token',$postr['username'],$postr['password']);
$token = json_decode($request);
$posterous_token = $token->api_token;

$fp = fopen($tokencache, 'w');
fwrite($fp, $posterous_token);
fclose($fp);
}
//echo $posterous_token;
$content = array('post[title]'=> $title,'post[body]'=>$description,'api_token'=>$posterous_token);
$result = poster_curl('http://posterous.com/api/2/users/me/sites/primary/posts', $content, $postr['username'], $postr['password']);
//echo $result;
}

?>