<div class="postx">
<?php 
include_once('./rewrite3.php');
require_once ('./magpie/rss_fetch.inc');
unset($gbdescs);
if (!$ads){$ads=1;} else {$ads = 1 + $ads;}
$url = 'http://www.bing.com/search?q='.urlencode($termstring).urlencode($addsearch).'&form=OSDSRC&format=rss';
$rss = fetch_rss($url);
if ($rss->items){
echo '<h2>'.ucwords($termstring).'</h2><br>';
echo '<script type="text/javascript" src="ads'.$ads.'.php"></script>';
$ads = $ads + 1;
echo '<script type="text/javascript" src="ads'.$ads.'.php"></script>';
foreach ( $rss->items as $item ) { ?>

<?php
//$gblogtittles[] = '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
if (rand(0,4)== 0 ) {
if($ads !==5){$ads = $ads + 1;}
if ($ads !== 5){$gbdescs .= '</p><script type="text/javascript" src="ads'.$ads.'.php"></script><p>'.clean_desc(ucfirst($item['description'])).' ';}
else{$gbdescs .= '</p><input type="hidden" name="IL_RELATED_TAGS" value="1"/><p>'.clean_desc(ucfirst($item['description'])).' ';}
} 
else {$gbdescs .= clean_desc(ucfirst($item['description'])).' ';}
if ($termstring !== ubah_space(CleanFileNameBan($item['title']))){
$gbdescs .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/?ur='.base64_encode($item['link']).'&cat=sch" target="_blank">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a> ';
}
 } ?>

<?php 
echo '<p>'.rewrite_text($gbdescs,$case_sensitive=false).'</p>';
//foreach (array_unique($gblogtittles) as $gbtitles) {echo $gbtitles;}
}
unset($gbdescs);
?>
</div>
