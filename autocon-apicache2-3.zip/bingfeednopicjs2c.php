<div class="postx">
<?php 
include_once('./rewrite3.php');
require_once ('./magpie/rss_fetch.inc');
unset($gbdescs);
if (!$ads){$ads=1;}
$url = 'http://www.bing.com/search?q='.urlencode($termstring).urlencode($addsearch).'&form=OSDSRC&format=rss';
$rss = fetch_rss($url);

foreach ( $rss->items as $item ) { ?>

<?php
//$gblogtittles[] = '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
if (rand(0,4)== 0 ) {
$gbdescs .= '</p><script type="text/javascript" src="ads'.$ads.'.php"></script><p>'.clean_desc(ucfirst($item['description'])).' ';
$ads = $ads + 1;} else {$gbdescs .= clean_desc(ucfirst($item['description'])).' ';}
if ($termstring !== ubah_space(CleanFileNameBan($item['title']))){
$gbdescs .= '<script type="text/javascript" src="/jslink.php?o='.urlencode(base64_encode($_SERVER["SERVER_NAME"])).'&t='.urlencode(base64_encode(CleanFileNameBan($item['title']))).'"></script>';
//$gbdescs .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/?s='.ubah_tanda(CleanFileNameBan($item['title'])).'&cat=sch" target="_blank">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a> ';
}
 } ?>

<?php 
echo '<p>'.rewrite_text($gbdescs,$case_sensitive=false).'</p>';
//foreach (array_unique($gblogtittles) as $gbtitles) {echo $gbtitles;}
unset($gbdescs);
?>
</div>
