<?php
require_once './magpie/rss_fetch.inc';
require_once('./simple_html_dom.php');
require_once ('./Readability.php');


$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
//curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729)");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $_REQUEST['u']);
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );



//domain check for known unhandle website
//$domainscheck[]='youtube.com';
//$domainscheck[]='google.com';
//$domainscheck[]='facebook.com';
//$domainscheck[]='twitter.com';
//$domainscheck[]='launchpad.net';


$exceptextension[]='.rpm';
$exceptextension[]='.pdf';
$exceptextension[]='.sig';
$exceptextension[]='.spl';
$exceptextension[]='.class';
$exceptextension[]='.torrent';
$exceptextension[]='.dvi';
$exceptextension[]='.gz';
$exceptextension[]='.pac';
$exceptextension[]='.swf';
$exceptextension[]='.tar.gz';
$exceptextension[]='.tgz';
$exceptextension[]='.tar';
$exceptextension[]='.zip';
$exceptextension[]='.mp3';
$exceptextension[]='.m3u';
$exceptextension[]='.wma';
$exceptextension[]='.wax';
$exceptextension[]='.ogg';
$exceptextension[]='.wav';
$exceptextension[]='.gif';
$exceptextension[]='.jar';
$exceptextension[]='.jpg';
$exceptextension[]='.jpeg';
$exceptextension[]='.png';
$exceptextension[]='.xbm';
$exceptextension[]='.xpm';
$exceptextension[]='.xwd';
$exceptextension[]='.css';
$exceptextension[]='.js';
$exceptextension[]='.asc';
$exceptextension[]='.cpp';
$exceptextension[]='.log';
$exceptextension[]='.conf';
$exceptextension[]='.text';
$exceptextension[]='.txt';
$exceptextension[]='.dtd';
$exceptextension[]='.xml';
$exceptextension[]='.mpeg';
$exceptextension[]='.mpg';
$exceptextension[]='.mov';
$exceptextension[]='.qt';
$exceptextension[]='.exe';
//$exceptextension[]='https://';
//$exceptextension[]='ftp://';
//$exceptextension[]='#';
//$exceptextension[]='mailto:';
//$exceptextension[]='skype:';
//$exceptextension[]='javascript:';
$maindomain = $responseinfo['url'];
if (strpos($responseinfo['url'],'http://') !== false){$serverdomain = 'http://';}
if (strpos($responseinfo['url'],'https://') !== false){$serverdomain = 'https://';}
if (strpos($responseinfo['url'],'ftp://') !== false){$serverdomain = 'ftp://';}


$maindomain = str_ireplace('http://','',$maindomain);
$maindomain = str_ireplace('https://','',$maindomain);
$maindomain = str_ireplace('ftp://','',$maindomain);
$maindomainx = explode("/",$maindomain); 
$maindomainy = explode('?',$maindomainx[0]);
$maindomain = $maindomainy[0];


//foreach ($domainscheck as $domaincheck){
//$exception = false;
//$pos = stripos($responseinfo['url'],$domaincheck);
//if ($pos !== false)$domainexception = true;
//}



$readability = new Readability($response, $responseinfo['url']);
$readability->debug = false;
$readability->convertLinksToFootnotes = false;
$result = $readability->init();
if ($result) {
	
	$content = $readability->getContent()->innerHTML;
	// if we've got Tidy, let's clean it up for output
	if (function_exists('tidy_parse_string')) {
		$tidy = tidy_parse_string($content, array('indent'=>true, 'show-body-only' => true), 'UTF8');
		$tidy->cleanRepair();
		$content = $tidy->value;
	}
$html = str_get_html($content);
$hrefcount = 0;
foreach ($html->find('*[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$html->find('*[href]',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$html->find('*[href]',$hrefcount)->href = $alink->href; $keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$html->find('*[href]',$hrefcount)->href = $alink->href; $keepurl = 1; }
else if (strpos($alink->href,$maindomain) === 0 ){$html->find('*[href]',$hrefcount)->href = $serverdomain.$alink->href;  } 
else {$html->find('*[href]',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}
//if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test9.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
$hrefcount = $hrefcount + 1;
}

$hrefcount = 0;
foreach ($html->find('a[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$html->find('a[href]',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$html->find('a[href]',$hrefcount)->href = $alink->href; $keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$html->find('a[href]',$hrefcount)->href = $alink->href; $keepurl = 1; }
else if (strpos($alink->href,$maindomain) === 0 ){$html->find('a[href]',$hrefcount)->href = $serverdomain.$alink->href;  } 
else {$html->find('a[href]',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}
foreach ($exceptextension as $except) {
$pos = strpos($alink->href,$except);
if ($pos !== false)$exception = true;
}
if ($exception != true){
if ($keepurl !== 1){$html->find('a[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test9.php?u='.urlencode($html->find('a[href]',$hrefcount)->href);}
}
else {
$html->find('a[href]',$hrefcount)->target = "_blank"; $html->find('a[href]',$hrefcount)->rel = "nofollow";
}

$hrefcount = $hrefcount + 1;
}


$hrefcount = 0;
foreach ($html->find('*[src]') as $alink) {
$keepurl = 0;
if (strpos($alink->src,'://') == false && $alink->src !== false){
preg_match('/[a-zA-Z]+:/',$alink->src,$specialurl);
if (strpos($alink->src,'/') === 0){$html->find('*[src]',$hrefcount)->src = $serverdomain.$maindomain.$alink->src; }
else if (strpos($alink->src,'#') === 0 ){$html->find('*[src]',$hrefcount)->src = $alink->src; $keepurl = 1;}
else if (strpos($alink->src,$specialurl[0]) === 0 && $specialurl !==false){$html->find('*[src]',$hrefcount)->src = $alink->src; $keepurl = 1; }
else if (strpos($alink->src,$maindomain) === 0 ){$html->find('*[src]',$hrefcount)->src = $serverdomain.$alink->src;  } 
else {$html->find('*[src]',$hrefcount)->src = $serverdomain.$maindomain.'/'.$alink->src; }
}
//if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test8.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
$hrefcount = $hrefcount + 1;
}

$hrefcount = 0;
foreach ($html->find('form') as $ascript){ 
if (strpos($ascript->action,'://') == false && $ascript->action !== false){
if (strpos($ascript->action,'/') === 0){$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.$ascript->action; }
else if (strpos($ascript->action,$maindomain) !== false){$html->find('form',$hrefcount)->action = $ascript->action; } 
else {$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.'/'.$ascript->action; }
}
$hrefcount = $hrefcount + 1;}


$hrefcount = 0;
foreach ($html->find('input[type=submit]') as $ascript){ 
$html->find('input[type=submit]',$hrefcount)->onclick = "this.form.target='_blank';return true;";
$hrefcount = $hrefcount + 1;}
echo $html;
} 

else { 
$html = str_get_html($response);
$hrefcount = 0;
foreach ($html->find('*[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$html->find('*[href]',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$html->find('*[href]',$hrefcount)->href = $alink->href; $keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$html->find('*[href]',$hrefcount)->href = $alink->href; $keepurl = 1; }
else if (strpos($alink->href,$maindomain) === 0 ){$html->find('*[href]',$hrefcount)->href = $serverdomain.$alink->href;  } 
else {$html->find('*[href]',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}
//if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test9.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
$hrefcount = $hrefcount + 1;
}

$hrefcount = 0;
foreach ($html->find('a[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$html->find('a[href]',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$html->find('a[href]',$hrefcount)->href = $alink->href; $keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$html->find('a[href]',$hrefcount)->href = $alink->href; $keepurl = 1; }
else if (strpos($alink->href,$maindomain) === 0 ){$html->find('a[href]',$hrefcount)->href = $serverdomain.$alink->href;  } 
else {$html->find('a[href]',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}
foreach ($exceptextension as $except) {
$pos = strpos($alink->href,$except);
if ($pos !== false)$exception = true;
}
if ($exception != true){
if ($keepurl !== 1){$html->find('a[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test9.php?u='.urlencode($html->find('a[href]',$hrefcount)->href);}
}
else {
$html->find('a[href]',$hrefcount)->target = "_blank"; $html->find('a[href]',$hrefcount)->rel = "nofollow";
}

$hrefcount = $hrefcount + 1;
}


$hrefcount = 0;
foreach ($html->find('*[src]') as $alink) {
$keepurl = 0;
if (strpos($alink->src,'://') == false && $alink->src !== false){
preg_match('/[a-zA-Z]+:/',$alink->src,$specialurl);
if (strpos($alink->src,'/') === 0){$html->find('*[src]',$hrefcount)->src = $serverdomain.$maindomain.$alink->src; }
else if (strpos($alink->src,'#') === 0 ){$html->find('*[src]',$hrefcount)->src = $alink->src; $keepurl = 1;}
else if (strpos($alink->src,$specialurl[0]) === 0 && $specialurl !==false){$html->find('*[src]',$hrefcount)->src = $alink->src; $keepurl = 1; }
else if (strpos($alink->src,$maindomain) === 0 ){$html->find('*[src]',$hrefcount)->src = $serverdomain.$alink->src;  } 
else {$html->find('*[src]',$hrefcount)->src = $serverdomain.$maindomain.'/'.$alink->src; }
}
//if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test8.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
$hrefcount = $hrefcount + 1;
}

$hrefcount = 0;
foreach ($html->find('form') as $ascript){ 
if (strpos($ascript->action,'://') == false && $ascript->action !== false){
if (strpos($ascript->action,'/') === 0){$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.$ascript->action; }
else if (strpos($ascript->action,$maindomain) !== false){$html->find('form',$hrefcount)->action = $ascript->action; } 
else {$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.'/'.$ascript->action; }
}
$hrefcount = $hrefcount + 1;}


$hrefcount = 0;
foreach ($html->find('input[type=submit]') as $ascript){ 
$html->find('input[type=submit]',$hrefcount)->onclick = "this.form.target='_blank';return true;";
$hrefcount = $hrefcount + 1;}




//foreach ($html->find('link') as $link){echo $link->outertext;}

$html->find('head title',0)->outertext = '';
echo $html->find('head',0)->innertext;
echo $html->find('body',0)->innertext; 
// echo $html;
$html->clear(); 
unset($html);
}






?>