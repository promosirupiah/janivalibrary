<?php
//header('Content-Type: text/xml; charset=UTF-8', true);
function ubah_tanda($result) { //change all special character to "-"
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
	$result = str_replace(array('___','__','_'),'-',$result);
	$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
}
function ubah_space($result) { //change all special character to " "
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', ' ', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
	$result = preg_replace('|-+|', ' ', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
	$result = str_replace(array('___','__','_'),' ',$result);
	$result = str_replace(array('    ','   ','  '), ' ', $result);
	$result = trim($result, ' ');
	return $result;
}
function CleanFileNameBan($result){
$bannedkey = array("<b>","</b>","...","..","crack","keygen","rapidshare","megaupload","http",".com",".net",".org",".jpg","blogspot.com","torrent","youtube","www","yahoo","index","the free encyclopedia","alcohol","cigarette","cigarettes","gamble","casino","sex","porn"); //remove those words on title result, lowercase only
$result = strtolower($result);
$result = str_ireplace($bannedkey, '',$result);
$result = str_ireplace(array('  ','   ','    '), ' ',$result);
$result = trim($result);
return $result;
}
function hilangkan_spesial_karakter($result) { //fungsi hilangkan semua spesial karakter pada Title
	$result = strip_tags($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', ' ', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
	$result = preg_replace('|-+|', ' ', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
		$result = str_replace(array('    ','   ','  '), ' ', $result);
	$result = trim($result, ' ');
	return $result;
}

include_once('./simple_html_dom.php');
if (isset($_REQUEST['as_qdr'])) {
$feedgrab = 'http://www.google.com/search?q='.urlencode($_REQUEST['q']).'&hl=en&tbm=blg&output=rss&tbs=qdr:'.$_REQUEST['as_qdr'];
}
else {
$feedgrab = 'http://www.google.com/search?q='.urlencode($_REQUEST['q']).'&hl=en&tbm=blg&output=rss'; }
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
//curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729)");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $feedgrab);
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
$html = str_get_html($response);
//echo $response;
foreach ($html->find('item') as $item) {
//echo $item->innertext;
preg_match("@<link[^>]*?>.*?</link>@siu",$item->innertext,$links);
$linkgo = html_entity_decode(str_replace(array('<link>','</link>'),'',$links[0]));
$item->innertext = preg_replace("@<link[^>]*?>.*?</link>@siu", '<link>'.htmlentities('http://'.$_SERVER["SERVER_NAME"].'/?ur='.base64_encode($linkgo).'&cat=full').'</link>', $item->innertext);
$item->innertext = preg_replace("@<title[^>]*?>.*?</title>@siu", '<title>'.ucwords(ubah_space(CleanFileNameBan(html_entity_decode($item->find('title',0)->innertext)))).'</title>', $item->innertext);

preg_match("@<link[^>]*?>.*?</link>@siu",$item->innertext,$links);
//$linkx[] = html_entity_decode(str_replace(array('<link>','</link>'),'',$links[0]));
preg_match("@<title[^>]*?>.*?</title>@siu",$item->innertext,$titles);
//$titlex[] = html_entity_decode(str_replace(array('<title>','</title>'),'',$titles[0]));
$descriptionx[] = html_entity_decode($item->find('description',0)->innertext);

$items[] = array('link'=>html_entity_decode(str_replace(array('<link>','</link>'),'',$links[0])),'title'=>html_entity_decode(str_replace(array('<title>','</title>'),'',$titles[0])),'description'=>html_entity_decode($item->find('description',0)->innertext));
//$item->find('title',0)->innertext = ucwords(ubah_space(CleanFileNameBan(html_entity_decode($item->find('title',0)->innertext))));
//$item->find('link',0)->innertext = 'http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda($item->find('title',0)->innertext);
}
$html->find('channel title',0)->innertext = str_replace('- Google Blog Search','',$html->find('channel title',0)->innertext);
$html->find('channel',0)->innertext = preg_replace("@<link[^>]*?>.*?</link>@siu",'<link>http://'.$_SERVER["SERVER_NAME"].'</link>',$html->find('channel',0)->innertext,1);
echo $html;

//include('./poster2.php');

$html->clear(); 
unset($html);
?>