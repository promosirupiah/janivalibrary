<?php 
$stcount .= 1;
$statusnet[$stcount]['url'] = "http://updateme.com/api/statuses/update.xml";
$statusnet[$stcount]['username'] = "username";
$statusnet[$stcount]['password'] = "password";
$stcount .= 1;
$statusnet[$stcount]['url'] = "http://identi.ca/api/statuses/update.xml";
$statusnet[$stcount]['username'] = "username";
$statusnet[$stcount]['password'] = "password";

$statuspost = array ('status'=>$posters[$counter]['url']);
foreach ($statusnet as $status) {
poster_curl($status['url'],$statuspost,$status['username'],$status['password']);
}

?>