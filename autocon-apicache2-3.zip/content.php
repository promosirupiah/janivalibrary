
<?php
function pete_curl_get($url, $params){$post_params = array();
foreach ($params as $key => &$val) {
if (is_array($val)) $val = implode(',', $val);
$post_params[] = $key.'='.urlencode($val);
}
$post_string = implode('&', $post_params);
$fullurl = $url."?".$post_string;
$ch = curl_init();curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);curl_setopt($ch, CURLOPT_URL, $fullurl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7) Gecko/20040608'); //choose user agent, see www.user-agents.org
$result = curl_exec($ch);curl_close($ch);
return $result;
}

 ?>



<?php 

$target[]='domain.com';
$target[]='domain.com';
$target[]='domain.com';

if (($_SERVER["REQUEST_URI"]) =='/'){
include ('./blogsearchfancy.php');//for frontpage
}
else if (in_array($termstring, $categories)) {
include ('./catblogsearchjsx2.php'); //for categories
}
else {

include ('./catblogsearchjsx2.php');
include('./catblogsearchnopicjs2c.php');
include('./bingfeednopicjs2c.php');

}
 ?>




