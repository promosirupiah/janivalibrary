<?php 
require_once('./simple_html_dom.php');
function get_response($URL, $context) {
 if(!function_exists('curl_init')) {
 die ("Curl PHP package not installed\n");
 }

 /*Initializing CURL*/
 $ch = curl_init();

 /*The URL to be downloaded is set*/
 curl_setopt($ch, CURLOPT_URL, $URL);
 curl_setopt($ch, CURLOPT_HEADER, false);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $context);
 curl_setopt($ch, CURLOPT_COOKIEJAR, "my_cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "my_cookies.txt");

 /*Now execute the CURL, download the URL specified*/
 $response = curl_exec($ch);
 return $response;
}
function poster_curl ($url, $data, $username, $password){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_COOKIEJAR, "my_cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "my_cookies.txt");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$response = curl_exec($ch);
// $info = curl_getinfo($ch);
return $response;
}

function poster_pass ($url, $username, $password){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_COOKIEJAR, "my_cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "my_cookies.txt");
$response = curl_exec($ch);
// $info = curl_getinfo($ch);
return $response;
}

function get_url($url){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_COOKIEJAR, "my_cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "my_cookies.txt");
$response = curl_exec($ch);
return $response;
}

if (file_exists('./datapost1.txt')) { $datapost1 = unserialize(file_get_contents('./datapost1.txt')) ;}else $datapost1[] ='';
if (file_exists('./datapost2.txt')) { $datapost2 = unserialize(file_get_contents('./datapost2.txt')) ;}else $datapost2[] ='';
if (count($datapost1) > 5000 ) {$dataposter1 = 'limit'; 
//echo '|dataposter1 limit ';
};
if (count($datapost2) > 5000 ) {$dataposter2 = 'limit'; 
//echo '|dataposter2 limit ';
};
$datapostcheck1 = $datapost1;
$datapostcheck2 = $datapost2;
$counter = 0;
foreach ( $rss->items as $item ) {
$counter .=1;
$item['title']= str_replace(array('<b>','</b>','...','..'),'',$item['title']);
$posters[$counter]['url'] = 'http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(urlencode($item['title']))).'&cat=full';
$posters[$counter]['title']= str_replace(array('<b>','</b>','...','..'),'',$item['title']);
$posters[$counter]['desc']= str_replace(array('<b>','</b>','...','..'),'',$item['description']);

if (!in_array($posters[$counter]['url'],$datapost1) && (!in_array($posters[$counter]['url'],$datapost2)) ){
//start posting

//include('./poster-statusnet.php');
//include('./poster-wordpress.php');
//include('./poster-xanga.php');
//include ('./poster-ping.php');
//include ('./poster-multiply.php');
//include ('./poster-livejournal.php');
//include('./poster-posterous.php');
//end posting, start log

$postings[]=array('url'=>$posters[$counter]['url'],'title'=>$posters[$counter]['title'],'desc'=>$posters[$counter]['desc']);

if ($dataposter1 != 'limit'){
$datapost1[] = $posters[$counter]['url']; 
//echo '|add url '.$posters[$counter]['url'].' to datapost1 ';
 }
else {
$datapost2[] = $posters[$counter]['url'];
//echo '|add url '.$posters[$counter]['url'].' to datapost2 ';
 }
}

}
if (isset($postings)){
//start posting 2nd method 
// include ('./poster-twitter.php');
//include ('./poster-pingomatic.php');
//include ('./poster-pingfm.php');
//end posting 2nd method
}
if ($dataposter1 != 'limit' && ($datapostcheck1 != $datapost1) ){
$fcache = fopen('./datapost1.txt', 'w');
$response = serialize($datapost1);
fwrite($fcache, $response);
fclose($fcache); 
//echo '|add url to file datapost1.txt ';
if (count($datapost1) > 5000 ) {
if (file_exists('./datapost2.txt')) {unlink('./datapost2.txt'); 
//echo '|delete datapost2.txt because datapost1.txt full ';
}}}

else if ($datapostcheck2 != $datapost2) {
$fcache = fopen('./datapost2.txt', 'w');
$response = serialize($datapost2);
fwrite($fcache, $response);
fclose($fcache);
//echo '|add url to file datapost2.txt';
if (count($datapost2) > 5000 ) {
unlink('./datapost1.txt'); 
//echo '|delete datapost1.txt because datapost2.txt full ';
}
}
 ?>

