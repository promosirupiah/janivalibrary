
<?php 

if (!$ads){$ads=1;}
include_once(TEMPLATEPATH .'/rewrite3.php');
require_once (TEMPLATEPATH .'/magpie/rss_fetch.inc');
$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($main_title).urlencode($addsearch).'&ie=utf-8&num=5&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>
<div class="postx">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?s='.ubah_tanda(CleanFileNameBan($item['title'])).'&cat=sch">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode(ubah_space(CleanFileNameBan($item['title']))); 
$response = pete_curl_get($request, array());

$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>
<a rel="popupgroup" title="<?php echo htmlentities('<a href="http://'.$_SERVER["SERVER_NAME"].'/?s='.ubah_tanda(CleanFileNameBan($content->Title)).'&cat=full">'.$content->Title.'</a><br><a href="http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($content->Url).'" rel="nofollow" target="_blank">read source</a>');?>" href="<?php echo $content->MediaUrl; ?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title)));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title)));?>" src="<?php echo $content->MediaUrl; ?>"></a>

<?php } ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode(ubah_space(CleanFileNameBan($item['title']))); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a rel="popupgroup" href="<?php echo $content->url; ?>" title="<?php echo htmlentities('<a href="http://'.$_SERVER["SERVER_NAME"].'/?s='.ubah_tanda(CleanFileNameBan($content->titleNoFormatting)).'&cat=full">'.$content->titleNoFormatting.'</a><br><a href="http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($content->originalContextUrl).'" rel="nofollow" target="_blank">read source</a>');?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting)));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting)));?>" src="<?php echo $content->unescapedUrl; ?>"></a>

<?php } ?>
<?php
//echo '<br style="clear:both"><p>'.clean_desc($item['description']).'</p><br style="clear:both">';
?>
<br style="clear:both">
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/<?php echo 'ads'.$ads.'.php';$ads = $ads+1;?>"></script>
<br style="clear:both">
<p><?php echo rewrite_text(clean_desc($item['description']),$case_sensitive=false);?></p>
<br style="clear:both">

</div>
<?php } ?>


