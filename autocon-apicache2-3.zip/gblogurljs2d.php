<div class="postx">
<?php
include_once('./simple_html_dom.php');
include_once('./rewrite3.php');
$feedgrab = 'http://www.google.com/search?q='.urlencode($termstring).urlencode($addsearch).'&hl=en&tbm=blg&output=rss'; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
//curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729)");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $feedgrab);
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
$htmlx = str_get_html($response);
//echo $response;
foreach ($htmlx->find('item') as $item) {
//echo $item->innertext;
$item->innertext = preg_replace("@<title[^>]*?>.*?</title>@siu", '<title>'.ucwords(ubah_space(CleanFileNameBan(html_entity_decode($item->find('title',0)->innertext)))).'</title>', $item->innertext);

preg_match("@<link[^>]*?>.*?</link>@siu",$item->innertext,$links);
$linkx = html_entity_decode(str_replace(array('<link>','</link>'),'',$links[0]));
preg_match("@<title[^>]*?>.*?</title>@siu",$item->innertext,$titles);
$titlex = html_entity_decode(str_replace(array('<title>','</title>'),'',$titles[0]));
$descriptionx = html_entity_decode($item->find('description',0)->innertext);

$items[] = array('link'=>html_entity_decode(str_replace(array('<link>','</link>'),'',$links[0])),'title'=>html_entity_decode(str_replace(array('<title>','</title>'),'',$titles[0])),'description'=>html_entity_decode($item->find('description',0)->innertext));
//$item->find('title',0)->innertext = ucwords(ubah_space(CleanFileNameBan(html_entity_decode($item->find('title',0)->innertext))));
//$item->find('link',0)->innertext = 'http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda($item->find('title',0)->innertext);
}
//$htmlx->find('channel title',0)->innertext = str_replace('- Google Blog Search','',$htmlx->find('channel title',0)->innertext);
//echo $htmlx;



if ($items){
echo '<h2>'.ucwords($termstring).'</h2><br>';
if (!$ads){$ads=1;} else {$ads = 1 + $ads;}
echo '<script type="text/javascript" src="ads'.$ads.'.php"></script>';
$ads = $ads + 1;
echo '<script type="text/javascript" src="ads'.$ads.'.php"></script>';
foreach ($items as $item) { ?>

<?php
//$gblogtittles[] = '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
if (rand(0,4)== 0 ) {
if($ads !==5){$ads = $ads + 1;}
if ($ads !== 5){$gbdescs .= '</p><script type="text/javascript" src="ads'.$ads.'.php"></script><p>'.clean_desc(ucfirst($item['description'])).' ';}
else{$gbdescs .= '</p><input type="hidden" name="IL_RELATED_TAGS" value="1"/><p>'.clean_desc(ucfirst($item['description'])).' ';}
} 
else {$gbdescs .= clean_desc(ucfirst($item['description'])).' ';}
if ($termstring !== ubah_space(CleanFileNameBan($item['title']))){
$gbdescs .= '<script type="text/javascript" src="/jsur.php?o='.urlencode(base64_encode($target[rand(0,count($target)-1)])).'&t='.urlencode(base64_encode(CleanFileNameBan($item['title']))).'&u='.urlencode(base64_encode($item['link'])).'"></script>';
//$gbdescs .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/?ur='.base64_encode($item['link']).'&cat=sch" target="_blank">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a> ';
}
 }
echo '<p>'.rewrite_text($gbdescs,$case_sensitive=false).'</p>';
}
unset($gbdescs); 
$htmlx->clear(); 
unset($htmlx);
?>
</div>