<?php





function strpos_array($haystack, $needles) {
    if ( is_array($needles) ) {
        foreach ($needles as $str) {
            if ( is_array($str) ) {
                $pos = strpos_array($haystack, $str);
            } else {
                $pos = strpos($haystack, $str);
            }
            if ($pos !== FALSE) {
                return $pos;
            }
        }
    } else {
        return strpos($haystack, $needles);
    }
}

function strpos_arr($haystack, $needle) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $what) {
        if(($pos = strpos($haystack, $what))!==false) return $pos;
    }
    return false;
}


//domain check for known unhandle website
//$domainscheck[]='youtube.com';
//$domainscheck[]='google.com';
//$domainscheck[]='facebook.com';
//$domainscheck[]='twitter.com';
//$domainscheck[]='launchpad.net';


$exceptextension[]='.rpm';
$exceptextension[]='.pdf';
$exceptextension[]='.sig';
$exceptextension[]='.spl';
$exceptextension[]='.class';
$exceptextension[]='.torrent';
$exceptextension[]='.dvi';
$exceptextension[]='.gz';
$exceptextension[]='.pac';
$exceptextension[]='.swf';
$exceptextension[]='.tar.gz';
$exceptextension[]='.tgz';
$exceptextension[]='.tar';
$exceptextension[]='.zip';
$exceptextension[]='.mp3';
$exceptextension[]='.m3u';
$exceptextension[]='.wma';
$exceptextension[]='.wax';
$exceptextension[]='.ogg';
$exceptextension[]='.wav';
$exceptextension[]='.gif';
$exceptextension[]='.jar';
$exceptextension[]='.jpg';
$exceptextension[]='.jpeg';
$exceptextension[]='.png';
$exceptextension[]='.xbm';
$exceptextension[]='.xpm';
$exceptextension[]='.xwd';
$exceptextension[]='.css';
$exceptextension[]='.js';
$exceptextension[]='.asc';
$exceptextension[]='.cpp';
$exceptextension[]='.log';
$exceptextension[]='.conf';
$exceptextension[]='.text';
$exceptextension[]='.txt';
$exceptextension[]='.dtd';
$exceptextension[]='.xml';
$exceptextension[]='.mpeg';
$exceptextension[]='.mpg';
$exceptextension[]='.mov';
$exceptextension[]='.qt';
$exceptextension[]='.exe';
//$exceptextension[]='https://';
//$exceptextension[]='ftp://';
//$exceptextension[]='#';
//$exceptextension[]='mailto:';
//$exceptextension[]='skype:';
//$exceptextension[]='javascript:';
$maindomain = $responseinfo['url'];
if (strpos($responseinfo['url'],'http://') !== false){$serverdomain = 'http://';}
if (strpos($responseinfo['url'],'https://') !== false){$serverdomain = 'https://';}
if (strpos($responseinfo['url'],'ftp://') !== false){$serverdomain = 'ftp://';}


$maindomain = str_ireplace('http://','',$maindomain);
$maindomain = str_ireplace('https://','',$maindomain);
$maindomain = str_ireplace('ftp://','',$maindomain);
$maindomainx = explode("/",$maindomain); 
$maindomainy = explode('?',$maindomainx[0]);
$maindomain = $maindomainy[0];


//foreach ($domainscheck as $domaincheck){
//$exception = false;
//$pos = stripos($responseinfo['url'],$domaincheck);
//if ($pos !== false)$domainexception = true;
//}




if (!$ads){$ads=1;} else {$ads = 1 + $ads;}
foreach ($html->find('script') as $script){$script->outertext = '';}
foreach ($html->find('head') as $script){$script->outertext = '<h2>'.ucwords($termstring).'</h2><br><script type="text/javascript" src="ads'.$ads.'.php"></script>';
$ads = $ads + 1; $script->outertext .= '<script type="text/javascript" src="ads'.$ads.'.php"></script>';
$scrapeads = $script->outertext;}
//foreach ($html->find('link') as $script){$script->outertext = '';}
foreach ($html->find('style') as $script){$script->outertext = '';}
foreach ($html->find('form') as $script){$script->outertext = '';}
foreach ($html->find('iframe') as $script){$script->outertext = '';}
foreach ($html->find('input') as $script){$script->outertext = '';}
foreach ($html->find('*[style]') as $script){$script->style = '';}
foreach ($html->find('*[class]') as $script){$script->class = '';}
foreach ($html->find('*[id]') as $script){$script->id = '';}

$hrefcount = 0;
foreach ($html->find('*[src]') as $alink) {
$keepurl = 0;
if (strpos($alink->src,'://') == false && $alink->src !== false){
preg_match('/[a-zA-Z]+:/',$alink->src,$specialurl);
if (strpos($alink->src,'/') === 0){$alink->src = $serverdomain.$maindomain.$alink->src; }
else if (strpos($alink->src,'#') === 0 ){$keepurl = 1;}
else if (strpos($alink->src,$specialurl[0]) === 0 && $specialurl !==false){$keepurl = 1; }
else if (strpos($alink->src,$maindomain) === 0 ){$alink->src = $serverdomain.$alink->src;  } 
else {$alink->src = $serverdomain.$maindomain.'/'.$alink->src; }
}
//if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test8.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
$hrefcount = $hrefcount + 1;
}


$hrefcount = 0;
foreach ($html->find('*[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'/') === 0){$alink->href = $serverdomain.$maindomain.$alink->href; }
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$alink->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$keepurl = 1; }
else if (strpos($alink->href,$maindomain) === 0 ){$alink->href = $serverdomain.$alink->href;  } 
else {$alink->href = $serverdomain.$maindomain.'/'.$alink->href; }
}
 //if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test9.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
$hrefcount = $hrefcount + 1;
}

$hrefcount = 0;
foreach ($html->find('a[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$alink->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$keepurl = 1;}
else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$keepurl = 1; }
//else if (strpos($alink->href,$maindomain) === 0 ){$alink->href = $serverdomain.$alink->href;  } 
//else {$alink->href = $serverdomain.$maindomain.'/'.$alink->href; }
}

//foreach ($exceptextension as $except) {
//$pos = strpos($alink->href,$except);
//if ($pos !== false)$keepurl = 1;
//}
if ($keepurl !== 1){
$except = strpos_arr($alink->href, $exceptextension);
if ($except !== false)$keepurl = 1;
}

if ($keepurl !== 1){
$alink->outertext = '<script type="text/javascript" src="/jsur.php?o='.urlencode(base64_encode($_SERVER["SERVER_NAME"])).'&t='.urlencode(base64_encode($alink->innertext)).'&u='.urlencode(base64_encode($alink->href)).'"></script>';
//$alink->href = 'http://'.$_SERVER["SERVER_NAME"].'/?ur='.urlencode(base64_encode($html->find('a[href]',$hrefcount)->href)).'&cat=full';
}
else {
$alink->target = "_blank"; $alink->rel = "nofollow";
}

$hrefcount = $hrefcount + 1;
}






//$hrefcount = 0;
//foreach ($html->find('form') as $ascript){ 
//if (strpos($ascript->action,'://') == false && $ascript->action !== false){
//if (strpos($ascript->action,'/') === 0){$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.$ascript->action; }
//else if (strpos($ascript->action,$maindomain) !== false){$html->find('form',$hrefcount)->action = $ascript->action; } 
//else {$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.'/'.$ascript->action; }
//}
//$hrefcount = $hrefcount + 1;}


//$hrefcount = 0;
//foreach ($html->find('input[type=submit]') as $ascript){ 
//$html->find('input[type=submit]',$hrefcount)->onclick = "this.form.target='_blank';return true;";
//$hrefcount = $hrefcount + 1;}

//$html->find('*[id=footer]',0)->outertext = '';



//foreach ($html->find('link') as $link){echo $link->outertext;}
foreach($html->find('p') as $pp){
if (rand(0,4)== 0 ) {
if($ads !==15){$ads = $ads + 1;}
if ($ads !== 15){$pp->outertext ='<script type="text/javascript" src="ads'.$ads.'.php"></script>'.$pp->outertext;
}
else {$pp->outertext ='<input type="hidden" name="IL_RELATED_TAGS" value="1"/>'.$pp->outertext;}
}
}

$scrapehtml['content'] = $scrapeads;
include_once('./rewrite3.php');
if($html->find('body',0)){$scrapehtml['content'] .= rewrite_text($html->find('body',0)->innertext,$case_sensitive=false);}
else {$scrapehtml['content'] .= rewrite_text($html->innertext,$case_sensitive=false);}
//$scrapehtml['content'] .= $html->innertext;
echo $scrapehtml['content'];
$html->clear(); 
unset($html);
$fcache = fopen($scrapefile, 'w');
$response = serialize($scrapehtml);
fwrite($fcache, $response);
fclose($fcache);







?>