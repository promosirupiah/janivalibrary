
<?php 
require_once './magpie/rss_fetch.inc';

$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).urlencode($addsearch).'&ie=utf-8&num=20&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>

<?php
$gblogtittles .= '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode(CleanFileNameBan($item['title'])); 
if (file_exists('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt')))
{
$response = file_get_contents('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ 
$gbimgs .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($content->Title))).'"><img alt="'.ucwords(CleanFileNameBan(ubah_space($content->Title))).'" title="'.ucwords(CleanFileNameBan(ubah_space($content->Title))).'" src="'.$content->MediaUrl.'"></a>||';

} ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode(CleanFileNameBan($item['title'])); 
if (file_exists('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt') && (time() - $apicachetime < filemtime('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt')))
{
$response = file_get_contents('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ 
$gbimgs .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($content->titleNoFormatting))).'"><img alt="'.ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))).'" title="'.ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))).'" src="'.$content->unescapedUrl.'"></a>||';

 } ?>
<?php
$gbdescs .= clean_desc($item['description']);

$gblinks .= '<a target=_blank rel="nofollow" href="http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$item['link'] .'">read more</a>';
 } ?>
<div class="postx">
<?php 
echo clean_desc($gbdescs);
echo $gblogtittles;
$gbimg = explode('||',$gbimgs);
$gimg = array_unique($gbimg);
foreach ($gimg as $gbig){
echo $gbig;
}
?>
</div>
