<div class="postx">
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/video?v=1.0&rsz=8&key='.$google_video_api.'&q=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($content->url); ?>" target=_blank rel="nofollow"><img src="<?php echo $content->tbUrl ?>" alt="<?php echo $content->title; ?>" title="<?php echo $content->title; ?>"></a>
<?php } ?>
</div>


