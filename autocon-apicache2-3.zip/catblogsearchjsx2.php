
<?php 

if (!$ads){$ads=1;}
echo '<div class="postx">';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>
<script type="text/javascript" src="/jsimg.php?i=<?php echo urlencode(base64_encode($content->MediaUrl)); ?>&t=<?php echo urlencode(base64_encode($content->Title)); ?>&o=<?php echo urlencode(base64_encode($content->Url)); ?>"></script>
<?php } 

$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<script type="text/javascript" src="/jsimg.php?i=<?php echo urlencode(base64_encode($content->url)); ?>&t=<?php echo urlencode(base64_encode($content->titleNoFormatting)); ?>&o=<?php echo urlencode(base64_encode($content->originalContextUrl)); ?>"></script>
<?php } ?>
<script type="text/javascript" src="<?php echo 'ads'.$ads.'.php';$ads = $ads+1;?>"></script>
<?php
echo '</div>';

include_once('./rewrite3.php');
require_once './magpie/rss_fetch.inc';
$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).urlencode($addsearch).'&ie=utf-8&num=3&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>
<div class="postx">
<?php
echo '<h2>'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode(ubah_space(CleanFileNameBan($item['title']))); 
$response = pete_curl_get($request, array());

$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ if ($termstring !== ubah_space(CleanFileNameBan($item['title']))){ ?>
<script type="text/javascript" src="/jsimg.php?i=<?php echo urlencode(base64_encode($content->MediaUrl)); ?>&t=<?php echo urlencode(base64_encode($content->Title)); ?>&o=<?php echo urlencode(base64_encode($content->Url)); ?>"></script>

<?php }} ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode(ubah_space(CleanFileNameBan($item['title']))); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ if ($termstring !== ubah_space(CleanFileNameBan($item['title']))){ ?>
<script type="text/javascript" src="/jsimg.php?i=<?php echo urlencode(base64_encode($content->url)); ?>&t=<?php echo urlencode(base64_encode($content->titleNoFormatting)); ?>&o=<?php echo urlencode(base64_encode($content->originalContextUrl)); ?>"></script>

<?php }} ?>
<?php
//echo '<br style="clear:both"><p>'.clean_desc($item['description']).'</p><br style="clear:both">';
?>
<br style="clear:both">
<script type="text/javascript" src="<?php echo 'ads'.$ads.'.php';$ads = $ads+1;?>"></script>
<br style="clear:both">
<p>
<?php 
if ($termstring !== ubah_space(CleanFileNameBan($item['title']))){
?>
<script type="text/javascript" src="/jslink.php?o=<?php echo urlencode(base64_encode($_SERVER["SERVER_NAME"]));?>&t=<?php echo urlencode(base64_encode(CleanFileNameBan($item['title'])));?>"></script>
<?php
//echo '<a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'&cat=sch" target="_blank">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a> ';
}
echo rewrite_text(clean_desc($item['description']),$case_sensitive=false);?></p>
<br style="clear:both">

</div>
<?php } ?>


