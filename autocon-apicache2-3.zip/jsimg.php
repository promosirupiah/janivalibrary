<?php 
function CleanFileNameBan($result){
$bannedkey = array("<b>","</b>","...","..","crack","keygen","rapidshare","megaupload","http",".com",".net",".org",".jpg","blogspot.com","torrent","youtube","www","yahoo","index","the free encyclopedia","alcohol","cigarette","cigarettes","gamble","casino","sex","porn"); //remove those words on title result, lowercase only
$result = strtolower($result);
$result = str_ireplace($bannedkey, '',$result);
$result = str_ireplace(array('  ','   ','    '), ' ',$result);
$result = trim($result);
return $result;
}
function ubah_space($result) { //change all special character to " "
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', ' ', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
	$result = preg_replace('|-+|', ' ', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
	$result = str_replace(array('___','__','_'),' ',$result);
	$result = str_replace(array('    ','   ','  '), ' ', $result);
	$result = trim($result, ' ');
	return $result;
}
// $pos = strpos($_SERVER['HTTP_REFERER'],'cat=sch');if ($pos === false) {
?>
document.write('<a rel="popupgroup" href="<?php echo base64_decode($_REQUEST['i']); ?>" title="<?php echo htmlentities('<a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(base64_decode($_REQUEST['t'])).'&cat=full">'.base64_decode($_REQUEST['t']).'</a><br><a href="http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode(base64_decode($_REQUEST['o'])).'" rel="nofollow" target="_blank">read source</a>');?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space(base64_decode($_REQUEST['t']))));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space(base64_decode($_REQUEST['t']))));?>" src="<?php echo base64_decode($_REQUEST['i']); ?>"></a>');
<?php 
// } ?>