<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/web?v=1.0&rsz=4&key='.$google_web_api.'&q=' .urlencode($termstring).urlencode($addsearch); 
if (file_exists('apicache/g_web_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/g_web_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/g_web_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_web_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $value) 
{ 

$gtittles .= '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($value->titleNoFormatting)).'">'.ucwords(CleanFileNameBan(ubah_space($value->titleNoFormatting))).'</a></h2>';
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode($value->titleNoFormatting); 
if (file_exists('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt') && (time() - $apicachetime < filemtime('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt')))
{
$response = file_get_contents('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ 
$gimgs .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($content->titleNoFormatting)).'"><img alt="'.ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))) .'" title="'.ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))) .'" src="'.$content->unescapedUrl .'"></a>||';

 } 

$gdescs .= $value->content; 
$glinks .= '<a target=_blank rel="nofollow" href="http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$value->url .'">read more</a>';

} ?>
<div class ="post">
<?php
echo clean_desc($gdescs).'<br style="clear:both;">';
echo $gtittles;
$gimage = explode('||',$gimgs);
$gimage = array_unique($gimage);
foreach ($gimage as $gimg){
echo $gimg;
}
?>
</div>


