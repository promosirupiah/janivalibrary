<?php








//domain check for known unhandle website
//$domainscheck[]='youtube.com';
//$domainscheck[]='google.com';
//$domainscheck[]='facebook.com';
//$domainscheck[]='twitter.com';
//$domainscheck[]='launchpad.net';


$exceptextension[]='.rpm';
$exceptextension[]='.pdf';
$exceptextension[]='.sig';
$exceptextension[]='.spl';
$exceptextension[]='.class';
$exceptextension[]='.torrent';
$exceptextension[]='.dvi';
$exceptextension[]='.gz';
$exceptextension[]='.pac';
$exceptextension[]='.swf';
$exceptextension[]='.tar.gz';
$exceptextension[]='.tgz';
$exceptextension[]='.tar';
$exceptextension[]='.zip';
$exceptextension[]='.mp3';
$exceptextension[]='.m3u';
$exceptextension[]='.wma';
$exceptextension[]='.wax';
$exceptextension[]='.ogg';
$exceptextension[]='.wav';
$exceptextension[]='.gif';
$exceptextension[]='.jar';
$exceptextension[]='.jpg';
$exceptextension[]='.jpeg';
$exceptextension[]='.png';
$exceptextension[]='.xbm';
$exceptextension[]='.xpm';
$exceptextension[]='.xwd';
$exceptextension[]='.css';
$exceptextension[]='.js';
$exceptextension[]='.asc';
$exceptextension[]='.cpp';
$exceptextension[]='.log';
$exceptextension[]='.conf';
$exceptextension[]='.text';
$exceptextension[]='.txt';
$exceptextension[]='.dtd';
$exceptextension[]='.xml';
$exceptextension[]='.mpeg';
$exceptextension[]='.mpg';
$exceptextension[]='.mov';
$exceptextension[]='.qt';
$exceptextension[]='.exe';
//$exceptextension[]='https://';
//$exceptextension[]='ftp://';
//$exceptextension[]='#';
//$exceptextension[]='mailto:';
//$exceptextension[]='skype:';
//$exceptextension[]='javascript:';
$maindomain = $responseinfo['url'];
if (strpos($responseinfo['url'],'http://') !== false){$serverdomain = 'http://';}
if (strpos($responseinfo['url'],'https://') !== false){$serverdomain = 'https://';}
if (strpos($responseinfo['url'],'ftp://') !== false){$serverdomain = 'ftp://';}


$maindomain = str_ireplace('http://','',$maindomain);
$maindomain = str_ireplace('https://','',$maindomain);
$maindomain = str_ireplace('ftp://','',$maindomain);
$maindomainx = explode("/",$maindomain); 
$maindomainy = explode('?',$maindomainx[0]);
$maindomain = $maindomainy[0];


//foreach ($domainscheck as $domaincheck){
//$exception = false;
//$pos = stripos($responseinfo['url'],$domaincheck);
//if ($pos !== false)$domainexception = true;
//}





//foreach ($html->find('script') as $script){$script->outertext = '';}
//foreach ($html->find('link') as $script){$script->outertext = '';}
//foreach ($html->find('style') as $script){$script->outertext = '';}

//$hrefcount = 0;
//foreach ($html->find('*[href]') as $alink) {
//$keepurl = 0;
//if (strpos($alink->href,'://') == false && $alink->href !== false){
//preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
//if (strpos($alink->href,'/') === 0){$html->find('*[href]',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
//else if (strpos($alink->href,'#') === 0 ){$html->find('*[href]',$hrefcount)->href = $alink->href; $keepurl = 1;}
//else if (strpos($alink->href,$specialurl[0]) === 0 && $specialurl !==false){$html->find('*[href]',$hrefcount)->href = $alink->href; $keepurl = 1; }
//else if (strpos($alink->href,$maindomain) === 0 ){$html->find('*[href]',$hrefcount)->href = $serverdomain.$alink->href;  } 
//else {$html->find('*[href]',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
//}
// //if ($keepurl !== 1){$html->find('*[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test9.php?u='.urlencode($html->find('*[href]',$hrefcount)->href);}
//$hrefcount = $hrefcount + 1;
//}

$hrefcount = 0;
foreach ($html->find('a[href]') as $alink) {
$keepurl = 0;
if (strpos($alink->href,'://') == false && $alink->href !== false){
preg_match('/[a-zA-Z]+:/',$alink->href,$specialurl);
if (strpos($alink->href,'/') === 0){$html->find('a[href]',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,'#') === 0 ){$html->find('a[href]',$hrefcount)->href = $alink->href; $keepurl = 1;}
else if (strpos($alink->href,$maindomain) === 0 ){$html->find('a[href]',$hrefcount)->href = $serverdomain.$alink->href;  } 
else {$html->find('a[href]',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}
foreach ($exceptextension as $except) {
$pos = strpos($alink->href,$except);
if ($pos !== false)$keepurl = 1;
}
if ($keepurl !== 1){
$html->find('a[href]',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/?ur='.urlencode(base64_encode($html->find('a[href]',$hrefcount)->href)).'&cat=full';
}
else {
$html->find('a[href]',$hrefcount)->target = "_blank"; $html->find('a[href]',$hrefcount)->rel = "nofollow";
}
$scrapehtml['content'] .='<li><a href="'.$html->find('a[href]',$hrefcount)->href.'">'.$html->find('a[href]',$hrefcount)->plaintext.'</a> | </li>';
$hrefcount = $hrefcount + 1;
}
$scrapehtml['content'] .='<br style="clear:both">';

$hrefcount = 0;
foreach ($html->find('img[src]') as $alink) {
$keepurl = 0;
if (strpos($alink->src,'://') == false && $alink->src !== false){
if (strpos($alink->src,'/') === 0){$html->find('img[src]',$hrefcount)->src = $serverdomain.$maindomain.$alink->src; }
else if (strpos($alink->src,$maindomain) === 0 ){$html->find('img[src]',$hrefcount)->src = $serverdomain.$alink->src;  } 
else {$html->find('img[src]',$hrefcount)->src = $serverdomain.$maindomain.'/'.$alink->src; }
}$scrapehtml['content'] .='<a href="'.$html->find('img[src]',$hrefcount)->src.'" rel="popupgroup"><img src="'.$html->find('img[src]',$hrefcount)->src.'"></a>';
$hrefcount = $hrefcount + 1;
}
$scrapehtml['content'] .='<br style="clear:both">';
$scrapehtml['content'] .=$html->find('body',0)->plaintext;
//$hrefcount = 0;
//foreach ($html->find('form') as $ascript){ 
//if (strpos($ascript->action,'://') == false && $ascript->action !== false){
//if (strpos($ascript->action,'/') === 0){$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.$ascript->action; }
//else if (strpos($ascript->action,$maindomain) !== false){$html->find('form',$hrefcount)->action = $ascript->action; } 
//else {$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.'/'.$ascript->action; }
//}
//$hrefcount = $hrefcount + 1;}

//$hrefcount = 0;
//foreach ($html->find('form') as $ascript){
// $html->find('form',$hrefcount)->outertext = '';
//$hrefcount = $hrefcount + 1;}
//$hrefcount = 0;
//foreach ($html->find('iframe') as $ascript){
// $html->find('iframe',$hrefcount)->outertext = '';
//$hrefcount = $hrefcount + 1;}

//$hrefcount = 0;
//foreach ($html->find('input[type=submit]') as $ascript){ 
//$html->find('input[type=submit]',$hrefcount)->onclick = "this.form.target='_blank';return true;";
//$hrefcount = $hrefcount + 1;}

//$html->find('*[id=footer]',0)->outertext = '';



//foreach ($html->find('link') as $link){echo $link->outertext;}


//$scrapehtml['content'] = $html->find('head',0)->innertext;
//$scrapehtml['content'] .= $html->find('body',0)->innertext; 
echo $scrapehtml['content'];
$html->clear(); 
unset($html);
$fcache = fopen($scrapefile, 'w');
$response = serialize($scrapehtml);
fwrite($fcache, $response);
fclose($fcache);







?>