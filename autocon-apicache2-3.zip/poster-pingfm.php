<?php
if(!function_exists('ubah_tanda')) {
function ubah_tanda($result) { //fungsi ubah spasi jadi plus pada permalink title
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
		$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
}
}
$pinglogins[] = array ('email'=>'xxx','password'=>'xxx');
//$pinglogins[] = array ('email'=>'xxx','password'=>'xxx');

foreach ($pinglogins as $pinglogin){
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1A543a Safari/419.3 ");
curl_setopt($ch, CURLOPT_COOKIEJAR, ubah_tanda($pinglogin['email']).'_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, ubah_tanda($pinglogin['email']).'_cookies.txt');



curl_setopt($ch, CURLOPT_URL, 'http://ping.fm/m/');
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
//echo $responseinfo['url'].'<br>';
if ($responseinfo['url'] !== 'http://ping.fm/m/')
{
//echo $response.'<br style="clear:both">';

//$html = str_get_html($response);
//$authz = $html->find('input[name="authenticity_token"]',0)->value;
//$pinglogin['authenticity_token'] = $html->find('input[name="authenticity_token"]',0)->value;
curl_setopt($ch, CURLOPT_POSTFIELDS, $pinglogin);
curl_setopt($ch, CURLOPT_URL, 'http://ping.fm/m/login/');
$response = curl_exec($ch);
//$responseinfo = curl_getinfo( $ch );
//echo $response.'<br style="clear:both">';
}
//$html = str_get_html($response);
//$authz = $html->find('input[name="authenticity_token"]',0)->value;
foreach ($postings as $posting) {

$pingposter = array("service" => '', "message"=>$posting['url'].' '.$posting['title']);
//$pingposter = array("service" => '', "message"=> 'love');
curl_setopt($ch, CURLOPT_POSTFIELDS, $pingposter);
curl_setopt($ch, CURLOPT_URL, 'http://ping.fm/m/');
$response = curl_exec($ch);
//echo $response.'<br style="clear:both">';
}
//$html->clear(); 
//unset($html);
}
?>