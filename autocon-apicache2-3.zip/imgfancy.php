<div class="postx">
<?php 
if (!$ads){$ads=1;}

$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>
<a rel="popupgroup" title="<?php echo htmlentities('<a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode($content->Title).'&cat=full">'.$content->Title.'</a><br><a href="http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($content->Url).'" rel="nofollow" target="_blank">read source</a>');?>" href="<?php echo $content->MediaUrl; ?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title)));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title)));?>" src="<?php echo $content->MediaUrl; ?>"></a>
<?php } 

$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a rel="popupgroup" href="<?php echo $content->url; ?>" title="<?php echo htmlentities('<a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode($content->titleNoFormatting).'&cat=full">'.$content->titleNoFormatting.'</a><br><a href="http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($content->originalContextUrl).'" rel="nofollow" target="_blank">read source</a>');?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting)));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting)));?>" src="<?php echo $content->unescapedUrl; ?>"></a>
<?php } ?>
<script type="text/javascript" src="<?php echo 'ads'.$ads.'.php';$ads = $ads+1;?>"></script>

</div>