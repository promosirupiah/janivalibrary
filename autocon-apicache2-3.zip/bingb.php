<?php
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_web_api.'&sources=web&Web.Count=6&query=' .urlencode($termstring).urlencode($addsearch); 
if (file_exists('apicache/bing_web_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_web_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/bing_web_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_web_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Web->Results as $value) 
{ ?>
<div class ="post">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($value->Title))).'">'.ucwords(CleanFileNameBan(ubah_space($value->Title))).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=6&query=' .urlencode($value->Title); 
if (file_exists('apicache/bing_img_'.ubah_tanda($value->Title).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_img_'.ubah_tanda($value->Title).'.txt')))
{
$response = file_get_contents('apicache/bing_img_'.ubah_tanda($value->Title).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_img_'.ubah_tanda($value->Title).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>

<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($content->Title)));?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title))) ?>" src="<?php echo $content->MediaUrl; ?>"></a>


<?php } ?>
<br style="clear:both">
<?php echo clean_desc($value->Description); ?>
<br style="clear:both">
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($value->Url) ?>">read more</a>
</div> <?php //end div post class ?>
<?php } ?>