<div class="postx">
<?php
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=video&Video.Count=1&query=' .urlencode($termstring); 
if (file_exists('apicache/b_vid_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/b_vid_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/b_vid_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/b_vid_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Video->Results as $content) 
{ ?>
<a href="<?php echo $content->PlayUrl; ?>" target=_blank rel="nofollow"><img src="<?php echo $content->StaticThumbnail->Url; ?>" alt="<?php echo $content->Title; ?>" title="<?php echo $content->Title; ?>" width="<?php echo $content->Width;?>" height="<?php echo $content->Height;?>"></a>
<?php } ?>
</div>

