<?php 
function SureRemoveDir($dir, $DeleteMe) {
    if(!$dh = @opendir($dir)) return;
    while (false !== ($obj = readdir($dh))) {
        if($obj=='.' || $obj=='..') continue;
        if (!@unlink($dir.'/'.$obj)) SureRemoveDir($dir.'/'.$obj, true);
    }

    closedir($dh);
    if ($DeleteMe){
        @rmdir($dir);
    }
}
if ($_SERVER["REQUEST_URI"] =='/index.php?clearapi'){SureRemoveDir('apicache',false);echo 'apicache clear';exit;} //*use http://yourdomain.com/index.php?clearapi to clear api cache
if ($_SERVER["REQUEST_URI"] =='/index.php?clearcache'){SureRemoveDir('cache',false);echo 'cache clear';exit;} //*use http://yourdomain.com/index.php?clearcache to clear cache file
if ($_SERVER["REQUEST_URI"] =='/index.php?clearscrape'){SureRemoveDir('scrapefiles',false);echo 'cache clear';exit;} //*use http://yourdomain.com/index.php?clearcache to clear cache file

if (empty($_REQUEST['cat']) && $_SERVER["REQUEST_URI"] !=='/') {header( 'Location: http://'.$_SERVER["SERVER_NAME"] );}

$main_title = 'Hot Picture'; //* Main Title and auto generate front page from blogsearch

$bingapis[] = '445D718A5BDF3CF151395BBEE50233167AA31EF2';
$bingapis[] = '445D718A5BDF3CF151395BBEE50233160FA0E9B9';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316210A4558';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316AA84FFC6';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316E9B013F2';
$bingapis[] = '445D718A5BDF3CF151395BBEE50233168B32FF5B';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316F0400F8C';


$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxRdQ_EONEqjNwrhu5GY3F6OI5M3TBQgZd9M93SliOUv8O-65hCxWxeD-w';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxR_NuWjYao3q0rhiKiAf4ILzqzzmRRONBNXDGKLIpECfTislZQwxqGm7g';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxShLuwtOPXh9xBK8HHHfeLk-yQrBhQRN-MHh78_ZNGan3WPyJq9oGmmDg';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxSlckdLM2mKx40qPfeB9aCAwtlVwBQw1iShhQwfUCtJ8-Ko26G3ZIKRPA';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxRJbkTihGh0jt8kBFTJhxS0AUsLRBSZDypHx3kXUOwI00vmLAO9s11imw';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxQRk-8loAPkAWWAgnHpsFmVod1BNhRDsam95y6h9S9s7CqWNnHI4Bqyvw';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxRmvpUMwSjGuKImj0uaGqbs5GXnohQk5uxgDcFX9CpWBHatw71QmtEU9w';

$bing_web_api = $bingapis[rand(0,count($bingapis)-1)]; //* insert your bing api
$bing_image_api = $bingapis[rand(0,count($bingapis)-1)]; //* better insert different api for bing image 
$google_web_api = $gapis[rand(0,count($gapis)-1)]; //*insert your google api
$google_image_api = $gapis[rand(0,count($gapis)-1)]; //*better insert different api for google image 
$google_video_api = $gapis[rand(0,count($gapis)-1)]; //*better insert different api for google image 

$categories = array('','celebrity','movies','car','politic','news','sport','fun'); //* lowercase, dynamic auto generate category from blogsearch
$addsearch = ' '.'picture -crack -keygen -torrent -alcohol -cigarette -cigarettes -gamble -casino -sex -porn -rapidshare -megaupload'; //*keyword filter search, can use + or -
$apicachetime = 7 * 24 * 60 * 60;// cache time for api in seconds
?>


<?php
function ubah_tanda($result) { //change all special character to "-"
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
	$result = str_replace(array('___','__','_'),'-',$result);
	$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
}
function ubah_space($result) { //change all special character to " "
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', ' ', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
	$result = preg_replace('|-+|', ' ', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
	$result = str_replace(array('___','__','_'),' ',$result);
	$result = str_replace(array('    ','   ','  '), ' ', $result);
	$result = trim($result, ' ');
	return $result;
}
function CleanFileNameBan($result){
$bannedkey = array("<b>","</b>","...","..","crack","keygen","rapidshare","megaupload","http",".com",".net",".org",".jpg","blogspot.com","torrent","youtube","www","yahoo","index","the free encyclopedia","alcohol","cigarette","cigarettes","gamble","casino","sex","porn"); //remove those words on title result, lowercase only
$result = strtolower($result);
$result = str_ireplace($bannedkey, '',$result);
$result = str_ireplace(array('  ','   ','    '), ' ',$result);
$result = trim($result);
return $result;
}
function clean_desc($result){
$bannedkey = array("<b>","</b>");
$result = str_replace($bannedkey,'',$result);
$result = str_replace(array('Comments Off','[',']','|',' ...','...','. .','..','<a href','href="http://'),array('','','','','.','. ','. ','.','<a rel="nofollow" target=_blank href',('href="http://'.$_SERVER["SERVER_NAME"].'/goto.php?http://')),$result);
return $result;
}
?>
<?php

if (!empty($_REQUEST['u']) || !empty($_REQUEST['ur'])){
if ($_REQUEST['u']) {$scrape = $_REQUEST['u'];}
else if ($_REQUEST['ur']){$scrape = base64_decode($_REQUEST['ur']);}
$scrapefile = 'scrapefiles/'.ubah_tanda(substr(base64_encode($scrape),0,240)).'.txt';

if (file_exists($scrapefile)) {$scrapehtml = unserialize(file_get_contents($scrapefile));
$termstring = ubah_space(CleanFileNameBan($scrapehtml['title']));}
else {
include_once('./simple_html_dom.php');
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
//curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729)");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $scrape);
$response = curl_exec($ch);
$responseinfo = curl_getinfo( $ch );
$html = str_get_html($response);
$scrapehtml['title']=$html->find('head title',0)->innertext;
$termstring = ubah_space(CleanFileNameBan($scrapehtml['title']));}
}
else if (!empty($_REQUEST['q'])) {
$termstring = ubah_space(CleanFileNameBan(base64_decode($_REQUEST['q']))); }
else if (!empty($_REQUEST['s'])) {
$termstring = ubah_space(CleanFileNameBan($_REQUEST['s'])); }
else {
$termstring = ubah_space(CleanFileNameBan(str_replace(array('?utm_source=twitterfeed&utm_medium=statusnet','?utm_source=twitterfeed&utm_medium=twitter'),'',$_SERVER["REQUEST_URI"])));
}
$displaytitle = ucwords($termstring);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/feed2.php?hl=en&as_drrb=q&as_qdr=h&ie=utf-8&num=10&output=rss&q='.urlencode($main_title)?>" />
<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/stylex.css'; ?>" type="text/css" media="screen" />
<?php if (($_SERVER["REQUEST_URI"]) !='/'){ //rss generated for title from blogsearch.google.com ?>
<link rel="alternate" type="application/rss+xml" title="<?php echo $termstring ?>" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/feed2.php?hl=en&q='.urlencode($termstring).'&ie=utf-8&num=20&output=rss' ?>" />
<?php } ?>
<title><?php if (($_SERVER["REQUEST_URI"]) !='/') {echo $displaytitle .'|';}; echo $main_title.' - '.$_SERVER["SERVER_NAME"]; ?></title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
	<script>
		!window.jQuery && document.write('<script src="jquery-1.4.3.min.js"><\/script>');
	</script>
	<script type="text/javascript" src="./fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
	<script type="text/javascript" src="./fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	<link rel="stylesheet" type="text/css" href="./fancybox/jquery.fancybox-1.3.4.css" media="screen" />

	<script type="text/javascript">
		$(document).ready(function() {

			$("a[rel=popupgroup]").fancybox({
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'titlePosition' 	: 'over',
				'titleFormat'		: function(title, currentArray, currentIndex, currentOpts) {
					return '<span id="fancybox-title-over">' + (title.length ? ' &nbsp; ' + title : '') + '</span>';
				}
			});


		});
	</script>




</head>
<body>

<div id="header">
<h1 style="clear:both"><a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"];?>"><?php echo $main_title ?></a></h1>
</div>

<script type="text/javascript">
    var infolink_pid = 168169;
    var infolink_wsid = 0;
    var infolink_link_color = '0000FF';
    var infolink_title_color = '0000FF';
    var infolink_ad_link_color = '0000FF';
</script>
<script type="text/javascript" src="http://resources.infolinks.com/js/infolinks_main.js"></script>
<div id="contentx">
<?php
//start check and read caching
//for front page
if ($_SERVER["REQUEST_URI"] =='/') {
$cachefile = 'cache/index.html';
$cachetime = 30 * 60; // cache time minutes * seconds
if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))) {
include($cachefile);
include ('./sidebar.php');
echo '</body></html>';

  	exit;      }
}

//*for categories

else if (in_array($termstring, $categories)) {
$cachefile = 'cache/'.ubah_tanda($termstring).'.html';
$cachetime = 60 * 60; // cache time minutes * seconds
if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))) {
include($cachefile); 
include ('./sidebar.php');
echo '</body></html>';
	exit;
}
}

//*special case
else if (!empty($_REQUEST['u']) || !empty($_REQUEST['ur'])){
$cachefile = 'cache/'.ubah_tanda($termstring).'.html';
if (file_exists($cachefile)) {
include($cachefile); }
else {
ob_start(); 
include ('./content.php');
$fp = fopen($cachefile, 'w');
fwrite($fp, ob_get_contents());
fclose($fp);
ob_end_flush();}
include ('./ads.php');
if (file_exists($scrapefile)) {echo '<div class="fl">'.$scrapehtml['content'].'</div>';}
else {echo '<div class="fl">';include('./scraper.php');echo '</div>';}
include ('./sidebar.php');
echo '</body></html>';
	exit;
$caching = 'no';}

//*for all uri
else {
$cachefile = 'cache/'.ubah_tanda($termstring).'.html';
if (file_exists($cachefile)) {
include($cachefile); 
include ('./sidebar.php');
echo '</body></html>';
	exit;
}
}


//end check and read caching
if ($caching !=='no'){
ob_start(); 
//*code start for caching
include ('./content.php');
//*code end
$fp = fopen($cachefile, 'w');
fwrite($fp, ob_get_contents());
fclose($fp);
ob_end_flush();
include ('./sidebar.php');
echo '</body></html>';
}
?>