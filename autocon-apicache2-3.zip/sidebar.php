</div> 
<div id="sidebarx">
<?php
if (empty($_REQUEST['u']) && empty($_REQUEST['ur'])){?>
<script type="text/javascript">
google_ad_client = "pub-9997800556090799";
google_ad_width = 160;
google_ad_height =600;
google_ad_type = "text_image";
</script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
<?php } ?>
<form name="myform" method="get" action="http://<?php echo $_SERVER["SERVER_NAME"] ?>/">
Search: <input type="text" name="s"><input name="cat" value="sch" type="hidden"><br>
<input type="submit" value="Submit">
</form> 
<?php foreach ($categories as $category) { ?>
<li><a href="http://<?php echo $_SERVER["SERVER_NAME"] ?>/?s=<?php echo htmlentities(ubah_tanda($category)) ?>&cat=cat"><?php echo ucwords($category) ?></a></li>
<?php } ?>
</div>
<div id="footerx">
<a href="http://<?php echo $_SERVER["SERVER_NAME"] ?>/privacy-policy.html">Privacy Policy</a><br>
copyright <?php echo $_SERVER["SERVER_NAME"] ?>
</div>


