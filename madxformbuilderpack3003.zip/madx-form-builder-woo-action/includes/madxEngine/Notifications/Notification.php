<?php


namespace madx_FB_Woo\madxEngine\Notifications;


use madx_FB_Woo\ActionTrait;
use madxWooCore\madxEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use ActionTrait;

}