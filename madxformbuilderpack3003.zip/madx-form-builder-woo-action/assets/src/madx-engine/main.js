import Notification from "./Notification";

const { addFilter } = wp.hooks;

addFilter( 'madx.engine.register.notifications', 'madx-engine', notifications => {
	notifications.push( Notification );

	return notifications;
} )