import { Actions } from 'jfb-editor';

const { __ } = wp.i18n;

const getLocalizedFullPack = new Actions.EditorData( 'redirect_to_checkout' ).setLabels( {
	product_manual: __( 'Input product ID', 'madx-form-builder-woo-action' ),
	product_id_from: __( 'Get product ID from', 'madx-form-builder-woo-action' ),
	product_id_field: __( 'Product ID field', 'madx-form-builder-woo-action' ),
	wc_price: __( 'WooCommerce Price field', 'madx-form-builder-woo-action' ),
	wc_order_details: __( 'WooCommerce order details', 'madx-form-builder-woo-action' ),
	wc_fields_map: __( 'WooCommerce checkout fields map', 'madx-form-builder' ),
	wc_details__type: __( 'Type', 'madx-form-builder-woo-action' ),
	wc_details__label: __( 'Label', 'madx-form-builder-woo-action' ),
	wc_details__date_format: __( 'Date format', 'madx-form-builder-woo-action' ),
	wc_details__field: __( 'Select form field', 'madx-form-builder-woo-action' ),
	wc_details__link_label: __( 'Link text', 'madx-form-builder-woo-action' ),
	wc_heading_order_details: __( 'Heading for Order Details', 'madx-form-builder-woo-action' ),
} ).exportAll();

export { getLocalizedFullPack };