<?php


namespace madx_Form_Builder\Actions\Methods\Form_Record\Query_Views;


use madx_Form_Builder\Db_Queries\Views\View_Base;
use madx_Form_Builder\Actions\Methods\Form_Record\Models;
use madx_Form_Builder\Db_Queries\Views\View_Base_Count_Trait;

class Record_View_Count extends Record_View {

	use View_Base_Count_Trait;

}