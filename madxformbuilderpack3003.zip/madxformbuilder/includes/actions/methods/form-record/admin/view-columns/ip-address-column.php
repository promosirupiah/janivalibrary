<?php


namespace madx_Form_Builder\Actions\Methods\Form_Record\Admin\View_Columns;

use madx_Form_Builder\Admin\Table_Views\Column_Advanced_Base;
use madx_Form_Builder\Admin\Table_Views\Column_Base;

class Ip_Address_Column extends Column_Advanced_Base {

	protected $column = 'ip_address';

	public function get_label(): string {
		return __( 'Ip Address', 'madx-form-builder' );
	}

	public function get_value( array $record = array() ) {
		$value = parent::get_value( $record );

		if ( $value ) {
			return $value;
		}

		return Utils::get_empty_status();
	}

	public function get_type( array $record = array() ): string {
		$value = parent::get_value( $record );

		return $value ? $this->type : Column_Base::STATUS;
	}
}
