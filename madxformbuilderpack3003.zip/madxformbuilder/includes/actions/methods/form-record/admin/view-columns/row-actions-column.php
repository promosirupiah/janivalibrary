<?php


namespace madx_Form_Builder\Actions\Methods\Form_Record\Admin\View_Columns;


use madx_Form_Builder\Admin\Table_Views\Columns\Base_Row_Actions_Column;

class Row_Actions_Column extends Base_Row_Actions_Column {

	use Actions_List_For_Column;

}