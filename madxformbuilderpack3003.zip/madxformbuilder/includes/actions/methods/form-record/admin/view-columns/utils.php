<?php


namespace madx_Form_Builder\Actions\Methods\Form_Record\Admin\View_Columns;


use madx_Form_Builder\Admin\Table_Views\Column_Base;

class Utils {

	public static function get_empty_status(): array {
		return array(
			'type'          => Column_Base::STATUS_WARNING,
			'help'          => __( 'This data is not stored now. You can enable data storing in the Action\'s settings', 'madx-form-builder' ),
			'text'          => __( 'Is not stored', 'madx-form-builder' ),
			'help_position' => 'top-left',
		);
	}
}