<?php


namespace madx_Form_Builder\Actions\Methods\Exceptions;


use madx_Form_Builder\Exceptions\Handler_Exception;

class Modifier_Exclude_Property extends Handler_Exception {

	public function save_exception(): bool {
		return false;
	}

}