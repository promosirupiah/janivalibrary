<?php


namespace madx_Form_Builder\Actions\Events;


abstract class  Base_Action_Event extends Base_Event {


}