<?php


namespace madx_Form_Builder\Actions\Events\On_Dynamic_State;


use madx_Form_Builder\Actions\Events\Base_Executor;

class On_Dynamic_State_Executor extends Base_Executor {

	public function is_supported(): bool {
		return true;
	}
}