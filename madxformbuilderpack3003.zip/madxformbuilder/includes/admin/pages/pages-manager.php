<?php


namespace madx_Form_Builder\Admin\Pages;

use madx_Form_Builder\Admin\Admin_Page_Interface;
use madx_Form_Builder\Admin\Exceptions\Not_Found_Page_Exception;
use madx_Form_Builder\Admin\Single_Pages\Base_Single_Page;
use madx_Form_Builder\Classes\Instance_Trait;
use madx_Form_Builder\Exceptions\Repository_Exception;
use madx_Form_Builder\Plugin;

/**
 * @method static Pages_Manager instance()
 *
 * Class Pages_Manager
 * @package madx_Form_Builder\Admin\Pages
 */
class Pages_Manager {

	use Instance_Trait;

	/** @var Base_Page */
	private $current_page;

	/** @var Stable_Pages_Manager */
	private $stable_manager;
	private $single_manager;

	const STYLE_ADMIN         = 'madx-form-builder-admin-style';
	const STYLE_DASHICONS     = 'dashicons';
	const SCRIPT_VUEX         = 'madx-form-builder-admin-vuex';
	const SCRIPT_PACKAGE      = 'madx-form-builder-admin-package';
	const SCRIPT_VUEX_PACKAGE = 'madx-form-builder-admin-vuex-package';

	protected function __construct() {
		/** Register pages */
		$this->stable()->rep_install();
		$this->single()->rep_install();
	}

	public function set_up() {
		add_action( 'init', array( $this, 'set_current_page' ), 100 );
	}

	public function stable(): Stable_Pages_Manager {
		if ( ! $this->stable_manager ) {
			$this->stable_manager = new Stable_Pages_Manager();
		}

		return $this->stable_manager;
	}

	public function single(): Single_Pages_Manager {
		if ( ! $this->single_manager ) {
			$this->single_manager = new Single_Pages_Manager();
		}

		return $this->single_manager;
	}

	public function get_stable_url( string $slug, array $query_args = array() ): string {
		try {
			$page = $this->get_stable( $slug );
		} catch ( Repository_Exception $exception ) {
			return '';
		}

		return $page->get_url( $query_args );
	}

	/**
	 * @param string $slug
	 *
	 * @return Base_Page
	 * @throws Repository_Exception
	 */
	public function get_stable( string $slug ): Base_Page {
		return $this->stable()->rep_get_item( $slug );
	}

	/**
	 * @param string $slug
	 *
	 * @return Base_Single_Page
	 * @throws Repository_Exception
	 */
	public function get_single( string $slug ): Base_Single_Page {
		return $this->single()->rep_get_item( $slug );
	}

	/**
	 * @return Base_Page|Base_Single_Page
	 * @throws Not_Found_Page_Exception
	 */
	public function get_current(): Admin_Page_Interface {
		if ( is_a( $this->current_page, Admin_Page_Interface::class ) ) {
			return $this->current_page;
		}

		throw new Not_Found_Page_Exception( 'Current page is not defined' );
	}

	/**
	 * Set current admin page
	 */
	public function set_current_page() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$post_type = sanitize_key( $_GET['post_type'] ?? '' );

		if ( madx_form_builder()->post_type->slug() !== $post_type ) {
			return;
		}

		try {
			$slug = sanitize_key( $_GET['page'] ?? '' );
			$page = $this->get_stable( $slug );
		} catch ( Repository_Exception $exception ) {
			return;
		}

		try {
			$this->current_page = $this->get_single( $slug );
			$this->current_page->make();

		} catch ( Not_Found_Page_Exception $exception ) {
			$this->current_page = $page;
		} catch ( Repository_Exception $exception ) {
			$this->current_page = $page;
		}

		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Dashboard assets
	 */
	public function assets() {
		$ui_data = Plugin::instance()->framework->get_included_module_data( 'cherry-x-vue-ui.php' );
		( new \CX_Vue_UI( $ui_data ) )->enqueue_assets();

		$this->current_page->render_config();
		$this->register_scripts();

		// phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores
		do_action( "madx-fb/admin-pages/before-assets/{$this->current_page->slug()}", $this );

		$this->current_page->assets();
	}

	public function register_scripts() {
		wp_register_script(
			self::SCRIPT_VUEX,
			Plugin::instance()->plugin_url( 'assets/lib/vuex{min}.js' ),
			array(),
			'3.6.2',
			true
		);

		$name = ( $this->current_page instanceof Base_Single_Page ) ? 'single' : 'static';

		wp_register_style(
			self::STYLE_ADMIN,
			Plugin::instance()->plugin_url( "assets/css/admin/$name.css" ),
			array(
				self::STYLE_DASHICONS,
			),
			Plugin::instance()->get_version()
		);

		wp_register_script(
			self::SCRIPT_PACKAGE,
			Plugin::instance()->plugin_url( 'assets/js/admin/package{min}.js' ),
			array(
				'wp-api',
				'wp-api-fetch',
			),
			Plugin::instance()->get_version(),
			true
		);

		wp_localize_script(
			self::SCRIPT_PACKAGE,
			'madxFBPageConfigPackage',
			array(
				'nonce' => wp_create_nonce( $this->current_page->slug() )
			)
		);

		wp_register_script(
			self::SCRIPT_VUEX_PACKAGE,
			Plugin::instance()->plugin_url( 'assets/js/admin/vuex.package{min}.js' ),
			array(
				'madx-form-builder-admin-vuex',
				'madx-form-builder-admin-package',
			),
			Plugin::instance()->get_version(),
			true
		);

		wp_register_script(
			$this->current_page->slug(),
			$this->current_page->base_script_url(),
			array(),
			Plugin::instance()->get_version(),
			true
		);

		wp_set_script_translations(
			$this->current_page->slug(),
			'madx-form-builder',
			Plugin::instance()->plugin_dir( 'languages' )
		);
	}

}
