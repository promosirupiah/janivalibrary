<?php


namespace madx_Form_Builder\Admin\Pages\Settings;

use madx_Form_Builder\Addons\Manager;
use madx_Form_Builder\Admin\Buttons\Base_Vui_Button as Button;
use madx_Form_Builder\Admin\Notices\Base_Notice;
use madx_Form_Builder\Classes\Http\Utm_Url;

class Pro_Notice extends Base_Notice {

	public function get_id(): string {
		return 'see-pro-addons';
	}

	public function get_message(): string {
		return __(
			'Expand your forms functionality with automate, calculate, integrations of payments gateways, 
		CRMs and email marketing. Try premium addons for madxFormBuilder plugin.',
			'madx-form-builder'
		);
	}

	public function get_buttons(): array {
		$utm = new Utm_Url( 'wp-dashboard/madxformbuilder-notification' );
		$utm->set_campaign( 'check-pro-addons' );

		return array(
			( new Button( 'check' ) )
				->set_label( __( 'Check Pro Addons', 'madx-form-builder' ) )
				->set_size( Button::SIZE_MINI )
				->set_url( $utm->add_query( madx_FORM_BUILDER_SITE . '/addons/' ) ),
			( new Button( 'thanks' ) )
				->set_label( __( 'No, thanks', 'madx-form-builder' ) )
				->set_size( Button::SIZE_MINI )
				->set_style( Button::STYLE_ACCENT_BORDER ),
		);
	}
}
