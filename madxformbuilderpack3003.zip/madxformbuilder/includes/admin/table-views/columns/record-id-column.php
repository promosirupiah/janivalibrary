<?php


namespace madx_Form_Builder\Admin\Table_Views\Columns;

use madx_Form_Builder\Admin\Table_Views\Column_Base;


class Record_Id_Column extends Column_Base {

	protected $type   = 'integer';
	protected $column = 'id';

}
