<?php


namespace madx_Form_Builder\Admin\Exceptions;


use madx_Form_Builder\Exceptions\Handler_Exception;

class Failed_Box_Update extends Handler_Exception {

}