<?php

namespace madx_Form_Builder\Admin\Exceptions;

use madx_Form_Builder\Exceptions\Handler_Exception;

class Not_Found_Page_Exception extends Handler_Exception {

}