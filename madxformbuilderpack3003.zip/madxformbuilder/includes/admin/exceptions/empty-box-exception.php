<?php


namespace madx_Form_Builder\Admin\Exceptions;


use madx_Form_Builder\Exceptions\Silence_Exception;

class Empty_Box_Exception extends Silence_Exception {

}