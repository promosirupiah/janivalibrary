<?php


namespace madx_Form_Builder\Admin\Single_Pages\Meta_Containers;


class Side_Meta_Container extends Base_Meta_Container {

	public function get_type(): string {
		return self::TYPE_SIDE;
	}
}