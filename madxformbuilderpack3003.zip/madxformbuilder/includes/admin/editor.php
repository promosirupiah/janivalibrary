<?php

namespace madx_Form_Builder\Admin;

use madx_Form_Builder\Actions\Conditions\Condition_Manager as Action_Condition_Manager;
use madx_Form_Builder\Admin\Pages\Pages_Manager;
use madx_Form_Builder\Admin\Tabs_Handlers\Tab_Handler_Manager;
use madx_Form_Builder\Blocks\Validation;
use madx_Form_Builder\Classes\Arguments\Form_Arguments;
use madx_Form_Builder\Classes\Http\Utm_Url;
use madx_Form_Builder\Classes\Tools;
use madx_Form_Builder\Gateways\Gateway_Manager;
use madx_Form_Builder\Plugin;
use madx_Form_Builder\Blocks\Conditional_Block\Condition_Manager as Block_Condition_Manager;
use madx_Form_Builder\Post_Meta\Messages_Meta;

/**
 * Form editor class
 * Thanks Tom J Nowell for initial editor idea and inspiration!
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define Editor class
 */
class Editor {

	const EDITOR_HANDLE         = 'madx-form-builder-editor';
	const EDITOR_PACKAGE_HANDLE = 'madx-form-builder-editor-package';

	public function __construct() {
		add_action( 'enqueue_block_editor_assets', array( $this, 'admin_assets' ) );
	}

	/**
	 * Register admin assets
	 *
	 * @return void [type] [description]
	 */
	public function admin_assets() {
		if ( madx_form_builder()->post_type->is_form_editor ) {
			$this->enqueue_assets();
		} else {
			$this->enqueue_form_assets();
		}
	}

	/**
	 * Returns taxonomies list for the config
	 *
	 * @return [type] [description]
	 */
	public function get_taxonomies_list() {

		$taxonomies = get_taxonomies( array(), 'objects' );

		$result = array();

		foreach ( $taxonomies as $tax ) {
			$result[] = array(
				'value' => $tax->name,
				'label' => sprintf( '%1$s (%2$s)', $tax->label, $tax->name ),
			);
		}

		return $result;

	}

	public function get_preset_config() {
		return apply_filters(
			'madx-form-builder/editor/preset-config',
			array(
				'global_fields' => array(
					array(
						'name'    => 'from',
						'label'   => __( 'Source:', 'madx-form-builder' ),
						'type'    => 'select',
						'options' => Tools::with_placeholder(
							array(
								array(
									'value' => 'post',
									'label' => __( 'Post', 'madx-form-builder' ),
								),
								array(
									'value' => 'user',
									'label' => __( 'User', 'madx-form-builder' ),
								),
								array(
									'value' => 'query_var',
									'label' => __( 'URL Query Variable', 'madx-form-builder' ),
								),
							)
						),
					),
					array(
						'name'      => 'post_from',
						'label'     => __( 'Get post ID from:', 'madx-form-builder' ),
						'type'      => 'select',
						'options'   => Tools::with_placeholder(
							array(
								array(
									'value' => 'current_post',
									'label' => __( 'Current post', 'madx-form-builder' ),
								),
								array(
									'value' => 'query_var',
									'label' => __( 'URL Query Variable', 'madx-form-builder' ),
								),
							)
						),
						'condition' => array(
							'field' => 'from',
							'value' => 'post',
						),
					),
					array(
						'name'      => 'user_from',
						'label'     => __( 'Get user ID from:', 'madx-form-builder' ),
						'type'      => 'select',
						'options'   => Tools::with_placeholder(
							array(
								array(
									'value' => 'current_user',
									'label' => __( 'Current user', 'madx-form-builder' ),
								),
								array(
									'value' => 'queried_user',
									'label' => __( 'Queried user', 'madx-form-builder' ),
								),
								array(
									'value' => 'query_var',
									'label' => __( 'URL Query Variable', 'madx-form-builder' ),
								),
							)
						),
						'condition' => array(
							'field' => 'from',
							'value' => 'user',
						),
					),
					array(
						'name'             => 'query_var',
						'label'            => __( 'Query variable name:', 'madx-form-builder' ),
						'type'             => 'text',
						'custom_condition' => 'query_var',
						'position'         => 'dynamic',
					),
				),
				'map_fields'    => array(
					array(
						'name'             => 'key',
						'label'            => __( 'Query variable key', 'madx-form-builder' ),
						'type'             => 'text',
						'position'         => 'general',
						'parent_condition' => array(
							'field' => 'from',
							'value' => 'query_var',
						),
					),
					array(
						'name'             => 'prop',
						'label'            => __( 'Post property', 'madx-form-builder' ),
						'type'             => 'select',
						'options'          => Tools::with_placeholder(
							array(
								array(
									'value' => 'ID',
									'label' => __( 'Post ID', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_title',
									'label' => __( 'Post Title', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_content',
									'label' => __( 'Post Content', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_status',
									'label' => __( 'Post Status', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_author',
									'label' => __( 'Post Author', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_excerpt',
									'label' => __( 'Post Excerpt', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_date',
									'label' => __( 'Post Date', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_date_gmt',
									'label' => __( 'Post Date GMT', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_thumb',
									'label' => __( 'Post Thumbnail', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_meta',
									'label' => __( 'Post Meta', 'madx-form-builder' ),
								),
								array(
									'value' => 'post_terms',
									'label' => __( 'Post Terms', 'madx-form-builder' ),
								),
							)
						),
						'parent_condition' => array(
							'field' => 'from',
							'value' => 'post',
						),
					),
					array(
						'name'             => 'key',
						'label'            => __( 'Taxonomy', 'madx-form-builder' ),
						'type'             => 'select',
						'options'          => Tools::with_placeholder( $this->get_taxonomies_list() ),
						'parent_condition' => array(
							'field' => 'from',
							'value' => 'post',
						),
						'condition'        => array(
							'field' => 'prop',
							'value' => 'post_terms',
						),
					),
					array(
						'name'             => 'key',
						'label'            => __( 'Meta field key', 'madx-form-builder' ),
						'type'             => 'text',
						'parent_condition' => array(
							'field' => 'from',
							'value' => 'post',
						),
						'condition'        => array(
							'field' => 'prop',
							'value' => 'post_meta',
						),
					),
					array(
						'name'             => 'prop',
						'label'            => __( 'User field', 'madx-form-builder' ),
						'type'             => 'select',
						'options'          => Tools::with_placeholder(
							array(
								array(
									'value' => 'ID',
									'label' => __( 'User ID', 'madx-form-builder' ),
								),
								array(
									'value' => 'user_login',
									'label' => __( 'User Login', 'madx-form-builder' ),
								),
								array(
									'value' => 'user_email',
									'label' => __( 'Email', 'madx-form-builder' ),
								),
								array(
									'value' => 'password',
									'label' => __( 'Password', 'madx-form-builder' ),
								),
								array(
									'value' => 'first_name',
									'label' => __( 'First Name', 'madx-form-builder' ),
								),
								array(
									'value' => 'last_name',
									'label' => __( 'Last Name', 'madx-form-builder' ),
								),
								array(
									'value' => 'user_url',
									'label' => __( 'User URL', 'madx-form-builder' ),
								),
								array(
									'value' => 'user_meta',
									'label' => __( 'User Meta', 'madx-form-builder' ),
								),
							)
						),
						'parent_condition' => array(
							'field' => 'from',
							'value' => 'user',
						),
					),
					array(
						'name'             => 'key',
						'label'            => __( 'Meta field key', 'madx-form-builder' ),
						'type'             => 'text',
						'parent_condition' => array(
							'field' => 'from',
							'value' => 'user',
						),
						'condition'        => array(
							'field' => 'prop',
							'value' => 'user_meta',
						),
					),
				),
			)
		);
	}

	/**
	 * Enqueue editor assets
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		do_action( 'madx-form-builder/editor-package/before', $this, self::EDITOR_PACKAGE_HANDLE );

		wp_enqueue_script(
			self::EDITOR_PACKAGE_HANDLE,
			Plugin::instance()->plugin_url( 'assets/js/editor/package{min}.js' ),
			array(
				'wp-editor',
				'wp-core-data',
				'wp-data',
				'wp-block-library',
				'wp-format-library',
				'wp-api-fetch',
			),
			madx_FORM_BUILDER_VERSION,
			true
		);

		wp_localize_script(
			self::EDITOR_PACKAGE_HANDLE,
			'madxFormEvents',
			madx_fb_events()->to_array()
		);

		wp_localize_script(
			self::EDITOR_PACKAGE_HANDLE,
			'madxFormValidation',
			Validation::instance()->to_array()
		);

		wp_localize_script(
			self::EDITOR_PACKAGE_HANDLE,
			'madxFormBlockConditions',
			Block_Condition_Manager::instance()->to_array()
		);

		wp_set_script_translations(
			self::EDITOR_PACKAGE_HANDLE,
			'madx-form-builder',
			Plugin::instance()->plugin_dir( 'languages' )
		);

		do_action( 'madx-form-builder/editor-assets/before', $this, self::EDITOR_HANDLE );

		wp_enqueue_script(
			self::EDITOR_HANDLE,
			Plugin::instance()->plugin_url( 'assets/js/editor/form.builder{min}.js' ),
			array(),
			madx_FORM_BUILDER_VERSION,
			true
		);

		wp_enqueue_style(
			self::EDITOR_HANDLE,
			madx_FORM_BUILDER_URL . 'assets/css/editor.css',
			array(
				'media',
				'l10n',
				'buttons',
				'wp-edit-blocks',
				'wp-editor',
			),
			madx_FORM_BUILDER_VERSION,
			'all'
		);

		$conditions_settings = ( new Action_Condition_Manager() )->get_settings();

		/** @var Messages_Meta $messages_meta */
		$messages_meta = madx_form_builder()->post_type->get_meta( Messages_Meta::class );

		$utm     = new Utm_Url( 'wp-admin/editor-madx-form' );
		$addons  = madx_FORM_BUILDER_SITE . '/addons/';
		$pricing = madx_FORM_BUILDER_SITE . '/pricing/';

		wp_localize_script(
			self::EDITOR_PACKAGE_HANDLE,
			'madxFormEditorData',
			array(
				'presetConfig'            => $this->get_preset_config(),
				'messagesDefault'         => $messages_meta->messages(),
				'gateways'                => Gateway_Manager::instance()->editor_data(),
				'helpForRepeaters'        => $this->get_help_for_repeaters(),
				'global_settings'         => Tab_Handler_Manager::instance()->all(),
				'global_settings_url'     => Pages_Manager::instance()->get_stable_url( 'jfb-settings' ),
				'madxEngineVersion'        => Tools::get_madx_engine_version(),
				'actionConditionSettings' => $conditions_settings,
				'argumentsSource'         => Form_Arguments::get_options(),
				'utmLinks'                => array(
					'allProActions'  => $utm->set_campaign( 'pro-actions' )->add_query( $addons ),
					'limitResponses' => $utm->set_campaign( 'responses-pricing' )->add_query( $pricing ),
					'scheduleForm'   => $utm->set_campaign( 'schedule-pricing' )->add_query( $pricing ),
				),
				'isActivePro'             => madx_form_builder()->addons_manager->is_active(),
			)
		);

		do_action( 'madx-form-builder/editor-assets/after', $this, self::EDITOR_HANDLE );
	}

	private function get_help_for_repeaters() {
		return array(
			'conditional_block'     => array(
				'label' => __( 'With many conditions for the block, they are checked with the AND operator', 'madx-form-builder' ),
			),
			'conditional_block_or'  => array(
				'label' => __( 'With many conditions for the block, they are checked with the OR operator', 'madx-form-builder' ),
			),
			'conditional_action'    => array(
				'label' => __( 'With many conditions for the action, they are checked with the AND operator', 'madx-form-builder' ),
			),
			'conditional_action_or' => array(
				'label' => __( 'With many conditions for the action, they are checked with the OR operator', 'madx-form-builder' ),
			),
		);
	}

	public function enqueue_form_assets() {

		$handle = 'madx-form-builder/form';

		do_action( 'madx-form-builder/other-editor-assets/before', $this, $handle );

		wp_register_script(
			$handle,
			Plugin::instance()->plugin_url( 'assets/js/editor/default.builder{min}.js' ),
			array(
				'wp-core-data',
				'wp-data',
				'wp-block-library',
				'wp-format-library',
				'wp-api-fetch',
			),
			madx_FORM_BUILDER_VERSION,
			true
		);

		wp_register_style(
			'madx-form-builder-others',
			Plugin::instance()->plugin_url( 'assets/css/frontend.css' ),
			array(),
			Plugin::instance()->get_version()
		);

		do_action( 'madx-form-builder/other-editor-assets/after', $this, $handle );

	}

}
