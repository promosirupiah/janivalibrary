<?php


namespace madx_Form_Builder\Blocks\Exceptions;


use madx_Form_Builder\Exceptions\Silence_Exception;

class Render_Empty_Field extends Silence_Exception {

}