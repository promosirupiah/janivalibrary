<?php


namespace madx_Form_Builder\Blocks\Exceptions;


class Condition_Exception extends \Exception {

}