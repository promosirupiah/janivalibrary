<?php


namespace madx_Form_Builder\Blocks;


use madx_Form_Builder\Blocks\Types\Base;
use madx_Form_Builder\Blocks\Types\Conditional_Block;
use madx_Form_Builder\Classes\Tools;
use madx_Form_Builder\Plugin;

use \madx_Form_Builder\Blocks\Render\Base as RenderBase;


class Dynamic_Value {

	const HANDLE = 'madx-fb-dynamic-value';

	public function __construct() {
		add_action(
			'madx-form-builder/before-start-form-row',
			array( $this, 'add_dynamic_value_block' )
		);
		add_filter(
			'madx-form-builder/render/hidden-field',
			array( $this, 'on_render_hidden_field' ),
			10, 2
		);
		add_action(
			'wp_enqueue_scripts',
			array( $this, 'register_scripts' )
		);
		add_action(
			'madx_plugins/frontend/register_scripts',
			array( $this, 'register_scripts' )
		);
	}

	public function register_scripts() {
		wp_register_script(
			self::HANDLE,
			Plugin::instance()->plugin_url( 'assets/js/frontend/dynamic.value{min}.js' ),
			array(
				Conditional_Block::HANDLE,
			),
			Plugin::instance()->get_version(),
			true
		);
	}

	public function add_dynamic_value_block( Base $block ) {
		$groups = $this->get_groups_json( $block );

		if ( ! $groups ) {
			return;
		}

		$block->add_attribute( 'data-value', Tools::esc_attr( $groups ) );
	}

	public function on_render_hidden_field( array $args, RenderBase $block ): array {
		$groups = $this->get_groups_json( $block->block_type );

		if ( ! $groups ) {
			return $args;
		}

		$block->add_attribute( 'data-dynamic-value', Tools::esc_attr( $groups ) );

		return $args;
	}

	protected function get_groups_json( Base $block ): string {
		$groups = $block->block_attrs['value']['groups'] ?? array();

		if ( ! count( $groups ) ) {
			return '';
		}

		wp_enqueue_script( self::HANDLE );

		foreach ( $groups as &$group ) {
			$group['to_set'] = madx_fb_parse_dynamic( $group['to_set'] ?? '' );

			if ( ! isset( $group['conditions'] ) ) {
				continue;
			}

			foreach ( $group['conditions'] as &$condition ) {
				$condition['value'] = madx_fb_parse_dynamic( $condition['value'] ?? '' );
			}
		}

		return Tools::encode_json( $groups );
	}

}