<?php


namespace madx_Form_Builder\Blocks\Conditional_Block\Functions;


use madx_Form_Builder\Blocks\Conditional_Block\Condition_Types\Base_Condition_Type;
use madx_Form_Builder\Blocks\Exceptions\Condition_Exception;

class Function_Hide extends Base_Function {

	const ID = 'hide';

	public function get_id(): string {
		return self::ID;
	}

	public function get_title(): string {
		return __( 'Hide if...', 'madx-form-builder' );
	}

	public function get_display(): string {
		return __( 'Hide current block', 'madx-form-builder' );
	}

}