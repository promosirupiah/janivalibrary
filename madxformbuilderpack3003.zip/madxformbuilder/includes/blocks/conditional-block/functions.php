<?php


namespace madx_Form_Builder\Blocks\Conditional_Block;


use madx_Form_Builder\Blocks\Conditional_Block\Functions\Base_Function;
use madx_Form_Builder\Blocks\Conditional_Block\Functions\Function_Hide;
use madx_Form_Builder\Blocks\Conditional_Block\Functions\Function_Show;
use madx_Form_Builder\Classes\Arrayable\Array_Tools;
use madx_Form_Builder\Classes\Arrayable\Arrayable;
use madx_Form_Builder\Classes\Repository\Repository_Pattern_Trait;
use madx_Form_Builder\Exceptions\Repository_Exception;

class Functions implements Arrayable {

	use Repository_Pattern_Trait;

	public function __construct() {
		$this->rep_install();
	}

	public function rep_instances(): array {
		return apply_filters(
			'madx-form-builder/conditional-block/functions',
			array(
				new Function_Show(),
				new Function_Hide(),
			)
		);
	}

	/**
	 * @param string $slug
	 *
	 * @return Base_Function
	 * @throws Repository_Exception
	 */
	public function get_function( string $slug ): Base_Function {
		return $this->rep_get_item( $slug );
	}

	/**
	 * @return array
	 */
	public function to_array(): array {
		return Array_Tools::to_array( $this->rep_get_items() );
	}
}