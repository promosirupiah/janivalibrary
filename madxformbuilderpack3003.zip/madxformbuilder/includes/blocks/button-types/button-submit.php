<?php


namespace madx_Form_Builder\Blocks\Button_Types;

class Button_Submit extends Button_Type_Base {

	public function slug(): string {
		return 'submit';
	}

	public function label(): string {
		return __( 'Submit Form', 'madx-form-builder' );
	}

	public function preset_label(): string {
		return __( 'Submit', 'madx-form-builder' );
	}

	public function html_attrs(): array {
		$button   = array( "madx-form-builder__{$this->slug()}" );
		$type     = madx_fb_live_args()->get_submit_type();
		$button[] = "submit-type-{$type}";

		return array(
			'type'  => 'submit',
			'class' => array(
				'button'  => $button,
				'wrapper' => "madx-form-builder__{$this->slug()}-wrap",
			),
		);
	}


}
