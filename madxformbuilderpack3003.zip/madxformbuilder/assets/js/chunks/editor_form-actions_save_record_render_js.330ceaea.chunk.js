"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk"] = self["webpackChunk"] || []).push([["editor_form-actions_save_record_render_js"],{

/***/ "./editor/form-actions/save.record/render.js":
/*!***************************************************!*\
  !*** ./editor/form-actions/save.record/render.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nvar ToggleControl = wp.components.ToggleControl;\nfunction SaveRecordRender(_ref) {\n  var settings = _ref.settings,\n    label = _ref.label,\n    onChangeSettingObj = _ref.onChangeSettingObj;\n  return wp.element.createElement(React.Fragment, null, wp.element.createElement(ToggleControl, {\n    label: label('save_user_data'),\n    checked: settings.save_user_data,\n    onChange: function onChange(save_user_data) {\n      return onChangeSettingObj({\n        save_user_data: save_user_data\n      });\n    }\n  }));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SaveRecordRender);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9lZGl0b3IvZm9ybS1hY3Rpb25zL3NhdmUucmVjb3JkL3JlbmRlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsSUFDT0EsYUFBYSxHQUNWQyxFQUFFLENBQUNDLFVBQVUsQ0FEaEJGLGFBQWE7QUFHcEIsU0FBU0csZ0JBQWdCLE9BSXJCO0VBQUEsSUFISEMsUUFBUSxRQUFSQSxRQUFRO0lBQ1JDLEtBQUssUUFBTEEsS0FBSztJQUNMQyxrQkFBa0IsUUFBbEJBLGtCQUFrQjtFQUdsQixPQUFPLCtDQUNOLHlCQUFDLGFBQWE7SUFDYixLQUFLLEVBQUdELEtBQUssQ0FBRSxnQkFBZ0IsQ0FBSTtJQUNuQyxPQUFPLEVBQUdELFFBQVEsQ0FBQ0csY0FBZ0I7SUFDbkMsUUFBUSxFQUNQLGtCQUFBQSxjQUFjO01BQUEsT0FBSUQsa0JBQWtCLENBQUU7UUFBRUMsY0FBYyxFQUFkQTtNQUFlLENBQUMsQ0FBRTtJQUFBO0VBQzFELEVBQ0EsQ0FDQTtBQUNKO0FBRUEsaUVBQWVKLGdCQUFnQiIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL2VkaXRvci9mb3JtLWFjdGlvbnMvc2F2ZS5yZWNvcmQvcmVuZGVyLmpzPzQ3MWIiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qge1xyXG5cdCAgICAgIFRvZ2dsZUNvbnRyb2wsXHJcbiAgICAgIH0gPSB3cC5jb21wb25lbnRzO1xyXG5cclxuZnVuY3Rpb24gU2F2ZVJlY29yZFJlbmRlcigge1xyXG5cdHNldHRpbmdzLFxyXG5cdGxhYmVsLFxyXG5cdG9uQ2hhbmdlU2V0dGluZ09iaixcclxufSApIHtcclxuXHJcblx0cmV0dXJuIDw+XHJcblx0XHQ8VG9nZ2xlQ29udHJvbFxyXG5cdFx0XHRsYWJlbD17IGxhYmVsKCAnc2F2ZV91c2VyX2RhdGEnICkgfVxyXG5cdFx0XHRjaGVja2VkPXsgc2V0dGluZ3Muc2F2ZV91c2VyX2RhdGEgfVxyXG5cdFx0XHRvbkNoYW5nZT17XHJcblx0XHRcdFx0c2F2ZV91c2VyX2RhdGEgPT4gb25DaGFuZ2VTZXR0aW5nT2JqKCB7IHNhdmVfdXNlcl9kYXRhIH0gKVxyXG5cdFx0XHR9XHJcblx0XHQvPlxyXG5cdDwvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2F2ZVJlY29yZFJlbmRlcjsiXSwibmFtZXMiOlsiVG9nZ2xlQ29udHJvbCIsIndwIiwiY29tcG9uZW50cyIsIlNhdmVSZWNvcmRSZW5kZXIiLCJzZXR0aW5ncyIsImxhYmVsIiwib25DaGFuZ2VTZXR0aW5nT2JqIiwic2F2ZV91c2VyX2RhdGEiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./editor/form-actions/save.record/render.js\n");

/***/ })

}]);