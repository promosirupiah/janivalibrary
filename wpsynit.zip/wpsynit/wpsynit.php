<?
/**
 Plugin Name: WPSynIT
 Plugin URI: http://wpsynit.zar.vg
 Version: 1.0.1
 Description: Autosubmits your article to wordpress article directories when post is published, while at the same time spinning it.
 Author: wickedguy
 Author URI: http://wpsynit.zar.vg
*/

if (($get_post_info->post_status == 'publish' || $_POST['publish'] == 'Publish') && ($_POST['prev_status'] == 'draft' || $_POST['original_post_status'] == 'draft' || $_POST['original_post_status'] == 'auto-draft' || $_POST['prev_status'] == 'pending' || $_POST['original_post_status'] == 'pending' ) ){
if (get_option('wpsyn_publish')=='yes'){add_action('publish_post', 'syndicator_save_permanent',10,2 );}}
add_action('admin_menu', 'syn_add_pages');
add_option('version', '1.0.1');
add_option('wpsyn_api', '');
add_option('wpsyn_title', '');
add_option('wpsyn_category', '');
add_option('wpsyn_body', '');
add_option('wpsyn_resource', 'This Author is a {prolific|really good|really excellent} {writer|webmaster|author|web-master} who {talks|writes|teaches|teach} {regarding|about|with regards to} <a href="http://thelinkyouwanttopromote.com">[anchors]</a>');
add_option('wpsyn_keywords', '');
add_option('wpsyn_totaldir', 10);
add_option('wpsyn_host', $_SERVER['HTTP_HOST']);
add_option('wpsyn_publish', 'yes');
add_option('wpsyn_edit','');
add_option('wpsyn_makespuntitle', 'yes');
add_option('wpsyn_makespunbody','yes');

if($_POST['savesettings']){$save=syndicator_save($_POST['wpsyn_title'],$_POST['wpsyn_category'],$_POST['wpsyn_body'],$_POST['wpsyn_resource'],$_POST['wpsyn_keywords'],$_POST['wpsyn_publish'],$_POST['wpsyn_edit'],$_POST['wpsyn_totaldir'],$_POST['wpsyn_makespuntitle'],$_POST['wpsyn_makespunbody']);}
if($_POST['saveapi']){update_option('wpsyn_api', trim($_POST['wpsyn_api']));}if($_POST['save_wpsyn_totaldir']){update_option('wpsyn_totaldir', trim($_POST['wpsyn_totaldir']));}function wpsyn_admin(){echo '<div class="wrap">';?><TABLE width="100%" height="100%" border="0" cellpadding="2" cellspacing="15"><TR><TD align="left" valign="top" width="50%" height="auto"><? echo "<h2>WPSynIT v1.0.1</h2>";
$x = WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__));echo curl_get_file_contents('http://wpsynit.zar.vg/ac.php?va='.trim(get_option('wpsyn_api')));if($_POST['submitarticle']){$submit = syndicator_post_manual($_POST['wpsyn_category'],$_POST['wpsyn_title'],$_POST['wpsyn_body'],$_POST['wpsyn_resource'],$_POST['wpsyn_keywords'],$_POST['wpsyn_totaldir'],get_option('wpsyn_host'),get_option('wpsyn_api'));}if($_POST['verifyapi']){echo curl_get_file_contents('http://wpsynit.zar.vg/api.php?va='.trim($_POST['wpsyn_api']));}?>
<div id="message" class="updated"><p><strong>MANUAL SUBMISSIONS:</strong> Select the desired <b>category</b> to submit to, the <b>total directories</b> to post to, enter your <b>title, article body, resourcebox details and keywords</b> and then hit the Save Article button. You may use a normal, or spun syntax article (recommended). WPsynIT will then post a different version to each directory each time you publish a post.</p></div><form name="form1" method="post" action="<? echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>"><p><b>ENTER YOUR API KEY and click Save API key:</b><br><INPUT type="text" size="40" name="wpsyn_api" value="<? echo get_option('wpsyn_api');?>"><input type="submit" name="saveapi" value="Save API key" class="button"/><input type="submit" name="verifyapi" value="Verify API key" class="button"/></p><p><b>CATEGORY:</b><br><select name="wpsyn_category" size="1" ><? $options = curl_get_file_contents("http://wpsynit.zar.vg/categories");$options=explode("\n",$options);if(get_option('wpsyn_category')==''){echo "<option value=\"0\" selected>Select Category</option>";}else{$seek=explode(':',get_option('wpsyn_category'));echo "<option value=\"".get_option('wpsyn_category')."\" selected>".$seek[2]."</option>";}foreach ($options as $key => $val){$cat = explode(":",$val);$count=count($cat)-1;$catt = trim($cat[$count]);echo "<option value=\"$val\">$catt</option>";}?></select> (Select Category to post to at the Directories)</p>
<p><b>TOTAL DIRECTORIES TO POST TO:</b>
<select name="wpsyn_totaldir">
<option value="<? echo get_option('wpsyn_totaldir');?>" selected="selected"><? echo get_option('wpsyn_totaldir');?></option>
<option value="5">5  </option>
<option value="10">10  </option>
<option value="20">20  </option>
<option value="30">30  </option>
<option value="40">40  </option>
<option value="50">50  </option>
</select>
<input name="save_wpsyn_totaldir" id="doaction" class="button-secondary action" value="Update" type="submit"></p>
<p><b>TITLE:</b> (this may also be in spun syntax)<br>
<TEXTAREA name="wpsyn_title" rows=4 cols=74 ><? echo stripslashes(get_option('wpsyn_title'));?></TEXTAREA></p>
<p><b>ARTICLE BODY:</b> (this may also be in spun syntax)<br>
<TEXTAREA name="wpsyn_body" rows=21 cols=74 ><? echo stripslashes(get_option('wpsyn_body'));?></TEXTAREA></p>
<p><b>RESOURCEBOX:</b><br><TEXTAREA name="wpsyn_resource" rows=9 cols=74 ><? echo stripslashes(get_option('wpsyn_resource'));?></TEXTAREA></p>
<p><b>KEYWORDS:</b> (enter tags seperated by commas)<br><INPUT type="text" size="74" name="wpsyn_keywords" value="<? echo get_option('wpsyn_keywords');?>"></p>
<p><? $updo= curl_get_file_contents("http://wpsynit.zar.vg/updo");echo str_replace('THEAPI',get_option('wpsyn_api'),$updo);?></p><p><INPUT type="checkbox" name="wpsyn_publish" value="yes" <? if (get_option('wpsyn_publish')=='yes'){echo "checked";} ?>><b>Submit when a Post is Published.</b><INPUT type="checkbox" name="wpsyn_makespuntitle" value="yes" <? if (get_option('wpsyn_makespuntitle')=='yes'){echo "checked";} ?>><b>Create Spun Title.</b><INPUT type="checkbox" name="wpsyn_makespunbody" value="yes" <? if (get_option('wpsyn_makespunbody')=='yes'){echo "checked";} ?>><b>Create Spun Body.</b></p><p class="submit"><input type="submit" name="savesettings" value="Save Settings" class="button-primary"/><input type="submit" name="submitarticle" value="Submit Article" class="button-primary"/></p></form></div></TD><TD align="left" valign="top" width="auto" height="auto"><p><? $news = curl_get_file_contents("http://wpsynit.zar.vg/instructions");echo str_replace("\n","<br />",$news);?></p></TD></TR></TABLE><?}
function syn_add_pages(){add_menu_page("WPSynIT", "WPSynIT", 8, __FILE__, "wpsyn_admin");}
function syndicator_save($title,$category,$body,$resource,$keywords,$publish,$edit,$totaldir,$makespuntitle,$makespunbody){
$title=stripslashes($title);
$category=stripslashes($category);
$body=stripslashes($body);
$resource=stripslashes($resource);
update_option('wpsyn_title', $title);update_option('wpsyn_category', $category);update_option('wpsyn_body', $body);update_option('wpsyn_resource', $resource);update_option('wpsyn_keywords', $keywords);update_option('wpsyn_totaldir', $totaldir);update_option('wpsyn_publish', $publish);update_option('wpsyn_edit', $edit);update_option('wpsyn_makespuntitle',$makespuntitle);update_option('wpsyn_makespunbody',$makespunbody);}
function syndicator_post_manual($category,$title,$body,$resource,$keywords,$totaldir,$host,$api){$postString= "category=".trim($category)."&title=".trim($title)."&body=" .trim($body) ."&resource=".trim($resource)."&keywords=".trim($keywords)."&host=".trim($host)."&totaldir=".trim($totaldir)."&api=".trim($api)."&mst=".trim(get_option('wpsyn_makespuntitle'))."&msb=".trim(get_option('wpsyn_makespunbody'));echo curl_post('http://wpsynit.zar.vg/api.php',$postString);}
function syndicator_post_auto(){
$wpcat = get_the_category();
$wpcat= $wpcat[0]->cat_name;
$queried_post = get_post($post_ID);
$wptitle = $_POST['post_title'];
$wpcontent= $_POST['post_content'];
$tags = get_the_tags();
if ($tags){foreach($tags as $tag){$tagx .= $tag->name . ',';}}$tagx =eregi_replace(',$','', $tagx);
$postString= "category=".trim(get_option('wpsyn_category'))."&title=".trim($wptitle)."&body=" .trim($wpcontent) ."&resource=".trim(get_option('wpsyn_resource'))."&keywords=".trim(get_option('wpsyn_keywords'))."&host=".trim(get_option('wpsyn_host'))."&totaldir=".trim(get_option('wpsyn_totaldir'))."&api=".trim(get_option('wpsyn_api'))."&pm=".get_permalink($post_ID)."&wpcat=".$wpcat."&wptags=".trim($tagx)."&mst=".trim(get_option('wpsyn_makespuntitle'))."&msb=".trim(get_option('wpsyn_makespunbody'));echo curl_post('http://wpsynit.zar.vg/api.php',$postString);}
global $the_post_is_saving;
$the_post_is_saving = 0;
function syndicator_save_permanent($post_ID,$post){
if ($post->post_date != $post->post_modified) return $post_ID;
global $the_post_is_saving;
if ($the_post_is_saving) return $post_ID;
$wptitle = $_POST['post_title'];
$wpcontent= $_POST['post_content'];
$content=spin_the_content($_POST['post_content']);
$_POST['post_content'] = $content;
if (get_option('spincomments')=='yes'){
$strcomment=spin_the_content($_POST['post_comment']);
$_POST['post_comment'] = $strcomment;
}
$strtitle=spin_the_content($_POST['post_title']);
$_POST['post_title'] = $strtitle;
$excerpt=spin_the_content($_POST['post_excerpt']);
$_POST['post_excerpt'] = $excerpt;
$_POST['post_status'] = 'publish';
$the_post_is_saving = 1;
wp_update_post($_POST);
$the_post_is_saving = 0;
$tags = get_the_tags();
if ($tags){foreach($tags as $tag){$tagx .= $tag->name . ',';}}$tagx =eregi_replace(',$','', $tagx);
$postString= "category=".trim(get_option('wpsyn_category'))."&title=".trim($wptitle)."&body=" .trim($wpcontent) ."&resource=AUTO&keywords=".trim(get_option('wpsyn_keywords'))."&host=".trim(get_option('wpsyn_host'))."&totaldir=".trim(get_option('wpsyn_totaldir'))."&api=".trim(get_option('wpsyn_api'))."&pm=".get_permalink($post_ID)."&wpcat=".$wpcat."&wptags=".trim($tagx)."&mst=".trim(get_option('wpsyn_makespuntitle'))."&msb=".trim(get_option('wpsyn_makespunbody'));echo curl_post('http://wpsynit.zar.vg/api.php',$postString);
return $post_ID;
}
function spin_the_content($text){
$text = stripslashes($text);
$pattern = '/\{\{(.*?)\}\}/si';
preg_match_all($pattern,$text,$matches);
for ($i=0; $i< count($matches[0]); $i++) {
$search = explode("||",$matches[1][$i]);
srand((float)microtime() * 1000000);
shuffle($search);
$text = str_replace($matches[0][$i],$search[0],$text);
}
for ($j=0; $j< 10; $j++) {
$pattern = '/\{([^{}]*)\}/si';
preg_match_all($pattern,$text,$matches);
for ($i=0; $i< count($matches[0]); $i++) {
$search = explode("|",$matches[1][$i]);
srand((float)microtime() * 1000000);
shuffle($search);
$text = str_replace($matches[0][$i],$search[0],$text);
}
}
return stripslashes(trim($text));
}
function curl_get_file_contents($URL){$c = curl_init();curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);curl_setopt($c, CURLOPT_URL, $URL);$contents = curl_exec($c);curl_close($c);if ($contents) return $contents;else return false;}function curl_post($URL,$poststring){$ch=curl_init();curl_setopt ($ch, CURLOPT_URL,$URL);curl_setopt ($ch, CURLOPT_POSTFIELDS, $poststring);curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 25);curl_setopt($ch, CURLOPT_TIMEOUT, 25);$data=curl_exec ($ch);flush();curl_close($ch);if ($data) return $data;else return false;}
?>