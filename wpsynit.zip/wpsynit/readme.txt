WPSynIT plugin for Wordpress

Installation and usage instructions: 

Upload the wpsynit folder to your wordpress plugins directory.
Go to your wordpress admin panel and activate WPSynIT.

You will find detailed usage instructions once you visit the WPSynIT user interface in your wordpress admin panel.