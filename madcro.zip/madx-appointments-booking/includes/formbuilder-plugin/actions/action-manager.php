<?php


namespace madx_APB\Formbuilder_Plugin\Actions;


use madx_APB\Formbuilder_Plugin\With_Form_Builder;

/**
 * The script for registering the action
 * is displayed in the
 * madx_APB\Formbuilder_Plugin\Blocks\Blocks_Manager class
 *
 * Class Action_Manager
 * @package madx_ABAF\Formbuilder_Plugin\Actions
 */
class Action_Manager {

	use With_Form_Builder;

	public function manager_init() {
		add_action(
			'madx-form-builder/actions/register',
			array( $this, 'register_actions' )
		);
		add_action(
			'madx-form-builder/editor-assets/before',
			array( $this, 'editor_assets' )
		);
	}

	public function register_actions( $manager ) {
		$manager->register_action_type( new Insert_Appointment_Action() );
	}

	public function editor_assets() {
		wp_enqueue_script(
			'madx-app-booking-form-builder-editor',
			madx_APB_URL . 'assets/js/builder.editor.js',
			array(),
			madx_APB_VERSION,
			true
		);
	}
}