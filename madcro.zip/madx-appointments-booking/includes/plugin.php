<?php
namespace madx_APB;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * @property WC_Integration wc
 * @property DB\Manager db
 * @property Form form
 * @property Admin\Settings settings
 * @property Rest_API\Manager rest_api
 * @property Tools tools
 * @property Calendar calendar
 *
 * Main file
 */
class Plugin {

	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	/**
	 * @var DB\Manager
	 */
	public $db = null;

	/**
	 * [$data description]
	 * @var boolean
	 */
	public $data = false;

	/**
	 * [$working_hours_config description]
	 * @var array
	 */
	public $working_hours_config = false;

	public $settings;
	public $tools;
	public $services_meta;
	public $providers_meta;
	public $form;
	public $calendar;
	public $rest_api;
	public $google_cal;
	public $wc;
	public $madxartwork;
	public $statuses;
	public $workflows;
	public $setup;
	public $dashboard;
	public $macros;

	/**
	 * Plugin constructor.
	 */
	private function __construct() {

		if ( ! function_exists( 'madx_engine' ) ) {

			add_action( 'admin_notices', function() {
				$class = 'notice notice-error';
				$message = __( '<b>WARNING!</b> <b>madxAppointmentsBooking</b> plugin requires <b>madxEngine</b> plugin to work properly!', 'madx-appointments-booking' );
				printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $message ) );
			} );

			return;
		}

		$this->register_autoloader();

		// madx Dashboard Init
		add_action( 'after_setup_theme', array( $this, 'init_components' ), 0 );

		// madx Dashboard Init
		add_action( 'init', array( $this, 'madx_dashboard_init' ), -999 );
	}

	/**
	 * Returns plugin version
	 *
	 * @return string
	 */
	public function get_version() {

		if ( is_admin() ) {

			if( ! function_exists('get_plugin_data') ){
				require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			if( ! $this->data ){
				$this->data = get_plugin_data( madx_APB__FILE__ );
			}
		}

		return $this->data['Version'];
	}

	/**
	 * Page slug
	 *
	 * @return string
	 */
	public function slug() {
		return 'madx-appointments-booking';
	}

	/**
	 * Register autoloader.
	 */
	private function register_autoloader() {
		require madx_APB_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}


	/**
	 * [madx_dashboard_init description]
	 * @return [type] [description]
	 */
	public function madx_dashboard_init() {

		if ( is_admin() ) {

			if( ! class_exists( 'madx_Dashboard\Dashboard' ) ){
				return;
			}

			$madx_dashboard = \madx_Dashboard\Dashboard::get_instance();

			$madx_dashboard->init( array(
				'path'           => $madx_dashboard->get_dashboard_path(),
				'url'            => $madx_dashboard->get_dashboard_url(),
				'cx_ui_instance' => array( $this, 'madx_dashboard_ui_instance_init' ),
				'plugin_data'    => array(
					'slug'    => $this->slug(),
					'file'    => madx_APB_PLUGIN_BASE,
					'version' => $this->get_version(),
					'plugin_links' => array(
						array(
							'label'  => esc_html__( 'Go to settings', 'madx-elements' ),
							'url'    => add_query_arg( array( 'page' => 'madx-dashboard-settings-page', 'subpage' => 'madx-apb-general-settings' ), admin_url( 'admin.php' ) ),
							'target' => '_self',
						),
					),
				),
			) );
		}
	}

	/**
	 * [madx_dashboard_ui_instance_init description]
	 * @return [type] [description]
	 */
	public function madx_dashboard_ui_instance_init() {
		$cx_ui_module_data = madx_engine()->framework->get_included_module_data( 'cherry-x-vue-ui.php' );

		return new \CX_Vue_UI( $cx_ui_module_data );
	}

	/**
	 * Initialize plugin parts
	 *
	 * @return void
	 */
	public function init_components() {
		
		add_action( 'admin_enqueue_scripts', [ $this, 'register_assets' ],        0 );
		add_action( 'wp_enqueue_scripts',    [ $this, 'register_public_assets' ], 0 );
		add_action( 'init',                  [ $this, 'register_macros' ] );

		$this->db                   = new DB\Manager();
		$this->settings             = new Admin\Settings();
		$this->tools                = new Tools();
		$this->services_meta        = new Admin\Cpt_Meta_Box\Services_Meta();
		$this->form                 = new Form();
		$this->calendar             = new Calendar();
		$this->rest_api             = new Rest_API\Manager();
		$this->google_cal           = new Google_Calendar();
		$this->wc                   = new WC_Integration();
		$this->madxartwork            = new madxartwork_Integration\Manager();
		$this->statuses             = new Statuses();
		$this->workflows            = new Workflows\Manager();

		Integrations\Manager::instance();

		if ( $this->settings->get( 'providers_cpt' ) ) {
			$this->providers_meta = new Admin\Cpt_Meta_Box\Providers_Meta();
		}

		if ( is_admin() ) {
			$this->setup = new Set_Up();

			//Init Settings Manager
			new \madx_APB\Admin\Settings\Manager();

			$this->dashboard = new Admin\Dashboard( array(
				new Admin\Pages\Appointments(),
			) );
			
			new DB_Upgrader();

		}

		new Listings();
		new Formbuilder_Plugin\Form_Builder();
		new Public_Actions\Manager();

		Cron\Manager::instance();
	}

	public function register_macros() {
		$this->macros = new Macros();
	}

	/**
	 * Page specific assets
	 *
	 * @return [type] [description]
	 */
	public function register_assets() {
		$this->register_script( 'momentjs', 'lib/moment/moment.min.js', true );
		$this->register_script( 'vuejs-datepicker', 'admin/lib/vuejs-datepicker.min.js' );
		$this->register_script( 'madx-apb-wc-details-builder', 'admin/wc-details-builder.js' );

		$this->register_style( 'vanilla-calendar', 'public/vanilla-calendar.css' );
		$this->register_style( 'madx-apb-working-hours', 'admin/working-hours.css' );
		$this->register_style( 'madx-apb-workflows', 'admin/workflows.css' );
		$this->register_style( 'madx-apb-integrations', 'admin/integrations.css' );
		$this->register_style( 'madx-apb-set-up', 'admin/set-up.css' );
		$this->register_style( 'madx-appointments-booking-admin', 'admin/madx-appointments-booking-admin.css' );
	}
	/**
	 * Page specific assets
	 *
	 * @return [type] [description]
	 */
	public function register_public_assets() {

		$this->register_script( 'madx-ab-front-init', 'public/appointments-init.js' );
		$this->register_script( 'madx-ab-choices', 'lib/choices/choices.min.js', true );
		$this->register_script( 'momentjs', 'lib/moment/moment.min.js', true );
		
		$this->register_script( 'vanilla-calendar', 'public/vanilla-calendar.js' );
		$this->register_script( 'flatpickr', 'lib/flatpickr/flatpickr.js', true );

		$this->register_style( 'madx-ab-front-style', 'public/madx-appointments-booking.css' );
		$this->register_style( 'madx-ab-choices', 'lib/choices/choices.min.css', true );
		$this->register_style( 'flatpickr', 'lib/flatpickr/flatpickr.min.css', true );
		$this->register_style( 'vanilla-calendar', 'public/vanilla-calendar.css' );
	}
	
	/**
	 * Register script
	 *
	 * @param  [type] $handle    [description]
	 * @param  [type] $file_path [description]
	 * @return [type]            [description]
	 */
	public function register_script( $handle = null, $file_path = null, $from_root = false ) {

		$prefix = 'assets/';

		if ( ! $from_root ) {
			$prefix .= 'js/';
		}

		wp_register_script(
			$handle,
			madx_APB_URL . $prefix . $file_path,
			array( 'wp-api-fetch', 'jquery' ),
			madx_APB_VERSION,
			true
		);
	}

	/**
	 * Register style
	 *
	 * @param  [type] $handle    [description]
	 * @param  [type] $file_path [description]
	 * @return [type]            [description]
	 */
	public function register_style( $handle = null, $file_path = null, $from_root = false ) {

		$prefix = 'assets/';

		if ( ! $from_root ) {
			$prefix .= 'css/';
		}

		wp_register_style(
			$handle,
			madx_APB_URL . $prefix . $file_path,
			array(),
			madx_APB_VERSION
		);
	}

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {

			self::$instance = new self();

		}

		return self::$instance;
	}
}

Plugin::instance();
