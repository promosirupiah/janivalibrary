<?php
namespace madx_APB\Admin\Settings;

use madx_APB\Plugin;
use madx_APB\Admin\Settings\Appointment_Settings_Base as Appointment_Settings_Base;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Working_Hours extends Appointment_Settings_Base {

	/**
	 * Returns module slug
	 *
	 * @return void
	 */
	public function get_page_slug() {
		return 'madx-apb-working-hours-settings';
	}

	/**
	 * [get_page_name description]
	 * @return [type] [description]
	 */
	public function get_page_name() {
		return esc_html__( 'Working Hours', 'madx-dashboard' );
	}

	public function page_assets() {
		Plugin::instance()->dashboard->components->appointments_range->assets();
	}

	/**
	 * [page_templates description]
	 * @param  array  $templates [description]
	 * @param  string $subpage   [description]
	 * @return [type]            [description]
	 */
	public function page_templates( $templates = array(), $page = false, $subpage = false ) {
		
		Plugin::instance()->dashboard->components->appointments_range->template();

		$templates['madx-apb-working-hours-settings'] = madx_APB_PATH .'templates/admin/madx-apb-settings/settings-working-hours.php';
		
		ob_start();
		include madx_APB_PATH . 'templates/admin/madx-apb-settings/custom-day-schedule.php';
		$content = ob_get_clean();

		printf(
			'<script type="text/x-template" id="madx-apb-custom-day-schedule">%s</script>',
			$content
		);
		
		return $templates;
	}
}
