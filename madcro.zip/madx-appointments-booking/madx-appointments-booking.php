<?php
/**
 * Plugin Name: madx Appointments Booking
 * Plugin URI:  https://madxartwork.eu.org/plugins/madxappointment/
 * Description: A must-have solution to create forms for booking the appointments.
 * Version:     2.0.1
 * Author:      madxartwork.eu.org
 * Author URI:  https://madxartwork.eu.org/
 * Text Domain: madx-appointments-booking
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

add_action( 'plugins_loaded', 'madx_apb_init' );

function madx_apb_init() {

	define( 'madx_APB_VERSION', '2.0.1' );
	define( 'madx_APB__FILE__', __FILE__ );
	define( 'madx_APB_PLUGIN_BASE', plugin_basename( madx_APB__FILE__ ) );
	define( 'madx_APB_PATH', plugin_dir_path( madx_APB__FILE__ ) );
	define( 'madx_APB_URL', plugins_url( '/', madx_APB__FILE__ ) );

	require madx_APB_PATH . 'includes/plugin.php';

}

add_action('plugins_loaded', 'madx_apb_lang');

function madx_apb_lang() {
	load_plugin_textdomain('madx-appointments-booking', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

function madx_apb() {
	return madx_APB\Plugin::instance();
}
