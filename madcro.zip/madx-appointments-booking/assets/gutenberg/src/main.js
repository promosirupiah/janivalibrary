import './actions/insert-appointment';
import * as provider from 'blocks/appointment-provider';
import * as date from 'blocks/appointment-date';

const {
		  addFilter,
	  } = wp.hooks;

addFilter( 'madx.fb.register.fields', 'madx-form-builder', blocks => {
	blocks.push( provider, date );

	return blocks;
} );
