(function () {

	'use strict';

	let picker,
		calendar = null,
		settings = {
			selector: '.appointment-calendar',
			datesFilter: true,
			pastDates: false,
			layout: window.madxAPBData.layout,
			weekDays: window.madxAPBData.week_days,
			timeFormat: window.madxAPBData.time_format,
			weekStart: window.madxAPBData.start_of_week,
			scrollToDetails: window.madxAPBData.scroll_to_details,
			api: window.madxAPBData.api,
			multiBooking: window.madxAPBData.multi_booking,
			services: window.madxAPBData.services,
			providers: window.madxAPBData.providers,
			UTCOffset: parseFloat( window.madxAPBData.utc_offset ),
			namespace: '',
		};

	if ( window.madxAPBData.months ) {
		settings.months = window.madxAPBData.months;
	}

	if ( window.madxAPBData.shortWeekday ) {
		settings.shortWeekday = window.madxAPBData.shortWeekday;
	}

	const calcFiledValue = function( value, $field ) {
			if ( 'appointment' === $field.data( 'field' ) ) {
				let outputValue = 0,
					parseValue = value ? JSON.parse( value ) : 0 ;

				if( typeof parseValue === 'object' ){
					for ( const slot of parseValue ) {
						outputValue += parseFloat( slot.price );
					}

					value = outputValue;
				}
			}

			return value;
		},
		bookingFormIinit = function( e, $el ) {

			let $cal = $el.find( '.appointment-calendar' );
			
			if ( ! $cal.length ) {
				return;
			}

			if ( calendar && calendar.destroy ) {
				calendar.destroy();
			}

			settings.namespace = e.data.namespace;
			calendar = new VanillaCalendar( settings );

			if( settings.namespace === "madx-form-builder" ){
				madxFormBuilderMain.filters.addFilter( 'forms/calculated-field-value', calcFiledValue );
			} else {
				madxEngine.filters.addFilter( 'forms/calculated-field-value', calcFiledValue );
			}

		};

	jQuery( document ).on( 'madx-engine/booking-form/init', { namespace: "madx-form" }, bookingFormIinit );
	jQuery( document ).on( 'madx-form-builder/init', { namespace: "madx-form-builder" }, bookingFormIinit );

}());
