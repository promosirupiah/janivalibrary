<div>
	<cx-vui-switcher
		label="<?php esc_html_e( 'Use custom labels', 'madx-appointments-booking' ); ?>"
		description="<?php esc_html_e( 'Check this change default weekdays and month labels', 'madx-appointments-booking' ); ?>"
		:wrapper-css="[ 'equalwidth' ]"
		:value="settings.use_custom_labels"
		@input="updateSetting( $event, 'use_custom_labels' )"
	></cx-vui-switcher>
	<template v-if="settings.use_custom_labels">
		<cx-vui-input
			label="<?php esc_html_e( 'Sunday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Sun', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Sun"
			@on-input-change="updateLabel( $event.target.value, 'Sun' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'Monday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Mon', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Mon"
			@on-input-change="updateLabel( $event.target.value, 'Mon' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'Tuesday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Tue', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Tue"
			@on-input-change="updateLabel( $event.target.value, 'Tue' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'Wednesday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Wed', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Wed"
			@on-input-change="updateLabel( $event.target.value, 'Wed' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'Thursday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Thu', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Thu"
			@on-input-change="updateLabel( $event.target.value, 'Thu' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'Friday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Fri', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Fri"
			@on-input-change="updateLabel( $event.target.value, 'Fri' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'Saturday', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: Sat', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.Sat"
			@on-input-change="updateLabel( $event.target.value, 'Sat' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'January', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: January', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.January"
			@on-input-change="updateLabel( $event.target.value, 'January' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'February', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: February', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.February"
			@on-input-change="updateLabel( $event.target.value, 'February' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'March', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: March', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.March"
			@on-input-change="updateLabel( $event.target.value, 'March' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'April', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: April', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.April"
			@on-input-change="updateLabel( $event.target.value, 'April' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'May', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: May', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.May"
			@on-input-change="updateLabel( $event.target.value, 'May' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'June', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: June', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.June"
			@on-input-change="updateLabel( $event.target.value, 'June' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'July', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: July', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.July"
			@on-input-change="updateLabel( $event.target.value, 'July' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'August', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: August', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.August"
			@on-input-change="updateLabel( $event.target.value, 'August' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'September', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: September', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.September"
			@on-input-change="updateLabel( $event.target.value, 'September' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'October', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: October', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.October"
			@on-input-change="updateLabel( $event.target.value, 'October' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'November', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: November', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.November"
			@on-input-change="updateLabel( $event.target.value, 'November' )"
		></cx-vui-input>
		<cx-vui-input
			label="<?php esc_html_e( 'December', 'madx-appointments-booking' ); ?>"
			description="<?php esc_html_e( 'By default: December', 'madx-appointments-booking' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			:size="'fullwidth'"
			:value="settings.custom_labels.December"
			@on-input-change="updateLabel( $event.target.value, 'December' )"
		></cx-vui-input>
	</template>
</div>
