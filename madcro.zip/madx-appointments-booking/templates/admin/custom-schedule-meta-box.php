<div id='madx-apb-custom-schedule-meta-box'>
	<cx-vui-switcher
		label="<?php esc_html_e( 'Use Custom Schedule', 'madx-appointments-booking' ); ?>"
		description="<?php esc_html_e( 'You can use a custom schedule for services or providers.', 'madx-appointments-booking' ); ?>"
		:wrapper-css="[ 'equalwidth' ]"
		:return-true="true"
		:return-false="false"
		v-model="settings.custom_schedule.use_custom_schedule"
		@input="updateSetting( $event, 'use_custom_schedule' )"
	></cx-vui-switcher>
	<madx-apb-working-hours-meta-box
		v-if="settings.custom_schedule.use_custom_schedule"
	></madx-apb-working-hours-meta-box>
</div>