<?php
/**
 * Popup trigger
 */
?>
<div class="madx-search__popup-trigger-container">
	<button type="button" class="madx-search__popup-trigger"><?php
		$this->__icon( 'search_popup_trigger_icon', '<span class="madx-search__popup-trigger-icon madx-blocks-icon">%s</span>' )
	?></button>
</div>