<?php
/**
 * Cart totals template
 */

$madxartwork    = madxartwork\Plugin::instance();
$is_edit_mode = $madxartwork->editor->is_edit_mode();

if ( ( $is_edit_mode && ! wp_doing_ajax() ) || null === WC()->cart ) {
	$totals = '';
} else {
	$totals = wp_kses_data( WC()->cart->get_cart_subtotal() );
}

?>
<span class="madx-blocks-cart__total-val"><?php
	echo $totals;
?></span>
