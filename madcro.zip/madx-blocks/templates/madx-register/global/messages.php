<?php
/**
 * Registration messages
 */

$message = wp_cache_get( 'madx-register-messages' );

if ( ! $message ) {
	return;
}

?>
<div class="madx-register-message"><?php
	echo $message;
?></div>