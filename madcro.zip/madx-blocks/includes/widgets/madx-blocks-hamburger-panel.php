<?php
/**
 * Class: madx_Blocks_Hamburger_Panel
 * Name: Hamburger Panel
 * Slug: madx-hamburger-panel
 */

namespace madxartwork;

use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Box_Shadow;
use madxartwork\Group_Control_Typography;
use madxartwork\Repeater;
use madxartwork\Core\Schemes\Color as Scheme_Color;
use madxartwork\Core\Schemes\Typography as Scheme_Typography;
use madxartwork\Widget_Base;
use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class madx_Blocks_Hamburger_Panel extends madx_Blocks_Base {

	public function get_name() {
		return 'madx-hamburger-panel';
	}

	public function get_title() {
		return esc_html__( 'Hamburger Panel', 'madx-blocks' );
	}

	public function get_icon() {
		return 'madx-blocks-icon-hamburger-panel';
	}

	public function get_madx_help_url() {
		return 'https://madxartwork.eu.org/knowledge-base/articles/madxblocks-how-to-display-any-template-within-a-hamburger-panel/';
	}

	public function get_categories() {
		return array( 'madx-blocks' );
	}

	protected function register_controls() {
		$css_scheme = apply_filters(
			'madx-blocks/hamburger-panel/css-scheme',
			array(
				'panel'    => '.madx-hamburger-panel',
				'instance' => '.madx-hamburger-panel__instance',
				'cover'    => '.madx-hamburger-panel__cover',
				'inner'    => '.madx-hamburger-panel__inner',
				'content'  => '.madx-hamburger-panel__content',
				'close'    => '.madx-hamburger-panel__close-button',
				'toggle'   => '.madx-hamburger-panel__toggle',
				'icon'     => '.madx-hamburger-panel__icon',
				'label'    => '.madx-hamburger-panel__toggle-label',
			)
		);

		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Content', 'madx-blocks' ),
			)
		);

		$this->__add_advanced_icon_control(
			'panel_toggle_icon',
			array(
				'label'       => esc_html__( 'Icon', 'madx-blocks' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => false,
				'skin'        => 'inline',
				'file'        => '',
				'default'     => 'fa fa-align-justify',
				'fa5_default' => array(
					'value'   => 'fas fa-align-justify',
					'library' => 'fa-solid',
				),
			)
		);

		$this->__add_advanced_icon_control(
			'panel_toggle_active_icon',
			array(
				'label'       => esc_html__( 'Active Icon', 'madx-blocks' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => false,
				'skin'        => 'inline',
				'file'        => '',
				'default'     => 'fa fa-close',
				'fa5_default' => array(
					'value'   => 'fas fa-times',
					'library' => 'fa-solid',
				),
			)
		);

		$this->__add_advanced_icon_control(
			'panel_close_icon',
			array(
				'label'       => esc_html__( 'Close Icon', 'madx-blocks' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => false,
				'skin'        => 'inline',
				'file'        => '',
				'default'     => 'fa fa-close',
				'fa5_default' => array(
					'value'   => 'fas fa-times',
					'library' => 'fa-solid',
				),
			)
		);

		$this->add_control(
			'panel_toggle_label',
			array(
				'label'   => esc_html__( 'Label', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'More', 'madx-blocks' ),
			)
		);

		$this->add_responsive_control(
			'panel_toggle_label_alignment',
			array(
				'label'   => esc_html__( 'Toggle Alignment', 'madx-blocks' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'flex-start' => array(
						'title' => esc_html__( 'Start', 'madx-blocks' ),
						'icon'  => ! is_rtl() ? 'eicon-h-align-left' : 'eicon-h-align-right',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'madx-blocks' ),
						'icon'  => 'eicon-h-align-center',
					),
					'flex-end' => array(
						'title' => esc_html__( 'End', 'madx-blocks' ),
						'icon'  => ! is_rtl() ? 'eicon-h-align-right' : 'eicon-h-align-left',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['panel'] => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'panel_template_id',
			array(
				'label'       => esc_html__( 'Choose Template', 'madx-blocks' ),
				'type'        => 'madx-query',
				'query_type'  => 'madxartwork_templates',
				'edit_button' => array(
					'active' => true,
					'label'  => __( 'Edit Template', 'madx-blocks' ),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_settings',
			array(
				'label' => esc_html__( 'Settings', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'position',
			array(
				'label'       => esc_html__( 'Position', 'madx-blocks' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'right',
				'options' => array(
					'right' => esc_html__( 'Right', 'madx-blocks' ),
					'left'  => esc_html__( 'Left', 'madx-blocks' ),
				),
			)
		);

		$this->add_control(
			'animation_effect',
			array(
				'label'       => esc_html__( 'Effect', 'madx-blocks' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'slide',
				'options' => array(
					'slide' => esc_html__( 'Slide', 'madx-blocks' ),
					'fade'  => esc_html__( 'Fade', 'madx-blocks' ),
					'zoom'  => esc_html__( 'Zoom', 'madx-blocks' ),
				),
			)
		);

		$this->add_control(
			'z_index',
			array(
				'label'   => esc_html__( 'Z-Index', 'madx-blocks' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100000,
				'step'    => 1,
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['instance'] => 'z-index: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'ajax_template',
			array(
				'label'        => esc_html__( 'Use Ajax Loading for Template', 'madx-blocks' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'madx-blocks' ),
				'label_off'    => esc_html__( 'Off', 'madx-blocks' ),
				'return_value' => 'yes',
				'default'      => 'false',
			)
		);

		$this->add_control(
			'ajax_template_cache',
			array(
				'label'        => esc_html__( 'Use Cache for Template', 'madx-blocks' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'On', 'madx-blocks' ),
				'label_off'    => esc_html__( 'Off', 'madx-blocks' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'ajax_template' => 'yes',
				)
			)
		);

		$this->end_controls_section();

		$this->__start_controls_section(
			'section_panel_style',
			array(
				'label'      => esc_html__( 'Panel', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->__add_responsive_control(
			'panel_width',
			array(
				'label'      => esc_html__( 'Panel Width', 'madx-blocks' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px', '%',
				),
				'range'      => array(
					'px' => array(
						'min' => 250,
						'max' => 800,
					),
					'%' => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['instance'] => 'width: {{SIZE}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_responsive_control(
			'panel_padding',
			array(
				'label'      => __( 'Padding', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['content'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'panel_background',
				'selector' => '{{WRAPPER}} ' . $css_scheme['inner'],
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'panel_border',
				'label'       => esc_html__( 'Border', 'madx-blocks' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['inner'],
			),
			75
		);

		$this->__add_control(
			'panel_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['inner'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			75
		);

		$this->__add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'panel_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['inner'],
			),
			75
		);

		$this->__add_control(
			'cover_style_heading',
			array(
				'label'     => esc_html__( 'Cover', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			),
			25
		);

		$this->__add_control(
			'cover_bg_color',
			array(
				'label' => esc_html__( 'Background color', 'madx-blocks' ),
				'type'  => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['cover'] => 'background-color: {{VALUE}};',
				),
			),
			25
		);

		$this->__add_control(
			'close_button_style_heading',
			array(
				'label'     => esc_html__( 'Close Button', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			),
			25
		);

		$this->__start_controls_tabs( 'close_button_styles' );

		$this->__start_controls_tab(
			'close_button_control',
			array(
				'label' => esc_html__( 'Normal', 'madx-blocks' ),
			)
		);

		$this->__add_group_control(
			\madx_Blocks_Group_Control_Box_Style::get_type(),
			array(
				'label'    => esc_html__( 'Close Icon', 'madx-blocks' ),
				'name'     => 'close_icon_box',
				'selector' => '{{WRAPPER}} ' . $css_scheme['close'],
			),
			25
		);

		$this->__end_controls_tab();

		$this->__start_controls_tab(
			'close_button_control_hover',
			array(
				'label' => esc_html__( 'Hover', 'madx-blocks' ),
			)
		);

		$this->__add_group_control(
			\madx_Blocks_Group_Control_Box_Style::get_type(),
			array(
				'label'    => esc_html__( 'Close Icon', 'madx-blocks' ),
				'name'     => 'close_icon_box_hover',
				'selector' => '{{WRAPPER}} ' . $css_scheme['close'] . ':hover',
			),
			25
		);

		$this->__end_controls_tab();

		$this->__end_controls_tabs();

		$this->__add_control(
			'content_loader_style_heading',
			array(
				'label'     => esc_html__( 'Loader Styles', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array(
					'ajax_template' => 'yes',
				)
			),
			25
		);

		$this->__add_control(
			'content_loader_color',
			array(
				'label' => esc_html__( 'Loader color', 'madx-blocks' ),
				'type'  => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['content'] . ' .madx-hamburger-panel-loader' => 'border-color: {{VALUE}}; border-top-color: white;',
				),
				'condition' => array(
					'ajax_template' => 'yes',
				)
			),
			25
		);

		$this->__end_controls_section();

		$this->__start_controls_section(
			'section_panel_toggle_style',
			array(
				'label'      => esc_html__( 'Toggle', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->__start_controls_tabs( 'toggle_styles' );

		$this->__start_controls_tab(
			'toggle_tab_normal',
			array(
				'label' => esc_html__( 'Normal', 'madx-blocks' ),
			)
		);

		$this->__add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'toggle_background',
				'fields_options' => array(
					'color' => array(
						'scheme' => array(
							'type'  => Scheme_Color::get_type(),
							'value' => Scheme_Color::COLOR_1,
						),
					),
				),
				'selector' => '{{WRAPPER}} ' . $css_scheme['toggle'],
			),
			25
		);

		$this->__end_controls_tab();

		$this->__start_controls_tab(
			'toggle_tab_hover',
			array(
				'label' => esc_html__( 'Hover', 'madx-blocks' ),
			)
		);

		$this->__add_group_control(
			Group_Control_Background::get_type(),
			array(
				'name'     => 'toggle_background_hover',
				'fields_options' => array(
					'color' => array(
						'scheme' => array(
							'type'  => Scheme_Color::get_type(),
							'value' => Scheme_Color::COLOR_1,
						),
					),
				),
				'selector' => '{{WRAPPER}} ' . $css_scheme['toggle'] . ':hover',
			),
			25
		);

		$this->__end_controls_tab();

		$this->__end_controls_tabs();

		$this->__add_responsive_control(
			'toggle_padding',
			array(
				'label'      => esc_html__( 'Padding', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['toggle'] => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator'  => 'before',
			),
			25
		);

		$this->__add_responsive_control(
			'toggle_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['toggle'] => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'        => 'toggle_border',
				'label'       => esc_html__( 'Border', 'madx-blocks' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} ' . $css_scheme['toggle'],
			),
			75
		);

		$this->__add_control(
			'toggle_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} ' . $css_scheme['toggle'] => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			75
		);

		$this->__add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'toggle_shadow',
				'selector' => '{{WRAPPER}} ' . $css_scheme['toggle'],
			),
			100
		);

		$this->__add_control(
			'toggle_icon_style_heading',
			array(
				'label'     => esc_html__( 'Icon Styles', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			),
			25
		);

		$this->__start_controls_tabs( 'toggle_icon_styles' );

		$this->__start_controls_tab(
			'toggle_icon_normal',
			array(
				'label' => esc_html__( 'Normal', 'madx-blocks' ),
			)
		);

		$this->__add_group_control(
			\madx_Blocks_Group_Control_Box_Style::get_type(),
			array(
				'label'    => esc_html__( 'Toggle Icon', 'madx-blocks' ),
				'name'     => 'toggle_icon_box',
				'selector' => '{{WRAPPER}} ' . $css_scheme['icon'],
			),
			25
		);

		$this->__end_controls_tab();

		$this->__start_controls_tab(
			'toggle_icon_hover',
			array(
				'label' => esc_html__( 'Hover', 'madx-blocks' ),
			)
		);

		$this->__add_group_control(
			\madx_Blocks_Group_Control_Box_Style::get_type(),
			array(
				'label'    => esc_html__( 'Toggle Icon', 'madx-blocks' ),
				'name'     => 'toggle_icon_box_hover',
				'selector' => '{{WRAPPER}} ' . $css_scheme['toggle'] . ':hover ' . $css_scheme['icon'],
			),
			25
		);

		$this->__end_controls_tab();

		$this->__end_controls_tabs();

		$this->__add_control(
			'toggle_label_style_heading',
			array(
				'label'     => esc_html__( 'Label Styles', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			),
			25
		);

		$this->__start_controls_tabs( 'toggle_label_styles' );

		$this->__start_controls_tab(
			'toggle_label_normal',
			array(
				'label' => esc_html__( 'Normal', 'madx-blocks' ),
			)
		);

		$this->__add_control(
			'toggle_control_label_color',
			array(
				'label'     => esc_html__( 'Label Color', 'madx-blocks' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['label'] => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'toggle_label_typography',
				'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} '. $css_scheme['label'],
			),
			50
		);

		$this->__end_controls_tab();

		$this->__start_controls_tab(
			'toggle_label_hover',
			array(
				'label' => esc_html__( 'Hover', 'madx-blocks' ),
			)
		);

		$this->__add_control(
			'toggle_control_label_color_hover',
			array(
				'label'     => esc_html__( 'Label Color', 'madx-blocks' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} ' . $css_scheme['toggle'] . ':hover ' . $css_scheme['label'] => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'toggle_label_typography_hover',
				'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ' . $css_scheme['toggle'] . ':hover ' . $css_scheme['label'],
			),
			50
		);

		$this->__end_controls_tab();

		$this->__end_controls_tabs();

		$this->__end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

		$panel_settings = $this->get_settings();

		$template_id          = isset( $panel_settings['panel_template_id'] ) ? $panel_settings['panel_template_id'] : '0';
		$position             = isset( $panel_settings['position'] ) ? $panel_settings['position'] : 'right';
		$animation_effect     = isset( $panel_settings['animation_effect'] ) ? $panel_settings['animation_effect'] : 'slide';
		$ajax_template        = isset( $panel_settings['ajax_template'] ) ? filter_var( $panel_settings['ajax_template'], FILTER_VALIDATE_BOOLEAN ) : false;
		$ajax_template_cache  = isset( $panel_settings['ajax_template_cache'] ) ? filter_var( $panel_settings['ajax_template_cache'], FILTER_VALIDATE_BOOLEAN ) : false;

		$settings = array(
			'position'          => $position,
			'ajaxTemplate'      => $ajax_template,
			'ajaxTemplateCache' => $ajax_template_cache,
		);

		if ( true === $ajax_template && true != $ajax_template_cache ) {
			add_filter( 'madx-blocks/rest/endpoint/madxartwork-template/cached', array( $this, 'disable_template_cache' ) );
		}

		$this->add_render_attribute( 'instance', array(
			'class' => array(
				'madx-hamburger-panel',
				'madx-hamburger-panel-' . $position . '-position',
				'madx-hamburger-panel-' . $animation_effect . '-effect',
			),
			'data-settings' => json_encode( $settings ),
		) );

		$close_button_html = $this->__get_icon( 'panel_close_icon', '<div class="madx-hamburger-panel__close-button madx-blocks-icon">%s</div>' );

		$toggle_control_html = '';

		$toggle_icon        = $this->__get_icon( 'panel_toggle_icon', '<span class="madx-hamburger-panel__icon icon-normal madx-blocks-icon">%s</span>' );
		$toggle_active_icon = $this->__get_icon( 'panel_toggle_active_icon', '<span class="madx-hamburger-panel__icon icon-active madx-blocks-icon">%s</span>' );

		if ( ! empty( $toggle_icon ) && ! empty( $toggle_active_icon ) ) {
			$toggle_control_html .= sprintf( '<div class="madx-hamburger-panel__toggle-icon">%1$s%2$s</div>', $toggle_icon, $toggle_active_icon );
		}

		$toggle_label_html = '';

		if ( ! empty( $panel_settings['panel_toggle_label'] ) ) {
			$toggle_label_html .= sprintf( '<div class="madx-hamburger-panel__toggle-label"><span>%1$s</span></div>', $panel_settings['panel_toggle_label'] );
		}

		$toggle_html = sprintf( '<div class="madx-hamburger-panel__toggle" role="button" tabindex="0">%1$s%2$s</div>', $toggle_control_html, $toggle_label_html );

		?>
		<div <?php echo $this->get_render_attribute_string( 'instance' ); ?>>
			<?php echo $toggle_html; ?>
			<div class="madx-hamburger-panel__instance">
				<div class="madx-hamburger-panel__cover"></div>
				<div class="madx-hamburger-panel__inner">
					<?php
						echo $close_button_html;

						if ( ! empty( $template_id ) ) {
							$link = add_query_arg(
								array(
									'madxartwork' => '',
								),
								get_permalink( $template_id )
							);

							if ( madx_blocks_integration()->in_madxartwork() ) {
								echo sprintf( '<div class="madx-blocks__edit-cover" data-template-edit-link="%s"><i class="eicon-edit"></i><span>%s</span></div>', $link, esc_html__( 'Edit Template', 'madx-blocks' ) );
							}
						}

						$this->add_render_attribute( 'madx-hamburger-panel__content', array(
							'class'            => 'madx-hamburger-panel__content',
							'data-template-id' => ! empty( $template_id ) ? $template_id : 'false',
						) );

						$content_html = '';

						if ( ! empty( $template_id ) && ! $ajax_template ) {
							$content_html .= madx_blocks()->madxartwork()->frontend->get_builder_content_for_display( $template_id );
						} else if ( ! $ajax_template ) {
							$content_html = $this->no_templates_message();
						} else {
							$content_html .= '<div class="madx-hamburger-panel-loader"></div>';
						}

						echo sprintf( '<div %1$s>%2$s</div>', $this->get_render_attribute_string( 'madx-hamburger-panel__content' ), $content_html );
					?>
				</div>
			</div>
		</div>
		<?php
	}

	public function disable_template_cache() {
		return false;
	}

	/**
	 * Empty templates message description
	 *
	 * @return string
	 */
	public function empty_templates_message() {
		return '<div id="madxartwork-widget-template-empty-templates">
				<div class="madxartwork-widget-template-empty-templates-icon"><i class="eicon-nerd"></i></div>
				<div class="madxartwork-widget-template-empty-templates-title">' . esc_html__( 'You Haven’t Saved Templates Yet.', 'madx-blocks' ) . '</div>
				<div class="madxartwork-widget-template-empty-templates-footer">' . esc_html__( 'What is Library?', 'madx-blocks' ) . ' <a class="madxartwork-widget-template-empty-templates-footer-url" href="https://go.madxartwork.com/docs-library/" target="_blank">' . esc_html__( 'Read our tutorial on using Library templates.', 'madx-blocks' ) . '</a></div>
				</div>';
	}

	/**
	 * No templates message
	 *
	 * @return string
	 */
	public function no_templates_message() {
		$message = '<span>' . esc_html__( 'Template is not defined. ', 'madx-blocks' ) . '</span>';

		$url = add_query_arg(
			array(
				'post_type'     => 'madxartwork_library',
				'action'        => 'madxartwork_new_post',
				'_wpnonce'      => wp_create_nonce( 'madxartwork_action_new_post' ),
				'template_type' => 'section',
			),
			esc_url( admin_url( '/edit.php' ) )
		);

		$new_link = '<span>' . esc_html__( 'Select an existing template or create a ', 'madx-blocks' ) . '</span><a class="madx-blocks-new-template-link madxartwork-clickable" href="' . $url . '" target="_blank">' . esc_html__( 'new one', 'madx-blocks' ) . '</a>' ;

		return sprintf(
			'<div class="madx-blocks-no-template-message">%1$s%2$s</div>',
			$message,
			madx_blocks_integration()->in_madxartwork() ? $new_link : ''
		);
	}

}


