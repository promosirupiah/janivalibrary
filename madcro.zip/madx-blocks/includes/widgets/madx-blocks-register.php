<?php
/**
 * Class: madx_Blocks_Register
 * Name: Registration Form
 * Slug: madx-register
 */

namespace madxartwork;

use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Border;
use madxartwork\Group_Control_Box_Shadow;
use madxartwork\Group_Control_Typography;
use madxartwork\Repeater;
use madxartwork\Core\Schemes\Color as Scheme_Color;
use madxartwork\Core\Schemes\Typography as Scheme_Typography;
use madxartwork\Widget_Base;
use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class madx_Blocks_Register extends madx_Blocks_Base {

	public function get_name() {
		return 'madx-register';
	}

	public function get_title() {
		return esc_html__( 'Registration Form', 'madx-blocks' );
	}

	public function get_icon() {
		return 'madx-blocks-icon-register';
	}

	public function get_madx_help_url() {
		return 'https://madxartwork.eu.org/knowledge-base/articles/how-to-add-a-registration-form-to-the-website-captcha-integration/';
	}

	public function get_categories() {
		return array( 'madx-blocks' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Content', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'label_username',
			array(
				'label'   => esc_html__( 'Username Label', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Username', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'placeholder_username',
			array(
				'label'   => esc_html__( 'Username Placeholder', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Username', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'label_email',
			array(
				'label'   => esc_html__( 'Email Label', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Email', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'placeholder_email',
			array(
				'label'   => esc_html__( 'Email Placeholder', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Email', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'label_pass',
			array(
				'label'   => esc_html__( 'Password Label', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Password', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'placeholder_pass',
			array(
				'label'   => esc_html__( 'Password Placeholder', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Password', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'confirm_password',
			array(
				'label'        => esc_html__( 'Show Confirm Password Field', 'madx-blocks' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'madx-blocks' ),
				'label_off'    => esc_html__( 'No', 'madx-blocks' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'label_pass_confirm',
			array(
				'label'     => esc_html__( 'Confirm Password Label', 'madx-blocks' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Please Confirm Password', 'madx-blocks' ),
				'condition' => array(
					'confirm_password' => 'yes'
				)
			)
		);

		$this->add_control(
			'placeholder_pass_confirm',
			array(
				'label'     => esc_html__( 'Confirm Password Placeholder', 'madx-blocks' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Confirm Password', 'madx-blocks' ),
				'condition' => array(
					'confirm_password' => 'yes'
				)
			)
		);

		$this->add_control(
			'label_submit',
			array(
				'label'   => esc_html__( 'Register Button Label', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Register', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'register_redirect',
			array(
				'type'       => 'select',
				'label'      => esc_html__( 'Redirect After Register', 'madx-blocks' ),
				'default'    => 'home',
				'options'    => array(
					'home'   => esc_html__( 'Home page', 'madx-blocks' ),
					'left'   => esc_html__( 'Stay on the current page', 'madx-blocks' ),
					'custom' => esc_html__( 'Custom URL', 'madx-blocks' ),
				),
			)
		);

		$this->add_control(
			'register_redirect_url',
			array(
				'label'     => esc_html__( 'Redirect URL', 'madx-blocks' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array(
					'register_redirect' => 'custom',
				),
			)
		);

		$this->add_control(
			'label_registered',
			array(
				'label'   => esc_html__( 'User Registered Message', 'madx-blocks' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'You already registered', 'madx-blocks' ),
			)
		);

		$this->add_control(
			'privacy_policy',
			array(
				'label'        => esc_html__( 'Show Privacy Policy Checkbox', 'madx-blocks' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'madx-blocks' ),
				'label_off'    => esc_html__( 'No', 'madx-blocks' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'privacy_policy_content',
			array(
				'label'     => 'Privacy Policy content',
				'type'      => Controls_Manager::TEXTAREA,
				'dynamic'   => array(
					'active' => true,
				),
				'default'   => esc_html__( 'I agree with the terms and conditions and the privacy policy', 'madx-blocks' ),
				'condition' => array(
					'privacy_policy' => 'yes',
				),
			)
		);

		$this->add_control(
			'use_password_requirements',
			array(
				'label'        => 'Use Strong Password Validation',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'madx-blocks' ),
				'label_off'    => esc_html__( 'No', 'madx-blocks' ),
				'return_value' => 'yes',
				'default'      => '',
				'separator'    => 'before',
			)
		);

		$this->add_control(
			'password_requirements',
			array(
				'label'       => esc_html__( 'Password Requirements', 'madx-blocks' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT2,
				'default'     => array( 'length', 'lowercase', 'uppercase', 'number', 'special' ),
				'multiple'    => true,
				'options'     => array(
					'length'    => esc_html__( 'Length', 'madx-blocks' ),
					'lowercase' => esc_html__( 'Lowercase', 'madx-blocks' ),
					'uppercase' => esc_html__( 'Uppercase', 'madx-blocks' ),
					'number'    => esc_html__( 'Number', 'madx-blocks' ),
					'special'   => esc_html__( 'Special character', 'madx-blocks' ),
				),
				'condition' => array(
					'use_password_requirements' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->__start_controls_section(
			'register_fields_style',
			array(
				'label'      => esc_html__( 'Fields', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->__add_control(
			'input_bg_color',
			array(
				'label'  => esc_html__( 'Background Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__input' => 'background-color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_control(
			'input_color',
			array(
				'label'  => esc_html__( 'Text Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__input' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'input_typography',
				'selector' => '{{WRAPPER}} .madx-register__input',
			),
			50
		);

		$this->__add_control(
			'placeholder_style',
			array(
				'label'     => esc_html__( 'Placeholder', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			),
			25
		);

		$this->__add_control(
			'input_placeholder_color',
			array(
				'label'  => esc_html__( 'Placeholder Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__input::-webkit-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .madx-register__input::-moz-placeholder'          => 'color: {{VALUE}}',
					'{{WRAPPER}} .madx-register__input:-ms-input-placeholder'      => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'input_placeholder_typography',
				'selector' => '{{WRAPPER}} .madx-register__input::-webkit-input-placeholder',
			),
			50
		);

		$this->__add_responsive_control(
			'input_padding',
			array(
				'label'      => esc_html__( 'Padding', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'separator'  => 'before',
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_responsive_control(
			'input_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'input_border',
				'label'          => esc_html__( 'Border', 'madx-blocks' ),
				'placeholder'    => '1px',
				'selector'       => '{{WRAPPER}} .madx-register__input',
			),
			50
		);

		$this->__add_responsive_control(
			'input_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			50
		);

		$this->__add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'input_box_shadow',
				'selector' => '{{WRAPPER}} .madx-register__input',
			),
			100
		);

		$this->__end_controls_section();

		$this->__start_controls_section(
			'register_labels_style',
			array(
				'label'      => esc_html__( 'Labels', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->__add_control(
			'labels_bg_color',
			array(
				'label'  => esc_html__( 'Background Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__label' => 'background-color: {{VALUE}}',
				),
			),
			50
		);

		$this->__add_control(
			'labels_color',
			array(
				'label'  => esc_html__( 'Text Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__label' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'labels_typography',
				'selector' => '{{WRAPPER}} .madx-register__label',
			),
			50
		);

		$this->__add_responsive_control(
			'labels_padding',
			array(
				'label'      => esc_html__( 'Padding', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			50
		);

		$this->__add_responsive_control(
			'labels_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'labels_border',
				'label'          => esc_html__( 'Border', 'madx-blocks' ),
				'placeholder'    => '1px',
				'selector'       => '{{WRAPPER}} .madx-register__label',
			),
			75
		);

		$this->__add_responsive_control(
			'labels_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			75
		);

		$this->__add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'labels_box_shadow',
				'selector' => '{{WRAPPER}} .madx-register__label',
			),
			100
		);

		$this->__end_controls_section();

		$this->__start_controls_section(
			'register_submit_style',
			array(
				'label'      => esc_html__( 'Submit', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->__start_controls_tabs( 'tabs_form_submit_style' );

		$this->__start_controls_tab(
			'register_form_submit_normal',
			array(
				'label' => esc_html__( 'Normal', 'madx-blocks' ),
			)
		);

		$this->__add_control(
			'register_submit_bg_color',
			array(
				'label'  => esc_html__( 'Background Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__submit' => 'background-color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_control(
			'register_submit_color',
			array(
				'label'  => esc_html__( 'Text Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__submit' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__end_controls_tab();

		$this->__start_controls_tab(
			'register_form_submit_hover',
			array(
				'label' => esc_html__( 'Hover', 'madx-blocks' ),
			)
		);

		$this->__add_control(
			'register_submit_bg_color_hover',
			array(
				'label'  => esc_html__( 'Background Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__submit:hover' => 'background-color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_control(
			'register_submit_color_hover',
			array(
				'label'  => esc_html__( 'Text Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register__submit:hover' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_control(
			'register_submit_hover_border_color',
			array(
				'label' => esc_html__( 'Border Color', 'madx-blocks' ),
				'type' => Controls_Manager::COLOR,
				'condition' => array(
					'register_submit_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .madx-register__submit:hover' => 'border-color: {{VALUE}};',
				),
			),
			75
		);

		$this->__end_controls_tab();

		$this->__end_controls_tabs();

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'register_submit_typography',
				'selector' => '{{WRAPPER}} .madx-register__submit',
				'fields_options' => array(
					'typography' => array(
						'separator' => 'before',
					),
				),
			),
			50
		);

		$this->__add_responsive_control(
			'register_submit_padding',
			array(
				'label'      => esc_html__( 'Padding', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'separator' => 'before',
			),
			25
		);

		$this->__add_responsive_control(
			'register_submit_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__submit' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'register_submit_border',
				'label'          => esc_html__( 'Border', 'madx-blocks' ),
				'placeholder'    => '1px',
				'selector'       => '{{WRAPPER}} .madx-register__submit',
			),
			75
		);

		$this->__add_responsive_control(
			'register_submit_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register__submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			75
		);

		$this->__add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'register_submit_box_shadow',
				'selector' => '{{WRAPPER}} .madx-register__submit',
			),
			100
		);

		$this->__add_responsive_control(
			'register_submit_alignment',
			array(
				'label'   => esc_html__( 'Alignment', 'madx-blocks' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'left',
				'options' => array(
					'left'    => array(
						'title' => esc_html__( 'Left', 'madx-blocks' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'madx-blocks' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'madx-blocks' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register-submit' => 'text-align: {{VALUE}};',
				),
				'classes' => 'madx-blocks-text-align-control',
			),
			50
		);

		$this->__end_controls_section();

		$this->__start_controls_section(
			'privacy_policy_style',
			array(
				'label'      => esc_html__( 'Privacy Policy', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
				'condition'  => array(
					'privacy_policy' => 'yes'
				),
			)
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'privacy_typography',
				'selector' => '{{WRAPPER}} .madx-privacy-policy .madx-register__label',
			),
			50
		);

		$this->__add_responsive_control(
			'privacy_checkbox_gap',
			array(
				'label' => esc_html__( 'Gap', 'madx-blocks' ),
				'type' => Controls_Manager::SLIDER,
				'default' => array(
					'size' => 5,
				),
				'selectors' => array(
					'{{WRAPPER}} .madx-privacy-policy .madx-register__input' => ! is_rtl() ? 'margin-right: {{SIZE}}{{UNIT}}' : 'margin-left: {{SIZE}}{{UNIT}}',
				),
			)
		);

		$this->__end_controls_section();

		$this->__start_controls_section(
			'login_errors_style',
			array(
				'label'      => esc_html__( 'Errors', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);

		$this->__add_control(
			'errors_bg_color',
			array(
				'label'  => esc_html__( 'Background Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register-message' => 'background-color: {{VALUE}}',
				),
			),
			50
		);

		$this->__add_control(
			'errors_color',
			array(
				'label'  => esc_html__( 'Text Color', 'madx-blocks' ),
				'type'   => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-register-message' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_responsive_control(
			'errors_padding',
			array(
				'label'      => esc_html__( 'Padding', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			50
		);

		$this->__add_responsive_control(
			'errors_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register-message' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'           => 'errors_border',
				'label'          => esc_html__( 'Border', 'madx-blocks' ),
				'placeholder'    => '1px',
				'selector'       => '{{WRAPPER}} .madx-register-message',
			),
			75
		);

		$this->__add_responsive_control(
			'errors_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register-message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			75
		);

		$this->__add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'errors_box_shadow',
				'selector' => '{{WRAPPER}} .madx-register-message',
			),
			100
		);

		$this->__end_controls_section();

		$this->__start_controls_section(
			'password_requirements_style',
			array(
				'label'      => esc_html__( 'Password Requirements', 'madx-blocks' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
				'condition' => array(
					'use_password_requirements' => 'yes'
				),
			)
		);

		$this->__add_control(
			'password_requirem_wrapper',
			array(
				'label'     => esc_html__( 'Container', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
			),
			25
		);

		$this->__add_responsive_control(
			'password_requirements_wrapper_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-register-password-requirements' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__add_control(
			'password_requirements_title',
			array(
				'label'     => esc_html__( 'Title', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
			),
			25
		);

		$this->__add_control(
			'password_requirements_title_color',
			array(
				'label'     => esc_html__( 'Color', 'madx-blocks' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-password-requirements__title' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'password_requirements_title',
				'selector' => '{{WRAPPER}} .madx-password-requirements__title',
			),
			50
		);

		$this->__add_control(
			'password_requirements_items',
			array(
				'label'     => esc_html__( 'Items', 'madx-blocks' ),
				'type'      => Controls_Manager::HEADING,
			),
			25
		);

		$this->__add_control(
			'password_requirements_items_color',
			array(
				'label'     => esc_html__( 'Color', 'madx-blocks' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .madx-password-requirements li' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_control(
			'password_requirements_items_success_color',
			array(
				'label'     => esc_html__( 'Success Color', 'madx-blocks' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00d30b',
				'selectors' => array(
					'{{WRAPPER}} .madx-password-requirements li.success' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_control(
			'password_requirements_error_color',
			array(
				'label'     => esc_html__( 'Error Color', 'madx-blocks' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'red',
				'selectors' => array(
					'{{WRAPPER}} .madx-password-requirements li.error' => 'color: {{VALUE}}',
				),
			),
			25
		);

		$this->__add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'password_requirements_items_typography',
				'selector' => '{{WRAPPER}} .madx-password-requirements li',
			),
			50
		);

		$this->__add_responsive_control(
			'password_requirements_items_margin',
			array(
				'label'      => esc_html__( 'Margin', 'madx-blocks' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .madx-password-requirements li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			),
			25
		);

		$this->__end_controls_section();

	}

	protected function render() {

		$this->__context = 'render';

		$settings = $this->get_settings();

		if ( is_user_logged_in() && ! madx_blocks_integration()->in_madxartwork() ) {

			$this->__open_wrap();
			echo $settings['label_registered'];
			$this->__close_wrap();

			return;
		}

		$registration_enabled = get_option( 'users_can_register' );

		if ( ! $registration_enabled && ! madx_blocks_integration()->in_madxartwork() ) {

			$this->__open_wrap();
			esc_html_e( 'Registration disabled', 'madx-blocks' );
			$this->__close_wrap();

			return;
		}

		$this->__open_wrap();

		$redirect_url = site_url( $_SERVER['REQUEST_URI'] );

		switch ( $settings['register_redirect'] ) {

			case 'home':
				$redirect_url = esc_url( home_url( '/' ) );
				break;

			case 'custom':
				$redirect_url = $settings['register_redirect_url'];
				break;
		}

		if ( ! $registration_enabled ) {
			esc_html_e( 'Registration currently disabled and this form will not be visible for guest users. Please, enable registration in Settings/General or remove this widget from the page.', 'madx-blocks' );
		}

		include $this->__get_global_template( 'index' );

		$this->__close_wrap();
	}

}
