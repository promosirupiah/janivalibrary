<?php
namespace madx_Dashboard\Compatibility\Theme;

use madx_Dashboard\Compatibility\Base_Theme as Base_Theme;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Hello extends Base_Theme {

	/**
	 * Returns module slug
	 *
	 * @return void
	 */
	public function get_slug() {
		return 'hellomadxartwork';
	}

	/**
	 * [theme_info_data description]
	 * @param  array  $theme_data [description]
	 * @return [type]             [description]
	 */
	public function theme_info_data( $theme_data = array() ) {
		return $theme_data;
	}
}
