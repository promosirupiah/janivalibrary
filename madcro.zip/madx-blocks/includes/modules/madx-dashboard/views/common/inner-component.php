<div
	class="madx-dashboard-page__inner-component"
	v-if="visible"
>
	<div class="madx-dashboard-page__banners">
		<madx-dashboard-banner
			v-for="( banner, index ) in bannersList"
			:key="index"
			:config="banner"
		></madx-dashboard-banner>
	</div>
</div>
