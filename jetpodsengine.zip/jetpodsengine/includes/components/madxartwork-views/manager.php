<?php
/**
 * madxartwork views manager
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_madxartwork_Views' ) ) {

	/**
	 * Define Jet_Engine_madxartwork_Views class
	 */
	class Jet_Engine_madxartwork_Views {

		/**
		 * madxartwork Frontend instance
		 *
		 * @var null
		 */
		public $frontend = null;

		/**
		 * Constructor for the class
		 */
		function __construct() {

			if ( ! jet_engine()->has_madxartwork() ) {
				return;
			}

			if ( ! jet_engine()->components->is_component_active( 'listings' ) ) {
				return;
			}

			add_filter( 'jet-engine/templates/listing-views', array( $this, 'add_madxartwork_listing_view' ) );

			add_filter( 'jet-engine/templates/create/data', array( $this, 'inject_listing_settings' ) );

			add_action( 'madxartwork/documents/register', array( $this, 'register_document_type' ) );

			add_action( 'madxartwork/elements/categories_registered', array( $this, 'register_category' ) );

			if ( defined( 'madxartwork_VERSION' ) && version_compare( madxartwork_VERSION, '3.5.0', '>=' ) ) {
				add_action( 'madxartwork/widgets/register', array( $this, 'register_widgets' ), 10 );
			} else {
				add_action( 'madxartwork/widgets/widgets_registered', array( $this, 'register_widgets' ), 10 );
			}

			add_filter( 'body_class', array( $this, 'add_body_classes' ) );

			add_action( 'madxartwork/dynamic_tags/before_render', array( $this, 'switch_to_preview_query' ) );
			add_action( 'madxartwork/dynamic_tags/after_render', array( $this, 'restore_current_query' ) );

			add_action( 'madxartwork/editor/after_enqueue_styles', array( $this, 'enqueue_icons_styles' ) );
			add_action( 'madxartwork/preview/enqueue_styles',      array( $this, 'enqueue_icons_styles' ) );

			add_action( 'madxartwork/editor/before_enqueue_scripts', array( $this, 'set_editor_listing' ) );

			add_action( 'current_screen', array( $this, 'no_madxartwork_notice' ) );

			require jet_engine()->plugin_path( 'includes/components/madxartwork-views/dynamic-tags/manager.php' );
			require jet_engine()->plugin_path( 'includes/components/madxartwork-views/frontend.php' );

			jet_engine()->dynamic_tags = new Jet_Engine_Dynamic_Tags_Manager();
			$this->frontend            = new Jet_Engine_madxartwork_Frontend();

			// Fix listing while widgets config set up
			add_action( 'madxartwork/ajax/register_actions', array( $this, 'set_listing_on_ajax' ), -1 );

			// Init Jet madxartwork Extension module
			$ext_module_data = jet_engine()->framework->get_included_module_data( 'jet-madxartwork-extension.php' );

			Jet_madxartwork_Extension\Module::get_instance(
				array(
					'path' => $ext_module_data['path'],
					'url'  => $ext_module_data['url'],
				)
			);


			add_filter( 'jet-engine/listings/dynamic-image/size', array( $this, 'prepare_custom_image_size' ), 10, 3 );
			add_filter( 'jet-engine/listings/dynamic-image/link-attr', array( $this, 'add_lightbox_attr' ), 10, 2 );

		}

		/**
		 * Setup current listing for editor
		 */
		public function set_editor_listing() {

			$post_id = \madxartwork\Plugin::instance()->editor->get_post_id();
			$this->setup_listing_doc( $post_id );

			jet_engine()->listings->post_type->listing_form_assets( true, array(
				'isAjax'   => true,
				'exclude'  => array( 'listing_view_type' ),
				'button'   => array(
					'css_class' => 'madxartwork-button madxartwork-button-default madxartwork-button-success',
				),
				'defaults' => array(
					'listing_view_type' => 'madxartwork',
				)
			) );

		}

		/**
		 * Setup default main listing document
		 *
		 * @param  [type] $post_id [description]
		 * @return [type]          [description]
		 */
		public function setup_listing_doc( $post_id ) {

			$settings = get_post_meta( $post_id, '_madxartwork_page_settings', true );

			if ( empty( $settings ) || ! isset( $settings['listing_source'] ) ) {

				$post_type = get_post_type( $post_id );

				if ( jet_engine()->post_type->slug() !== $post_type ) {
					jet_engine()->listings->data->set_listing( jet_engine()->listings->get_new_doc( array(
						'listing_source'    => 'posts',
						'listing_post_type' => $post_type,
						'listing_tax'       => false,
						'is_main'           => true,
					), $post_id ) );
				}

			} else {
				$source = ! empty( $settings['listing_source'] ) ? esc_attr( $settings['listing_source'] ) : 'posts';
				$post_type = ! empty( $settings['listing_post_type'] ) ? esc_attr( $settings['listing_post_type'] ) : get_post_type( $post_id );
				$tax = ! empty( $settings['listing_tax'] ) ? esc_attr( $settings['listing_tax'] ) : '';

				jet_engine()->listings->data->set_listing( jet_engine()->listings->get_new_doc( array(
					'listing_source'    => $source,
					'listing_post_type' => $post_type,
					'listing_tax'       => $tax,
					'repeater_source'   => ! empty( $settings['repeater_source'] ) ? $settings['repeater_source'] : '',
					'repeater_field'    => ! empty( $settings['repeater_field'] ) ? $settings['repeater_field'] : '',
					'repeater_option'   => ! empty( $settings['repeater_option'] ) ? $settings['repeater_option'] : '',
					'is_main'           => true,
				), $post_id ) );
			}



		}

		/**
		 * Set listing on ajax widgets cnfig updating
		 */
		public function set_listing_on_ajax( $ajax_manager ) {

			if ( empty( $_REQUEST['actions'] ) ) {
				return;
			}

			if ( false === strpos( $_REQUEST['actions'], 'get_widgets_config' ) ) {
				return;
			}

			if ( empty( $_REQUEST['editor_post_id'] ) ) {
				return;
			}

			$post_id = $_REQUEST['editor_post_id'];

			$this->setup_listing_doc( $post_id );
		}

		/**
		 * Add notice on listings page if madxartwork not installed
		 *
		 * @return void
		 */
		public function no_madxartwork_notice() {

			if ( jet_engine()->has_madxartwork() ) {
				return;
			}

			$screen = get_current_screen();

			if ( $screen->id !== 'edit-' . jet_engine()->post_type->slug() ) {
				return;
			}

			add_action( 'admin_notices', array( $this, 'no_madxartwork_warning' ) );

		}

		/**
		 * Print no madxartwork notice
		 *
		 * @return [type] [description]
		 */
		public function no_madxartwork_warning() {

			$install_url = add_query_arg(
				array(
					's'    => 'madxartwork',
					'tab'  => 'search',
					'type' => 'term',
				),
				admin_url( 'plugin-install.php' )
			);

			?>
			<div class="notice notice-warning">
				<p><?php
					_e( 'You need an <b>madxartwork Page Builder</b> plugin to create and edit listing items', 'jet-engine' );
				?></p>
				<p>
					<a href="<?php echo $install_url; ?>">
						<b><?php _e( 'Install madxartwork Page Builder', 'jet-engine' ); ?></b>
					</a>
				</p>
			</div>
			<?php
		}

		/**
		 * Enqueue icons styles
		 *
		 * @return void
		 */
		public function enqueue_icons_styles() {

			wp_enqueue_style(
				'jet-engine-icons',
				jet_engine()->plugin_url( 'assets/lib/jetengine-icons/icons.css' ),
				array(),
				jet_engine()->get_version()
			);

		}

		/**
		 * Switch to specific preview query
		 *
		 * @return void
		 */
		public function switch_to_preview_query() {

			$current_post_id = get_the_ID();

			if ( jet_engine()->post_type->slug() !== get_post_type( $current_post_id ) ) {
				return;
			}

			$document = madxartwork\Plugin::instance()->documents->get_doc_or_auto_save( $current_post_id );

			if ( ! is_object( $document ) || ! method_exists( $document, 'get_preview_as_query_args' ) ) {
				return;
			}

			$new_query_vars = $document->get_preview_as_query_args();

			if ( empty( $new_query_vars ) ) {
				return;
			}

			madxartwork\Plugin::instance()->db->switch_to_query( $new_query_vars );

		}

		/**
		 * Restore default query
		 *
		 * @return void
		 */
		public function restore_current_query() {
			madxartwork\Plugin::instance()->db->restore_current_query();
		}

		/**
		 * Add body classes
		 */
		public function add_body_classes( $classes ) {

			$template_type = get_post_meta( get_the_ID(), '_madxartwork_template_type', true );

			if ( 'jet-listing-items' === $template_type ) {
				$classes[] = 'jet-listing-item';
			}

			return $classes;
		}

		/**
		 * Register cherry category for madxartwork if not exists
		 *
		 * @return void
		 */
		public function register_category( $elements_manager ) {
			$elements_manager->add_category(
				'jet-listing-elements',
				array(
					'title' => esc_html__( 'Listing Elements', 'jet-engine' ),
					'icon'  => 'font',
				)
			);
		}

		public function include_base_widget() {
		
			if ( ! class_exists( '\Jet_madxartwork_Widgets_Storage' ) ) {
				require jet_engine()->plugin_path( 'includes/components/madxartwork-views/widgets-storage.php' );
			}

			if ( ! class_exists( '\Jet_Listing_Dynamic_Widget' ) ) {
				require jet_engine()->plugin_path( 'includes/components/madxartwork-views/dynamic-widgets/dynamic-widget.php' );
			}
			
		}

		/**
		 * Register listing widgets
		 *
		 * @return void
		 */
		public function register_widgets( $widgets_manager ) {

			$base      = jet_engine()->plugin_path( 'includes/components/madxartwork-views/' );
			$post_type = get_post_type();

			$this->include_base_widget();

			foreach ( glob( $base . 'dynamic-widgets/*.php' ) as $file ) {
				$slug = basename( $file, '.php' );
				$this->register_widget( $file, $widgets_manager );
			}

			foreach ( glob( $base . 'static-widgets/*.php' ) as $file ) {
				$slug = basename( $file, '.php' );
				$this->register_widget( $file, $widgets_manager );
			}

		}


		/**
		 * Register new widget
		 *
		 * @return void
		 */
		public function register_widget( $file = '', $widgets_manager = null, $class = false ) {

			if ( ! $class ) {
				$base  = basename( str_replace( '.php', '', $file ) );
				$class = ucwords( str_replace( '-', ' ', $base ) );
				$class = str_replace( ' ', '_', $class );
				$class = sprintf( 'madxartwork\Jet_Listing_%s_Widget', $class );
			}

			require_once $file;

			if ( class_exists( $class ) ) {

				if ( method_exists( $widgets_manager, 'register' ) ) {
					$widgets_manager->register( new $class );
				} else {
					$widgets_manager->register_widget_type( new $class );
				}
			}

		}

		/**
		 * Register apropriate Document Types for listing items
		 *
		 * @return void
		 */
		public function register_document_type( $documents_manager ) {

			$base_path = jet_engine()->plugin_path( 'includes/components/madxartwork-views/document-types/' );

			require $base_path . 'listing-item.php';
			require $base_path . 'not-supported.php';

			$documents_manager->register_document_type(
				jet_engine()->listings->get_id(),
				'Jet_Listing_Item_Document'
			);

			$documents_manager->register_document_type(
				'jet-engine-not-supported',
				'Jet_Engine_Not_Supported'
			);

		}

		/**
		 * Return listing template ediit URL to redirect on
		 * @return [type] [description]
		 */
		public function get_redirect_url( $template_id ) {

			if ( version_compare( madxartwork_VERSION, '2.6.0', '<' ) ) {
				$redirect = madxartwork\Utils::get_edit_link( $template_id );
			} else {
				$redirect = madxartwork\Plugin::$instance->documents->get( $template_id )->get_edit_url();
			}

			return $redirect;
		}

		/**
		 * Inject listing settings from template into _madxartwork_page_settings meta
		 * @param  [type] $template_data [description]
		 * @return [type]                [description]
		 */
		public function inject_listing_settings( $template_data ) {

			if ( empty( $_REQUEST['listing_view_type'] ) || 'madxartwork' !== $_REQUEST['listing_view_type'] ) {
				return $template_data;
			}

			if ( ! class_exists( 'madxartwork\Plugin' ) ) {
				wp_die(
					__( 'Please install <a href="https://wordpress.org/plugins/madxartwork/" target="_blank">madxartwork page builder</a> to manage listings layout', 'jet-engine' ),
					__( 'madxartwork missed', 'jet-engine' )
				);
			}

			$documents = madxartwork\Plugin::instance()->documents;
			$doc_type  = $documents->get_document_type( jet_engine()->listings->get_id() );

			if ( ! $doc_type ) {
				wp_die(
					esc_html__( 'Incorrect template type. Please try again.', 'jet-engine' ),
					esc_html__( 'Error', 'jet-engine' )
				);
			}

			if ( ! isset( $_REQUEST['listing_source'] ) ) {
				return $template_data;
			}

			$template_data['meta_input']['_madxartwork_edit_mode'] = 'builder';
			$template_data['meta_input'][ $doc_type::TYPE_META_KEY ] = jet_engine()->listings->get_id();

			return $template_data;

		}

		/**
		 * Add the madxartwork listing view type
		 *
		 * @param  array $views
		 * @return array
		 */
		public function add_madxartwork_listing_view( $views ) {
			$views = array( 'madxartwork' => __( 'madxartwork', 'jet-engine' ) ) + $views;
			return $views;
		}

		/**
		 * Is editor ajax.
		 *
		 * @return bool
		 */
		public function is_editor_ajax() {
			return is_admin() && isset( $_REQUEST['action'] ) && 'madxartwork_ajax' === $_REQUEST['action'];
		}

		/**
		 * Prepare custom image size.
		 *
		 * @param string $size
		 * @param string $img_size_key
		 * @param array  $settings
		 *
		 * @return array|string
		 */
		public function prepare_custom_image_size( $size, $img_size_key, $settings ) {

			if ( 'custom' !== $size ) {
				return $size;
			}

			if ( empty( $settings[ $img_size_key . '_custom_dimension' ] ) ) {
				return $size;
			}

			// Use BFI_Thumb script
			require_once madxartwork_PATH . 'includes/libraries/bfi-thumb/bfi-thumb.php';

			$custom_dimension = $settings[ $img_size_key . '_custom_dimension' ];

			$attachment_size = array(
				// Defaults sizes
				0 => null, // Width.
				1 => null, // Height.

				'bfi_thumb' => true,
				'crop'      => true,
			);

			$has_custom_size = false;

			if ( ! empty( $custom_dimension['width'] ) ) {
				$has_custom_size = true;
				$attachment_size[0] = $custom_dimension['width'];
			}

			if ( ! empty( $custom_dimension['height'] ) ) {
				$has_custom_size = true;
				$attachment_size[1] = $custom_dimension['height'];
			}

			if ( ! $has_custom_size ) {
				$attachment_size = 'full';
			}

			return $attachment_size;
		}

		/**
		 * Add lightbox attr for Dynamic Image Link.
		 *
		 * @param $attr
		 * @param $settings
		 *
		 * @return mixed
		 */
		public function add_lightbox_attr( $attr, $settings ) {

			if ( empty( $settings['image_link_source'] ) ) {
				return $attr;
			}

			if ( '_file' !== $settings['image_link_source'] ) {
				return $attr;
			}

			if ( ! isset( $settings['lightbox'] ) ) {
				return $attr;
			}

			$lightbox = filter_var( $settings['lightbox'], FILTER_VALIDATE_BOOLEAN );

			$attr['data-madxartwork-open-lightbox'] = $lightbox ? 'yes' : 'no';

			return $attr;
		}

	}

}
