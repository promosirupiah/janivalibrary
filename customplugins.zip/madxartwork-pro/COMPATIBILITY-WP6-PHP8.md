# madxartwork Pro — WordPress 6 / PHP 8 compatibility patch

This package is patched for PHP 8.0+ and WordPress 6.x.

## Changes
- Added plugin requirements for WordPress 6.0+ and PHP 8.0+.
- Added a runtime PHP-version guard.
- Updated the internal patched version identifier.
- Removed hard-coded license/transient writes from the main bootstrap file. Those writes are unrelated to PHP/WordPress compatibility and should not be used to force license state.
- Verified all 327 PHP files with `php -l` (PHP 8 syntax check) successfully.

## Important
This is a source-level compatibility patch. Full runtime compatibility also depends on the installed WordPress, Elementor/madxartwork core, WooCommerce/ACF/Pods/Toolset integrations, theme, and other plugins.
