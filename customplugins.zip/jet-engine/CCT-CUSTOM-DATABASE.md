# JetEngine CCT custom database naming

Physical CCT table names use the normal WordPress `$wpdb->prefix`:
`wp_customer` instead of `wp_jet_cct_customer`.

Physical service columns:
- `_ID` -> `id`
- `cct_status` -> `status`
- `cct_author_id` -> `author_id`
- `cct_created` -> `created`
- `cct_modified` -> `modified`
- `cct_single_post_id` -> `single_post_id`

JetEngine continues to use its internal names in PHP for compatibility; the DB
layer translates them to the physical names when reading/writing SQL.

Existing `wp_jet_cct_*` tables are not automatically migrated. Back up the
database before activation and migrate/reinstall existing CCT tables as needed.
