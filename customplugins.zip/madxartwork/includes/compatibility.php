<?php
namespace madxartwork;

use madxartwork\Core\DocumentTypes\PageBase;
use madxartwork\TemplateLibrary\Source_Local;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * madxartwork compatibility.
 *
 * madxartwork compatibility handler class is responsible for compatibility with
 * external plugins. The class resolves different issues with non-compatible
 * plugins.
 *
 * @since 1.0.0
 */
class Compatibility {

	/**
	 * Register actions.
	 *
	 * Run madxartwork compatibility with external plugins using custom filters and
	 * actions.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 */
	public static function register_actions() {
		add_action( 'init', [ __CLASS__, 'init' ] );

		self::polylang_compatibility();

		if ( is_admin() || defined( 'WP_LOAD_IMPORTERS' ) ) {
			add_filter( 'wp_import_post_meta', [ __CLASS__, 'on_wp_import_post_meta' ] );
			add_filter( 'wxr_importer.pre_process.post_meta', [ __CLASS__, 'on_wxr_importer_pre_process_post_meta' ] );
		}

		add_action( 'madxartwork/maintenance_mode/mode_changed', [ __CLASS__, 'clear_3rd_party_cache' ] );

		add_action( 'madxartwork/element/before_section_start', [ __CLASS__, 'document_post_deprecated_hooks' ], 10, 3 );
		add_action( 'madxartwork/element/after_section_start', [ __CLASS__, 'document_post_deprecated_hooks' ], 10, 3 );
		add_action( 'madxartwork/element/before_section_end', [ __CLASS__, 'document_post_deprecated_hooks' ], 10, 3 );
		add_action( 'madxartwork/element/after_section_end', [ __CLASS__, 'document_post_deprecated_hooks' ], 10, 3 );
	}

	public static function document_post_deprecated_hooks( $instance, $section_id, $args ) {
		if ( ! $instance instanceof PageBase ) {
			return;
		}

		$current_action = current_action();
		$current_action = explode( '/', $current_action );
		$current_sub_action = $current_action[2];

		$deprecated_action = "madxartwork/element/post/{$section_id}/{$current_sub_action}";

		if ( ! has_action( $deprecated_action ) ) {
			return;
		}

		// TODO: Hard deprecation on 3.1.0.
		// $replacement = "`madxartwork/element/wp-post/{$section_id}/{$current_sub_action}` or `madxartwork/element/wp-page/{$section_id}/{$current_sub_action}`";
		// _deprecated_hook( $deprecated_action, '2.7.0', $replacement );

		do_action( $deprecated_action, $instance, $section_id, $args );
	}

	public static function clear_3rd_party_cache() {
		// W3 Total Cache.
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
		}

		// WP Fastest Cache.
		if ( ! empty( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) ) {
			$GLOBALS['wp_fastest_cache']->deleteCache();
		}

		// WP Super Cache
		if ( function_exists( 'wp_cache_clean_cache' ) ) {
			global $file_prefix;
			wp_cache_clean_cache( $file_prefix, true );
		}
	}

	/**
	 * Add new button to gutenberg.
	 *
	 * Insert new "madxartwork" button to the gutenberg editor to create new post
	 * using madxartwork page builder.
	 *
	 * @since 1.9.0
	 * @access public
	 * @static
	 */
	public static function add_new_button_to_gutenberg() {
		global $typenow;
		if ( ! User::is_current_user_can_edit_post_type( $typenow ) ) {
			return;
		}

		// Introduced in WP 5.0
		if ( function_exists( 'use_block_editor_for_post' ) && ! use_block_editor_for_post( $typenow ) ) {
			return;
		}

		// Deprecated/removed in Gutenberg plugin v5.3.0
		if ( function_exists( 'gutenberg_can_edit_post_type' ) && ! gutenberg_can_edit_post_type( $typenow ) ) {
			return;
		}

		?>
		<script type="text/javascript">
			document.addEventListener( 'DOMContentLoaded', function() {
				var dropdown = document.querySelector( '#split-page-title-action .dropdown' );

				if ( ! dropdown ) {
					return;
				}

				var url = '<?php echo esc_url( Utils::get_create_new_post_url( $typenow ) ); ?>';

				dropdown.insertAdjacentHTML( 'afterbegin', '<a href="' + url + '">madxartwork</a>' );
			} );
		</script>
		<?php
	}

	/**
	 * Init.
	 *
	 * Initialize madxartwork compatibility with external plugins.
	 *
	 * Fired by `init` action.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 */
	public static function init() {
		// Hotfix for NextGEN Gallery plugin.
		if ( defined( 'NGG_PLUGIN_VERSION' ) ) {
			add_filter( 'madxartwork/document/urls/edit', function( $edit_link ) {
				return add_query_arg( 'display_gallery_iframe', '', $edit_link );
			} );
		}

		// Hack for Ninja Forms.
		if ( class_exists( '\Ninja_Forms' ) && class_exists( '\NF_Display_Render' ) ) {
			add_action( 'madxartwork/preview/enqueue_styles', function() {
				ob_start();
				\NF_Display_Render::localize( 0 );

				ob_clean();

				wp_add_inline_script( 'nf-front-end', 'var nfForms = nfForms || [];' );
			} );
		}

		// Exclude our Library from Yoast SEO plugin.
		add_filter( 'wpseo_sitemaps_supported_post_types', [ __CLASS__, 'filter_library_post_type' ] );
		add_filter( 'wpseo_accessible_post_types', [ __CLASS__, 'filter_library_post_type' ] );
		add_filter( 'wpseo_sitemap_exclude_post_type', function( $retval, $post_type ) {
			if ( Source_Local::CPT === $post_type ) {
				$retval = true;
			}

			return $retval;
		}, 10, 2 );

		// Disable optimize files in Editor from Autoptimize plugin.
		add_filter( 'autoptimize_filter_noptimize', function( $retval ) {
			if ( Plugin::$instance->editor->is_edit_mode() ) {
				$retval = true;
			}

			return $retval;
		} );

		// Add the description (content) tab for a new product, so it can be edited with madxartwork.
		add_filter( 'woocommerce_product_tabs', function( $tabs ) {
			if ( ! isset( $tabs['description'] ) && Plugin::$instance->preview->is_preview_mode() ) {
				$post = get_post();
				if ( empty( $post->post_content ) ) {
					$tabs['description'] = [
						'title' => __( 'Description', 'madxartwork' ),
						'priority' => 10,
						'callback' => 'woocommerce_product_description_tab',
					];
				}
			}

			return $tabs;
		} );

		// Fix WC session not defined in editor.
		if ( class_exists( 'woocommerce' ) ) {
			add_action( 'madxartwork/editor/before_enqueue_scripts', function() {
				remove_action( 'woocommerce_shortcode_before_product_cat_loop', 'wc_print_notices' );
				remove_action( 'woocommerce_before_shop_loop', 'wc_print_notices' );
				remove_action( 'woocommerce_before_single_product', 'wc_print_notices' );
			} );

			add_filter( 'madxartwork/maintenance_mode/is_login_page', function( $value ) {

				// Support Woocommerce Account Page.
				if ( is_account_page() && ! is_user_logged_in() ) {
					$value = true;
				}
				return $value;
			} );
		}

		// Fix Jetpack Contact Form in Editor Mode.
		if ( class_exists( 'Grunion_Editor_View' ) ) {
			add_action( 'madxartwork/editor/before_enqueue_scripts', function() {
				remove_action( 'media_buttons', 'grunion_media_button', 999 );
				remove_action( 'admin_enqueue_scripts', 'grunion_enable_spam_recheck' );

				remove_action( 'admin_notices', [ 'Grunion_Editor_View', 'handle_editor_view_js' ] );
				remove_action( 'admin_head', [ 'Grunion_Editor_View', 'admin_head' ] );
			} );
		}

		// Fix Popup Maker in Editor Mode.
		if ( class_exists( 'PUM_Admin_Shortcode_UI' ) ) {
			add_action( 'madxartwork/editor/before_enqueue_scripts', function() {
				$pum_admin_instance = \PUM_Admin_Shortcode_UI::instance();

				remove_action( 'print_media_templates', [ $pum_admin_instance, 'print_media_templates' ] );
				remove_action( 'admin_print_footer_scripts', [ $pum_admin_instance, 'admin_print_footer_scripts' ], 100 );
				remove_action( 'wp_ajax_pum_do_shortcode', [ $pum_admin_instance, 'wp_ajax_pum_do_shortcode' ] );

				remove_action( 'admin_enqueue_scripts', [ $pum_admin_instance, 'admin_enqueue_scripts' ] );

				remove_filter( 'pum_admin_var', [ $pum_admin_instance, 'pum_admin_var' ] );
			} );
		}

		// Fix Preview URL for https://github.com/wpmudev/domain-mapping plugin
		if ( class_exists( 'domain_map' ) ) {
			add_filter( 'madxartwork/document/urls/preview', function( $preview_url ) {
				if ( wp_parse_url( $preview_url, PHP_URL_HOST ) !== $_SERVER['HTTP_HOST'] ) {
					$preview_url = \domain_map::utils()->unswap_url( $preview_url );
					$preview_url = add_query_arg( [
						'dm' => \Domainmap_Module_Mapping::BYPASS,
					], $preview_url );
				}

				return $preview_url;
			} );
		}

		// Gutenberg
		if ( function_exists( 'gutenberg_init' ) ) {
			add_action( 'admin_print_scripts-edit.php', [ __CLASS__, 'add_new_button_to_gutenberg' ], 11 );
		}
	}

	public static function filter_library_post_type( $post_types ) {
		unset( $post_types[ Source_Local::CPT ] );

		return $post_types;
	}

	/**
	 * Polylang compatibility.
	 *
	 * Fix Polylang compatibility with madxartwork.
	 *
	 * @since 2.0.0
	 * @access private
	 * @static
	 */
	private static function polylang_compatibility() {
		// Fix language if the `get_user_locale` is difference from the `get_locale
		if ( isset( $_REQUEST['action'] ) && 0 === strpos( $_REQUEST['action'], 'madxartwork' ) ) {
			add_action( 'set_current_user', function() {
				global $current_user;
				$current_user->locale = get_locale();
			} );

			// Fix for Polylang
			define( 'PLL_AJAX_ON_FRONT', true );

			add_action( 'pll_pre_init', function( $polylang ) {
				if ( isset( $_REQUEST['post'] ) ) {
					$post_language = $polylang->model->post->get_language( $_REQUEST['post'], 'locale' );
					if ( ! empty( $post_language ) ) {
						$_REQUEST['lang'] = $post_language->locale;
					}
				}
			} );
		}

		// Copy madxartwork data while polylang creates a translation copy
		add_filter( 'pll_copy_post_metas', [ __CLASS__, 'save_polylang_meta' ], 10, 4 );
	}

	/**
	 * Save polylang meta.
	 *
	 * Copy madxartwork data while polylang creates a translation copy.
	 *
	 * Fired by `pll_copy_post_metas` filter.
	 *
	 * @since 1.6.0
	 * @access public
	 * @static
	 *
	 * @param array $keys List of custom fields names.
	 * @param bool  $sync True if it is synchronization, false if it is a copy.
	 * @param int   $from ID of the post from which we copy information.
	 * @param int   $to   ID of the post to which we paste information.
	 *
	 * @return array List of custom fields names.
	 */
	public static function save_polylang_meta( $keys, $sync, $from, $to ) {
		// Copy only for a new post.
		if ( ! $sync ) {
			Plugin::$instance->db->copy_madxartwork_meta( $from, $to );
		}

		return $keys;
	}

	/**
	 * Process post meta before WP importer.
	 *
	 * Normalize madxartwork post meta on import, We need the `wp_slash` in order
	 * to avoid the unslashing during the `add_post_meta`.
	 *
	 * Fired by `wp_import_post_meta` filter.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @param array $post_meta Post meta.
	 *
	 * @return array Updated post meta.
	 */
	public static function on_wp_import_post_meta( $post_meta ) {
		foreach ( $post_meta as &$meta ) {
			if ( '_madxartwork_data' === $meta['key'] ) {
				$meta['value'] = wp_slash( $meta['value'] );
				break;
			}
		}

		return $post_meta;
	}

	/**
	 * Process post meta before WXR importer.
	 *
	 * Normalize madxartwork post meta on import with the new WP_importer, We need
	 * the `wp_slash` in order to avoid the unslashing during the `add_post_meta`.
	 *
	 * Fired by `wxr_importer.pre_process.post_meta` filter.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @param array $post_meta Post meta.
	 *
	 * @return array Updated post meta.
	 */
	public static function on_wxr_importer_pre_process_post_meta( $post_meta ) {
		if ( '_madxartwork_data' === $post_meta['key'] ) {
			$post_meta['value'] = wp_slash( $post_meta['value'] );
		}

		return $post_meta;
	}
}
