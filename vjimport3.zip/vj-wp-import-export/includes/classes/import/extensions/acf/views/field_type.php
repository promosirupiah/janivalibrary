<?php

?>
<input type="hidden" name="acf<?php echo esc_attr($parent_field_key ); ?>[<?php echo esc_attr($field_key) ?>][type]" value="<?php echo esc_attr($field_type) ?>"/>
