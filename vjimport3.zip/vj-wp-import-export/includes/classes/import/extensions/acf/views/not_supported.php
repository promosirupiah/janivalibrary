<div class="wpie_acf_item_wrapper" >
        <div class="wpie_item_act_label" ><?php echo esc_html( $title ); ?></div>
        <p><?php esc_html_e( 'This field type is not supported. E-mail support@vjinfotech.com with the details of the custom ACF field you are trying to import to, as well as a link to download the plugin or theme to install to add this field type to ACF, and we will investigate the  possibility of including support for it in the WP Import Export Plugin.', 'vj-wp-import-export' ); ?></p>
</div>