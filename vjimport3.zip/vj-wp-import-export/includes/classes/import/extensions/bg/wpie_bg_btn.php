<?php
if (!defined('ABSPATH')) {
    die(__("Can't load this file directly", 'vj-wp-import-export'));
}
?>
<div class="wpie_btn wpie_btn_primary wpie_import_bg_process_btn wpie_import_process_btn">
    <i class="fas fa-sync wpie_general_btn_icon " aria-hidden="true"></i>
    <?php esc_html_e('Import In Background', 'vj-wp-import-export'); ?>
</div>