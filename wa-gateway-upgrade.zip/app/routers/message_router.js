const { Router } = require("express");
const {
  sendMessage,
  sendBulkMessage,
  sendImageMessage,
  sendVideoMessage,
  sendDocumentMessage
} = require("../controllers/message_controller");
const MessageRouter = Router();

MessageRouter.all("/send-message", sendMessage);
MessageRouter.all("/send-bulk-message", sendBulkMessage);
MessageRouter.all("/send-image", sendImageMessage);
MessageRouter.all("/send-video", sendVideoMessage);
MessageRouter.all("/send-document", sendDocumentMessage);
module.exports = MessageRouter;
