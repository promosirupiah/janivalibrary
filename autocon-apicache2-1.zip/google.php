<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/web?v=1.0&rsz=4&key='.$google_web_api.'&q=' .urlencode($termstring).urlencode($addsearch); 
if (file_exists('apicache/g_web_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/g_web_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/g_web_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_web_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $value) 
{ ?>
<div class="post">
<?php echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($value->titleNoFormatting)).'">'.ucwords(CleanFileNameBan(ubah_space($value->titleNoFormatting))).'</a></h2>'; ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode($value->titleNoFormatting); 
if (file_exists('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt') && (time() - $apicachetime < filemtime('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt')))
{
$response = file_get_contents('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_img_'.ubah_tanda($value->titleNoFormatting).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($content->titleNoFormatting));?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))) ?>"src="<?php echo $content->unescapedUrl; ?>"></a>

<?php } ?>
<br style="clear:both">
<?php echo $value->content; ?>
<br style="clear:both">
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$value->url ?>">read more</a>
</div>
<?php } ?> 


