<?php 
$main_title = 'Best Video'; //* Main Title and auto generate front page from blogsearch

$bingapis[] = '445D718A5BDF3CF151395BBEE50233167AA31EF2';
$bingapis[] = '445D718A5BDF3CF151395BBEE50233160FA0E9B9';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316210A4558';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316AA84FFC6';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316E9B013F2';
$bingapis[] = '445D718A5BDF3CF151395BBEE50233168B32FF5B';
$bingapis[] = '445D718A5BDF3CF151395BBEE5023316F0400F8C';


$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxRdQ_EONEqjNwrhu5GY3F6OI5M3TBQgZd9M93SliOUv8O-65hCxWxeD-w';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxR_NuWjYao3q0rhiKiAf4ILzqzzmRRONBNXDGKLIpECfTislZQwxqGm7g';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxShLuwtOPXh9xBK8HHHfeLk-yQrBhQRN-MHh78_ZNGan3WPyJq9oGmmDg';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxSlckdLM2mKx40qPfeB9aCAwtlVwBQw1iShhQwfUCtJ8-Ko26G3ZIKRPA';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxRJbkTihGh0jt8kBFTJhxS0AUsLRBSZDypHx3kXUOwI00vmLAO9s11imw';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxQRk-8loAPkAWWAgnHpsFmVod1BNhRDsam95y6h9S9s7CqWNnHI4Bqyvw';
$gapis[] = 'ABQIAAAAkCMqLpuFGIta6SLpaQ5DfxRmvpUMwSjGuKImj0uaGqbs5GXnohQk5uxgDcFX9CpWBHatw71QmtEU9w';

$bing_web_api = $bingapis[rand(0,count($bingapis)-1)]; //* insert your bing api
$bing_image_api = $bingapis[rand(0,count($bingapis)-1)]; //* better insert different api for bing image 
$google_web_api = $gapis[rand(0,count($gapis)-1)]; //*insert your google api
$google_image_api = $gapis[rand(0,count($gapis)-1)]; //*better insert different api for google image 

$categories = array('cartoon','movies','horror','drama comedy'); //* lowercase, dynamic auto generate category from blogsearch
$addsearch = ' free +video -youtube -alcohol -cigarette -cigarettes -gamble -casino -sex -porn -rapidshare -megaupload'; //*additional keyword use +,-,or just keyword
$apicachetime = 7 * 24 * 60 * 60;// cache time for api in seconds
?>

<?php
function SureRemoveDir($dir, $DeleteMe) {
    if(!$dh = @opendir($dir)) return;
    while (false !== ($obj = readdir($dh))) {
        if($obj=='.' || $obj=='..') continue;
        if (!@unlink($dir.'/'.$obj)) SureRemoveDir($dir.'/'.$obj, true);
    }

    closedir($dh);
    if ($DeleteMe){
        @rmdir($dir);
    }
}
if ($_SERVER["REQUEST_URI"] =='/index.php?clearapi'){SureRemoveDir('apicache',false);echo 'apicache clear';exit;} //*use http://yourdomain.com/index.php?clearapi to clear api cache
if ($_SERVER["REQUEST_URI"] =='/index.php?clearcache'){SureRemoveDir('cache',false);echo 'cache clear';exit;} //*use http://yourdomain.com/index.php?clearcache to clear cache file

?>
<?php
function ubah_tanda($result) { //change all special character to "-"
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
	$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
}
function ubah_space($result) { //change all special character to " "
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', ' ', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
	$result = preg_replace('|-+|', ' ', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
	$result = str_replace(array('    ','   ','  '), ' ', $result);
	$result = trim($result, ' ');
	return $result;
}
function CleanFileNameBan($result){
$bannedkey = array("<b>","</b>","...","..","http","wikipedia","youtube","amazon","www","yahoo","index","the free encyclopedia","blogspot","wiki","facebook","alcohol","cigarette","cigarettes","gamble","casino","sex","porn"); //remove those words on title result, lowercase only
$result = strtolower($result);
$result = str_replace($bannedkey, '',$result);
$result = trim($result);
return $result;
}

?>
<?php
$termstring = ubah_tanda(CleanFileNameBan(str_replace(array('?utm_source=twitterfeed&utm_medium=statusnet','?utm_source=twitterfeed&utm_medium=twitter'),'',$_SERVER["REQUEST_URI"])));
$termstring = str_replace(array("-","--","---","----")," ",$termstring);
$displaytitle = ucwords($termstring);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/feedmask.php?http://blogsearch.google.com/blogsearch_feeds?hl=en&as_drrb=q&as_qdr=h&ie=utf-8&num=10&output=rss&q='.urlencode($main_title)?>" />
<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/style.css'; ?>" type="text/css" media="screen" />
<?php if (($_SERVER["REQUEST_URI"]) !='/'){ //rss generated for title from blogsearch.google.com ?>
<link rel="alternate" type="application/rss+xml" title="<?php echo $termstring ?>" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/feedmask.php?http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).'&ie=utf-8&num=20&output=rss' ?>" />
<?php } ?>
<title><?php if (($_SERVER["REQUEST_URI"]) !='/') {echo $displaytitle .'|';}; echo $main_title; ?></title>

</head>
<body>
<div id="header">
<h1 style="clear:both"><a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"];?>"><?php echo $main_title ?></a></h1>
</div>
<div style="float:left;">
<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<div style="float:left;">
<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<?php
//start check and read caching
//for front page
if ($_SERVER["REQUEST_URI"] =='/') {
$cachefile = 'cache/index.html';
$cachetime = 30 * 60; // cache time minutes * seconds
if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))) {
include($cachefile);
include ('./sidebar.php');
echo '</body></html>';

  	exit;      }
}

//*for categories

else if (in_array(str_replace(array('/','-'),array('',' '),$_SERVER["REQUEST_URI"]), $categories)) {
$cachefile = 'cache/'.ubah_tanda($_SERVER["REQUEST_URI"]).'.html';
$cachetime = 30 * 60; // cache time minutes * seconds
if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))) {
include($cachefile); 
include ('./sidebar.php');
echo '</body></html>';
	exit;
}
}


//*for all uri
else {
$cachefile = 'cache/'.ubah_tanda($_SERVER["REQUEST_URI"]).'.html';
if (file_exists($cachefile)) {
include($cachefile); 
include ('./sidebar.php');
echo '</body></html>';
	exit;
}
}


//end check and read caching

ob_start(); 
//*code start for caching
include ('./content.php');
//*code end
$fp = fopen($cachefile, 'w');
fwrite($fp, ob_get_contents());
fclose($fp);
ob_end_flush();
include ('./sidebar.php');
echo '</body></html>';

?>