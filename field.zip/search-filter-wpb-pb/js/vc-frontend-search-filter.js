(function ( $ ) {
	
	"use strict";
	
	function initPagination($this){
		var $vc_pagination = $this.find(".search-filter-vc-pagi-hidden");
		
		if($vc_pagination.length > 0)
		{
			$vc_pagination.remove().attr('style', '');
			
			if($this.hasClass("search-filter-results-pagination"))
			{
				$this.append($vc_pagination);
			}
		}
	}		
	
	$(document).on("sf:init", ".searchandfilter", function(e, data){
		
		var search_form = data.object;
		
		if(search_form.display_result_method=="vc_post_grid")
		{
			var $vc_results_container = $('.vc_basic_grid.search-filter-results-'+data.sfid+', .vc_masonry_grid.search-filter-results-'+data.sfid+', .vc_media_grid.search-filter-results-'+data.sfid+', .vc_masonry_media_grid.search-filter-results-'+data.sfid);
			if($vc_results_container.length>0)
			{
				
				var vc_data = $.parseJSON($vc_results_container.attr("data-vc-grid-settings"));
				search_form.addQueryParam("sfvc_page_id", vc_data.page_id, "ajax");
				search_form.addQueryParam("sfvc_shortcode_id", vc_data.shortcode_id, "ajax");
				search_form.addQueryParam("sfvc_style", vc_data.style, "ajax");
				search_form.addQueryParam("sfvc_shortcode_tag", vc_data.tag, "ajax");
			}
		}
		
	});
	
	//assumes we only have 1 grid on a page
	//var ajax_count = 0;
	$(window).on("grid:items:added", function(e, grid){

		//if( ajax_count == 0 ){

			var $grid = $(grid);
			
			if($grid.hasClass("search-filter-results")){
				initPagination($grid);
			}
			//ajax_count++;
		//}
	});
	
	$(document).on("sf:ajaxfinish", ".searchandfilter", function(e, data){
		
		var search_form = data.object;
		
		if(search_form.display_result_method=="vc_post_grid")
		{
			var $vc_basic_grid_results_container = $('.vc_basic_grid.search-filter-results-'+data.sfid);
			if($vc_basic_grid_results_container.length>0)
			{//then regular post grid
		
				$vc_basic_grid_results_container.find(".vc_grid-item").css("display", "inline-block");
				$vc_basic_grid_results_container.find(".vc_grid-item .vc_gitem-animated-block .vc_gitem-zone").addClass("vc-gitem-zone-height-mode-auto");
				
				var tVcGrid = $vc_basic_grid_results_container.data("vcGrid").gridBuilder;
				window.vc_prettyPhoto();
				$(window).trigger("grid:items:added", tVcGrid.$el); 
				
			}
			
			var $vc_media_grid_results_container = $('.vc_media_grid.search-filter-results-'+data.sfid);
			if($vc_media_grid_results_container.length>0)
			{//then regular post grid
		
				$vc_media_grid_results_container.find(".vc_grid-item").css("display", "inline-block");
				$vc_media_grid_results_container.find(".vc_grid-item .vc_gitem-animated-block .vc_gitem-zone").addClass("vc-gitem-zone-height-mode-auto");
				
				var tVcGrid = $vc_media_grid_results_container.data("vcGrid").gridBuilder;
				window.vc_prettyPhoto();
				$(window).trigger("grid:items:added", tVcGrid.$el); 
				//need to re-init lightbox
				
			}
			
			var $vc_masonry_grid_results_container = $('.vc_masonry_grid.search-filter-results-'+data.sfid);
			if($vc_masonry_grid_results_container.length>0)
			{//then masonry grid					
		
				var $vc_pagination = $vc_masonry_grid_results_container.find(".search-filter-vc-pagi-hidden");
				$vc_pagination.remove().attr('style', '');
				if($vc_masonry_grid_results_container.hasClass("search-filter-results-pagination"))
				{
					$vc_masonry_grid_results_container.append($vc_pagination);
				}
				
				// WORKING
				var tVcGrid = $vc_masonry_grid_results_container.data("vcGrid").gridBuilder;
				var html = $vc_masonry_grid_results_container.html();
				$vc_masonry_grid_results_container.empty();
				
				tVcGrid.addItems(html);
				//tVcGrid.setMasonry();
				//tVcGrid.render();
				var $els = tVcGrid.$content.find(".vc_grid-item" + tVcGrid.filterValue);
				$els.addClass("vc_visible-item");
				$els.imagesLoaded(function() {
					tVcGrid.masonryEnabled = false;
					tVcGrid.setItems($els); //$els.addClass("vc_visible-item");
					
					//tVcGrid.$content.masonry("destroy");
					//tVcGrid.masonryEnabled = false;
					//$els.addClass("vc_visible-item");
					//tVcGrid.setItems($els);
					
					tVcGrid.unsetIsLoading();
					window.vc_prettyPhoto();
					$(window).trigger("grid:items:added", tVcGrid.$el); 
				});
			}
			
			var $vc_masonry_media_grid_results_container = $('.vc_masonry_media_grid.search-filter-results-'+data.sfid);
			if($vc_masonry_media_grid_results_container.length>0)
			{//then masonry grid					
		
				var $vc_pagination = $vc_masonry_media_grid_results_container.find(".search-filter-vc-pagi-hidden");
				$vc_pagination.remove().attr('style', '');
				if($vc_masonry_media_grid_results_container.hasClass("search-filter-results-pagination"))
				{
					$vc_masonry_media_grid_results_container.append($vc_pagination);
				}
				
				var tVcGrid = $vc_masonry_media_grid_results_container.data("vcGrid").gridBuilder;
				var html = $vc_masonry_media_grid_results_container.html();
				$vc_masonry_media_grid_results_container.empty();
				
				tVcGrid.addItems(html);
				
				var $els = tVcGrid.$content.find(".vc_grid-item" + tVcGrid.filterValue);
				$els.addClass("vc_visible-item");
				$els.imagesLoaded(function() {
					tVcGrid.masonryEnabled = false;
					tVcGrid.setItems($els);
					
					tVcGrid.unsetIsLoading();
					window.vc_prettyPhoto();
					$(window).trigger("grid:items:added", tVcGrid.$el); 
				});
			}  
			
		}
	});
	
}(window.jQuery));
