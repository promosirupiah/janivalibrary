<?php
/**
 * Plugin Name:       Search & Filter - WPBakery PB Extension
 * Description:       Adds Search & Filter integration for WPBakery Page Builder - integrates with the Post Grid, Post Masonry Grid, Media Grid, Masonry Media Grid & Products elements
 * Plugin URI:        https://searchandfilter.com
 * Version:           1.0.1
 * Author:            Code Amp
 * Author URI:        https://www.codeamp.com
 * Text Domain:       search-filter-wpb-pb
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'plugins_loaded', array( 'Search_Filter_WPB_PB', 'get_instance' ) );

Class Search_Filter_WPB_PB{
	
	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.1';
	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Search_Filter_WPB_PB The single instance of the class.
	 */
	protected static $instance = null;
	
	private $search_form_options = array();
	private $vc_shortcodes = array();
	private $vc_query;
	
	private $search_filter_vc_id = 0;
	private $search_filter_vc_pagination = '';
	private $search_filter_vc_grid_query = null;
	private $search_filter_vc_grid_iterator = 0;
	
	const PLUGIN_UPDATE_URL = 'https://searchandfilter.com';
	const PLUGIN_UPDATE_ID = 185367; 
	
	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Search_Filter_madxartwork_Extension An instance of the class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}
	
	private function __construct() {
		
		// Check if Visual Composer is installed
        if ( ( ! defined( 'WPB_VC_VERSION' ) ) || ( ! defined( 'SEARCH_FILTER_VERSION' ) ) ) {
            // Display notice that Visual Compser is required
            // add_action('admin_notices', array( $this, 'showVcVersionNotice' ));
            return;
        }
		else
		{
			add_action( 'vc_before_init', array($this, 'init_vc_mappings') );
			add_action( 'init', array($this, 'vc_add_params_to_elements'), 2000 );
			add_action( 'vc_after_init', array($this, 'vc_edit_element_params'), 2000 );
			
			add_action( 'loop_end', array($this, 'vc_grid_loop_end'), 10); //add pagination after loop 
			add_action( 'loop_start', array($this, 'vc_grid_loop_start'), 10); //add pagination after loop 
			
			//modify shortcodes 
			add_filter( 'shortcode_atts_vc_basic_grid', array($this, 'vc_filter_frontend_shortcode'), 10, 3 );
			add_filter( 'shortcode_atts_vc_masonry_grid', array($this, 'vc_filter_frontend_shortcode'), 10, 3 );
			add_filter( 'shortcode_atts_vc_media_grid', array($this, 'vc_filter_frontend_shortcode_media'), 10, 3 );
			add_filter( 'shortcode_atts_vc_masonry_media_grid', array($this, 'vc_filter_frontend_shortcode_media'), 10, 3 );
			add_filter( 'shortcode_atts_products', array($this, 'vc_filter_frontend_shortcode_products'), 10, 3 );
			
			add_filter( 'sf_ajax_data_fields', array($this, 'sf_ajax_data_fields'), 10, 2 );
			
			add_filter( "search_filter_ajax_object_vc_results", array($this, 'search_filter_ajax_object_vc_results'), 10, 1);
			add_filter( 'sf_ajax_results_url', array($this, 'sf_ajax_results_url'), 10, 2 );
			add_filter( 'search_filter_admin_option_display_results', array($this, 'search_filter_admin_option_display_results'), 10, 2 );
			add_filter( 'search_filter_form_attributes', array($this, 'search_filter_form_attributes'), 10, 2 );
			
			add_filter( 'vc_basic_grid_template_filter', array($this, 'filter_grid_output'), 10, 2 );
			//add_filter( 'products_template_filter', array($this, 'filter_grid_output'), 10, 2 ); //we don't need to add our pagination, WC provides a `paginate` option in the shortcode
			
			//add_filter( 'vc_basic_grid_filter_query_filters', array($this, 'add_filter_vc_query' ));
			//add_filter( 'pre_get_posts', array($this, 'filter_vc_query' ));
			
			add_action('wp_enqueue_scripts', array($this, "enqueue_scripts"), 10);
			
			
			// Plugin Updater
			add_action( 'admin_init', array($this, 'update_plugin_handler'), 0 );
			
			// WooCommerce stuff
			// add filter to modify the WC shortcode query
			// add_filter( 'woocommerce_shortcode_products_query', array( $this, 'attach_sf_to_wc_shortcode_args' ), 1000, 3 );
		

		}
	}
	
	public function add_filter_vc_query($query){
		//add_filter( 'pre_get_posts', array($this, 'filter_vc_query' ));
	}
	
	public function filter_vc_query($query){
		//actually, just grab a reference to the query object, so we can setup pagination
		
		$this->vc_query = $query;
		remove_filter( 'pre_get_posts', array($this, 'filter_vc_query' ));
		return $query;
	}
	
	public function grid_pagination_fix($url){
		
		$url = remove_query_arg("sfvc_page_id", $url);
		$url = remove_query_arg("sfvc_shortcode_id", $url);
		$url = remove_query_arg("sfvc_style", $url);
		
		return $url;
	}
	
	public function filter_grid_output($output, $atts){
		
		global $search_filter_vc_grid_iterator;
		if($search_filter_vc_grid_iterator==0)
		{
			add_filter('get_pagenum_link', array($this, 'grid_pagination_fix'), 101 );
			add_filter('paginate_links', array($this, 'grid_pagination_fix'), 101 );
			
			$output .= '<div class="search-filter-vc-pagi-hidden" style="display: none !important;">';
						
			$pagi_output = apply_filters( 'search_filter_vc_pagination', '', $this->vc_query );
			
			if($pagi_output !== '')
			{
				$output .= $pagi_output;
			}
			else
			{
				$big = 999999999; // need an unlikely integer
				$args = array(
					'total' 			 => $this->vc_query->max_num_pages,
					'current' 			 => $this->vc_query->query_vars['paged'],
					'base' 				 => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
					'format' 			 => '?paged=%#%',
					'mid_size'           => 1,
					'prev_text'          => _x( 'Previous', 'previous set of posts' ),
					'next_text'          => _x( 'Next', 'next set of posts' ),
					'screen_reader_text' => __( 'Posts navigation' ),
				);
				
				$args = apply_filters( 'search_filter_vc_pagination_args', $args ); // return only grid shortcodes
				$output .=  '<nav class="navigation pagination" role="navigation">'. paginate_links($args) . '</nav>';
			}
			
			remove_filter('get_pagenum_link', array($this, 'grid_pagination_fix'), 101 );
			remove_filter('paginate_links', array($this, 'grid_pagination_fix'), 101 );
			
			$output .= '</div>';
		}
		
		$search_filter_vc_grid_iterator++;
		
		return $output;
	}
	
	public function vc_grid_loop_start($query){
		
		if(isset($query->query_vars['search_filter_id'])) {
			global $search_filter_vc_grid_iterator;
			$search_filter_vc_grid_iterator = 0;
		}
	}
	public function vc_grid_loop_end($query){
		
		if(isset($query->query_vars['search_filter_id'])) {
			global $search_filter_vc_grid_iterator;
			$search_filter_vc_grid_iterator = 0;
			
		}
	}
	
	public function enqueue_scripts(){	
	
		wp_register_script( 'search-filter-wpb-pb', plugins_url( 'js/vc-frontend-search-filter.js', __FILE__ ), array( 'jquery' ), "1.0.1" );
		wp_localize_script( 'search-filter-wpb-pb', 'SFVC_DATA', array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'home_url' => (home_url('/')) ));
		wp_enqueue_script( 'search-filter-wpb-pb');
	}
	
	public function search_filter_form_attributes($attributes, $sfid){
		
		if(isset($attributes['data-display-result-method'])) {
			
			if($attributes['data-display-result-method']=="vc_post_grid") {
				
				$attributes['data-ajax-target'] = '.search-filter-results-'.$sfid;
				$attributes['data-ajax-links-selector'] = 'a.page-numbers';
				$attributes['data-ajax-data-type'] = 'json';
			}
			else if($attributes['data-display-result-method']=="vc_products") {
				
				$attributes['data-ajax-target'] = '.search-filter-results-'.$sfid;
				$attributes['data-ajax-links-selector'] = '.page-numbers a';
			}
		}
		return $attributes;
	}
	public function search_filter_admin_option_display_results($display_results_options){
		
		$display_results_options['vc_post_grid'] = array(
            'label'         => __('WPBakery - Post or Media (Masonry) Grid Element'),
            'description'   => 
				'<p>'.__('Search Results will displayed using one of WPBakery\'s elements.', '').'</p>'.
				'<p>'.__('Remember to set the <strong>Data Source</strong> in your elements to use this Search Form.', '').'</p>',
            'base'          => 'shortcode'
        );
		$display_results_options['vc_products'] = array(
            'label'         => __('WPBakery - Products Element'),
            'description'   => 
				'<p>'.__('Search Results will displayed using one of WPBakery\'s elements.', '').'</p>'.
				'<p>'.__('Remember to connect the Recent Products element to Search & Filter.', '').'</p>',
            'base'          => 'shortcode'
        );
		
		return $display_results_options;
	}
	
	public function sf_ajax_data_fields($data_type, $sfid){
		
		global $searchandfilter;
		$display_result_as = $searchandfilter->get($sfid)->settings("display_results_as");
		$enable_auto_count = $searchandfilter->get($sfid)->settings("enable_auto_count");
		$auto_submit = $searchandfilter->get($sfid)->settings("auto_submit");
		
		if($display_result_as=="vc_post_grid") {
			
			if (($enable_auto_count==1)&&($auto_submit==1)) {
				//if auto count & auto submit are enabled, then we must request a copy of the search form too (with the updated count numbers & fields)
				$data_type = "form,vc_results";
			}
			else {
				
				$data_type = "vc_results";
			}		
		}
		
		return $data_type;
	}
	
	public function search_filter_ajax_object_vc_results($ajax_object){
		
		$data = array();
		
		if((isset($_GET['sfvc_page_id']))&&(isset($_GET['sfvc_style']))&&(isset($_GET['sfvc_shortcode_id']))&&(isset($_GET['sfvc_shortcode_tag']))) {
			
			$data["page_id"] = intval($_GET['sfvc_page_id']);
			$data["style"] = sanitize_text_field($_GET['sfvc_style']);
			$data["shortcode_id"] = sanitize_text_field($_GET['sfvc_shortcode_id']);
			$data["tag"] = sanitize_text_field($_GET['sfvc_shortcode_tag']);
			
			$ajax_object['results'] = $this->get_vc_results($data);
		}
		
		return $ajax_object;
	}
		
	public function sf_ajax_results_url($url, $sfid){
		
		global $searchandfilter;
		$display_result_as = $searchandfilter->get($sfid)->settings("display_results_as");
		
		if($display_result_as=="vc_post_grid")
		{
			$url = add_query_arg("sfid", $sfid, $url);
			$url = add_query_arg("sf_action", "get_data", $url);
		}
		
		return $url;		
	}
		
	public function change_element_class_name($class_string, $tag){
		
		if(($tag=="vc_basic_grid")||($tag=="vc_masonry_grid")||($tag=="vc_media_grid")||($tag=="vc_masonry_media_grid"))
		{
			//if(strpos($class_string, "vc_grid-container")!==false)
			//{
				
				$class_string .= ' search-filter-results search-filter-results-'.$this->search_filter_vc_id.' ';
				
				if($this->search_filter_vc_pagination == "wp_pagination")
				{
					$class_string .= " search-filter-results-pagination";
				}
				
				//reset globals
				$this->search_filter_vc_id = 0;
				$this->search_filter_vc_pagination = "";
				
				//remove filters
				remove_filter( 'vc_shortcodes_css_class', array($this, 'change_element_class_name'), 1000, 2 );
				
				return $class_string;
			//}
		}
		else{
			
		}
		
		
		return $class_string;
	}
	
	public function get_vc_results($atts){
		
		$allowed = true;
		
		//recreate the VC ajax request
        if ( $allowed ) {
            $shortcode_fishbone = visual_composer()->getShortCode( $atts['tag'] );
            if ( is_object( $shortcode_fishbone ) ) {
                /** @var $vc_grid WPBakeryShortcode_Vc_Basic_Grid */
                $vc_grid = $shortcode_fishbone->shortcodeClass();
                if ( method_exists( $vc_grid, 'isObjectPageable' ) && $vc_grid->isObjectPageable() && method_exists( $vc_grid, 'renderAjax' ) ) {
					
                    $data = array();
                    $data["visible_pages"]= "5";
                    //$data["page_id"] = (int)$_GET['sfvc_page_id'];
                    //$data["style"]= "all";
                    $data["action"]= "vc_get_vc_grid_data";
					
					if(!isset($atts['shortcode_id'])) {
						$atts['shortcode_id'] = "";
					}
					if(!isset($atts['page_id'])) {
						$atts['page_id'] = "";
					}
					if(!isset($atts['sfvc_style'])) {
						$atts['sfvc_style'] = "";
					}
					
                    $data["shortcode_id"] = $atts['shortcode_id'];
                    $data["page_id"] = $atts['page_id'];
                    $data["style"] = $atts['style'];
                    $data["tag"] = $atts['tag'];
					
					$results = $vc_grid->renderAjax($data);
					
                    return $results;
                }
            }
        }
	}
	
	public function vc_filter_frontend_shortcode($out, $pairs, $atts){
		
		if(!isset($atts['post_type'])){
			return $out;
		}
		
		if($atts['post_type']=='search_filter'){
			//then the user selected S&F as the input source
			$search_filter_slug = $atts['search_filter_slug'];
			
			$out['post_type'] = "custom";
			$out['search_filter_slug'] = "";
			$out['taxonomies'] = "";
			$search_filter_pagination = isset($atts['search_filter_pagination']) ? $atts['search_filter_pagination'] : '';
			
			$search_filter_id = 0;
			
			if ( $post = get_page_by_path( esc_attr($search_filter_slug), OBJECT, 'search-filter-widget' ) ) {	
				$search_filter_id = (int)$post->ID;
			}
			
			if($search_filter_id!==0) {
				
				//$atts['post_type'] = array("post");
				$out['custom_query'] = "search_filter_id=$search_filter_id";
				//$atts['el_class'] .= " search-filter-results-$search_filter_id";
				
				$this->search_filter_vc_id = $search_filter_id;
				$this->search_filter_vc_pagination = $search_filter_pagination;
				
				add_filter( 'pre_get_posts', array($this, 'filter_vc_query' )); //attach S&F
				add_filter( 'vc_shortcodes_css_class', array($this, 'change_element_class_name'), 1000, 2 );
				add_filter( "vc_grid_request_url", array($this, 'add_query_args_to_request'), 10 );
			}
		}
		
		return $out;
	}
	public function vc_filter_frontend_shortcode_products($out, $pairs, $atts){
		
		if(isset($atts['search_filter_connect'])){
			
			if($atts['search_filter_connect'] == "yes"){
				
				if(isset($atts['search_filter_slug'])){
					
					$search_filter_slug = $atts['search_filter_slug'];
					$out['search_filter_slug'] = "";
					
					$search_filter_pagination = isset($atts['search_filter_pagination']) ? $atts['search_filter_pagination'] : '';
					
					$search_filter_id = 0;
					
					if ( $post = get_page_by_path( esc_attr($search_filter_slug), OBJECT, 'search-filter-widget' ) ){	
					
						$search_filter_id = (int)$post->ID;
					}
					
					if($search_filter_id!==0){
						$out['class'] .= ' search-filter-results search-filter-results-'.$search_filter_id.' ';
					}
					
					/*
					unset($out['limit']);
					unset($out['orderby']);
					unset($out['order']);
					unset($out['ids']);
					unset($out['skus']);
					unset($out['category']);
					unset($out['cat_operator']);
					unset($out['attribute']);
					unset($out['terms']);
					unset($out['terms_operator']);
					unset($out['tag']);
					unset($out['tag_operator']);
					unset($out['visibility']);
					unset($out['page']);
					unset($out['paginate']);*/
					//unset($out['cache']);
					$out['cache'] = false;
					if(!empty($search_filter_pagination)){
						$out['paginate'] = true;
					}
					
					$this->search_filter_vc_id = $search_filter_id;
					$this->search_filter_vc_pagination = $search_filter_pagination;
					
					//add filter to modify the WC shortcode query
					add_filter( 'woocommerce_shortcode_products_query', array( $this, 'attach_sf_to_wc_shortcode_args' ), 1000000, 3 );
				}
				
				
			}
		}
		
		return $out;
	}
	public function vc_filter_frontend_shortcode_media($out, $pairs, $atts){
		
		if(isset($atts['search_filter_connect'])){
			
			if($atts['search_filter_connect'] == "yes"){
				
				if(isset($atts['search_filter_slug'])){
					
					$search_filter_slug = $atts['search_filter_slug'];
					//$out['search_filter_slug'] = "";
					
					$search_filter_pagination = isset($atts['search_filter_pagination']) ? $atts['search_filter_pagination'] : '';
					$search_filter_id = 0;
					
					if ( $post = get_page_by_path( esc_attr($search_filter_slug), OBJECT, 'search-filter-widget' ) ){	
					
						$search_filter_id = (int)$post->ID;
					}
					
					if($search_filter_id===0){
						return $out;
					}
					
					//initial page load runs via ajax
					$this->search_filter_vc_id = $search_filter_id;
					$this->search_filter_vc_pagination = $search_filter_pagination;
					
					add_filter( 'vc_shortcodes_css_class', array($this, 'change_element_class_name'), 1000, 2 );
					add_filter( "vc_grid_request_url", array($this, 'add_query_args_to_request'), 10 );
					
					
					
					$args = array(
						'fields' => 'ids',
						'post_type' => 'attachment',
						'search_filter_id' => $search_filter_id,
						'suppress_filters' => true
					);
					
					$media_results = new WP_Query($args);
					$this->vc_query = $media_results; //copy here for pagination
					$ids = '';
					
					if( intval($media_results->found_posts) > 0 ){
						$ids = implode(',', $media_results->posts);
					}
					/*if($media_results->found_posts > 0){
						$tids = array();
						foreach($media_results->posts as $post){
							array_push($tids, $post->ID);
						}
						$ids = implode(',', $tids);
						
					}*/
					
					
					wp_reset_postdata();
					
					$out['include'] = $ids;
					$out['style'] = 'all';
					//$out['items_per_page'] = '10';
					//$out['element_width'] = '4';
					//$out['gap'] = '5';
					//$out['button_style'] = '';
					//$out['button_size'] = '';
					//$out['arrows_design'] = 'none';
					//$out['arrows_position'] = 'inside';
					//$out['arrows_color'] = 'blue';
					//$out['paging_design'] = 'radio_dots';
					//$out['paging_color'] = 'grey';
					//$out['loop'] = '';
					//$out['autoplay'] = '-1';
					//$out['paging_animation_in'] = '';
					//$out['paging_animation_out'] = '';
					//$out['item'] = 'mediaGrid_Default';
					//$out['el_id'] = 'mediaGrid_Default';
					//$out['el_class'] = 'mediaGrid_Default';
					//$out['el_class'] = 'mediaGrid_Default';
					//$out['css'] = 'mediaGrid_Default';
					//$out['btn_title'] = 'Load More';
					//$out['btn_style'] = 'flat';
					//$out['btn_gradient_color_1'] = 'turquoise';
					//$out['btn_gradient_color_2'] = 'blue';
					//$out['btn_gradient_custom_color_1'] = '#dd3333';
					//$out['btn_gradient_custom_color_2'] = '#eeee22';
					//$out['btn_gradient_text_color'] = '#ffffff';
					//$out['btn_custom_background'] = '#ededed';
					//$out['btn_custom_text'] = '#666';
					//$out['btn_outline_custom_color'] = '#666';
					//$out['btn_outline_custom_hover_background'] = '#666';
					//$out['btn_outline_custom_hover_text'] = '#fff';
					//$out['btn_shape'] = 'rounded';
					//$out['btn_color'] = 'blue';
					//$out['btn_size'] = 'md';
					//$out['btn_align'] = 'inline';
					//$out['initial_loading_animation'] = 'fadeIn';
					
					
				}
			}
		}
		
		return $out;
	}
	
	public function attach_sf_to_wc_shortcode_args( $query_args, $attributes, $type ) {
		
		$query_args['search_filter_id'] = intval($this->search_filter_vc_id);
		$this->search_filter_vc_id = 0;
		remove_filter( 'woocommerce_shortcode_products_query', array( $this, 'attach_sf_to_wc_shortcode_args' ), 1000, 3 );
		return $query_args;
	}
	public function add_query_args_to_request($link){
		
		//this is for when ajax is disabled & initial page load, passing query args into the `data-vc-request` attribute of the VC grid shortcode
	
		foreach($_GET as $key => $value){
			$link = add_query_arg($key, $value, $link);
		}
		
		remove_filter( "vc_grid_request_url", array($this, 'add_query_args_to_request'), 10, 2 );
		
		return $link;
		
	}
	
	private function get_search_form_options(){
		
		if(empty($this->search_form_options)){
			
			$custom_posts = new WP_Query('post_type=search-filter-widget&post_status=publish&posts_per_page=-1');
			
			if( $custom_posts->post_count > 0 ){
				foreach ($custom_posts->posts as $post){
					$this->search_form_options[html_entity_decode(get_the_title($post->ID))] = get_post_field( 'post_name', $post->ID );
				}
			}
		}
		
		return $this->search_form_options;
	}
	
	public function init_vc_mappings($mapping){
		
		$formid = "";
		
		//get search forms
		$search_form_options = $this->get_search_form_options();
		
		$search_forms_list = array();
		$search_forms_list["Choose a Search Form"] = "";
		$search_forms_list = array_merge($search_forms_list, $search_form_options);
				
		$search_form_param = array(
			"type" => "dropdown",
			'admin_label' => true,
			//'save_always' => true,
			//"holder" => "div",
			"class" => "",
			"heading" => __( "Search Form", "search-filter-wpb-pb" ),
			"param_name" => "slug",
			"value" => $search_forms_list /*,
			"description" => __( "Search Form Slug", "search-filter-wpb-pb" ) */
		);
		
		$vc_params = array(
			"name" => __( "Search & Filter Form", "search-filter-wpb-pb" ),
			"base" => "searchandfilter",
			"icon" => "search-filter-wpb-pb-backend-icon",
			'admin_enqueue_css' => array( plugins_url( 'css/vc-backend.css', __FILE__ ) ), //icons
			'front_enqueue_css' => array( plugins_url( 'css/vc-backend.css', __FILE__ ) ), //icons
			//"class" => "wn-bild",
			"category" => __( "Content", "search-filter-wpb-pb"),
			"params" => array(
				$search_form_param
			)
		);
		
		vc_map( $vc_params );
	}
	
	public function vc_add_params_to_elements($wp)
	{
		$search_form_options = $this->get_search_form_options();
		
		$search_forms_list = array();
		$search_forms_list["Choose a Search Form"] = "";
		$search_forms_list = array_merge($search_forms_list, $search_form_options);
		
		$search_form_param = array(
			"type" => "dropdown",
			'admin_label' => true,
			'weight' => 1,
			"class" => "",
			"heading" => __( "Choose a Search & Filter Query", "search-filter-wpb-pb" ),
			"param_name" => "search_filter_slug",
			"dependency" => array(
				'element' => 'post_type',
				'value' => array('search_filter')
				//'value' => array('Search & Filter'),
			),
			"value" => $search_forms_list /*,
			"description" => __( "Search Form Slug", "search-filter-wpb-pb" ) */
		);
		//$search_form_param['weight'] = 100;
		
		$shortcodes = $this->get_vc_shortcodes();
				
		$pagination_options = array();
		$pagination_options["None"] = "";
		$pagination_options["WordPress Pagination"] = "wp_pagination";
		
		$pagination_param = array(
			"type" => "dropdown",
			'admin_label' => true,
			'weight' => 1,
			"class" => "",
			"heading" => __( "Pagination", "search-filter-wpb-pb" ),
			"param_name" => "search_filter_pagination",
			"dependency" => array(
				'element' => 'post_type',
				'value' => array('search_filter')
			),
			"value" => $pagination_options /*,
			"description" => __( "Search Form Slug", "search-filter-wpb-pb" ) */
		);
		
		//$shortcodes = $this->get_vc_shortcodes();
				
		if(in_array("vc_basic_grid", $shortcodes))
		{
			vc_add_param( 'vc_basic_grid', $search_form_param );
			vc_add_param( 'vc_basic_grid', $pagination_param );
		}
		if(in_array("vc_masonry_grid", $shortcodes))
		{
			vc_add_param( 'vc_masonry_grid', $search_form_param );
			vc_add_param( 'vc_masonry_grid', $pagination_param );
		}
		
		if(in_array("vc_media_grid", $shortcodes)){
			
			//add a new drop down to trigger S&F for recent products element
			$link_with_search_form_param = array(
				"type" => "dropdown",
				'admin_label' => true,
				'weight' => 1,
				"class" => "",
				"heading" => __( "Connect with Search & Filter", "search-filter-wpb-pb" ),
				"param_name" => "search_filter_connect",
				/*"dependency" => array(
					'element' => 'post_type',
					'value' => array('search_filter')
					//'value' => array('Search & Filter'),
				),*/
				"value" => array ("No" => "no", "Yes" => "yes"),
				//"description" => __( "Connect to Search & Filter", "search-filter-wpb-pb" )
			);
			
			//modify the S&F query chooser to depend on this new dropdwon
			$search_form_param["dependency"] = array(
				'element' => 'search_filter_connect',
				'value' => array('yes')
			);
			$pagination_param["dependency"] = array(
				'element' => 'search_filter_connect',
				'value' => array('yes')
			);
			vc_add_param( 'vc_media_grid', $link_with_search_form_param );
			vc_add_param( 'vc_media_grid', $search_form_param );
			vc_add_param( 'vc_media_grid', $pagination_param );
		}
		
		if(in_array("vc_masonry_media_grid", $shortcodes)){
			
			//add a new drop down to trigger S&F for recent products element
			$link_with_search_form_param = array(
				"type" => "dropdown",
				'admin_label' => true,
				'weight' => 1,
				"class" => "",
				"heading" => __( "Connect with Search & Filter", "search-filter-wpb-pb" ),
				"param_name" => "search_filter_connect",
				/*"dependency" => array(
					'element' => 'post_type',
					'value' => array('search_filter')
					//'value' => array('Search & Filter'),
				),*/
				"value" => array ("No" => "no", "Yes" => "yes"),
				//"description" => __( "Connect to Search & Filter", "search-filter-wpb-pb" )
			);
			
			//modify the S&F query chooser to depend on this new dropdwon
			$search_form_param["dependency"] = array(
				'element' => 'search_filter_connect',
				'value' => array('yes')
			);
			$pagination_param["dependency"] = array(
				'element' => 'search_filter_connect',
				'value' => array('yes')
			);
			vc_add_param( 'vc_masonry_media_grid', $link_with_search_form_param );
			vc_add_param( 'vc_masonry_media_grid', $search_form_param );
			vc_add_param( 'vc_masonry_media_grid', $pagination_param );
		}
		
		if(in_array("products", $shortcodes))
		{
			//add a new drop down to trigger S&F for recent products element
			$link_with_search_form_param = array(
				"type" => "dropdown",
				'admin_label' => true,
				'weight' => 1,
				"class" => "",
				"heading" => __( "Connect with Search & Filter", "search-filter-wpb-pb" ),
				"param_name" => "search_filter_connect",
				/*"dependency" => array(
					'element' => 'post_type',
					'value' => array('search_filter')
					//'value' => array('Search & Filter'),
				),*/
				"value" => array ("No" => "no", "Yes" => "yes"),
				//"description" => __( "Connect to Search & Filter", "search-filter-wpb-pb" )
			);
			
			//modify the S&F query chooser to depend on this new dropdwon
			$search_form_param["dependency"] = array(
				'element' => 'search_filter_connect',
				'value' => array('yes')
			);
			$pagination_param["dependency"] = array(
				'element' => 'search_filter_connect',
				'value' => array('yes')
			);
			vc_add_param( 'products', $link_with_search_form_param );
			vc_add_param( 'products', $search_form_param );
			vc_add_param( 'products', $pagination_param );
			
		}
	}
	
	public function get_vc_shortcodes(){
		
		if(empty($this->vc_shortcodes))
		{
			$shortcodes_objects = WPBMap::getAllShortCodes();
			$shortcodes = array();
			
			foreach($shortcodes_objects as $shortcode_key => $shortecode)
			{
				array_push($shortcodes, $shortcode_key);
			}
			$this->vc_shortcodes = $shortcodes;
		}
		return $this->vc_shortcodes;
	}
	
	public function vc_edit_element_params($wp){
		
		
		$shortcodes = $this->get_vc_shortcodes();
		
		if(in_array("vc_basic_grid", $shortcodes))
		{
			$this->init_grid_widget("vc_basic_grid");
		}
		if(in_array("vc_masonry_grid", $shortcodes))
		{
			$this->init_grid_widget("vc_masonry_grid");
		}
		if(in_array("vc_media_grid", $shortcodes))
		{
			$this->init_media_grid_widget("vc_media_grid");
		}
		if(in_array("vc_masonry_media_grid", $shortcodes))
		{
			$this->init_media_grid_widget("vc_masonry_media_grid");
		}
		if(in_array("products", $shortcodes))
		{
			$this->init_products_widget("products");
		}
	}
	
	public function init_grid_widget($widget_name){
		
		//add a new option for 
		$post_type_param = WPBMap::getParam( $widget_name, 'post_type' );
		
		if(!$post_type_param)
		{
			return;
		}
		
		$options = $post_type_param['value'];
		
		if((is_array($options))&&(!empty($options)))
		{
			//be nice, remove "search-filter-widget" as an option from the dropdown
			$index = 0;
			$search_pos = -1;
			foreach($options as $option)
			{
				if($option[0]=="search-filter-widget")
				{
					$search_pos = $index;
				}
				
				$index++;
			}
			
			if($search_pos!==-1)
			{//found, so remove
				unset($options[$search_pos]);
			}
			
			//add a Search & Filter option to the dropdown
			array_push($options, array("search_filter", "Search & Filter Query"));
			$post_type_param['weight'] = 2; //set the weight of  this param so its above S&F which is set to 1
			$post_type_param['value'] = $options;
			
			//now tell VC the param is updated
			vc_update_shortcode_param( $widget_name, $post_type_param );
		}
		
		//make sure the taxonomies param does not get shown when the Search & Filter data source has been set, by adding it to the "exclude" dependency list
		$taxonomies_param = WPBMap::getParam( $widget_name, 'taxonomies' );		
		if(isset($taxonomies_param['dependency']))
		{
			if(isset($taxonomies_param['dependency']['value_not_equal_to']))
			{
				array_push($taxonomies_param['dependency']['value_not_equal_to'], "search_filter");
			}
		}
		
		vc_update_shortcode_param( $widget_name, $taxonomies_param );
		
		//make sure the total items is hidden too as this is controlled by S&F setting "results per page"
		$total_param = WPBMap::getParam( $widget_name, 'max_items' );		
		if(isset($total_param['dependency']))
		{
			if(isset($total_param['dependency']['value_not_equal_to']))
			{
				array_push($total_param['dependency']['value_not_equal_to'], "search_filter");
			}
		}
		vc_update_shortcode_param( $widget_name, $total_param );
		
		$style_param = WPBMap::getParam( $widget_name, 'style' );
		
		if(isset($style_param['dependency']))
		{
			if(isset($style_param['dependency']['value_not_equal_to']))
			{
				array_push($style_param['dependency']['value_not_equal_to'], "search_filter");
			}
		}
		vc_update_shortcode_param( $widget_name, $style_param );
		
		$show_filter_param = WPBMap::getParam( $widget_name, 'show_filter' );
		
		if(!isset($show_filter_param['dependency'])) {
			$show_filter_param['dependency'] = array();
		}
		$show_filter_param['dependency']['element'] = 'post_type';
		$show_filter_param['dependency']['value_not_equal_to'] = 'search_filter';
		
		vc_update_shortcode_param( $widget_name, $show_filter_param );
	}
	
	public function init_products_widget($widget_name){
		
		//update per_page dependency - only show it if S&F is not connected
		$per_page_param = WPBMap::getParam( $widget_name, 'per_page' );
		
		if($per_page_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($per_page_param['dependency'])){
				$per_page_param['dependency'] = array();
				$per_page_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($per_page_param['dependency']['value_not_equal_to']))
			{
				$per_page_param['dependency']['element'] = 'search_filter_connect';
				array_push($per_page_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $per_page_param );
		}
		
		//update orderby dependency - only show it if S&F is not connected
		$orderby_param = WPBMap::getParam( $widget_name, 'orderby' );
		
		if($orderby_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($orderby_param['dependency'])){
				$orderby_param['dependency'] = array();
				$orderby_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($orderby_param['dependency']['value_not_equal_to']))
			{
				$orderby_param['dependency']['element'] = 'search_filter_connect';
				array_push($orderby_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $orderby_param );
		}
		
		//update order dependency - only show it if S&F is not connected
		$order_param = WPBMap::getParam( $widget_name, 'order' );
		
		if($order_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($order_param['dependency'])){
				$order_param['dependency'] = array();
				$order_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($order_param['dependency']['value_not_equal_to']))
			{
				$order_param['dependency']['element'] = 'search_filter_connect';
				array_push($order_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $order_param );
		}
		
		
		//update ids dependency - only show it if S&F is not connected
		$ids_param = WPBMap::getParam( $widget_name, 'ids' );
		
		if($ids_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($ids_param['dependency'])){
				$ids_param['dependency'] = array();
				$ids_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($ids_param['dependency']['value_not_equal_to']))
			{
				$ids_param['dependency']['element'] = 'search_filter_connect';
				array_push($ids_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $ids_param );
		}
		
		
	}
	public function init_media_grid_widget($widget_name){
		
		//update per_page dependency - only show it if S&F is not connected
		$images_param = WPBMap::getParam( $widget_name, 'include' );
		
		if($images_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($images_param['dependency'])){
				$images_param['dependency'] = array();
				$images_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($images_param['dependency']['value_not_equal_to']))
			{
				$images_param['dependency']['element'] = 'search_filter_connect';
				array_push($images_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $images_param );
			
			//style = all
			
			
		}
		
		//update style dependency - only show it if S&F is not connected
		$style_param = WPBMap::getParam( $widget_name, 'style' );
		
		if($style_param){
			
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($style_param['dependency'])){
				$style_param['dependency'] = array();
				$style_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($style_param['dependency']['value_not_equal_to']))
			{
				$style_param['dependency']['element'] = 'search_filter_connect';
				array_push($style_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $style_param );
		}
		
		//update order dependency - only show it if S&F is not connected
		$order_param = WPBMap::getParam( $widget_name, 'order' );
		
		if($order_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($order_param['dependency'])){
				$order_param['dependency'] = array();
				$order_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($order_param['dependency']['value_not_equal_to']))
			{
				$order_param['dependency']['element'] = 'search_filter_connect';
				array_push($order_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $order_param );
		}
		
		
		//update ids dependency - only show it if S&F is not connected
		$ids_param = WPBMap::getParam( $widget_name, 'ids' );
		
		if($ids_param){
			//update per_page dependency - only show it if S&F is not connected
			if(!isset($ids_param['dependency'])){
				$ids_param['dependency'] = array();
				$ids_param['dependency']['value_not_equal_to'] = array();
			}		
			if(isset($ids_param['dependency']['value_not_equal_to']))
			{
				$ids_param['dependency']['element'] = 'search_filter_connect';
				array_push($ids_param['dependency']['value_not_equal_to'], "yes");
			}
			
			vc_update_shortcode_param( $widget_name, $ids_param );
		}
		
		
	}
	
	/**
	 * Handle plugin updates
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function update_plugin_handler() {
		
		// setup the updater
		$edd_updater = new Search_Filter_WPB_PB_Plugin_Updater( self::PLUGIN_UPDATE_URL, __FILE__,
			array(
				'version' => self::VERSION,
				'license' => 'search-filter-extension-free',
				'item_id' => self::PLUGIN_UPDATE_ID,       // ID of the product
				'author'  => 'Search & Filter', // author of this plugin
				'beta'    => false,
			)
		);
		
	}
}


if( !class_exists( 'Search_Filter_WPB_PB_Plugin_Updater' ) ) {
	// load our custom updater
	include( dirname( __FILE__ ) . '/search-filter-wpb-pb-plugin-updater.php' );
}
