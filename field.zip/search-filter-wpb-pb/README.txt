=== Search & Filter Pro - WPBakery Page Builder Extension ===
Contributors: CodeAmp
Donate link:
Tags: 
Requires at least: 3.5
Tested up to: 5.4
Stable tag: 1.0.1

Adds Search & Filter integration for WPBakery Page Builder - integrates with the Post Grid, Post Masonry Grid, Media Grid, Masonry Media Grid & Products elements

== Description ==

Adds Search & Filter integration for WPBakery Page Builder - integrates with the Post Grid, Post Masonry Grid, Media Grid, Masonry Media Grid & Products elements


== Installation ==

= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `search-filter-wpb-pb.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard


= Using FTP =

1. Download `search-filter-wpb-pb.zip`
2. Extract the `search-filter-wpb-pb` directory to your computer
3. Upload the `search-filter-wpb-pb` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0.1 =
* Fix - an issue where the query for our search forms was not being reset - causing undesirable side effects when displaying certain post types

= 1.0.0 = 
* Initial release

== Upgrade Notice ==
