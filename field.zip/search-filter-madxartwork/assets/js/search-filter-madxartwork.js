( function ( $ ) {
	"use strict";
	$( function () {
		// re init layout after ajax request
		$( document ).on( "sf:ajaxfinish", ".searchandfilter", function( e, data ) {
			if ( window.madxartworkFrontend && window.madxartworkFrontend.elementsHandler && window.madxartworkFrontend.elementsHandler.runReadyTrigger) {
				var runReadyTrigger = window.madxartworkFrontend.elementsHandler.runReadyTrigger;

				runReadyTrigger( data.targetSelector );
				var ajaxTarget = $( data.targetSelector );
				if ( ajaxTarget.length > 0 ) {
					// re-init the accordion js - madxartwork-widget-accordion
					ajaxTarget.find( '.madxartwork-widget' ).each( function () {
						runReadyTrigger( $( this ) );
					} );
				}
			}
		});
	});

	//Detects the end of an ajax request being made
	var forms = [];
	$(document).on("sf:ajaxfinish", ".searchandfilter", function( e, form ){
		var $form = $( '.searchandfilter[data-sf-form-id=' + form.sfid  + ']' )
		forms[ form.sfid ] = $form[0].innerHTML;
	});
	
	// load search forms in popups
	$( window ).on( 'madxartwork/frontend/init', function() {
		// Search forms in popups reset to their page load state every time they are shown.
		// So we need to keep track of the latest one, and reload it into the popup when it is shown.
		if ( window.madxartworkFrontend ) {
			window.madxartworkFrontend.elements.$window.on( 'madxartwork/popup/show', ( e, id, document ) => {
				if ( $().searchAndFilter ) {
					var $sliders = $( '.madxartwork-popup-modal .searchandfilter .meta-slider' );
					if ( $sliders.length > 0 ) {
						$sliders.empty();
					}

					// Get the forms ID:
					$( '.madxartwork-popup-modal .searchandfilter' ).each( function () {
						var $form = $( this );
						$form.off();
						var formId = $form.data( 'sf-form-id' );
						if ( forms[ formId ] ) {
							// Replace the form with the latest version:
							$form.html( forms[ formId ])
						}
						$form.searchAndFilter();

					} );
				}
			} );
		}
	});

}( jQuery ) );
