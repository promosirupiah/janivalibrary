<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class TextACFField extends ACFFieldBase {

	const TYPE = 'text';

}