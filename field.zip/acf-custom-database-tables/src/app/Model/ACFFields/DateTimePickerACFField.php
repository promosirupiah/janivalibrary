<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class DateTimePickerACFField extends ACFFieldBase {

	const TYPE = 'date_time_picker';

}