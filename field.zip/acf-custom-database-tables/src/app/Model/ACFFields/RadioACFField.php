<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class RadioACFField extends ACFFieldBase {

	const TYPE = 'radio';

}