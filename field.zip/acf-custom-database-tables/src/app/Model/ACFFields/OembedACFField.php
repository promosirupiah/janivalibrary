<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class OembedACFField extends ACFFieldBase {

	const TYPE = 'oembed';

}