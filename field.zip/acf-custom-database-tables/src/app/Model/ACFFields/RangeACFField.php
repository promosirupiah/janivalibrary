<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class RangeACFField extends ACFFieldBase {

	const TYPE = 'range';

}