<?php

_deprecated_file(
	__FILE__,
	'1.1',
	null,
	'Container definitions now reside in service providers. This file will be removed in version 1.2.' );