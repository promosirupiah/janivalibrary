=== Search & Filter - Beaver Builder Add-on ===
Contributors: DesignsAndCode
Donate link:
Tags: posts, custom posts, products, category, filter, taxonomy, beaver builder, bb, search & filter
Requires at least: 3.5
Tested up to: 5.4
Stable tag: 1.0.1

Bridge Plugin allowing for easy integration with Beaver Builder and Search & Filter

== Description ==

Bridge Plugin allowing for easy integration with Beaver Builder and Search & Filter


== Installation ==


= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `search-filter-bb.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard


= Using FTP =

1. Download `search-filter-bb.zip`
2. Extract the `search-filter-bb` directory to your computer
3. Upload the `search-filter-bb` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0.1 =
* Fix - Stop using `the_post()` and `wp_reset_postdata()` to loop through some of our queries - causes some very strange bugs
* Fix - an issue with "equal heights" option not being respected in BB Module settings
* Fix - an issue with our JS not firing when BB Posts Module Layout is set to "Columns"
* New - add support for BB pagination types: Numbers, Scroll, Load More
* New - add support for Gallery layout in Post Module

= 1.0.0 =
* Init release

== Upgrade Notice ==

