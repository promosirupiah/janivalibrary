<?php

/**
 * Render the search form
 */

?>
<?php echo do_shortcode("[searchandfilter id='".$settings->search_form_id."']"); ?>