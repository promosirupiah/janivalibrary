=== Search & Filter Pro - Divi Extension ===
Contributors: CodeAmp
Donate link:
Tags: posts, custom posts, products, category, filter, taxonomy, post meta, custom fields, search, wordpress, post type, post date, author
Requires at least: 4.0
Tested up to: 5.4
Stable tag: 1.0.3

A bridge Plugin enabling easy integration of the Divi Blog, Portfolio and Shop modules with Search & Filter Pro

== Description ==

A bridge Plugin enabling easy integration of the Divi Blog, Portfolio and Shop modules with Search & Filter Pro


== Installation ==


= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `search-filter-divi.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard


= Using FTP =

1. Download `search-filter-divi.zip`
2. Extract the `search-filter-divi` directory to your computer
3. Upload the `search-filter-divi` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0.3 =
* Fix an issue with custom CSS classes being lost with S&F results/modules

= 1.0.2 =
* Fix an issue with an option disappearing from the Blog module

= 1.0.1 =
* Fix an issue with the Shop module not being filtered

= 1.0.0 =
* Initial release

== Upgrade Notice ==

