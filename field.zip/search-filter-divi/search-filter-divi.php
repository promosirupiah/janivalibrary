<?php
/**
 * Plugin Name:       Search & Filter Pro - Divi Extension
 * Plugin URI:        https://searchandfilter.com
 * Description:       A bridge Plugin enabling easy integration of the Divi Blog, Portfolio and Shop modules with Search & Filter Pro
 * Version:           1.0.3
 * Author:            Code Amp
 * Author URI:        https://www.codeamp.com
 * Text Domain:       search-filter-divi
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path:       /languages
 */

/*----------------------------------------------------------------------------*
 * Public-Facing Functionality
 *----------------------------------------------------------------------------*/

add_action( 'plugins_loaded', array( 'Search_Filter_Divi', 'get_instance' ) );


if ( ! defined( 'SEARCH_FILTER_DIVI_PATH' ) ) {
	define('SEARCH_FILTER_DIVI_PATH', plugin_dir_path(__FILE__));
}
if ( ! defined( 'SEARCH_FILTER_DIVI_URL' ) ) {
	define('SEARCH_FILTER_DIVI_URL', plugin_dir_url(__FILE__));
}

Class Search_Filter_Divi {
	
	const VERSION = '1.0.3';
	
	const PLUGIN_UPDATE_URL = 'https://searchandfilter.com';
	const PLUGIN_UPDATE_ID = 197854; 
	
	protected static $instance = null;
	
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}
	
	
	private function __construct() {
		
		// Init Divi extenion
		add_action( 'divi_extensions_init', array($this, 'initialise_divi_extension' ) );
		
		// Scripts
		add_action('wp_enqueue_scripts', array($this, "enqueue_scripts"), 10);
		
		// Plugin Updater
		add_action( 'admin_init', array($this, 'update_plugin_handler'), 0 );
	}
	
	/**
	 * Load Scripts
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function enqueue_scripts(){	
	
		wp_register_script( 'search-filter-divi', plugins_url( 'scripts/search-filter-divi.js', __FILE__ ), array( 'jquery' ), "1.0.0" );
		wp_localize_script( 'search-filter-divi', 'SFE_DATA', array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'home_url' => (home_url('/')) ));
		wp_enqueue_script( 'search-filter-divi' );
	}
	
	/**
	 * Init Divi Extension
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function initialise_divi_extension() {
		
		require_once plugin_dir_path( __FILE__ ) . 'includes/search-filter-divi-extension.php';
	}
	
	/**
	 * Handle plugin updates
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function update_plugin_handler() {
		
		// setup the updater
		$edd_updater = new Search_Filter_Divi_Plugin_Updater( self::PLUGIN_UPDATE_URL, __FILE__,
			array(
				'version' => self::VERSION,
				'license' => 'search-filter-extension-free',
				'item_id' => self::PLUGIN_UPDATE_ID,       // ID of the product
				'author'  => 'Search & Filter', // author of this plugin
				'beta'    => false,
			)
		);
		
	}
	
}

if( !class_exists( 'Search_Filter_Divi_Plugin_Updater' ) ) {
	// load our custom updater
	include( dirname( __FILE__ ) . '/search-filter-divi-plugin-updater.php' );
}

if( !class_exists( 'Search_Filter_Divi_Query' ) ) {
	include( dirname( __FILE__ ) . '/includes/search-filter-divi-query.php' );
}
