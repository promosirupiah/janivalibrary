<?php

namespace ACA\GravityForms;

interface MetaTypes {

	const GRAVITY_FORMS_ENTRY = 'gravity_forms_entry';

}