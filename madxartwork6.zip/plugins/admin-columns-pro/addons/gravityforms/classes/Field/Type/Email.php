<?php

namespace ACA\GravityForms\Field\Type;

class Email extends Input {

	/**
	 * @return string
	 */
	public function get_input_type() {
		return 'email';
	}

}