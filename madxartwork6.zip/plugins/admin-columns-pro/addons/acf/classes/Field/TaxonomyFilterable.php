<?php

namespace ACA\ACF\Field;

interface TaxonomyFilterable {

	/**
	 * @return array
	 */
	public function get_taxonomies();

}