<?php

namespace ACA\ACF\Field;

interface DisplayFormat {

	/**
	 * @return string
	 */
	public function get_display_format();

}