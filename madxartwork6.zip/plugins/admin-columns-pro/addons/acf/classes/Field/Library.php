<?php

namespace ACA\ACF\Field;

interface Library {

	/**
	 * @return bool
	 */
	public function is_upload_media_only();

}