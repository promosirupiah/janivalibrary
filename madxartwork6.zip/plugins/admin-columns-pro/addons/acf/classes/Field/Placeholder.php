<?php

namespace ACA\ACF\Field;

interface Placeholder {

	/**
	 * @return string
	 */
	public function get_placeholder();

}