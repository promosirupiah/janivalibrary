<?php

namespace ACA\BP\Field\Profile;

class Selectbox extends Radio {

}