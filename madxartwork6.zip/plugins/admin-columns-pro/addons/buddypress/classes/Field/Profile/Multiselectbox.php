<?php

namespace ACA\BP\Field\Profile;

class Multiselectbox extends Checkbox {

}