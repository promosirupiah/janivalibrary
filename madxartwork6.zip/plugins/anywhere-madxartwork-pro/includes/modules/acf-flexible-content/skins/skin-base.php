<?php
namespace Aepro\Modules\AcfFlexibleContent\Skins;

use Aepro\Aepro;
use madxartwork\Icons_Manager;
use madxartwork\Plugin;
use madxartwork\Controls_Manager;
use madxartwork\Widget_Base;
use madxartwork\Skin_Base as madxartwork_Skin_Base;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

abstract class Skin_Base extends madxartwork_Skin_Base {

	//phpcs:ignore PSR2.Methods.MethodDeclaration.Underscore
	protected function _register_controls_actions() {
	}

	public function register_controls( Widget_Base $widget ) {

		$this->parent = $widget;
	}
}
