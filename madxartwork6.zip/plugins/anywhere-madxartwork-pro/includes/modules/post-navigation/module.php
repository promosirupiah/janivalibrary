<?php

namespace Aepro\Modules\PostNavigation;

use Aepro\Base\ModuleBase;

class Module extends ModuleBase {

	public function get_widgets() {
		return [
			'ae-post-navigation',
		];
	}

}
