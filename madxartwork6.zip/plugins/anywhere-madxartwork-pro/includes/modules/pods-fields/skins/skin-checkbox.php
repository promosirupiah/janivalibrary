<?php

namespace Aepro\Modules\PodsFields\Skins;

use Aepro\Modules\PodsFields;
use Aepro\Classes\PodsMaster;
use madxartwork\Group_Control_Box_Shadow;
use Aepro\Base\Widget_Base;
use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Typography;
use madxartwork\Group_Control_Border;


class Skin_Checkbox extends Skin_Select {

	public function get_id() {
		return 'checkbox';
	}

	public function get_title() {
		return __( 'Checkbox', 'ae-pro' );
	}


	public function register_controls( Widget_Base $widget ) {

		$this->parent = $widget;

		parent::register_select_controls();
	}

}
