<?php
namespace Aepro;

use Aepro\Classes\CacheManager;
use madxartwork\Core\Common\Modules\Finder\Base_Category;


class Aep_Finder extends Base_Category {

	public function get_title() {
		return __( 'Anywhere madxartwork Pro', 'ae-pro' );
	}

	public function get_category_items( array $options = [] ) {

		$items = CacheManager::instance()->get_finder_items();

		return $items;
	}
}
