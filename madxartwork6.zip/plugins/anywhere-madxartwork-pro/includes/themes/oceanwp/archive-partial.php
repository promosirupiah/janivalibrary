<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme and one of the
 * two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * For example, it puts together the home page when no home.php file exists.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package OceanWP WordPress theme
 */
get_header(); ?>

    <?php do_action('ocean_before_content_wrap'); ?>

    <div id="content-wrap" class="container clr">

        <?php do_action('ocean_before_primary'); ?>

        <div id="primary" class="content-area clr">

            <?php do_action('ocean_before_content'); ?>

            <div id="content" class="site-content clr">

                <?php do_action('ocean_before_content_inner'); ?>

                <?php
                // Check if posts exist
                if (have_posts() ) :
                    ?>

                    <?php /* Start the Loop */ ?>
                    <?php
                    while ( have_posts() ) :
                        the_post();
                        ?>
                        <div id="blog-entries" class="<?php oceanwp_blog_wrap_classes(); ?>">
                      <?php //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <?php echo do_action('aepro_archive_data', get_the_content()); ?>
                        </div><!-- #blog-entries -->

                    <?php endwhile; ?>
                    <?php
                    // No posts found
                else :
                    ?>

                    <?php
                    // Display no post found notice
                    get_template_part('partials/none');
                    ?>

                <?php endif; ?>

                <?php do_action('ocean_after_content_inner'); ?>

            </div><!-- #content -->

            <?php do_action('ocean_after_content'); ?>

        </div><!-- #primary -->

        <?php do_action('ocean_after_primary'); ?>

    </div><!-- #content-wrap -->

    <?php do_action('ocean_after_content_wrap'); ?>

<?php get_footer(); ?>
