<?php echo do_shortcode('[madxartwork-template id=6]'); 
echo '<script type="text/javascript" src="https://angkasajayaamerta.com/wp-content/plugins/madxartwork-pro/assets/lib/smartmenus/jquery.smartmenus.min.js"></script>';
//echo "<link href='https://angkasajayaamerta.com/wp-content/uploads/madxartwork/css/post-6.css' type='text/css' media='all' />";
echo '<!-- madxajaxcache -->'; 
?>