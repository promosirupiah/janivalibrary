<?php echo do_shortcode('[madxartwork-template id=97]'); 
//echo "<link href='https://angkasajayaamerta.com/wp-content/uploads/madxartwork/css/post-97.css' type='text/css' media='all' />";
echo '<!-- madxajaxcache -->'; ?>