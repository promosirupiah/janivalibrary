<?php
/**
 * The template for displaying the footer.
 *
 * Contains the body & html closing tags.
 *
 * @package Hellomadxartwork
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
if ( ! function_exists( 'madxartwork_theme_do_location' ) || ! madxartwork_theme_do_location( 'footer' ) ) {
	if ( did_action( 'madxartwork/loaded' ) && hello_header_footer_experiment_active() ) {
		get_template_part( 'template-parts/dynamic-footer' );
	} else {
		get_template_part( 'template-parts/footer' );
	}
} */


echo madxget('footer');
?>

<?php wp_footer(); ?>

</body>
</html>
