<?php

if (have_posts()) : while (have_posts()) : the_post(); 
$ID = get_the_ID();
$post = get_post($ID);
echo '<iframe src="'.get_bloginfo( 'siteurl' ).'/madxtemp/'.$post->post_name.'" style="width:100%;"></iframe><br>';
endwhile; endif;		
?>