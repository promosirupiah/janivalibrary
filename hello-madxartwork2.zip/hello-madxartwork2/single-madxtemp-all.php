<?php 
//get_header(); wp_head();
//global $post;

$args = array(
'showposts'   => 999,
'post_type' => 'madxtemp',
//'exclude' => $post->ID,
);

$posts = get_posts($args);
print_r($posts);
foreach ($posts as $madxtemp){
print_r($madxtemp);
echo '<iframe src="'.get_bloginfo( 'siteurl' ).'/madxtemp/'.$madxtemp->post_name.'" style="width:100%;"></iframe><br>';
//echo madxget($madxtemp->post_name);
//echo do_shortcode('[madxtemp name='.$madxtemp->post_name.']');
//echo '<br/>';
}



//wp_footer();
echo '<!-- madxajaxcache -->'; 

?>