<?php 
if (isset($_GET["header"])){wp_head();}
global $post;
echo do_shortcode($post->post_content);
//echo '<!-- madxajaxcache -->'; 
if (isset($_GET["footer"])){wp_footer();}
?>