<?php 
global $post;
echo do_shortcode($post->post_content);
//echo '<!-- madxajaxcache -->'; 
?>