<?php
/**
 * Plugin Name: YayMail Conditional Logic
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates with Conditional Logic
 * Version: 2.4.5
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 8.3.1
 * Domain Path: /i18n/languages/
 *
 * @package YayMailConditionalLogic
 */

namespace YayMailConditionalLogic;

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'YAYMAIL_CONDITIONAL_LOGIC_VERSION' ) ) {
	define( 'YAYMAIL_CONDITIONAL_LOGIC_VERSION', '2.4.5' );
}

if ( ! defined( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_FILE' ) ) {
	define( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_URL' ) ) {
	define( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_PATH' ) ) {
	define( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME' ) ) {
	define( 'YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/includes';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

add_action(
	'plugins_loaded',
	function() {
		if ( is_plugin_active( 'yaymail-addon-for-conditional-logic/yaymail-conditional-logic.php' ) ) {
			require_once plugin_dir_path( __FILE__ ) . 'includes/Backend/Fallback.php';
			add_action(
				'admin_init',
				function() {
					deactivate_plugins( 'yaymail-addon-for-conditional-logic/yaymail-conditional-logic.php' );
				}
			);
			return;
		}
	}
);

if ( ! function_exists( 'YayMailConditionalLogic\\plugins_loaded' ) ) {
	License::initialize();
	function plugins_loaded() {
		Backend\Enqueue::initialize();
		Backend\Actions::initialize();
		Core\ConditionalLogicController::getInstance();
	}
	add_action( 'plugins_loaded', 'YayMailConditionalLogic\\plugins_loaded' );
}
