<?php

namespace YayMailConditionalLogic\Backend;

defined( 'ABSPATH' ) || exit;

class Actions {

	public static function initialize() {
		add_filter( 'plugin_action_links_' . YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME, array( __CLASS__, 'yaymail_addon_add_action_links' ) );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'yaymail_addon_custom_plugin_row_meta' ), 10, 2 );
		add_action( 'after_plugin_row_' . YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME, array( __CLASS__, 'yaymail_addon_add_notification_after_plugin_row' ), 10, 2 );
	}

	public static function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

		if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
			$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
			?>
			<script>
			var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME ); ?>"]');
			plugin_row_element.classList.add('update');
			</script>
			<?php
			echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
			echo '<div class="notice inline notice-warning notice-alt"><p>';
			echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
                        </p>
                    </div>
                </td>
                </tr>';
		}

	}

	public static function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

		if ( strpos( $plugin_file, YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME ) !== false ) {
			$new_links = array(
				'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
				'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
			);

			$plugin_meta = array_merge( $plugin_meta, $new_links );
		}

		return $plugin_meta;
	}

	public static function yaymail_addon_add_action_links( $actions ) {

		if ( defined( 'YAYMAIL_PREFIX' ) ) {
			$links   = array(
				'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
			);
			$actions = array_merge( $links, $actions );
		}
		return $actions;
	}
}
