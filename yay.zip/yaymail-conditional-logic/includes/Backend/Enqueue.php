<?php

namespace YayMailConditionalLogic\Backend;

defined( 'ABSPATH' ) || exit;

class Enqueue {
    public static function initialize() {
		add_action( 'yaymail_enqueue_script_conditional_logic', array( __CLASS__, 'yaymail_dependence' ) );
	}

    public static function yaymail_dependence() {
        wp_enqueue_script( 'yaymail-conditional-logic', YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_URL . 'assets/dist/js/app.js', array(), YAYMAIL_CONDITIONAL_LOGIC_VERSION, true );
        wp_enqueue_style( 'yaymail-conditional-logic', YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_URL . 'assets/dist/css/app.css', array(), YAYMAIL_CONDITIONAL_LOGIC_VERSION );
    }
}