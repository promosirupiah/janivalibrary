<?php

namespace YayMailConditionalLogic;

defined( 'ABSPATH' ) || exit;

class License {
	public static function initialize() {
		add_filter( 'yaymail_available_licensing_plugins', array( __CLASS__, 'license_info' ) );
	}

	public static function license_info( $plugins ) {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$plugin_data    = get_plugin_data( YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_FILE );
		$plugin_version = $plugin_data['Version'];
		$plugin_name    = $plugin_data['Name'];
		$plugin_slug    = strtolower( str_replace( ' ', '_', $plugin_name ) );
		$plugins[]      = array(
			'name'     => $plugin_name,
			'slug'     => $plugin_slug,
			'dir_path' => YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_PATH,
			'basename' => YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_BASENAME,
			'url'      => 'https://yaycommerce.com/yaymail-addons/conditional-logic-addon-for-yaymail/',
			'file'     => YAYMAIL_CONDITIONAL_LOGIC_PLUGIN_FILE,
			'version'  => $plugin_version,
			'item_id'  => '8236',
		);
		return $plugins;
	}
}
