<?php

namespace YayMailConditionalLogic\Core;

defined( 'ABSPATH' ) || exit;

class ConditionalLogicController {
	protected static $instance = null;

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
			self::$instance->doHooks();
		}

		return self::$instance;
	}

	private function doHooks() {
		add_filter( 'yaymail_addon_get_updated_elements', array( $this, 'get_updated_elements' ), 10, 1 );
		add_filter( 'yaymail_addon_for_conditional_logic', array( $this, 'yaymail_addon_for_conditional_logic' ), 10, 3 );
	}

	public static function yaymail_addon_for_conditional_logic( $default_value, $args, $setting_row ) {
		if (empty ($setting_row['arrConditionLogic'])) {
			return true;
		}
		$logic_operator = isset($setting_row['conditionType']) ? $setting_row['conditionType']  : 'all';

		$is_showed = array_reduce($setting_row['arrConditionLogic'], function ($carry, $item) use ($args, $logic_operator) {
			$result = forward_static_call(['YayMailConditionalLogic\Core\ConditionalLogicHandle', 'check_condition'], $item, $args);

			if ($logic_operator == 'any') {
				return $carry || $result;
			} else {
				return $carry && $result;
			}
		}, $logic_operator == 'all');

		return $is_showed || $default_value;
	}

	public static function get_updated_elements( $element ) {
		$result = array_merge(
			$element,
			array(
				'Logo'              => array(
					'enableConditionalLogic' => false,
					'billingCountry'         => array(),
					'productCategories'      => array(),
					'orderMin'               => '',
					'orderMax'               => '',
					'arrConditionLogic'      => array(),
				),
				'ElementText'       => array(
					'arrConditionLogic' => array(),
				),
				'Images'            => array(
					'arrConditionLogic' => array(),
				),
				'Title'             => array(
					'arrConditionLogic' => array(),
				),
				'SocialIcon'        => array(
					'arrConditionLogic' => array(),
				),
				'Video'             => array(
					'arrConditionLogic' => array(),
				),
				'ImageList'         => array(
					'arrConditionLogic' => array(),
				),
				'ImageBox'          => array(
					'arrConditionLogic' => array(),
				),
				'TextList'          => array(
					'arrConditionLogic' => array(),
				),
				'HTMLCode'          => array(
					'arrConditionLogic' => array(),
				),
				'Space'             => array(
					'arrConditionLogic' => array(),
				),
				'Divider'           => array(
					'arrConditionLogic' => array(),
				),
				'OneColumn'         => array(
					'arrConditionLogic' => array(),
				),
				'TwoColumns'        => array(
					'arrConditionLogic' => array(),
				),
				'ThreeColumns'      => array(
					'arrConditionLogic' => array(),
				),
				'FourColumns'       => array(
					'arrConditionLogic' => array(),
				),
				'ShippingAddress'   => array(
					'arrConditionLogic' => array(),
				),
				'BillingAddress'    => array(
					'arrConditionLogic' => array(),
				),
				'OrderItem'         => array(
					'arrConditionLogic' => array(),
				),
				'Hook'              => array(
					'arrConditionLogic' => array(),
				),
				'OrderItemDownload' => array(
					'arrConditionLogic' => array(),
				),
			)
		);
		return $result;
	}
}
