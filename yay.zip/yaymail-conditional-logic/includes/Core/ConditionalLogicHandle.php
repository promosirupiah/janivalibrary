<?php

namespace YayMailConditionalLogic\Core;

defined( 'ABSPATH' ) || exit;

class ConditionalLogicHandle {

	/**
	 * Check a specific condition based on the provided logic and arguments.
	 *
	 * This function evaluates a condition specified by the 'logic' key in the $condition array
	 * and delegates the actual condition checking to specific methods based on the 'logic' value.
	 *
	 * @param array $condition An array specifying the condition to check. It should have the following structure:
	 *   - comparingOperator: The operator used for comparison (e.g., "excludesAll").
	 *   - logic: The type of condition to check (e.g., "billing_country").
	 *   - name: A human-readable name for the condition (e.g., "Billing country").
	 *   - value: An array containing data relevant to the condition (specific to the logic).
	 *
	 * @param array $args An array of arguments and context used for evaluating the condition.
	 *   It may include contextual data like 'gift_card' and 'order'.
	 *
	 * @return boolean Returns the result of the condition check.
	 *   Returns `false` if the 'logic' value in the condition is not recognized.
	 *
	 * @see check_billing_country(), check_product_category(), check_product_ids(),
	 *      check_product_skus(), check_payment_method(), check_shipping_method(),
	 *      check_coupon_codes(), check_payment_status()
	 */
	public static function check_condition ( $condition, $args ) {
		$logic = isset($condition['logic']) ? $condition['logic'] : '';

		if ( function_exists( 'yith_ywgc_premium_init' ) ) {
			if ( isset( $args['gift_card'] ) && $args['gift_card'] instanceof \YWGC_Gift_Card_Premium ) {
				$args['order'] = wc_get_order( $args['gift_card']->order_id );
			}
		}
		if ( (! isset( $args['order'] ) && !isset($args['booking'])) || (isset($args['order'] ) && 'SampleOrder' === $args['order']) ) {
			return false;
		}
		
		$logic_functions = [
			'billing_country' => 'check_billing_country',
			'product_categories' => 'check_product_category',
			'products' => 'check_product_ids',
			'product_skus' => 'check_product_skus',
			'order_min' => 'check_order_min',
			'order_max' => 'check_order_max',
			'payment_methods' => 'check_payment_method',
			'shipping_methods' => 'check_shipping_method',
			'coupon_codes'=> 'check_coupon_codes',
			'payment_status' => 'check_payment_status'
		];
		
		if (isset($logic_functions[$logic])) {
			$function_name = $logic_functions[$logic];
			return self::$function_name($condition, $args);
		}
		
		return false;
	}
	
	/**
	 * Get the final result by applying a comparing operator to two arrays.
	 *
	 * - 'is': Returns true if at least one element in the needle_array appears in the hay_array.
	 * - 'isNot': Returns true if none of the elements in the needle_array appear in the hay_array.
	 * - 'containsAll': Returns true if all elements in the needle_array are present in the hay_array.
	 * - 'excludesAll': Returns true if not all elements in the needle_array appear in the hay_array.
	 *
	 * @param array $needle_array An array containing elements to be compared.
	 * @param array $hay_array An array in which elements are compared against the needle_array.
	 * @param string $logic The comparing operator to determine the result.
	 *
	 * @return bool The result of the comparison based on the chosen operator.
	 */
	public static function get_final_result_by_applying_comparing_operator( $needle_array, $hay_array, $logic ) {
		switch($logic) {
			case 'is': 
				/**
				 * Return true when at least 1 needle appears in haystack
				 */
				$result = count(array_intersect($needle_array, $hay_array)) > 0;
				break;
			case 'isNot': 
				/**
				 * Return true when none of the needles appear in haystack
				 */
				$result = count(array_intersect($needle_array, $hay_array)) === 0;
				break;
			case 'containsAll':
				/**
				 * Return true when all needles appear in haystack
				 */
				$result = true;
				foreach ($needle_array as $needle) {
					if (!in_array($needle, $hay_array)) {
						$result = false;
						break;
					}
				}
				break;

			case 'excludesAll':
				/**
				 *	Return true when not all of the needles appear in haystack
				 */
				$result = false;
				foreach ($needle_array as $needle) {
					if (!in_array($needle, $hay_array)) {
						$result = true;
						break;
					}
				}
				break;
			default: 
				$result = false;
				break;

		}
		return $result;

	}

	public static function check_billing_country( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$array_billing_country = $condition['value'];

		$order_billing_country    = $args['order']->get_billing_country();

		return self::get_final_result_by_applying_comparing_operator( $array_billing_country, array($order_billing_country), $condition['comparingOperator'] );
	}

	public static function check_product_category( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$criteria_product_category_ids = isset( $condition['value'] ) ?  $condition['value'] : null;

		$items                  = $args['order']->get_items();
		$order_product_category_ids = array();
		foreach ( $items as $key => $item ) {
			$product_id   = $item['product_id'];
			$terms        = get_the_terms( $product_id, 'product_cat' );
			foreach ( $terms as $term ) {
				if ( $term->parent ) {
					$parent_term              = get_term( $term->parent );
					$order_product_category_ids[] = $parent_term->term_id;
				}
				$order_product_category_ids[] = $term->term_id;
			}
		}

		return self::get_final_result_by_applying_comparing_operator( $criteria_product_category_ids, $order_product_category_ids, $condition['comparingOperator'] );
	}

	public static function check_order_min( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$value_order_min = $condition['value'];

		$order_total = $args['order']->get_total();

		$conditional_logic_result = ( $value_order_min <= $order_total );

		return $conditional_logic_result;
	}

	public static function check_order_max( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$value_order_max = $condition['value'];
		$order_total = $args['order']->get_total();

		$conditional_logic_result = ( $value_order_max >= $order_total );

		return $conditional_logic_result;
	}

	public static function check_payment_method( $condition, $args  ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$array_payment_method = $condition['value'];
		$payment_method           = $args['order']->get_payment_method();

		return self::get_final_result_by_applying_comparing_operator( $array_payment_method, array($payment_method), $condition['comparingOperator'] );

	}

	public static function check_shipping_method( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$array_shipping_method = $condition['value'];

		$shipping_data_method_ids = [];
		foreach ( $args['order']->get_items( 'shipping' ) as $item_id => $item ) {
			$item_data               = $item->get_data();
			$shipping_data_method_ids[] = $item_data['method_id'];
		}

		return self::get_final_result_by_applying_comparing_operator( $array_shipping_method, $shipping_data_method_ids, $condition['comparingOperator'] );
	}

	public static function check_coupon_codes( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$array_coupon_codes = array_map('strtolower',$condition['value']);

		$coupon_codes = array_map('strtolower',$args['order']->get_coupon_codes());

		return self::get_final_result_by_applying_comparing_operator( $array_coupon_codes, $coupon_codes, $condition['comparingOperator'] );

	}

	public static function check_product_ids( $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$line_items          = $args['order']->get_data()['line_items'];

		$line_items = array_values( array_map( function($item) {
			if (isset( $item->get_data()['product_id'])) {
				return  $item->get_data()['product_id'];
			} else {
				return -1;
			}
		} , $line_items));

		$condition_products_ids = array_map ( function ($product) {
			if (isset ($product['id'])) {
				return $product['id'];
			} else {
				return -2;
			}
		},  $condition ['value']);

		return self::get_final_result_by_applying_comparing_operator( $condition_products_ids, $line_items, $condition['comparingOperator'] );

	}

	public static function check_product_skus(  $condition, $args ) {
		if ( empty( $condition ) ) {
			return false;
		}

		$line_items = $args['order']->get_data()['line_items'];

		$order_product_skus = [];
		if ( $line_items ) {
			foreach ( $line_items as $key => $line_item ) {
				if ( ! isset( $line_item->get_data()['product_id'] ) ) {
					continue;
				}

				if (isset( $line_item->get_data()['variation_id'] ) && $line_item->get_data()['variation_id'] !== 0) {
					$variation_id = $line_item->get_data()['variation_id'];
					$sku_meta = get_post_meta($variation_id, '_sku', true);
				} 
				if (!isset($sku_meta) || empty($sku_meta)) {
					$product_id = $line_item->get_data()['product_id'];
					$sku_meta = get_post_meta( $product_id, '_sku', true );
				}
				$order_product_skus[] = $sku_meta;
				unset($sku_meta);
			}
		}

		return self::get_final_result_by_applying_comparing_operator( $condition['value'], $order_product_skus, $condition['comparingOperator'] );

	}

	public static function check_payment_status( $condition, $args ) {

		if ( empty( $condition ) ) {
			return false;
		}

		if ( ! empty( $args['booking'] ) && ! empty( $args['booking']->get_data()['order_id'] ) ) {
			$order = wc_get_order( $args['booking']->get_data()['order_id'] );
		} elseif ( ! empty( $args['order'] ) ) {
			$order = $args['order'];
		}

		$conditional_values = $condition['value'];
		if ( empty( $conditional_values ) ) {
			return false;
		}

		// map all values to lowercase
		$lowercase_conditional_values = array_map(
			function( $value ) {
				return strtolower( $value );
			},
			$conditional_values
		);

		$order_status = $order->get_data()['status'];

		if ($order_status !== 'pending') {
			$order_status = 'processing';
		}

		return self::get_final_result_by_applying_comparing_operator( $lowercase_conditional_values, array($order_status), $condition['comparingOperator'] );
	}
}
