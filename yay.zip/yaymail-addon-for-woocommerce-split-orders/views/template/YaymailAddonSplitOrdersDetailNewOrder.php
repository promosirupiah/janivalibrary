<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_align         = is_rtl() ? 'right' : 'left';
$text_link_color    = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
$yaymail_settings   = get_option( 'yaymail_settings' );
$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
$titleProduct       = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleQuantity      = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Quantity';
$titlePrice         = isset( $attrs['titlePrice'] ) ? $attrs['titlePrice'] : 'Price';
$borderColor        = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor          = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleColor         = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
?>
<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; 
	<?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; 
	<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; 
  "
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
>
	<tbody>
		<tr>
			<td
				id="web-<?php echo esc_attr( $id ); ?>-order-item"
				class="web-order-item"
				align="left"
				style='font-size: 13px; line-height: 22px; word-break: break-word;
				<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
				<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
				'
			>
			<div style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
				
				<?php 
                    $before = '<h2  style="margin-bottom: 15px;font-size:18px;' . esc_attr( $titleColor ) . '"><a style="font-weight: normal;' . esc_attr( $titleColor ) . '" class="yaymail_builder_link" href="' . esc_url( $order->get_edit_order_url() ) . '">';
                    $after  = '</a>';
                    /* translators: %s: Order ID. */
                    echo wp_kses_post( $before . sprintf( __( '[Order #%s]', 'woocommerce' ) . $after . ' (<time datetime="%s">%s</time>)</h2>', $order->get_order_number(), $order->get_date_created()->format( 'c' ), wc_format_datetime( $order->get_date_created() ) ) );
                ?>
				
				<table cellspacing="0" cellpadding="6" border="1" style="width:100%;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
					<thead>
						<tr style="<?php echo esc_attr( $textColor ); ?>">
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleProduct, 'yaymail' ); ?></th>
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleQuantity, 'yaymail' ); ?></th>
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titlePrice, 'yaymail' ); ?></th>
						</tr>
					</thead>
					<tbody> <?php
                    foreach ( $items as $item_id => $item ) :
                        if ( apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {
                                            $product           = $item->get_product();
                                            $result_attributes = array();
                            ?>
                            <tr style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?> class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'order_item', $item, $order ) ); ?>">
                            <th class="td" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;font-weight: normal;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;">
                            <?php

                            if ( 'Bottom' == $orderImagePostions && '1' == $orderImage ) {
                                echo ( '<div class="yaymail-product-text" style="padding: 5px 0;">' );
                                // Product name
                                echo wp_kses_post( '<span class="yaymail-product-name" data-sku=' . $product->get_sku() . '>' . $item->get_name() . '</span>' );

                                // SKU
                                if ( $show_sku && is_object( $product ) && $product->get_sku() ) {
                                    echo wp_kses_post( '<span class="yaymail-product-sku"> (#' . $product->get_sku() . ')</span>' );
                                }
                                    // allow other plugins to add additional product information here
                                    do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order, $plain_text );

                                    // Display item meta data.
                                    wc_display_item_meta( $item );

                                    echo ( '</div>' );
                                // Show title/image etc
                                if ( $show_image && is_object( $product ) ) {
                                    echo wp_kses_post( apply_filters( 'woocommerce_order_item_thumbnail', '<div class="yaymail-product-image" style="margin-bottom: 5px"><img src="' . ( $product->get_image_id() ? current( wp_get_attachment_image_src( $product->get_image_id(), $image_size[2] ) ) : wc_placeholder_img_src() ) . '" alt="' . esc_attr__( 'Product image', 'woocommerce' ) . '" height="' . esc_attr( str_replace( 'px', '', $image_size[1] ) ) . '" width="' . esc_attr( str_replace( 'px', '', $image_size[0] ) ) . '" style="vertical-align:middle; margin-' . ( is_rtl() ? 'left' : 'right' ) . ': 10px;" /></div>', $item ) );
                                }
                            } else {
                                // Show title/image etc
                                if ( $show_image && is_object( $product ) ) {
                                    echo wp_kses_post( apply_filters( 'woocommerce_order_item_thumbnail', '<div class="yaymail-product-image" style="margin-bottom: 5px"><img src="' . ( $product->get_image_id() ? current( wp_get_attachment_image_src( $product->get_image_id(), $image_size[2] ) ) : wc_placeholder_img_src() ) . '" alt="' . esc_attr__( 'Product image', 'woocommerce' ) . '" height="' . esc_attr( str_replace( 'px', '', $image_size[1] ) ) . '" width="' . esc_attr( str_replace( 'px', '', $image_size[0] ) ) . '" style="vertical-align:middle; margin-' . ( is_rtl() ? 'left' : 'right' ) . ': 10px;" /></div>', $item ) );
                                }
                                echo ( '<div style="padding: 5px 0;">' );
                                // Product name
                                echo wp_kses_post( '<span class="yaymail-product-name" data-sku=' . $product->get_sku() . '>' . $item->get_name() . '</span>' );

                                // SKU
                                if ( $show_sku && is_object( $product ) && $product->get_sku() ) {
                                    echo wp_kses_post( '<span class="yaymail-product-sku"> (#' . $product->get_sku() . ')</span>' );
                                }
                                    // allow other plugins to add additional product information here
                                    do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order, $plain_text );

                                    // Display item meta data.
                                    wc_display_item_meta( $item );

                                    echo ( '</div>' );
                            }


                            // Display item download links.
                            if ( $show_download_links ) {
                                wc_display_item_downloads( $item );
                            }

                            // allow other plugins to add additional product information here
                            do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order, $plain_text );
                            ?>

                                </th>
                                <th class="td" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;">
                            <?php echo wp_kses_post( apply_filters( 'woocommerce_email_order_item_quantity', $item->get_quantity(), $item ) ); ?>
                                </th>
                                <th class="td" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;font-weight: normal;vertical-align: middle;padding: 12px;font-size: 14px; word-break: break-all;">
                            <?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?>
                                </th>
                            </tr>
                            <?php
                        }
                       ?>

                    <?php endforeach; ?>

					</tbody>
                    <tfoot>
                        <?php
                        $item_totals = $order->get_order_item_totals();

                        if ( $item_totals ) {
                            $i = 0;
                            foreach ( $item_totals as $total ) {
                                $i++;
                                ?>
                                <tr>
                                    <th class="td" scope="row" colspan="2" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>; <?php echo ( 1 === $i ) ? 'border-top-width: 4px;' : ''; ?>"><?php echo wp_kses_post( $total['label'] ); ?></th>
                                    <td class="td" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>; <?php echo ( 1 === $i ) ? 'border-top-width: 4px;' : ''; ?>"><?php echo wp_kses_post( $total['value'] ); ?></td>
                                </tr>
                                <?php
                            }
                        }
                        if ( $order->get_customer_note() ) {
                            ?>
                            <tr>
                                <th class="td" scope="row" colspan="2" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Note:', 'woocommerce' ); ?></th>
                                <td class="td" style="border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo wp_kses_post( nl2br( wptexturize( $order->get_customer_note() ) ) ); ?></td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tfoot>
				</table>
			</div>
		</td>
	  </tr>
	</tbody>
</table>