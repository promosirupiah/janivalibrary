<?php
	$yaymail_settings   = get_option( 'yaymail_settings' );
	$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
	$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
	$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
	$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
	$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
				<div
				class="yaymail-items-order-border"
					style="min-height: 10px"
					:style="{
					color: emailContent.settingRow.textColor,
					borderColor: emailContent.settingRow.borderColor,
					}"
				>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}">
						<?php $before = '<a style="font-weight: normal;" class="yaymail_builder_link" href="">';
                            $after  = '</a>';
                            /* translators: %s: Order ID. */
                            echo wp_kses_post( $before . sprintf( __( '[Order #%s]', 'woocommerce' ) . $after . ' (<time datetime="%s">%s</time>)', 1, new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ) );
                        ?>
					</h2>
					<table cellspacing="0" cellpadding="6" class="yaymail_builder_table_items_content" style="border-collapse: separate;width: 100%;border-width: 1px;border-style: solid;" :style="{'border-color' : emailContent.settingRow.borderColor}" border="1" bordercolor="#eee">
						<thead>
						<tr :style="{'color' : emailContent.settingRow.textColor}">
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;<?php echo esc_attr( $borderColor ); ?>">{{emailContent.settingRow.titleProduct}}</th>
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;<?php echo esc_attr( $borderColor ); ?>">{{emailContent.settingRow.titleQuantity}}</th>
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;<?php echo esc_attr( $borderColor ); ?>">{{emailContent.settingRow.titlePrice}}</th>
						</tr>
						</thead>
                        <tbody>
                            <tr>
                                <th class="td" scope="row" style="font-weight: normal;text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( 'Happy YayCommerce1', 'yaymail' ); ?>
                                </th>
                                <th class="td" scope="row" style="font-weight: normal;text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( 1, 'yaymail' ); ?>
                                <th class="td" scope="row" style="font-weight: normal;text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( '£18.00', 'yaymail' ); ?>
                                </th>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th class="td yaymail_item_subtoltal_title" scope="row" colspan="2" style="text-align:left;font-weight: bold;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?> ;border-top-width: 4px;">
                                    <?php esc_html_e( 'Subtotal:', 'woocommerce' ); ?>
                                </th>
                                <th class="td" scope="row" colspan="1" style="font-weight: normal;text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>; border-top-width: 4px;">
                                    <?php esc_html_e( '£18.00', 'yaymail' ); ?>
                                </th>
                            </tr>
                            <tr>
                                <th class="td yaymail_item_payment_method_title" scope="row" colspan="2" style="text-align:left; font-weight: bold;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( 'Payment method:', 'woocommerce' ); ?>
                                </th>
                                <th class="td" scope="row" colspan="1" style="font-weight: normal;text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( 'Direct bank transfer', 'woocommerce' ); ?>
                                </th>
                            </tr>
                            <tr>
                                <th class="td yaymail_item_total_title" scope="row" colspan="2" style="text-align:left; font-weight: bold;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( 'Total:', 'woocommerce' ); ?>
                                </th>
                                <th class="td" scope="row" colspan="1" style="font-weight: normal;text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>;<?php echo esc_attr( $textColor ); ?>">
                                    <?php esc_html_e( '£18.00', 'yaymail' ); ?>
                                </th>
                            </tr>
                        </tfoot>
					</table>
				</div>
			</td>
		</tr>
	</tbody>
</table>