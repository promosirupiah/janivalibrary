<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Split Orders
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates for WooCommerce Split Orders plugin
 * Version: 1.0
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.4.1
 * Domain Path: /i18n/languages/
 */

namespace YayMailWooSplitOrders;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailWooSplitOrders\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YayMailWooSplitOrders\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailWooSplitOrders\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_dependence() {
	wp_enqueue_script( 'yaymail-split-orders', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.0', true );
	wp_enqueue_style( 'yaymail-split-orders', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.0' );
}



add_action( 'yaymail_before_enqueue_dependence', 'YayMailWooSplitOrders\\yaymail_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => 'Split_Orders', // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array( 'SplitOrdersDetailNewOrder' ), // CHANGE HERE => main-name required
			'template_name'    => array( 'customer_order_split'),
		);
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailWooSplitOrders\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {

	if ( 'Customer_Order_Split' == $key ) {
		$getHeading          = $value->heading;
		$defaultOrderSplit = templateDefault\DefaultOrderSplit::getTemplates( $value->id, $getHeading );
		return $defaultOrderSplit;
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateWooSubscription = array( 'customer_order_split');
		if ( in_array( $arrData[2], $templateWooSubscription ) ) {
			$arrData[0]->setOrderId( $arrData[1]['old_order']->get_id(), $arrData[1]['sent_to_admin'], $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( $arrData[1]['sent_to_admin'], $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function($result, $template ) {
		$templateWooSubscription = array( 'customer_order_split');
		if ( in_array( $template, $templateWooSubscription ) ) {
			return true;
		}
		return $result;
	}, 10, 2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( $component['plugin_name'] === 'Split_Orders' ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[$position]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates['split_orders'] = array_merge( isset( $addon_templates['split_orders'] ) ? $addon_templates['split_orders'] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Add new shortcode to shortcodes list
// add_filter(
// 	'yaymail_shortcodes',
// 	function( $shortcode_list ) {
// 		$shortcode_list[] = 'yaymail_addon_order_subscription';
// 		return $shortcode_list;
// 	},
// 	10,
// 	1
// );

// Create shortcode
// add_filter(
// 	'yaymail_do_shortcode',
// 	function( $shortcode_list, $yaymail_informations, $args = array() ) {
// 		$shortcode_list['[yaymail_addon_order_subscription]'] = yaymailAddonOrderSubscription( $yaymail_informations, $args );
// 		return $shortcode_list;
// 	},
// 	10,
// 	3
// );

// function yaymailAddonOrderSubscription( $yaymail_informations, $args = array() ) {
// 	ob_start();
// 	include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonOrderSubscription.php';
// 	$html = ob_get_contents();
// 	ob_end_clean();
// 	return $html;
// }
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
add_action( 'YaymailAddonSplitOrdersDetailNewOrderVue', 'YayMailWooSplitOrders\\yith_vendor_information_vue', 100, 5 );
function yith_vendor_information_vue( $order, $postID = '' ) {

	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonSplitOrdersDetailNewOrder.php';
	$html = ob_get_contents();
	ob_end_clean();

	echo $html;
}

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonSplitOrdersDetailNewOrder', 'YayMailWooSplitOrders\\yaymail_addon_yith_vendor_information', 100, 5 );
function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( isset( $args['new_order'] ) ) {
		$yaymail_settings = get_option( 'yaymail_settings' );
		$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
		$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
		$show_product_image            = isset( $yaymail_settings['product_image'] ) ? $yaymail_settings['product_image'] : 0;
		$show_product_sku              = isset( $yaymail_settings['product_sku'] ) ? $yaymail_settings['product_sku'] : 0;
		$default_args['image_size'][0] = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
		$default_args['image_size'][1] = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
		$default_args['image_size'][2] = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';

		$order = $args['new_order'];
		$items = $order->get_items();
		$show_download_links = $order->is_download_permitted() && ! false;
		$show_sku = $show_product_sku;
		$show_purchase_note = $order->is_paid() && ! false;
		$show_image = $show_product_image;
		$image_size = $default_args['image_size'];
		$plain_text = $args['plain_text'];
		$sent_to_admin = false;

		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonSplitOrdersDetailNewOrder.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	} else {
		echo wp_kses_post( '' );
	}
}




