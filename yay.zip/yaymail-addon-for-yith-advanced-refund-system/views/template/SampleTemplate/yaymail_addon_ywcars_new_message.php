<?php
/**
 * Email for admin notification of new message received.
 *
 * @author  Yithemes
 * @package yith-woocommerce-automatic-role-changer.premium\templates\emails
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

?>

    <p><?php echo esc_html__('Hi, You have received a new message.', 'yaymail'); ?></p>
    <div style="padding: 27px;" class="ywcars_refund_info_message_box">
        <div>
            <div class="ywcars_refund_info_message_author"><?php echo esc_html__('Shop Manager', 'yaymail'); ?></div>
            <span class="ywcars_refund_info_message_date"><?php echo esc_html__('00:00', 'yaymail'); ?></span>
        </div>
        <div class="ywcars_refund_info_message_body">
            <span><?php echo esc_html__('message', 'yaymail'); ?></span>
        </div>
		
    </div>
