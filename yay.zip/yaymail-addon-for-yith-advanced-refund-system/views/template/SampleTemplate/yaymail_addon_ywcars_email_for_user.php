<?php
/**
 * Email for user notification
 *
 * @author  Yithemes
 * @package yith-advanced-refund-system-for-woocommerce.premium\templates\emails
 */

?>
<p> <?php echo esc_html__('Hi, Your request #1 for order #2 has been successfully submitted. You will receive a reply soon.', 'yaymail')  ?> </p>