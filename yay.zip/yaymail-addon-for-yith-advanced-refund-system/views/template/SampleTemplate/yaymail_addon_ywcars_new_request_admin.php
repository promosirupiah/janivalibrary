<?php
/**
 * Email for user notification
 *
 * @author  Yithemes
 * @package yith-advanced-refund-system-for-woocommerce.premium\templates\emails
 */

?>
<p> <?php echo esc_html__('Hi Admin, there is a new Refund Request (#1) from user Pntrung on order #2', 'yaymail')  ?> </p>