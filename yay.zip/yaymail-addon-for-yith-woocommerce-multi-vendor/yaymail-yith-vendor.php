<?php
/**
 * Plugin Name: YayMail Addon for YITH WooCommerce Multi Vendor Premium
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize email templates for YITH WooCommerce Multi Vendor Premium plugin
 * Version: 1.4
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.4.1
 * Domain Path: /i18n/languages/
 */

namespace YayMailYithVendor;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailYithVendor\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

add_filter( 'plugin_row_meta', 'YayMailYithVendor\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailYithVendor\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );

function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_yith_vendor_dependence() {
	if ( function_exists( 'YITH_Vendors' ) ) {
		wp_enqueue_script( 'yaymail-yith-vendor', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.2', true );
		wp_enqueue_style( 'yaymail-yith-vendor', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.2' );
	}
}
add_action( 'yaymail_before_enqueue_dependence', 'YayMailYithVendor\\yaymail_yith_vendor_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		if ( function_exists( 'YITH_Vendors' ) ) {
			$plugins[] = array(
				'plugin_name'      => 'YITH_Vendors',
				'addon_components' => array( 'YithVendorInformation', 'YithVendorNewOrder', 'YithVendorOrderCommissionsPaid', 'YithVendorOrderCommissionsBulk', 'YithVendorRegistration' ), // main-name required
				'template_name'    => array(
					'cancelled_order_to_vendor',
					'commissions_paid',
					'commissions_unpaid',
					'new_order_to_vendor',
					'new_vendor_registration',
					'product_set_in_pending_review',
					'vendor_commissions_bulk_action',
					'vendor_commissions_paid',
					'vendor_new_account',
				),
			);
		}
		return $plugins;
	},
	10,
	1
);

/*
ACtion to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateYithVendor = array( 'cancelled_order_to_vendor', 'commissions_paid', 'commissions_unpaid', 'new_order_to_vendor', 'new_vendor_registration', 'product_set_in_pending_review', 'vendor_commissions_bulk_action', 'vendor_commissions_paid', 'vendor_new_account' );
		if ( in_array( $arrData[2], $templateYithVendor ) ) {
			$arrData[0]->setOrderId( $arrData[1]['order_number'], isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function($result, $template ) {
		$templateYithVendor = array( 'cancelled_order_to_vendor', 'commissions_paid', 'commissions_unpaid', 'new_order_to_vendor', 'new_vendor_registration', 'product_set_in_pending_review', 'vendor_commissions_bulk_action', 'vendor_commissions_paid', 'vendor_new_account' );
		if ( in_array( $template, $templateYithVendor ) ) {
			return true;
		}
		return $result;
	}, 10, 2
);

// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		if ( function_exists( 'YITH_Vendors' ) ) {
			$components = apply_filters( 'yaymail_plugins', array() );
			$position   = '';
			foreach ( $components as $key => $component ) {
				if ( $component['plugin_name'] === 'YITH_Vendors' ) {
					$position = $key;
					break;
				}
			}
			foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
				ob_start();
				do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
				$html = ob_get_contents();
				ob_end_clean();
				$addon_templates['yith_vendor'] = array_merge( isset( $addon_templates['yith_vendor'] ) ? $addon_templates['yith_vendor'] : array(), array( $component . 'Vue' => $html ) );
			}
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( function_exists( 'YITH_Vendors' ) ) {
			$shortcode_list[] = 'yaymail_addon_yith_vendor_new_account';
		}
		return $shortcode_list;
	},
	10,
	1
);

add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YITH Multi Vendor',
			'shortcode' => array(
				array( '[yaymail_addon_yith_vendor_new_account]', 'New Account' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( function_exists( 'YITH_Vendors' ) ) {
			$shortcode_list['[yaymail_addon_yith_vendor_new_account]'] = yaymailAddonYithVendorNewAccount( $yaymail_informations, $args );
		}
		return $shortcode_list;

	},
	10,
	3
);

function yaymailAddonYithVendorNewAccount( $yaymail_informations, $args = array() ) {
	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorNewAccount.php';
	$html = ob_get_contents();
	ob_end_clean();
	return $html;
}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// Name of action follow : YaymailAddon + main-name + Vue
add_action( 'YaymailAddonYithVendorInformationVue', 'YayMailYithVendor\\yith_vendor_information_vue', 100, 5 );
function yith_vendor_information_vue( $order, $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		if ( '' === $order ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorInformationDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			foreach ( $order->get_items() as $item ) {
				$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
				$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
			}
			if ( null != $commission ) {
				$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			}
			if ( null !== $vendor ) {
				$owner = get_user_by( 'id', absint( $vendor->get_owner() ) );
			}
			ob_start();
			if ( null === $owner || false === $owner ) {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorInformationDefault.php';
			} else {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorInformation.php';
			}
			$html = ob_get_contents();
			ob_end_clean();
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		echo $html;
	}
}

add_action( 'YaymailAddonYithVendorNewOrderVue', 'YayMailYithVendor\\yith_vendor_new_order_vue', 100, 5 );
function yith_vendor_new_order_vue( $order, $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		if ( '' === $order ) {
			$order_id = 1;
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorNewOrderDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			foreach ( $order->get_items() as $item ) {
				$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
				$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
			}
			if ( null != $commission ) {
				$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			}
			ob_start();
			if ( is_null( $vendor ) ) {
				$order_id = $order->id;
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorNewOrderDefault.php';
			} else {
				$path = plugin_dir_path( __FILE__ );
				include $path . '/views/vue-template/YaymailAddonYithVendorNewOrder.php';
			}
			$html = ob_get_contents();
			ob_end_clean();
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		echo $html;
	}
}

add_action( 'YaymailAddonYithVendorRegistrationVue', 'YayMailYithVendor\\yith_vendor_registration_vue', 100, 5 );
function yith_vendor_registration_vue( $order, $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		if ( '' === $order ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorRegistrationDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			foreach ( $order->get_items() as $item ) {
				$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
				$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
			}
			if ( null != $commission ) {
				$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			}
			if ( null !== $vendor ) {
				$owner = get_user_by( 'id', absint( $vendor->get_owner() ) );
			}
			ob_start();
			if ( null === $owner || false === $owner ) {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorRegistrationDefault.php';
			} else {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorRegistration.php';
			}
			$html = ob_get_contents();
			ob_end_clean();
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		echo $html;
	}
}

add_action( 'YaymailAddonYithVendorOrderCommissionsBulkVue', 'YayMailYithVendor\\yith_vendor_order_commissions_bulk_vue', 100, 5 );
function yith_vendor_order_commissions_bulk_vue( $order, $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		if ( '' === $order ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorOrderCommissionsBulkDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			foreach ( $order->get_items() as $item ) {
				$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
				$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
			}
			if ( null != $commission ) {
				$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			}
			ob_start();
			if ( is_null( $vendor ) ) {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorOrderCommissionsBulkDefault.php';
			} else {
				$path = plugin_dir_path( __FILE__ );
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorOrderCommissionsBulk.php';
			}
			$html = ob_get_contents();
			ob_end_clean();
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		echo $html;
	}
}

add_action( 'YaymailAddonYithVendorOrderCommissionsPaidVue', 'YayMailYithVendor\\yith_vendor_order_commissions_paid_vue', 100, 5 );
function yith_vendor_order_commissions_paid_vue( $order, $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		if ( '' === $order ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorOrderCommissionsPaidDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			$tax_label  = get_option( 'yith_vat_label', __( 'VAT/SSN', 'yith-woocommerce-product-vendors' ) );
			$commission = array();
			foreach ( $order->get_items() as $item ) {
				$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
				$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
			}
			if ( null != $commission ) {
				$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			}
			ob_start();
			if ( is_null( $vendor ) ) {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorOrderCommissionsPaidDefault.php';
			} else {
				include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorOrderCommissionsPaid.php';
			}
			$html = ob_get_contents();
			ob_end_clean();
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		echo $html;
	}
}

// Create HTML to display when send mail
// Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonYithVendorInformation', 'YayMailYithVendor\\yaymail_addon_yith_vendor_information', 100, 5 );
function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		
		if ( isset( $args['order'] ) && ( isset( $args['commission'] ) || isset( $args['commissions'] ) ) ) {
			$order = $args['order'];
			$commission = isset( $args['commission'] ) ? $args['commission'] : $args['commissions'];
		} else {
			if ( isset( $args['order']  ) ) {
				$order = $args['order'];
				if ( 'SampleOrder' !== $order ) {
					foreach ( $order->get_items() as $item ) {
						$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
						$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
					}
				}
			}
		}
		if ( null != $commission ) {
			$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			$order  = isset( $args['order'] ) ? $args['order'] : $commission->get_order();
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorInformation.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} elseif ( 'SampleOrder' == $args['order'] ) {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorInformationDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

add_action( 'YaymailAddonYithVendorRegistration', 'YayMailYithVendor\\yaymail_addon_yith_vendor_registration', 100, 5 );
function yaymail_addon_yith_vendor_registration( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		
		if ( isset( $args['vendor'] ) ) {
			$vendor = $args['vendor'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorRegistration.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} elseif ( 'SampleOrder' == $args['order'] ) {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorRegistrationDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

add_action( 'YaymailAddonYithVendorOrderCommissionsPaid', 'YayMailYithVendor\\yaymail_addon_yith_vendor_order_commissions_paid', 100, 5 );
function yaymail_addon_yith_vendor_order_commissions_paid( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		
		if ( isset( $args['order'] ) && ( isset( $args['commission'] ) || isset( $args['commissions'] ) ) ) {
			$order = $args['order'];
			$commission = isset( $args['commission'] ) ? $args['commission'] : $args['commissions'];
		} else {
			if ( isset( $args['order'] ) ) {
				$order = $args['order'];
				if ( 'SampleOrder' !== $order ) {
					$tax_label  = get_option( 'yith_vat_label', __( 'VAT/SSN', 'yith-woocommerce-product-vendors' ) );
					$commission = array();
					foreach ( $order->get_items() as $item ) {
						$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
						$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
					}
				}
			}
		}
		if ( null != $commission ) {
			$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			$order  = isset( $args['order'] ) ? $args['order'] : $commission->get_order();
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorOrderCommissionsPaid.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} elseif ( 'SampleOrder' == $args['order'] ) {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorOrderCommissionsPaidDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

add_action( 'YaymailAddonYithVendorOrderCommissionsBulk', 'YayMailYithVendor\\yaymail_addon_yith_vendor_order_commissions_bulk', 100, 5 );
function yaymail_addon_yith_vendor_order_commissions_bulk( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		
		if ( isset( $args['order'] ) && ( isset( $args['commission'] ) || isset( $args['commissions'] ) ) ) {
			$order = $args['order'];
			$commission = isset( $args['commission'] ) ? $args['commission'] : $args['commissions'];
		} else {
			if ( isset( $args['order'] ) ) {
				$order = $args['order'];
				if ( 'SampleOrder' !== $order ) {
					$tax_label  = get_option( 'yith_vat_label', __( 'VAT/SSN', 'yith-woocommerce-product-vendors' ) );
					$commission = array();
					foreach ( $order->get_items() as $item ) {
						$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
						$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
					}
				}
			}
		}
		if ( null != $commission ) {
			$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			$order  = isset( $args['order'] ) ? $args['order'] : $commission->get_order();
			$path   = plugin_dir_path( __FILE__ );
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorOrderCommissionsBulk.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} elseif ( 'SampleOrder' == $args['order'] ) {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorOrderCommissionsBulkDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

add_action( 'YaymailAddonYithVendorNewOrder', 'YayMailYithVendor\\yaymail_addon_yith_vendor_new_order', 100, 5 );
function yaymail_addon_yith_vendor_new_order( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( function_exists( 'YITH_Vendors' ) ) {
		
		if ( isset( $args['order'] ) && ( isset( $args['commission'] ) || isset( $args['commissions'] ) ) ) {
			$order = $args['order'];
			$commission = isset( $args['commission'] ) ? $args['commission'] : $args['commissions'];
		} else {
			if ( isset( $args['order'] ) ) {
				$order = $args['order'];
				if ( 'SampleOrder' !== $order ) {
					foreach ( $order->get_items() as $item ) {
						$item_meta_key = wp_get_post_parent_id( $order->get_id() ) ? '_commission_id' : '_child__commission_id';
						$commission    = isset( $item[ $item_meta_key ] ) && function_exists( 'YITH_Commission' ) ? YITH_Commission( $item[ $item_meta_key ] ) : null;
					}
				}
			}
		}
		if ( null != $commission ) {
			$vendor = function_exists( 'yith_get_vendor' ) ? yith_get_vendor( absint( $commission->vendor_id ) ) : null;
			$order  = isset( $args['order'] ) ? $args['order'] : $commission->get_order();
			$path   = plugin_dir_path( __FILE__ );
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorNewOrder.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} elseif ( 'SampleOrder' == $args['order'] ) {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorNewOrderDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailYithVendor\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default($array, $key, $value ) {
	$getHeading = $value->heading;
	if ( 'YITH_WC_Email_Cancelled_Order' == $key
	|| 'YITH_WC_Email_Commissions_Paid' == $key
	|| 'YITH_WC_Email_Commissions_Unpaid' == $key
	|| 'YITH_WC_Email_Vendor_Commissions_Paid' == $key
	) {
		$yithMultiCommissions = templateDefault\YITHMultiCommissions::getTemplates( $value->id, $getHeading );
		return $yithMultiCommissions;
	} elseif ( 'YITH_WC_Email_Product_Set_In_Pending_Review' == $key || 'YITH_WC_Email_Vendor_New_Account' == $key ) {
		$yithMultiVendorDefault = templateDefault\YITHMultiVendorDefault::getTemplates( $value->id, $getHeading );
		return $yithMultiVendorDefault;
	} elseif ( 'YITH_WC_Email_New_Order' == $key ) {
		$yithMultiVendorNewOrder = templateDefault\YITHMultiVendorNewOrder::getTemplates( $value->id, $getHeading );
		return $yithMultiVendorNewOrder;
	} elseif ( 'YITH_WC_Email_Vendor_Commissions_Bulk_Action' == $key ) {
		$yithCommissionsBulk = templateDefault\YITHMultiVendorCommissionsBulk::getTemplates( $value->id, $getHeading );
		return $yithCommissionsBulk;
	} elseif ( 'YITH_WC_Email_New_Vendor_Registration' == $key ) {
		$yithVendorRegistration = templateDefault\YITHMultiVendorRegistration::getTemplates( $value->id, $getHeading );
		return $yithVendorRegistration;
	}
	return $array;
}



