<?php
/**
 * Admin new order email
 *
 * @author WooThemes
 * @package WooCommerce/Templates/Emails/HTML
 * @version 2.0.0
 *
 * @var YITH_Commission $commission
 * @var YITH_Vendor $vendor
 * @var WC_Product $product
 * @var WC_Order $order
 * @var array $item
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$shipping_fee_total          = 0;
$commissions_total           = $shipping_fee_total;
$wc_price_args               = apply_filters( 'yith_wcmv_commissions_bulk_email_wc_price_args', array() );
$titleCommissionID           = isset( $attrs['titleCommissionID'] ) ? $attrs['titleCommissionID'] : 'Commission ID';
$titleOrderID                = isset( $attrs['titleOrderID'] ) ? $attrs['titleOrderID'] : 'Order ID';
$titleSKU                    = isset( $attrs['titleSKU'] ) ? $attrs['titleSKU'] : 'SKU';
$titleAmount                 = isset( $attrs['titleAmount'] ) ? $attrs['titleAmount'] : 'Amount';
$titleRate                   = isset( $attrs['titleRate'] ) ? $attrs['titleRate'] : '%Rate';
$titleNewStatus              = isset( $attrs['titleNewStatus'] ) ? $attrs['titleNewStatus'] : 'New Status';
$titleNote                   = isset( $attrs['titleNote'] ) ? $attrs['titleNote'] : 'Note';
$titleTotalProductCommission = isset( $attrs['titleTotalProductCommission'] ) ? $attrs['titleTotalProductCommission'] : 'Total product commissions';
add_filter( 'yith_wcmv_commission_have_been_calculated_text', '__return_empty_string' );
?>

	<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
		<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleCommissionID, 'yith-woocommerce-product-vendors' ); ?></td>
		<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleOrderID, 'yith-woocommerce-product-vendors' ); ?></td>
		<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:center; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleSKU, 'yith-woocommerce-product-vendors' ); ?></td>
		<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleAmount, 'yith-woocommerce-product-vendors' ); ?></td>
		<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleRate, 'yith-woocommerce-product-vendors' ); ?></td>
		<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleNewStatus, 'yith-woocommerce-product-vendors' ); ?></td>

		<?php if ( $show_note ) : ?>
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleNote, 'yith-woocommerce-product-vendors' ); ?></td>
		<?php endif; ?>

	</tr>

	<?php if ( ! is_array( $commissions ) ) : ?>
		<?php $commissions = array( $commissions ); ?> 
	<?php endif; ?>

	<?php foreach ( $commissions as $commission ) : ?>
		<?php
		if ( 'shipping' == $commission->type ) {
			$shipping_fee_total = $shipping_fee_total + $commission->get_amount();
		} else {
			$commissions_total = $commissions_total + $commission->get_amount();
		}
		?>
		<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<a href="<?php echo esc_attr( $commission->get_view_url( 'admin' ) ); ?>">
					<?php echo '#' . esc_attr( $commission->id ); ?>
				</a>
			</td>
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<?php $order_id = $commission->get_order() instanceof WC_Order ? $commission->get_order()->get_id() : ''; ?>
				<?php if ( ! empty( $order_id ) ) : ?>
					<?php $order_uri = apply_filters( 'yith_wcmv_commissions_list_table_order_url', admin_url( 'post.php?post=' . absint( $order_id ) . '&action=edit' ), $commission, $commission->get_order() ); ?>
					<a style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>" href="<?php echo esc_attr( $order_uri ); ?>">
				<?php endif; ?>

				<?php echo '#' . esc_attr( $order_id ); ?>

				<?php if ( ! empty( $order_id ) ) : ?>
					</a>
				<?php endif; ?>
			</td>
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:center; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<?php
				$currency = $commission->get_order() instanceof WC_Order ? $commission->get_order()->get_currency() : '';
				if ( 'shipping' == $commission->type ) {
					$info = _x( 'Shipping', '[admin] part of shipping fee details', 'yith-woocommerce-product-vendors' );
				} else {
					$info = '-';
					$item = $commission->get_item();
					if ( $item instanceof WC_Order_Item ) {
						$product = $commission->get_product();

						if ( $product ) {
							$sku = $product->get_sku( 'view' );

							if ( ! empty( $sku ) ) {
								if ( apply_filters( 'yith_wcmv_show_product_uri_in_commissions_bulk_email', true ) ) {
									$product_url = apply_filters( 'yith_wcmv_commissions_list_table_product_url', get_edit_post_link( $product->get_id() ), $product, $commission );
									$info        = sprintf( '<a :style="{color: emailTextLinkColor}" href="%s">%s</a>', $product_url, $sku );
								} else {
									$info = $sku;
								}
							}
						}
					}
				}

				echo ( $info )
				?>
			</td>
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo ( $commission->get_amount( 'display', array( 'currency' => $currency ) ) ); ?></td>
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo ( $commission->get_rate( 'display' ) ); ?></td>
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo ( $new_commission_status ); ?></td>

			<?php if ( $show_note ) : ?>
				<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word; <?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
					<?php
					$msg = '-';

					if ( $item instanceof WC_Order_Item_Product ) {
						/**
						 * Check if the commissions included tax
						 */
						$commission_included_tax = wc_get_order_item_meta( $item->get_id(), '_commission_included_tax', true );
						/**
						 * Check if the commissions included coupon
						 */
						$commission_included_coupon = wc_get_order_item_meta( $item->get_id(), '_commission_included_coupon', true );

						$msg = YITH_Commissions::get_tax_and_coupon_management_message( $commission_included_tax, $commission_included_coupon );
					}

					echo ( $msg );

					?>
				</td>
			<?php endif; ?>

		</tr>
	<?php endforeach; ?>

	<?php if ( ! empty( $commissions_total ) ) : ?>
		<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<strong>
					<?php esc_html_e( $titleTotalProductCommission, 'yith-woocommerce-product-vendors' ); ?>
				</strong>
			</td>
			<td colspan="6" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<?php echo ( wc_price( $commissions_total, $wc_price_args ) ); ?>
			</td>
		</tr>
	<?php endif; ?>

	<?php if ( ! empty( $shipping_fee_total ) ) : ?>
		<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
			<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<strong>
					<?php esc_html_x( 'Total Shipping Fee', '[Email commissions report]: Total commissions amount', 'yith-woocommerce-product-vendors' ); ?>
				</strong>
			</td>
			<td colspan="6" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
				<?php echo esc_html( wc_price( $shipping_fee_total, $wc_price_args ) ); ?>

			</td>
		</tr>
	<?php endif; ?>

<?php remove_filter( 'yith_wcmv_commission_have_been_calculated_text', '__return_empty_string' ); ?>
