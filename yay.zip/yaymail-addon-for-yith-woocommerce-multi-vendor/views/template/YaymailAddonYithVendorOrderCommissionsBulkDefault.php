<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color             = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
$titleColor                  = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$borderColor                 = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor                   = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleCommissionID           = isset( $attrs['titleCommissionID'] ) ? $attrs['titleCommissionID'] : 'Commission ID';
$titleOrderID                = isset( $attrs['titleOrderID'] ) ? $attrs['titleOrderID'] : 'Order ID';
$titleSKU                    = isset( $attrs['titleSKU'] ) ? $attrs['titleSKU'] : 'SKU';
$titleAmount                 = isset( $attrs['titleAmount'] ) ? $attrs['titleAmount'] : 'Amount';
$titleRate                   = isset( $attrs['titleRate'] ) ? $attrs['titleRate'] : '%Rate';
$titleNewStatus              = isset( $attrs['titleNewStatus'] ) ? $attrs['titleNewStatus'] : 'New Status';
$titleNote                   = isset( $attrs['titleNote'] ) ? $attrs['titleNote'] : 'Note';
$titleTotalProductCommission = isset( $attrs['titleTotalProductCommission'] ) ? $attrs['titleTotalProductCommission'] : 'Total product commissions';
?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
		  <h2 class="yaymail_commission_bulk_title" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;margin: 0 0 18px;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'>
		  <?php printf( '%s <a style="color: %s;" href="">%s</a>', _x( 'Commissions Report for', 'yith-woocommerce-product-vendors' ), esc_attr( $attrs['titleColor'] ), 'YayMail' ); ?></h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
			cellspacing="0" cellpadding="6" border="1" 
			style="width: 100% !important;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;" width="100%">
				<tbody>
					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleCommissionID, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleOrderID, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: center; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleSKU, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleAmount, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleRate, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleNewStatus, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleNote, 'yith-woocommerce-product-vendors' ); ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<a href="" style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>;"> #5 </a>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<a href="" style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>;">
								#1039
							</a>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: center; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<a href="" style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>;">sub1</a>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<span class="woocommerce-Price-amount amount">
								<bdi>21,0<span class="woocommerce-Price-currencySymbol">€</span></bdi>
							</span>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>50%</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>paid</td>

						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<br />
							* coupon <em>included</em><br />
							* tax: <em>credit taxes to the website admin</em>
						</td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<strong> <?php esc_html_e( $titleTotalProductCommission, 'yith-woocommerce-product-vendors' ); ?> </strong>
						</td>
						<td colspan="6" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle; word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<span class="woocommerce-Price-amount amount">
								<bdi>21,0<span class="woocommerce-Price-currencySymbol">€</span></bdi>
							</span>
						</td>
					</tr>
				</tbody>
			</table>
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
