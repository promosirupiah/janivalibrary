<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$order_id               = $order->id;
$order_date_created     = $order->get_date_created();
$tax_credited_to_vendor = 'vendor' == get_option( 'yith_wpv_commissions_tax_management', 'website' );
$currency               = array( 'currency' => yith_wcmv_get_order_currency( $order ) );
$vendor_products        = $vendor->get_products(
	array(
		'fields'      => 'ids',
		'post_status' => 'any',
	)
);
$commission_ids         = YITH_Commissions()->get_commissions(
	array(
		'order_id' => $order->get_id(),
		'status'   => 'all',
	)
);
if ( ! function_exists( 'yaymaiOrderYITHItemTablesEmail' ) ) {
	function yaymaiOrderYITHItemTablesEmail( $order, $default_args, $path ) {
		$items            = $order->get_items();
		$yaymail_settings = get_option( 'yaymail_settings' );

		$show_product_image            = isset( $yaymail_settings['product_image'] ) ? $yaymail_settings['product_image'] : 0;
		$show_product_sku              = isset( $yaymail_settings['product_sku'] ) ? $yaymail_settings['product_sku'] : 0;
		$default_args['image_size'][0] = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
		$default_args['image_size'][1] = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
		$default_args['image_size'][2] = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';

		$vendor                        = $default_args['vendor'];
		$attrs                         = $default_args['attrs'];
		$items                         = $order->get_items();
		$show_download_links           = $order->is_download_permitted() && ! $default_args['sent_to_admin'];
		$show_sku                      = $show_product_sku;
		$show_purchase_note            = $order->is_paid() && ! $default_args['sent_to_admin'];
		$show_image                    = $show_product_image;
		$image_size                    = $default_args['image_size'];
		$sent_to_admin                 = $default_args['sent_to_admin'];
		$order_item_table_border_color = isset( $yaymail_settings['background_color_table_items'] ) ? $yaymail_settings['background_color_table_items'] : '#dddddd';
		$tax_credited_to_vendor        = 'vendor' == get_option( 'yith_wpv_commissions_tax_management', 'website' );

		include $path . '/views/support-template/vendor-email-order-items-email.php';
	}
}
$text_link_color = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
$titleColor      = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$borderColor     = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor       = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleProduct    = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleQuantity   = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Qty';
$titlePrice      = isset( $attrs['titlePrice'] ) ? $attrs['titlePrice'] : 'Price';
$titleCommission = isset( $attrs['titleCommission'] ) ? $attrs['titleCommission'] : 'Commission';
$titleEarnings   = isset( $attrs['titleEarnings'] ) ? $attrs['titleEarnings'] : 'Earnings';
?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
			  <h2 class="yaymail_vendor_new_order_title" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;margin: 0 0 18px;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'>
				<?php
					// translators: 1. order id
					printf( __( 'Order #%s', 'yith-woocommerce-product-vendors' ), esc_html( $order->id ) );
				?>
				(<?php printf( '<time datetime="%s">%s</time>', esc_html( $order->get_date_created()->format( 'c' ) ), esc_html( wc_format_datetime( $order->get_date_created() ) ) ); ?>)
			</h2>
			<!-- Table Items has Border -->
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
				cellspacing="0" cellpadding="6" border="1" 
				style="width: 100% !important;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;" width="100%">
				<thead>
					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleProduct, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleQuantity, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titlePrice, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleCommission, 'yith-woocommerce-product-vendors' ); ?></th>
						<?php if ( $tax_credited_to_vendor ) : ?>
							<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_x( 'Tax', 'Email: tax amount column', 'yith-woocommerce-product-vendors' ); ?></th>
						<?php endif; ?>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<?php $earnings_text = esc_html__( $titleEarnings, 'yith-woocommerce-product-vendors' ); ?>
							<?php if ( $tax_credited_to_vendor ) : ?>
								<?php $earnings_text .= ' '; ?>
								<?php $earnings_text .= _x( '(inc. taxes)', 'Email: commission amount column', 'yith-woocommerce-product-vendors' ); ?>
							<?php endif; ?>
							<?php echo esc_html( $earnings_text ); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php
					echo wp_kses_post(
						yaymaiOrderYITHItemTablesEmail(
							$order,
							array(
								'show_sku'      => $sent_to_admin,
								'show_image'    => false,
								'image_size'    => array( 32, 32 ),
								'sent_to_admin' => $sent_to_admin,
								'vendor'        => $vendor,
								'attrs'         => $attrs,
							),
							$path
						)
					);
					?>
				</tbody>

			</table>
			<?php
			$shipping_fee_ids = function_exists( 'YITH_Commissions' ) && function_exists( 'yit_get_prop' ) ? YITH_Commissions()->get_commissions(
				array(
					'order_id' => yit_get_prop( $order, 'id' ),
					'status'   => 'all',
					'type'     => 'shipping',
				)
			) : '';
			?>


			<?php if ( ! empty( $shipping_fee_ids ) ) : ?>
				<h3 style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;'><?php esc_html_x( 'Shipping Fee', 'Email: Title before the Shipping fee list', 'yith-woocommerce-product-vendors' ); ?></h3>
				<table id="vendor-table-shipping" cellspacing="0" cellpadding="6" 
					style="width: 100%;border-collapse: collapse<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;" border="1">
					<thead>
					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_x( 'Shipping Method', 'Email: shipping method column', 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_x( 'Rate', 'Email: commission rate column', 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_x( 'Amount', 'Email: commission amount column', 'yith-woocommerce-product-vendors' ); ?></th>
					</tr>
					</thead>
					<?php
					$line_items_shipping = $order->get_items( 'shipping' );
					foreach ( $shipping_fee_ids as $shipping_fee_id ) :
						?>
						<?php
						$shipping_fee = YITH_Commission( $shipping_fee_id );
						if ( ! empty( $shipping_fee ) ) :
							?>
							<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php
								$shipping_method = isset( $line_items_shipping[ $shipping_fee->line_item_id ] ) ? $line_items_shipping[ $shipping_fee->line_item_id ] : null;
								if ( ! empty( $shipping_method ) ) {
									echo esc_html( $shipping_method->get_name() );
									$linkUrl = '<a style="color: ' . emailTextLinkColor . '" href="' . $shipping_fee->get_view_url( 'admin' ) . '">' . $shipping_fee->id . '</a>';
									echo '<br/><small>' . esc_html_x( 'Commission id:', 'New Order Email', 'yith-woocommerce-product-vendors' ) . ' ' . $linkUrl . '</small>';
								}
								?>
							</td>
						<?php endif; ?>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<?php echo esc_html( $shipping_fee->get_rate( 'display' ) ); ?>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<?php echo esc_html( $shipping_fee->get_amount( 'display', $currency ) ); ?>
						</td>
					<?php endforeach; ?>
					<?php
					if ( $order->get_customer_note() ) {
						?>
							<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
								<th class="td" scope="row" colspan="2" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( 'Note:', 'woocommerce' ); ?></th>
								<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo wp_kses_post( nl2br( wptexturize( $order->get_customer_note() ) ) ); ?></td>
							</tr>
							<?php
					}
					?>
				</table>
			<?php endif; ?>
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
