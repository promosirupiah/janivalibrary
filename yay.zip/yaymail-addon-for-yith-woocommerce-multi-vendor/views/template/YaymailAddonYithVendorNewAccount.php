<?php

defined( 'ABSPATH' ) || exit;

$admin_url  = apply_filters( 'yith_wcmv_get_main_page_url', function_exists( 'yith_wcfm_get_main_page_url' ) ? yith_wcfm_get_main_page_url() : admin_url() );
$admin_site = get_bloginfo( 'name' );
?>
<p>
<?php
 // translators: 1. blog name
 printf( wp_kses_post( 'Your vendor account has been approved on %s.', 'yith-woocommerce-product-vendors' ), esc_html( $admin_site ) );
?>
</p>

<p>
<?php
 // translators: 1. link url
printf( wp_kses_post( 'From your vendor dashboard you can view your recent commissions, view the sales report and manage your store and payment settings. Click <a href="%s">here</a> to access <strong>store dashboard</strong>.', 'yith-woocommerce-product-vendors' ), esc_html( $admin_url ) );
?>
</p>

