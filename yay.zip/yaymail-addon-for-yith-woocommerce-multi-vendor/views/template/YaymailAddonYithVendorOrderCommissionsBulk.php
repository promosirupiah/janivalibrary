<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$tax_credited_to_vendor = 'vendor' == get_option( 'yith_wpv_commissions_tax_management', 'website' );
$currency               = array( 'currency' => yith_wcmv_get_order_currency( $order ) );
$vendor_products        = $vendor->get_products(
	array(
		'fields'      => 'ids',
		'post_status' => 'any',
	)
);
$commission_ids         = YITH_Commissions()->get_commissions(
	array(
		'order_id' => $order->get_id(),
		'status'   => 'all',
	)
);
$vendor_uri             = add_query_arg(
	array(
		'page'          => 'yith_vendor_commissions',
		'vendor_id'     => $vendor->id,
		'filter_action' => 'Filter',
	),
	admin_url( 'admin.php' )
);

function orderCommissionBulkTables( $order, $default_args, $path ) {
	$items                 = $order->get_items();
	$commissions           = $default_args['commissions'];
	$attrs                 = $default_args['attrs'];
	$new_commission_status = isset( $commissions->status ) ? $commissions->status : '';
	$show_note             = true;
	include $path . '/views/support-template/commission-bulk-table-email.php';
}

$text_link_color = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
$titleColor      = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$borderColor     = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor       = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';

?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
		  <h2 style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;margin: 0 0 18px;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'><?php printf( '%s <a style="color:%s" href="%s">%s</a>', _x( 'Commissions Report for', 'yith-woocommerce-product-vendors' ), esc_attr( $attrs['titleColor'] ), $vendor_uri, $vendor->name ); ?></h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
			cellspacing="0" cellpadding="6" border="1" 
			style="width: 100% !important;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;" width="100%">
				<tbody>
					<?php
					echo wp_kses_post(
						orderCommissionBulkTables(
							$order,
							array(
								'commissions' => $commission,
								'attrs'       => $attrs,
								'show_note'   => true,
							),
							$path
						)
					);
					?>
				</tbody>

			</table>
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
