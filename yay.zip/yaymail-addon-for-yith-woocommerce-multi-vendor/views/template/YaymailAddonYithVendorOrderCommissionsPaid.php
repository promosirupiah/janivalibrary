<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
$titleColor       = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$borderColor      = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor        = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleStatus      = isset( $attrs['titleStatus'] ) ? $attrs['titleStatus'] : 'Status';
$titleDate        = isset( $attrs['titleDate'] ) ? $attrs['titleDate'] : 'Date';
$titleAmount      = isset( $attrs['titleAmount'] ) ? $attrs['titleAmount'] : 'Amount';
$titlePaypalEmail = isset( $attrs['titlePaypalEmail'] ) ? $attrs['titlePaypalEmail'] : 'Paypal email';
$titleVendor      = isset( $attrs['titleVendor'] ) ? $attrs['titleVendor'] : 'Vendor';
$titleOrderNumber = isset( $attrs['titleOrderNumber'] ) ? $attrs['titleOrderNumber'] : 'Order number';
$titleProduct     = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
			<h2 style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;margin: 0 0 18px;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'>
				  <a class="yaymail_commission_paid_title" style="font-weight: bold;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;" href="<?php echo esc_attr( $commission->get_view_url( 'admin' ) ); ?>">
				<?php
					// translators: 1. commission id
					printf( __( 'Commission #%s detail', 'yith-woocommerce-product-vendors' ), esc_html( $commission->id ) );
				?>
				</a>
			</h2>
			<!-- Table Items has Border -->
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" cellspacing="0" cellpadding="6" border="1" style="width: 100% !important;<?php echo esc_attr( $borderColor ); ?>;" width="100%">
				<tbody style="flex-direction:inherit;">
					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleStatus, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo $commission->get_status( 'display' ) != null ? esc_html( $commission->get_status( 'display' ) ) : ''; ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleDate, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo $commission->get_date( 'display' ) != null ? esc_html( $commission->get_date( 'display' ) ) : ''; ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleAmount, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo $commission->get_amount( 'display' ) != null ? wp_kses_post( $commission->get_amount( 'display', array( 'currency' => $order->get_currency() ) ) ) : ''; ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titlePaypalEmail, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo isset( $vendor->paypal_email ) ? esc_html( $vendor->paypal_email ) : ''; ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleVendor, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo isset( $vendor->name ) ? esc_html( $vendor->name ) : ''; ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleOrderNumber, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo esc_html( $order->get_order_number() ); ?></td>
					</tr>

					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleProduct, 'yith-woocommerce-product-vendors' ); ?></td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle; word-wrap:break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php echo $commission->get_item() ? esc_html( $commission->get_item()->get_data()['name'] ) : ''; ?></td>
					</tr>

				</tbody>
			</table>
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
