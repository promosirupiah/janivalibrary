<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
$titleColor      = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$borderColor     = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor       = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleProduct    = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleQuantity   = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Qty';
$titlePrice      = isset( $attrs['titlePrice'] ) ? $attrs['titlePrice'] : 'Price';
$titleCommission = isset( $attrs['titleCommission'] ) ? $attrs['titleCommission'] : 'Commission';
$titleEarnings   = isset( $attrs['titleEarnings'] ) ? $attrs['titleEarnings'] : 'Earnings';
?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
		  	<h2 class="yaymail_vendor_new_order_title" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;margin: 0 0 18px;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'>
			  <?php printf( __( 'Order #%s', 'yith-woocommerce-product-vendors' ), 1 ); ?> (<?php printf( '<time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?>)
			</h2>
			<!-- Table Items has Border -->
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
				cellspacing="0" cellpadding="6" border="1" 
				style="width: 100% !important;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;" width="100%">
				<thead>
					<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleProduct, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleQuantity, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titlePrice, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleCommission, 'yith-woocommerce-product-vendors' ); ?></th>
						<th scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleEarnings, 'yith-woocommerce-product-vendors' ); ?></th>
					</tr>
				</thead>
				<tbody></tbody>
				<tbody>
					<tr class="order_item" style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle;word-wrap: break-word;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							Virtual Product<span class="yith_wcmv_sold_by_wrapper"> <small>(Sold by: yaymail)</small></span> (#sub1)<br />
							<small>Commission id: <a href="" style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>;">5</a></small>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: center; vertical-align: middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>1</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<span class="woocommerce-Price-amount amount">
								<bdi>42,0<span class="woocommerce-Price-currencySymbol">€</span></bdi>
							</span>
						</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: center; vertical-align: middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>50%</td>
						<td style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align: left; vertical-align: middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
							<span class="woocommerce-Price-amount amount">
								<bdi>21,0<span class="woocommerce-Price-currencySymbol">€</span></bdi>
							</span>
						</td>
					</tr>
				</tbody>

			</table>
		</td>
	  </tr>
	</tbody>
</table>
