<?php
	$tax_credited_to_vendor = 'vendor' == get_option( 'yith_wpv_commissions_tax_management', 'website' );
	$currency               = array( 'currency' => yith_wcmv_get_order_currency( $order ) );
	$vendor_products        = $vendor->get_products(
		array(
			'fields'      => 'ids',
			'post_status' => 'any',
		)
	);
	$commission_ids         = YITH_Commissions()->get_commissions(
		array(
			'order_id' => $order->get_id(),
			'status'   => 'all',
		)
	);
	$vendor_uri             = add_query_arg(
		array(
			'page'          => 'yith_vendor_commissions',
			'vendor_id'     => $vendor->id,
			'filter_action' => 'Filter',
		),
		admin_url( 'admin.php' )
	);
	?>
<?php
function orderCommissionBulkTables( $order, $default_args, $path ) {
	$items                 = $order->get_items();
	$commissions           = $default_args['commissions'];
	$new_commission_status = isset( $commissions->status ) ? $commissions->status : '';
	$show_note             = true;
	include $path . '/views/support-template/commission-bulk-table.php';
}
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
			  <h2 style="margin: 0 0 18px;" :style="{color: emailContent.settingRow.titleColor, 'font-family':emailContent.settingRow.family}"><?php printf( '%s <a :style="{color: emailContent.settingRow.titleColor}" href="%s">%s</a>', _x( 'Commissions Report for', 'yith-woocommerce-product-vendors' ), $vendor_uri, $vendor->name ); ?></h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
			cellspacing="0" cellpadding="6" border="1" 
			style="width: 100% !important;" :style="{'border-color':emailContent.settingRow.borderColor}" width="100%">
				<tbody>
					<?php
					echo wp_kses_post(
						orderCommissionBulkTables(
							$order,
							array(
								'commissions' => $commission,
								'show_note'   => true,
							),
							$path
						)
					);
					?>
				</tbody>

			</table>
		  </div>
	</td>
	</tr>
</tbody>
</table>
