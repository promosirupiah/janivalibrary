<?php
	$store_name_label  = apply_filters( 'yith_wcmv_vendor_admin_settings_store_name_label', __( 'Store name', 'yith-woocommerce-product-vendors' ) );
	$store_email_label = apply_filters( 'yith_wcmv_vendor_admin_settings_store_email_label', __( 'Store email', 'yith-woocommerce-product-vendors' ) );
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	<tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
			<div
			class="yaymail-items-subscript-border"
				style="min-height: 10px"
				:style="{
				color: emailContent.settingRow.textColor,
				borderColor: emailContent.settingRow.borderColor,
				}"
			>
			<h2 style="margin: 0 0 18px;" :style="{color: emailContent.settingRow.titleColor, 'font-family': emailContent.settingRow.family}">
				<a :style="{color: emailContent.settingRow.titleColor}" href="<?php echo esc_attr( $vendor->get_url( 'admin' ) ); ?>">
					<?php esc_html_e( 'Vendor Registration', 'yith-woocommerce-product-vendors ' ); ?>
				</a>
			</h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
			cellspacing="0" cellpadding="6" style="width: 100%;" :style="{'border-color':emailContent.settingRow.borderColor}" border="1" >
				<tbody>
				<tr style="word-break: normal;" :style="{'color':emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleOwner}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}">
							<?php
							$owner_info = '';
							$href       = add_query_arg( array( 'user_id' => $owner->get( 'ID' ) ), admin_url( 'user-edit.php' ) );
							if ( ! empty( $owner->user_firstname ) || ! empty( $owner->user_lastname ) ) {
								$owner_info = $owner->user_firstname . ' ' . $owner->user_lastname;
							} else {
								$owner_info = $owner->user_email;
							}

							printf( '<a :style="{color: emailTextLinkColor}" href="%s">%s</a>', esc_attr( $href ), esc_html( $owner_info ) )

							?>
						</td>
					</tr>

					<tr style="word-break: normal;" :style="{'color':emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStoreName}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}"><?php echo esc_html( $vendor->name ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color':emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleLocation}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}"><?php echo esc_html( $vendor->location ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color':emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStoreEmail}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}"><?php echo esc_html( $vendor->store_email ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color':emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleTelephone}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color':emailContent.settingRow.borderColor}"><?php echo esc_html( $vendor->telephone ); ?></td>
					</tr>
				</tbody>
			</table>
			</div>
			</td>
		</tr>
	</tbody>
</table>
