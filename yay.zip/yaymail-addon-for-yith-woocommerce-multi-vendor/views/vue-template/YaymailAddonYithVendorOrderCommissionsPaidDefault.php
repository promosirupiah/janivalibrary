<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
		  <h2 style="margin: 0 0 18px;" :style="{color: emailContent.settingRow.titleColor, 'font-family' : emailContent.settingRow.family}">
          <a class="yaymail_commission_paid_title" style="font-weight: bold;" :style="{color: emailContent.settingRow.titleColor}" href=""><?php printf( __( 'Commission #%s detail', 'yith-woocommerce-product-vendors' ), 1 ); ?></a></h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
            cellspacing="0" cellpadding="6" border="1" style="width: 100% !important;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor}">
				<tbody style="flex-direction:inherit;">
					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStatus}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( 'Pending' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleDate}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( 'Feb 22, 2021 - 10:52' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleAmount}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( '21,0€' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titlePaypalEmail}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( 'yaymail@gmail.com' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleVendor}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( 'Virtual Product' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleOrderNumber}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( 1 ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo ( 'Virtual Product' ); ?></td>
					</tr>

				</tbody>
			</table>
		</div>
	</td>
	</tr>
</tbody>
</table>
