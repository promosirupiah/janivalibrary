<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
		  <h2 class="yaymail_commission_bulk_title" style="margin: 0 0 18px; font-family: inherit;" :style="{color: emailContent.settingRow.titleColor}">
          <?php printf( '%s <a :style="{color: emailContent.settingRow.titleColor}" href="">%s</a>', _x( 'Commissions Report for', 'yith-woocommerce-product-vendors' ), 'YayMail' ); ?></h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
            cellspacing="0" cellpadding="6" border="1" style="width: 100% !important;" :style="{'border-color': emailContent.settingRow.borderColor}" width="100%">
				<tbody>
					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleCommissionID}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleOrderID}}</td>
						<td style="text-align: center; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleSKU}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleAmount}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleRate}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleNewStatus}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleNote}}</td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<a href="" style="color: rgb(150, 88, 138);"> #5 </a>
						</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<a href="" style="color: rgb(150, 88, 138);">
								#1039
							</a>
						</td>
						<td style="text-align: center; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<a href="" style="color: rgb(150, 88, 138);">sub1</a>
						</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<span class="woocommerce-Price-amount amount">
								<bdi>21,0<span class="woocommerce-Price-currencySymbol">€</span></bdi>
							</span>
						</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">50%</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">paid</td>

						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<br />
							* coupon <em>included</em><br />
							* tax: <em>credit taxes to the website admin</em>
						</td>
					</tr>

					<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<strong> {{emailContent.settingRow.titleTotalProductCommission}} </strong>
						</td>
						<td colspan="6" style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<span class="woocommerce-Price-amount amount">
								<bdi>21,0<span class="woocommerce-Price-currencySymbol">€</span></bdi>
							</span>
						</td>
					</tr>
				</tbody>
			</table>
		  </div>
	</td>
	</tr>
</tbody>
</table>
