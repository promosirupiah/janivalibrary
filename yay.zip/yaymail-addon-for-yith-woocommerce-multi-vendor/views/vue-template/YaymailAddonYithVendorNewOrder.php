<?php
	$order_id               = $order->id;
	$order_date_created     = $order->get_date_created();
	$tax_credited_to_vendor = 'vendor' == get_option( 'yith_wpv_commissions_tax_management', 'website' );
	$currency               = array( 'currency' => yith_wcmv_get_order_currency( $order ) );
	$vendor_products        = $vendor->get_products(
		array(
			'fields'      => 'ids',
			'post_status' => 'any',
		)
	);
	$commission_ids         = YITH_Commissions()->get_commissions(
		array(
			'order_id' => $order->get_id(),
			'status'   => 'all',
		)
	);
	?>
<?php
function orderYITHItemTables( $order, $default_args, $path ) {
	$items            = $order->get_items();
	$yaymail_settings = get_option( 'yaymail_settings' );

	$show_product_image            = isset( $yaymail_settings['product_image'] ) ? $yaymail_settings['product_image'] : 0;
	$show_product_sku              = isset( $yaymail_settings['product_sku'] ) ? $yaymail_settings['product_sku'] : 0;
	$default_args['image_size'][0] = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
	$default_args['image_size'][1] = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
	$default_args['image_size'][2] = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';

	$vendor                        = $default_args['vendor'];
	$items                         = $order->get_items();
	$show_download_links           = $order->is_download_permitted() && ! $default_args['sent_to_admin'];
	$show_sku                      = $show_product_sku;
	$show_purchase_note            = $order->is_paid() && ! $default_args['sent_to_admin'];
	$show_image                    = $show_product_image;
	$image_size                    = $default_args['image_size'];
	$sent_to_admin                 = $default_args['sent_to_admin'];
	$order_item_table_border_color = isset( $yaymail_settings['background_color_table_items'] ) ? $yaymail_settings['background_color_table_items'] : '#dddddd';
	$tax_credited_to_vendor        = 'vendor' == get_option( 'yith_wpv_commissions_tax_management', 'website' );

	include $path . '/views/support-template/vendor-email-order-items.php';
}

?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
		  <h2 class="yaymail_vendor_new_order_title" style="margin: 0 0 18px;" :style="{color: emailContent.settingRow.titleColor, 'font-family': emailContent.settingRow.family}">
	<?php
		// translators: 1. order id
		printf( __( 'Order #%s', 'yith-woocommerce-product-vendors' ), esc_html( $order->id ) );
	?>
	(<?php printf( '<time datetime="%s">%s</time>', esc_html( $order->get_date_created()->format( 'c' ) ), esc_html( wc_format_datetime( $order->get_date_created() ) ) ); ?>)
</h2>
<!-- Table Items has Border -->
<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" 
	   cellspacing="0" cellpadding="6" border="1" 
	   style="width: 100% !important;" :style="{'border-color': emailContent.settingRow.borderColor}" width="100%">
	<thead>
		<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</th>
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleQuantity}}</th>
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titlePrice}}</th>
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleCommission}}</th>
			<?php if ( $tax_credited_to_vendor ) : ?>
				<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php esc_html_x( 'Tax', 'Email: tax amount column', 'yith-woocommerce-product-vendors' ); ?></th>
			<?php endif; ?>
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">
			{{emailContent.settingRow.titleEarnings}}
				<?php $earnings_text = ''; ?>
				<?php if ( $tax_credited_to_vendor ) : ?>
					<?php $earnings_text .= ' '; ?>
					<?php $earnings_text .= _x( '(inc. taxes)', 'Email: commission amount column', 'yith-woocommerce-product-vendors' ); ?>
				<?php endif; ?>
				<?php echo esc_html( $earnings_text ); ?>
			</th>
		</tr>
	</thead>
	<tbody>
		<?php
		echo wp_kses_post(
			orderYITHItemTables(
				$order,
				array(
					'show_sku'      => $sent_to_admin,
					'show_image'    => false,
					'image_size'    => array( 32, 32 ),
					'sent_to_admin' => $sent_to_admin,
					'vendor'        => $vendor,
                ),
                $path
			)
		);
		?>
	</tbody>

</table>
<?php
$shipping_fee_ids = function_exists( 'YITH_Commissions' ) && function_exists( 'yit_get_prop' ) ? YITH_Commissions()->get_commissions(
	array(
		'order_id' => yit_get_prop( $order, 'id' ),
		'status'   => 'all',
		'type'     => 'shipping',
	)
) : '';
?>


<?php if ( ! empty( $shipping_fee_ids ) ) : ?>
	<h3 :style="{'font-family': emailContent.settingRow.family}"><?php esc_html_x( 'Shipping Fee', 'Email: Title before the Shipping fee list', 'yith-woocommerce-product-vendors' ); ?></h3>
	<table id="vendor-table-shipping" cellspacing="0" cellpadding="6" 
		  style="width: 100%;border-collapse: collapse" :style="{'border-color': emailContent.settingRow.borderColor}" border="1">
		<thead>
		<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php esc_html_x( 'Shipping Method', 'Email: shièpèing method column', 'yith-woocommerce-product-vendors' ); ?></th>
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php esc_html_x( 'Rate', 'Email: commission rate column', 'yith-woocommerce-product-vendors' ); ?></th>
			<th scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php esc_html_x( 'Amount', 'Email: commission amount column', 'yith-woocommerce-product-vendors' ); ?></th>
		</tr>
		</thead>
		<?php
		$line_items_shipping = $order->get_items( 'shipping' );
		foreach ( $shipping_fee_ids as $shipping_fee_id ) :
			?>
			<?php
			$shipping_fee = YITH_Commission( $shipping_fee_id );
			if ( ! empty( $shipping_fee ) ) :
				?>
				<td style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
					<?php
					$shipping_method = isset( $line_items_shipping[ $shipping_fee->line_item_id ] ) ? $line_items_shipping[ $shipping_fee->line_item_id ] : null;
					if ( ! empty( $shipping_method ) ) {
						echo esc_html( $shipping_method->get_name() );
						$linkUrl = '<a :style="{color: emailTextLinkColor}" href="' . $shipping_fee->get_view_url( 'admin' ) . '">' . $shipping_fee->id . '</a>';
						echo '<br/><small>' . esc_html_x( 'Commission id:', 'New Order Email', 'yith-woocommerce-product-vendors' ) . ' ' .  $linkUrl  . '</small>';
					}
					?>
				</td>
			<?php endif; ?>
			<td style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
				<?php echo esc_html( $shipping_fee->get_rate( 'display' ) ); ?>
			</td>
			<td style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
				<?php echo esc_html( $shipping_fee->get_amount( 'display', $currency ) ); ?>
			</td>
		<?php endforeach; ?>
		<?php
		if ( $order->get_customer_note() ) {
			?>
				<tr style="word-break: normal;" :style="{'color': emailContent.settingRow.textColor}">
					<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php esc_html_e( 'Note:', 'woocommerce' ); ?></th>
					<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo wp_kses_post( nl2br( wptexturize( $order->get_customer_note() ) ) ); ?></td>
				</tr>
				<?php
		}
		?>
	</table>
<?php endif; ?>
		</div>
	</td>
	</tr>
</tbody>
</table>
