<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	<tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
			<div
			class="yaymail-items-subscript-border"
				style="min-height: 10px"
				:style="{
				color: emailContent.settingRow.textColor,
				borderColor: emailContent.settingRow.borderColor,
				}"
			>
			<h2 class="yaymail_vendor_information_title" style="margin: 0 0 18px;" :style="{color: emailContent.settingRow.titleColor, 'font-family' : emailContent.settingRow.family}">
				<a href="" :style="{color: emailContent.settingRow.titleColor}"><?php esc_html_e( 'Vendor Information', 'yaymail' ); ?> </a>
			</h2>
			<table class="yaymail_builder_table_items_border yaymail_builder_table_item_multi_vendor" cellspacing="0" cellpadding="6" style="width: 100%;" :style="{'border-color' : emailContent.settingRow.borderColor}" border="1" >
				<tbody>
					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleOwner}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">
							<a href="" :style="{color: emailTextLinkColor}" ><?php esc_html_e( 'YayMail', 'yaymail' ); ?></a>
						</td>
					</tr>

					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStoreName}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php esc_html_e( 'yaymail', 'yaymail' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleLocation}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php esc_html_e( 'US', 'yaymail' ); ?></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStoreEmail}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}"></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleTelephone}}</td>
						<td style="text-align: left; vertical-align: middle; word-wrap: break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php esc_html_e( '+1 (606) 299-4034', 'yaymail' ); ?></td>
					</tr>
					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleVAT}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}"></td>
					</tr>

					<tr style="word-break: normal;" :style="{'color' : emailContent.settingRow.textColor}">
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleNote}}</td>
						<td style="text-align:left; vertical-align:middle; word-wrap:break-word;" :style="{'border-color' : emailContent.settingRow.borderColor}"></td>
					</tr>
				</tbody>
			</table>
			</div>
			</td>
		</tr>
	</tbody>
</table>
