<?php
/**
 * Customer outbid email
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
$yaymail_settings   = get_option( 'yaymail_settings' );
$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
?>

<div class="yaymail-product-image" style="margin-bottom: 5px; float: unset;">
    <img src="<?php echo ( wp_kses_post( wc_placeholder_img_src() ) ); ?>" alt="Product image" height="<?php echo esc_attr( $image_height ); ?>" width="<?php echo esc_attr( $image_width ); ?>" style="vertical-align:middle;margin-right: 10px">
</div>