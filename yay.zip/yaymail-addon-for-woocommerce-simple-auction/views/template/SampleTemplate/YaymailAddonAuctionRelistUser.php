<?php
/**
 * Customer outbid email
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
?>

<p><?php printf(__("The auction for <a style='color:%s' href='%s'>%s</a>.  has been relisted. Reason: auction not paid for %s hours", 'wc_simple_auctions'), $text_link_color, '', 'YayMail', '10'); ?></p>
