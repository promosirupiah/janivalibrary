<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color    = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
$yaymail_settings   = get_option( 'yaymail_settings' );
$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
$titleProduct       = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleBid           = isset( $attrs['titleBid'] ) ? $attrs['titleBid'] : 'Bid';
$borderColor        = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor          = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleColor         = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';

$product_data = wc_get_product( $product_id );
?>
<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; 
	<?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; 
	<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; 
  "
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
>
	<tbody>
		<tr>
			<td
				id="web-<?php echo esc_attr( $id ); ?>-order-item"
				class="web-order-item"
				align="<?php echo esc_attr( $attrs['align'] ); ?>"
				style='font-size: 13px; line-height: 22px; word-break: break-word;
				<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
				'
			>

			<img
			  class="web-img"
			  border="0"
			  tabindex="0"
			  src="<?php echo ( $product_data->get_image_id() ? wp_kses_post( current( wp_get_attachment_image_src( $product_data->get_image_id(), $image_size ) ) ) : wp_kses_post( wc_placeholder_img_src() ) ); ?>"
			  width="<?php echo esc_attr( $attrs['width'] ); ?>"
			  height="auto"
			/>
		</td>
	  </tr>
	</tbody>
</table>
