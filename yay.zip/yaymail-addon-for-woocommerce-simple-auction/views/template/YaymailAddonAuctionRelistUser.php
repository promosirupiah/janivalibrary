<?php
/**
 * Customer outbid email
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
$product_data = wc_get_product(  $product_id );
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
?>

<p><?php printf(__("The auction for <a style='color:%s' href='%s'>%s</a>.  has been relisted. Reason: auction not paid for %s hours", 'wc_simple_auctions'), $text_link_color, get_permalink($product_id), $product_data->get_title(), $product_data->get_auction_relist_not_paid_time()); ?></p>
