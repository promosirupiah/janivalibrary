<?php

namespace YayMailWooSimpleAuction\templateDefault;

defined( 'ABSPATH' ) || exit;

class DefaultWooSimpleAuction {

	protected static $instance = null;

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function getTemplates( $customOrder, $emailHeading ) {
		/*
		@@@ Html default send email.
		@@@ Note: Add characters '\' before special characters in a string.
		@@@ Example: font-family: \'Helvetica Neue\'...
		*/
		$emailTitle        = __( $emailHeading, 'woocommerce' );
		$additionalContent = __( 'Thanks for reading.', 'woocommerce' );
		$shortCode         = '';

		if ( $customOrder === 'outbid_note' ) {
			$shortCode = '[yaymail_addon_outbid]';
		} elseif ( $customOrder === 'auction_fail' ) {
			$shortCode = '[yaymail_addon_auction_fail]';
		} elseif ( $customOrder === 'Reserve_fail' ) {
			$shortCode = '[yaymail_addon_reserve_fail]';
		} elseif ( $customOrder === 'auction_buy_now' ) {
			$shortCode = '[yaymail_addon_auction_buy_now]';
		} elseif ( $customOrder === 'auction_finished' ) {
			$shortCode = '[yaymail_addon_auction_finish]';
		} elseif ( $customOrder === 'bid_note' ) {
			$shortCode = '[yaymail_addon_bid]';
		} elseif ( $customOrder === 'auction_relist_user' ) {
			$shortCode = '[yaymail_addon_auction_relist_user]';
		} elseif ( $customOrder === 'auction_relist' ) {
			$shortCode = '[yaymail_addon_auction_relist_admin]';
		} elseif ( $customOrder === 'customer_bid_note' ) {
			$shortCode = '[yaymail_addon_customerbid]';
		} elseif ( $customOrder === 'auction_closing_soon' ) {
			$shortCode = '[yaymail_addon_auction_closing_soon]';
		} elseif ( $customOrder === 'auction_win' ) {
			$shortCode = '[yaymail_addon_auction_win]';
		} elseif ( $customOrder === 'remind_to_pay' ) {
			$shortCode = '[yaymail_addon_auction_remind_to_pay]';
		}

		/*
		@@@ Elements default when reset template.
		@@@ Note 1: Add characters '\' before special characters in a string.
		@@@ example 1: "family": "\'Helvetica Neue\',Helvetica,Roboto,Arial,sans-serif",

		@@@ Note 2: Add characters '\' before special characters in a string.
		@@@ example 2: "<h1 style=\"font-family: \'Helvetica Neue\',...."
		*/

		// Elements
		$elements =
		'[{
			"id": "8ffa62b5-7258-42cc-ba53-7ae69638c1fe",
			"type": "Logo",
			"nameElement": "Logo",
			"settingRow": {
				"backgroundColor": "#ECECEC",
				"align": "center",
				"pathImg": "",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50",
				"width": "172",
				"url": "#"
			}
		}, {
			"id": "802bfe24-7af8-48af-ac5e-6560a81345b3",
			"type": "ElementText",
			"nameElement": "Email Heading",
			"settingRow": {
				"content": "<h1 style=\"font-size: 30px; font-weight: 300; line-height: normal; margin: 0; color: inherit;\">' . $emailTitle . '</h1>",
				"backgroundColor": "#96588A",
				"textColor": "#ffffff",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "36",
				"paddingRight": "48",
				"paddingBottom": "36",
				"paddingLeft": "48"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8dere",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "' . $shortCode . '",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "10",
				"paddingRight": "50",
				"paddingBottom": "10",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8d",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "<p><span style=\"font-size: 14px;\">' . $additionalContent . '</span></p>",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "0",
				"paddingRight": "50",
				"paddingBottom": "38",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8ds",
			"type": "ElementText",
			"nameElement": "Footer",
			"settingRow": {
				"content": "<p style=\"font-size: 14px;margin: 0px 0px 16px; text-align: center;\">[yaymail_site_name]&nbsp;- Built with <a style=\"color: #96588a; font-weight: normal; text-decoration: underline;\" href=\"https://woocommerce.com\" target=\"_blank\" rel=\"noopener\">WooCommerce</a></p>",
				"backgroundColor": "#ececec",
				"textColor": "#8a8a8a",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50"
			}
		}]';

		// Templates Subscription
		$templates = array(
			$customOrder => array(),
		);

		$templates[ $customOrder ]['elements'] = $elements;
		return $templates;
	}

}
