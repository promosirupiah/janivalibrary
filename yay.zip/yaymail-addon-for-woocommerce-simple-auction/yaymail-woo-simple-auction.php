<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Simple Auction
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates for WooCommerce Simple Auction plugin
 * Version: 1.2
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.8.0
 * Domain Path: /i18n/languages/
 */

namespace YayMailWooSimpleAuction;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailWooSimpleAuction\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YayMailWooSimpleAuction\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailWooSimpleAuction\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_dependence() {
	wp_enqueue_script( 'yaymail-simple-auction', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.2', true );
	wp_enqueue_style( 'yaymail-simple-auction', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.2' );
}


add_action( 'yaymail_before_enqueue_dependence', 'YayMailWooSimpleAuction\\yaymail_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		if ( class_exists( 'WooCommerce_simple_auction' ) ) {
			$plugins[] = array(
				'plugin_name'      => 'Woo_Simple_Auction', // --> CHANGE HERE => name of plugin (maybe name of the class)
				'addon_components' => array( 'SimpleAutionItems' ), // CHANGE HERE => main-name required
				'template_name'    => array(
					'auction_buy_now',
					'auction_closing_soon',
					'auction_fail',
					'auction_finished',
					'auction_relist',
					'auction_relist_user',
					'auction_win',
					'bid_note',
					'customer_bid_note',
					'outbid_note',
					'remind_to_pay',
					'Reserve_fail',
				),
			);
		}
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailWooSimpleAuction\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {
	if ( class_exists( 'WooCommerce_simple_auction' ) ) {
		if ( $key === 'WC_Email_SA_Auction_Buy_Now'
			|| $key === 'WC_Email_SA_Auction_Closing_soon'
			|| $key === 'WC_Email_SA_Auction_Failed'
			|| $key === 'WC_Email_SA_Auction_Finished'
			|| $key === 'WC_Email_SA_Auction_Relist'
			|| $key === 'WC_Email_SA_Auction_Relist_User'
			|| $key === 'WC_Email_SA_Auction_Win'
			|| $key === 'WC_Email_SA_Bid'
			|| $key === 'WC_Email_SA_Customerbid_Note'
			|| $key === 'WC_Email_SA_Outbid_Note'
			|| $key === 'WC_Email_SA_Reminde_to_pay'
			|| $key === 'WC_Email_SA_Reserve_Failed'
		) {
			$getHeading              = $value->heading;
			$defaultWooSimpleAuction = templateDefault\DefaultWooSimpleAuction::getTemplates( $value->id, $getHeading );
			return $defaultWooSimpleAuction;
		}
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateWooSubscription = array(
			'auction_buy_now',
			'auction_closing_soon',
			'auction_fail',
			'auction_finished',
			'auction_relist',
			'auction_relist_user',
			'auction_win',
			'bid_note',
			'customer_bid_note',
			'outbid_note',
			'remind_to_pay',
			'Reserve_fail',
		);
		if ( in_array( $arrData[2], $templateWooSubscription ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateWooSubscription = array(
			'auction_buy_now',
			'auction_closing_soon',
			'auction_fail',
			'auction_finished',
			'auction_relist',
			'auction_relist_user',
			'auction_win',
			'bid_note',
			'customer_bid_note',
			'outbid_note',
			'remind_to_pay',
			'Reserve_fail',
		);
		if ( in_array( $template, $templateWooSubscription ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( $component['plugin_name'] === 'Woo_Simple_Auction' ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[$position]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates['woo_simple_auction'] = array_merge( isset( $addon_templates['woo_simple_auction'] ) ? $addon_templates['woo_simple_auction'] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Display shortcode in core
add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin' => 'Simple Auction',
			'shortcode' => array(
				['[yaymail_addon_outbid]', 'Auction Outbid'],
				['[yaymail_addon_reserve_fail]', 'Auction Reserve Fail'],
				['[yaymail_addon_customerbid]', 'Auction Customerbid'],
				['[yaymail_addon_bid]', 'Auction Bid'],
				['[yaymail_addon_auction_win]', 'Auction Win'],
				['[yaymail_addon_auction_remind_to_pay]', 'Auction Remind To Pay'],
				['[yaymail_addon_auction_relist_user]', 'Auction Relist User'],
				['[yaymail_addon_auction_relist_admin]', 'Auction Relist Admin'],
				['[yaymail_addon_auction_finish]', 'Auction Finish'],
				['[yaymail_addon_auction_fail]', 'Auction Fail'],
				['[yaymail_addon_auction_closing_soon]', 'Auction Closing Soon'],
				['[yaymail_addon_auction_buy_now]', 'Auction Buy Now'],
				['[yaymail_addon_product_image]', 'Auction Product Image'],
			)
		);

		return $shortcode_list;
	},
	10,
	1
);
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( class_exists( 'WooCommerce_simple_auction' ) ) {
			$shortcode_list[] = 'yaymail_addon_outbid';
			$shortcode_list[] = 'yaymail_addon_reserve_fail';
			$shortcode_list[] = 'yaymail_addon_customerbid';
			$shortcode_list[] = 'yaymail_addon_bid';
			$shortcode_list[] = 'yaymail_addon_auction_win';
			$shortcode_list[] = 'yaymail_addon_auction_remind_to_pay';
			$shortcode_list[] = 'yaymail_addon_auction_relist_user';
			$shortcode_list[] = 'yaymail_addon_auction_relist_admin';
			$shortcode_list[] = 'yaymail_addon_auction_finish';
			$shortcode_list[] = 'yaymail_addon_auction_fail';
			$shortcode_list[] = 'yaymail_addon_auction_closing_soon';
			$shortcode_list[] = 'yaymail_addon_auction_buy_now';
			$shortcode_list[] = 'yaymail_addon_product_image';
		}
		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WooCommerce_simple_auction' ) ) {
			$shortcode_list['[yaymail_addon_outbid]']                = yaymailAddonOutbid( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_reserve_fail]']          = yaymailAddonReserveFail( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_customerbid]']           = yaymailAddonCustomerbid( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_bid]']                   = yaymailAddonBid( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_win]']           = yaymailAddonAuctionWin( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_remind_to_pay]'] = yaymailAddonAuctionRemindToPay( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_relist_user]']   = yaymailAddonAuctionRelistUser( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_relist_admin]']  = yaymailAddonAuctionRelistAdmin( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_finish]']        = yaymailAddonAuctionFinish( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_fail]']          = yaymailAddonAuctionFail( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_closing_soon]']  = yaymailAddonAuctionClosingSoon( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_auction_buy_now]']       = yaymailAddonAuctionBuyNow( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_product_image]']         = yaymailAddonProductImage( $yaymail_informations, $args );
		}
		return $shortcode_list;
	},
	10,
	3
);

function yaymailAddonProductImage( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonProductImage.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonProductImage.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}

function yaymailAddonAuctionBuyNow( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionBuyNow.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionBuyNow.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionClosingSoon( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionClosingSoon.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionClosingSoon.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionFail( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) && isset( $args['reason'] ) ) {
		$product_id = $args['product_id'];
		$reason     = $args['reason'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionFail.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionFail.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionFinish( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionFinish.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionFinish.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionRelistAdmin( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) && isset( $args['reason'] ) ) {
		$product_id = $args['product_id'];
		$reason     = $args['reason'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionRelistAdmin.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionRelistAdmin.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionRelistUser( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionRelistUser.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionRelistUser.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionRemindToPay( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) && isset( $args['checkout_url'] ) && isset( $args['current_bid'] ) ) {
		$product_id   = $args['product_id'];
		$checkout_url = $args['checkout_url'];
		$current_bid  = $args['current_bid'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionRemindToPay.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionRemindToPay.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonAuctionWin( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) && isset( $args['checkout_url'] ) && isset( $args['current_bid'] ) ) {
		$product_id   = $args['product_id'];
		$checkout_url = $args['checkout_url'];
		$current_bid  = $args['current_bid'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonAuctionWin.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonAuctionWin.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonBid( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonBid.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonBid.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonCustomerbid( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonCustomerbid.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonCustomerbid.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonReserveFail( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonReserveFail.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonReserveFail.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymailAddonOutbid( $yaymail_informations, $args = array() ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonOutbid.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonOutbid.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
add_action( 'YaymailAddonSimpleAutionItemsVue', 'YayMailWooSimpleAuction\\yith_vendor_information_vue', 100, 5 );
function yith_vendor_information_vue( $order, $postID = '' ) {
	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonSimpleAutionItems.php';
	$html = ob_get_contents();
	ob_end_clean();
	if ( '' === $html ) {
		$html = '<div></div>';
	}
	echo $html;
}

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonSimpleAutionItems', 'YayMailWooSimpleAuction\\yaymail_addon_yith_vendor_information', 100, 5 );
function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( isset( $args['product_id'] ) ) {
		$product_id = $args['product_id'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonSimpleAutionItems.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonSimpleAutionItems.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	}
}




