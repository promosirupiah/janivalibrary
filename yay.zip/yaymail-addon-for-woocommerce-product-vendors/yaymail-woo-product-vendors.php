<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Product Vendors
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates for WooCommerce Product Vendors plugin
 * Version: 1.0
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 6.0.0
 * Domain Path: /i18n/languages/
 */

namespace YayMailWooProductVendors;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailWooProductVendors\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YayMailWooProductVendors\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailWooProductVendors\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_dependence() {
	wp_enqueue_script( 'yaymail_dependence', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.0', true );
	wp_enqueue_style( 'yaymail_dependence', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.0' );
}
add_action( 'yaymail_before_enqueue_dependence', 'YayMailWooProductVendors\\yaymail_dependence' );

add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => 'Woo_Product_Vendors', // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array( 'ProductVendorsOrderDetails' ), // CHANGE HERE => main-name required
			'template_name'    => array( 
				'vendor_approval',
			 	'cancelled_order_email_to_vendor',
			  	'order_email_to_vendor',
			   	'order_fulfill_status_to_admin',
				'order_note_to_customer',
				'product_added_notice',
				'vendor_registration_to_admin',
				'vendor_registration_to_vendor',
			 ),
		);
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailWooProductVendors\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {

	if ( 'WC_Product_Vendors_Approval' == $key
		|| 'WC_Product_Vendors_Order_Fulfill_Status_To_Admin' == $key
		|| 'WC_Product_Vendors_Product_Added_Notice' == $key
		|| 'WC_Product_Vendors_Registration_Email_To_Admin' == $key
		|| 'WC_Product_Vendors_Registration_Email_To_Vendor' == $key
	) {
		$getHeading          = $value->heading;
		$defaultWooProductVendors = templateDefault\DefaultWooProductVendors::getTemplates( $value->id, $getHeading );
		return $defaultWooProductVendors;
	} elseif ('WC_Product_Vendors_Order_Email_To_Vendor' == $key) 
	{
		$getHeading          = $value->heading;
		$defaultWooProductVendorsOrder = templateDefault\DefaultWooProductVendorsOrder::getTemplates( $value->id, $getHeading );
		return $defaultWooProductVendorsOrder;
	}
	elseif ('WC_Product_Vendors_Order_Note_To_Customer' == $key
	|| 'WC_Product_Vendors_Cancelled_Order_Email_To_Vendor' == $key
	) 
	{
		$getHeading          = $value->heading;
		$defaultWooProductVendorsOrderNote = templateDefault\DefaultWooProductVendorsOrderNote::getTemplates( $value->id, $getHeading );
		return $defaultWooProductVendorsOrderNote;
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateWooSubscription = array( 
				'vendor_approval',
			 	'cancelled_order_email_to_vendor',
			  	'order_email_to_vendor',
			   	'order_fulfill_status_to_admin',
				'order_note_to_customer',
				'product_added_notice',
				'vendor_registration_to_admin',
				'vendor_registration_to_vendor',
			 );
		if ( in_array( $arrData[2], $templateWooSubscription ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateWooSubscription = array( 
				'vendor_approval',
			 	'cancelled_order_email_to_vendor',
			  	'order_email_to_vendor',
			   	'order_fulfill_status_to_admin',
				'order_note_to_customer',
				'product_added_notice',
				'vendor_registration_to_admin',
				'vendor_registration_to_vendor',
			 );
		if ( in_array( $template, $templateWooSubscription ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( $component['plugin_name'] === 'Woo_Product_Vendors' ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[$position]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates['woo_product_vendors'] = array_merge( isset( $addon_templates['woo_product_vendors'] ) ? $addon_templates['woo_product_vendors'] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Display shortcode in core
add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin' => 'WooCommerce Product Vendors',
			'shortcode' => array(
				['[yaymail_addon_product_vendor_name]', 'Vendor name'],
				['[yaymail_addon_product_vendor_order_item_name]', 'Order item_name'],
				['[yaymail_addon_product_vendor_fulfillment_status]', 'Fulfillment status'],
				['[yaymail_addon_product_vendor_note]', 'Vendor note'],
				['[yaymail_addon_product_vendor_product_name]', 'Product name'],
				['[yaymail_addon_product_vendor_product_link]', 'Product link'],
				['[yaymail_addon_product_vendor_user_email]', 'User email'],
				['[yaymail_addon_product_vendor_first_name]', 'First name'],
				['[yaymail_addon_product_vendor_last_name]', 'Last name'],
				['[yaymail_addon_product_vendor_vendor_desc]', 'Vendor desc'],
				['[yaymail_addon_template_vendor_approval]', 'Template vendor approval'],
				['[yaymail_addon_template_vendor_registration_to_vendor]', 'Template vendor registration to vendor'],
			)
		);

		return $shortcode_list;
	},
	10,
	1
);
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = 'yaymail_addon_product_vendor_name';
		$shortcode_list[] = 'yaymail_addon_product_vendor_order_item_name';
		$shortcode_list[] = 'yaymail_addon_product_vendor_fulfillment_status';
		$shortcode_list[] = 'yaymail_addon_product_vendor_note';
		$shortcode_list[] = 'yaymail_addon_product_vendor_product_name';
		$shortcode_list[] = 'yaymail_addon_product_vendor_product_link';
		$shortcode_list[] = 'yaymail_addon_product_vendor_user_email';
		$shortcode_list[] = 'yaymail_addon_product_vendor_first_name';
		$shortcode_list[] = 'yaymail_addon_product_vendor_last_name';
		$shortcode_list[] = 'yaymail_addon_product_vendor_vendor_desc';

		$shortcode_list[] = 'yaymail_addon_template_vendor_approval';
		$shortcode_list[] = 'yaymail_addon_template_vendor_registration_to_vendor';
		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		$shortcode_list['[yaymail_addon_product_vendor_name]'] = yaymail_addon_product_vendor_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_order_item_name]'] = yaymail_addon_product_vendor_order_item_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_fulfillment_status]'] = yaymail_addon_product_vendor_fulfillment_status( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_note]'] = yaymail_addon_product_vendor_note( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_product_name]'] = yaymail_addon_product_vendor_product_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_product_link]'] = yaymail_addon_product_vendor_product_link( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_user_email]'] = yaymail_addon_product_vendor_user_email( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_first_name]'] = yaymail_addon_product_vendor_first_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_last_name]'] = yaymail_addon_product_vendor_last_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_product_vendor_vendor_desc]'] = yaymail_addon_product_vendor_vendor_desc( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_vendor_approval]'] = yaymail_addon_template_vendor_approval( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_vendor_registration_to_vendor]'] = yaymail_addon_template_vendor_registration_to_vendor( $yaymail_informations, $args );
		return $shortcode_list;
	},
	10,
	3
);

function yaymail_addon_template_vendor_registration_to_vendor( $yaymail_informations, $args = array() ) {
	if( isset($args['password_reset_key']) && isset($args['user_login']) ) { 
		$password_reset_key = $args['password_reset_key'];
		$user_login = $args['user_login'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_vendor_registration_to_vendor.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/templateSample/yaymail_addon_template_vendor_registration_to_vendor.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
	
}

function yaymail_addon_template_vendor_approval( $yaymail_informations, $args = array() ) {
	if(isset($args['role'])) { 
		$role = $args['role'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_vendor_approval.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/templateSample/yaymail_addon_template_vendor_approval.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
	
}

function yaymail_addon_product_vendor_vendor_desc( $yaymail_informations, $args = array() ) {
	if(isset($args['vendor_desc'])) {
		return stripslashes( $args['vendor_desc'] );
	}
	return 'vendor_desc';
}

function yaymail_addon_product_vendor_last_name( $yaymail_informations, $args = array() ) {
	if(isset($args['last_name'])) {
		return $args['last_name'];
	}
	return 'last_name';
}

function yaymail_addon_product_vendor_first_name( $yaymail_informations, $args = array() ) {
	if(isset($args['first_name'])) {
		return $args['first_name'];
	}
	return 'first_name';
}

function yaymail_addon_product_vendor_user_email( $yaymail_informations, $args = array() ) {
	if(isset($args['user_email'])) {
		return $args['user_email'];
	}
	return 'user_email';
}

function yaymail_addon_product_vendor_product_link( $yaymail_informations, $args = array() ) {
	if(isset($args['product_link'])) {
		return esc_url( $args['product_link'] );
	}
	return 'product_link';
}

function yaymail_addon_product_vendor_product_name( $yaymail_informations, $args = array() ) {
	if(isset($args['product_name'])) {
		return $args['product_name'];
	}
	return 'product_name';
}

function yaymail_addon_product_vendor_note( $yaymail_informations, $args = array() ) {
	if(isset($args['note'])) {
		return wpautop( wptexturize( $args['note'] ) );
	}
	return 'note';
}

function yaymail_addon_product_vendor_fulfillment_status( $yaymail_informations, $args = array() ) {
	if(isset($args['fulfillment_status'])) {
		return ucfirst( $args['fulfillment_status'] );
	}
	return 'fulfillment_status';
}

function yaymail_addon_product_vendor_order_item_name( $yaymail_informations, $args = array() ) {
	if(isset($args['order_item_name'])) {
		return $args['order_item_name'];
	}
	return 'order_item_name';
}

function yaymail_addon_product_vendor_name( $yaymail_informations, $args = array() ) {
	if(isset($args['vendor_name'])) {
		return $args['vendor_name'];
	}
	return 'vendor_name';
}

/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
add_action( 'YaymailAddonProductVendorsOrderDetailsVue', 'YayMailWooProductVendors\\yith_vendor_information_vue', 100, 5 );
function yith_vendor_information_vue( $order, $postID = '' ) {
	
	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonProductVendorsOrderDetails.php';
	$html = ob_get_contents();
	ob_end_clean();
	if ( '' === $html ) {
		$html = '<div></div>';
	}
	
	echo $html;
}

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonProductVendorsOrderDetails', 'YayMailWooProductVendors\\yaymail_addon_yith_vendor_information', 100, 5 );
function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( isset( $args['order'] ) && isset( $args['this_vendor'] ) && isset( $args['email'] ) ) {
		$order = $args['order'];
		$this_vendor = $args['this_vendor'];
		$email = $args['email'];

		$sent_to_admin = isset($args['sent_to_admin']) ? $args['sent_to_admin'] : false;
		$plain_text = isset($args['plain_text']) ? $args['plain_text'] : '';
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonProductVendorsOrderDetails.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/templateSample/YaymailAddonProductVendorsOrderDetails.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	}
}




