<?php
/**
 * Vendor registration email to vendor.
 *
 * @version 2.0.21
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<h3><?php esc_html_e( 'Hello! Thank you for registering to become a vendor.', 'woocommerce-product-vendors' ); ?></h3>

<p><?php esc_html_e( 'Once your application has been approved, you will be notified.', 'woocommerce-product-vendors' ); ?></p>

<p><?php esc_html_e( 'Here is your login account information:', 'woocommerce-product-vendors' ); ?></p>

<ul>
	<li><?php printf( esc_html__( 'Login Address: %s', 'woocommerce-product-vendors' ), '<a href="' . esc_url( wp_login_url() ) . '">' . wp_login_url() . '</a>' ); ?></li>
	<li><?php printf( esc_html__( 'Login Name: %s', 'woocommerce-product-vendors' ), 'user_login' ); ?></li>
</ul>


