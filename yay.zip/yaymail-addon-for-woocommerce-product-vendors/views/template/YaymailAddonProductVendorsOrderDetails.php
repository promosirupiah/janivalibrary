<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color    = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
$yaymail_settings   = get_option( 'yaymail_settings' );
$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
$titleProduct       = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleQuantity      = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Quantity';
$titlePrice         = isset( $attrs['titlePrice'] ) ? $attrs['titlePrice'] : 'Price';
$borderColor        = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor          = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleColor         = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
?>
<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; 
	<?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; 
	<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; 
  "
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
>
	<tbody>
		<tr>
			<td
				id="web-<?php echo esc_attr( $id ); ?>-order-item"
				class="web-order-item"
				align="left"
				style='font-size: 13px; line-height: 22px; word-break: break-word;
				<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
				<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
				'
			>
			<div style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
				<table cellspacing="0" cellpadding="6" border="1" style="width:100%;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
					<thead>
						<tr style="<?php echo esc_attr( $textColor ); ?>">
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleProduct, 'yaymail' ); ?></th>
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleQuantity, 'yaymail' ); ?></th>
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titlePrice, 'yaymail' ); ?></th>
						</tr>
					</thead>
					<tbody>
                    <?php
                        $pass_shipping = false;

                        foreach ( $order->get_items() as $item_id => $item ) {
                            $_product  = $item->get_product();
                            $item_meta = version_compare( WC_VERSION, '3.0', '<' ) ? new WC_Order_Item_Meta( $item, $_product ) : new WC_Order_Item_Product( $item_id );

                            if ( version_compare( WC_VERSION, '3.0.0', '<' ) ) {
                                $product_id = $_product->id;
                            } else {
                                $product_id = ( 'product_variation' === $_product->post_type ) ? $_product->get_parent_id() : $_product->get_id();
                            }

                            $pass_shipping |= 'yes' === get_post_meta( $product_id, '_wcpv_product_pass_shipping', true );
                            $vendor_id = WC_Product_Vendors_Utils::get_vendor_id_from_product( $product_id );

                            // remove the order items that are not from this vendor
                            if ( $this_vendor !== $vendor_id ) {
                                continue;
                            }

                            if ( apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {
                                ?>
                                <tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'order_item', $item, $order ) ); ?>">
                                    <td class="td" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php

                                        $show_image = apply_filters( 'wcpv_email_order_details_show_image', false );

                                        // Show title/image etc
                                        if ( $show_image ) {
                                            echo apply_filters( 'woocommerce_order_item_thumbnail', '<div style="margin-bottom: 5px"><img src="' . ( $_product->get_image_id() ? current( wp_get_attachment_image_src( $_product->get_image_id(), 'thumbnail') ) : wc_placeholder_img_src() ) .'" alt="' . esc_attr__( 'Product Image', 'woocommerce-product-vendors' ) . '" height="' . esc_attr( $image_size[1] ) . '" width="' . esc_attr( $image_size[0] ) . '" style="vertical-align:middle; margin-right: 10px;" /></div>', $item );
                                        }

                                        // Product name
                                        echo apply_filters( 'woocommerce_order_item_name', $item['name'], $item, false );

                                        // SKU
                                        if ( is_object( $_product ) && $_product->get_sku() ) {
                                            echo ' (#' . $_product->get_sku() . ')';
                                        }

                                        // allow other plugins to add additional product information here
                                        do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order );

                                        // Variation
                                        if ( version_compare( WC_VERSION, '3.0', '<' ) ) {
                                            if ( ! empty( $item_meta->meta ) ) {
                                                echo '<br/><small>' . nl2br( $item_meta->display( true, true, '_', "\n" ) ) . '</small>';
                                            }
                                        } else {
                                            wc_display_item_meta( $item );
                                        }

                                        // allow other plugins to add additional product information here
                                        do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order );

                                    ?></td>
                                    <td class="td" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo apply_filters( 'woocommerce_email_order_item_quantity', $item['qty'], $item ); ?></td>
                                    <td class="td" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></td>
                                </tr>
                                <?php
                            }
                        }
                    ?>
					</tbody>
                    <?php
                    $shipping_method = $order->get_shipping_method();
                    $customer_note   = $order->get_customer_note();
                    ?>

                    <tfoot>
                            <?php if ( $pass_shipping && ! empty( $shipping_method ) ) : ?>
                                <tr>
                                    <th class="td" scope="row" colspan="2" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php esc_html_e( 'Shipping method', 'woocommerce-product-vendors' ); ?></th>
                                    <td class="td" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html( $shipping_method ); ?></td>
                                </tr>
                            <?php endif; ?>

                            <?php
                            /**
                             * Determine if we should show the customer added note.
                             *
                             * @since 2.1.52
                             * @param boolean  $show_note Whether to show cusotmer notes. Default true.
                             * @param WC_Order $order     Order object.
                             */
                            if ( $customer_note && apply_filters( 'wcpv_email_to_vendor_show_notes', true, $order ) ) : ?>
                                <tr>
                                    <th class="td" scope="row" colspan="2" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
                                        <?php esc_html_e( 'Customer note:', 'woocommerce-product-vendors' ); ?>
                                    </th>
                                    <td class="td" style="text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
                                        <?php echo wp_kses_post( nl2br( wptexturize( $customer_note ) ) ); ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tfoot>
				</table>

                <?php do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email ); ?>

                <?php do_action( 'wc_product_vendors_email_order_meta', $order, $sent_to_admin, $plain_text, $email ); ?>
			</div>
		</td>
	  </tr>
	</tbody>
</table>