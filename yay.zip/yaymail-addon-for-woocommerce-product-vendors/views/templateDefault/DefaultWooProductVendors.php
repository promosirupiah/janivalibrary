<?php

namespace YayMailWooProductVendors\templateDefault;

defined( 'ABSPATH' ) || exit;

class DefaultWooProductVendors {

	protected static $instance = null;

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function getTemplates( $customOrder, $emailHeading ) {
		/*
		@@@ Html default send email.
		@@@ Note: Add characters '\' before special characters in a string.
		@@@ Example: font-family: \'Helvetica Neue\'...
		*/

		$emailTitle        = __( $emailHeading, 'woocommerce' );
		$customText        = '';
		$emailtext         = esc_html__( 'A subscription belonging to ', 'woocommerce' ) . esc_html( do_shortcode( '[yaymail_billing_first_name] [yaymail_billing_last_name]' ) ) . $customText . esc_html__( ' Their subscription\'s details are as follows:', 'woocommerce' );
		$additionalContent = __( 'Thanks for reading.', 'woocommerce' );


		if ( 'order_fulfill_status_to_admin' == $customOrder ) {
			$emailtext         = '<h3>' . esc_html__( 'Hello! A vendor has updated an order item fulfillment status.', 'woocommerce-product-vendors' ) .'</h3>';
			$emailtext         .= '<p>' . esc_html__( 'Order Information:', 'woocommerce-product-vendors' ) .'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Vendor', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_name]' ) ).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Order Number', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_order_number]' ) ).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Order Item', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_order_item_name]' )).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Fulfillment Status', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_fulfillment_status]' ) ).'</p>';
			$emailtext         .= '<p>' . '<a href=\"' . admin_url( 'post.php?post=' . do_shortcode( '[yaymail_order_id]' ) . '&action=edit' ) . '\">' . do_shortcode( '[yaymail_order_number]' ) . '</a>'.'</p>';
			$additionalContent = __( 'Congratulations on the sale.', 'woocommerce' );
		}

		if ( 'vendor_registration_to_admin' == $customOrder ) {
			$emailtext         = '<h3>' . esc_html__( 'Hello! A vendor has requested to be registered.', 'woocommerce-product-vendors' ) .'</h3>';
			$emailtext         .= '<p>' . esc_html__( 'Vendor information:', 'woocommerce-product-vendors' ) .'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Email', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_user_email]' ) ).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'First Name', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_first_name]' ) ).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Last Name', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_last_name]' ) ).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Vendor Name', 'woocommerce-product-vendors' ) . ': %s', do_shortcode( '[yaymail_addon_product_vendor_name]' ) ).'</p>';
			$emailtext         .= '<p>' . sprintf( esc_html__( 'Vendor Description', 'woocommerce-product-vendors' ) . ':<br />%s', do_shortcode( '[yaymail_addon_product_vendor_vendor_desc]' ) ).'</p>';
		}

		if ( 'product_added_notice' == $customOrder ) {
			$emailtext         = '<h3>' . sprintf( esc_html__( 'Hello! A vendor ( %s ) has added a new product awaiting review.', 'woocommerce-product-vendors' ), do_shortcode( '[yaymail_addon_product_vendor_name]' ) ) .'</h3>';
			$emailtext         .= '</br>' . '<a href=\"' . do_shortcode( '[yaymail_addon_product_vendor_product_link]' ) . '\">' . do_shortcode( '[yaymail_addon_product_vendor_product_name]' ) . '</a>';
		}

		if ( 'vendor_approval' == $customOrder ) {
			$emailtext         = esc_html( do_shortcode( '[yaymail_addon_template_vendor_approval]' ) );
		}

		if ( 'vendor_registration_to_vendor' == $customOrder ) {
			$emailtext         = esc_html( do_shortcode( '[yaymail_addon_template_vendor_registration_to_vendor]' ) );
		}

		/*
		@@@ Elements default when reset template.
		@@@ Note 1: Add characters '\' before special characters in a string.
		@@@ example 1: "family": "\'Helvetica Neue\',Helvetica,Roboto,Arial,sans-serif",

		@@@ Note 2: Add characters '\' before special characters in a string.
		@@@ example 2: "<h1 style=\"font-family: \'Helvetica Neue\',...."
		*/

		// Elements
		$elements =
		'[{
			"id": "8ffa62b5-7258-42cc-ba53-7ae69638c1fe",
			"type": "Logo",
			"nameElement": "Logo",
			"settingRow": {
				"backgroundColor": "#ECECEC",
				"align": "center",
				"pathImg": "",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50",
				"width": "172",
				"url": "#"
			}
		}, {
			"id": "802bfe24-7af8-48af-ac5e-6560a81345b3",
			"type": "ElementText",
			"nameElement": "Email Heading",
			"settingRow": {
				"content": "<h1 style=\"font-size: 30px; font-weight: 300; line-height: normal; margin: 0; color: inherit;\">' . $emailTitle . '</h1>",
				"backgroundColor": "#96588A",
				"textColor": "#ffffff",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "36",
				"paddingRight": "48",
				"paddingBottom": "36",
				"paddingLeft": "48"
			}
		}, {
			"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $emailtext . '</span></p>",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "47",
				"paddingRight": "50",
				"paddingBottom": "0",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8d",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "<p><span style=\"font-size: 14px;\">' . $additionalContent . '</span></p>",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "0",
				"paddingRight": "50",
				"paddingBottom": "38",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8ds",
			"type": "ElementText",
			"nameElement": "Footer",
			"settingRow": {
				"content": "<p style=\"font-size: 14px;margin: 0px 0px 16px; text-align: center;\">[yaymail_site_name]&nbsp;- Built with <a style=\"color: #96588a; font-weight: normal; text-decoration: underline;\" href=\"https://woocommerce.com\" target=\"_blank\" rel=\"noopener\">WooCommerce</a></p>",
				"backgroundColor": "#ececec",
				"textColor": "#8a8a8a",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50"
			}
		}]';

		// Templates Subscription
		$templates = array(
			$customOrder => array(),
		);

		$templates[ $customOrder ]['elements'] = $elements;
		return $templates;
	}

}
