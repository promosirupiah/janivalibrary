<?php
/**
 * New Coupon Email
 *
 * An email is sent to admin and customer when a vendor generate a coupon
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! $coupon ) {
    return;
}

$coupon_link = wc_get_page_permalink( 'myaccount' );
$view_request_link = $coupon_link . '/view-warranty-request/'. $request['id'];

?>

<p><?php echo sprintf( '%s %s,', __( 'Hello', 'wc-return-warranty-pro' ), $request['customer']['first_name'] . ' ' . $request['customer']['last_name'] ); ?></p>

<p><?php echo sprintf( '%s <a href="%s">%s %d</a>', __( 'You got a new coupon according to this return request', 'wc-return-warranty-pro' ), $view_request_link, __( 'Request #', 'wc-return-warranty-pro' ), $request['id'] ); ?></p>

<p><?php _e( 'Details of Coupon:', 'wc-return-warranty-pro' ); ?></p>
<hr>

<p><?php printf( __( 'Coupon Code: <strong>%s</strong>', 'wc-return-warranty-pro' ), $coupon->get_code() ); ?></p>
<p><?php printf( __( 'Coupon Amount: <strong>%s</strong>', 'wc-return-warranty-pro' ), wc_price( $coupon->get_amount() ) ); ?></p>

