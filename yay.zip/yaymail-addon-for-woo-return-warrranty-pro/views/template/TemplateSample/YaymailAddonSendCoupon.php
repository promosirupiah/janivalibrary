<?php
/**
 * New Coupon Email
 *
 * An email is sent to admin and customer when a vendor generate a coupon
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


?>

<p><?php echo sprintf( '%s %s,', __( 'Hello', 'wc-return-warranty-pro' ), 'first_name' . ' ' . 'last_name' ); ?></p>

<p><?php echo sprintf( '%s <a href="%s">%s %d</a>', __( 'You got a new coupon according to this return request', 'wc-return-warranty-pro' ), '#', __( 'Request #', 'wc-return-warranty-pro' ), '1' ); ?></p>

<p><?php _e( 'Details of Coupon:', 'wc-return-warranty-pro' ); ?></p>
<hr>

<p><?php printf( __( 'Coupon Code: <strong>%s</strong>', 'wc-return-warranty-pro' ), '1' ); ?></p>
<p><?php printf( __( 'Coupon Amount: <strong>%s</strong>', 'wc-return-warranty-pro' ), wc_price( '10' ) ); ?></p>

