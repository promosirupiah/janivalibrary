<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color    = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
$yaymail_settings   = get_option( 'yaymail_settings' );
$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
$titleProduct       = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleQuantity      = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Quantity';
$titlePrice         = isset( $attrs['titlePrice'] ) ? $attrs['titlePrice'] : 'Price';
$borderColor        = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor          = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleColor         = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$text_align        = is_rtl() ? 'right' : 'left';
?>
<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; 
	<?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; 
	<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; 
  "
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
>
	<tbody>
		<tr>
			<td
				id="web-<?php echo esc_attr( $id ); ?>-order-item"
				class="web-order-item"
				align="left"
				style='font-size: 13px; line-height: 22px; word-break: break-word;
				<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
				<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
				'
			>
			<div style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
				<table cellspacing="0" cellpadding="6" border="1" style="width:100%;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
					<thead>
						<tr style="<?php echo esc_attr( $textColor ); ?>">
							<th scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;padding:12px;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleProduct, 'yaymail' ); ?></th>
							<th scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;padding:12px;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleQuantity, 'yaymail' ); ?></th>
							<th scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;padding:12px;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titlePrice, 'yaymail' ); ?></th>
						</tr>
					</thead>
					<tbody>
                        <tr>
                            <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
                                <?php
                                    echo '<img src="' . esc_url( wc_placeholder_img_src( $image_size ) ) . '" width="32px" height="32px">';
                                    echo 'Sample Product';
                                ?>
                            </td>
                            <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
                                <?php echo wp_kses_post('1'); ?>
                            </td>
                            <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
                                <?php echo wp_kses_post( wc_price( '10' ) ); ?>
                            </td>
                        </tr>
                    </tbody>
				</table>
			</div>
		</td>
	  </tr>
	</tbody>
</table>