<?php
/**
 * New Coupon Email
 *
 * An email is sent to admin and customer when a vendor generate a coupon
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


$admin_request_link    = add_query_arg( ['page' => 'wc-return-warranty', 'request_id' => $request_id ], admin_url( 'admin.php' ) );
$myaccount_link        = wc_get_page_permalink( 'myaccount' );
$customer_request_link = $myaccount_link . '/view-warranty-request/'. $request_id;
?>

<p><?php echo sprintf( '%s %s,', __( 'Hello', 'wc-return-warranty-pro' ), 'name' ); ?></p>

<p><?php echo sprintf( '%s %d', __( 'You got a new message for Request ID #', 'wc-return-warranty-pro' ), '1' ); ?></p>
<p><?php echo sprintf( '%s : %s', __( 'You message is', 'wc-return-warranty-pro' ), 'message_body' ); ?></p>


<p><a href="#"><?php _e( 'View Message', 'wc-return-warranty-pro' ) ?></a></p>


<hr>
