<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Return and Warrranty Pro
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates for WooCommerce Return and Warrranty Pro plugin
 * Version: 1.1
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 6.3.1
 * Domain Path: /i18n/languages/
 */

namespace YayMailWooReturnWarrrantyPro;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailWooReturnWarrrantyPro\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YayMailWooReturnWarrrantyPro\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailWooReturnWarrrantyPro\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_dependence() {
	wp_enqueue_script( 'yaymail-ReturnWarrranty', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.0', true );
	wp_enqueue_style( 'yaymail-ReturnWarrranty', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.0' );
}

add_action( 'yaymail_before_enqueue_dependence', 'YayMailWooReturnWarrrantyPro\\yaymail_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => 'Woo_Return_Warrranty_Pro', // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array( 'WooReturnWarrrantyPro' ), // CHANGE HERE => main-name required
			'template_name'    => array( 'WCRW_Send_Coupon_Email', 'WCRW_Send_Message_Email', 'wcrw_cancel_order_request', 'wcrw_create_request_to_admin','wcrw_create_request_to_customer', 'wcrw_update_request_notification'),
		);
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailWooReturnWarrrantyPro\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {

	if ( 'WCRW_Send_Coupon_Email' == $key
		|| 'WCRW_Send_Message_Email' == $key
	) {
		$getHeading          = $value->get_heading();
		$defaultWooReturnWarrrantyPro = templateDefault\DefaultWooReturnWarrrantyPro::getTemplates( $value->id, $getHeading );
		return $defaultWooReturnWarrrantyPro;
	} elseif( 'WCRW_Cancel_Order_Request' == $key
		|| 'WCRW_Create_Request_Admin' == $key
		|| 'WCRW_Create_Request_Customer' == $key
		|| 'WCRW_Update_Request' == $key
	) {
		$getHeading          = $value->get_heading();
		$defaultWooReturnWarrranty = templateDefault\DefaultWooReturnWarrranty::getTemplates( $value->id, $getHeading );
		return $defaultWooReturnWarrranty;
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateWooSubscription = array( 'WCRW_Send_Coupon_Email', 'WCRW_Send_Message_Email', 'wcrw_cancel_order_request', 'wcrw_create_request_to_admin','wcrw_create_request_to_customer', 'wcrw_update_request_notification');
		if ( in_array( $arrData[2], $templateWooSubscription ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateWooSubscription = array( 'WCRW_Send_Coupon_Email', 'WCRW_Send_Message_Email', 'wcrw_cancel_order_request', 'wcrw_create_request_to_admin','wcrw_create_request_to_customer', 'wcrw_update_request_notification');
		if ( in_array( $template, $templateWooSubscription ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( $component['plugin_name'] === 'Woo_Return_Warrranty_Pro' ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[$position]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates['woo_return_warrranty_pro'] = array_merge( isset( $addon_templates['woo_return_warrranty_pro'] ) ? $addon_templates['woo_return_warrranty_pro'] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Display shortcode in core
add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin' => 'WooCommerce Return and Warrranty Pro',
			'shortcode' => array(
				['[yaymail_addon_template_send_coupon]', 'Template send coupon'],
				['[yaymail_addon_template_send_message]', 'Template send message'],
				['[yaymail_addon_view_request_link]', 'View request link'],
				['[yaymail_addon_customer_name]', 'Customer name'],
				['[yaymail_addon_request_coupon_id]', 'Request coupon id'],
				['[yaymail_addon_coupon_code]', 'Coupon code'],
				['[yaymail_addon_coupon_get_amount]', 'Coupon get amount'],
				['[yaymail_addon_request_message_id]', 'Request message id'],
				['[yaymail_addon_message_user_name]', 'Message user name'],
				['[yaymail_addon_message_body]', 'Message body'],
				['[yaymail_addon_request_status]', 'Request status'],
			)
		);

		return $shortcode_list;
	},
	10,
	1
);
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		//Shortcode for template
		$shortcode_list[] = 'yaymail_addon_template_send_coupon';
		$shortcode_list[] = 'yaymail_addon_template_send_message';

		$shortcode_list[] = 'yaymail_addon_view_request_link';
		$shortcode_list[] = 'yaymail_addon_customer_name';
		$shortcode_list[] = 'yaymail_addon_request_coupon_id';
		$shortcode_list[] = 'yaymail_addon_coupon_code';
		$shortcode_list[] = 'yaymail_addon_coupon_get_amount';

		$shortcode_list[] = 'yaymail_addon_request_message_id';
		$shortcode_list[] = 'yaymail_addon_message_user_name';
		$shortcode_list[] = 'yaymail_addon_message_body';
		$shortcode_list[] = 'yaymail_addon_request_status';

		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		$shortcode_list['[yaymail_addon_template_send_coupon]'] = yaymailAddonSendCoupon( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_send_message]'] = yaymailAddonSendMessage( $yaymail_informations, $args );

		$shortcode_list['[yaymail_addon_view_request_link]'] = yaymail_addon_view_request_link( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_customer_name]'] = yaymail_addon_customer_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_request_coupon_id]'] = yaymail_addon_request_coupon_id( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_coupon_code]'] = yaymail_addon_coupon_code( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_coupon_get_amount]'] = yaymail_addon_coupon_get_amount( $yaymail_informations, $args );

		$shortcode_list['[yaymail_addon_request_message_id]'] = yaymail_addon_request_message_id( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_message_user_name]'] = yaymail_addon_message_user_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_message_body]'] = yaymail_addon_message_body( $yaymail_informations, $args );

		$shortcode_list['[yaymail_addon_request_status]'] = yaymail_addon_request_status( $yaymail_informations, $args );
		return $shortcode_list;
	},
	10,
	3
);

function yaymail_addon_request_status( $yaymail_informations, $args = array() ) {
	if ( isset($args['request']) ) {
		$request = $args['request'];
		$status = wcrw_warranty_request_status( $request['status'] );
		return $status;
	}
	return 'request_status';
}

function yaymail_addon_message_body( $yaymail_informations, $args = array() ) {
	if ( isset($args['message_body']) ) {
		return $args['message_body'];
	}
	return 'message_body';
}

function yaymail_addon_message_user_name( $yaymail_informations, $args = array() ) {
	if ( isset($args['to_user']) ) {
		$to_user = $args['to_user'];
		return $to_user->first_name . ' ' . $to_user->last_name;
	}
	return 'user_name';
}

function yaymail_addon_request_message_id( $yaymail_informations, $args = array() ) {
	if ( isset($args['request_id']) ) {
		return $args['request_id'];
	}
	return '1';
}

function yaymail_addon_coupon_get_amount( $yaymail_informations, $args = array() ) {
	if ( isset($args['coupon']) ) {
		$coupon = $args['coupon'];

		return wc_price( $coupon->get_amount() );
	}
	return wc_price( '10' );
}

function yaymail_addon_coupon_code( $yaymail_informations, $args = array() ) {
	if ( isset($args['coupon']) ) {
		$coupon = $args['coupon'];

		return $coupon->get_code();
	}
	return '1';
}

function yaymail_addon_request_coupon_id( $yaymail_informations, $args = array() ) {
	if ( isset($args['request']) ) {
		$request = $args['request'];

		return $request['id'];
	}
	return '1';
}

function yaymail_addon_customer_name( $yaymail_informations, $args = array() ) {
	if ( isset($args['request']) ) {
		$request = $args['request'];
		$customer_name = $request['customer']['first_name'] . ' ' . $request['customer']['last_name'];

		return $customer_name;
	}
	return 'customer_name';
}

function yaymail_addon_view_request_link( $yaymail_informations, $args = array() ) {
	if ( isset($args['request']) ) {
		$request = $args['request'];
		$coupon_link = wc_get_page_permalink( 'myaccount' );
		$view_request_link = $coupon_link . '/view-warranty-request/'. $request['id'];

		return $view_request_link;
	}
	return wc_get_page_permalink( 'myaccount' );
}

function yaymailAddonSendMessage( $yaymail_informations, $args = array() ) {
	if ( isset($args['request_id']) && isset($args['to_user']) && isset($args['message_body']) ) {
		$request_id = $args['request_id'];
		$to_user = $args['to_user'];
		$message_body = $args['message_body'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonSendMessage.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/YaymailAddonSendMessage.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
	
}

function yaymailAddonSendCoupon( $yaymail_informations, $args = array() ) {
	if ( isset($args['coupon']) && isset($args['request']) ) {
		$coupon = $args['coupon'];
		$request = $args['request'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonSendCoupon.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/YaymailAddonSendCoupon.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
	
}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
add_action( 'YaymailAddonWooReturnWarrrantyProVue', 'YayMailWooReturnWarrrantyPro\\yith_vendor_information_vue', 100, 5 );
function yith_vendor_information_vue( $order, $postID = '' ) {
	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonWooReturnWarrrantyPro.php';
	$html = ob_get_contents();
	ob_end_clean();

	echo $html;
}

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonWooReturnWarrrantyPro', 'YayMailWooReturnWarrrantyPro\\yaymail_addon_yith_vendor_information', 100, 5 );
function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( isset( $args['request'] ) ) {
		$request = $args['request'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooReturnWarrrantyPro.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/YaymailAddonWooReturnWarrrantyPro.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	}
}




