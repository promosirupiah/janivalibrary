<?php
	$yaymail_settings                = get_option( 'yaymail_settings' );
	$orderImagePostions              = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
	$orderImage                      = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
	$image_width                     = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
	$image_height                    = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
	$image_size                      = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
	$description_template_email_text = get_option( 'ywgc_description_template_email_text' );
	$email_button_label_get_option   = get_option( 'ywgc_email_button_label', esc_html__( 'Apply your gift card code', 'yith-woocommerce-gift-cards' ) );
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
				<div
				class="yaymail-items-order-border"
					style="min-height: 10px"
					:style="{
					color: emailContent.settingRow.textColor,
					borderColor: emailContent.settingRow.borderColor,
					}"
				>
					<p style="margin-bottom:15px; text-align:center; margin:0 0 16px">
						<?php echo esc_html( 'Hi, you have received this gift card from YayMail, use it on our online shop.' ); ?>
					</p>

					<table cellspacing="0" style="padding:1em; border:3px solid #f4f4f4; width:100%">
						<tbody>
							<tr>
								<td colspan="2" style="text-align:center; padding:12px">
									<img data-imagetype="External" src="<?php echo wp_kses_post( wc_placeholder_img_src() ); ?>" alt="Gift card image" title="Gift card image" style="border:none; font-size:14px; font-weight:bold; outline:none; text-decoration:none; text-transform:capitalize; vertical-align:middle; margin-right:10px; max-width:100%; height:auto; margin:0 auto; display:block; width:520px"> 
								</td>
							</tr>
							<tr>
								<td colspan="2" align="left" style="padding:12px"></td>
							</tr>
							<tr>
								<td style="text-align:left; font-weight:bold; font-size:24px; padding:12px; float:left"><?php echo esc_html( 'Yaymail' ); ?></td>
								<td valign="bottom" style="width:100px; text-align:right; font-weight:bold; font-size:24px; padding:12px">
									<?php echo wc_price( 10 ); ?>
								</td>
							</tr>
							<tr>
								<td colspan="2" style="padding:12px">
									<hr style="color:lightgrey">
								</td>
							</tr>
							<tr>
								<td colspan="2" style="text-align:left; font-weight:bold; padding:12px"><?php echo esc_html( 'message' ); ?>  </td>
							</tr>
							<tr>
								<td style="padding:12px"><br></td>
							</tr>
							<tr>
								<td style="padding:12px">
									<span style="font-weight:bold; font-size:18px; text-align:left">
										<?php _e( 'Gift card code: ', 'yith-woocommerce-gift-cards' ); ?>
									</span>
									<br><br>
									<span style="font-weight:bold; color:grey; font-size:18px; text-align:left">
										<?php echo esc_html( '1ME-328' ); ?>
									</span>
								</td>
							</tr>
							<tr>
								<td colspan="2" style="padding:12px">
									<hr style="color:lightgrey">
								</td>
							</tr>
							<tr>
								<td colspan="2" style="padding:12px; text-align:center">
									 <?php echo esc_html( $description_template_email_text ); ?>
								</td>
							</tr>
						</tbody>
					</table>

					<div style="text-align:justify; margin:3em">
						<div style="text-align:center; margin-bottom:30px">
							<a href="#" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" :style="{backgroundColor: emailContent.settingRow.titleColor}" style="color:white; font-weight:700; display:inline-block; padding:8px 15px; border-radius:5px; text-transform:uppercase; font-size:13px; text-decoration:none" data-linkindex="2">
								<?php echo esc_html( $email_button_label_get_option ); ?>
							</a>
						</div>
					</div>
				</div>
			</td>
		</tr>
	</tbody>
</table>
