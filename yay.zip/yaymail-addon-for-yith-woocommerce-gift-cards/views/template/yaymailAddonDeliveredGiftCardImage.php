<?php
/**
 * Send the gift card code email
 *
 * @author  Yithemes
 * @package yith-woocommerce-gift-cards-premium\templates\emails
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<div class="ywgc-delivered-gift-card-image-container">

	<img style="width: 100%;" class="ywgc-delivered-gift-card-image" src="<?php echo YITH_YWGC_ASSETS_IMAGES_URL . 'delivered-gift-card.png'?>" alt="">

</div>