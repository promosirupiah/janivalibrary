<?php
/**
 * Send the gift card code email
 *
 * @author  Yithemes
 * @package yith-woocommerce-gift-cards-premium\templates\emails
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<p class="center-email">
Hi, you have received this gift card from YayMail, use it on our online shop.
</p>
