<?php
/**
 * Send the gift card code email
 *
 * @author  Yithemes
 * @package yith-woocommerce-gift-cards-premium\templates\emails
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<p class="center-email">
    <?php echo apply_filters ( 'ywgc_gift_card_email_before_preview', $introductory_text, $gift_card ); ?>
</p>
