<?php
/**
 * Plugin Name: YayMail Addon for YITH WooCommerce Gift Cards
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize YITH WooCommerce Gift Cards email templates with YayMail - WooCommerce Email Customizer
 * Version: 1.5
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 7.3.0
 * Domain Path: /i18n/languages/
 */

namespace YayMailYITHGiftCards;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

/** Licensing */
add_filter( 'yaymail_available_licensing_plugins', 'YayMailYITHGiftCards\\yaymail_addon_yith_gift_cards_plugin_info' );
function yaymail_addon_yith_gift_cards_plugin_info( $plugins ) {
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$plugin_data    = get_plugin_data( __FILE__ );
	$plugin_version = $plugin_data['Version'];
	$plugin_name    = $plugin_data['Name'];
	$plugin_slug    = strtolower( str_replace( ' ', '_', $plugin_name ) );
	$plugins[]      = array(
		'name'     => $plugin_name,
		'slug'     => $plugin_slug,
		'dir_path' => plugin_dir_path( __FILE__ ),
		'basename' => plugin_basename( __FILE__ ),
		'url'      => 'https://yaycommerce.com/yaymail-addons/yaymail-premium-addon-for-yith-woocommerce-gift-cards/',
		'file'     => __FILE__,
		'version'  => $plugin_version,
		'item_id'  => '7784',
	);
	return $plugins;
}

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailYITHGiftCards\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YayMailYITHGiftCards\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailYITHGiftCards\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_dependence() {
	if ( function_exists( 'yith_ywgc_premium_init' ) ) {
		wp_enqueue_script( 'yaymail-subscription', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.2', true );
		wp_enqueue_style( 'yaymail-subscription', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.2' );
	}

}

add_action( 'yaymail_before_enqueue_dependence', 'YayMailYITHGiftCards\\yaymail_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		if ( function_exists( 'yith_ywgc_premium_init' ) ) {
			$plugins[] = array(
				'plugin_name'      => 'YITH_Gift_Cards', // --> CHANGE HERE => name of plugin (maybe name of the class)
				'addon_components' => array( 'YithDigitalGiftCards' ), // CHANGE HERE => main-name required
				'template_name'    => array( 'ywgc-email-delivered-gift-card', 'ywgc-email-send-gift-card', 'ywgc-email-notify-customer' ),
			);
		}
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailYITHGiftCards\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {
	if ( function_exists( 'yith_ywgc_premium_init' ) ) {
		if ( $key == 'ywgc-email-send-gift-card' ) {
			$getHeading       = $value->heading;
			$defaultGiftCards = templateDefault\DefaultGiftCards::getTemplates( $value->id, $getHeading );
			return $defaultGiftCards;
		}
		if ( $key == 'ywgc-email-notify-customer' ) {
			$getHeading     = $value->heading;
			$notifyCustomer = templateDefault\NotifyCustomer::getTemplates( $value->id, $getHeading );
			return $notifyCustomer;
		}
		if ( $key == 'ywgc-email-delivered-gift-card' ) {
			$getHeading        = $value->heading;
			$deliveredGiftCard = templateDefault\DeliveredGiftCard::getTemplates( $value->id, $getHeading );
			return $deliveredGiftCard;
		}
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateWooSubscription = array( 'ywgc-email-delivered-gift-card', 'ywgc-email-send-gift-card', 'ywgc-email-notify-customer' );
		if ( in_array( $arrData[2], $templateWooSubscription ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateWooSubscription = array( 'ywgc-email-delivered-gift-card', 'ywgc-email-send-gift-card', 'ywgc-email-notify-customer' );
		if ( in_array( $template, $templateWooSubscription ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		if ( function_exists( 'yith_ywgc_premium_init' ) ) {
			$components = apply_filters( 'yaymail_plugins', array() );
			$position   = '';
			foreach ( $components as $key => $component ) {
				if ( $component['plugin_name'] === 'YITH_Gift_Cards' ) {
					$position = $key;
					break;
				}
			}
			foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
				ob_start();
				do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
				$html = ob_get_contents();
				ob_end_clean();
				$addon_templates['yith_gift_cards'] = array_merge( isset( $addon_templates['yith_gift_cards'] ) ? $addon_templates['yith_gift_cards'] : array(), array( $component . 'Vue' => $html ) );
			}
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Display shortcode in core
add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YITH Gift Cards',
			'shortcode' => array(
				array( '[yaymail_addon_email_notify_customer]', 'Email Notify To Customer' ),
				array( '[yaymail_addon_gift_card_price]', 'Gift Card Price' ),
				array( '[yaymail_addon_gift_card_code]', 'Gift Card Code' ),
				array( '[yaymail_addon_sender_name]', 'Sender Name' ),
				array( '[yaymail_addon_recipient_name]', 'Recipient Name' ),
				array( '[yaymail_addon_delivered_gift_card_image]', 'Delivered Gift Card Image' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( function_exists( 'yith_ywgc_premium_init' ) ) {
			$shortcode_list[] = 'yaymail_addon_email_notify_customer';
			$shortcode_list[] = 'yaymail_addon_gift_card_price';
			$shortcode_list[] = 'yaymail_addon_gift_card_code';
			$shortcode_list[] = 'yaymail_addon_sender_name';
			$shortcode_list[] = 'yaymail_addon_recipient_name';
			$shortcode_list[] = 'yaymail_addon_delivered_gift_card_image';
		}
		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( function_exists( 'yith_ywgc_premium_init' ) ) {
			$shortcode_list['[yaymail_addon_email_notify_customer]']     = yaymailAddonEmailNotifyCustomer( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_gift_card_price]']           = yaymail_addon_gift_card_price( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_gift_card_code]']            = yaymail_addon_gift_card_code( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_sender_name]']               = yaymail_addon_sender_name( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_recipient_name]']            = yaymail_addon_recipient_name( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_delivered_gift_card_image]'] = yaymail_addon_delivered_gift_card_image( $yaymail_informations, $args );
		}
		return $shortcode_list;
	},
	10,
	3
);
function yaymail_addon_delivered_gift_card_image( $yaymail_informations, $args ) {
	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/template/yaymailAddonDeliveredGiftCardImage.php';
	$html = ob_get_contents();
	ob_end_clean();
	return $html;
}
function yaymail_addon_recipient_name( $yaymail_informations, $args ) {
	if ( isset( $args['gift_card'] ) ) {
		$object = $args['gift_card'];
		if ( $object instanceof \YWGC_Gift_Card_Premium ) {
			$recipient_name = $object->recipient_name;
		}

		return $recipient_name;
	} else {
		return 'YayMail';
	}
}

function yaymail_addon_sender_name( $yaymail_informations, $args ) {
	if ( isset( $args['gift_card'] ) ) {
		$object = $args['gift_card'];
		if ( $object instanceof \YWGC_Gift_Card_Premium ) {
			$sender_name = $object->sender_name;
		}

		return $sender_name;
	} else {
		return 'YayMail';
	}
}

function yaymail_addon_gift_card_code( $yaymail_informations, $args ) {
	if ( isset( $args['gift_card'] ) ) {
		$object = $args['gift_card'];
		if ( $object instanceof \YWGC_Gift_Card_Premium ) {
			$gift_card_code = $object->gift_card_number;
		}

		return $gift_card_code;
	} else {
		return 'YayMail';
	}
}

function yaymail_addon_gift_card_price( $yaymail_informations, $args ) {
	if ( isset( $args['gift_card'] ) ) {
		$object = $args['gift_card'];
		if ( $object instanceof \YWGC_Gift_Card_Premium ) {
			$amount          = $object->total_amount;
			$formatted_price = apply_filters( 'yith_ywgc_gift_card_template_amount', wc_price( $amount ), $object, $amount );
		}
		$context = 'email';
		return apply_filters( 'yith_wcgc_template_formatted_price', $formatted_price, $object, $context );
	} else {
		return wc_price( '100' );
	}
}

function yaymailAddonEmailNotifyCustomer( $yaymail_informations, $args ) {
	if ( isset( $args['gift_card'] ) ) {
		$gift_card         = $args['gift_card'];
		$introductory_text = isset( $args['introductory_text'] ) ? $args['introductory_text'] : '';
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymailAddonEmailNotifyCustomer.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/yaymailAddonEmailNotifyCustomer.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
add_action( 'YaymailAddonYithDigitalGiftCardsVue', 'YayMailYITHGiftCards\\yith_vendor_information_vue', 100, 5 );
function yith_vendor_information_vue( $order, $postID = '' ) {
	if ( function_exists( 'yith_ywgc_premium_init' ) ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithDigitalGiftCards.php';
		$html = ob_get_contents();
		ob_end_clean();
		if ( '' === $html ) {
			$html = '<div></div>';
		}
		echo $html;
	}
}

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonYithDigitalGiftCards', 'YayMailYITHGiftCards\\yaymail_addon_yith_vendor_information', 100, 5 );
function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( function_exists( 'yith_ywgc_premium_init' ) ) {
		if ( isset( $args['gift_card'] ) ) {
			$object            = $args['gift_card'];
			$case              = isset( $args['case'] ) ? $args['case'] : '';
			$introductory_text = isset( $args['introductory_text'] ) ? $args['introductory_text'] : '';
			if ( $object instanceof \YWGC_Gift_Card_Premium ) {

				$header_image_url = \YITH_WooCommerce_Gift_Cards_Premium::get_instance()->get_header_image( $object );

				$amount          = $object->total_amount;
				$formatted_price = apply_filters( 'yith_ywgc_gift_card_template_amount', wc_price( $amount ), $object, $amount );

				$gift_card_code = $object->gift_card_number;
				$message        = $object->message;

			}

			// Checking if the image sent is a product image, if so then we set $header_image_url with correct url
			if ( isset( $header_image_url ) ) {
				if ( strpos( $header_image_url, '-yith_wc_gift_card_premium_separator_ywgc_template_design-' ) !== false ) {
					$array_header_image_url = explode( '-yith_wc_gift_card_premium_separator_ywgc_template_design-', $header_image_url );
					$header_image_url       = $array_header_image_url['1'];
				}
			}

			$product_id = isset( $object->product_id ) ? $object->product_id : '';

			$company_logo_url         = ( 'yes' == get_option( 'ywgc_shop_logo_on_gift_card', 'no' ) ) ? get_option( 'ywgc_shop_logo_url', YITH_YWGC_ASSETS_IMAGES_URL . 'default-giftcard-main-image.png' ) : '';
			$header_image_url         = $header_image_url;
			$default_header_image_url = \YITH_WooCommerce_Gift_Cards_Premium::get_instance()->get_default_header_image();
			$formatted_price          = $formatted_price;
			$gift_card_code           = $gift_card_code;
			$message                  = $message;
			$context                  = 'email';
			$object                   = $object;
			$product_id               = $product_id;
			$case                     = $case;

			// button
			$gift_card          = $args['gift_card'];
			$apply_discount_url = '#';
			$args_gift_card     = array();
			if ( 'no' != get_option( 'ywgc_auto_discount_button_activation', 'yes' ) && ! $gift_card->product_as_present ) {
				$shop_page_url = apply_filters( 'yith_ywgc_shop_page_url', get_permalink( wc_get_page_id( 'shop' ) ) ? get_permalink( wc_get_page_id( 'shop' ) ) : site_url() );

				if ( get_option( 'ywgc_auto_discount', 'yes' ) != 'no' ) {
					$args_gift_card = array(
						YWGC_ACTION_ADD_DISCOUNT_TO_CART => $gift_card->gift_card_number,
						YWGC_ACTION_VERIFY_CODE          => YITH_YWGC()->hash_gift_card( $gift_card ),
					);
				}

				if ( get_option( 'ywgc_redirected_page', 'home_page' ) ) {
					$apply_discount_url = esc_url( add_query_arg( $args_gift_card, get_page_link( get_option( 'ywgc_redirected_page', 'home_page' ) ) ) );
				} else {
					$apply_discount_url = esc_url( add_query_arg( $args_gift_card, $shop_page_url ) );
				}
			}
			$discount_link = apply_filters( 'yith_ywgc_email_automatic_cart_discount_url', $apply_discount_url, $args_gift_card, $gift_card );
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/yaymailAddonDigitalGiftCards.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/yaymailAddonDigitalGiftCards.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		}
	}
}




