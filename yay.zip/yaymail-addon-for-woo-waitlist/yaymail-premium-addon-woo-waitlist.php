<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Waitlist
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize email templates for WooCommerce Waitlist plugin
 * Version: 1.4
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.4.1
 * Domain Path: /i18n/languages/
 */

namespace YayMailWooWaitlist;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailWooWaitlist\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

add_filter( 'plugin_row_meta', 'YayMailWooWaitlist\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailWooWaitlist\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );

function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
			$plugins[] = array(
				'plugin_name'      => 'WooCommerce_Waitlist',
				'addon_components' => array(),
				'template_name'    => array(
					'woocommerce_waitlist_joined_email',
					'woocommerce_waitlist_left_email',
					'woocommerce_waitlist_mailout',
					'woocommerce_waitlist_signup_email',
				),
			);
		}
		return $plugins;
	},
	10,
	1
);

/*
ACtion to defined shortcode

$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
			$templateWooWaitlist = array( 'woocommerce_waitlist_joined_email', 'woocommerce_waitlist_left_email', 'woocommerce_waitlist_mailout', 'woocommerce_waitlist_signup_email' );
			if ( in_array( $arrData[2], $templateWooWaitlist ) ) {
				$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			}
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
			$templateWooWaitlist = array( 'woocommerce_waitlist_joined_email', 'woocommerce_waitlist_left_email', 'woocommerce_waitlist_mailout', 'woocommerce_waitlist_signup_email' );
			if ( in_array( $template, $templateWooWaitlist ) ) {
				return true;
			}
			return $result;
		}
		return $result;
	},
	10,
	2
);

// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
			$shortcode_list[] = 'yaymail_addon_woo_waitlist_product_title';
			$shortcode_list[] = 'yaymail_addon_woo_waitlist_product_link';
			$shortcode_list[] = 'yaymail_addon_woo_waitlist_email';
			$shortcode_list[] = 'yaymail_addon_woo_waitlist_disabled';
			$shortcode_list[] = 'yaymail_addon_woo_waitlist_count_new_user';
			$shortcode_list[] = 'yaymail_addon_woo_waitlist_heading';
		}
		return $shortcode_list;
	},
	10,
	1
);

add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'WooCommerce Waitlist',
			'shortcode' => array(
				array( '[yaymail_addon_woo_waitlist_product_title]', 'Product Title' ),
				array( '[yaymail_addon_woo_waitlist_product_link]', 'Product Link' ),
				array( '[yaymail_addon_woo_waitlist_email]', 'Waitlist Email' ),
				array( '[yaymail_addon_woo_waitlist_disabled]', 'Waitlist Disabled' ),
				array( '[yaymail_addon_woo_waitlist_count_new_user]', 'Count New User' ),
				array( '[yaymail_addon_woo_waitlist_heading]', 'Waitlist Heading' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
			$shortcode_list['[yaymail_addon_woo_waitlist_product_title]']  = yaymailAddonWooWaitlistProductTitle( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_woo_waitlist_product_link]']   = yaymailAddonWooWaitlistProductLink( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_woo_waitlist_email]']          = yaymailAddonWooWaitlistEmail( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_woo_waitlist_disabled]']       = yaymailAddonWooWaitlistDisabled( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_woo_waitlist_count_new_user]'] = yaymailAddonWooWaitlistCountNewUser( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_woo_waitlist_heading]']        = yaymailAddonWooWaitlistHeading( $yaymail_informations, $args );
		}
		return $shortcode_list;
	},
	10,
	3
);
function yaymailAddonWooWaitlistProductTitle( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		if ( isset( $args ) ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooWaitlistProductTitle.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/YaymailAddonWooWaitlistProductTitle.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function yaymailAddonWooWaitlistProductLink( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		if ( isset( $args ) ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooWaitlistProductLink.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/YaymailAddonWooWaitlistProductLink.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function yaymailAddonWooWaitlistEmail( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		if ( isset( $args ) ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooWaitlistEmail.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/YaymailAddonWooWaitlistEmail.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function yaymailAddonWooWaitlistDisabled( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		if ( isset( $args ) ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooWaitlistDisabled.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/YaymailAddonWooWaitlistDisabled.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function yaymailAddonWooWaitlistCountNewUser( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		if ( isset( $args ) ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooWaitlistCountNewUser.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/YaymailAddonWooWaitlistCountNewUser.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function yaymailAddonWooWaitlistHeading( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		if ( isset( $args ) ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonWooWaitlistHeading.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/YaymailAddonWooWaitlistHeading.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailWooWaitlist\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {
	if ( class_exists( 'WooCommerce_Waitlist_Plugin' ) ) {
		$getHeading = $value->heading;
		if ( 'Pie_WCWL_Waitlist_Mailout' == $key ) {
			$defaultWaitlistMailout = templateDefault\DefaultWooWaitlistMailout::getTemplates( $value->id, $getHeading );
			return $defaultWaitlistMailout;
		} elseif ( 'Pie_WCWL_Waitlist_Joined_Email' == $key ) {
			$defaultWaitlistJoined = templateDefault\DefaultWooWaitlistJoined::getTemplates( $value->id, $getHeading );
			return $defaultWaitlistJoined;
		} elseif ( 'Pie_WCWL_Waitlist_Left_Email' == $key ) {
			$defaultWaitlistLeft = templateDefault\DefaultWooWaitlistLeft::getTemplates( $value->id, $getHeading );
			return $defaultWaitlistLeft;
		} elseif ( 'Pie_WCWL_Waitlist_Signup_Email' == $key ) {
			$defaultWaitlistAdminSignupNew = templateDefault\DefaultWooWaitlistAdminSignupNew::getTemplates( $value->id, $getHeading );
			return $defaultWaitlistAdminSignupNew;
		}
		return $array;
	}
}




