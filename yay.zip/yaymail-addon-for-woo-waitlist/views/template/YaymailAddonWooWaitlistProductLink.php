<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
?>

<?php if ( isset( $args['product_link'] ) ) : ?>
	<?php if ( 'woocommerce_waitlist_left_email' == $yaymail_informations['template'] ) : ?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_attr( $args['product_link'] ); ?>"><?php esc_html_e( 'here', 'woocommerce-waitlist' ); ?></a>
	<?php elseif ( 'woocommerce_waitlist_joined_email' == $yaymail_informations['template'] ) : ?>
		<?php
		$product_link = apply_filters(
			'wcwl_product_link_joined_email',
			add_query_arg(
				array(
					'wcwl_remove_user' => esc_attr( $args['email'] ),
					'product_id'       => absint( $args['product_id'] ),
					'key'              => $args['key'],
				),
				$args['product_link']
			)
		);
		?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_attr( $product_link ); ?>"><?php esc_html_e( 'here', 'woocommerce-waitlist' ); ?></a>
	<?php elseif ( 'woocommerce_waitlist_signup_email' == $yaymail_informations['template'] ) : ?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_attr( $args['product_link'] ); ?>"><?php esc_html_e( 'edit product screen', 'woocommerce-waitlist' ); ?></a>
	<?php else : ?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_attr( $args['product_link'] ); ?>"><?php echo esc_html( $args['product_link'] ); ?> </a>
	<?php endif; ?>
<?php else : ?>
	<?php if ( 'woocommerce_waitlist_left_email' == $yaymail_informations['template'] || 'woocommerce_waitlist_joined_email' == $yaymail_informations['template'] ) : ?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="#"><?php esc_html_e( 'here', 'woocommerce-waitlist' ); ?></a>
	<?php elseif ( 'woocommerce_waitlist_signup_email' == $yaymail_informations['template'] ) : ?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="#"><?php esc_html_e( 'edit product screen', 'woocommerce-waitlist' ); ?></a>
	<?php else : ?>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="#">	<?php echo esc_attr( get_site_url() . '/product/' ); ?> </a>
	<?php endif; ?>
<?php endif; ?>
