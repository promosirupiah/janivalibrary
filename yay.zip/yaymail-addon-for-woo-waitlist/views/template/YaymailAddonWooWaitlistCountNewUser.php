<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<?php if ( isset( $args['count'] ) ) : ?>
	<span>	<?php esc_html_e( $args['count'], 'woocommerce-waitlist' ); ?> </span>
<?php else : ?>
	<span>	<?php esc_html_e( '1', 'woocommerce-waitlist' ); ?> </span>
<?php endif; ?>
