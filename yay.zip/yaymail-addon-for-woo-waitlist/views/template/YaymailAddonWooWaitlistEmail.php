<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<?php if ( isset( $args['user_email'] ) ) : ?>
	<span>	<?php echo esc_html( $args['user_email'] ); ?> </span>
<?php else : ?>
	<span>	<?php echo esc_html( 'yaymail@example.com' ); ?> </span>
<?php endif; ?>
