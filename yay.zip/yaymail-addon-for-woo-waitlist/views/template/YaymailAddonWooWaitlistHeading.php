<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<?php if ( isset( $args['email_heading'] ) ) : ?>
	<span>	<?php esc_html_e( $args['email_heading'], 'yaymail' ); ?> </span>
<?php else : ?>
	<?php if ( 'woocommerce_waitlist_joined_email' == $yaymail_informations['template'] ) : ?>
		<span> <?php echo esc_html_e( 'You have been added to the waitlist for Product at ', 'yaymail' ) . wp_kses_post( get_option( 'blogname' ) ); ?> </span>
	<?php elseif ( 'woocommerce_waitlist_left_email' == $yaymail_informations['template'] ) : ?>
		<span>	<?php echo esc_html_e( 'You have been removed from the waitlist for Product at ', 'yaymail' ) . wp_kses_post( get_option( 'blogname' ) ); ?> </span>
	<?php elseif ( 'woocommerce_waitlist_mailout' == $yaymail_informations['template'] ) : ?>
		<span>	<?php echo esc_html_e( 'Product is now back in stock at ', 'yaymail' ) . wp_kses_post( get_option( 'blogname' ) ); ?> </span>
	<?php else : ?>
		<span>	<?php echo esc_html_e( 'Heading', 'yaymail' ); ?> </span>
	<?php endif; ?>
<?php endif; ?>
