<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<?php if ( isset( $args['product_id'] ) && isset( $args['triggered_manually'] ) && WooCommerce_Waitlist_Plugin::persistent_waitlists_are_disabled( $args['product_id'] ) && ! $args['triggered_manually'] ) : ?>
	<span>	<?php esc_html_e( 'You have been removed from the waitlist for this product', 'woocommerce-waitlist' ); ?> </span>
<?php else : ?>
	<span>	<?php esc_html_e( 'You have been removed from the waitlist for this product', 'woocommerce-waitlist' ); ?> </span>
<?php endif; ?>
