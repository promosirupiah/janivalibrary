<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<p>	<?php echo esc_html( 'additional notes' ); ?> </p>