<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
?>

<span>
	<a href="" style="color: <?php echo esc_attr( $text_link_color ); ?>">
		<?php
		// translators: 1. Wishlist name.
		echo esc_html( sprintf( __( '%s', 'yith-woocommerce-wishlist' ), 'ZXP6LRL6ANH6' ) );
		?>
	</a>
</span>