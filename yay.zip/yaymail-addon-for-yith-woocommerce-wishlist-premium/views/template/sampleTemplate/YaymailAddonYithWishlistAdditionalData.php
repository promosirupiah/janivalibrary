<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<p>	<b><?php echo esc_html( 'Lable New Field' ); ?></b>: <?php echo esc_html( 'Text' ); ?><br/> </p>
