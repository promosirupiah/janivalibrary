<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<?php if ( 'yith_wcwl_promotion_mail' === $template ) : ?>
	<table>
		<tbody>
			<tr>
				<td style="padding: 12px;">
					<div style="margin-bottom: 5px;">
						<img
							data-imagetype="External"
							src="<?php echo wp_kses_post( wc_placeholder_img_src() ); ?>"
							alt="Product image"
							height="32"
							width="32"
							style="
								border: none;
								display: inline-block;
								font-size: 14px;
								font-weight: bold;
								height: auto;
								outline: none;
								text-decoration: none;
								text-transform: capitalize;
								max-width: 100%;
								vertical-align: middle;
								margin-right: 10px;
							"
						/>
					</div>
				</td>
				<td style="padding: 12px;"><?php esc_html_e( 'YayMail Product', 'yaymail' ); ?></td>
				<td style="padding: 12px;">
					<ins>
						<span><?php echo wp_kses_post( wc_price( 50 ) ); ?></span>
					</ins>
				</td>
			</tr>
		</tbody>
	</table>
<?php else : ?>
	<table cellspacing="0" cellpadding="6" border="1" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; margin: 0 0 16px;">
		<thead>
			<tr>
				<th scope="col" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"><?php esc_html_e( 'Product', 'woocommerce' ); ?></th>
				<th scope="col" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"><?php esc_html_e( 'Price', 'woocommerce' ); ?></th>
				<th scope="col" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td style="color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
					<a href="" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color: #96588a; font-weight: normal; text-decoration: underline;" data-linkindex="2"><?php esc_html_e( 'Yaymail', 'yaymail' ); ?></a>
				</td>
				<td style="color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
					<span><?php echo wp_kses_post( wc_price( 50 ) ); ?></span>
				</td>
				<td style="color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
					<a
						href=""
						target="_blank"
						rel="noopener noreferrer"
						data-auth="NotApplicable"
						style="font-weight: normal; background-color: #ebe9eb; color: #515151; padding: 0.618em 1em; border-radius: 3px; text-decoration: none;"
						data-linkindex="3"
					>
						<?php esc_html_e( 'Add to cart', 'woocommerce' ); ?>
					</a>
				</td>
			</tr>
		</tbody>
	</table>
<?php endif; ?>
