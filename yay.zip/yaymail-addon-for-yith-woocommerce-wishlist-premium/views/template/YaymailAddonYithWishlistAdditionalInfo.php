<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php if ( ! empty( $additional_notes ) ) : ?>
	<p>
		<?php echo esc_html( $additional_notes ); ?>
	</p>

<?php endif; ?>
