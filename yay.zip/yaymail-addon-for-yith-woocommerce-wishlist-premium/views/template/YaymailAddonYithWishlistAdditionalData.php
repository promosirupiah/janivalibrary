<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php if ( ! empty( $additional_data ) ) : ?>
	<p>
		<?php foreach ( $additional_data as $key => $value ) : ?>

			<?php
			$key   = strip_tags( ucwords( str_replace( array( '_', '-' ), ' ', $key ) ) );
			$value = strip_tags( $value );
			?>

			<b><?php echo esc_html( $key ); ?></b>: <?php echo esc_html( $value ); ?><br/>

		<?php endforeach; ?>
	</p>

<?php endif; ?>

<?php do_action( 'yith_wcwl_email_after_wishlist_table', $wishlist_data ); ?>
