<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
?>

<?php if ( $wishlist_data->get_token() ) : ?>
	<span>
		<a style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_url( $wishlist_data->get_url() ); ?>">
			<?php
			// translators: 1. Wishlist name.
			echo esc_html( sprintf( apply_filters( 'yith_wcwl_ask_estimate_email_wishlist_name', __( '%s', 'yith-woocommerce-wishlist' ), $wishlist_data ), $wishlist_data->get_token() ) );
			?>
		</a>
	</span>
<?php endif; ?>
