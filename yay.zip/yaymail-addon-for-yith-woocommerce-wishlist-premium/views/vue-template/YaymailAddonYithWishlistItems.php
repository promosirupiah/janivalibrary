<?php
	$yaymail_settings   = get_option( 'yaymail_settings' );
	$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
	$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
	$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
	$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
	$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
				<div
				class="yaymail-items-order-border"
					style="min-height: 10px"
					:style="{
					color: emailContent.settingRow.textColor,
					borderColor: emailContent.settingRow.borderColor,
					}"
				>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}">
						<?php echo esc_html_e( 'Wishlist Items', 'yaymail' ); ?>
					</h2>
					<table cellspacing="0" cellpadding="6" class="yaymail_builder_table_items_content" style="border-collapse: separate;width: 100%;border-width: 1px;border-style: solid;" :style="{'border-color' : emailContent.settingRow.borderColor}" border="1" bordercolor="#eee">
						<thead>
						<tr :style="{'color' : emailContent.settingRow.textColor}">
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;<?php echo esc_attr( $borderColor ); ?>">{{emailContent.settingRow.titleProduct}}</th>
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;<?php echo esc_attr( $borderColor ); ?>">{{emailContent.settingRow.titleQuantity}}</th>
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;<?php echo esc_attr( $borderColor ); ?>">{{emailContent.settingRow.titlePrice}}</th>
						</tr>
						</thead>
                        <?php for ( $index = 0; $index < 2; $index++ ) : ?>
						<tbody>
							<tr>
								<td scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
								<?php if ( 'Bottom' == $orderImagePostions && '1' == $orderImage ) : ?>
									<a :style="{color: emailTextLinkColor}" href="#"><?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?></a>
								<?php else : ?>
									<div class="yaymail-product-image" style="margin-bottom: 5px; float: unset;">
										<img src="<?php echo esc_url( wc_placeholder_img_src( $image_size ) ); ?>" alt="Product image" height="<?php echo esc_attr( $image_height ); ?>" width="<?php echo esc_attr( $image_width ); ?>" style="vertical-align:middle;margin-right: 10px">
									</div>
									<div>
										<a :style="{color: emailTextLinkColor}" href="#"><?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?></a>
									</div>
								<?php endif; ?>
									
								</td>
								<td scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
									<?php echo esc_html( 1 ); ?>
								</td>
								<td scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
									<?php echo wc_price( 100 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</td>
							</tr>
						</tbody>
                        <?php endfor; ?>
					</table>
				</div>
			</td>
		</tr>
	</tbody>
</table>
