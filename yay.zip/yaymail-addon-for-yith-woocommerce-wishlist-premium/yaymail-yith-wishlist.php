<?php
/**
 * Plugin Name: YayMail Addon for YITH WooCommerce Wishlist Premium
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize email templates for YITH WooCommerce Wishlist Premium plugin
 * Version: 1.4
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.4.1
 * Domain Path: /i18n/languages/
 */

namespace YayMailYithWishlist;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailYithWishlist\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

add_filter( 'plugin_row_meta', 'YayMailYithWishlist\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailYithWishlist\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );

function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

function yaymail_yith_wishlist_dependence() {
	if ( function_exists( 'yith_wishlist_constructor' ) ) {
		wp_enqueue_script( 'yaymail-yith-wishlist', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.2', true );
		wp_enqueue_style( 'yaymail-yith-wishlist', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.2' );
	}
}
add_action( 'yaymail_before_enqueue_dependence', 'YayMailYithWishlist\\yaymail_yith_wishlist_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		if ( function_exists( 'yith_wishlist_constructor' ) ) {
			$plugins[] = array(
				'plugin_name'      => 'yith_wishlist_constructor',
				'addon_components' => array( 'YithWishlistItems' ), // main-name required
				'template_name'    => array( 'estimate_mail', 'yith_wcwl_back_in_stock', 'yith_wcwl_on_sale_item', 'yith_wcwl_promotion_mail' ),
			);
		}
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailYithWishlist\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {
	if ( function_exists( 'yith_wishlist_constructor' ) ) {
		$getHeading = $value->heading;
		if ( $key == 'YITH_WCWL_Estimate_Email' ) {
			$estimateMail = templateDefault\DefaultEstimateMail::getTemplates( $value->id, $getHeading );
			return $estimateMail;
		} elseif ( $key == 'YITH_WCWL_Back_In_Stock_Email'
		|| $key == 'YITH_WCWL_On_Sale_Item_Email'
		|| $key == 'YITH_WCWL_Promotion_Email' ) {
			$simpleEstimateMail = templateDefault\SimpleEstimateMail::getTemplates( $value->id, $getHeading );
			return $simpleEstimateMail;
		}
		return $array;
	}
}

/*
ACtion to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateYithWishlist = array( 'estimate_mail', 'yith_wcwl_back_in_stock', 'yith_wcwl_on_sale_item', 'yith_wcwl_promotion_mail' );
		if ( in_array( $arrData[2], $templateYithWishlist ) ) {
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateYithWishlist = array( 'estimate_mail', 'yith_wcwl_back_in_stock', 'yith_wcwl_on_sale_item', 'yith_wcwl_promotion_mail' );
		if ( in_array( $template, $templateYithWishlist ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		if ( function_exists( 'yith_wishlist_constructor' ) ) {
			$components = apply_filters( 'yaymail_plugins', array() );
			$position   = '';
			foreach ( $components as $key => $component ) {
				if ( $component['plugin_name'] === 'yith_wishlist_constructor' ) {
					$position = $key;
					break;
				}
			}
			foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
				ob_start();
				do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
				$html = ob_get_contents();
				ob_end_clean();
				$addon_templates['yith_wishlist'] = array_merge( isset( $addon_templates['yith_wishlist'] ) ? $addon_templates['yith_wishlist'] : array(), array( $component . 'Vue' => $html ) );
			}
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( function_exists( 'yith_wishlist_constructor' ) ) {
			$shortcode_list[] = 'yaymail_addon_yith_wishlist_items_title';
			$shortcode_list[] = 'yaymail_addon_yith_wishlist_additional_info';
			$shortcode_list[] = 'yaymail_addon_yith_wishlist_additional_data';
			$shortcode_list[] = 'yaymail_addon_yith_wishlist_customer_details';
			$shortcode_list[] = 'yaymail_addon_yith_wishlist_email_admin';
			$shortcode_list[] = 'yaymail_addon_yith_wishlist_email_content';
		}
		return $shortcode_list;
	},
	10,
	1
);

add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YITH Wishlist Premium',
			'shortcode' => array(
				array( '[yaymail_addon_yith_wishlist_items_title]', 'Items Title' ),
				array( '[yaymail_addon_yith_wishlist_additional_info]', 'Additional Information' ),
				array( '[yaymail_addon_yith_wishlist_additional_data]', 'Additional Data' ),
				array( '[yaymail_addon_yith_wishlist_customer_details]', 'Customer Details' ),
				array( '[yaymail_addon_yith_wishlist_email_content]', 'Email Content' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( function_exists( 'yith_wishlist_constructor' ) ) {
			$shortcode_list['[yaymail_addon_yith_wishlist_items_title]']      = YaymailAddonYithWishlistItemsTitle( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_wishlist_additional_info]']  = YaymailAddonYithWishlistAdditionalInfo( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_wishlist_additional_data]']  = YaymailAddonYithWishlistAdditionalData( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_wishlist_customer_details]'] = YaymailAddonYithWishlistCustomerDetails( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_wishlist_email_admin]']      = YaymailAddonYithWishlistEmailAdmin( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_wishlist_email_content]']    = yaymailAddonYithWishlistEmailContent( $yaymail_informations, $args );
		}
		return $shortcode_list;
	},
	10,
	3
);

function YaymailAddonYithWishlistItemsTitle( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		if ( isset( $args ) && isset( $args['wishlist_data'] ) && 'estimate_mail' === $args['email']->id ) {
			$wishlist_data = $args['wishlist_data'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistItemTitle.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/sampleTemplate/YaymailAddonYithWishlistItemsTitle.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}
function YaymailAddonYithWishlistAdditionalInfo( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		if ( isset( $args ) && isset( $args['additional_notes'] ) && 'estimate_mail' === $args['email']->id ) {
			$additional_notes = $args['additional_notes'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistAdditionalInfo.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/sampleTemplate/YaymailAddonYithWishlistAdditionalInfo.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}
function YaymailAddonYithWishlistAdditionalData( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		if ( isset( $args ) && isset( $args['additional_data'] ) && isset( $args['wishlist_data'] ) && 'estimate_mail' === $args['email']->id ) {
			$additional_data = $args['additional_data'];
			$wishlist_data   = $args['wishlist_data'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistAdditionalData.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/sampleTemplate/YaymailAddonYithWishlistAdditionalData.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function YaymailAddonYithWishlistCustomerDetails( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		if ( isset( $args ) && isset( $args['email'] ) && isset( $args['email']->reply_email ) && 'estimate_mail' === $args['email']->id ) {
			$reply_email = $args['email']->reply_email;
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistCustomerDetails.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/sampleTemplate/YaymailAddonYithWishlistCustomerDetails.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function YaymailAddonYithWishlistEmailAdmin( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		if ( isset( $args ) && isset( $args['email']->reply_email ) && 'estimate_mail' === $args['email']->id ) {
			$reply_email = $args['email']->reply_email;
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistEmailAdmin.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			$path = plugin_dir_path( __FILE__ ) . 'views/template/sampleTemplate/YaymailAddonYithWishlistEmailAdmin.php';
			include $path;
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}

function yaymailAddonYithWishlistEmailContent( $yaymail_informations, $args = array() ) {
	if ( isset( $args ) && isset( $args['email']->id ) ) {
		if ( 'yith_wcwl_back_in_stock' === $args['email']->id
			|| 'yith_wcwl_on_sale_item' === $args['email']->id
			|| 'yith_wcwl_promotion_mail' === $args['email']->id ) {
			$content = $args['email']->get_custom_content_html();
			return $content;
		}
		return '';
	} else {
		$template = $yaymail_informations['template'];
		ob_start();
		$path = plugin_dir_path( __FILE__ ) . 'views/template/sampleTemplate/YaymailAddonYithWishlistEmailContent.php';
		include $path;
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// Name of action follow : YaymailAddon + main-name + Vue
add_action( 'YaymailAddonYithWishlistItemsVue', 'YayMailYithWishlist\\yith_wishlist_items_vue', 100, 5 );
function yith_wishlist_items_vue( $order, $postID = '' ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithWishlistItems.php';
		$html = ob_get_contents();
		ob_end_clean();
		if ( '' === $html ) {
			$html = '<div></div>';
		}
		echo $html;
	}
}

// Create HTML to display when send mail
// Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonYithWishlistCustomerDetail', 'YayMailYithWishlist\\yaymail_addon_yith_wishlist_customer_detail', 100, 5 );
function yaymail_addon_yith_wishlist_customer_detail( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		
		if ( isset( $args['order'] ) ) {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistCustomerDetail.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

add_action( 'YaymailAddonYithWishlistItems', 'YayMailYithWishlist\\yaymail_addon_yith_wishlist_items', 100, 5 );
function yaymail_addon_yith_wishlist_items( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( class_exists( 'YITH_WCWL_Admin' ) ) {
		if ( isset( $args ) && isset( $args['wishlist_data'] ) ) {
			$wishlist_data = $args['wishlist_data'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithWishlistItem.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/sampleTemlplate/YaymailAddonYithWishlistItem.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		}
	}
}






