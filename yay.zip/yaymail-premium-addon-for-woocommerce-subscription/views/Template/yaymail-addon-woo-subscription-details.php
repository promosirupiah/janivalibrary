<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$text_align      = is_rtl() ? 'right' : 'left';
$text_link_color = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#7f54b3';
$borderColor     = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor       = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';

$subscript_titleSubscription   = isset( $attrs['titleSubscription'] ) ? $attrs['titleSubscription'] : 'Subscription';
$subscript_product             = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$subscript_quantity            = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Quantity';
$subscript_price               = isset( $attrs['titlePrice'] ) ? $attrs['titlePrice'] : 'Price';
$subscript_subtotal            = isset( $attrs['titleSubtotal'] ) ? $attrs['titleSubtotal'] : 'Subtotal';
$subscript_discount            = isset( $attrs['titleDiscount'] ) ? $attrs['titleDiscount'] : 'Discount';
$subscript_shipping            = isset( $attrs['titleShipping'] ) ? $attrs['titleShipping'] : 'Shipping';
$subscript_payment_method      = isset( $attrs['titlePaymentMethod'] ) ? $attrs['titlePaymentMethod'] : 'Payment Method';
$subscript_total               = isset( $attrs['titleTotal'] ) ? $attrs['titleTotal'] : 'Total';
$yaymail_settings              = get_option( 'yaymail_settings' );
$show_product_image            = isset( $yaymail_settings['product_image'] ) && 1 == $yaymail_settings['product_image'] ? true : false;
$default_args['image_size'][0] = isset( $yaymail_settings['image_width'] ) ? str_replace( 'px', '', $yaymail_settings['image_width'] ) : 32;
$default_args['image_size'][1] = isset( $yaymail_settings['image_height'] ) ? str_replace( 'px', '', $yaymail_settings['image_height'] ) : 32;

?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
			<?php
				$order_items_table_args = array(
					'show_download_links' => ( $sent_to_admin ) ? false : $subscription->is_download_permitted(),
					'show_sku'            => $sent_to_admin,
					'show_purchase_note'  => ( $sent_to_admin ) ? false : $subscription->has_status( apply_filters( 'woocommerce_order_is_paid_statuses', array( 'processing', 'completed' ) ) ),
					'show_image'          => $show_product_image,
					'image_size'          => $default_args['image_size'],
					'plain_text'          => $plain_text,
				);
				$link_element_url       = ( $sent_to_admin ) ? wcs_get_edit_post_link( wcs_get_objects_property( $subscription, 'id' ) ) : ( wcs_is_subscription( $subscription ) ? $subscription->get_view_order_url() : '' );
				?>
				<h2 class="yaymail_builder_order yaymail_subscription_table_title" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;font-size: 18px; font-weight: 700; <?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>'>
					<?php echo esc_html_e( $subscript_titleSubscription, 'woocommerce-subscriptions' ); ?>
					<a href="<?php echo esc_url( $link_element_url ); ?>" style="<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>"><?php echo esc_html( '#' . $subscription->get_id() ); ?></a>
				</h2> 
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription yaymail_new_subscription_detail_content" cellspacing="0" cellpadding="6" border="1" style="width: 100% !important;<?php echo esc_attr( $borderColor ); ?>;color: inherit;flex-direction:inherit;" width="100%">
					<thead>
						<tr style="word-break: normal;<?php echo esc_attr( $textColor ); ?>">
							<th class="td yaymail_subscription_produc_title" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php esc_html_e( $subscript_product, 'woocommerce-subscriptions' ); ?></th>
							<th class="td yaymail_subscription_quantity_title" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php echo esc_html_x( $subscript_quantity, 'table headings in notification email', 'woocommerce-subscriptions' ); ?></th>
							<th class="td yaymail_subscription_price_title" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php echo esc_html_x( $subscript_price, 'table heading', 'woocommerce-subscriptions' ); ?></th>
						</tr>
					</thead>

					<tbody>
						<?php echo wp_kses_post( WC_Subscriptions_Email::email_order_items_table( $subscription, $order_items_table_args ) ); ?>
					</tbody>
					<tfoot>
						<?php
						$order_item_totals = $subscription->get_order_item_totals();
						if ( $order_item_totals ) {
							$i = 0;
							foreach ( $order_item_totals as $key => $total ) {
								$i++;
								if ( 'cart_subtotal' == $key ) {
									$text_title = $subscript_subtotal;
								}
								if ( 'shipping' == $key ) {
									$text_title = $subscript_shipping;
								}
								if ( 'payment_method' == $key ) {
									$text_title = $subscript_payment_method;
								}
								if ( 'order_total' == $key ) {
									$text_title = $subscript_total;
								}
								?>
								<tr>
									<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>; 
																										<?php
																										if ( 1 == $i ) {
																											echo 'border-top-width: 4px;'; }
																										?>
									">
										<?php echo wp_kses_post( $text_title ); ?>
									</th>
									<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; 
																				<?php
																				if ( 1 == $i ) {
																					echo 'border-top-width: 4px;'; }
																				?>
									"> 
										<?php echo wp_kses_post( $total['value'] ); ?>
									</td>
								</tr>
								<?php
							}
						}
						if ( method_exists( $subscription, 'get_customer_note' ) && ! empty( $subscription->get_customer_note() ) ) {
							?>
							<tr>
								<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Note:', 'woocommerce-subscriptions' ); ?></th>
								<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo wp_kses_post( wptexturize( $order->get_customer_note() ) ); ?></td>
							</tr>
							<?php
						}
						?>
					</tfoot>
				</table>
			<!-- Table Subscription Cancelled -->
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
