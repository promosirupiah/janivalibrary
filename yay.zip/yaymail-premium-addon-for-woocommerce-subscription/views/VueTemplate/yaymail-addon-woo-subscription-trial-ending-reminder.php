<?php
	$sent_to_admin    = ( isset( $sent_to_admin ) ? true : false );
	$plain_text       = ( isset( $plain_text ) ? $plain_text : '' );
	$email            = ( isset( $email ) ? $email : '' );
	$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#7f54b3';
	$order_item_title = get_post_meta( $postID, '_yaymail_email_order_item_title', true );
?>

<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
		
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription yaymail_subscription_cancelled_content" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width: 100% !important;color: inherit;flex-direction:inherit;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor}">
					<thead>
						<tr style="word-break: normal;" :style="{color: emailContent.settingRow.textColor}">
							<th class="td yaymail_subscription_id_title" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleSubscription}}</th>
							<th class="td yaymail_subscription_price_title" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titlePrice}}</th>
							<th class="td yaymail_subscription_last_order_date_title" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleTrialEndDate}}</th>
						</tr>
					</thead>

					<tbody style="flex-direction:inherit;">
						<tr class="order_item" style="flex-direction:inherit;" :style="{color: emailContent.settingRow.textColor}">
							<td class="td yaymail_subscription_id_content"   style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
									<a :style="{color: emailTextLinkColor }" href="">#<?php echo esc_html( '1' ); ?></a>
							</td>
							<td class="td yaymail_subscription_price_content" style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( wc_price( 10 ) ); ?>
							</td>
							<td class="td yaymail_subscription_end_prepaid_term_content" style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( date_i18n( wc_date_format() ) ); ?>
							</td>
						</tr>
					</tbody>
				</table>
			
		</div>
	</td>
	</tr>
</tbody>
</table>

