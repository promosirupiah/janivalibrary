<?php
$text_align       = is_rtl() ? 'right' : 'left';
$sent_to_admin    = ( isset( $sent_to_admin ) ? true : false );
$plain_text       = ( isset( $plain_text ) ? $plain_text : '' );
$email            = ( isset( $email ) ? $email : '' );
$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#7f54b3';
$order_item_title = get_post_meta( $postID, '_yaymail_email_order_item_title', true );

$yaymail_settings              = get_option( 'yaymail_settings' );
$show_product_image            = isset( $yaymail_settings['product_image'] ) && 1 == $yaymail_settings['product_image'] ? true : false;
$default_args['image_size'][0] = isset( $yaymail_settings['image_width'] ) ? str_replace( 'px', '', $yaymail_settings['image_width'] ) : 32;
$default_args['image_size'][1] = isset( $yaymail_settings['image_height'] ) ? str_replace( 'px', '', $yaymail_settings['image_height'] ) : 32;
?>

<table :width="tableWidth" cellspacing="0" cellpadding="0" border="0" align="center" style="display: table;width: 100%;" :style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}" class="web-main-row" :id="'web' + emailContent.id">
	<tbody>
		<tr>
			<td :id="'web-' + emailContent.id + '-order-item'" class="web-order-item" align="left" style="font-size: 13px; line-height: 22px; word-break: break-word;" :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }">
				<div class="yaymail-items-order-border" style="min-height: 10px" :style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}">

					<?php
					$order_items_table_args = array(
						'show_download_links' => false,
						'show_sku'            => false,
						'show_purchase_note'  => false,
						'show_image'          => $show_product_image,
						'image_size'          => $default_args['image_size'],
						'plain_text'          => '',
					);
					$link_element_url       = wcs_get_edit_post_link( wcs_get_objects_property( $order, 'id' ) );

					?>
					<h2 class="yaymail_builder_order yaymail_subscription_table_title" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}">
						{{emailContent.settingRow.titleSubscription}}
						<a href="<?php echo esc_url( $link_element_url ); ?>" :style="{color: emailContent.settingRow.titleColor}"><?php echo esc_html( '#' . $subscription->get_id() ); ?></a>
					</h2>
					<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription yaymail_subscription_cancelled_content" cellspacing="0" cellpadding="6" border="1" style="width: 100% !important;color: inherit;flex-direction:inherit;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor}">
						<thead>
							<tr style="word-break: normal;" :style="{color: emailContent.settingRow.textColor}">
								<th class="td yaymail_subscription_product_title" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</th>
								<th class="td yaymail_subscription_quantity_title" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleQuantity}}</th>
								<th class="td yaymail_subscription_price_title" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titlePrice}}</th>
							</tr>
						</thead>

						<tbody>

							<?php echo wp_kses_post( WC_Subscriptions_Email::email_order_items_table( $subscription, $order_items_table_args ) ); ?>
						</tbody>
						<tfoot>
							<?php
							$order_item_totals = $subscription->get_order_item_totals();
							if ( $order_item_totals ) {
								$i = 0;
								foreach ( $order_item_totals as $key => $total ) {
									$i++;
									if ( 'cart_subtotal' == $key ) {
										$text_title = '{{emailContent.settingRow.titleSubtotal}}';
									}
									if ( 'shipping' == $key ) {
										$text_title = '{{emailContent.settingRow.titleShipping}}';
									}
									if ( 'payment_method' == $key ) {
										$text_title = '{{emailContent.settingRow.titlePaymentMethod}}';
									}
									if ( 'order_total' == $key ) {
										$text_title = '{{emailContent.settingRow.titleTotal}}';
									}
									?>
									<tr>
										<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>; 
																									<?php
																									if ( 1 == $i ) {
																										echo 'border-top-width: 4px;';
																									}
																									?>
								"><?php echo wp_kses_post( $text_title ); ?></th>
										<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; 
																			<?php
																			if ( 1 == $i ) {
																				echo 'border-top-width: 4px;';
																			}
																			?>
								"><?php echo wp_kses_post( $total['value'] ); ?></td>
									</tr>
									<?php
								}
							}
							if ( method_exists( $subscription, 'get_customer_note' ) && ! empty( $subscription->get_customer_note() ) ) {
								?>
								<tr>
									<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Note:', 'woocommerce-subscriptions' ); ?></th>
									<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo wp_kses_post( wptexturize( $order->get_customer_note() ) ); ?></td>
								</tr>
								<?php
							}
							?>
						</tfoot>
					</table>
				</div>
			</td>
		</tr>
	</tbody>
</table>
