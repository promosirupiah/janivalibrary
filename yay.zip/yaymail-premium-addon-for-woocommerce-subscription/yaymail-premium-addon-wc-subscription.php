<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Subscriptions
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize WooCommerce Subscriptions email templates with YayMail - WooCommerce Email Customizer
 * Version: 2.5.1
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 7.7.0
 * Domain Path: /i18n/languages/
 *
 * @package YayMailAddonWooSubscriptions
 */

namespace YayMailAddonWooSubscriptions;

defined( 'ABSPATH' ) || exit;


if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_NAME' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_NAME', 'WooCommerce Subscriptions' );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_LINK_URL' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_LINK_URL', 'https://yaycommerce.com/yaymail-addons/yaymail-premium-addon-for-woocommerce-subscriptions/' );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS', 'WC_Subscription' );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_VERSION' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_VERSION', '2.5.1' );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_FILE' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_URL' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_BASENAME' ) ) {
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_DATA' ) ) {
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	define( 'YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_DATA', get_plugin_data( __FILE__ ) );
}

spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/includes';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

function init() {

	Core\YayMailAddonLicense::initialize(); // Remove when up to Woocommerce

	if ( ! defined( 'YAYMAIL_THIRD_PARTY_WOO_SUBSCRIPTIONS_IS_ACTIVE' ) ) {
		$is_active = class_exists( 'WC_Subscription' );
		define( 'YAYMAIL_THIRD_PARTY_WOO_SUBSCRIPTIONS_IS_ACTIVE', $is_active );
	}

	if ( ! YAYMAIL_THIRD_PARTY_WOO_SUBSCRIPTIONS_IS_ACTIVE || ! function_exists( 'YayMail\\init' ) ) {
		Backend\Notices::initialize();
	}

	if ( YAYMAIL_THIRD_PARTY_WOO_SUBSCRIPTIONS_IS_ACTIVE && function_exists( 'YayMail\\init' ) ) {

		Backend\Enqueue::initialize();
		Backend\Actions::initialize();
		Core\YayMailAddonController::getInstance();
		Core\YayMailAddonShortCodeHandle::getInstance();
	}
}

add_action( 'plugins_loaded', 'YayMailAddonWooSubscriptions\\init' );
