<?php

namespace YayMailAddonWooSubscriptions\Core;

defined( 'ABSPATH' ) || exit;

use YayMail\Helper\Helper;

class YayMailAddonElementRender {
	protected static $instance = null;
	private $templateEmailID   = null;
	public static function getInstance( $templateEmailID ) {
		if ( null == self::$instance ) {
			self::$instance = new self();
			self::$instance->doHooks( $templateEmailID );
		}

		return self::$instance;
	}

	private function doHooks( $templateEmailID ) {
		$this->templateEmailID = $templateEmailID;
		add_filter( 'yaymail_plugins', array( $this, 'yaymail_plugins' ), 10, 1 );
		add_filter( 'yaymail_addon_templates', array( $this, 'yaymail_addon_templates' ), 100, 3 );
		$this->do_hook_vue_render();
		$this->do_hook_element_render();
	}

	// Filter to add template to Vuex
	public static function yaymail_addon_templates( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( YAYMAIL_ADDON_WOO_SUBSCRIPTIONS === $component['plugin_name'] ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates[ YAYMAIL_ADDON_WOO_SUBSCRIPTIONS ] = array_merge( isset( $addon_templates[ YAYMAIL_ADDON_WOO_SUBSCRIPTIONS ] ) ? $addon_templates[ YAYMAIL_ADDON_WOO_SUBSCRIPTIONS ] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	}

	public function yaymail_plugins( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => YAYMAIL_ADDON_WOO_SUBSCRIPTIONS, // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array(
				'WooSubscriptionInformation',
				'WooSubscriptionSuspended',
				'WooSubscriptionExpired',
				'WooSubscriptionCancelled',
				'WooSubscriptionCustomerExpiryReminder',
				'WooSubscriptionPriceUpdated',
				'WooSubscriptionTrialEndingReminder',
				'WooSubscriptionNewDetails',
				'WooSubscriptionDetails',
			), // CHANGE HERE => main-name required
			'template_name'    => $this->templateEmailID,
		);
		return $plugins;
	}

	// Create HTML with Vue syntax to display in Vue
	// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
	// CHANGE SOURCE VUE TOO
	private function do_hook_vue_render() {
		add_action( 'YaymailAddonWooSubscriptionInformationVue', array( $this, 'woo_subscription_information_vue' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionSuspendedVue', array( $this, 'woo_subscription_suspended_vue' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionExpiredVue', array( $this, 'woo_subscription_expired_vue' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionCancelledVue', array( $this, 'woo_subscription_cancelled_vue' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionCustomerExpiryReminderVue', array( $this, 'WooSubscriptionCustomerExpiryReminder' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionPriceUpdatedVue', array( $this, 'WooSubscriptionPriceUpdated' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionTrialEndingReminderVue', array( $this, 'WooSubscriptionTrialEndingReminder' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionNewDetailsVue', array( $this, 'WooSubscriptionNewDetails' ), 100, 2 );
		add_action( 'YaymailAddonWooSubscriptionDetailsVue', array( $this, 'wooSubscriptionDetails' ), 100, 2 );
	}

	// Create HTML to display when send mail
	// CHANGE HERE => Name of action follow: YaymailAddon + main-name
	private function do_hook_element_render() {
		add_action( 'YaymailAddonWooSubscriptionDetails', array( $this, 'Woo_Subscription_Details' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionNewDetails', array( $this, 'Woo_Subscription_New_Details' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionTrialEndingReminder', array( $this, 'Woo_Subscription_Trial_Ending_Reminder' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionPriceUpdated', array( $this, 'Woo_Subscription_Price_Updated' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionCustomerExpiryReminder', array( $this, 'Woo_Subscription_Customer_Expiry_Reminder' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionInformation', array( $this, 'woo_subscription_information' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionSuspended', array( $this, 'yaymail_addon_woo_subscription_suspended' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionCancelled', array( $this, 'yaymail_addon_woo_subscription_cancelled' ), 100, 5 );
		add_action( 'YaymailAddonWooSubscriptionExpired', array( $this, 'yaymail_addon_woo_subscription_expired' ), 100, 5 );
	}


	// -------------- Vue Element Render -----------//
	public function wooSubscriptionDetails( $order, $postID = '' ) {
		if ( '' === $order ) {
			ob_start();
			include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/SampleTemplate/yaymail-addon-woo-subscription-details.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			$is_parent_order = wcs_order_contains_subscription( $order, 'parent' );
			$html            = '';
			if ( $is_parent_order ) {
				$arrSubscription = wcs_get_subscriptions_for_order( $order->get_id() );
				$subscription    = reset( $arrSubscription );
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-details.php';
				$html = ob_get_contents();
				ob_end_clean();
			}
		}
		$html              = Helper::replaceCustomAllowedHTMLTags( $html );
		$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
		echo wp_kses( $html, $allowed_html_tags );

	}

	/*
	This element just for template:
	- admin new switch order ( Subscription Switched )
	- custommer completed switch order ( Subscription Switch Complete )
	*/
	public function WooSubscriptionNewDetails( $order, $postID = '' ) {
		if ( '' === $order ) {
			ob_start();
			include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/SampleTemplate/yaymail-addon-woo-subscription-new-details.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			$switched_subscriptions = wcs_get_subscriptions_for_switch_order( $order );
			$html                   = '';
			if ( $switched_subscriptions ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-new-details.php';
				$html = ob_get_contents();
				ob_end_clean();
			}
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		$html              = Helper::replaceCustomAllowedHTMLTags( $html );
		$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
		echo wp_kses( $html, $allowed_html_tags );
	}

	public function WooSubscriptionTrialEndingReminder( $order, $postID = '' ) {
		ob_start();
		include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-trial-ending-reminder.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html              = Helper::replaceCustomAllowedHTMLTags( $html );
		$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
		echo wp_kses( $html, $allowed_html_tags );
	}

	public function WooSubscriptionPriceUpdated( $order, $postID = '' ) {
		ob_start();
		include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-price-updated.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html              = Helper::replaceCustomAllowedHTMLTags( $html );
		$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
		echo wp_kses( $html, $allowed_html_tags );
	}

	public function WooSubscriptionCustomerExpiryReminder( $order, $postID = '' ) {
		ob_start();
		include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-customer-expiry-reminder.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html              = Helper::replaceCustomAllowedHTMLTags( $html );
		$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
		echo wp_kses( $html, $allowed_html_tags );
	}

	public function woo_subscription_cancelled_vue( $order, $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( '' === $order ) {
				$arrSubscription = array( false );
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-cancelled.php';
				$html = ob_get_contents();
				ob_end_clean();
			} else {
				$is_parent_order = wcs_order_contains_subscription( $order, 'parent' );
				$html            = '';
				if ( $is_parent_order ) {
					$arrSubscription = wcs_get_subscriptions_for_order( $order->get_id(), array( 'order_type' => array( 'parent', 'renewal' ) ) );
					if ( $arrSubscription ) {
						ob_start();
						include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-cancelled.php';
						$html = ob_get_contents();
						ob_end_clean();
					}
				} else {
					$arrSubscription = wcs_get_subscription( $order->get_id() );
					ob_start();
					include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-cancelled.php';
					$html = ob_get_contents();
					ob_end_clean();
				}
				if ( '' === $html ) {
					$html = '<div></div>';
				}
			}
			$html              = Helper::replaceCustomAllowedHTMLTags( $html );
			$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
			echo wp_kses( $html, $allowed_html_tags );
		}
	}

	public function woo_subscription_expired_vue( $order, $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( '' === $order ) {
				$arrSubscription = array( false );
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-expired.php';
				$html = ob_get_contents();
				ob_end_clean();
			} else {
				$is_parent_order = wcs_order_contains_subscription( $order, 'parent' );
				$html            = '';
				if ( $is_parent_order ) {
					$arrSubscription = wcs_get_subscriptions_for_order( $order->get_id(), array( 'order_type' => array( 'parent', 'renewal' ) ) );
					if ( $arrSubscription ) {
						ob_start();
						include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-expired.php';
						$html = ob_get_contents();
						ob_end_clean();
					}
				} else {
					$arrSubscription = wcs_get_subscription( $order->get_id() );
					ob_start();
					include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-expired.php';
					$html = ob_get_contents();
					ob_end_clean();
				}
				if ( '' === $html ) {
					$html = '<div></div>';
				}
			}
			$html              = Helper::replaceCustomAllowedHTMLTags( $html );
			$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
			echo wp_kses( $html, $allowed_html_tags );
		}
	}

	public function woo_subscription_suspended_vue( $order, $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( '' === $order ) {
				$arrSubscription = array( false );
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-suspended.php';
				$html = ob_get_contents();
				ob_end_clean();
			} else {
				$is_parent_order = wcs_order_contains_subscription( $order, 'parent' );
				$html            = '';
				if ( $is_parent_order ) {
					$arrSubscription = wcs_get_subscriptions_for_order( $order->get_id(), array( 'order_type' => array( 'parent', 'renewal' ) ) );
					if ( $arrSubscription ) {
						ob_start();
						include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-suspended.php';
						$html = ob_get_contents();
						ob_end_clean();
					}
				} else {
					$arrSubscription = wcs_get_subscription( $order->get_id() );
					if ( false !== $arrSubscription ) {
						ob_start();
						include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-suspended.php';
						$html = ob_get_contents();
						ob_end_clean();
					};
				}
				if ( '' === $html ) {
					$html = '<div></div>';
				}
			}
			$html              = Helper::replaceCustomAllowedHTMLTags( $html );
			$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
			echo wp_kses( $html, $allowed_html_tags );
		}
	}

	public function woo_subscription_information_vue( $order, $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( '' === $order ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-information.php';
				$html = ob_get_contents();
				ob_end_clean();
			} else {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/VueTemplate/yaymail-addon-woo-subscription-information.php';
				$html = ob_get_contents();
				ob_end_clean();
				if ( '' === $html ) {
					$html = '<div></div>';
				}
			}
			$html              = Helper::replaceCustomAllowedHTMLTags( $html );
			$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
			echo wp_kses( $html, $allowed_html_tags );
		}
	}


	// -------------- Element Render -----------//
	public function yaymail_addon_woo_subscription_expired( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			$subscription = $args['subscription'];
			if ( isset( $subscription ) ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-subscription-expired.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} elseif ( isset( $args['order'] ) && 'SampleOrder' === $args['order'] ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-subscription-expired-default.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				echo wp_kses_post( '' );
			}
		}
	}

	public function yaymail_addon_woo_subscription_cancelled( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			$subscription = $args['subscription'];
			if ( isset( $subscription ) ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-subscription-cancelled.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} elseif ( isset( $args['order'] ) && 'SampleOrder' === $args['order'] ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-subscription-cancelled-default.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				echo wp_kses_post( '' );
			}
		}
	}

	public function yaymail_addon_woo_subscription_suspended( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			$subscription = $args['subscription'];
			if ( isset( $subscription ) ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-subscription-suspended.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} elseif ( isset( $args['order'] ) && 'SampleOrder' === $args['order'] ) {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-subscription-suspended-default.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				echo wp_kses_post( '' );
			}
		}
	}

	public function woo_subscription_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['order'] ) ) {
				ob_start();
				$order = $args['order'];
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-order-subscription.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				echo wp_kses_post( '' );
			}
		}
	}

	public function Woo_Subscription_Customer_Expiry_Reminder( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) ) {
				ob_start();
				$subscription = $args['subscription'];
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-customer-expiry-reminder.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/SampleTemplate/yaymail-addon-woo-subscription-customer-expiry-reminder.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			}
		}
	}

	public function Woo_Subscription_Price_Updated( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) && isset( $args['price_changed_items'] ) ) {
				ob_start();
				$subscription        = $args['subscription'];
				$price_changed_items = $args['price_changed_items'];
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-price-updated.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/SampleTemplate/yaymail-addon-woo-subscription-price-updated.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			}
		}
	}

	public function Woo_Subscription_Trial_Ending_Reminder( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) ) {
				ob_start();
				$subscription = $args['subscription'];
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-trial-ending-reminder.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/SampleTemplate/yaymail-addon-woo-subscription-trial-ending-reminder.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			}
		}
	}

	public function Woo_Subscription_New_Details( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscriptions'] ) && isset( $args['email'] ) ) {
				ob_start();
				$subscriptions = $args['subscriptions'];
				$email         = $args['email'];
				$sent_to_admin = $args['sent_to_admin'];
				$plain_text    = $args['plain_text'];
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-new-details.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} elseif ( isset( $args['order'] ) && 'SampleOrder' !== $args['order'] ) {
				$switched_subscriptions = wcs_get_subscriptions_for_switch_order( $args['order'] );
				if ( $switched_subscriptions ) {
					$subscriptions = $switched_subscriptions;
					ob_start();
					include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-new-details.php';
					$html = ob_get_contents();
					ob_end_clean();
					$html = do_shortcode( $html );
					echo wp_kses_post( $html );
				}
				echo wp_kses_post( '' );
			} else {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/SampleTemplate/yaymail-addon-woo-subscription-new-details.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			}
		}
	}

	public function Woo_Subscription_Details( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( ( isset( $args['subscription'] ) && isset( $args['email'] ) ) || isset( $args['order'] ) && isset( $args['email'] ) ) {
				$subscription  = isset( $args['subscription'] ) ? $args['subscription'] : $args['order'];
				$email         = $args['email'];
				$sent_to_admin = isset( $args['sent_to_admin'] ) ? $args['sent_to_admin'] : false;
				$plain_text    = isset( $args['plain_text'] ) ? $args['plain_text'] : '';
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-details.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} elseif ( isset( $args['order'] ) && 'SampleOrder' !== $args['order'] ) {
				$order           = $args['order'];
				$is_parent_order = wcs_order_contains_subscription( $order, 'parent' );
				$html            = '';
				if ( $is_parent_order ) {
					$arrSubscription = wcs_get_subscriptions_for_order( $order->get_id() );
					$subscription    = reset( $arrSubscription );
					$sent_to_admin   = false;
					$plain_text      = '';
					ob_start();
					include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/yaymail-addon-woo-subscription-details.php';
					$html = ob_get_contents();
					ob_end_clean();
					$html = do_shortcode( $html );
					echo wp_kses_post( $html );
				}
			} else {
				ob_start();
				include YAYMAIL_ADDON_WOO_SUBSCRIPTIONS_PLUGIN_PATH . 'views/Template/SampleTemplate/yaymail-addon-woo-subscription-new-details.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			}
		}
	}
}
