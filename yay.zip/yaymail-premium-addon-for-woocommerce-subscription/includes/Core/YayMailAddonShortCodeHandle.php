<?php

namespace YayMailAddonWooSubscriptions\Core;

defined( 'ABSPATH' ) || exit;

class YayMailAddonShortCodeHandle {
	protected static $instance = null;

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
			self::$instance->doHooks();
		}

		return self::$instance;
	}

	private function doHooks() {
		add_filter( 'yaymail_shortcodes', array( $this, 'yaymail_shortcodes' ), 10, 1 );
		add_filter( 'yaymail_do_shortcode', array( $this, 'yaymail_do_shortcode' ), 10, 3 );
		add_filter( 'yaymail_list_shortcodes', array( $this, 'yaymail_list_shortcodes' ), 10, 1 );
	}

	public static function yaymail_list_shortcodes( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'WooCommerce Subscription',
			'shortcode' => array(
				array( '[yaymail_addon_subscription_retry_time]', 'Retry Time' ),
				array( '[yaymail_addon_subscription_order_url]', 'Order Url' ),
				array( '[yaymail_addon_subscription_order_number]', 'Order Number' ),
				array( '[yaymail_addon_subscription_time_next_payment]', 'Time Next Payment' ),
				array( '[yaymail_addon_subscription_shipping_cycle_string]', 'Shipping Cycle' ),
			),
		);

		return $shortcode_list;
	}

	public static function yaymail_shortcodes( $shortcode_list ) {
		$shortcode_list[] = 'yaymail_addon_subscription_retry_time';
		$shortcode_list[] = 'yaymail_addon_subscription_order_url';
		$shortcode_list[] = 'yaymail_addon_subscription_order_number';
		$shortcode_list[] = 'yaymail_addon_subscription_time_next_payment';
		$shortcode_list[] = 'yaymail_addon_subscription_shipping_cycle_string';
		return $shortcode_list;
	}

	public function yaymail_do_shortcode( $shortcode_list, $yaymail_informations, $args = array() ) {
		$shortcode_list['[yaymail_addon_subscription_retry_time]']            = $this->yaymailAddonSubscriptionRetryTime( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_subscription_order_url]']             = $this->yaymail_addon_subscription_order_url( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_subscription_order_number]']          = $this->yaymail_addon_subscription_order_number( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_subscription_time_next_payment]']     = $this->yaymail_addon_subscription_time_next_payment( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_subscription_shipping_cycle_string]'] = $this->yaymail_addon_subscription_shipping_cycle_string( $yaymail_informations, $args );
		return $shortcode_list;
	}

	public function yaymail_addon_subscription_shipping_cycle_string( $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) && ! empty( $args['email'] ) && '_enr_customer_shipping_frequency_notification' === $args['email']->id ) {
				$shipping_cycle_string = _enr_get_shipping_frequency_string(
					array(
						'is_synced'      => _enr_is_shipping_frequency_synced( $args['subscription'] ),
						'interval'       => $args['subscription']->get_meta( '_enr_shipping_period_interval' ),
						'period'         => $args['subscription']->get_meta( '_enr_shipping_period' ),
						'sync_date_day'  => $args['subscription']->get_meta( '_enr_shipping_frequency_sync_date_day' ),
						'sync_date_week' => $args['subscription']->get_meta( '_enr_shipping_frequency_sync_date_week' ),
					)
				);
				return $shipping_cycle_string;
			}
			return 'shipping_cycle_string';
		}
	}

	public function yaymail_addon_subscription_time_next_payment( $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) ) {

				return esc_html( date_i18n( wc_date_format(), $args['subscription']->get_time( 'next_payment', 'site' ) ) );
			}
			return 'next_payment.';
		}
	}

	public function yaymail_addon_subscription_order_number( $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) ) {

				return wp_kses_post( $args['subscription']->get_order_number() );
			}
			return '1';
		}
	}

	public function yaymail_addon_subscription_order_url( $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['subscription'] ) ) {

				return ( $args['subscription']->get_view_order_url() );
			}
			return 'order_url';
		}
	}

	public function yaymailAddonSubscriptionRetryTime( $yaymail_informations, $args = array() ) {
		if ( class_exists( 'WC_Subscription' ) ) {
			if ( isset( $args['retry'] ) ) {
				$retry = wcs_get_human_time_diff( $args['retry']->get_time() );
				return $retry;
			}
			return 'retry_time';
		}
	}

}
