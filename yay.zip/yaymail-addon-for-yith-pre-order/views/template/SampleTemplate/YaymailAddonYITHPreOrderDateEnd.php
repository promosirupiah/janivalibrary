<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<p>
	<a href="#" style=""><?php echo esc_html__( 'Yaymail', 'yaymail' ) ?></a>
	<span style="font-weight:bold;"><?php echo (wc_format_datetime( new \WC_DateTime() )) ?></span>
</p>

<div>
	<img src="<?php echo (wc_placeholder_img_src()) ?>" width="100" height="100" >
</div>