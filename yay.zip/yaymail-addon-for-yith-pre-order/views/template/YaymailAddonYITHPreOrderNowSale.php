<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$product  = wc_get_product( $product_id );
$order    = wc_get_order( $order_id );
?>

<?php
if ( false !== $product && false !== $order && $product->is_downloadable() && $order->is_download_permitted() ) {
	foreach ( $order->get_items() as $item ) {
		$item_product_id = ! empty( $item['variation_id'] ) ? $item['variation_id'] : $item['product_id'];
		if ( $product_id == $item_product_id ) {
			if ( $order instanceof WC_Data ) {
				wc_display_item_meta( $item );
				wc_display_item_downloads( $item );
			} else {
				$order->display_item_meta( $item );
				$order->display_item_downloads( $item );
			}
		}
	}
}

