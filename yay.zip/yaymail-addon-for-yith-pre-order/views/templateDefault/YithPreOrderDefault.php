<?php

namespace YayMailYITHPreOrder\templateDefault;

defined( 'ABSPATH' ) || exit;

class YithPreOrderDefault {

	protected static $instance = null;

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function getTemplates( $customOrder, $emailHeading ) {
		/*
		@@@ Html default send email.
		@@@ Note: Add characters '\' before special characters in a string.
		@@@ Example: font-family: \'Helvetica Neue\'...
		*/

		$emailTitle = __( $emailHeading, 'woocommerce' );
		$hiText     = '[yaymail_addon_yith_pre_order_customer_name]';
		if ( 'ywpo_confirmed_email' === $customOrder ) {
			$emailText  = esc_html__( 'Your pre-order has been received and is now being processed:', 'yith-pre-order-for-woocommerce' );
			$emailText2 = esc_html__( 'We will send you another email when the product becomes available in our shop. The expected availability/release date is [yaymail_addon_yith_pre_order_release_date]', 'yith-pre-order-for-woocommerce' );
		} elseif ( 'ywpo_new_pre_order_email' === $customOrder ) {
			$hiText     = 'admin';
			$emailText  = esc_html__( 'We would like to inform you that you received a new pre-order from customer [yaymail_addon_yith_pre_order_customer_name].', 'yith-pre-order-for-woocommerce' );
			$emailText2 = '';
		} elseif ( 'ywpo_completed_email' === $customOrder ) {
			$emailText  = esc_html__( 'The product [yaymail_addon_yith_pre_order_product_link] you pre-ordered in our shop (Pre-order [yaymail_addon_yith_pre_order_order_link]) is now available.', 'yith-pre-order-for-woocommerce' );
			$emailText2 = esc_html( '[yaymail_addon_yith_pre_order_pending_payment]' );
		} elseif ( 'ywpo_cancelled_email' === $customOrder ) {
			$emailText  = esc_html__( 'Unfortunately, the pre-order you placed for the product [yaymail_addon_yith_pre_order_product_link] has been cancelled.', 'yith-pre-order-for-woocommerce' );
			$emailText2 = '';
		} elseif ( 'ywpo_out_of_stock_email' === $customOrder ) {
			$hiText     = 'admin';
			$emailText  = esc_html__( 'We would like to inform you that a product from your shop is out of stock and is now in pre-order mode:', 'yith-pre-order-for-woocommerce' );
			$emailText2 = esc_html__( 'The pre-order mode will be automatically disabled when the product is back in stock or if you choose to manually manage the pre-order options.', 'yith-pre-order-for-woocommerce' );
		} elseif ( 'ywpo_payment_reminder_email' === $customOrder ) {
			$emailText  = esc_html__( 'Your pre-order has been completed and is now awaiting payment:', 'yith-pre-order-for-woocommerce' );
			$emailText2 = esc_html( '[yaymail_addon_yith_pre_order_pending_payment]' );
		} elseif ( 'ywpo_release_date_changed_email' === $customOrder ) {
			$emailText  = esc_html__( 'We would like to inform you that the availability date for the product you pre-ordered in our shop has changed:', 'yith-pre-order-for-woocommerce' );
			$emailText2 = esc_html__( 'We are sorry for this but, please, be patient: great things take time!', 'yith-pre-order-for-woocommerce' );
		} elseif ( 'ywpo_release_date_reminder' === $customOrder ) {
			$hiText     = 'admin';
			$emailText  = esc_html__( 'We would like to inform you this product\'s availability date is near and the pre-order mode is going to be disabled:', 'yith-pre-order-for-woocommerce' );
			$emailText2 = esc_html__( 'When the pre-order mode ends, this product will be available for sale in your shop and the customers that pre-ordered it will receive an email confirming the product is now available. Not ready for that?Don\'t worry. You can change the availability date by editing the product.', 'yith-pre-order-for-woocommerce' );
		}
		/*
		@@@ Elements default when reset template.
		@@@ Note 1: Add characters '\' before special characters in a string.
		@@@ example 1: "family": "\'Helvetica Neue\',Helvetica,Roboto,Arial,sans-serif",

		@@@ Note 2: Add characters '\' before special characters in a string.
		@@@ example 2: "<h1 style=\"font-family: \'Helvetica Neue\',...."
		*/

		// Elements
		$elements =
		'[{
			"id": "8ffa62b5-7258-42cc-ba53-7ae69638c1fe",
			"type": "Logo",
			"nameElement": "Logo",
			"settingRow": {
				"backgroundColor": "#ECECEC",
				"align": "center",
				"pathImg": "",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50",
				"width": "172",
				"url": "#"
			}
		}, {
			"id": "802bfe24-7af8-48af-ac5e-6560a81345b3",
			"type": "ElementText",
			"nameElement": "Email Heading",
			"settingRow": {
				"content": "<h1 style=\"font-size: 30px; font-weight: 300; line-height: normal; margin: 0; color: inherit;\">' . $emailTitle . '</h1>",
				"backgroundColor": "#7F54B3",
				"textColor": "#ffffff",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "36",
				"paddingRight": "48",
				"paddingBottom": "36",
				"paddingLeft": "48"
			}
		}, {
			"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "Hi ' . $hiText . ',<br/> ' . $emailText . '",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "47",
				"paddingRight": "50",
				"paddingBottom": "0",
				"paddingLeft": "50"
			}
		},';
		if ( 'ywpo_confirmed_email' === $customOrder || 'ywpo_payment_reminder_email' === $customOrder || 'ywpo_new_pre_order_email' === $customOrder ) {
			$elements .= '{
				"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f-order",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "[yaymail_addon_yith_pre_order_order_link]",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "20",
					"paddingRight": "50",
					"paddingBottom": "0",
					"paddingLeft": "50"
				}
			},';
		}
		$elements .= '{
			"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f-table",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "[yaymail_addon_yith_pre_order_product_table]",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "20",
				"paddingRight": "50",
				"paddingBottom": "30",
				"paddingLeft": "50"
			}
		},';
		if ( ! empty( $emailText2 ) ) {
			$elements .= '{
				"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8d",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "' . $emailText2 . '",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "0",
					"paddingRight": "50",
					"paddingBottom": "20",
					"paddingLeft": "50"
				}
			},';
		}
		$elements .= '{
			"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f-site-name",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "Regards,<br />[yaymail_site_name]",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "10",
				"paddingRight": "50",
				"paddingBottom": "30",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8ds",
			"type": "ElementText",
			"nameElement": "Footer",
			"settingRow": {
				"content": "<p style=\"font-size: 14px;margin: 0px 0px 16px; text-align: center;\">[yaymail_site_name]&nbsp;- Built with <a style=\"color: #7F54B3; font-weight: normal; text-decoration: underline;\" href=\"https://woocommerce.com\" target=\"_blank\" rel=\"noopener\">WooCommerce</a></p>",
				"backgroundColor": "#ececec",
				"textColor": "#8a8a8a",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50"
			}
		}]';

		// Templates Subscription
		$templates = array(
			$customOrder => array(),
		);

		$templates[ $customOrder ]['elements'] = $elements;
		return $templates;
	}

}
