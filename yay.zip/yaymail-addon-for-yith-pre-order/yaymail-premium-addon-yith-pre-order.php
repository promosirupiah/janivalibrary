<?php
/**
 * Plugin Name: YayMail Addon for YITH Pre-Order WooCommerce Premium
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize email templates for YITH Pre-Order WooCommerce Premium plugin
 * Version: 1.4
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 7.3.0
 * Domain Path: /i18n/languages/
 */

namespace YayMailYITHPreOrder;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailYITHPreOrder\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

add_filter( 'plugin_row_meta', 'YayMailYITHPreOrder\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailYITHPreOrder\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );

function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

// add_action( 'yaymail_before_enqueue_dependence', 'YayMailYITHPreOrder\\yaymail_yith_pre_order' );
// function yaymail_yith_pre_order() {
// wp_enqueue_script( 'yith-pre-order', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.9.5', true );
// wp_enqueue_style( 'yith-pre-order', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.9.5' );
// }

add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => 'YITH_Pre_Order', // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array( 'YithPreOrderDateChange', 'YithPreOrderDateEnd', 'YithPreOrderForSale', 'YithPreOrderOutOfStock' ), // CHANGE HERE => main-name required
			'template_name'    => array(
				'ywpo_cancelled_email',
				'ywpo_completed_email',
				'ywpo_confirmed_email',
				'ywpo_new_pre_order_email',
				'ywpo_out_of_stock_email',
				'ywpo_payment_reminder_email',
				'ywpo_release_date_changed_email',
				'ywpo_release_date_reminder',
			),
		);
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailYITHPreOrder\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {
	$getHeading = $value->heading;
	if ( 'YITH_Pre_Order_Cancelled_Email' === $key 
	|| 'YITH_Pre_Order_Completed_Email' === $key 
	|| 'YITH_Pre_Order_Confirmed_Email' === $key 
	|| 'YITH_Pre_Order_New_Pre_Order_Email' === $key 
	|| 'YITH_Pre_Order_Out_Of_Stock_Email' === $key 
	|| 'YITH_Pre_Order_Payment_Reminder_Email' === $key 
	|| 'YITH_Pre_Order_Release_Date_Changed_Email' === $key 
	|| 'YITH_Pre_Order_Release_Date_Reminder_Email' === $key ) {
		$yith_pre_order_default = templateDefault\YithPreOrderDefault::getTemplates( $value->id, $getHeading );
		return $yith_pre_order_default;
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateYITHPreOrder = array(
			'ywpo_cancelled_email',
			'ywpo_completed_email',
			'ywpo_confirmed_email',
			'ywpo_new_pre_order_email',
			'ywpo_out_of_stock_email',
			'ywpo_payment_reminder_email',
			'ywpo_release_date_changed_email',
			'ywpo_release_date_reminder',
		);
		if ( in_array( $arrData[2], $templateYITHPreOrder ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateYITHPreOrder = array(
			'ywpo_cancelled_email',
			'ywpo_completed_email',
			'ywpo_confirmed_email',
			'ywpo_new_pre_order_email',
			'ywpo_out_of_stock_email',
			'ywpo_payment_reminder_email',
			'ywpo_release_date_changed_email',
			'ywpo_release_date_reminder',
		);
		if ( in_array( $template, $templateYITHPreOrder ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		if ( class_exists( 'YITH_Pre_Order_Premium' ) ) {
			$components = apply_filters( 'yaymail_plugins', array() );
			$position   = '';
			foreach ( $components as $key => $component ) {
				if ( 'YITH_Pre_Order' === $component['plugin_name'] ) {
					$position = $key;
					break;
				}
			}
			foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
				ob_start();
				do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
				$html = ob_get_contents();
				ob_end_clean();
				$addon_templates['YITH_Pre_Order'] = array_merge( isset( $addon_templates['YITH_Pre_Order'] ) ? $addon_templates['YITH_Pre_Order'] : array(), array( $component . 'Vue' => $html ) );
			}
			return $addon_templates;
		}
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( class_exists( 'YITH_Pre_Order_Premium' ) ) {
			// $shortcode_list[] = 'yaymail_addon_yith_pre_order_previous_sale_date';
			// $shortcode_list[] = 'yaymail_addon_yith_pre_order_new_sale_date';
			// $shortcode_list[] = 'yaymail_addon_yith_pre_order_out_stock_images';
			// $shortcode_list[] = 'yaymail_addon_yith_pre_order_date_end';

			// for template pre order is now for sale
			// $shortcode_list[] = 'yaymail_addon_yith_pre_order_now_sale';
			// $shortcode_list[] = 'yaymail_addon_yith_pre_order_link';

			// new version
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_product_link';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_product_title';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_product_url';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_order_number';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_order_link';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_release_date';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_release_datetime';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_old_release_date';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_old_release_datetime';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_new_release_date';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_new_release_datetime';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_offset';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_customer_name';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_pending_payment';
			$shortcode_list[] = 'yaymail_addon_yith_pre_order_product_table';
		}
		return $shortcode_list;
	},
	10,
	1
);

add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YITH Pre Order',
			'shortcode' => array(
				
				// array( '[yaymail_addon_yith_pre_order_previous_sale_date]', 'Previous Sale Date' ),
				// array( '[yaymail_addon_yith_pre_order_new_sale_date]', 'New Sale Date' ),
				// array( '[yaymail_addon_yith_pre_order_out_stock_images]', 'Out Stock Images' ),
				// array( '[yaymail_addon_yith_pre_order_date_end]', 'Pre Order Date End' ),
				// array( '[yaymail_addon_yith_pre_order_now_sale]', 'Pre Order Now Sale' ),
				// array( '[yaymail_addon_yith_pre_order_link]', 'Pre Order Link' ),

				// New version
				array( '[yaymail_addon_yith_pre_order_product_link]', 'Product Link' ),
				array( '[yaymail_addon_yith_pre_order_product_title]', 'Product Title' ),
				array( '[yaymail_addon_yith_pre_order_product_url]', 'Product Url' ),
				array( '[yaymail_addon_yith_pre_order_order_number]', 'Order Number' ),
				array( '[yaymail_addon_yith_pre_order_order_link]', 'Order Link' ),
				array( '[yaymail_addon_yith_pre_order_release_date]', 'Release Date' ),
				array( '[yaymail_addon_yith_pre_order_release_datetime]', 'Release Datetime' ),
				array( '[yaymail_addon_yith_pre_order_old_release_date]', 'Old Release Date' ),
				array( '[yaymail_addon_yith_pre_order_old_release_datetime]', 'Old Release DateTime' ),
				array( '[yaymail_addon_yith_pre_order_new_release_date]', 'New Release Date' ),
				array( '[yaymail_addon_yith_pre_order_new_release_datetime]', 'New Release DateTime' ),
				array( '[yaymail_addon_yith_pre_order_offset]', 'Offset' ),
				array( '[yaymail_addon_yith_pre_order_customer_name]', 'Customer Name' ),
				array( '[yaymail_addon_yith_pre_order_pending_payment]', 'Pending Payment' ),
				array( '[yaymail_addon_yith_pre_order_product_table]', 'Product Table' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( class_exists( 'YITH_Pre_Order_Premium' ) ) {
		
			//$shortcode_list['[yaymail_addon_yith_pre_order_previous_sale_date]'] = yaymailAddonYITHPreOrderPreviousSaleDate( $yaymail_informations, $args );
			//$shortcode_list['[yaymail_addon_yith_pre_order_new_sale_date]']      = yaymailAddonYITHPreOrderNewSaleDate( $yaymail_informations, $args );
			//$shortcode_list['[yaymail_addon_yith_pre_order_out_stock_images]']   = yaymailAddonYITHPreOrderOutStockImages( $yaymail_informations, $args );
			//$shortcode_list['[yaymail_addon_yith_pre_order_date_end]']           = yaymailAddonYITHPreOrderDateEnd( $yaymail_informations, $args );
			// for template pre order is now for sale
			//$shortcode_list['[yaymail_addon_yith_pre_order_now_sale]'] = yaymailAddonYITHPreOrderNowSale( $yaymail_informations, $args );
			//$shortcode_list['[yaymail_addon_yith_pre_order_link]']     = yaymailAddonYITHPreOrderLink( $yaymail_informations, $args );

			// new ver
			$shortcode_list['[yaymail_addon_yith_pre_order_product_link]']       = yaymailAddonYITHPreOrderProductLink( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_product_title]']        = yaymail_addon_yith_pre_order_product_title( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_product_url]']          = yaymail_addon_yith_pre_order_product_url( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_order_number]']         = yaymail_addon_yith_pre_order_order_number( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_order_link]']           = yaymail_addon_yith_pre_order_order_link( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_release_date]']         = yaymail_addon_yith_pre_order_release_date( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_release_datetime]']     = yaymail_addon_yith_pre_order_release_datetime( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_old_release_date]']     = yaymail_addon_yith_pre_order_old_release_date( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_old_release_datetime]'] = yaymail_addon_yith_pre_order_old_release_datetime( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_new_release_date]']     = yaymail_addon_yith_pre_order_new_release_date( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_new_release_datetime]'] = yaymail_addon_yith_pre_order_new_release_datetime( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_offset]']               = yaymail_addon_yith_pre_order_offset( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_customer_name]']        = yaymail_addon_yith_pre_order_customer_name( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_pending_payment]']      = yaymail_addon_yith_pre_order_pending_payment( $yaymail_informations, $args );
			$shortcode_list['[yaymail_addon_yith_pre_order_product_table]']        = yaymail_addon_yith_pre_order_product_table( $yaymail_informations, $args );
		}
		return $shortcode_list;
	},
	10,
	3
);

function yaymail_addon_yith_pre_order_product_table( $yaymail_informations, $args = array() ) {
	$email                 = $args['email'] ?? null;
	$context_replace_ywpo  = str_replace( 'ywpo_', '', $yaymail_informations['template'] );
	$context_replace_email = str_replace( '_email', '', $context_replace_ywpo );
	$context               = str_replace( '_', '-', $context_replace_email );
	if ( 'cancelled' === $context || 'completed' === $context || 'confirmed' === $context ) {
		$context = 'pre-order-' . $context;
	}
	$_order   = '';
	$item_id  = '';
	$_product = '';
	if ( 'new-pre-order' === $context || 'payment-reminder' === $context || 'pre-order-cancelled' === $context || 'pre-order-completed' === $context ) {
		if ( $email && isset( $email->data ) && array_key_exists( 'product', $email->data ) && array_key_exists( 'order', $email->data ) && array_key_exists( 'item_id', $email->data ) ) {
			$_product = wc_get_product( $email->data['product'] );
			$_order   = $email->data['order'];
			$item_id  = $email->data['item_id'];
		}
	} elseif ( 'out-of-stock' === $context || 'release-date-reminder' === $context ) {
		if ( $email && isset( $email->product ) ) {
			$_product = $email->product;
		}
	} elseif ( 'pre-order-confirmed' === $context ) {
		if ( $email && isset( $email->data ) && array_key_exists( 'product', $email->data ) && array_key_exists( 'order', $email->data ) && array_key_exists( 'item_id', $email->data ) ) {
			$_product = $email->data['product'];
			$_order   = $email->data['order'];
			$item_id  = $email->data['item_id'];
		}
	} elseif ( 'release-date-changed' === $context ) {
		if ( $email && isset( $email->data ) && array_key_exists( 'product_id', $email->data ) && array_key_exists( 'old_release_date', $email->data ) && array_key_exists( 'new_release_date', $email->data ) ) {
			$_product         = ! empty( $email->data['product_id'] ) ? wc_get_product( $email->data['product_id'] ) : '';
			$old_release_date = ! empty( $email->data['old_release_date'] ) ? $email->data['old_release_date'] : '';
			$new_release_date = ! empty( $email->data['new_release_date'] ) ? $email->data['new_release_date'] : '';
		}
	}
	if ( ! empty( $_product ) ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHPreOrderProductTable.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonYITHPreOrderProductTable.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymail_addon_yith_pre_order_pending_payment( $yaymail_informations, $args = array() ) {
	$email                 = $args['email'] ?? null;
	$context_replace_ywpo  = str_replace( 'ywpo_', '', $yaymail_informations['template'] );
	$context_replace_email = str_replace( '_email', '', $context_replace_ywpo );
	$context               = str_replace( '_', '-', $context_replace_email );
	if ( 'cancelled' === $context || 'completed' === $context || 'confirmed' === $context ) {
		$context = 'pre-order-' . $context;
	}
	$_order   = '';
	$item_id  = '';
	$_product = '';
	$message  = '';
	if ( 'new-pre-order' === $context || 'payment-reminder' === $context || 'pre-order-cancelled' === $context || 'pre-order-completed' === $context ) {
		if ( $email && isset( $email->data ) && array_key_exists( 'product', $email->data ) && array_key_exists( 'order', $email->data ) && array_key_exists( 'item_id', $email->data ) ) {
			$_product = wc_get_product( $email->data['product'] );
			$_order   = $email->data['order'];
			$item_id  = $email->data['item_id'];
			if ( 'pre-order-completed' === $context && ! empty( $email->pending_payment_msg ) ) {
				$message = $email->pending_payment_msg;
			}
		}
	} elseif ( 'out-of-stock' === $context || 'release-date-reminder' === $context ) {
		if ( $email && isset( $email->product ) ) {
			$_product = $email->product;
		}
	} elseif ( 'pre-order-confirmed' === $context ) {
		if ( $email && isset( $email->data ) && array_key_exists( 'product', $email->data ) && array_key_exists( 'order', $email->data ) && array_key_exists( 'item_id', $email->data ) ) {
			$_product = $email->data['product'];
			$_order   = $email->data['order'];
			$item_id  = $email->data['item_id'];
		}
	} elseif ( 'release-date-changed' === $context ) {
		if ( $email && isset( $email->data ) && array_key_exists( 'product_id', $email->data ) && array_key_exists( 'old_release_date', $email->data ) && array_key_exists( 'new_release_date', $email->data ) ) {
			$_product         = ! empty( $email->data['product_id'] ) ? wc_get_product( $email->data['product_id'] ) : '';
			$old_release_date = ! empty( $email->data['old_release_date'] ) ? $email->data['old_release_date'] : '';
			$new_release_date = ! empty( $email->data['new_release_date'] ) ? $email->data['new_release_date'] : '';
		}
	}
	if ( ( ! empty( $_order ) && function_exists( 'wpo_order_is_paid' ) && wpo_order_is_paid( $_order ) ) || 'payment-reminder' === $context ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHPreOrderPendingPayment.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		return '';
	}
}

function yaymail_addon_yith_pre_order_customer_name( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'order', $email->data ) ) {
		$order         = $email->data['order'];
		$customer_name = $order->get_formatted_billing_full_name();
		return $customer_name;
	} elseif ( $email && isset( $email->data ) && array_key_exists( 'new_release_date', $email->data ) && array_key_exists( 'old_release_date', $email->data ) && array_key_exists( 'product_id', $email->data ) ) {
		$user             = get_user_by( 'email', $email->data['email'] );
		$product_id       = $email->data['product_id'];
		$old_release_date = $email->data['old_release_date'];
		$new_release_date = $email->data['new_release_date'];
		$username         = '';
		if ( $user ) {
			if ( get_user_meta( $user->ID, 'billing_first_name', true ) ) {
				$username = get_user_meta( $user->ID, 'billing_first_name', true );
			} elseif ( $user->first_name ) {
				$username = $user->first_name;
			} elseif ( $user->display_name ) {
				$username = $user->display_name;
			}
		}
		return apply_filters( 'ywpo_release_date_changed_username', $username, $user, $email->data['email'], $product_id, $old_release_date, $new_release_date );
	}
	return '{customer_name}';
}

function yaymail_addon_yith_pre_order_offset( $yaymail_informations, $args = array() ) {
	return ywpo_get_timezone_offset_label();
}

function yaymail_addon_yith_pre_order_new_release_datetime( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'new_release_date', $email->data ) ) {
		$new_release_date = $email->data['new_release_date'];
		return $new_release_date ? ywpo_print_datetime( $new_release_date ) : '';
	}
	return date_i18n( wc_date_format() );
}

function yaymail_addon_yith_pre_order_new_release_date( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'new_release_date', $email->data ) ) {
		$new_release_date = $email->data['new_release_date'];
		return $new_release_date ? ywpo_print_date( $new_release_date ) : '';
	}
	return date_i18n( wc_date_format() );
}

function yaymail_addon_yith_pre_order_old_release_datetime( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'old_release_date', $email->data ) ) {
		$old_release_date = $email->data['old_release_date'];
		return $old_release_date ? ywpo_print_datetime( $old_release_date ) : '';
	}
	return date_i18n( wc_date_format() );
}

function yaymail_addon_yith_pre_order_old_release_date( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'old_release_date', $email->data ) ) {
		$old_release_date = $email->data['old_release_date'];
		return $old_release_date ? ywpo_print_date( $old_release_date ) : '';
	}
	return date_i18n( wc_date_format() );
}

function yaymail_addon_yith_pre_order_release_datetime( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'order', $email->data ) && array_key_exists( 'item_id', $email->data ) ) {
		$order               = $email->data['order'];
		$item_id             = $email->data['item_id'];
		$release_date        = $order->get_item( $item_id )->get_meta( '_ywpo_item_for_sale_date' );
		$no_release_date_msg = __( 'at a future date', 'yith-pre-order-for-woocommerce' );
		return $release_date ? ywpo_print_datetime( $release_date ) : $no_release_date_msg;
	}
	return date_i18n( wc_date_format() );
}

function yaymail_addon_yith_pre_order_release_date( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'order', $email->data ) && array_key_exists( 'item_id', $email->data ) ) {
		$order               = $email->data['order'];
		$item_id             = $email->data['item_id'];
		$release_date        = $order->get_item( $item_id )->get_meta( '_ywpo_item_for_sale_date' );
		$no_release_date_msg = __( 'at a future date', 'yith-pre-order-for-woocommerce' );
		return $release_date ? ywpo_print_date( $release_date ) : $no_release_date_msg;
	}
	return date_i18n( wc_date_format() );
}

function yaymail_addon_yith_pre_order_order_link( $yaymail_informations, $args = array() ) {
	$email         = $args['email'] ?? null;
	$textLinkColor = isset( $yaymail_informations['general_settings']['textLinkColor'] ) ? 'color:' . $yaymail_informations['general_settings']['textLinkColor'] : 'color:#7F54B3';
	if ( $email && isset( $email->data ) && array_key_exists( 'order', $email->data ) ) {
		$order = $email->data['order'];
		return wp_kses_post( '<a  style="' . $textLinkColor . '" href="' . $order->get_view_order_url() . '">#' . $order->get_id() . '</a>' );
	}
	return wp_kses_post( '<a  style="' . $textLinkColor . '" href=""> Order #1 </a>' );
}

function yaymail_addon_yith_pre_order_order_number( $yaymail_informations, $args = array() ) {
	$email = $args['email'] ?? null;
	if ( $email && isset( $email->data ) && array_key_exists( 'order', $email->data ) ) {
		$order = $email->data['order'];
		return $order->get_order_number();
	}
	return wp_kses_post( '#1' );
}

function yaymail_addon_yith_pre_order_product_url( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] ) && isset( $args['email']->data ) && array_key_exists( 'product', $args['email']->data ) ) {
		$product     = $args['email']->data['product'];
		$product_url = get_admin_url( null, 'post.php?post=' . $product->get_id() . '&action=edit' );
		return $product_url;
	} else {
		return wp_kses_post( '<a href=""> YayMail </a>' );
	}
}

function yaymail_addon_yith_pre_order_product_title( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] ) && isset( $args['email']->data ) && array_key_exists( 'product', $args['email']->data ) ) {
		$product = $args['email']->data['product'];
		return $product->get_title();
	} else {
		return wp_kses_post( 'YayMail' );
	}
}

function yaymailAddonYITHPreOrderProductLink( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] ) && isset( $args['email']->data ) && array_key_exists( 'product', $args['email']->data ) ) {
		$product       = $args['email']->data['product'];
		$textLinkColor = isset( $yaymail_informations['general_settings']['textLinkColor'] ) ? 'color:' . $yaymail_informations['general_settings']['textLinkColor'] : 'color:#7F54B3';
		if ( isset( $args['sent_to_admin'] ) ) {
			$product_url  = get_admin_url( null, 'post.php?post=' . $product->get_id() . '&action=edit' );
			$product_link = '<a style="' . $textLinkColor . '" href="' . $product_url . '">' . $product->get_title() . '</a>';
			return $product_link;
		}
		$product_link = '<a style="' . $textLinkColor . '" href="' . $product->get_permalink() . '">' . $product->get_title() . '</a>';
		return $product_link;
	} else {
		return wp_kses_post( '<a href=""> YayMail </a>' );
	}

}

function yaymailAddonYITHPreOrderPreviousSaleDate( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] )
		&& ( 'yith_ywpo_date_end' == $args['email']->id
		|| 'yith_ywpo_sale_date_changed' == $args['email']->id
		|| 'yith_ywpo_is_for_sale' == $args['email']->id
		|| 'yith_ywpo_out_of_stock' == $args['email']->id ) ) {
		$email      = $args['email'];
		$gmt_offset = get_option( 'gmt_offset' );
		if ( 0 <= $gmt_offset ) {
			$offset_name = '+' . $gmt_offset;
		} else {
			$offset_name = (string) $gmt_offset;
		}

		$offset_name = str_replace( array( '.25', '.5', '.75' ), array( ':15', ':30', ':45' ), $offset_name );
		$offset_name = 'UTC' . $offset_name;

		$previous_sale_date = $email->object['previous_sale_date'];

		$date = $previous_sale_date . $offset_name;
		return $date;
	} else {
		return wc_format_datetime( new \WC_DateTime() );
	}

}

function yaymailAddonYITHPreOrderNewSaleDate( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] )
		&& ( 'yith_ywpo_date_end' == $args['email']->id
		|| 'yith_ywpo_sale_date_changed' == $args['email']->id
		|| 'yith_ywpo_is_for_sale' == $args['email']->id
		|| 'yith_ywpo_out_of_stock' == $args['email']->id ) ) {
		$email      = $args['email'];
		$gmt_offset = get_option( 'gmt_offset' );
		if ( 0 <= $gmt_offset ) {
			$offset_name = '+' . $gmt_offset;
		} else {
			$offset_name = (string) $gmt_offset;
		}

		$offset_name = str_replace( array( '.25', '.5', '.75' ), array( ':15', ':30', ':45' ), $offset_name );
		$offset_name = 'UTC' . $offset_name;

		$new_sale_date = $email->object['new_sale_date'];

		$date = $new_sale_date . $offset_name;
		return $date;
	} else {
		return wc_format_datetime( new \WC_DateTime() );
	}

}

function yaymailAddonYITHPreOrderNowSale( $yaymail_informations, $args = array() ) {
	if ( ( isset( $args['email'] ) && 'yith_ywpo_is_for_sale' === $args['email']->id ) ) {
		$order_id   = null;
		$product_id = null;
		if ( isset( $args['email'] ) ) {
			$email      = $args['email'];
			$order_id   = $email->object['customer_order_id'];
			$product_id = $email->object['product_id'];
		} else {
			foreach ( $yaymail_informations['order']->get_items() as $item_id => $item ) {
				$product_id = $item->get_product_id();
			}
			$order_id = $yaymail_informations['order']->id;
		}
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHPreOrderNowSale.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		return '';
	}
}

function yaymailAddonYITHPreOrderOutStockImages( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] ) && 'yith_ywpo_out_of_stock' === $args['email']->id ) {
		$email   = $args['email'];
		$product = wc_get_product( $email->object );
		return $product->get_image();
	} else {
		$image = '<img src="' . wc_placeholder_img_src() . '" />';
		return $image;
	}
}

function yaymailAddonYITHPreOrderDateEnd( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] ) && 'yith_ywpo_date_end' === $args['email']->id ) {
		$email = $args['email'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHPreOrderDateEnd.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/SampleTemplate/YaymailAddonYITHPreOrderDateEnd.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}

function yaymailAddonYITHPreOrderLink( $yaymail_informations, $args = array() ) {
	if ( isset( $args['email'] )
	&& ( 'yith_ywpo_date_end' == $args['email']->id
	|| 'yith_ywpo_sale_date_changed' == $args['email']->id
	|| 'yith_ywpo_is_for_sale' == $args['email']->id
	|| 'yith_ywpo_out_of_stock' == $args['email']->id ) ) {
		$email         = $args['email'];
		$order_id      = $email->object['customer_order_id'];
		$order         = wc_get_order( $order_id );
		$textLinkColor = isset( $yaymail_informations['general_settings']['textLinkColor'] ) ? 'color:' . $yaymail_informations['general_settings']['textLinkColor'] : 'color:#7F54B3';
		$order_link    = '<a style="' . $textLinkColor . '" href="' . $order->get_view_order_url() . '">' . $order_id . '</a>';
		return $order_link;
	} else {
		return wp_kses_post( '<a href=""> 1 </a>' );
	}
}

/** END SHORTCODE */






