<div class="update-message notice inline notice-warning notice-alt">
	<p>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=yaycommerce-licenses' ) ); ?>">Please activate your license for access to premium features and automatic updates</a>.
	</p>
</div>
