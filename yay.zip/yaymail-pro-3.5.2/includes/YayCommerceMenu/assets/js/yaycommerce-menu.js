jQuery(document).ready(function () {
	jQuery("#adminmenu li.toplevel_page_yaycommerce ul li > a[href='yaycommerce-help']").attr('href', 'https://yaycommerce.com/support').attr('target', '_blank')
})