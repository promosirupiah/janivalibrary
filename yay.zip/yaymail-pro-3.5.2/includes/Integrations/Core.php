<?php

namespace YayMail\Integrations;

class Core {

	public static function create() {
		require_once YAYMAIL_PLUGIN_PATH . 'includes/Integrations/Translations/Initialize.php';
	}

}
