<?php
	$show_price        = true;
	$colspan           = 1;
	$total             = 0;
	$total_tax         = 0;
	$show_total_column = ywraq_show_element_on_list( 'line_total' );
	$tax_display_list  = apply_filters( 'ywraq_tax_display_list', get_option( 'woocommerce_tax_display_cart' ) );
	$quote_number      = ! empty( $order ) ? apply_filters( 'ywraq_quote_number', $order->get_id() ) : '1';
	$in_email          = true;
	$show_image        = ( get_option( 'ywraq_show_preview' ) === 'yes' ) || in_array( 'images', get_option( 'ywraq_product_table_show' ), true );
	$show_permalinks   = apply_filters( 'ywraq_list_show_product_permalinks', true, 'email_request_quote_table' );
	$yaymail_settings  = get_option( 'yaymail_settings' );
	$image_width       = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 50;
	$image_height      = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 50;
	$image_size        = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
?>

<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
				<div
				class="yaymail-items-order-border"
					style="min-height: 10px"
					:style="{
					color: emailContent.settingRow.textColor,
					borderColor: emailContent.settingRow.borderColor,
					}"
				>
				<?php
				if ( ! empty( $order ) ) :
					if ( get_option( 'ywraq_enable_order_creation', 'yes' ) === 'yes' && ! empty( $quote_number ) ) : //phpcs:ignore ?>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}"><?php printf( '%s #%s', esc_html( __( 'Request', 'yith-woocommerce-request-a-quote' ) ), esc_html( $quote_number ) ); ?></h2>
					<?php else : ?>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}"><?php esc_html_e( 'Request a Quote', 'yith-woocommerce-request-a-quote' ); ?></h2>
					<?php endif ?>
				<?php else : ?>
					<?php if ( get_option( 'ywraq_enable_order_creation', 'yes' ) === 'yes' ) : //phpcs:ignore ?>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}"><?php printf( '%s #%s', esc_html( __( 'Request', 'yith-woocommerce-request-a-quote' ) ), esc_html( $quote_number ) ); ?></h2>
					<?php else : ?>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}"><?php esc_html_e( 'Quote request', 'yith-woocommerce-request-a-quote' ); ?></h2>
					<?php endif ?>
				<?php endif ?>
					
					<table cellspacing="0" cellpadding="6" class="yaymail_builder_table_items_content" style="border-collapse: separate;width: 100%;border-width: 1px;border-style: solid;" :style="{'border-color' : emailContent.settingRow.borderColor}" border="1" bordercolor="#eee">
						<thead>
						<tr :style="{'color' : emailContent.settingRow.textColor}">
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</th>
							<th scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleQuantity}}</th>
							<?php if ( $show_total_column ) : ?>
							<th scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleSubtotal}}</th>
							<?php endif ?>
						</tr>
						</thead>
						
						<tbody>
						<?php if ( empty( $order ) ) : ?>
							<?php for ( $index = 0; $index < 2; $index++ ) : ?>
								<tr :style="{'color' : emailContent.settingRow.textColor}">
									<td scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
									<?php
									if ( $show_image ) :
										if ( $show_permalinks ) :
											?>
												<a :style="{color: emailTextLinkColor}" href="#" style="display: table-cell;margin-right: 15px;padding-right: 15px;" class="thumb-wrapper">
												<?php else : ?>
												<div class="thumb-wrapper" style="display: table-cell;margin-right: 15px;padding-right: 15px;">
													<?php endif; ?>
													<img src="<?php echo esc_url( wc_placeholder_img_src( $image_size ) ); ?>" alt="Product image" height="<?php echo esc_attr( 60 ); ?>" width="<?php echo esc_attr( 60 ); ?>" style="vertical-align:middle;margin-right: 10px">
													<?php
													if ( $show_permalinks ) :
														?>
											</a>
											<?php else : ?> 
											</div>
											<?php endif ?>
										<?php endif; ?>
											<div class="product-name-wrapper" style="display: table-cell;vertical-align: middle;">
												<?php if ( $show_permalinks ) : ?>
													<a :style="{color: emailTextLinkColor}" href="#"><?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?></a>
												<?php else : ?>
													<?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?>
												<?php endif ?>
											</div>
									</td>
									
									<td scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php echo esc_html( 1 ); ?>
									</td>
									<?php if ( $show_total_column ) : ?>
									<td scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php echo wc_price( 100 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</td>
									<?php endif ?>
								</tr>
							<?php endfor; ?>
							<?php if ( $show_total_column ) : ?>
								<?php
								if ( 'incl' !== $tax_display_list && apply_filters( 'ywraq_show_taxes_quote_list', false ) ) :
									?>
									<tr class="taxt-total" :style="{'color' : emailContent.settingRow.textColor}">
										<td colspan="<?php echo esc_attr( $colspan ); ?>"  scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										</td>
										<th scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
										<td class="raq-totals" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
											<?php
												echo wp_kses_post( wc_price( 200 ) );
											?>
										</td>
									</tr>
								<?php endif; ?>
								<tr :style="{'color' : emailContent.settingRow.textColor}">
									<td colspan="<?php echo esc_attr( $colspan ); ?>"  scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"></td>
									<th scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
									{{emailContent.settingRow.titleTotal}}
									</th>
									<td class="raq-totals" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php
										echo wp_kses_post( wc_price( 200 ) );
										if ( 'incl' === $tax_display_list && apply_filters( 'ywraq_show_taxes_quote_list', false ) ) {
											echo '<br><small class="includes_tax">' . sprintf( '(%s %s %s)', esc_html( __( 'includes', 'yith-woocommerce-request-a-quote' ) ), wp_kses_post( wc_price( 200 ) ), wp_kses_post( WC()->countries->tax_or_vat() ) ) . '</small>';
										}
										?>

									</td>
								</tr>
							<?php endif; ?>
						<?php else : ?>
								<?php
								$items    = $order->get_items();
								$currency = $order->get_currency();
								if ( ! empty( $items ) ) :
									foreach ( $items as $key => $item ) :

										$_product_id = isset( $item['variation_id'] ) && $item['variation_id'] ? $item['variation_id'] : $item['product_id'];
										$_product    = wc_get_product( $_product_id );

										if ( ! $_product ) {
											continue;
										}

									$title = $_product->get_title(); //phpcs:ignore

										// Add SKU to the name.
										if ( '' !== $_product->get_sku() && ywraq_show_element_on_list( 'sku' ) ) {
											$sku    = apply_filters( 'ywraq_sku_label', __( ' SKU:', 'yith-woocommerce-request-a-quote' ) ) . $_product->get_sku(); //phpcs:ignore
											$title .= ' ' . apply_filters( 'ywraq_sku_label_html', $sku, $_product ); //phpcs:ignore
										}

										?>

								<tr :style="{'color' : emailContent.settingRow.textColor}">
										
									<td class="td" scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php
										if ( $show_image ) :
											$dimensions = apply_filters( 'ywraq_email_image_product_size', array( 80, 80 ), $_product );
											$src        = ( $_product->get_image_id() ) ? current(
												wp_get_attachment_image_src(
													$_product->get_image_id(),
													$dimensions
												)
											) : wc_placeholder_img_src();

											if ( $show_permalinks ) :
												?>
												<a :style="{color: emailTextLinkColor}" href="<?php echo esc_url( $_product->get_permalink() ); ?>" style="display: table-cell;margin-right: 15px;padding-right: 15px;">
													<?php else : ?>
													<div style="display: table-cell;margin-right: 15px;padding-right: 15px;">
														<?php endif; ?>
														<img
																src="<?php echo esc_url( $src ); ?>"
																height="<?php echo esc_attr( $dimensions[1] ); ?>"
																width="<?php echo esc_attr( $dimensions[0] ); ?>"/>
														<?php
														if ( $show_permalinks ) :
															?>
												</a>
													<?php else : ?> 
												</div>
											<?php endif; ?>
											<?php endif; ?>
								
										<div style="display: table-cell;vertical-align: middle;">
											<?php if ( $show_permalinks ) : ?>
												<a :style="{color: emailTextLinkColor}" href="<?php echo esc_url( $_product->get_permalink() ); ?>"><?php echo wp_kses_post( $title ); ?></a>
											<?php else : ?>
												<?php echo wp_kses_post( $title ); ?>
											<?php endif ?>
						
											<?php
											if ( $_product->get_sku() !== '' && ywraq_show_element_on_list( 'sku' ) ) {
												$sku = '<br/><small>' . apply_filters( 'ywraq_sku_label', __( ' SKU:', 'yith-woocommerce-request-a-quote' ) ) . $_product->get_sku() . '</small>';
												echo wp_kses_post(apply_filters('ywraq_sku_label_html', $sku, $_product)); //phpcs:ignore
											}
											?>
						
						
											<?php do_action( 'ywraq_request_quote_email_view_item_after_title', $item, $raq_data, $key ); ?>
											<?php if ( isset( $item['variations'] ) || ( ! is_array( $item ) && isset( $item->get_data()['variation_id'] ) && (int) $item->get_data()['variation_id'] > 0 ) || isset( $item['addons'] ) || isset( $item['yith_wapo_options'] ) ) : ?>
												<small style="line-height: 1em">
													<?php
													echo yith_ywraq_get_product_meta(
														$item,
														true,
														$show_price
													); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
													?>
												</small>
											<?php endif ?>
										</div>
									</td>

									<td class="td" scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo esc_html( $item['quantity'] ); ?></td>
										<?php if ( $show_total_column ) : ?>
											<td class="td" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
											<?php
											if ( $show_price ) {
												do_action( 'ywraq_quote_adjust_price', $item, $_product );

												if ( $item instanceof WC_Order_Item_Product ) {
													$price      = wc_price( $item->get_total() );
													$total     += floatval( $item->get_total() );
													$total_tax += floatval( $item->get_total_tax() );
												} else {
													$price = ( 'incl' === $tax_display_list ) ? wc_get_price_including_tax(
														$_product,
														array( 'qty' => $item['quantity'] )
													) : wc_get_price_excluding_tax(
														$_product,
														array( 'qty' => $item['quantity'] )
													);

													if ( $price ) {
														if ( $_product->is_type( 'yith-composite' ) && isset( $item['yith_wcp_component_data'] ) ) {
															$component_data                   = $item['yith_wcp_component_data'];
															$composite_stored_data            = $_product->getComponentsData();
															$composite_data_price             = 0;
															$composite_data_price_with_tax    = 0;
															$composite_data_price_without_tax = 0;
															foreach ( $composite_stored_data as $wcp_key => $component_item ) {
																if ( isset( $component_data['selection_data'][ $wcp_key ] ) && $component_data['selection_data'][ $wcp_key ] > 0 ) {
																	// variation selected.
																	if ( isset( $component_data['selection_variation_data'][ $wcp_key ] ) && $component_data['selection_variation_data'][ $wcp_key ] > 0 ) {
																		$child_product = wc_get_product( $component_data['selection_variation_data'][ $wcp_key ] );
																	} else {
																		$child_product = wc_get_product( $component_data['selection_data'][ $wcp_key ] );
																	}
																	if ( ! $child_product ) {
																		continue;
																	}
																	$composite_data_price             += wc_get_price_to_display(
																		$child_product,
																		array( 'qty' => $item['quantity'] )
																	);
																	$composite_data_price_with_tax    += wc_get_price_including_tax(
																		$child_product,
																		array( 'qty' => $item['quantity'] )
																	);
																	$composite_data_price_without_tax += wc_get_price_excluding_tax(
																		$child_product,
																		array( 'qty' => $item['quantity'] )
																	);
																}
															}
															$total     += floatval( $price + $composite_data_price );
															$total_tax += floatval( $composite_data_price_with_tax - $composite_data_price_without_tax );
														} else {
															$price_with_tax    = wc_get_price_including_tax(
																$_product,
																array( 'qty' => $item['quantity'] )
															);
															$price_without_tax = wc_get_price_excluding_tax(
																$_product,
																array( 'qty' => $item['quantity'] )
															);
															$total            += floatval( $price );
															$total_tax        += floatval( $price_with_tax - $price_without_tax );
														}
														$price = apply_filters(
															'yith_ywraq_product_price_html',
															WC()->cart->get_product_subtotal( $_product, $item['quantity'] ),
															$_product,
															$item
														);
													} else {
														$price = wc_price( 0 );
													}
												}

												echo wp_kses_post(
													apply_filters(
														'yith_ywraq_hide_price_template',
														$price,
														$_product->get_id(),
														$item
													)
												);
											}
											?>
										</td>
									<?php endif ?>
								</tr>
										<?php
										do_action( 'ywraq_after_request_quote_view_item_on_email', $order, $key );
									endforeach;
									?>
									<?php if ( $show_total_column ) : ?>
										<?php
										if ( $total_tax > 0 && 'incl' !== $tax_display_list && apply_filters( 'ywraq_show_taxes_quote_list', false ) ) :
											?>
											<tr class="taxt-total" :style="{'color' : emailContent.settingRow.textColor}">
												<td colspan="<?php echo esc_attr( $colspan ); ?>"  scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
												</td>
												<th scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
												<td class="raq-totals" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
													<?php
														echo wp_kses_post( wc_price( $total_tax, array( 'currency' => $currency ) ) );
													?>
												</td>
											</tr>
										<?php endif; ?>
										<tr :style="{'color' : emailContent.settingRow.textColor}">
											<td colspan="<?php echo esc_attr( $colspan ); ?>"  scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"></td>
											<th scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
											{{emailContent.settingRow.titleTotal}}
											</th>
											<td class="raq-totals" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
												<?php
												echo wp_kses_post( wc_price( $total, array( 'currency' => $currency ) ) );
												if ( $total_tax > 0 && 'incl' === $tax_display_list && apply_filters( 'ywraq_show_taxes_quote_list', false ) ) {
													echo '<br><small class="includes_tax">' . sprintf( '(%s %s %s)', esc_html( __( 'includes', 'yith-woocommerce-request-a-quote' ) ), wp_kses_post( wc_price( $total_tax, array( 'currency' => $currency ) ) ), wp_kses_post( WC()->countries->tax_or_vat() ) ) . '</small>';
												}
												?>

											</td>
										</tr>
									<?php endif; ?>
								<?php endif; ?>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
			</td>
		</tr>
	</tbody>
</table>
