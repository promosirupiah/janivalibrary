<?php
	$order_id         = ! empty( $order ) ? $order->get_id() : '';
	$yaymail_settings = get_option( 'yaymail_settings' );
	$image_width      = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
	$image_height     = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
	$image_size       = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
	$show_permalinks  = apply_filters( 'ywraq_list_show_product_permalinks', true, 'pdf_quote_table' );
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
				<div
				class="yaymail-items-order-border"
					style="min-height: 10px"
					:style="{
					color: emailContent.settingRow.textColor,
					borderColor: emailContent.settingRow.borderColor,
					}"
				>
				<?php
				add_filter( 'woocommerce_is_attribute_in_product_name', '__return_false' );
				$colspan = 2;
				if ( ( ! empty( $order ) ) ) {
					$before_list = $order->get_meta( '_ywraq_request_response_before' );
					if ( ( ! empty( $before_list ) ) ) :
						?>
							<p><?php echo esc_html( apply_filters( 'ywraq_quote_before_list', $before_list, $order_id ) ); ?></p>
						<?php
					endif;
					$currency = $order->get_currency();
				} else {
					$currency = get_woocommerce_currency();
				}
				?>
					<table cellspacing="0" cellpadding="6" class="yaymail_builder_table_items_content" style="border-collapse: separate;width: 100%;border-width: 1px;border-style: solid;" :style="{'border-color' : emailContent.settingRow.borderColor}" border="1" bordercolor="#eee">
						<thead>
						<tr :style="{'color' : emailContent.settingRow.textColor}">
							<th scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</th>
							<th scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleQuantity}}</th>
							<th scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleSubtotal}}</th>
						</tr>
						</thead>
						
						<tbody>
						<?php if ( empty( $order ) ) : ?>
							<?php for ( $index = 0; $index < 2; $index++ ) : ?>
								<tr>
									<td scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
									<?php
									if ( get_option( 'ywraq_show_preview' ) === 'yes' ) :
										if ( $show_permalinks ) :
											?>
												<a :style="{color: emailTextLinkColor}" href="#" style="display: table-cell;margin-right: 15px;padding-right: 15px;" class="thumb-wrapper">
												<?php else : ?>
												<div class="thumb-wrapper" style="display: table-cell;margin-right: 15px;padding-right: 15px;">
													<?php endif; ?>
													<img src="<?php echo esc_url( wc_placeholder_img_src( $image_size ) ); ?>" alt="Product image" height="<?php echo esc_attr( 60 ); ?>" width="<?php echo esc_attr( 60 ); ?>" style="vertical-align:middle;">
													<?php
													if ( $show_permalinks ) :
														?>
											</a>
											<?php else : ?> 
											</div>
											<?php endif; ?>
										<?php endif; ?>
											<div class="product-name-wrapper" style="display: table-cell;vertical-align: middle;">
												<?php if ( $show_permalinks ) : ?>
													<a :style="{color: emailTextLinkColor}" href="#"><?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?></a>
												<?php else : ?>
													<?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?>
												<?php endif ?>
											</div>
									</td>
									<td scope="col" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php echo esc_html( 1 ); ?>
									</td>
									<td scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php echo wc_price( 100 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</td>
								</tr>
							<?php endfor; ?>

								<tr :style="{'color' : emailContent.settingRow.textColor}">
									<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php esc_html_e( 'Subtotal:', 'yaymail' ); ?>
									</th>
									<td scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php echo wc_price( 200 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</td>
								</tr>
								<tr :style="{'color' : emailContent.settingRow.textColor}">
									<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php esc_html_e( 'Payment method:', 'yaymail' ); ?>
									</th>
									<td scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php esc_html_e( 'Direct bank transfer', 'yaymail' ); ?>
									</td>
								</tr>
								<tr :style="{'color' : emailContent.settingRow.textColor}">
									<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php esc_html_e( 'Total:', 'yaymail' ); ?>
									</th>
									<td scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
										<?php echo wc_price( 200 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</td>
								</tr>
						<?php else : ?>
								<?php
								$items = $order->get_items();
								if ( ! empty( $items ) ) :
									$bundles_items_to_hide = array(); /* for compatiblity with hide product option in YITH Bundle */
									foreach ( $items as $item ) :

										if ( isset( $item['variation_id'] ) && $item['variation_id'] ) {
											$_product = wc_get_product( $item['variation_id'] );
										} else {
											$_product = wc_get_product( $item['product_id'] );
										}

										$component = $item->get_meta( '_yith_wcp_child_component_data' );

										if ( ! $_product ) {
											continue;
										}

										/* compatiblity with hide product option in YITH Bundle starts */
										if ( 'yith_bundle' === $_product->get_type() ) {
											$bundle_meta = $_product->get_meta( '_yith_wcpb_bundle_data' );
											if ( $bundle_meta ) {
												foreach ( $bundle_meta as $bundle_info ) {
													if ( isset( $bundle_info['bp_hide_item'] ) && 'yes' === $bundle_info['bp_hide_item'] ) {
														$bundles_items_to_hide[] = $bundle_info['product_id'];
													}
												}
											}
										}

										if ( in_array( $_product->get_id(), $bundles_items_to_hide ) ) { //phpcs:ignore
											continue;
										}

										/* compatiblity with hide product option in YITH Bundle ends */

										$subtotal = wc_price( $item['line_total'], array( 'currency', $currency ) );

										if ( 'yes' === get_option( 'ywraq_show_old_price' ) ) {
											$subtotal = ( $item['line_subtotal'] !== $item['line_total'] ) ? '<small><del>' . wc_price(
												$item['line_subtotal'],
												array( 'currency', $currency )
											) . '</del></small> ' . wc_price(
												$item['line_total'],
												array( 'currency', $currency )
											) : wc_price(
												$item['line_subtotal'],
												array( 'currency', $currency )
											);
										}

										$title = $_product->get_title(); //phpcs:ignore

										// retro compatibility .
										$im = false;

										?>
									<tr :style="{'color' : emailContent.settingRow.textColor}">
										<td class="td" scope="col" style="text-align:left;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}">
											<?php
											if ( get_option( 'ywraq_show_preview' ) === 'yes' ) :
												$dimensions = apply_filters( 'ywraq_email_image_product_size', array( 80, 80 ), $_product );
												$src        = ( $_product->get_image_id() ) ? current(
													wp_get_attachment_image_src(
														$_product->get_image_id(),
														$dimensions
													)
												) : wc_placeholder_img_src();

												if ( $show_permalinks ) :
													?>
													<a :style="{color: emailTextLinkColor}" href="<?php echo esc_url( $_product->get_permalink() ); ?>" style="display: table-cell;margin-right: 15px;padding-right: 15px;">
														<?php else : ?>
														<div style="display: table-cell;margin-right: 15px;padding-right: 15px;">
															<?php endif; ?>
															<img
																	src="<?php echo esc_url( $src ); ?>"
																	height="<?php echo esc_attr( $dimensions[1] ); ?>"
																	width="<?php echo esc_attr( $dimensions[0] ); ?>"/>
															<?php
															if ( $show_permalinks ) :
																?>
													</a>
													<?php else : ?> 
												</div>
												<?php endif; ?>
												<?php endif; ?>

											<div style="display: table-cell;vertical-align: middle;">
												<?php if ( $component ) : ?>
													<?php $component_data = $component['yith_wcp_component_parent_object']->getComponentItemByKey( $component['yith_wcp_component_key'] ); ?>
													<div><strong><?php echo wp_kses_post( $component_data['name'] ); ?></strong></div>
													<div><?php echo wp_kses_post( $_product->get_title() ); ?></div>
												<?php elseif ( $show_permalinks ) : ?>
													<a :style="{color: emailTextLinkColor}" href="<?php echo esc_url( $_product->get_permalink() ); ?>"><?php echo wp_kses_post( $title ); ?></a>
												<?php else : ?>
													<?php echo wp_kses_post( $title ); ?>
												<?php endif; ?>
													<?php
													if ( $_product->get_sku() !== '' && ywraq_show_element_on_list( 'sku' ) ) {
														$sku = '<br/><small>' . apply_filters( 'ywraq_sku_label', __( ' SKU:', 'yith-woocommerce-request-a-quote' ) ) . $_product->get_sku() . '</small>';
														echo  wp_kses_post( apply_filters( 'ywraq_sku_label_html', $sku, $_product ) ); //phpcs:ignore
													}
													?>

												<small>
													<?php
													if ( $im ) {
														$im->display();
													} else {
														wc_display_item_meta( $item );
													}
													?>
												</small>
											</div>
										</td>
										
										<td scope="col" class="td" style="text-align:center;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo esc_html( $item['qty'] ); ?></td>
										<td scope="col" class="td" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo apply_filters( 'ywraq_quote_subtotal_item', wp_kses_post( ywraq_formatted_line_total( $order, $item ) ), $item['line_total'], $_product ); // phpcs:ignore
										?>
										</td>

									</tr>

										<?php
									endforeach;
									?>

									<?php
									foreach ( $order->get_order_item_totals() as $key => $total ) {
										if ( ! apply_filters( 'ywraq_hide_payment_method_pdf', false ) || 'payment_method' !== $key ) :
											?>
									<tr :style="{'color' : emailContent.settingRow.textColor}">

										<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo wp_kses_post( $total['label'] ); ?></th>
										<td scope="col" class="td" style="text-align:right;vertical-align: middle;padding: 12px;font-size: 14px;" :style="{'border-color' : emailContent.settingRow.borderColor}"><?php echo wp_kses_post( $total['value'] ); ?></td>
									</tr>
										<?php endif; ?>
										<?php
									}
									?>

								<?php endif; ?>
						<?php endif ?>
						</tbody>
					</table>
				</div>
			</td>
		</tr>
	</tbody>
</table>
