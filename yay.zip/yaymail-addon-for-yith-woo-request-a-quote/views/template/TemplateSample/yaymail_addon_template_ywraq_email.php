<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package YITH Woocommerce Request A Quote
 */

/**
 * HTML Template Email Request a Quote
 *
 * @since   1.0.0
 * @author  YITH
 *
 * @package YITH Woocommerce Request A Quote
 * @version 2.2.7
 */
$mail_options      = get_option( 'woocommerce_ywraq_email_settings' );
$customer          = 0;
$page_detail_admin = $mail_options && 'editor' === $mail_options['quote_detail_link'];

?>

<p></p>
<div class="yaymail-content-yith-request-quote yaymail-content-ywraq">
	<?php if ( ( ( get_option( 'ywraq_enable_order_creation', 'yes' ) === 'yes' ) ) || ( $page_detail_admin && get_option( 'ywraq_enable_order_creation', 'yes' ) === 'yes' ) ) : ?>
		<p><?php printf( '%s <a>%s</a>', wp_kses_post( __( 'You can see details here:', 'yith-woocommerce-request-a-quote' ) ), wp_kses_post( 'ID' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
	<?php endif ?>


	<h2 class="yaymail-yith-request-quote-title"><?php esc_html_e( 'Customer\'s message', 'yith-woocommerce-request-a-quote' ); ?></h2>
	<p>{customer_message}</p>

	<h2 class="yaymail-yith-request-quote-title"><?php esc_html_e( 'Customer\'s details', 'yith-woocommerce-request-a-quote' ); ?></h2>

	<p>
		<p><strong><?php _e( 'First Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span><?php echo 'first_name'; ?></span></p>
		<p><strong><?php _e( 'Last Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span ><?php echo 'last_name'; ?></span></p>
		<p><strong><?php _e( 'Email:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span><a href="#"><?php echo 'email'; ?></a></span></p>
	</p>
</div>
