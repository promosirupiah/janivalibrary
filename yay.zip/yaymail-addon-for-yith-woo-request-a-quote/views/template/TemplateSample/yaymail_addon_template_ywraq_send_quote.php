<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * HTML Template Email Send Quote
 *
 * @since   1.0.0
 * @author  YITH
 * @version 2.2.7
 * @package YITH Woocommerce Request A Quote
 */
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#7f54b3';
$order_date      = wc_format_datetime( new WC_DateTime() );

$acceptLink = 'Accept';
$rejectLink = 'Reject';
if ( class_exists( 'YITH_Request_Quote_Premium' ) ) {
	$acceptLink = ywraq_get_label( 'accept', true );
	$rejectLink = ywraq_get_label( 'reject', true );
}

?>
<style>
	.customer-info div {
		line-height: 2em;
	}

	h2 {
		margin-bottom: 10px;
	}

	h2.quote-title {
		margin-bottom: 25px;
	}
	.tax_label {
		display:block;
	}
	.thumb-wrapper {
		display: table-cell;
		margin-right: 15px;
		padding-right: 15px;
	}

	.product-name-wrapper {
		display: table-cell;
		vertical-align: middle;
	}

	.wc-item-meta p {
		display: inline-block;
	}

	.date-request {
		float: left;
		width: 50%;
	}

	.date-expiration {
		float: right;
		text-align: right;
		width: 50%;
	}

	.date-wrapper {
		padding: 20px 0;
		border-top: 1px solid #eee;
		margin-top: 20px;
	}

	.table-wrapper {
		margin: 30px 0;
	}
</style>
<div class="yaymail-content-yith-request-quote yaymail-content-ywraq-send-qoute">
	<p class="yaymail-text-send-quote">
		<?php if ( get_option( 'ywraq_show_accept_link' ) !== 'no' ) : ?>
			<a class="yaymail-send-quote" style="color: <?php echo esc_attr( $text_link_color ); ?>" href="#"><?php esc_html( $acceptLink ); ?></a>
			<?php
		endif;
		echo ( get_option( 'ywraq_show_accept_link' ) !== 'no' && get_option( 'ywraq_show_reject_link' ) !== 'no' ) ? ' | ' : '';
		if ( get_option( 'ywraq_show_reject_link' ) !== 'no' ) :
			?>
			<a class="yaymail-send-quote" style="color: <?php echo esc_attr( $text_link_color ); ?>" href="#"><?php esc_html( $rejectLink ); ?></a>
		<?php endif; ?>
	</p>
	<br/>
	<div class="yaymail-detail-quote">
		<h2 class="yaymail-yith-request-quote-title"><?php esc_html_e( 'Customer\'s details', 'yith-woocommerce-request-a-quote' ); ?></h2>

		<p>
			<p><strong><?php _e( 'Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span><?php echo 'customer_name'; ?></span></p>
			<p><strong><?php _e( 'Email:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span><a href="#"><?php echo 'email'; ?></a></span></p>
		</p>
	</div>
	<div class="date-wrapper">
		<div class="date-request">
			<strong><?php esc_html_e( 'Request date', 'yith-woocommerce-request-a-quote' ); ?></strong>: <?php echo esc_html( $order_date ); ?>
		</div>

		<div class="date-expiration">
			<strong><?php esc_html_e( 'Expiration date', 'yith-woocommerce-request-a-quote' ); ?></strong>: <?php echo esc_html( $order_date ); ?>
		</div>
	</div>
</div>
