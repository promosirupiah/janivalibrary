<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package YITH Woocommerce Request A Quote
 */

/**
 * HTML Template Email Request a Quote
 *
 * @package YITH Woocommerce Request A Quote
 * @since   1.1.6
 * @version 2.2.7
 * @author  YITH
 */


?>
	<p style="margin: 0 0 16px;">
	<?php
		// translators: number of quote.
		printf( esc_html__( 'The Proposal #%s has been accepted', 'yith-woocommerce-request-a-quote' ), esc_html( 'ID' ) );
	?>
		</p>

	<p><?php printf( '%1$s <a>#%2$s</a>', esc_html( __( 'You can see details here:', 'yith-woocommerce-request-a-quote' ) ), esc_html( 'ID' ) ); ?></p>

