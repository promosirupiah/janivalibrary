<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588a';
$yaymail_settings = get_option( 'yaymail_settings' );
$image_size       = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
$image_width      = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
$image_height     = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
$titlePreview     = isset( $attrs['titlePreview'] ) ? $attrs['titlePreview'] : 'Preview';
$titleProduct     = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleQuantity    = isset( $attrs['titleQuantity'] ) ? $attrs['titleQuantity'] : 'Quantity';
$titleSubtotal    = isset( $attrs['titleSubtotal'] ) ? $attrs['titleSubtotal'] : 'Subtotal';
$borderColor      = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor        = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$titleColor       = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';

$colspan         = 2;
$currency        = get_woocommerce_currency();
$show_permalinks = apply_filters( 'ywraq_list_show_product_permalinks', true, 'pdf_quote_table' );

?>

<table
width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
cellspacing="0"
cellpadding="0"
border="0"
align="center"
style="display: table; 
	<?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; 
	<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; 
"
class="web-main-row"
id="web<?php echo esc_attr( $id ); ?>"
>
	<tbody>
		<tr>
			<td
				id="web-<?php echo esc_attr( $id ); ?>-order-item"
				class="web-order-item"
				align="left"
				style='font-size: 13px; line-height: 22px; word-break: break-word;
				<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
				<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
				'
			>
			<div style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
				<table cellspacing="0" cellpadding="6" border="1" style="width:100%;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
					<thead>
						<tr style="<?php echo esc_attr( $textColor ); ?>">
							<th scope="col" style="padding:12px;text-align:left;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleProduct, 'yaymail' ); ?></th>
							<th scope="col" style="padding:12px;text-align:center;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleQuantity, 'yaymail' ); ?></th>
							<th scope="col" style="padding:12px;text-align:right;border: 1px solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html__( $titleSubtotal, 'yaymail' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						for ( $index = 0; $index < 2; $index++ ) :
							?>
							<tr>
								<td scope="col" style="padding:12px;text-align:left;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
									
							   <?php
								if ( get_option( 'ywraq_show_preview' ) === 'yes' ) :
									if ( $show_permalinks ) :
										?>
												<a style="float:left;padding-right:5px;color: <?php echo esc_attr( $text_link_color ); ?>" href="#" class="thumb-wrapper">
											   <?php else : ?>
												<div class="thumb-wrapper" style="float:left;padding-right:5px;">
													<?php endif; ?>
													<img src="<?php echo esc_url( wc_placeholder_img_src( $image_size ) ); ?>" alt="Product image" height="<?php echo esc_attr( 60 ); ?>" width="<?php echo esc_attr( 60 ); ?>" style="vertical-align:middle;">
											  <?php
												if ( $show_permalinks ) :
													?>
											</a>
											<?php else : ?> 
											</div>
											<?php endif; ?>
										<?php endif; ?>
											<div class="product-name-wrapper" style="padding: 15px 0;vertical-align: middle;">
												<?php if ( $show_permalinks ) : ?>
													<a style="color: <?php echo esc_attr( $text_link_color ); ?>"><?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?></a>
												<?php else : ?>
													<?php echo wp_kses_post( 'Sample Product ' . ( $index + 1 ) ); ?>
												<?php endif ?>
											</div>
								</td>
								<td scope="col" style="padding:12px;text-align:center;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo esc_html( 1 ); ?></td>
								<td scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>"><?php echo wc_price( 100 ); ?></td>
							</tr>
							<?php
						endfor;
						?>
						<tr>
							<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
								<?php esc_html_e( 'Subtotal:', 'yaymail' ); ?>
							</th>
							<td scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
								<?php echo wc_price( 200 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							</td>
						</tr>
						<tr>
							<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
								<?php esc_html_e( 'Payment method:', 'yaymail' ); ?>
							</th>
							<td scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
							<?php esc_html_e( 'Direct bank transfer', 'yaymail' ); ?>
							</td>
						</tr>
						<tr>
							<th colspan="<?php echo esc_attr( $colspan ); ?>" scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
								<?php esc_html_e( 'Total:', 'yaymail' ); ?>
							</th>
							<td scope="col" style="padding:12px;text-align:right;border-width: 1px;border-style: solid;<?php echo esc_attr( $borderColor ); ?>">
								<?php echo wc_price( 200 );  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</td>
	</tr>
	</tbody>
</table>

