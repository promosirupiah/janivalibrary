<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * @package YITH Woocommerce Request A Quote
 */

/**
 * HTML Template Email Request a Quote
 *
 * @since   1.0.0
 * @author  YITH
 *
 * @package YITH Woocommerce Request A Quote
 * @version 2.2.7
 */

$customer          = 0;
$page_detail_admin = false;

?>

<p></p>

<?php if ( ( ( get_option( 'ywraq_enable_order_creation', 'yes' ) === 'yes' ) ) ) : ?>
	<p>
	<?php
		$show_details = sprintf( '<a>#%s</a>', esc_html( 'ID' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo esc_html( __( 'You can see details here:', 'yith-woocommerce-request-a-quote' ) ) . ' ' . wp_kses_post( apply_filters( 'ywraq_request_quote_email_show_detail', $show_details, 'ID' ) )
	?>
	</p>
<?php endif ?>


<h2 class="yaymail-yith-request-quote-title"><?php esc_html_e( 'Your message', 'yith-woocommerce-request-a-quote' ); ?></h2>
<p>{your_message}</p>

<h2 class="yaymail-yith-request-quote-title"><?php esc_html_e( 'Your details', 'yith-woocommerce-request-a-quote' ); ?></h2>

<p>
	<p><strong><?php _e( 'First Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span><?php echo 'first_name'; ?></span></p>
	<p><strong><?php _e( 'Last Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span ><?php echo 'last_name'; ?></span></p>
	<p><strong><?php _e( 'Email:', 'yith-woocommerce-request-a-quote' ); ?></strong> <span><a href="#"><?php echo 'email'; ?></a></span></p>
</p>
