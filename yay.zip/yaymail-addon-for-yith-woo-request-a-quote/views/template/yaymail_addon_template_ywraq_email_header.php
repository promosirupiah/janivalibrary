<p>
	<?php if ( isset( $args['email_description'] ) ) {
		if ( 'ywraq_send_quote_reminder' === $yaymail_informations['template'] ) {
			if ( isset( $args['email_title'] ) ) { ?>
			<h2 style="color: #7f54b3;"><?php printf(apply_filters('wpml_translate_single_string', esc_html( $args['email_title'] ), 'admin_texts_woocommerce_ywraq_send_quote_reminder_settings', '[woocommerce_ywraq_send_quote_reminder_settings]email-title', $args['raq_data']['lang'])); // phpcs:ignore ?></h2>
			<br>
			<?php } ?>
			<p><?php echo apply_filters( 'wpml_translate_single_string', wp_kses_post( nl2br( $args['email_description'] ) ), 'admin_texts_woocommerce_ywraq_send_quote_settings', '[woocommerce_ywraq_send_quote_settings]email-description', $args['raq_data']['lang'] ); // phpcs:ignore ?></p>
			<?php if ( get_option( 'ywraq_hide_table_is_pdf_attachment' ) === 'no' ) : ?>
				<?php if ( ! empty( $args['raq_data']['admin_message'] ) ) : ?>
					<br>
					<p><?php echo wp_kses_post( $args['raq_data']['admin_message'] ); ?></p>
				<?php endif; ?>
			<?php endif; ?>
			<?php
		} elseif ( 'ywraq_send_quote' === $yaymail_informations['template'] ) {
			if ( isset( $args['email_title'] ) ) {
				?>
			<h2 style="color: #7f54b3;"><?php printf( ( '%1$s n. %2$s' ), apply_filters( 'wpml_translate_single_string', esc_html( $args['email_title'] ), 'admin_texts_woocommerce_ywraq_send_quote_settings', '[woocommerce_ywraq_send_quote_settings]email-title', $args['raq_data']['lang'] ),  esc_html( $args['raq_data']['order-number'] ) ); // phpcs:ignore ?></h2>
			<br>
			<?php } ?>
			<p><?php echo apply_filters( 'wpml_translate_single_string', wp_kses_post( nl2br( $args['email_description'] ) ), 'admin_texts_woocommerce_ywraq_send_quote_settings', '[woocommerce_ywraq_send_quote_settings]email-description', $args['raq_data']['lang'] ); // phpcs:ignore ?></p>
			<?php if ( get_option( 'ywraq_hide_table_is_pdf_attachment' ) === 'no' || get_option( 'ywraq_hide_table_is_pdf_attachment', '' ) === '' ) : ?>
				<?php if ( ! empty( $args['raq_data']['admin_message'] ) ) : ?>
					<p><?php echo wp_kses_post( $args['raq_data']['admin_message'] ); ?></p>
				<?php endif; ?>
			<?php endif; ?>
			<?php
		} else {
			echo wp_kses_post( $args['email_description'] );
		}
	} else {
		if ( 'ywraq_quote_status' === $yaymail_informations['template'] || 'ywraq_email' === $yaymail_informations['template'] ) {
			_e( 'You have received a request for a quote. The request is the following:', 'yith-woocommerce-request-a-quote' );
		}
		if ( 'ywraq_email_customer' === $yaymail_informations['template'] ) {
			_e( 'You have sent a quote request for the following products:', 'yith-woocommerce-request-a-quote' );
		}
		if ( 'ywraq_send_quote' === $yaymail_informations['template'] ) {
			?>
			<h2 style="color: #7f54b3;"><?php _e( 'Quote n. 1', 'yith-woocommerce-request-a-quote' ); ?></h2>
			<br>
			<p>
				<?php _e( 'You have received this email because you sent a quote request to our shop. The response to your request is the following:', 'yith-woocommerce-request-a-quote' ); ?>
			</p>
			<?php
		}
		if ( 'ywraq_send_quote_reminder' === $yaymail_informations['template'] ) {
			?>
			<h2 style="color: #7f54b3;"><?php _e( 'Expiring Proposal', 'yith-woocommerce-request-a-quote' ); ?></h2>
			<br>
			<p>
				<?php _e( 'You have received this email because your quote request on our store is about to expire and will be no longer available. Our best proposal is the following:', 'yith-woocommerce-request-a-quote' ); ?>
			</p>
			<?php
		}
		if ( 'ywraq_send_quote_reminder_accept' === $yaymail_informations['template'] ) {
			?>
			<p>
				<?php _e( 'We are contacting you because you have a pending quote on our shop. Don\'t forget it! Our best proposal is the following:', 'yith-woocommerce-request-a-quote' ); ?>
			</p>
			<?php
		}
	}
	?>
</p>
