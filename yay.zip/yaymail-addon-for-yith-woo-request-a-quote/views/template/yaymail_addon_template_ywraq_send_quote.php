<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * HTML Template Email Send Quote
 *
 * @since   1.0.0
 * @author  YITH
 * @version 2.2.7
 * @package YITH Woocommerce Request A Quote
 *
 * @var $order WC_Order
 * @var $raq_data array
 * @var $email_heading array
 * @var $email string
 * @var $email_description string
 * @var $email_title string
 */

$order_id        = $order->get_id();
$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#7f54b3';

$order_date = wc_format_datetime( $order->get_date_created() );
$exdata     = $order->get_meta( '_ywcm_request_expire' );
$exdata     = new WC_DateTime( $exdata, new DateTimeZone( 'UTC' ) );
$exdata     = wc_format_datetime( $exdata );

?>

<p class="yaymail-text-send-quote">
<?php if ( get_option( 'ywraq_show_accept_link' ) !== 'no' ) : ?>
	<a class="yaymail-send-quote" style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_url( ywraq_get_accepted_quote_page( $order ) ); ?>"><?php esc_html( ywraq_get_label( 'accept', true ) ); ?></a>
	<?php
endif;
echo ( get_option( 'ywraq_show_accept_link' ) !== 'no' && get_option( 'ywraq_show_reject_link' ) !== 'no' ) ? ' | ' : '';
if ( get_option( 'ywraq_show_reject_link' ) !== 'no' ) :
	?>
	<a class="yaymail-send-quote" style="color: <?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_url( ywraq_get_rejected_quote_page( $order ) ); ?>"><?php esc_html( ywraq_get_label( 'reject', true ) ); ?></a>
<?php endif; ?>
</p>

<?php
$after_list = $order->get_meta( '_ywraq_request_response_after', true );
if ( '' !== $after_list ) :
	?>
<p><?php echo wp_kses_post( apply_filters( 'ywraq_quote_after_list', nl2br( $after_list ), $order_id ) ); ?></p>
<?php endif; ?>

<?php

$user_name         = $order->get_meta( 'ywraq_customer_name', true );
$user_email        = $order->get_meta( 'ywraq_customer_email', true ); //phpcs:ignore
$formatted_address = $order->get_formatted_billing_address();
$billing_name      = $order->get_meta( '_billing_first_name', true );
$billing_surname   = $order->get_meta( '_billing_last_name', true );
$billing_phone     = $order->get_meta( 'ywraq_billing_phone', true );
$billing_phone     = empty( $billing_phone ) ? $order->get_meta( '_billing_phone', true ) : $billing_phone;
$billing_vat       = $order->get_meta( 'ywraq_billing_vat', true );
$billing_vat       = empty( $billing_vat ) ? $order->get_meta( '_billing_vat', true ) : $billing_vat;

?>

<style>
	.customer-info div {
		line-height: 2em;
	}

	h2 {
		margin-bottom: 10px;
	}

	h2.quote-title {
		margin-bottom: 25px;
	}
	.tax_label {
		display:block;
	}
	.thumb-wrapper {
		display: table-cell;
		margin-right: 15px;
		padding-right: 15px;
	}

	.product-name-wrapper {
		display: table-cell;
		vertical-align: middle;
	}

	.wc-item-meta p {
		display: inline-block;
	}

	.date-request {
		float: left;
		width: 50%;
	}

	.date-expiration {
		float: right;
		text-align: right;
		width: 50%;
	}

	.date-wrapper {
		padding: 20px 0;
		border-top: 1px solid #eee;
		margin-top: 20px;
	}

	.table-wrapper {
		margin: 30px 0;
	}
</style>
<div class="yaymail-content-yith-request-quote yaymail-content-ywraq-send-qoute">
	<div class="yaymail-detail-quote">
		<h2 style="margin-top: 40px; color:#7f54b3;"><?php esc_html_e( 'Customer\'s details', 'yith-woocommerce-request-a-quote' ); ?></h2>
		<?php if ( empty( $billing_name ) && empty( $billing_surname ) ) : ?>
			<p>
				<strong><?php esc_html_e( 'Name:', 'yith-woocommerce-request-a-quote' ); ?></strong> <?php echo esc_html( $user_name ); ?>
			</p>
		<?php endif; ?>

		<p><?php echo wp_kses_post( $formatted_address ); ?></p>

		<p><strong><?php esc_html_e( 'Email:', 'yith-woocommerce-request-a-quote' ); ?></strong>
			<a  style="color: <?php echo esc_attr( $text_link_color ); ?>" href="mailto:<?php echo esc_html( $raq_data['user_email'] ); ?>"><?php echo esc_html( $raq_data['user_email'] ); ?></a>
		</p>

		<?php if ( '' !== $billing_vat ) : ?>
			<p>
				<strong><?php esc_html_e( 'Billing VAT:', 'yith-woocommerce-request-a-quote' ); ?></strong> <?php echo esc_html( $billing_vat ); ?>
			</p>
		<?php endif; ?>

		<?php if ( '' !== $billing_phone ) : ?>
			<p>
				<strong><?php esc_html_e( 'Billing Phone:', 'yith-woocommerce-request-a-quote' ); ?></strong> <?php echo esc_html( $billing_phone ); ?>
			</p>
			<?php
		endif;


		// Retro compatibility.
		$af1 = $order->get_meta( 'ywraq_customer_additional_field', true );
		if ( ! empty( $af1 ) ) {
			printf( '<p><strong>%s</strong>: %s</p>', esc_html( get_option( 'ywraq_additional_text_field_label' ) ), esc_html( $af1 ) );
		}

		$af2 = $order->get_meta( 'ywraq_customer_additional_field_2', true );
		if ( ! empty( $af2 ) ) {
			printf( '<p><strong>%s</strong>: %s</p>', esc_html( get_option( 'ywraq_additional_text_field_label_2' ) ), esc_html( $af2 ) );
		}

		$af3 = $order->get_meta( 'ywraq_customer_additional_field_3', true );
		if ( ! empty( $af3 ) ) {
			printf( '<p><strong>%s</strong>: %s</p>', esc_html( get_option( 'ywraq_additional_text_field_label_3' ) ), esc_html( $af3 ) );
		}

		$af4 = $order->get_meta( 'ywraq_customer_other_email_content', true );

		if ( ! empty( $af4 ) ) {
			printf( '<p>%s</p>', esc_html( $af4 ) );
		}
		?>
	</div>
	<div class="date-wrapper">
		<div class="date-request">
			<strong><?php esc_html_e( 'Request date', 'yith-woocommerce-request-a-quote' ); ?></strong>: <?php echo esc_html( $order_date ); ?>
		</div>

		<?php if ( ! empty( $exdata ) ) : ?>
			<div class="date-expiration">
				<strong><?php esc_html_e( 'Expiration date', 'yith-woocommerce-request-a-quote' ); ?></strong>: <?php echo esc_html( $exdata ); ?>
			</div>
		<?php endif ?>
	</div>
</div>
