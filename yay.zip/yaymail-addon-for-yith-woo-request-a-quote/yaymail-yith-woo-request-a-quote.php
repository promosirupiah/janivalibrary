<?php
/**
 * Plugin Name: YayMail Premium Addon for YITH WooCommerce Request A Quote Premium
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize YITH WooCommerce Request A Quote Premium email templates with YayMail - WooCommerce Email Customizer
 * Version: 1.3
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.6.0
 * Domain Path: /i18n/languages/
 */

namespace YITHWooRequestAQuote;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YITHWooRequestAQuote\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YITHWooRequestAQuote\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YITHWooRequestAQuote\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
	?>
	<script>
	var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
	plugin_row_element.classList.add('update');
	</script>
	<?php
	echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>';
	}
	if ( ! class_exists( 'YITH_Request_Quote_Premium' ) ) {
		$notice_addon = '<div class="notice inline notice-warning notice-alt"><p>';
		// Translators: Placeholders are opening and closing Addon Name tags.
		$notice_addon .= sprintf( esc_html__( 'In order to customize templates of %1$s, please install %2$s first.', 'yaymail' ), '<strong>YITH WooCommerce Request A Quote Premium</strong>', '<strong>YITH WooCommerce Request A Quote Premium</strong>' );
		$notice_addon .= '</p> </div>';
		echo $notice_addon;
	}
	echo '</td></tr>';

}

function yaymail_dependence() {
	wp_enqueue_script( 'yaymail-yith-woo-request-a-quote', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.1', true );
	wp_enqueue_style( 'yaymail-yith-woo-request-a-quote', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.1' );
}

add_action( 'yaymail_before_enqueue_dependence', 'YITHWooRequestAQuote\\yaymail_dependence' );

add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => 'YITH_Request_Quote', // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array( 'YithRequestAQuote', 'YithRequestAQuoteQuote' ), // CHANGE HERE => main-name required
			'template_name'    => array(
				'ywraq_quote_status',
				'ywraq_email',
				'ywraq_email_customer',
				'ywraq_send_quote',
				'ywraq_send_quote_reminder',
				'ywraq_send_quote_reminder_accept',
			),
		);
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YITHWooRequestAQuote\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {

	if ( 'YITH_YWRAQ_Quote_Status' == $key
		|| 'YITH_YWRAQ_Send_Email_Request_Quote' == $key
		|| 'YITH_YWRAQ_Send_Email_Request_Quote_Customer' == $key
		|| 'YITH_YWRAQ_Send_Quote' == $key
		|| 'YITH_YWRAQ_Send_Quote_Reminder' == $key
		|| 'YITH_YWRAQ_Send_Quote_Reminder_Accept' == $key
	) {
		$getHeading                  = $value->heading;
		$defaultYITHWooRequestAQuote = templateDefault\DefaultYITHWooRequestAQuote::getTemplates( $value->id, $getHeading );
		return $defaultYITHWooRequestAQuote;
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateYITHWooRequestAQuote = array(
			'ywraq_quote_status',
			'ywraq_email',
			'ywraq_email_customer',
			'ywraq_send_quote',
			'ywraq_send_quote_reminder',
			'ywraq_send_quote_reminder_accept',
		);
		if ( in_array( $arrData[2], $templateYITHWooRequestAQuote ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateYITHWooRequestAQuote = array(
			'ywraq_quote_status',
			'ywraq_email',
			'ywraq_email_customer',
			'ywraq_send_quote',
			'ywraq_send_quote_reminder',
			'ywraq_send_quote_reminder_accept',
		);
		if ( in_array( $template, $templateYITHWooRequestAQuote ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( 'YITH_Request_Quote' === $component['plugin_name'] ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates['yith_request_a_quote'] = array_merge( isset( $addon_templates['yith_request_a_quote'] ) ? $addon_templates['yith_request_a_quote'] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */
// Display shortcode in core
add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YITH WooCommerce Request A Quote',
			'shortcode' => array(
				array( '[yaymail_addon_template_ywraq_email_header]', 'Quote header text' ),
				array( '[yaymail_addon_template_ywraq_quote_status]', 'Update status content' ),
				array( '[yaymail_addon_template_ywraq_email]', 'Admin quote request content' ),
				array( '[yaymail_addon_template_ywraq_email_customer]', 'Customer quote request content' ),
				array( '[yaymail_addon_template_ywraq_send_quote]', 'Email with quote content' ),
				array( '[yaymail_addon_template_ywraq_send_quote_reminder]', 'Reminder expiring quote content' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		// $shortcode_list[] = 'yaymail_addon_order_subscription';
		$shortcode_list[] = 'yaymail_addon_template_ywraq_email_header';
		$shortcode_list[] = 'yaymail_addon_template_ywraq_quote_status';
		$shortcode_list[] = 'yaymail_addon_template_ywraq_email';
		$shortcode_list[] = 'yaymail_addon_template_ywraq_email_customer';
		$shortcode_list[] = 'yaymail_addon_template_ywraq_send_quote';
		$shortcode_list[] = 'yaymail_addon_template_ywraq_send_quote_reminder';
		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		$shortcode_list['[yaymail_addon_template_ywraq_email_header]']        = yaymail_addon_template_ywraq_email_header( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_ywraq_quote_status]']        = yaymail_addon_template_ywraq_quote_status( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_ywraq_email]']               = yaymail_addon_template_ywraq_email( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_ywraq_email_customer]']      = yaymail_addon_template_ywraq_email_customer( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_ywraq_send_quote]']          = yaymail_addon_template_ywraq_send_quote( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_template_ywraq_send_quote_reminder]'] = yaymail_addon_template_ywraq_send_quote_reminder( $yaymail_informations, $args );
		return $shortcode_list;
	},
	10,
	3
);

function yaymail_addon_template_ywraq_email_header( $yaymail_informations, $args = array() ) {
	ob_start();
	include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_ywraq_email_header.php';
	$html = ob_get_contents();
	ob_end_clean();
	return $html;
}

function yaymail_addon_template_ywraq_quote_status( $yaymail_informations, $args = array() ) {
	if ( isset( $args['status'] ) && isset( $args['order'] ) ) {
		$status = $args['status'];
		$order  = $args['order'];
		$reason = isset( $args['reason'] ) ? $args['reason'] : '';
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_ywraq_quote_status.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_template_ywraq_quote_status.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}

function yaymail_addon_template_ywraq_email_customer( $yaymail_informations, $args = array() ) {
	if ( isset( $args['raq_data'] ) ) {
		$raq_data = $args['raq_data'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_ywraq_email_customer.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_template_ywraq_email_customer.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}

function yaymail_addon_template_ywraq_email( $yaymail_informations, $args = array() ) {
	if ( isset( $args['raq_data'] ) ) {
		$raq_data = $args['raq_data'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_ywraq_email.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_template_ywraq_email.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}

function yaymail_addon_template_ywraq_send_quote( $yaymail_informations, $args = array() ) {
	if ( isset( $args['raq_data'] ) && isset( $args['order'] ) ) {
		$raq_data = $args['raq_data'];
		$order    = $args['order'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_ywraq_send_quote.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_template_ywraq_send_quote.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}

function yaymail_addon_template_ywraq_send_quote_reminder( $yaymail_informations, $args = array() ) {
	if ( isset( $args['raq_data'] ) && isset( $args['order'] ) ) {
		$raq_data = $args['raq_data'];
		$order    = $args['order'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_template_ywraq_send_quote_reminder.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_template_ywraq_send_quote_reminder.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
add_action( 'YaymailAddonYithRequestAQuoteVue', 'YITHWooRequestAQuote\\yith_request_a_quote_vue', 100, 5 );
function yith_request_a_quote_vue( $order, $postID = '' ) {
	$html = '';
	if ( class_exists( 'YITH_Request_Quote_Premium' ) ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithRequestAQuoteVue.php';
		$html = ob_get_contents();
		ob_end_clean();
	}
	if ( '' === $html ) {
		$html = '<div></div>';
	}
	echo $html;

}

add_action( 'YaymailAddonYithRequestAQuoteQuoteVue', 'YITHWooRequestAQuote\\yith_request_a_quote_quote_vue', 100, 5 );
function yith_request_a_quote_quote_vue( $order, $postID = '' ) {
	$html = '';
	if ( class_exists( 'YITH_Request_Quote_Premium' ) ) {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithRequestAQuoteQuoteVue.php';
		$html = ob_get_contents();
		ob_end_clean();
	}
	if ( '' === $html ) {
		$html = '<div></div>';
	}
	echo $html;

}

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
add_action( 'YaymailAddonYithRequestAQuote', 'YITHWooRequestAQuote\\yaymail_addon_yith_request_a_quote', 100, 5 );
function yaymail_addon_yith_request_a_quote( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( isset( $args['raq_data'] ) ) {
		$raq_data   = $args['raq_data'];
		$email_type = $args['email']->id;
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithRequestAQuote.php';
		$html = ob_get_contents();
		ob_end_clean();
		$html = do_shortcode( $html );
		echo wp_kses_post( $html );
	} else {
		if ( isset( $args['order'] ) ) {
			$email_type = get_post_meta( $postID, '_yaymail_template', true ) ? get_post_meta( $postID, '_yaymail_template', true ) : 'ywraq_email';
			if ( 'SampleOrder' === $args['order'] ) {
				ob_start();
				include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/YaymailAddonYithRequestAQuote.php';
			} else {
				$raq_data = array(
					'order_id'    => $args['order']->get_id(),
					'raq_content' => $args['order']->get_items(),
				);
				ob_start();
				include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithRequestAQuote.php';
			}
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

add_action( 'YaymailAddonYithRequestAQuoteQuote', 'YITHWooRequestAQuote\\yaymail_addon_yith_request_a_quote_quote', 100, 5 );
function yaymail_addon_yith_request_a_quote_quote( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( isset( $args['order'] ) ) {
		if ( 'SampleOrder' === $args['order'] ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/YaymailAddonYithRequestAQuoteQuote.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			$order = $args['order'];
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithRequestAQuoteQuote.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		}
	} else {
		echo wp_kses_post( '' );
	}
}
