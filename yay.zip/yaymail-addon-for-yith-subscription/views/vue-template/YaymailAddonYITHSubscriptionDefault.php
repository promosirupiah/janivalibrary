<?php
	$sent_to_admin   = ( isset( $sent_to_admin ) ? true : false );
	$plain_text      = ( isset( $plain_text ) ? $plain_text : '' );
	$email           = ( isset( $email ) ? $email : '' );
	$text_link_color = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';

?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
				<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}">
					<a :style="{color: emailContent.settingRow.titleColor}" href="#" class="yaymail_builder_link"><?php printf( esc_html__( '[Subscription #1]', 'woocommerce' ) ); ?></a>
					(<?php printf( ' <time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?>)
				</h2>
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width: 100% !important;color: inherit;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor}">
					<thead>
						<tr style="word-break: normal;" :style="{color: emailContent.settingRow.textColor}">
							<th class="td" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</th>
							<th class="td" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleSubtotal}}</th>
						</tr>
					</thead>
					<tbody>
						<tr class="order_item" :style="{color: emailContent.settingRow.textColor}">
							<td class="td" style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<a href="#" :style="{color: emailTextLinkColor }"> <?php esc_html_e( 'Happy YayCommerce', 'yaymail' ); ?> </a> <?php esc_html_e( ' x 1', 'yaymail' ); ?>
							</td>
							<td class="td" style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php esc_html_e( '£18.00', 'yaymail' ); ?>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleItemTax}}
							</th>
							<td class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php esc_html_e( '£0', 'yaymail' ); ?>
							</td>
						</tr>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleSubtotal}}
							</th>
							<td class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php esc_html_e( '£18.00', 'yaymail' ); ?>
							</td>
						</tr>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleShipping}}
							</th>
							<td class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php esc_html_e( '£0', 'yaymail' ); ?>
							</td>
						</tr>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleShippingTax}}
							</th>
							<td colspan="2" class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php esc_html_e( '£0', 'yaymail' ); ?>
							</td>
						</tr>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleTotal}}
							</th>
							<td colspan="2" class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php esc_html_e( '£18.00', 'yaymail' ); ?>
							</td>
						</tr>
					</tfoot>
				</table>
			</div>
		</td>
	</tr>
</tbody>
</table>
