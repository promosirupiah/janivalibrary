<?php
if ( false != $subscription ) :
	$sent_to_admin    = ( isset( $sent_to_admin ) ? true : false );
	$plain_text       = ( isset( $plain_text ) ? $plain_text : '' );
	$email            = ( isset( $email ) ? $email : '' );
	$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
	$productId        = get_post_meta( $subscription, 'product_id', true );
	$productName      = get_post_meta( $subscription, 'product_name', true );
	$quantity         = (float) get_post_meta( $subscription, 'quantity', true );
	$lineTotal        = (float) get_post_meta( $subscription, 'line_total', true );
	$orderCurrency    = get_post_meta( $subscription, 'order_currency', true );
	$lineSubTotal     = (float) get_post_meta( $subscription, 'line_subtotal', true );
	$lineTax          = false == get_post_meta( $subscription, 'line_tax', true ) ? (float) get_post_meta( $subscription, 'line_tax', true ) : 0;
	$subscriptionDate = gmdate( 'Y-m-d', intval(get_post_meta( $subscription, 'start_date', true )) );
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >
				<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}">
					<a :style="{color: emailContent.settingRow.titleColor}" href="<?php echo esc_url( get_edit_post_link( $subscription ) ) ?>" class="yaymail_builder_link"><?php printf( esc_html__( '[Subscription #%s]', 'woocommerce' ), $subscription ); ?></a>
					(<?php printf( '<time datetime="%s">%s</time>', $subscriptionDate, wc_format_datetime( $order->get_date_created() ) ); ?>)
				</h2>
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width: 100% !important;color: inherit;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor}">
					<thead>
						<tr style="word-break: normal;" :style="{color: emailContent.settingRow.textColor}">
							<th class="td" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</th>
							<th class="td" scope="col" style="text-align:left;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleSubtotal}}</th>
						</tr>
					</thead>
					<tbody>
						<tr class="order_item" :style="{color: emailContent.settingRow.textColor}">
							<td class="td" style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<a href="<?php echo esc_url( get_permalink( $productId ) ); ?>" :style="{color: emailTextLinkColor }"> <?php echo wp_kses_post( $productName ); ?> </a> <?php echo ' x ' . esc_html( $quantity ); ?>
							</td>
							<td class="td" style="text-align:left; vertical-align:middle;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( wc_price( $lineTotal, array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<?php if ( 0 !== $lineTax ) : ?>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleItemTax}}
							</th>
							<td class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( wc_price( $lineTax, array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
						<?php endif ?>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleSubtotal}}
							</th>
							<td class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( wc_price( $lineTotal + $lineTax, array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
						<?php
						$subscriptions_shippings = get_post_meta( $subscription, 'order_shipping', true );
						if ( $subscriptions_shippings ) :
							?>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleShipping}}
							</th>
							<td class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php
									// translators:placeholder shipping name.
									echo wp_kses_post( wc_price( $subscriptions_shippings, array( 'currency' => $orderCurrency ) ) );
								?>
							</td>
						</tr>
							<?php
							if ( ! empty( get_post_meta( $subscription, 'order_shipping_tax', true ) ) ) :
							?>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleShippingTax}}
							</th>
							<td colspan="2" class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( wc_price( get_post_meta( $subscription, 'order_shipping_tax', true ), array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
								<?php
						endif;
						endif;
						?>
						<tr :style="{color: emailContent.settingRow.textColor}">
							<th scope="row" :style="{'border-color': emailContent.settingRow.borderColor}">
							{{emailContent.settingRow.titleTotal}}
							</th>
							<td colspan="2" class="td" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php echo wp_kses_post( wc_price( get_post_meta( $subscription, 'subscription_total', true ), array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
					</tfoot>
				</table>
			</div>
		</td>
	</tr>
</tbody>
</table>
<?php endif; ?>
