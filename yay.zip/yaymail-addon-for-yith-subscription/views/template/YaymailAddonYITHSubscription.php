<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( false != $subscription ) :
	$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
	$borderColor      = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
	$textColor        = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
	$sent_to_admin    = ( isset( $sent_to_admin ) ? true : false );
	$plain_text       = ( isset( $plain_text ) ? $plain_text : '' );
	$email            = ( isset( $email ) ? $email : '' );
	$titleProduct     = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
	$titleSubtotal    = isset( $attrs['titleSubtotal'] ) ? $attrs['titleSubtotal'] : 'Subtotal';
	$titleItemTax     = isset( $attrs['titleItemTax'] ) ? $attrs['titleItemTax'] : 'Item Tax';
	$titleShipping    = isset( $attrs['titleShipping'] ) ? $attrs['titleShipping'] : 'Shipping';
	$titleShippingTax = isset( $attrs['titleShippingTax'] ) ? $attrs['titleShippingTax'] : 'Shipping Tax';
	$titleTotal       = isset( $attrs['titleTotal'] ) ? $attrs['titleTotal'] : 'Total';
	$productId        = get_post_meta( $subscription, 'product_id', true );
	$productName      = get_post_meta( $subscription, 'product_name', true );
	$quantity         = (float) get_post_meta( $subscription, 'quantity', true );
	$lineTotal        = (float) get_post_meta( $subscription, 'line_total', true );
	$orderCurrency    = get_post_meta( $subscription, 'order_currency', true );
	$lineSubTotal     = (float) get_post_meta( $subscription, 'line_subtotal', true );
	$lineTax          = false == get_post_meta( $subscription, 'line_tax', true ) ? (float) get_post_meta( $subscription, 'line_tax', true ) : 0;
	$subscriptionDate = gmdate( 'Y-m-d', intval(get_post_meta( $subscription, 'start_date', true )) );
	?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
		  		<h2 class="yaymail_builder_order" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;font-size: 18px; font-weight: 700;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'>
					<a style="<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;" href="<?php echo esc_url( get_edit_post_link( $subscription ) ) ?>" class="yaymail_builder_link"><?php printf( esc_html__( '[Subscription #%s]', 'woocommerce' ), $subscription ); ?></a>
					(<?php esc_html_e( date_i18n( wc_date_format(), strtotime( $subscriptionDate ) ) ); ?>)
				</h2>
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style='width: 100% !important;color: inherit;<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
					<thead>
						<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th class="td" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleProduct, 'yith-woocommerce-subscription' ); ?></th>
							<th class="td" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleSubtotal, 'yith-woocommerce-subscription' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<tr class="order_item" style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<a href="<?php echo esc_url( get_permalink( $productId ) ); ?>" style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>;"> <?php echo wp_kses_post( $productName ); ?> </a> <?php echo ' x ' . esc_html( $quantity ); ?>
							</td>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php echo wp_kses_post( wc_price( $lineTotal, array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<?php if ( 0 !== $lineTax ) : ?>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleItemTax, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php echo wp_kses_post( wc_price( $lineTax, array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
						<?php endif ?>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleSubtotal, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php echo wp_kses_post( wc_price( $lineTotal + $lineTax, array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
						<?php
						$subscriptions_shippings = get_post_meta( $subscription, 'order_shipping', true );
						if ( $subscriptions_shippings ) :
							?>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleShipping, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php
									// translators:placeholder shipping name.
									echo wp_kses_post( wc_price( $subscriptions_shippings, array( 'currency' => $orderCurrency ) ) );
								?>
							</td>
						</tr>
							<?php
							if ( ! empty( get_post_meta( $subscription, 'order_shipping_tax', true ) ) ) :
							?>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleShippingTax, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td colspan="2" class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php echo wp_kses_post( wc_price( get_post_meta( $subscription, 'order_shipping_tax', true ), array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
								<?php
						endif;
						endif;
						?>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleTotal, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td colspan="2" class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php echo wp_kses_post( wc_price( get_post_meta( $subscription, 'subscription_total', true ), array( 'currency' => $orderCurrency ) ) ); ?>
							</td>
						</tr>
					</tfoot>
				</table>
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
<?php endif; ?>
