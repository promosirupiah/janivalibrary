<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$text_link_color  = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
$borderColor      = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
$textColor        = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
$sent_to_admin    = ( isset( $sent_to_admin ) ? true : false );
$plain_text       = ( isset( $plain_text ) ? $plain_text : '' );
$email            = ( isset( $email ) ? $email : '' );
$titleProduct     = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
$titleSubtotal    = isset( $attrs['titleSubtotal'] ) ? $attrs['titleSubtotal'] : 'Subtotal';
$titleItemTax     = isset( $attrs['titleItemTax'] ) ? $attrs['titleItemTax'] : 'Item Tax';
$titleShipping    = isset( $attrs['titleShipping'] ) ? $attrs['titleShipping'] : 'Shipping';
$titleShippingTax = isset( $attrs['titleShippingTax'] ) ? $attrs['titleShippingTax'] : 'Shipping Tax';
$titleTotal       = isset( $attrs['titleTotal'] ) ? $attrs['titleTotal'] : 'Total';
?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>;<?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>;"
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
		  		<h2 class="yaymail_builder_order" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;font-size: 18px; font-weight: 700;<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;'>
				  <a style="<?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>;" href="#" class="yaymail_builder_link"><?php printf( esc_html__( '[Subscription #1]', 'woocommerce' ) ); ?></a>
					(<?php printf( ' <time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?>)
				</h2>
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style='width: 100% !important;color: inherit;<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
					<thead>
						<tr style="word-break: normal;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th class="td" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleProduct, 'yith-woocommerce-subscription' ); ?></th>
							<th class="td" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'><?php esc_html_e( $titleSubtotal, 'yith-woocommerce-subscription' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<tr class="order_item" style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<a href="#" style="<?php echo esc_attr( 'color: ' . $text_link_color ); ?>;"> <?php esc_html_e( 'Happy YayCommerce', 'yaymail' ); ?> </a> <?php esc_html_e( ' x 1', 'yaymail' ); ?>
							</td>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( '£18.00', 'yaymail' ); ?>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleItemTax, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( '£0', 'yaymail' ); ?>
							</td>
						</tr>

						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleSubtotal, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( '£18.00', 'yaymail' ); ?>
							</td>
						</tr>
					
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleShipping, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( '£0', 'yaymail' ); ?>
							</td>
						</tr>
						
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleShippingTax, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td colspan="2" class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( '£0', 'yaymail' ); ?>
							</td>
						</tr>
						<tr style="<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
							<th scope="row" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( $titleTotal, 'yith-woocommerce-subscription' ); ?>
							</th>
							<td colspan="2" class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'border-color: ' . $attrs['borderColor'] ); ?>;'>
								<?php esc_html_e( '£18.00', 'yaymail' ); ?>
							</td>
						</tr>
					</tfoot>
				</table>
		  </div>
		</td>
	  </tr>
	</tbody>
</table>
