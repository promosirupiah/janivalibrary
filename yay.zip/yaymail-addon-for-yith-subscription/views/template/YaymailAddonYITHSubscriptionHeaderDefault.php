<?php

defined( 'ABSPATH' ) || exit;
$sent_to_admin  = ( isset( $args['sent_to_admin'] ) ? true : false );
$beforeText     = esc_html__( 'Hi John', 'woocommerce' ) . wp_kses_post( ',<br><br>' );
$headerContent  = '';
$headerContent  = '<span style="color: inherit;font-size: 14px;" class="yaymail_subscription_header">';
$headerContent .= $beforeText;
if ( 'ywsbs_customer_subscription_expired' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 has expired.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_before_expired' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 is going to expire.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_suspended' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 has been suspended.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_cancelled' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 has been cancelled.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_paused' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 has been paused.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_resumed' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 has been resumed.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_renew_reminder' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Subscription #1 is going to renew.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_request_payment' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Your recent subscription renewal order on ', 'woocommerce' ) . wp_kses_post( get_option( 'blogname' ) ) . esc_html__( ' is late for payment.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_payment_failed' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'The payment to renew your subscription failed. Please, verify your available funds for the card specified during subscription and/or verify that your card is not expired.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_payment_done' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'Your subscription order is now being processed. Your order details are shown below for your reference: ', 'woocommerce' ) . wp_kses_post( get_option( 'blogname' ) );
}
if ( 'ywsbs_subscription_admin_mail' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'The status of subscription #1 has changed.', 'woocommerce' );
}
if ( 'ywsbs_customer_subscription_delivery_schedules' == $yaymail_informations['template'] ) {
	$headerContent .= esc_html__( 'We confirm you that we\'ve just shipped your product to your address:', 'woocommerce' );
}
$headerContent .= '</span>';
echo wp_kses_post( $headerContent );
