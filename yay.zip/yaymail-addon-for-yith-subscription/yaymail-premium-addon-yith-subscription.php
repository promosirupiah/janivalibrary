<?php
/**
 * Plugin Name: YayMail Addon for YITH WooCommerce Subscription
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize email templates for YITH WooCommerce Subscription plugin
 * Version: 1.4
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 5.4.1
 * Domain Path: /i18n/languages/
 */

namespace YayMailYITHSubscription;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailYITHSubscription\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

add_filter( 'plugin_row_meta', 'YayMailYITHSubscription\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailYITHSubscription\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );

function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

// if ( class_exists( 'YWSBS_Subscription' ) ) {

function yaymail_yith_subscription_dependence() {
	if ( class_exists( 'YWSBS_Subscription' ) ) {
		wp_enqueue_script( 'yaymail-yith-subscription', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.2', true );
		wp_enqueue_style( 'yaymail-yith-subscription', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.2' );
	}
}

// Add filter to defined new updated element's properties
add_filter(
	'yaymail_addon_get_updated_elements',
	function( $element ) {
		if ( class_exists( 'YWSBS_Subscription' ) ) {
			$result = array_merge(
				$element,
				array(
					'AddonYITHSubscription' => array(), // Element type => array of new properties
				)
			);
		}
		return $result;
	},
	10,
	1
);

add_action( 'yaymail_before_enqueue_dependence', 'YayMailYITHSubscription\\yaymail_yith_subscription_dependence' );
add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		if ( class_exists( 'YWSBS_Subscription' ) ) {
			$plugins[] = array(
				'plugin_name'      => 'YITH_Subscription',
				'addon_components' => array( 'YITHSubscription' ),
				'template_name'    => array(
					'ywsbs_subscription_admin_mail',
					'ywsbs_customer_subscription_cancelled',
					'ywsbs_customer_subscription_suspended',
					'ywsbs_customer_subscription_expired',
					'ywsbs_customer_subscription_before_expired',
					'ywsbs_customer_subscription_paused',
					'ywsbs_customer_subscription_resumed',
					'ywsbs_customer_subscription_request_payment',
					'ywsbs_customer_subscription_renew_reminder',
					'ywsbs_customer_subscription_payment_done',
					'ywsbs_customer_subscription_payment_failed',
					'ywsbs_customer_subscription_delivery_schedules',
				),
			);
		}
		return $plugins;
	},
	10,
	1
);

/*
ACtion to defined shortcode

$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateYITHSubscription = array( 'ywsbs_subscription_admin_mail', 'ywsbs_customer_subscription_cancelled', 'ywsbs_customer_subscription_suspended', 'ywsbs_customer_subscription_expired', 'ywsbs_customer_subscription_before_expired', 'ywsbs_customer_subscription_paused', 'ywsbs_customer_subscription_resumed', 'ywsbs_customer_subscription_request_payment', 'ywsbs_customer_subscription_renew_reminder', 'ywsbs_customer_subscription_payment_done', 'ywsbs_customer_subscription_payment_failed', 'ywsbs_customer_subscription_delivery_schedules' );
		if ( in_array( $arrData[2], $templateYITHSubscription ) ) {
			$arrData[0]->setOrderId( $arrData[1]['subscription']->order->id, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateYITHSubscription = array( 'ywsbs_subscription_admin_mail', 'ywsbs_customer_subscription_cancelled', 'ywsbs_customer_subscription_suspended', 'ywsbs_customer_subscription_expired', 'ywsbs_customer_subscription_before_expired', 'ywsbs_customer_subscription_paused', 'ywsbs_customer_subscription_resumed', 'ywsbs_customer_subscription_request_payment', 'ywsbs_customer_subscription_renew_reminder', 'ywsbs_customer_subscription_payment_done', 'ywsbs_customer_subscription_payment_failed', 'ywsbs_customer_subscription_delivery_schedules' );
		if ( in_array( $template, $templateYITHSubscription ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		if ( class_exists( 'YWSBS_Subscription' ) ) {
			$components = apply_filters( 'yaymail_plugins', array() );
			$position   = '';
			foreach ( $components as $key => $component ) {
				if ( $component['plugin_name'] === 'YITH_Subscription' ) {
					$position = $key;
					break;
				}
			}
			foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
				ob_start();
				do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
				$html = ob_get_contents();
				ob_end_clean();
				$addon_templates['yith_subscription'] = array_merge( isset( $addon_templates['yith_subscription'] ) ? $addon_templates['yith_subscription'] : array(), array( $component . 'Vue' => $html ) );
			}
		}
		return $addon_templates;
	},
	10,
	3
);

// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		if ( class_exists( 'YWSBS_Subscription' ) ) {
			$shortcode_list[] = 'yaymail_addon_yith_subscription_header';
		}
		return $shortcode_list;
	},
	10,
	1
);

add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YITH Subscription',
			'shortcode' => array(
				array( '[yaymail_addon_yith_subscription_header]', 'Subscription Header' ),
			),
		);

		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( class_exists( 'YWSBS_Subscription' ) ) {
			$shortcode_list['[yaymail_addon_yith_subscription_header]'] = yaymailAddonYITHSubscriptionHeader( $yaymail_informations, $args );
		}
		return $shortcode_list;
	},
	10,
	3
);
function yaymailAddonYITHSubscriptionHeader( $yaymail_informations, $args = array() ) {
	if ( class_exists( 'YWSBS_Subscription' ) ) {
		$order        = isset( $yaymail_informations['order'] ) ? $yaymail_informations['order'] : null;
		$subscription = false;
		if ( isset( $order ) ) {
			foreach ( $order->get_meta_data() as $meta ) {
				$item_meta_data = $meta->get_data()['key'];
				if ( 'subscriptions' == $item_meta_data ) {
					$subscription = is_array( $meta->get_data()['value'] ) ? $meta->get_data()['value'][0] : $meta->get_data()['value'];
					break;
				}
			}
		}
		if ( false !== $subscription ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHSubscriptionHeader.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHSubscriptionHeaderDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}
}


// Create HTML with Vue syntax to display in Vue
add_action( 'YaymailAddonYITHSubscriptionVue', 'YayMailYITHSubscription\\yith_subscription_vue', 100, 5 );
function yith_subscription_vue( $order, $postID = '' ) {
	if ( class_exists( 'YWSBS_Subscription' ) ) {
		$subscription = false;
		if ( '' !== $order ) {
			foreach ( $order->get_meta_data() as $meta ) {
				$item_meta_data = $meta->get_data()['key'];
				if ( 'subscriptions' == $item_meta_data ) {
					$subscription = is_array( $meta->get_data()['value'] ) ? $meta->get_data()['value'][0] : $meta->get_data()['value'];
					break;
				}
			}
		}
		if ( '' === $order || false === $subscription ) {
			$order_id = 1;
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYITHSubscriptionDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
		} else {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYITHSubscription.php';
			$html = ob_get_contents();
			ob_end_clean();
			if ( '' === $html ) {
				$html = '<div></div>';
			}
		}
		echo $html;
	}
}

// Create HTML to display when send mail
add_action( 'YaymailAddonYITHSubscription', 'YayMailYITHSubscription\\yith_subscription', 100, 5 );
function yith_subscription( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
	if ( class_exists( 'YWSBS_Subscription' ) ) {
		$order        = null;
		$subscription = false;
		if ( isset( $args['order'] ) ) {
			$order = $args['order'];
			if ( 'SampleOrder' !== $order ) {
				foreach ( $order->get_meta_data() as $meta ) {
					$item_meta_data = $meta->get_data()['key'];
					if ( 'subscriptions' == $item_meta_data ) {
						$subscription = is_array( $meta->get_data()['value'] ) ? $meta->get_data()['value'][0] : $meta->get_data()['value'];
						break;
					}
				}
			}
		} elseif ( isset( $args['subscription'] ) ) {
			$subscription = $args['subscription']->id;
		}
		if ( false !== $subscription ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHSubscription.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} elseif ( 'SampleOrder' == $order ) {
			ob_start();
			include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYITHSubscriptionDefault.php';
			$html = ob_get_contents();
			ob_end_clean();
			$html = do_shortcode( $html );
			echo wp_kses_post( $html );
		} else {
			echo wp_kses_post( '' );
		}
	}
}

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailYITHSubscription\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {
	if ( class_exists( 'YWSBS_Subscription' ) ) {
		$getHeading = $value->heading;
		if ( 'YITH_WC_Subscription_Status' == $key
		|| 'YITH_WC_Customer_Subscription_Cancelled' == $key
		|| 'YITH_WC_Customer_Subscription_Suspended' == $key
		|| 'YITH_WC_Customer_Subscription_Expired' == $key
		|| 'YITH_WC_Customer_Subscription_Before_Expired' == $key
		|| 'YITH_WC_Customer_Subscription_Paused' == $key
		|| 'YITH_WC_Customer_Subscription_Resumed' == $key
		|| 'YITH_WC_Customer_Subscription_Request_Payment' == $key
		|| 'YITH_WC_Customer_Subscription_Renew_Reminder' == $key
		|| 'YITH_WC_Customer_Subscription_Payment_Done' == $key
		|| 'YITH_WC_Customer_Subscription_Payment_Failed' == $key
		|| 'YITH_WC_Customer_Subscription_Delivery_Schedules' == $key
		) {
			$defaultYITHSubscription = templateDefault\DefaultYITHSubscription::getTemplates( $value->id, $getHeading );
			return $defaultYITHSubscription;
		}
		return $array;
	}
}




