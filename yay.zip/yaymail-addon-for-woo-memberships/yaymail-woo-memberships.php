<?php
/**
 * Plugin Name: YayMail Addon for WooCommerce Memberships
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates for WooCommerce Memberships plugin
 * Version: 1.2
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 6.1.0
 * Domain Path: /i18n/languages/
 */

namespace YayMailWooMemberships;

defined( 'ABSPATH' ) || exit;
spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/views';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// Add action link customize
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'YayMailWooMemberships\\yaymail_addon_add_action_links' );
function yaymail_addon_add_action_links( $actions ) {

	if ( defined( 'YAYMAIL_PREFIX' ) ) {
		$links   = array(
			'<a href="' . admin_url( 'admin.php?page=yaymail-settings' ) . '" aria-label="' . esc_attr__( 'View WooCommerce Email Builder', 'yaymail' ) . '">' . esc_html__( 'Start Customizing', 'yaymail' ) . '</a>',
		);
		$actions = array_merge( $links, $actions );
	}
	return $actions;
}

// Add action link docs and support
add_filter( 'plugin_row_meta', 'YayMailWooMemberships\\yaymail_addon_custom_plugin_row_meta', 10, 2 );
function yaymail_addon_custom_plugin_row_meta( $plugin_meta, $plugin_file ) {

	if ( strpos( $plugin_file, plugin_basename( __FILE__ ) ) !== false ) {
		$new_links = array(
			'docs'    => '<a href="https://yaycommerce.gitbook.io/yaymail/" aria-label="' . esc_attr__( 'View YayMail documentation', 'yaymail' ) . '">' . esc_html__( 'Docs', 'yaymail' ) . '</a>',
			'support' => '<a href="https://yaycommerce.com/support/" aria-label="' . esc_attr__( 'Visit community forums', 'yaymail' ) . '">' . esc_html__( 'Support', 'yaymail' ) . '</a>',
		);

		$plugin_meta = array_merge( $plugin_meta, $new_links );
	}

	return $plugin_meta;
}

// Add action notice
add_action( 'after_plugin_row_' . plugin_basename( __FILE__ ), 'YayMailWooMemberships\\yaymail_addon_add_notification_after_plugin_row', 10, 2 );
function yaymail_addon_add_notification_after_plugin_row( $plugin_file, $plugin_data ) {

	if ( ! defined( 'YAYMAIL_PREFIX' ) ) {
		$wp_list_table = _get_list_table( 'WP_MS_Themes_List_Table' );
		?>
		<script>
		var plugin_row_element = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( __FILE__ ) ); ?>"]');
		plugin_row_element.classList.add('update');
		</script>
		<?php
		echo '<tr class="plugin-update-tr' . ( is_plugin_active( $plugin_file ) ? ' active' : '' ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange" >';
		echo '<div class="notice inline notice-warning notice-alt"><p>';
		echo esc_html__( 'To use this addon, you need to install and activate YayMail plugin. Get ', 'yaymail' ) . '<a href="' . esc_url( 'https://wordpress.org/plugins/yaymail/' ) . '">' . esc_html__( 'YayMail Free', 'yaymail' ) . '</a> or <a href="' . esc_url( 'https://yaycommerce.com/yaymail-woocommerce-email-customizer/' ) . '">' . esc_html__( 'YayMail Pro', 'yaymail' ) . '</a>.
					</p>
				</div>
			</td>
			</tr>';
	}

}

// function yaymail_dependence() {
// 	wp_enqueue_script( 'yaymail-woomemberships', plugin_dir_url( __FILE__ ) . 'assets/dist/js/app.js', array(), '1.0', true );
// 	wp_enqueue_style( 'yaymail-woomemberships', plugin_dir_url( __FILE__ ) . 'assets/dist/css/app.css', array(), '1.0' );
// }
// add_action( 'yaymail_before_enqueue_dependence', 'YayMailWooMemberships\\yaymail_dependence' );

add_filter(
	'yaymail_plugins',
	function( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => 'Woo_Memberships', // --> CHANGE HERE => name of plugin (maybe name of the class)
			'addon_components' => array(), // CHANGE HERE => main-name required
			'template_name'    => array(
				'WC_Memberships_User_Membership_Activated_Email',
				'WC_Memberships_User_Membership_Ended_Email',
				'WC_Memberships_User_Membership_Ending_Soon_Email',
				'WC_Memberships_User_Membership_Note_Email',
				'WC_Memberships_User_Membership_Renewal_Reminder_Email',
				'wc_memberships_for_teams_team_invitation',
				'wc_memberships_for_teams_team_membership_ended',
				'wc_memberships_for_teams_team_membership_ending_soon',
				'wc_memberships_for_teams_team_membership_renewal_reminder',
			),
		);
		return $plugins;
	},
	10,
	1
);

// Action create template default
add_filter( 'YaymailNewTempalteDefault', 'YayMailWooMemberships\\yaymail_new_template_default', 100, 3 );
function yaymail_new_template_default( $array, $key, $value ) {

	if ( 'WC_Memberships_User_Membership_Activated_Email' == $key
		|| 'WC_Memberships_User_Membership_Ended_Email' == $key
		|| 'WC_Memberships_User_Membership_Ending_Soon_Email' == $key
		|| 'WC_Memberships_User_Membership_Note_Email' == $key
		|| 'WC_Memberships_User_Membership_Renewal_Reminder_Email' == $key
		|| 'wc_memberships_for_teams_team_invitation' == $key
		|| 'wc_memberships_for_teams_team_membership_ended' == $key
		|| 'wc_memberships_for_teams_team_membership_ending_soon' == $key
		|| 'wc_memberships_for_teams_team_membership_renewal_reminder' == $key
	) {
		$getHeading            = $value->heading;
		$defaultWooMemberships = templateDefault\DefaultWooMemberships::getTemplates( $value->id, $getHeading );
		return $defaultWooMemberships;
	}
	return $array;
}

/*
Action to defined shortcode
$arrData[0] : $custom_shortcode
$arrData[1] : $args
$arrData[2] : $templateName
*/

add_action(
	'yaymail_addon_defined_shorcode',
	function( $arrData ) {
		$templateWooSubscription = array(
				'WC_Memberships_User_Membership_Activated_Email',
				'WC_Memberships_User_Membership_Ended_Email',
				'WC_Memberships_User_Membership_Ending_Soon_Email',
				'WC_Memberships_User_Membership_Note_Email',
				'WC_Memberships_User_Membership_Renewal_Reminder_Email',
				'wc_memberships_for_teams_team_invitation',
				'wc_memberships_for_teams_team_membership_ended',
				'wc_memberships_for_teams_team_membership_ending_soon',
				'wc_memberships_for_teams_team_membership_renewal_reminder',
			);
		if ( in_array( $arrData[2], $templateWooSubscription ) ) {
			$arrData[0]->setOrderId( 0, isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
			$arrData[0]->shortCodesOrderDefined( isset( $arrData[1]['sent_to_admin'] ) ? $arrData[1]['sent_to_admin'] : false, $arrData[1] );
		}
	}
);

// Filter to defined template
add_filter(
	'yaymail_addon_defined_template',
	function( $result, $template ) {
		$templateWooSubscription = array(
				'WC_Memberships_User_Membership_Activated_Email',
				'WC_Memberships_User_Membership_Ended_Email',
				'WC_Memberships_User_Membership_Ending_Soon_Email',
				'WC_Memberships_User_Membership_Note_Email',
				'WC_Memberships_User_Membership_Renewal_Reminder_Email',
				'wc_memberships_for_teams_team_invitation',
				'wc_memberships_for_teams_team_membership_ended',
				'wc_memberships_for_teams_team_membership_ending_soon',
				'wc_memberships_for_teams_team_membership_renewal_reminder',
			);
		if ( in_array( $template, $templateWooSubscription ) ) {
			return true;
		}
		return $result;
	},
	10,
	2
);

// CHANGE HERE
// Filter to add template to Vuex
add_filter(
	'yaymail_addon_templates',
	function( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( $component['plugin_name'] === 'Woo_Memberships' ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates['woo_memberships'] = array_merge( isset( $addon_templates['woo_memberships'] ) ? $addon_templates['woo_memberships'] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	},
	10,
	3
);

/** SHORTCODE WILL DO HERE */

// Display shortcode in core
add_filter(
	'yaymail_list_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin' => 'Memberships',
			'shortcode' => array(
				['[yaymail_addon_memberships_member_name]', 'Memberships Member Name'],
				['[yaymail_addon_memberships_member_first_name]', 'Memberships Member First Name'],
				['[yaymail_addon_memberships_member_last_name]', 'Memberships Member Last Name'],
				['[yaymail_addon_memberships_member_full_name]', 'Memberships Member Full Name'],
				['[yaymail_addon_membership_plan]', 'Memberships Plan'],
				['[yaymail_addon_membership_expiration_date]', 'Memberships Expiration Date'],
				['[yaymail_addon_membership_view_url]', 'Memberships View URL'],
				['[yaymail_addon_membership_renewal_url]', 'Memberships Renewal URL'],
				['[yaymail_addon_membership_note]', 'Memberships Note'],
				['[yaymail_addon_membership_team_invitation]', 'Team Invitation Template'],
				['[yaymail_addon_membership_team_membership_ended]', 'Membership Ended Template'],
				['[yaymail_addon_team_membership_ending_soon]', 'Ending Soon Template'],
				['[yaymail_addon_team_membership_renewal_reminder]', 'Renewal Reminder Template'],
				['[yaymail_addon_membership_team_sender_name]', 'Sender Name'],
				['[yaymail_addon_membership_team_name]', 'Team Name'],
				['[yaymail_addon_membership_team_site_title]', 'Site Title'],
				['[yaymail_addon_membership_team_membership_plan]', 'Membership Plan Name'],
			)
		);

		return $shortcode_list;
	},
	10,
	1
);
// Add new shortcode to shortcodes list
add_filter(
	'yaymail_shortcodes',
	function( $shortcode_list ) {
		$shortcode_list[] = 'yaymail_addon_memberships_member_name';
		$shortcode_list[] = 'yaymail_addon_memberships_member_first_name';
		$shortcode_list[] = 'yaymail_addon_memberships_member_last_name';
		$shortcode_list[] = 'yaymail_addon_memberships_member_full_name';
		$shortcode_list[] = 'yaymail_addon_membership_plan';
		$shortcode_list[] = 'yaymail_addon_membership_expiration_date';
		$shortcode_list[] = 'yaymail_addon_membership_expiry_time_diff';
		$shortcode_list[] = 'yaymail_addon_membership_view_url';
		$shortcode_list[] = 'yaymail_addon_membership_renewal_url';
		$shortcode_list[] = 'yaymail_addon_membership_note';

		$shortcode_list[] = 'yaymail_addon_membership_team_invitation';
		$shortcode_list[] = 'yaymail_addon_membership_team_membership_ended';
		$shortcode_list[] = 'yaymail_addon_team_membership_ending_soon';
		$shortcode_list[] = 'yaymail_addon_team_membership_renewal_reminder';

		$shortcode_list[] = 'yaymail_addon_membership_team_sender_name';
		$shortcode_list[] = 'yaymail_addon_membership_team_name';
		$shortcode_list[] = 'yaymail_addon_membership_team_site_title';
		$shortcode_list[] = 'yaymail_addon_membership_team_membership_plan';
		return $shortcode_list;
	},
	10,
	1
);

// Create shortcode
add_filter(
	'yaymail_do_shortcode',
	function( $shortcode_list, $yaymail_informations, $args = array() ) {
		$shortcode_list['[yaymail_addon_memberships_member_name]']       = yaymail_addon_memberships_member_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_memberships_member_first_name]'] = yaymail_addon_memberships_member_first_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_memberships_member_last_name]']  = yaymail_addon_memberships_member_last_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_memberships_member_full_name]']  = yaymail_addon_memberships_member_full_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_plan]']               = yaymail_addon_membership_plan( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_expiration_date]']    = yaymail_addon_membership_expiration_date( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_expiry_time_diff]']   = yaymail_addon_membership_expiry_time_diff( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_view_url]']           = yaymail_addon_membership_view_url( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_renewal_url]']        = yaymail_addon_membership_renewal_url( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_note]']               = yaymail_addon_membership_note( $yaymail_informations, $args );

		$shortcode_list['[yaymail_addon_membership_team_invitation]']               = yaymail_addon_membership_team_invitation( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_team_membership_ended]']               = yaymail_addon_membership_team_membership_ended( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_team_membership_ending_soon]']               = yaymail_addon_membership_team_membership_ending_soon( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_team_membership_renewal_reminder]']               = yaymail_addon_membership_team_membership_renewal_reminder( $yaymail_informations, $args );
		
		$shortcode_list['[yaymail_addon_membership_team_sender_name]']               = yaymail_addon_membership_team_sender_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_team_name]']               = yaymail_addon_membership_team_name( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_team_site_title]']               = yaymail_addon_membership_team_site_title( $yaymail_informations, $args );
		$shortcode_list['[yaymail_addon_membership_team_membership_plan]']               = yaymail_addon_membership_team_membership_plan( $yaymail_informations, $args );
	
		return $shortcode_list;
	},
	10,
	3
);

function yaymail_addon_membership_team_membership_plan( $yaymail_informations, $args = array() ) {
	if (isset($args['invitation'])) {
		$invitation = $args['invitation'];
		$plan = $invitation->get_plan();
		$membership_plan = $plan ? $plan->get_name() : '';
		return $membership_plan;
	}
	 return 'membership_plan';
}

function yaymail_addon_membership_team_site_title( $yaymail_informations, $args = array() ) {
	$site_title          = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
	return $site_title;
}

function yaymail_addon_membership_team_name( $yaymail_informations, $args = array() ) {
	if (isset($args['invitation'])) {
		$invitation = $args['invitation'];
		$team = $invitation->get_team();
		$team_name = $team ? $team->get_name() : '';
		return $team_name;
	}
	 return 'team_name';
}

function yaymail_addon_membership_team_sender_name( $yaymail_informations, $args = array() ) {
	if (isset($args['invitation'])) {
		$invitation = $args['invitation'];
		$sender            = $invitation->get_sender();
		$sender_name       = ! empty( $sender->display_name ) ? $sender->display_name : '';
		return $sender_name;
	}
	 return 'sender_name';
}

function yaymail_addon_membership_team_membership_renewal_reminder( $yaymail_informations, $args = array() ) {
	if (isset($args['team'])) {
		$team = $args['team'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_membership_team_membership_renewal_reminder.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_membership_team_membership_renewal_reminder.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymail_addon_membership_team_membership_ending_soon( $yaymail_informations, $args = array() ) {
	if (isset($args['team'])) {
		$team = $args['team'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_membership_team_membership_ending_soon.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_membership_team_membership_ending_soon.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymail_addon_membership_team_membership_ended( $yaymail_informations, $args = array() ) {
	if (isset($args['team'])) {
		$team = $args['team'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_membership_team_membership_ended.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_membership_team_membership_ended.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymail_addon_membership_team_invitation( $yaymail_informations, $args = array() ) {
	if (isset($args['invitation'])) {
		$invitation = $args['invitation'];
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/yaymail_addon_membership_team_invitation.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	} else {
		ob_start();
		include plugin_dir_path( __FILE__ ) . '/views/template/TemplateSample/yaymail_addon_membership_team_invitation.php';
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}

}

function yaymail_addon_membership_note( $yaymail_informations, $args = array() ) {
	if ( isset( $args['membership_note'] ) ) {
		$membership_note = $args['membership_note'];
		return $membership_note;
	}
	return 'membership_note';
}

function yaymail_addon_membership_renewal_url( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership        = $args['user_membership'];
		$membership_renewal_url = esc_url( $user_membership->get_renew_membership_url() );
		return $membership_renewal_url;
	}
	return 'membership_renewal_url';
}

function yaymail_addon_membership_view_url( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership     = $args['user_membership'];
		$membership_view_url = esc_url( $user_membership->get_view_membership_url() );
		return $membership_view_url;
	}
	return 'membership_view_url';
}

function yaymail_addon_membership_expiry_time_diff( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership           = $args['user_membership'];
		$expiration_date_timestamp = $user_membership->get_local_end_date( 'timestamp' );
		return human_time_diff( time(), $expiration_date_timestamp );
	}
	return 'membership_expiry_time_diff';
}

function yaymail_addon_membership_expiration_date( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership           = $args['user_membership'];
		$expiration_date_timestamp = $user_membership->get_local_end_date( 'timestamp' );
		return date_i18n( wc_date_format(), $expiration_date_timestamp );
	}
	return 'expiration_date_timestamp';
}

function yaymail_addon_membership_plan( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership  = $args['user_membership'];
		$membership_plan  = $user_membership->get_plan();
		$membership_plans = $membership_plan ? $membership_plan->get_name() : '';
		return $membership_plans;
	}
	return 'membership_plan';
}

function yaymail_addon_memberships_member_full_name( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership   = $args['user_membership'];
		$member            = get_user_by( 'id', $user_membership->get_user_id() );
		$member_name       = ! empty( $member->display_name ) ? $member->display_name : '';
		$member_first_name = ! empty( $member->first_name ) ? $member->first_name : $member_name;
		$member_last_name  = ! empty( $member->last_name ) ? $member->last_name : '';
		$member_full_name  = $member_first_name && $member_last_name ? $member_first_name . ' ' . $member->last_name : $member_name;
		return $member_full_name;
	}
	return 'member_full_name';
}

function yaymail_addon_memberships_member_last_name( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership  = $args['user_membership'];
		$member           = get_user_by( 'id', $user_membership->get_user_id() );
		$member_last_name = ! empty( $member->last_name ) ? $member->last_name : '';
		return $member_last_name;
	}
	return 'member_last_name';
}

function yaymail_addon_memberships_member_first_name( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership   = $args['user_membership'];
		$member            = get_user_by( 'id', $user_membership->get_user_id() );
		$member_name       = ! empty( $member->display_name ) ? $member->display_name : '';
		$member_first_name = ! empty( $member->first_name ) ? $member->first_name : $member_name;
		return $member_first_name;
	}
	return 'member_first_name';
}

function yaymail_addon_memberships_member_name( $yaymail_informations, $args = array() ) {
	if ( isset( $args['user_membership'] ) ) {
		$user_membership = $args['user_membership'];
		$member          = get_user_by( 'id', $user_membership->get_user_id() );
		$member_name     = ! empty( $member->display_name ) ? $member->display_name : '';
		return $member_name;
	}
	return 'member_name';
}
/** END SHORTCODE */


// Create HTML with Vue syntax to display in Vue
// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
// CHANGE SOURCE VUE TOO
// add_action( 'YaymailAddonYithVendorInformationVue', 'YayMailWooMemberships\\yith_vendor_information_vue', 100, 5 );
// function yith_vendor_information_vue( $order, $postID = '' ) {
// 	if ( '' === $order ) {
// 		ob_start();
// 		include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorInformation.php';
// 		$html = ob_get_contents();
// 		ob_end_clean();
// 	} else {
// 		ob_start();
// 		include plugin_dir_path( __FILE__ ) . '/views/vue-template/YaymailAddonYithVendorInformation.php';
// 		$html = ob_get_contents();
// 		ob_end_clean();
// 		if ( '' === $html ) {
// 			$html = '<div></div>';
// 		}
// 	}
// 	echo $html;
// }

// Create HTML to display when send mail
// CHANGE HERE => Name of action follow: YaymailAddon + main-name
// add_action( 'YaymailAddonYithVendorInformation', 'YayMailWooMemberships\\yaymail_addon_yith_vendor_information', 100, 5 );
// function yaymail_addon_yith_vendor_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $postID = '' ) {
// 	$order = $args['order'];
// 	if ( isset( $order ) ) {
// 		ob_start();
// 		include plugin_dir_path( __FILE__ ) . '/views/template/YaymailAddonYithVendorInformation.php';
// 		$html = ob_get_contents();
// 		ob_end_clean();
// 		$html = do_shortcode( $html );
// 		echo wp_kses_post( $html );
// 	} else {
// 		echo wp_kses_post( '' );
// 	}
// }




