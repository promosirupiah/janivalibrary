<?php

namespace YayMailWooMemberships\templateDefault;

defined( 'ABSPATH' ) || exit;

class DefaultWooMemberships {

	protected static $instance = null;

	public static function getInstance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function getTemplates( $customOrder, $emailHeading ) {
		/*
		@@@ Html default send email.
		@@@ Note: Add characters '\' before special characters in a string.
		@@@ Example: font-family: \'Helvetica Neue\'...
		*/

		$emailTitle = __( $emailHeading, 'woocommerce' );

		$customText = '';
		$emailtext = '1111';
		if ( 'WC_Memberships_User_Membership_Ending_Soon_Email' == $customOrder ) {
			$emailTitle = 'An update about your ' . do_shortcode( '[yaymail_addon_membership_plan]' );
		}

		if ( 'WC_Memberships_User_Membership_Renewal_Reminder_Email' == $customOrder ) {
			$emailTitle = 'You can renew your ' . do_shortcode( '[yaymail_addon_membership_plan]' );
		}

		if ( 'WC_Memberships_User_Membership_Note_Email' == $customOrder ) {
			$emailtext = '<p>Hello, a note has just been added to your membership:</p><p>' . do_shortcode( '[yaymail_addon_membership_note]' ) . '</p>';
		}
		if ( 'WC_Memberships_User_Membership_Activated_Email' == $customOrder ) {
			$emailTitle = 'You can now access ' . do_shortcode( '[yaymail_addon_membership_plan]' );
			$emailtext = '<p>Hey' . do_shortcode( '[yaymail_addon_memberships_member_name]' ) . '</p><p>Your ' . do_shortcode( '[yaymail_addon_membership_plan]' ) . ' membership at ' . do_shortcode( '[yaymail_site_name]' ) . 'is now active!</p><p>You can view more details about your membership from</p><p><a href=\"' . do_shortcode( '[yaymail_addon_membership_view_url]' ) . '\">your account</a>';

		}
		if ( 'WC_Memberships_User_Membership_Ending_Soon_Email' == $customOrder || 'WC_Memberships_User_Membership_Renewal_Reminder_Email' == $customOrder ) {
			$emailtext = '<p>Hey' . do_shortcode( '[yaymail_addon_memberships_member_name]' ) . '</p><p>Heads up: your ' . do_shortcode( '[yaymail_addon_membership_plan]' ) . ' at ' . do_shortcode( '[yaymail_site_name]' ) . 'is ending soon! Your membership access will stop on ' . do_shortcode( '[yaymail_addon_membership_expiration_date]' ) . '</p><p>If you would like to continue to access members-only content and perks, please renew your membership.</p><p><a href=\"' . do_shortcode( '[yaymail_addon_membership_renewal_url]' ) . '\">Click here to log in and renew your membership now</a>';

		}
		if ( 'WC_Memberships_User_Membership_Ended_Email' == $customOrder ) {
			$emailTitle = 'Renew your ' . do_shortcode( '[yaymail_addon_membership_plan]' );
			$emailtext = '<p>Hey' . do_shortcode( '[yaymail_addon_memberships_member_name]' ) . '</p><p>Oh no, your access to ' . do_shortcode( '[yaymail_addon_membership_plan]' ) . ' at ' . do_shortcode( '[yaymail_site_name]' ) . 'has now ended!</p><p>If you would like to continue to access members-only content and perks, please renew your membership.</p><p><a href=\"' . do_shortcode( '[yaymail_addon_membership_renewal_url]' ) . '\">Click here to log in and renew your membership now</a>';

		}

		if ( 'wc_memberships_for_teams_team_invitation' == $customOrder ) {
			$emailTitle = do_shortcode( '[yaymail_addon_membership_team_sender_name]' ) . ' has invited you to join the ' . do_shortcode( '[yaymail_addon_membership_team_name]' ) . ' team on ' . do_shortcode( '[yaymail_addon_membership_team_site_title]' );
			$emailtext = do_shortcode( '[yaymail_addon_membership_team_invitation]' );
		}

		if ( 'wc_memberships_for_teams_team_membership_renewal_reminder' == $customOrder ) {
			$emailTitle = 'You can renew your ' . do_shortcode( '[yaymail_addon_membership_team_membership_plan]' ) . ' for ' . do_shortcode( '[yaymail_addon_membership_team_name]' );
			$emailtext = do_shortcode( '[yaymail_addon_team_membership_renewal_reminder]' );
		}

		if ( 'wc_memberships_for_teams_team_membership_ending_soon' == $customOrder ) {
			$emailTitle = 'An update about your ' . do_shortcode( '[yaymail_addon_membership_team_membership_plan]' ) . ' for ' . do_shortcode( '[yaymail_addon_membership_team_name]' );
			$emailtext = do_shortcode( '[yaymail_addon_team_membership_ending_soon]' );
		}

		if ( 'wc_memberships_for_teams_team_membership_ended' == $customOrder ) {
			$emailTitle = 'Renew your ' . do_shortcode( '[yaymail_addon_membership_team_membership_plan]' ) . ' for ' . do_shortcode( '[yaymail_addon_membership_team_name]' );
			$emailtext = do_shortcode( '[yaymail_addon_membership_team_membership_ended]' );
		}

		$additionalContent = __( 'Thanks for reading.', 'woocommerce' );

		/*
		@@@ Elements default when reset template.
		@@@ Note 1: Add characters '\' before special characters in a string.
		@@@ example 1: "family": "\'Helvetica Neue\',Helvetica,Roboto,Arial,sans-serif",

		@@@ Note 2: Add characters '\' before special characters in a string.
		@@@ example 2: "<h1 style=\"font-family: \'Helvetica Neue\',...."
		*/

		// Elements
		$elements =
		'[{
			"id": "8ffa62b5-7258-42cc-ba53-7ae69638c1fe",
			"type": "Logo",
			"nameElement": "Logo",
			"settingRow": {
				"backgroundColor": "#ECECEC",
				"align": "center",
				"pathImg": "",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50",
				"width": "172",
				"url": "#"
			}
		}, {
			"id": "802bfe24-7af8-48af-ac5e-6560a81345b3",
			"type": "ElementText",
			"nameElement": "Email Heading",
			"settingRow": {
				"content": "<h1 style=\"font-size: 30px; font-weight: 300; line-height: normal; margin: 0; color: inherit;\">' . $emailTitle . '</h1>",
				"backgroundColor": "#96588A",
				"textColor": "#ffffff",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "36",
				"paddingRight": "40",
				"paddingBottom": "36",
				"paddingLeft": "40"
			}
		}, {
			"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $emailtext . '</span></p>",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "47",
				"paddingRight": "50",
				"paddingBottom": "0",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8d",
			"type": "ElementText",
			"nameElement": "Text",
			"settingRow": {
				"content": "<p><span style=\"font-size: 14px;\">' . $additionalContent . '</span></p>",
				"backgroundColor": "#fff",
				"textColor": "#636363",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "0",
				"paddingRight": "50",
				"paddingBottom": "38",
				"paddingLeft": "50"
			}
		},
		{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8ds",
			"type": "ElementText",
			"nameElement": "Footer",
			"settingRow": {
				"content": "<p style=\"font-size: 14px;margin: 0px 0px 16px; text-align: center;\">[yaymail_site_name]&nbsp;- Built with <a style=\"color: #96588a; font-weight: normal; text-decoration: underline;\" href=\"https://woocommerce.com\" target=\"_blank\" rel=\"noopener\">WooCommerce</a></p>",
				"backgroundColor": "#ececec",
				"textColor": "#8a8a8a",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50"
			}
		}]';

		// Templates Subscription
		$templates = array(
			$customOrder => array(),
		);

		$templates[ $customOrder ]['elements'] = $elements;
		return $templates;
	}
}
