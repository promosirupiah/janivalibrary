<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( isset( $args['subscription'] ) ) {
	$text_link_color           = get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $postID, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
	$order_item_title          = get_post_meta( $postID, '_yaymail_email_order_item_title', true );
	$subscript_subscription    = false != $order_item_title ? $order_item_title['subscript_subscription'] : 'Subscription';
	$subscript_price           = false != $order_item_title ? $order_item_title['subscript_price'] : 'Price';
	$subscript_last_order_date = false != $order_item_title ? $order_item_title['subscript_last_order_date'] : 'Last Order Date';
	$subscript_date_suspended  = false != $order_item_title ? $order_item_title['subscript_date_suspended'] : 'Date Suspended';
	$borderColor               = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
	$textColor                 = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
}
?>

<table
  width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
  cellspacing="0"
  cellpadding="0"
  border="0"
  align="center"
  style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; "
  class="web-main-row"
  id="web<?php echo esc_attr( $id ); ?>"
  >
  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;
		  <?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;
		  <?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>
		  '
		>
		  <div
			style="min-height: 10px; <?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;"
		  >
			<h2 style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;font-size: 18px; font-weight: 700; <?php echo esc_attr( 'color: ' . $attrs['titleColor'] ); ?>'>
				<?php echo esc_html_e( 'Subscription suspended', 'woocommerce-subscriptions' ); ?>
			</h2>
			<!-- Table Subscription Suspended -->
			<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" cellspacing="0" cellpadding="6" border="1" style="width: 100% !important;<?php echo esc_attr( $borderColor ); ?>;color: inherit;flex-direction:inherit;" width="100%">
				<thead>
					<tr style="word-break: normal;<?php echo esc_attr( $textColor ); ?>">
						<th class="td yaymail-title-subscription" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php esc_html_e( $subscript_subscription, 'woocommerce-subscriptions' ); ?></th>
						<th class="td yaymail-title-subscription-price" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php echo esc_html_x( $subscript_price, 'table headings in notification email', 'woocommerce-subscriptions' ); ?></th>
						<th class="td yaymail-title-subscription-last-order-date" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php echo esc_html_x( $subscript_last_order_date, 'table heading', 'woocommerce-subscriptions' ); ?></th>
						<th class="td yaymail-title-subscription-date-suspended" scope="col" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left;<?php echo esc_attr( $borderColor ); ?>;'><?php echo esc_html_x( $subscript_date_suspended, 'table headings in notification email', 'woocommerce-subscriptions' ); ?></th>
					</tr>
				</thead>

				<tbody style="flex-direction:inherit;">
					<tr class="order_item" style="flex-direction:inherit;<?php echo esc_attr( $textColor ); ?>">
						<td class="td" width="1%" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( $borderColor ); ?>;'>
							<a style="color:<?php echo esc_attr( $text_link_color ); ?>" href="<?php echo esc_url( wcs_get_edit_post_link( $subscription->get_id() ) ); ?>">#<?php echo esc_html( $subscription->get_order_number() ); ?></a>
						</td>
						<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( $borderColor ); ?>;'>
							<?php echo wp_kses_post( $subscription->get_formatted_order_total() ); ?>
						</td>
						<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( $borderColor ); ?>;'>
							<?php
							$last_order_time_created = $subscription->get_time( 'last_order_date_created', 'site' );
							if ( ! empty( $last_order_time_created ) ) {
								echo esc_html( date_i18n( wc_date_format(), $last_order_time_created ) );
							} else {
								esc_html_e( '-', 'yaymail' );
							}
							?>
						</td>
						<td class="td" style='<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;text-align:left; vertical-align:middle;<?php echo esc_attr( $borderColor ); ?>;'>
							<?php echo esc_html( date_i18n( wc_date_format(), time() ) ); ?>
						</td>
					</tr>
				</tbody>
			</table>

			<!-- Table Subscription Suspended -->
		  </div>
		</td>
	  </tr>
	</tbody>
  </table>
