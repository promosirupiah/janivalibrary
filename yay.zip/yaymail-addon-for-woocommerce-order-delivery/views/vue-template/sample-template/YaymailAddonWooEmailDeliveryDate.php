<?php
	$yaymail_settings   = get_option( 'yaymail_settings' );
	$orderImagePostions = isset( $yaymail_settings['image_position'] ) && ! empty( $yaymail_settings['image_position'] ) ? $yaymail_settings['image_position'] : 'Top';
	$orderImage         = isset( $yaymail_settings['product_image'] ) && '0' != $yaymail_settings['product_image'] ? $yaymail_settings['product_image'] : '0';
	$image_width        = isset( $yaymail_settings['image_width'] ) ? $yaymail_settings['image_width'] : 32;
	$image_height       = isset( $yaymail_settings['image_height'] ) ? $yaymail_settings['image_height'] : 32;
	$image_size         = isset( $yaymail_settings['image_size'] ) ? $yaymail_settings['image_size'] : 'thumbnail';
	$wc_format_datetime = wc_format_datetime( new WC_DateTime() );
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row"
	:id="'web' + emailContent.id"
  >
	  <tbody>
		<tr>
			<td
			:id="'web-' + emailContent.id + '-order-item'"
			class="web-order-item"
			align="left"
			style="font-size: 13px; line-height: 22px; word-break: break-word;"
			:style="{
				fontFamily: emailContent.settingRow.family,
				paddingTop: emailContent.settingRow.paddingTop + 'px',
				paddingBottom: emailContent.settingRow.paddingBottom + 'px',
				paddingRight: emailContent.settingRow.paddingRight + 'px',
				paddingLeft: emailContent.settingRow.paddingLeft + 'px'
			}"
			>
				<div
				class="yaymail-items-order-border"
					style="min-height: 10px"
					:style="{
					color: emailContent.settingRow.textColor,
					borderColor: emailContent.settingRow.borderColor,
					}"
				>
					<h2 class="yaymail_builder_order" style="font-size: 18px; font-weight: 700;" :style="{color: emailContent.settingRow.titleColor}">
						<?php echo __( 'Delivery details', 'woocommerce-order-delivery' ); ?>
					</h2>
					<div>
						<p>
						<?php
							/* translators: %s: delivery date */
							printf( wp_kses_post( __( 'We will try our best to deliver your order on %s.', 'woocommerce-order-delivery' ) ), "<strong>{$wc_format_datetime}</strong>" ); // WPCS: XSS ok.
						?>
						</p>
					</div>
				</div>
			</td>
		</tr>
	</tbody>
</table>