<?php

namespace YayMailYITHBooking\Core;

defined( 'ABSPATH' ) || exit;

use YayMailYITHBooking\TemplateDefault\DefaultBooking;

class YayMailAddonController {
	protected static $instance = null;
	private $template_email_id = null;

	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
			self::$instance->do_hooks();
		}

		return self::$instance;
	}

	private function do_hooks() {
		$this->template_email_id = array(
			'yith_wcbk_admin_new_booking',
			'yith_wcbk_booking_status',
			'yith_wcbk_customer_booking_note',
			'yith_wcbk_customer_cancelled_booking',
			'yith_wcbk_customer_completed_booking',
			'yith_wcbk_customer_confirmed_booking',
			'yith_wcbk_customer_new_booking',
			'yith_wcbk_customer_paid_booking',
			'yith_wcbk_customer_unconfirmed_booking',
			'yith_wcbk_booking_status_vendor',
		);

		YayMailAddonElementRender::get_instance( $this->template_email_id );
		add_filter( 'yaymail_addon_get_updated_elements', array( $this, 'yaymail_addon_get_updated_elements' ), 10, 1 );
		add_filter( 'YaymailNewTempalteDefault', array( $this, 'yaymail_new_template_default' ), 100, 3 );
		add_filter( 'yaymail_addon_defined_shorcode', array( $this, 'yaymail_addon_defined_shorcode' ) );
		add_filter( 'yaymail_addon_defined_template', array( $this, 'yaymail_addon_defined_template' ), 100, 2 );
	}

	public function yaymail_addon_defined_template( $result, $template ) {
		$template_email_id = $this->template_email_id;
		if ( in_array( $template, $template_email_id ) ) {
			return true;
		}
		return $result;
	}

	/*
	Action to defined shortcode
	$arr_data[0] : $custom_shortcode
	$arr_data[1] : $args
	$arr_data[2] : $templateName
	*/
	public function yaymail_addon_defined_shorcode( $arr_data ) {
		$template_email_id = $this->template_email_id;
		if ( in_array( $arr_data[2], $template_email_id ) ) {
			$arr_data[0]->setOrderId( isset( $arr_data[1]['booking']->get_data()['order_id'] ) ? $arr_data[1]['booking']->get_data()['order_id'] : 0, $arr_data[1]['sent_to_admin'], $arr_data[1] );
			$arr_data[0]->shortCodesOrderDefined( $arr_data[1]['sent_to_admin'], $arr_data[1] );
		}
	}

	public function yaymail_new_template_default( $array, $key, $value ) {
		$get_heading = isset( $value->heading ) ? $value->heading : '';
		if ( 'YITH_WCBK_Email_Admin_New_Booking' == $key
		|| 'YITH_WCBK_Email_Booking_Status' == $key
		|| 'YITH_WCBK_Email_Customer_Booking_Note' == $key
		|| 'YITH_WCBK_Email_Customer_Cancelled_Booking' == $key
		|| 'YITH_WCBK_Email_Customer_Completed_Booking' == $key
		|| 'YITH_WCBK_Email_Customer_Confirmed_Booking' == $key
		|| 'YITH_WCBK_Email_Customer_New_Booking' == $key
		|| 'YITH_WCBK_Email_Customer_Paid_Booking' == $key
		|| 'YITH_WCBK_Email_Customer_Unconfirmed_Booking' == $key
		|| 'YITH_WCBK_Email_Booking_Status_Vendor' == $key
		|| 'YITH_WCBK_Email_Vendor_New_Booking' == $key
		) {
			$default_booking                        = DefaultBooking::get_templates( $value->id, $get_heading );
			$default_booking[ $value->id ]['title'] = __( $value->title, 'woocommerce' );
			return $default_booking;
		}
		return $array;
	}

	public static function yaymail_addon_get_updated_elements( $element ) {
		$result = array_merge( $element, array() );
		return $result;
	}
}
