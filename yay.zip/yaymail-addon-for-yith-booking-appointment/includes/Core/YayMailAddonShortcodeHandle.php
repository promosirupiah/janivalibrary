<?php

namespace YayMailYITHBooking\Core;

defined( 'ABSPATH' ) || exit;

use ReflectionObject;
use YayMailYITHBooking\Helper\YayMailAddonShortcodeTemplateRenderer;

class YayMailAddonShortcodeHandle {
	protected static $instance = null;

	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
			self::$instance->do_hooks();
		}

		return self::$instance;
	}

	private function do_hooks() {
		add_filter( 'yaymail_shortcodes', array( $this, 'yaymail_shortcodes' ), 10, 1 );
		add_filter( 'yaymail_do_shortcode', array( $this, 'yaymail_do_shortcode' ), 10, 3 );
		add_filter( 'yaymail_list_shortcodes', array( $this, 'yaymail_list_shortcodes' ), 10, 1 );
	}

	public function yaymail_shortcodes( $shortcode_list ) {
		if ( class_exists( 'YITH_WCBK' ) ) {
			$shortcode_list[] = 'yaymail_addon_yith_booking_link_id';
			$shortcode_list[] = 'yaymail_addon_yith_booking_name';
			$shortcode_list[] = 'yaymail_addon_yith_booking_customer_name';
			$shortcode_list[] = 'yaymail_addon_yith_view_booking_product_url';
			$shortcode_list[] = 'yaymail_addon_yith_edit_booking_product_url';
			$shortcode_list[] = 'yaymail_addon_yith_booking_url';
			$shortcode_list[] = 'yaymail_addon_yith_booking_status';
			$shortcode_list[] = 'yaymail_addon_yith_booking_action';
			$shortcode_list[] = 'yaymail_addon_yith_booking_customer_note';
			$shortcode_list[] = 'yaymail_addon_yith_booking_view_order_url';
			$shortcode_list[] = 'yaymail_addon_yith_booking_edit_order_url';

			// links
			$shortcode_list[] = 'yaymail_addon_yith_booking_link_tag';
			$shortcode_list[] = 'yaymail_addon_yith_booking_product_link_tag';

		}
		return $shortcode_list;
	}

	public function yaymail_do_shortcode( $shortcode_list, $yaymail_informations, $args = array() ) {
		if ( class_exists( 'YITH_WCBK' ) ) {

			$shortcode_list['[yaymail_addon_yith_booking_link_id]'] = $this->yaymail_addon_yith_booking_link_id( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_name]'] = $this->yaymail_addon_yith_booking_name( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_customer_name]'] = $this->yaymail_addon_yith_booking_customer_name( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_view_booking_product_url]'] = $this->yaymail_addon_yith_view_booking_product_url( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_edit_booking_product_url]'] = $this->yaymail_addon_yith_edit_booking_product_url( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_url]'] = $this->yaymail_addon_yith_booking_url( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_status]'] =
			$this->yaymail_addon_yith_booking_status( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_action]'] = $this->yaymail_addon_yith_booking_action( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_customer_note]'] = $this->yaymail_addon_yith_booking_customer_note( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_view_order_url]'] = $this->yaymail_addon_yith_booking_view_order_url( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_edit_order_url]'] = $this->yaymail_addon_yith_booking_edit_order_url( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_link_tag]'] = $this->yaymail_addon_yith_booking_link_tag( $yaymail_informations, $args );

			$shortcode_list['[yaymail_addon_yith_booking_product_link_tag]'] = $this->yaymail_addon_yith_booking_product_link_tag( $yaymail_informations, $args );
		}
		return $shortcode_list;
	}

	public function yaymail_list_shortcodes( $shortcode_list ) {
		$shortcode_list[] = array(
			'plugin'    => 'YayMail YITH Booking',
			'shortcode' => array(
				array( '[yaymail_addon_yith_booking_link_id]', 'YITH Booking ID' ),
				array( '[yaymail_addon_yith_booking_name]', 'YITH Booking Name' ),
				array( '[yaymail_addon_yith_booking_customer_name]', 'YITH Booking Customer Name' ),
				array( '[yaymail_addon_yith_view_booking_product_url]', 'YITH View Booking Product URL' ),
				array( '[yaymail_addon_yith_edit_booking_product_url]', 'YITH Edit Booking Product URL' ),
				array( '[yaymail_addon_yith_booking_url]', 'YITH Booking URL' ),
				array( '[yaymail_addon_yith_booking_status]', 'YITH Booking Status' ),
				array( '[yaymail_addon_yith_booking_action]', 'YITH Booking Action' ),
				array( '[yaymail_addon_yith_booking_customer_note]', 'YITH Booking Customer Note' ),
				array( '[yaymail_addon_yith_booking_view_order_url]', 'YITH Booking View Order URL' ),
				array( '[yaymail_addon_yith_booking_edit_order_url]', 'YITH Booking Edit Order URL' ),
				array( '[yaymail_addon_yith_booking_link_tag]', 'YITH Booking Link' ),
				array( '[yaymail_addon_yith_booking_product_link_tag]', 'YITH Booking Product Link' ),
			),
		);

		return $shortcode_list;
	}

	public function yaymail_addon_yith_booking_link_id( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_id' )
			) {
			// Case: Real emails

			$booking_id = $args['booking']->get_id();

			if ( ! empty( $booking_id ) ) {
				$text_link_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
				$link     = isset( $args['sent_to_admin'] ) && $args['sent_to_admin'] ? get_edit_post_link( $booking_id ) : $args['booking']->get_view_booking_url();
				$booking_link = sprintf(
					' <a style="color: %s" href="%s">#%s</a>',
					esc_attr( $text_link_color ),
					esc_url( $link ),
					esc_html( $booking_id )
				);
				return $booking_link;
			}
		}

		// Case: Preview
		return '1';
	}

	public function yaymail_addon_yith_booking_name( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_raw_title' )
			) {
			// Case: Real emails

			$booking_name = $args['booking']->get_raw_title();

			if ( ! empty( $booking_name ) ) {
				return $booking_name;
			}
		}

		// Case: Preview
		return 'YayMail';
	}

	public function yaymail_addon_yith_booking_customer_name( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_order' )
			) {
			// Case: Real emails

			$order = $args['booking']->get_order();

			if ( ! isset( $order )
				|| ! method_exists( $order, 'get_billing_first_name' )
				|| ! method_exists( $order, 'get_billing_last_name' )
			) {
				return 'YayMail';
			}

			$customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

			if ( ! empty( $customer_name ) ) {
				return $customer_name;
			}
		}

		// Case: Preview
		return 'YayMail';
	}

	public function yaymail_addon_yith_view_booking_product_url( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_product' )
			) {
			// Case: Real emails
			$booking_product = $args['booking']->get_product();

			if ( empty( $booking_product )
				|| ! method_exists( $booking_product, 'get_permalink_with_data' ) ) {
				return;
			}

			$view_booking_url = $booking_product->get_permalink_with_data();

			if ( ! empty( $view_booking_url ) ) {
				return $view_booking_url;
			}
		}

		// Case: Preview
		return 'https://yaycommerce.com/';
	}

	public function yaymail_addon_yith_edit_booking_product_url( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_edit_url' )
			) {
			// Case: Real emails
			$post_edit_url = $args['booking']->get_edit_url();

			if ( ! empty( $post_edit_url ) ) {
				return $post_edit_url;
			}
		}

		// Case: Preview
		return 'https://yaycommerce.com/';
	}

	public function yaymail_addon_yith_booking_url( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_view_booking_url' )
			) {
			// Case: Real emails
			$view_booking_url = $args['booking']->get_view_booking_url();

			if ( ! empty( $view_booking_url ) ) {
				return $view_booking_url;
			}
		}

		// Case: Preview
		return 'https://yaycommerce.com/';
	}

	public function yaymail_addon_yith_booking_customer_note( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['email'] ) ) {
			// Case: Real emails
			$email_data     = $args['email'];
			$reflection_obj = new ReflectionObject( $email_data );
			$placeholders   = $reflection_obj->getProperty( 'placeholders' );
			$placeholders->setAccessible( true );

			if ( isset( $placeholders->getValue( $email_data )['{note}'] ) ) {
				$note_html = $placeholders->getValue( $email_data )['{note}'];
				// return strip_tags( $note_html );
				return $note_html;
			}
		}

		// Case: Preview
		return 'Customer note';
	}

	public function yaymail_addon_yith_booking_status( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_status' )
			) {
			// Case: Real emails
			$booking_status = $args['booking']->get_status();

			if ( ! empty( $booking_status ) ) {
				return ucfirst( $booking_status );
			}
		}

		// Case: Preview
		return 'Unpaid';
	}

	public function yaymail_addon_yith_booking_action( $yaymail_informations, $args ) {
		if ( isset( $args['booking'] ) ) {
			$booking       = $args['booking'];
			$sent_to_admin = isset( $args['sent_to_admin'] ) ? $args['sent_to_admin'] : false;
			$plain_text    = isset( $args['plain_text'] ) ? $args['plain_text'] : '';
			$email         = isset( $args['email'] ) ? $args['email'] : '';
			// if ( 'yith_wcbk_customer_confirmed_booking' === $args['email']->id ) {
			// 	$actions_to_show = array( 'pay', 'view' );

			// } else {
			// 	$actions_to_show = $booking->has_status( 'pending-confirm' ) ? array( 'confirm', 'unconfirm' ) : array();
			// }
			// if ( ! $actions_to_show ) {
			// 	return;
			// }

			$actions_to_show = array( 'pay', 'view' );

			$booking_edit_uri = admin_url( 'post.php?post=' . $booking->get_id() . '&action=edit' );
			$booking_actions  = apply_filters(
				'yith_wcbk_booking_actions_for_emails',
				array(
					'pay'       => array(
						'url'  => $booking->get_confirmed_booking_payment_url(),
						'name' => __( 'Pay booking', 'yith-booking-for-woocommerce' ),
					),
					'view'      => array(
						'url'  => $booking->get_view_booking_url(),
						'name' => __( 'View booking', 'yith-booking-for-woocommerce' ),
					),
					'cancel'    => array(
						'url'  => $booking->get_cancel_booking_url(),
						'name' => __( 'Cancel', 'yith-booking-for-woocommerce' ),
					),
					'confirm'   => array(
						'url'  => $booking->get_mark_action_url( 'confirmed', array( '_wp_http_referer' => urlencode( $booking_edit_uri ) ) ),
						'name' => __( 'Confirm booking', 'yith-booking-for-woocommerce' ),
					),
					'unconfirm' => array(
						'url'  => $booking->get_mark_action_url( 'unconfirmed', array( '_wp_http_referer' => urlencode( $booking_edit_uri ) ) ),
						'name' => __( 'Reject booking', 'yith-booking-for-woocommerce' ),
					),
				),
				$booking,
				$sent_to_admin,
				$plain_text,
				$email,
				$actions_to_show
			);

			$actions = array();
			foreach ( $booking_actions as $key => $value ) {
				if ( in_array( $key, $actions_to_show ) ) {
					$actions[ $key ] = $value;
				}
			}
			if ( isset( $actions['pay'] ) && ! $booking->has_status( 'confirmed' ) ) {
				unset( $actions['pay'] );
			}

			if ( isset( $actions['cancel'] ) && ! $booking->can_be( 'cancelled_by_user' ) ) {
				unset( $actions['cancel'] );
			}

			ob_start();
			include YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH . 'views/Shortcode/RealOrder/yaymail_addon_yith_booking_action.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		} else {
			ob_start();
			include YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH . 'views/Shortcode/SampleOrder/yaymail_addon_yith_booking_action.php';
			$html = ob_get_contents();
			ob_end_clean();
			return $html;
		}
	}

	public function yaymail_addon_yith_booking_view_order_url( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_order' )
			) {
			// Case: Real emails
			$order = $args['booking']->get_order();

			if ( isset( $order ) ) {
				$view_order_url = $order->get_view_order_url();

				return $view_order_url;
			}
		}

		// Case: Preview
		return 'https://yaycommerce.com';
	}

	public function yaymail_addon_yith_booking_edit_order_url( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_order' )
			) {
			// Case: Real emails
			$order = $args['booking']->get_order();

			if ( isset( $order ) ) {
				$edit_order_url = $order->get_edit_order_url();

				return $edit_order_url;
			}
		}

		// Case: Preview
		return 'https://yaycommerce.com';
	}

	public function yaymail_addon_yith_booking_link_tag( $yaymail_informations, $args ) {
		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		$link_text_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true );

		$link_text_color = $link_text_color ? $link_text_color : '#7f54b3';

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_id' )
			&& method_exists( $args['booking'], 'get_view_booking_url' )
			) {
			// Case: Real emails
			$booking_id       = $args['booking']->get_id();
			$view_booking_url = $args['booking']->get_view_booking_url();

			if ( isset( $booking_id, $view_booking_url ) ) {
				return $this->generate_link( '#' . $booking_id, $view_booking_url, $link_text_color );
			}
		}

		// Case: Preview
		return $this->generate_link( '#1', 'https://yaycommerce.com', $link_text_color );
	}

	public function yaymail_addon_yith_booking_product_link_tag( $yaymail_informations, $args ) {

		if ( ! class_exists( 'YITH_WCBK' ) ) {
			return;
		}

		$link_text_color = get_post_meta( $yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true );

		$link_text_color = $link_text_color ? $link_text_color : '#7f54b3';

		if ( isset( $args['booking'] )
			&& method_exists( $args['booking'], 'get_raw_title' )
			&& method_exists( $args['booking'], 'get_view_booking_url' )
			) {
			// Case: Real emails
			$booking_product_name = $args['booking']->get_raw_title();

			$booking_product = $args['booking']->get_product();
			if ( empty( $booking_product )
				|| ! method_exists( $booking_product, 'get_permalink_with_data' ) ) {
				return;
			}

			$view_booking_url = $booking_product->get_permalink_with_data();

			if ( isset( $booking_product_name, $view_booking_url ) ) {
				return $this->generate_link( $booking_product_name, $view_booking_url, $link_text_color );
			}
		}

		// Case: Preview
		return $this->generate_link( 'YayMail', 'https://yaycommerce.com', $link_text_color );
	}

	/**
	 * Generates an HTML anchor tag.
	 *
	 * @param string $title The text to be displayed as the link's anchor text.
	 * @param string $url   The URL to which the link will point.
	 * @param optional string $color The color of the link (CSS value).
	 * @return string       The generated HTML anchor tag.
	 */
	private function generate_link( $title, $url, $color = 'initial' ) {
		$link = '<a href="' . esc_url( $url ) . '" target="_blank" style="color: ' . esc_attr( $color ) . ';">' . esc_html( $title ) . '</a>';
		return $link;
	}

}
