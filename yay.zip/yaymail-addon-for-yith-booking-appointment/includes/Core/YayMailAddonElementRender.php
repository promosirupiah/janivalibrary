<?php

namespace YayMailYITHBooking\Core;

defined( 'ABSPATH' ) || exit;

use YayMail\Helper\Helper;

class YayMailAddonElementRender {
	protected static $instance = null;
	private $template_email_id = null;
	public static function get_instance( $template_email_id ) {
		if ( null == self::$instance ) {
			self::$instance = new self();
			self::$instance->do_hooks( $template_email_id );
		}

		return self::$instance;
	}

	private function do_hooks( $template_email_id ) {
		$this->template_email_id = $template_email_id;
		add_filter( 'yaymail_plugins', array( $this, 'yaymail_plugins' ), 10, 1 );
		add_filter( 'yaymail_addon_templates', array( $this, 'yaymail_addon_templates' ), 100, 3 );
		$this->do_hook_vue_render();
		$this->do_hook_element_render();
	}

	public function yaymail_plugins( $plugins ) {
		$plugins[] = array(
			'plugin_name'      => YAYMAIL_ADDON_YITH_BOOKING,
			'addon_components' => array(
				'YITHBooking',
			),
			'template_name'    => $this->template_email_id,
		);
		return $plugins;
	}

	// Filter to add template to Vuex
	public static function yaymail_addon_templates( $addon_templates, $order, $post_id ) {
		$components = apply_filters( 'yaymail_plugins', array() );
		$position   = '';
		foreach ( $components as $key => $component ) {
			if ( $component['plugin_name'] === YAYMAIL_ADDON_YITH_BOOKING ) {
				$position = $key;
				break;
			}
		}
		foreach ( $components[ $position ]['addon_components'] as $key => $component ) {
			ob_start();
			do_action( 'YaymailAddon' . $component . 'Vue', $order, $post_id );
			$html = ob_get_contents();
			ob_end_clean();
			$addon_templates[ YAYMAIL_ADDON_YITH_BOOKING ] = array_merge( isset( $addon_templates[ YAYMAIL_ADDON_YITH_BOOKING ] ) ? $addon_templates[ YAYMAIL_ADDON_YITH_BOOKING ] : array(), array( $component . 'Vue' => $html ) );
		}
		return $addon_templates;
	}

	// Create HTML with Vue syntax to display in Vue
	// CHANGE HERE => Name of action follow : YaymailAddon + main-name + Vue
	// CHANGE SOURCE VUE TOO
	// TODO Change this
	private function do_hook_vue_render() {
		add_action( 'YaymailAddonYITHBookingVue', array( $this, 'yith_booking_information_vue' ), 100, 2 );
	}

	// Create HTML to display when send mail
	// CHANGE HERE => Name of action follow: YaymailAddon + main-name
	private function do_hook_element_render() {
		add_action( 'YaymailAddonYITHBooking', array( $this, 'yith_booking_information' ), 100, 5 );
	}

	//-------------- Vue Element Render -----------//

	public function yith_booking_information_vue( $order, $post_id = '' ) {
		if ( class_exists( 'YITH_WCBK' ) ) {
			if ( '' === $order ) {
				ob_start();
				include YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH . '/views/VueTemplate/SampleOrder/yaymail_addon_yith_booking.php';
				$html = ob_get_contents();
				ob_end_clean();
			} else {
				$bookings = YITH_WCBK()->booking_helper->get_bookings_by_order( $order->get_id() );
				ob_start();

				include YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH . '/views/VueTemplate/RealOrder/yaymail_addon_yith_booking.php';
				$html = ob_get_contents();
				ob_end_clean();
				if ( '' === $html ) {
					$html = '<div></div>';
				}
			}
			$html              = Helper::replaceCustomAllowedHTMLTags( $html );
			$allowed_html_tags = Helper::customAllowedHTMLTags( array( 'yaymail-style' => true ) );
			echo wp_kses( $html, $allowed_html_tags );
		}
	}

	//-------------- Element Render -----------//

	public function yith_booking_information( $args = array(), $attrs = array(), $general_attrs = array(), $id = '', $post_id = '' ) {
		if ( class_exists( 'YITH_WCBK' ) ) {
			$show_link = true;
			if ( isset( $args['booking'] ) && isset( $args['email'] ) ) {
				$booking    = $args['booking'];
				$plain_text = isset( $args['plain_text'] ) ? $args['plain_text'] : '';
				$email      = $args['email'];
				ob_start();
				include YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH . '/views/Template/RealOrder/yaymail_addon_yith_booking.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				$allowed_html_tags          = wp_kses_allowed_html( 'post' );
				$allowed_html_tags['style'] = array();
				echo wp_kses( $html, $allowed_html_tags );
			} elseif ( isset( $args['order'] ) && 'SampleOrder' == $args['order'] ) {
				ob_start();
				include YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH . '/views/Template/SampleOrder/yaymail_addon_yith_booking.php';
				$html = ob_get_contents();
				ob_end_clean();
				$html = do_shortcode( $html );
				echo wp_kses_post( $html );
			} else {
				echo wp_kses_post( '' );
			}
		}
	}
}
