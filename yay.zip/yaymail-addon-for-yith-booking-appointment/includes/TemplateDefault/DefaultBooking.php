<?php

namespace YayMailYITHBooking\TemplateDefault;

defined( 'ABSPATH' ) || exit;

class DefaultBooking {

	protected static $instance = null;

	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function get_templates( $custom_order, $email_heading ) {
		/*
		@@@ Html default send email.
		@@@ Note: Add characters '\' before special characters in a string.
		@@@ Example: font-family: \'Helvetica Neue\'...
		*/

		$email_title   = __( 'New Booking', 'yith-booking-for-woocommerce' );
		$customer_name = do_shortcode( '[yaymail_addon_yith_booking_customer_name]' );
		switch ( $custom_order ) {
			case 'yith_wcbk_admin_new_booking':
			case 'yith_wcbk_vendor_new_booking':
				$email_text  = esc_html( 'Hi Admin' );
				$email_text .= '<br/>';
				$email_text .= esc_html( 'Greate news! There is a new booking for the item "' . do_shortcode( '[yaymail_addon_yith_booking_product_link_tag]' ) . '"' );
				break;

			case 'yith_wcbk_customer_new_booking':
				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html(
					'Greate news! Your booking ' . do_shortcode( '[yaymail_addon_yith_booking_link_tag]' ) . ' has been created and it\'s now '
				);
				$email_text .= '<strong>' . do_shortcode( '[yaymail_addon_yith_booking_status]' ) . '</strong>';

				break;

			case 'yith_wcbk_customer_paid_booking':
				$email_title = __( 'Paid Booking', 'yith-booking-for-woocommerce' );

				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html( 'Your booking ' . do_shortcode( '[yaymail_addon_yith_booking_link_tag]' ) ) . esc_html__( ' is now paid!', 'yith-booking-for-woocommerce' );
				break;

			case 'yith_wcbk_customer_completed_booking':
				$email_title = __( 'Thanks for your Booking', 'yith-booking-for-woocommerce' );

				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html( 'Your booking ' . do_shortcode( '[yaymail_addon_yith_booking_link_tag]' ) ) . esc_html__( ' was completed!', 'yith-booking-for-woocommerce' );
				break;

			case 'yith_wcbk_customer_cancelled_booking':
				$email_title = __( 'Cancelled Booking', 'yith-booking-for-woocommerce' );
				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html( 'Your booking ' . do_shortcode( '[yaymail_addon_yith_booking_link_tag]' ) . ' was cancelled!' );
				break;

			case 'yith_wcbk_customer_unconfirmed_booking':
				$email_title = __( 'Rejected booking', 'yith-booking-for-woocommerce' );
				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html( 'Your booking ' . do_shortcode( '[yaymail_addon_yith_booking_link_tag]' ) . ' was rejected!' );
				break;

			case 'yith_wcbk_customer_booking_note':
				$email_title = __( 'A note has been added to your Booking #', 'yith-booking-for-woocommerce' ) . esc_html( do_shortcode( '[yaymail_addon_yith_booking_id]' ) );

				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html__( 'a note has just been added to your booking ', 'yith-booking-for-woocommerce' ) . esc_html( do_shortcode( '[yaymail_addon_yith_booking_link_tag]' ) ) . ':';
				$email_text .= '<br/>';

				break;

			case 'yith_wcbk_customer_confirmed_booking':
				$email_title = __( 'Confirmed Booking', 'yith-booking-for-woocommerce' );

				$email_text  = esc_html( 'Hi ' . $customer_name . ',' );
				$email_text .= '<br/>';
				$email_text .= esc_html( 'Your booking ' . do_shortcode( '[yaymail_addon_yith_booking_product_link_tag]' ) . ' was confirmed!' );

				break;

			case 'yith_wcbk_booking_status':
			case 'yith_wcbk_booking_status_vendor':
				$email_title = __( 'Booking status changed', 'yith-booking-for-woocommerce' );
				$email_text  = esc_html( 'The booking' . do_shortcode( '[yaymail_addon_yith_booking_link_id]' ) ) . esc_html__( ' status changed to ', 'yith-booking-for-woocommerce' ) . esc_html( do_shortcode( '[yaymail_addon_yith_booking_status]' ) );
				break;
		}

		$email_text_note = esc_html__( 'For your reference, your booking details are shown below.', 'yith-booking-for-woocommerce' );
		/*
		@@@ Elements default when reset template.
		@@@ Note 1: Add characters '\' before special characters in a string.
		@@@ example 1: "family": "\'Helvetica Neue\',Helvetica,Roboto,Arial,sans-serif",

		@@@ Note 2: Add characters '\' before special characters in a string.
		@@@ example 2: "<h1 style=\"font-family: \'Helvetica Neue\',...."
		*/

		$elements =
		'[{
			"id": "802bfe24-7af8-48af-ac5e-6560a81345b3",
			"type": "ElementText",
			"nameElement": "Email Heading",
			"settingRow": {
				"content": "<h1 style=\"font-size: 30px; font-weight: 300; line-height: normal; margin: 0; color: inherit;\">' . $email_title . '</h1>",
				"backgroundColor": "#7f54b3",
				"textColor": "#ffffff",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "36",
				"paddingRight": "48",
				"paddingBottom": "36",
				"paddingLeft": "48"
			}
		},';
		if ( 'yith_wcbk_admin_new_booking' == $custom_order || 'yith_wcbk_customer_new_booking' == $custom_order || 'yith_wcbk_vendor_new_booking' == $custom_order ) {
			$elements .= '{
				"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $email_text . '</span></p>",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "47",
					"paddingRight": "50",
					"paddingBottom": "0",
					"paddingLeft": "50"
				}
			},';
		} elseif ( 'yith_wcbk_customer_paid_booking' == $custom_order || 'yith_wcbk_customer_completed_booking' == $custom_order || 'yith_wcbk_customer_cancelled_booking' == $custom_order || 'yith_wcbk_customer_unconfirmed_booking' == $custom_order || 'yith_wcbk_customer_confirmed_booking' == $custom_order || 'yith_wcbk_booking_status' == $custom_order || 'yith_wcbk_booking_status_vendor' == $custom_order ) {
			$elements .= '{
				"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $email_text . '</span></p>",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "47",
					"paddingRight": "50",
					"paddingBottom": "0",
					"paddingLeft": "50"
				}
			},';
		} elseif ( 'yith_wcbk_customer_booking_note' == $custom_order ) {
			$elements .= '{
				"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $email_text . '</span></p>\n [yaymail_addon_yith_booking_customer_note]\n<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $email_text_note . '</span></p>",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "47",
					"paddingRight": "50",
					"paddingBottom": "0",
					"paddingLeft": "50"
				}
			},';
		} else {
			$elements .= '{
				"id": "b035d1f1-0cfe-41c5-b79c-0478f144ef5f",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "<p style=\"margin: 0px;\"><span style=\"font-size: 14px;\">' . $email_text . '<strong>[yaymail_addon_yith_booking_status]</strong></span></p>",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "47",
					"paddingRight": "50",
					"paddingBottom": "0",
					"paddingLeft": "50"
				}
			},';
		}
		$elements .= '{
			"id": "yi422370-f762-4a26-92de-c4cf3878h0oi",
			"type": "AddonYITHBooking",
			"nameElement": "YITH Booking",
			"settingRow": {
				"backgroundColor": "#FFF",
				"dataTableBackgroundColor": "#F5F5F5",
				"borderColor": "transparent",
				"content": "This is content",
				"contentTitle": "YITH Booking and ",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingBottom": "15",
				"paddingLeft": "50",
				"paddingRight": "50",
				"paddingTop": "15",
				"textColor": "#636363",
				"titleBookingId": "Booking ID",
				"titleColor": "#96588a",
				"titleProduct": "Product",
				"titleOrder": "Order",
				"titleStatus": "Status",
				"titleDuration": "Duration",
				"titleFrom": "From",
				"titleTo": "To",
				"titlePeople": "People",
				"statusBackground": "#E9E9E9",
				"statusUnpaidColor": "#979797",
				"statusPaidColor": "#a5b200",
				"statusConfirmedColor": "#0083aa",
				"statusRejectedColor": "#920000",
				"statusCancelledColor": "#d62800",
				"statusCompletedColor": "#474747"
			}
		},';

		$elements .= '{
			"id": "b035d1f1-0cfe-41c5-b79c-0478f144efsczaiusdyausidya",
				"type": "ElementText",
				"nameElement": "Text",
				"settingRow": {
					"content": "Regards,<br/>' . get_bloginfo( 'name' ) . ' Staff",
					"backgroundColor": "#fff",
					"textColor": "#636363",
					"family": "Helvetica,Roboto,Arial,sans-serif",
					"paddingTop": "10",
					"paddingRight": "50",
					"paddingBottom": "30",
					"paddingLeft": "50"
				}
		},';

		$elements .= '{
			"id": "b39bf2e6-8c1a-4384-a5ec-37663da27c8ds",
			"type": "ElementText",
			"nameElement": "Footer",
			"settingRow": {
				"content": "<p style=\"font-size: 14px;margin: 0px 0px 16px; text-align: center;\">[yaymail_site_name]&nbsp;- Built with <a style=\"color: #7f54b3; font-weight: normal; text-decoration: underline;\" href=\"https://yith-booking-for-woocommerce.com\" target=\"_blank\" rel=\"noopener\">WooCommerce</a></p>",
				"backgroundColor": "#ececec",
				"textColor": "#8a8a8a",
				"family": "Helvetica,Roboto,Arial,sans-serif",
				"paddingTop": "15",
				"paddingRight": "50",
				"paddingBottom": "15",
				"paddingLeft": "50"
			}
		}]';

		// Templates Subscription
		$templates                              = array(
			$custom_order => array(),
		);
		$templates[ $custom_order ]['elements'] = $elements;
		return $templates;
	}
}
