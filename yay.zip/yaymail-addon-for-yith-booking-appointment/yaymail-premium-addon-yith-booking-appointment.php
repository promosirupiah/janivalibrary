<?php
/**
 * Plugin Name: YayMail Addon for YITH Booking and Appointment for WooCommerce Premium
 * Plugin URI: https://yaycommerce.com/yaymail-woocommerce-email-customizer/
 * Description: Customize templates for YITH Booking and Appointment for WooCommerce Premium plugin
 * Version: 2.0
 * Author: YayCommerce
 * Author URI: https://yaycommerce.com
 * Text Domain: yaymail
 * WC requires at least: 3.0.0
 * WC tested up to: 7.9.0
 * Domain Path: /i18n/languages/
 */

namespace YayMailYITHBooking;

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_NAME' ) ) {
	define( 'YAYMAIL_ADDON_YITH_BOOKING_NAME', 'YITH Booking and Appointment for WooCommerce Premium' );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING' ) ) {
	define( 'YAYMAIL_ADDON_YITH_BOOKING', 'yith_booking' );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH' ) ) {
	define( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_BASENAME' ) ) {
	define( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_DATA' ) ) {
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	define( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_DATA', get_plugin_data( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_LINK_URL' ) ) {
	// TODO Change this url
	define( 'YAYMAIL_ADDON_YITH_BOOKING_LINK_URL', 'https://yaycommerce.com/yaymail-addons/yaymail-premium-addon-for-woocommerce-subscriptions/' );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_URL' ) ) {
	define( 'YAYMAIL_ADDON_YITH_BOOKING_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'YAYMAIL_ADDON_YITH_BOOKING_VERSION' ) ) {
	// TODO Change version

	define( 'YAYMAIL_ADDON_YITH_BOOKING_VERSION', '2.0' );
}


spl_autoload_register(
	function ( $class ) {
		$prefix   = __NAMESPACE__;
		$base_dir = __DIR__ . '/includes';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class_name = substr( $class, $len );

		$file = $base_dir . str_replace( '\\', '/', $relative_class_name ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

function init() {

	if ( ! defined( 'YAYMAIL_THIRD_PARTY_YITH_BOOKING_IS_ACTIVE' ) ) {
		$is_active = function_exists( 'yith_wcbk_init' );
		define( 'YAYMAIL_THIRD_PARTY_YITH_BOOKING_IS_ACTIVE', $is_active );
	}

	if ( ! YAYMAIL_THIRD_PARTY_YITH_BOOKING_IS_ACTIVE || ! function_exists( 'YayMail\\init' ) ) {
		Backend\Notices::initialize();
	}

	if ( YAYMAIL_THIRD_PARTY_YITH_BOOKING_IS_ACTIVE && function_exists( 'YayMail\\init' ) ) {
		// Core\YayMailYITHBookingLicense::initialize();
		Backend\Enqueue::initialize();
		Backend\Actions::initialize();
		Core\YayMailAddonController::get_instance();
		Core\YayMailAddonShortcodeHandle::get_instance();
	}
}

add_action( 'plugins_loaded', 'YayMailYITHBooking\\init' );




