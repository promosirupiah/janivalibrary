<?php
defined( 'ABSPATH' ) || exit;

$text_link_color = get_post_meta( $this->yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $this->yaymail_informations['post_id'], '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
?>

<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" style="width: 100%;">
	<tr>
		<td align="center" valign="top">
		   
		<a href="#" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color:#96588a; font-weight:normal; text-decoration:none" data-linkindex="5">
			<span style="padding:6px 28px; font-size:12px; background:#e5e5e5; color:#333; text-decoration:none; text-transform:uppercase; font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif; font-weight:800; border-radius:3px; margin:5px">
			
			<?php echo esc_html_e( 'Pay booking', 'yith-booking-for-woocommerce' ); ?>
			</span>
		</a>

		<a href="#" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color:#96588a; font-weight:normal; text-decoration:none" data-linkindex="5">
			<span style="padding:6px 28px; font-size:12px; background:#e5e5e5; color:#333; text-decoration:none; text-transform:uppercase; font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif; font-weight:800; border-radius:3px; margin:5px">
				<?php echo __( 'View booking', 'yith-booking-for-woocommerce' )?>
			</span>
		</a>
		</td>
	</tr>
</table>


