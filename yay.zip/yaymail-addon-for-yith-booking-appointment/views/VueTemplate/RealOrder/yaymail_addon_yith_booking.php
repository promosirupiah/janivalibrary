<?php
	$sent_to_admin   = ( isset( $sent_to_admin ) ? true : false );
	$plain_text      = ( isset( $plain_text ) ? $plain_text : '' );
	$email           = ( isset( $email ) ? $email : '' );
	$text_link_color = get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
	$template        = get_post_meta( $post_id, '_yaymail_template', true ) ? get_post_meta( $post_id, '_yaymail_template', true ) : false;
foreach ( $bookings as $key => $value ) {
	$booking         = yith_get_booking( $value->id );
	$order_id        = apply_filters( 'yith_wcbk_email_booking_details_order_id', $booking->get_order_id(), $booking, $sent_to_admin, $plain_text, $email );
	$the_order       = ! ! $order_id ? wc_get_order( $order_id ) : false;
	$booking_args    = array(
		'order_id'       => $order_id,
		'order'          => $the_order,
		'split_services' => true,
	);
	$data_to_display = $booking->get_booking_data_to_display( $sent_to_admin ? 'admin' : 'frontend', $booking_args );
	if ( isset( $data_to_display['status'] ) ) {
		unset( $data_to_display['status'] );
	}

	?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row yith-booking-table"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >		
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width: 100% !important;color: inherit;
						border: none;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor, backgroundColor: emailContent.settingRow.dataTableBackgroundColor}">
						<tbody>
						<!-- start booking id -->
						<tr>
							<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;width: 40%;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleBookingId}}</td>
							<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<?php
							printf(
								' <a style="color: %s" href="%s">#%s</a>',
								esc_attr( $text_link_color ),
								esc_url( $booking->get_view_booking_url() ),
								esc_html( $booking->get_id() )
							);
							?>
							</td>
						</tr>
						<!-- end booking id -->

						<!-- start product -->
						<?php
						if ( null !== $booking->get_product_id() && ( $product = wc_get_product( $booking->get_product_id() ) ) ) :

							$product_link  = get_permalink( $booking->get_product_id() );
							$product_title = $product->get_title();
							?>
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
							<?php printf( ' <a style="color: %s" href="%s">%s</a>', esc_attr( $text_link_color ), esc_url( $product_link ), esc_html( $product_title ) ); ?>
								</td>
							</tr>
							<?php endif; ?>
						<!-- end product -->

						<!-- start order -->
						<?php
						$booking_order_id = apply_filters( 'yith_wcbk_email_booking_details_order_id', $booking->get_order_id(), $booking, $sent_to_admin, $plain_text, $email );
						?>

						<?php
						if ( $booking_order_id && $order = wc_get_order( $booking_order_id ) ) :
							if ( ! $sent_to_admin ) {
								$order_link = $order->get_view_order_url();
							} else {
								$order_link = esc_url( admin_url( 'post.php?post=' . $booking_order_id . '&action=edit' ) );
							}
							$order_title = _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number();
							?>
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleOrder}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
									<?php printf( ' <a style="color: %s" href="%s">%s</a>', esc_attr( $text_link_color ), esc_url( $order_link ), esc_html( $order_title ) ); ?> 
									
									<?php
									if ( $template == 'yith_wcbk_admin_new_booking' ) {
										$data = $the_order->data;
										if ( isset( $data['billing']['first_name'] ) ) {
											printf( ' by %s ', esc_html( ucfirst( $data['billing']['first_name'] ) ) );
										}
										if ( isset( $data['billing']['last_name'] ) ) {
											printf( '%s', esc_html( ucfirst( $data['billing']['last_name'] ) ) );
										}
									}
									?>
								</td>
							</tr>
							<?php endif; ?>
							<!-- end order -->

							<!-- start from date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleFrom}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo esc_html( $booking->get_formatted_date( 'from' ) ); ?></td>
							</tr>
							<!-- end from date -->

							<!-- start to date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleTo}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo esc_html( $booking->get_formatted_date( 'to' ) ); ?></td>
							</tr>
							<!-- end to date -->

							<!-- start duration -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleDuration}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo esc_html_e( $booking->get_duration_html(), 'yaymail' ); ?></td>
							</tr>
							<!-- end duration -->

							<!-- start duration -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titlePeople}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
									<?php
										$value       = $booking->get_persons();
										$person_type = $booking->get_person_types_html();
									if ( ! empty( $person_type ) ) {

										$value .= ' (' . $booking->get_person_types_html() . ')';
									}
										echo wp_kses_post( $value );
									?>
								</td>
							</tr>
							<!-- end duration -->

							<!-- start status -->
							<?php
								$status_text           = $booking->get_status_text();
								$status_lowercase_text = strtolower( $status_text );

								$status_background = 'statusBackground';
								$status_color      = 'statusUnpaidColor';
							switch ( $status_lowercase_text ) {
								case 'unpaid':
									$status_color = 'statusUnpaidColor';
									break;

								case 'paid':
									$status_color = 'statusPaidColor';
									break;

								case 'confirmed':
									$status_color = 'statusConfirmedColor';
									break;

								case 'rejected':
									$status_color = 'statusRejectedColor';
									break;

								case 'cancelled':
									$status_color = 'statusCancelledColor';
									break;

								case 'completed':
									$status_color = 'statusCompletedColor';
									break;

								default:
									break;
							}
							?>
							<!-- set background color based on status -->
							<tr :style="{backgroundColor: emailContent.settingRow.<?php printf( '%s', esc_html( $status_background ) ); ?> }">
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStatus}}</td>
								<td class="td" style="font-weight: bold; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor, color: emailContent.settingRow.<?php printf( '%s', esc_html( $status_color ) ); ?>}"><?php echo esc_html_e( $status_text, 'yaymail' ); ?></td>
							</tr>
							<!--  end status -->

						</tbody>
				</table>
				<?php
				if ( $status_text === 'Confirmed' ) :
					?>
						<div style="text-align: center; padding: 15px 20px;"
						:style="{backgroundColor: emailContent.settingRow.statusBackground}">
							<div style="padding-bottom: 10px;">
								<a 
								style="
								color: #fff; 
								text-align: center;
								font-weight: 600;
								padding: 6px 20px;
								text-transform: uppercase;
								border-radius: 3px;
								display: inline-block;
								text-decoration: none;
								background: #bab91b;
								"
								><?php echo esc_html_e( 'PAY BOOKING', 'yaymail' ); ?></a>
							</div>
							<?php echo esc_html_e( 'or', 'yaymail' ); ?>
							<a style="color: <?php echo esc_html( $text_link_color ); ?>"><?php echo esc_html_e( 'View booking details', 'yaymail' ); ?></a>
						</div>

					<?php
				endif;
				?>
			</div>
		</td>
	</tr>
</tbody>
</table>
<?php } ?>
