<?php
	$sent_to_admin   = ( isset( $sent_to_admin ) ? true : false );
	$plain_text      = ( isset( $plain_text ) ? $plain_text : '' );
	$email           = ( isset( $email ) ? $email : '' );
	$text_link_color = get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
	$template        = get_post_meta( $post_id, '_yaymail_template', true ) ? get_post_meta( $post_id, '_yaymail_template', true ) : false;
?>
<table
	:width="tableWidth"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table;width: 100%;"
	:style="{
	  backgroundColor: emailContent.settingRow.backgroundColor,
	  width: tableWidth
	}"
	class="web-main-row yith-booking-table"
	:id="'web' + emailContent.id"
  >
	  <tbody>
	  <tr>
		<td
		  :id="'web-' + emailContent.id + '-order-item'"
		  class="web-order-item"
		  align="left"
		  style="font-size: 13px; line-height: 22px; word-break: break-word;"
		  :style="{
			fontFamily: emailContent.settingRow.family,
			paddingTop: emailContent.settingRow.paddingTop + 'px',
			paddingBottom: emailContent.settingRow.paddingBottom + 'px',
			paddingRight: emailContent.settingRow.paddingRight + 'px',
			paddingLeft: emailContent.settingRow.paddingLeft + 'px'
		  }"
		>
		  <div
		  class="yaymail-items-order-border"
			style="min-height: 10px"
			:style="{
			  color: emailContent.settingRow.textColor,
			  borderColor: emailContent.settingRow.borderColor,
			}"
		  >		
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width: 100% !important;color: inherit;
						border: none;" width="100%" :style="{'border-color': emailContent.settingRow.borderColor, backgroundColor: emailContent.settingRow.dataTableBackgroundColor}">
						<tbody>

							<!-- start booking id -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid; width: 40%;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleBookingId}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php
								printf(
									' <a style="color: %s" href="#">#1</a>',
									esc_attr( $text_link_color )
								);
								?>
								</td>
							</tr>
							<!-- end booking id -->

							<!-- start product -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleProduct}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
								<?php printf( ' <a style="color: %s" href="#">Yaymail</a>', esc_attr( $text_link_color ) ); ?>
								</td>
							</tr>
						<!-- end product -->

							<!-- start order -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleOrder}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">
									<?php printf( ' <a style="color: %s" href="#">#1</a>', esc_attr( $text_link_color ) ); ?> 
									
									<?php
									if ( $template == 'yith_wcbk_admin_new_booking' ) {
											printf( ' by Yaymail ' );
									}
									?>
								</td>
							</tr>
							<!-- end order -->

						<!-- start from date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleFrom}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php printf( ' <time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?> </td>
							</tr>
							<!-- end from date -->

							<!-- start to date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleTo}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php printf( ' <time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?> </td>
							</tr>
							<!-- end to date -->
						
							<!-- start duration -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleDuration}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo esc_html_e( '1 day', 'yaymail' ); ?></td>
							</tr>
							<!-- end duration -->

							<!-- start people -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titlePeople}}</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}"><?php echo esc_html_e( '1 (test people: 1)', 'yaymail' ); ?></td>
							</tr>
							<!-- end people -->

							<!-- start status -->
							<?php
								$status_text  = 'Paid';
								$status_color = 'statusPaidColor';

							switch ( $template ) {
								case 'yith_wcbk_customer_confirmed_booking':
									$status_text  = 'Confirmed';
									$status_color = 'statusConfirmedColor';
									break;

								case 'yith_wcbk_customer_unconfirmed_booking':
									$status_text  = 'Rejected';
									$status_color = 'statusRejectedColor';
									break;
								case 'yith_wcbk_customer_cancelled_booking':
									$status_text  = 'Cancelled';
									$status_color = 'statusCancelledColor';
									break;

								case 'yith_wcbk_customer_completed_booking':
									$status_text  = 'Completed';
									$status_color = 'statusCompletedColor';
									break;

								default:
									break;
							}
							?>
							<tr :style="{backgroundColor: emailContent.settingRow.statusBackground}">
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor}">{{emailContent.settingRow.titleStatus}}</td>
								<td class="td" style="font-weight: bold; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;" :style="{'border-color': emailContent.settingRow.borderColor, color: emailContent.settingRow.<?php echo esc_html( $status_color ); ?>}"><?php echo esc_html_e( $status_text, 'yaymail' ); ?>
								</td>
								
							</tr>
							
							<!--  end status -->
						</tbody>
				</table>
				<?php
				if ( $status_text === 'Confirmed' ) :
					?>
						<div style="text-align: center; padding: 15px 20px;"
						:style="{backgroundColor: emailContent.settingRow.statusBackground}">
							<div style="padding-bottom: 10px;">
								<a 
								style="
								color: #fff; 
								text-align: center;
								font-weight: 600;
								padding: 6px 20px;
								text-transform: uppercase;
								border-radius: 3px;
								display: inline-block;
								text-decoration: none;
								background: #bab91b;
								"
								><?php echo esc_html_e( 'PAY BOOKING', 'yaymail' ); ?></a>
							</div>
							<?php echo esc_html_e( 'or', 'yaymail' ); ?>
							<a style="color: <?php echo esc_html( $text_link_color ); ?>"><?php echo esc_html_e( 'View booking details', 'yaymail' ); ?></a>
						</div>

					<?php
				endif;
				?>
			
			</span>
		</td>
	</tr>
</tbody>
</table>
