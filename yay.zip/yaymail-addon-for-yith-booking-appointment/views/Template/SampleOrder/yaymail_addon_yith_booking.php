<?php
	$text_link_color   = get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';
	$title_booking_id  = isset( $attrs['titleBookingId'] ) ? $attrs['titleBookingId'] : 'Booking Id';
	$title_product     = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
	$title_status      = isset( $attrs['titleStatus'] ) ? $attrs['titleStatus'] : 'Status';
	$title_order       = isset( $attrs['titleOrder'] ) ? $attrs['titleOrder'] : 'Order';
	$title_duration    = isset( $attrs['titleDuration'] ) ? $attrs['titleDuration'] : 'Duration';
	$title_from        = isset( $attrs['titleFrom'] ) ? $attrs['titleFrom'] : 'From';
	$title_to          = isset( $attrs['titleTo'] ) ? $attrs['titleTo'] : 'To';
	$title_people      = isset( $attrs['titlePeople'] ) ? $attrs['titlePeople'] : 'People';
	$border_color      = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
	$text_color        = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
	$title_color       = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
	$status_background = isset( $attrs['statusBackground'] ) && $attrs['statusBackground'] ? 'background-color:' . html_entity_decode( $attrs['statusBackground'], ENT_QUOTES, 'UTF-8' ) : 'background-color:inherit';

	$data_table_background = isset( $attrs['dataTableBackgroundColor'] ) && $attrs['dataTableBackgroundColor'] ? 'background-color:' . html_entity_decode( $attrs['dataTableBackgroundColor'], ENT_QUOTES, 'UTF-8' ) : 'background-color:inherit';
	$template              = get_post_meta( $post_id, '_yaymail_template', true ) ? get_post_meta( $post_id, '_yaymail_template', true ) : false;
?>
<table
	width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; <?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; "
	class="web-main-row"
	id="web<?php echo esc_attr( $id ); ?>"
  >
	  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>'
		>
		  <div style="min-height: 10px;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
				  
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width:100%;border-width: 1px;border-style: solid;
						border: none;
						<?php echo esc_attr( $border_color ); ?>;
						<?php echo esc_attr( $data_table_background ); ?>;
						<?php echo esc_attr( $text_color ); ?>;">
						<tbody>
							<!-- start booking id -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;
								width: 40%;
								<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_booking_id, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;">
								<?php
								printf(
									' <a style="color: %s" href="#">#1</a>',
									esc_attr( $text_link_color )
								);
								?>
								</td>
							</tr>
							<!-- end booking id -->

							<!-- start product -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;">
								<?php echo esc_html_e( $title_product, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" >
								<?php printf( ' <a style="color: %s" href="#">Yaymail</a>', esc_attr( $text_link_color ) ); ?>
								</td>
							</tr>
							<!-- end product -->

							<!-- start order -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_order, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;">
									<?php printf( ' <a style="color: %s" href="#">#1</a>', esc_attr( $text_link_color ) ); ?> 
									
									<?php
									if ( $template == 'yith_wcbk_admin_new_booking' ) {
											printf( ' by Yaymail ' );
									}
									?>
								</td>
							</tr>
							<!-- end order -->

							<!-- start from date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_from, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid; <?php echo esc_attr( $border_color ); ?>;"><?php printf( ' <time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?> </td>
							</tr>
							<!-- end from date -->

							<!-- start to date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_to, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php printf( ' <time datetime="%s">%s</time>', new WC_DateTime(), wc_format_datetime( new WC_DateTime() ) ); ?> </td>
							</tr>
							<!-- end to date -->

							<!-- start duration -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_duration, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( '1 day', 'yaymail' ); ?></td>
							</tr>
							<!-- end duration -->

							<!-- start people-->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_people, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( '1 (test people: 1)', 'yaymail' ); ?></td>
							</tr>
							<!-- end people -->
						
							<!-- start status -->

							<?php
								$status_text  = 'Paid';
								$status_color = 'statusPaidColor';

							switch ( $template ) {
								case 'yith_wcbk_customer_confirmed_booking':
									$status_text  = 'Confirmed';
									$status_color = 'statusConfirmedColor';
									break;

								case 'yith_wcbk_customer_unconfirmed_booking':
									$status_text  = 'Rejected';
									$status_color = 'statusRejectedColor';
									break;

								case 'yith_wcbk_customer_cancelled_booking':
									$status_text  = 'Cancelled';
									$status_color = 'statusCancelledColor';
									break;

								case 'yith_wcbk_customer_completed_booking':
									$status_text  = 'Completed';
									$status_color = 'statusCompletedColor';
									break;

								default:
									break;
							}

							$status_color = isset( $attrs[ $status_color ] ) && $attrs[ $status_color ] ? 'color:' . html_entity_decode( $attrs [ $status_color ], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
							?>
							
							<tr style="<?php echo esc_attr( $status_background ); ?>;">
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_status, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: bold; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;<?php echo esc_attr( $status_color ); ?>;"><?php echo esc_html( $status_text ); ?></td>
							</tr>
							<!--  end status -->

						</tbody>
				</table>
				<?php
				if ( $status_text === 'Confirmed' ) :
					?>
						<div style="text-align: center; padding: 15px 20px; <?php echo esc_attr( $status_background ); ?>;">
							<div style="padding-bottom: 10px;">
								<a 
								target="_blank"
								href="<?php echo esc_url( wc_get_checkout_url() ); ?>"
								style="
								color: #fff; 
								text-align: center;
								font-weight: 600;
								padding: 6px 20px;
								text-transform: uppercase;
								border-radius: 3px;
								display: inline-block;
								text-decoration: none;
								background: #bab91b;
								"
								><?php echo esc_html_e( 'PAY BOOKING', 'yaymail' ); ?></a>
							</div>
							<?php echo esc_html_e( 'or', 'yaymail' ); ?> 
							<a style="color: <?php echo esc_html( $text_link_color ); ?>"
							target="_blank"
							href="#">
								<?php echo esc_html_e( 'View booking details', 'yaymail' ); ?>
							</a>
						</div>

					<?php
				endif;
				?>
			</div>
		</td>
	</tr>
</tbody>
</table>
