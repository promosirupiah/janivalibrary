<?php
	$text_link_color = get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) ? get_post_meta( $post_id, '_yaymail_email_textLinkColor_settings', true ) : '#96588A';

	$title_booking_id      = isset( $attrs['titleBookingId'] ) ? $attrs['titleBookingId'] : 'Booking ID';
	$title_product         = isset( $attrs['titleProduct'] ) ? $attrs['titleProduct'] : 'Product';
	$title_status          = isset( $attrs['titleStatus'] ) ? $attrs['titleStatus'] : 'Status';
	$title_order           = isset( $attrs['titleOrder'] ) ? $attrs['titleOrder'] : 'Order';
	$title_user           = isset( $attrs['titleUser'] ) ? $attrs['titleUser'] : 'User';
	$title_duration        = isset( $attrs['titleDuration'] ) ? $attrs['titleDuration'] : 'Duration';
	$title_from            = isset( $attrs['titleFrom'] ) ? $attrs['titleFrom'] : 'From';
	$title_to              = isset( $attrs['titleTo'] ) ? $attrs['titleTo'] : 'To';
	$title_people          = isset( $attrs['titlePeople'] ) ? $attrs['titlePeople'] : 'People';
	$border_color          = isset( $attrs['borderColor'] ) && $attrs['borderColor'] ? 'border-color:' . html_entity_decode( $attrs['borderColor'], ENT_QUOTES, 'UTF-8' ) : 'border-color:inherit';
	$data_table_background = isset( $attrs['dataTableBackgroundColor'] ) && $attrs['dataTableBackgroundColor'] ? 'background-color:' . html_entity_decode( $attrs['dataTableBackgroundColor'], ENT_QUOTES, 'UTF-8' ) : 'background-color:inherit';
	$text_color            = isset( $attrs['textColor'] ) && $attrs['textColor'] ? 'color:' . html_entity_decode( $attrs['textColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
	$title_color           = isset( $attrs['titleColor'] ) && $attrs['titleColor'] ? 'color:' . html_entity_decode( $attrs['titleColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
	$status_background     = isset( $attrs['statusBackground'] ) && $attrs['statusBackground'] ? 'background-color:' . html_entity_decode( $attrs['statusBackground'], ENT_QUOTES, 'UTF-8' ) : 'background-color:inherit';
	$status_color          = isset( $attrs['statusPaidColor'] ) && $attrs['statusPaidColor'] ? 'color:' . html_entity_decode( $attrs['statusPaidColor'], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
	$sent_to_admin         = isset( $args['sent_to_admin'] ) ? $args['sent_to_admin'] : false;
	$template              = get_post_meta( $post_id, '_yaymail_template', true ) ? get_post_meta( $post_id, '_yaymail_template', true ) : false;
	$order_id              = apply_filters( 'yith_wcbk_email_booking_details_order_id', $booking->get_order_id(), $booking, $sent_to_admin, $plain_text, $email );
	$the_order             = ! ! $order_id ? wc_get_order( $order_id ) : false;
?>
<style>
	.yaymail_builder_table_yith_booking_appointment a {
		color: <?php echo($text_link_color) ?> !important
	}
</style>
<table
	width="<?php esc_attr_e( $general_attrs['tableWidth'], 'woocommerce' ); ?>"
	cellspacing="0"
	cellpadding="0"
	border="0"
	align="center"
	style="display: table; <?php echo esc_attr( 'background-color: ' . $attrs['backgroundColor'] ); ?>; <?php echo esc_attr( 'min-width: ' . $general_attrs['tableWidth'] . 'px' ); ?>; "
	class="web-main-row yith-booking-table"
	id="web<?php echo esc_attr( $id ); ?>"
  >
	  <tbody>
	  <tr>
		<td
		  id="web-<?php echo esc_attr( $id ); ?>-order-item"
		  class="web-order-item"
		  align="left"
		  style='font-size: 13px; line-height: 22px; word-break: break-word;<?php echo 'font-family: ' . wp_kses_post( $attrs['family'] ); ?>;<?php echo esc_attr( 'padding: ' . $attrs['paddingTop'] . 'px ' . $attrs['paddingRight'] . 'px ' . $attrs['paddingBottom'] . 'px ' . $attrs['paddingLeft'] . 'px;' ); ?>'
		>
		  <div style="min-height: 10px;<?php echo esc_attr( 'color: ' . $attrs['textColor'] ); ?>;">
				<table class="yaymail_builder_table_items_border yaymail_builder_table_subcription yaymail_builder_table_yith_booking_appointment" 
						cellspacing="0" cellpadding="6" border="1" 
						style="width:100%;border-width: 1px;border-style: solid;
						border: none;<?php echo esc_attr( $border_color ); ?>;
						<?php echo esc_attr( $data_table_background ); ?>;
						<?php echo esc_attr( $text_color ); ?>">
						<tbody>

						<!-- start booking id -->
						<?php
							$booking_link     = $sent_to_admin ? get_edit_post_link( $booking->get_id() ) : $booking->get_view_booking_url();
						?>
						<tr>
							<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;
							width: 40%; <?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_booking_id, 'yaymail' ); ?></td>
							<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;">
							<?php
							printf(
								' <a style="color: %s" href="%s">#%s</a>',
								esc_attr( $text_link_color ),
								esc_url( $booking_link ),
								esc_html( $booking->get_id() )
							);
							?>
							</td>
						</tr>
						<!-- end booking id -->

							<!-- start product -->
							<?php
							if ( null !== $booking->get_product_id() && ( $product = wc_get_product( $booking->get_product_id() ) ) ) :

								$product_link  = get_permalink( $booking->get_product_id() );
								$product_title = $product->get_title();
								?>
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_product, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" >
								<?php printf( ' <a style="color: %s" href="%s">%s</a>', esc_attr( $text_link_color ), esc_url( $product_link ), esc_html( $product_title ) ); ?>
								</td>
							</tr>
							<?php endif; ?>
						<!-- end product -->

						<!-- start order -->
						<?php
						$booking_order_id = apply_filters( 'yith_wcbk_email_booking_details_order_id', $booking->get_order_id(), $booking, $sent_to_admin, $plain_text, $email );
						?>

						<?php
						if ( $booking_order_id && $order = wc_get_order( $booking_order_id ) ) :
							if ( ! $sent_to_admin ) {
								$link  = $order->get_view_order_url();
								$title = _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number();
								$order_link = sprintf( '<a href="%s">%s</a>', esc_url( $link ), esc_html( $title ) );
							} else {
								$order_link = yith_wcbk_admin_order_info_html(
									$booking,
									array(
										'show_email'  => false,
										'show_status' => false,
									),
									false
								);
							}
							$order_title = _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number();
							?>
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_order, 'yaymail' ); ?>
								</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;
								<?php echo esc_attr( $border_color ); ?>;" >
									<?php
									echo wp_kses_post($order_link)
									?>
								</td>
							</tr>
							<?php endif; ?>
							<!-- end order -->
							<!-- start user -->
							<?php
								if ( false ) {
							?>
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_user, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo wp_kses_post( yith_wcbk_admin_user_info_html( $booking, false ) ); ?></td>
							</tr>
							<?php
								}
							?>
							<!-- end user -->
							<!-- start from date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_from, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html( $booking->get_formatted_date( 'from' ) ); ?></td>
							</tr>
							<!-- end from date -->

							<!-- start to date -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_to, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;
								<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html( $booking->get_formatted_date( 'to' ) ); ?></td>
							</tr>
							<!-- end to date -->

							<!-- start duration -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_duration, 'yaymail' ); ?>
								</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;
								<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $booking->get_duration_html(), 'yaymail' ); ?></td>
							</tr>
							<!-- end duration -->

							<!-- start people -->
							<tr>
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;" ><?php echo esc_html_e( $title_people, 'yaymail' ); ?>
								</td>
								<td class="td" style="font-weight: normal; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;">
									<?php
										$value       = $booking->get_persons();
										$person_type = $booking->get_person_types_html();

									if ( ! empty( $person_type ) ) {
										$value .= ' (' . $person_type . ')';
									}

										echo wp_kses_post( $value );
									?>
								</td>
							</tr>

							<!-- end people -->

							<!-- start status -->
							<?php
								$status_text           = $booking->get_status_text();
								$status_lowercase_text = strtolower( $status_text );

								// $status_background = 'statusBackground';
								$status_color      = null;
							switch ( $status_lowercase_text ) {
								case 'unpaid':
									$status_color = 'statusUnpaidColor';
									break;

								case 'paid':
									$status_color = 'statusPaidColor';
									break;

								case 'confirmed':
									$status_color = 'statusConfirmedColor';
									break;

								case 'rejected':
									$status_color = 'statusRejectedColor';
									break;

								case 'cancelled':
									$status_color = 'statusCancelledColor';
									break;

								case 'completed':
									$status_color = 'statusCompletedColor';
									break;

								default:
									break;
							}

							$status_color = isset( $attrs[ $status_color ] ) && $attrs[ $status_color ] ? 'color:' . html_entity_decode( $attrs [ $status_color ], ENT_QUOTES, 'UTF-8' ) : 'color:inherit';
							?>
							<!-- set background color based on status -->
							<tr style="background-color: <?php echo esc_attr( $attrs['statusBackground'] ); ?>;">
								<td class="td" style="text-align:left;font-weight: 600;word-wrap:break-word;vertical-align: middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;"><?php echo esc_html_e( $title_status, 'yaymail' ); ?></td>
								<td class="td" style="font-weight: bold; vertical-align:middle;padding: 12px;font-size: 14px;border-width: 1px;border-style: solid;<?php echo esc_attr( $border_color ); ?>;<?php echo esc_attr( $status_color ); ?>;" ><?php echo esc_html_e( $status_text, 'yaymail' ); ?></td>
							</tr>
							<!--  end status -->
							

					</table>
					<?php if ( ( $sent_to_admin && $booking->has_status( 'pending-confirm' ) ) || ( ! $sent_to_admin && $booking->has_status( 'confirmed' ) ) ) : ?>
						<div class="booking-actions">
							<?php if ( $sent_to_admin && $booking->has_status( 'pending-confirm' ) ) : ?>
								<?php
								$confirm_url = $booking->get_mark_action_url( 'confirmed', array( 'source' => 'email' ) );
								$reject_url  = $booking->get_mark_action_url( 'unconfirmed', array( 'source' => 'email' ) );
								?>
								<div class="booking-actions__row">
									<a class='booking-button booking-action--confirm' href="<?php echo esc_url( $confirm_url ); ?>"><?php esc_html_e( 'Confirm booking', 'yith-booking-for-woocommerce' ); ?></a>
								</div>
								<div class="booking-actions__row">
									<?php
									echo wp_kses_post(
										sprintf(
										// translators: %s is an action link.
											_x( 'or %s', 'Email action alternative', 'yith-booking-for-woocommerce' ),
											sprintf(
												'<a style="color: %s" class="booking-link booking-action--reject" href="%s">%s</a>',
												esc_attr( $text_link_color ),
												esc_url( $reject_url ),
												esc_html__( 'Reject booking', 'yith-booking-for-woocommerce' )
											)
										)
									);
									?>
								</div>

							<?php elseif ( ! $sent_to_admin && $booking->has_status( 'confirmed' ) ) : ?>
								<?php
								$pay_url  = $booking->get_confirmed_booking_payment_url();
								$view_url = $booking->get_view_booking_url();
								?>
								<div class="booking-actions__row">
									<a class="booking-button booking-action--pay" href="<?php echo esc_url( $pay_url ); ?>"><?php esc_html_e( 'Pay booking', 'yith-booking-for-woocommerce' ); ?></a>
								</div>
								<div class="booking-actions__row">
									<?php
									echo wp_kses_post(
										sprintf(
										// translators: %s is an action link.
											_x( 'or %s', 'Email action alternative', 'yith-booking-for-woocommerce' ),
											sprintf(
												'<a style="color: %s"  class="booking-link booking-action--view" href="%s">%s</a>',
												esc_attr( $text_link_color ),
												esc_url( $view_url ),
												esc_html__( 'View booking details', 'yith-booking-for-woocommerce' )
											)
										)
									);
									?>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
			</div>
		</td>
	</tr>
</tbody>
</table>
