/**
 * Editor script.
 */

/* global jQuery */
;( function ( $ ) {
    'use strict';

    $( document ).ready( function () {

        /**
         * Trigger section style control.
         */
        madxartwork.hooks.addAction( 'panel/open_editor/section', function ( panel, model, view ) {
            panel.$el.find( '#madxartwork-panel-content-wrapper #madxartwork-panel-page-editor .madxartwork-panel-navigation .madxartwork-tab-control-style a' ).trigger( 'click' );
            panel.$el.find( '#madxartwork-panel-content-wrapper #madxartwork-panel-page-editor' ).addClass( 'woolentor-email-section-editor' );
            panel.$el.find( '#madxartwork-panel-content-wrapper #madxartwork-panel-page-editor #madxartwork-controls .madxartwork-control-section_background .madxartwork-section-title' ).text( woolentor_email_customizer_editor.section_style_title );
        } );

        /**
         * Trigger column style control.
         */
        madxartwork.hooks.addAction( 'panel/open_editor/column', function ( panel, model, view ) {
            panel.$el.find( '#madxartwork-panel-content-wrapper #madxartwork-panel-page-editor .madxartwork-panel-navigation .madxartwork-tab-control-style a' ).trigger( 'click' );
            panel.$el.find( '#madxartwork-panel-content-wrapper #madxartwork-panel-page-editor' ).addClass( 'woolentor-email-column-editor' );
            panel.$el.find( '#madxartwork-panel-content-wrapper #madxartwork-panel-page-editor #madxartwork-controls .madxartwork-control-section_style .madxartwork-section-title' ).text( woolentor_email_customizer_editor.column_style_title );
        } );

    } );

} )( jQuery );
