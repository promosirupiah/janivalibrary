<?php
/**
 * Styles.
 */

$width = woolentor_get_option_pro( 'width','woolentor_email_customizer_settings', 600 );
$width = absint( $width );
$width = ! empty( $width ) ? $width : 600;
?>

.madxartwork .madxartwork-inner,
.madxartwork .madxartwork-section-wrap,
.madxartwork-section,
#madxartwork-add-new-section,
#woolentor-email-wrapper {
    width: 100%;
    max-width: <?php echo $width; ?>px;
}