<div class="wrap">
	<h2><?php _e('Tags','ace'); ?></h2><p>
  <?php _e('Coming soon ;)','ace'); ?><br />
  <?php _e('Stay updated!','ace'); ?>
</div>