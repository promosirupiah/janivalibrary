<div class="wrap">
  <h2><?php _e('Advanced Category Excluder','ace'); ?></h2>
  <div class="metabox-holder" id="poststuff">
    <div id="ace_main" class="postbox">
      <h3 class="hndle">
        <span><?php _e('Homepages','ace'); ?></span>
      </h3>
      <div class="inside">
      	<ul>
      	 <li><a href="http://wordpress.org/extend/plugins/advanced-category-excluder/" target="_blank">Our page on WordPress.org Plugin directory</a> - offical download location</li>
      	 <li><a href="http://advanced-category-excluder.dev.rain.hu/" target="_blank">Our developement base</a> - this is for comments, feature requests, and feedbacks</li>
      	 <li><strong><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=paypal@djz.hu&item_name=Advanced%20Category%20Excluder%20for%20Wordpress
      " target="_blank">You can make a donation here</a></strong></li>
      	</ul>
      </div>
    </div>
  </div>
</div>