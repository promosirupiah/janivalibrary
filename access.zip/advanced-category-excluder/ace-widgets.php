<?php
/*
Plugin Name: Advanced Category Excluder Widgets
Version: 1.4.3
Plugin URI: http://advanced-category-excluder.dev.rain.hu
Description: This plugin one basic widgetsm that support exclusion
Author: DjZoNe
Author URI: http://djz.hu/
*/

require_once("widgets/recent-comments.php");
require_once("widgets/recent-posts.php");
require_once("widgets/categories.php");
?>