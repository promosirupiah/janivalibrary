<div class="gdsr-title">GD Star Rating</div>
<div class="inside" style="padding-top: 5px;">
<?php include(STARRATING_PATH.'integrate/edit.php'); ?>
</div>
