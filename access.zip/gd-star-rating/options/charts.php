<div class="wrap">
    <h2 class="gdptlogopage">GD Star Rating: <?php _e("Charts", "gd-star-rating"); ?></h2>
<div class="gdsr">

<div id="gdsr_tabs" class="gdsrtabs">
<ul>
    <li><a href="#fragment-1"><span><?php _e("Articles (Posts And Pages)", "gd-star-rating"); ?></span></a></li>
    <li><a href="#fragment-2"><span><?php _e("Comments", "gd-star-rating"); ?></span></a></li>
</ul>
<div style="clear: both"></div>

<div id="fragment-1">

</div>

<div id="fragment-2">

</div>

</div>
</div>