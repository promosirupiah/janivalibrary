<div class="wrap"><h2 class="gdptlogopage">GD Star Rating: <?php _e("Wizard", "gd-star-rating"); ?></h2>
<div class="gdsr">
Work in progress. Expected for the GD Star Rating 2.0.
</div>
</div>