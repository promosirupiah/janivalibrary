<table class="form-table"><tbody>
<tr><th scope="row"><?php _e("Export Templates", "gd-star-rating"); ?></th>
    <td>
        <?php _e("This will export all templates you created into a file.", "gd-star-rating"); ?><br />
        <div class="inputbutton"><a href="<?php echo STARRATING_URL; ?>/export.php?ex=t2"><?php _e("Export", "gd-star-rating"); ?></a></div>
        <div class="gdsr-table-split"></div>
        <?php _e("Exported file will contain names, descriptions and contents of templates. File will be in CSV format.", "gd-star-rating"); ?>
    </td>
</tr>
</tbody></table>
