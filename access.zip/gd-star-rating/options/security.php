<div class="wrap"><h2 class="gdptlogopage">GD Star Rating: <?php _e("Security", "gd-star-rating"); ?></h2>
<div class="gdsr">
Work in progress. Expected for the GD Star Rating 1.8.
</div>
</div>