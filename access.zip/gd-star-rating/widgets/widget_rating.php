<?php include(STARRATING_PATH.'widgets/rating/part_basic.php'); ?>
<?php include(STARRATING_PATH.'widgets/rating/part_trend.php'); ?>
<?php include(STARRATING_PATH.'widgets/rating/part_filter.php'); ?>
<?php include(STARRATING_PATH.'widgets/rating/part_image.php'); ?>
<?php include(STARRATING_PATH.'widgets/rating/part_stars.php'); ?>

<input type="hidden" id="gdstarr-submit" name="<?php echo $wpfn; ?>[submit]" value="1" />
