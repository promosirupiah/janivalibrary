<?php

    require_once("./config.php");
    $wpload = get_gdsr_wpload_path();
    require($wpload);

    global $gdsr;

?>