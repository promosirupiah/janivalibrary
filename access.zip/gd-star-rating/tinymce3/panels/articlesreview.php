<fieldset>
<legend><?php _e("Articles Review Rating", "gd-star-rating"); ?></legend>
<p><?php _e("StarReview will render stars representing review value assigned to the post or page.", "gd-star-rating"); ?></p>
</fieldset>

<fieldset>
<legend><?php _e("Template", "gd-star-rating"); ?></legend>
    <?php gdTemplateHelper::render_templates_section("RSB", "srTemplateRSB", 0, 300); ?>
</fieldset>
