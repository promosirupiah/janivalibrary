/*jQuery(function($) {
	//$()
	//Theres nothing here yet.. But there will be in time.
});*/