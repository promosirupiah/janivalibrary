<?php
if(!defined('ABSPATH'))die();
if(!class_exists('WishListMemberCore')){
	class WishListMemberCore{
		// -----------------------------------------
		// Constructor
		function Constructor($pluginfile,$sku,$menuid,$title,$link){ // constructor
			require_once(ABSPATH.'/wp-admin/includes/plugin.php');

			// character encoding
			$this->BlogCharset=get_option('blog_charset');

			$this->ProductSKU=$sku;
			$this->MenuID=$menuid;
			$this->Title=$title;
			$this->Link=$link;
			
			$this->PluginInfo=(object)get_plugin_data($pluginfile);
			$this->Version=$this->PluginInfo->Version;
			$this->WPVersion=$GLOBALS['wp_version']+0;
			
			$this->pluginPath=$pluginfile;
			$this->pluginDir=dirname($this->pluginPath);
			$this->pluginBasename=plugin_basename($this->pluginPath);
			$this->pluginURL=get_bloginfo('wpurl').'/'.PLUGINDIR.'/'.dirname(plugin_basename($this->pluginPath));
			
			$this->Menus=array();
			
			$this->ClearOptions();
			$this->PluginOptions=get_option('WishListMemberOptions');
			if($_POST['WishListMemberAction']=='Save'){
				$this->SaveOptions();
			}
			add_action('admin_menu',array(&$this,'AdminMenus'));
			add_action('admin_notices',array(&$this,'SubMenus'),1);
		}
		// -----------------------------------------
		// Admin Menus
		function AdminMenus(){
			// Top Menu
			$firstMenu=AdminPage;
			if(!defined('WPWLTOPMENU')){
				add_menu_page('WishList Plugins','WL Plugins',8,'WPWishList',array(&$this,$firstMenu));
				define('WPWLTOPMENU','WPWishList');
			}
			
			add_submenu_page(WPWLTOPMENU,$this->Title,$this->Link,8,$this->MenuID,array(&$this,$firstMenu));
			
			// Submenu for "Other Tab"
			$found=false;
			foreach($GLOBALS['submenu'] AS $key=>$sm){
				foreach ($sm AS $k=>$m){
					if($m[2]=='WPWLOther'){
						unset($GLOBALS['submenu'][$key][$k]);
						$found=true;
						$GLOBALS['submenu'][$key][]=$m;
						break;
					}
				}
			}
			if(!$found)add_submenu_page(WPWLTOPMENU,'Other WP WishList Plugins','Other',8,'WPWLOther',array(&$this,'OtherTab'));
			// End of Submenu for "Other Tab"
			
			unset($GLOBALS['submenu']['WPWishList'][0]);
		}
		
		// -----------------------------------------
		// Admin Submenus
		function SubMenus(){
			if($_GET['page']==$this->MenuID){
				echo '<ul class="WLSubMenu">';
				echo '<li><a '.($_GET['wl']==''?'class="current"':'').' href="?page='.$this->MenuID.'">Dashboard</a></li>';
				foreach($this->Menus AS $key=>$menu){
					echo '<li><a '.($_GET['wl']==($key)?'class="current"':'').' href="?page='.$this->MenuID.'&wl='.$key.'">'.$menu['Name'].'</a></li>';
				}
				echo '</ul>';
				if($_POST['err']) echo '<div class="updated fade"><p><b>Error:</b> '.$_POST['err'].'</p></div>';
				if($_GET['err']) echo '<div class="updated fade"><p><b>Error:</b> '.$_GET['err'].'</p></div>';
				if($_POST['msg']) echo '<div class="updated fade"><p>'.$_POST['msg'].'</p></div>';
				if($_GET['msg']) echo '<div class="updated fade"><p>'.$_GET['msg'].'</p></div>';
			}
		}
		
		// -----------------------------------------
		// Retrieve individual submenus
		function GetMenu($key,$html=false){
			if($obj=$this->Menus[$key]){
				$obj=(object)$obj;
				$obj->URL='?page='.$this->MenuID.'&wl='.$key;
				$obj->HTML='<a href="'.$obj->URL.'">'.$obj->Name.'</a>';
				if($html) echo $obj->HTML;
				return $obj;
			}else{
				return false;
			}
		}
		
		// -----------------------------------------
		// Admin Pages
		function AdminPage(){
			echo '<div class="wrap"><h2 style="border:none;height:1px;margin:0;padding:0;line-height:0"></h2>';
			$menu=$this->Menus[$_GET['wl']];
			if(!@include($this->pluginDir.'/admin/'.$menu['File'])){
				include($this->pluginDir.'/admin/dashboard.php');
			}
			echo '</div>';
		}
		
		// -----------------------------------------
		// WP WishList Other Tab
		function OtherTab(){
				echo'<div class="wrap"><h2>Other WP WishList Plugins</h2><p>For more Wordpress tools and resources please visit the <a href="http://www.wpwishlist.com/" target="_blank">WP WishList Blog</a></p></div>';
		}
	
		// -----------------------------------------
		// Returns the Query String. Pass a GET variable and that gets removed.
		function QueryString(){
			$args=func_get_args();
			$get=array();
			foreach($_GET AS $key=>$value)$get[$key]="{$key}={$value}";
			foreach(array_keys($get) AS $key){
				if(in_array($key,$args))unset($get[$key]);
			}
			return implode('&',$get);
		}
		
		// -----------------------------------------
		// Sets Options and Retrieves
		function Option($name='',$required=false){
			if($name){
				$this->FormOption=$name;
				$this->FormOptions[$name]=(bool)$required;
				echo $name;
			}else{
				echo $this->FormOption;
			}
		}
		
		// -----------------------------------------
		// Sets Options and Retrieves
		function OptionValue($return=false,$default=''){
			if($_POST['err']){
				$x=$_POST[$this->FormOption];
			}else{
				$x=$this->PluginOptions[$this->FormOption];
			}
			if(!strlen($x))$x=$default;
			$x=__($x);
			if($return)return __($x);
			echo htmlentities($x,ENT_QUOTES,$this->BlogCharset);
		}
		
		// -----------------------------------------
		// Returns selected status 
		function OptionSelected($value){
			$x=$this->OptionValue(true);
			if($x==$value) echo ' selected="true"';
		}
		
		// -----------------------------------------
		// Returns checked status 
		function OptionChecked($value){
			$x=$this->OptionValue(true);
			if($x==$value) echo ' checked="true"';
		}
		
		// -----------------------------------------
		// Echoes Form Options as a comma delimited string
		function Options($html=true){
			$value=implode(',',array_keys($this->FormOptions));
			if($html){
				echo '<input type="hidden" name="WLOptions" value="'.$value.'" />';
			}else{
				echo $value;
			}
		}
		
		// -----------------------------------------
		// Echoes Required Form Options as a comma delimited string
		function RequiredOptions($html=true){
			$value=implode(',',array_keys($this->FormOptions,true));
			if($html){
				echo '<input type="hidden" name="WLRequiredOptions" value="'.$value.'" />';
			}else{
				echo $value;
			}
		}
		
		// -----------------------------------------
		// Clears FormOptions Array
		function ClearOptions(){
			$this->FormOptions=array();
		}
		
		// -----------------------------------------
		// Saves Options
		function SaveOptions($showmsg=true){
			foreach($_POST AS $k=>$v){
				if(!is_array($v))$_POST[$k]=trim(stripslashes($v));
			}
			$required=explode(',',$_POST['WLRequiredOptions']);
			foreach($required AS $req){
				if($req && !$_POST[$req]){
					$_POST['err']='<strong>Error:</strong> Fields marked with an asterisk (*) are required';
					return false;
				}
			}
			$options=explode(',',$_POST['WLOptions']);
			foreach($options AS $option){
				$this->PluginOptions[$option]=is_array($_POST[$option])?serialize($_POST[$option]):$_POST[$option];
			}
			update_option('WishListMemberOptions',$this->PluginOptions);
			if($showmsg)$_POST['msg']=$_POST['WLSaveMessage']?$_POST['WLSaveMessage']:'Settings Saved';
		}
		
		// -----------------------------------------
		// Retrieves Option Value
		function GetOption($option){
			$x=$this->PluginOptions[$option];
			$y=@unserialize($x);
			if(!$y) return $x;
			return $y;
		}
		
		// -----------------------------------------
		// Retrieves Option Value
		function DeleteOption(){
			$x=func_get_args();
			foreach($x AS $o)unset($this->PluginOptions[$o]);
			update_option('WishListMemberOptions',$this->PluginOptions);
		}
		
		// -----------------------------------------
		// Retrieves Option Value
		function SaveOption($name,$value){
			$this->PluginOptions[$name]=$value;
			update_option('WishListMemberOptions',$this->PluginOptions);
		}
		
		// -----------------------------------------
		// Add Option
		function AddOption($name,$value){
			if(!isset($this->PluginOptions[$name])){
				$this->PluginOptions[$name]=$value;
				update_option('WishListMemberOptions',$this->PluginOptions);
			}
		}
		
		// -----------------------------------------
		// Add Menus
		function AddMenu($key,$name,$file){
			$this->Menus[$key]=array('Name'=>$name,'File'=>$file);
		}
	}
}
?>