<?php
if(!defined('ABSPATH'))die();
if(!class_exists('WishListMemberPluginMethods')){
	class WishListMemberPluginMethods extends WishListMemberCore{
		// -----------------------------------------
		// Save Membership Content
		function SaveMembershipContent($data=''){
			if($data){
				$msg=false;
				extract($data);
			}else{
				$msg=true;
				extract($_POST);
			}
			if($Level=='Protection'){
				switch($ContentType){
					case 'categories':
						$Checked=(array)$Checked+(array)$ID;
						foreach($Checked AS $k=>$v)$Checked[$k]=abs($v-1); // the world's inverted for category protection... unprotected categories are the once saved...
						$Option='CatProtect';
					break;
					case 'posts':
					case 'pages':
						$Checked=(array)$Checked+(array)$ID;
						$Option='Protect';
					break;
					default:
						return false;
				}
				$Content=$this->GetOption($Option);
				$Content=implode(',',array_keys($Checked+wlm_array_combine($x=@explode(',',$Content),array_fill(0,count($x),1)),1));
				$this->SaveOption($Option,$Content);
				if($msg)$_POST['msg']='<b>Content Protection updated.</b>';
			}else{
				$Checked=(array)$Checked+(array)$ID;
				switch($ContentType){
					case 'categories':
						$Option='MembershipCategories';
					break;
					case 'pages':
						$Option='MembershipPages';
					break;
					case 'posts':
						$Option='MembershipPosts';
					break;
					case 'comments':
						$Option='MembershipComments';
					break;
					default:
						return false;
				}
				$Content=$this->GetOption($Option);
				$Content[$Level]=implode(',',array_keys($Checked+wlm_array_combine($x=@explode(',',$Content[$Level]),array_fill(0,count($x),1)),1));
				$this->SaveOption($Option,$Content);
				if($msg)$_POST['msg']='<b>Membership Level access updated.</b>';
			}
		}
		// -----------------------------------------
		// Retrieve Membership Content
		function GetMembershipContent($ContentType,$Level=''){
			switch($ContentType){
				case 'categories':
					$Option='MembershipCategories';
				break;
				case 'pages':
					$Option='MembershipPages';
				break;
				case 'posts':
					$Option='MembershipPosts';
				break;
				case 'comments':
					$Option='MembershipComments';
				break;
			}
			$Content=$this->GetOption($Option);
			if((int)$Level && !is_array($Level)){
				$Content=explode(',',$Content[(int)$Level]);
			}elseif(is_array($Level)){
				$xContent=array();
				foreach($Level AS $L){
					if((int)$L){
						$xContent=array_merge($xContent,explode(',',$Content[(int)$L]));
					}
				}
				$Content=array_unique($xContent);
			}else{
				foreach($Content AS $k=>$v)$Content[$k]=explode(',',$v);
			}
			return $Content;
		}

		// -----------------------------------------
		// Clone Membership Level
		function CloneMembershipContent($from,$to){
			foreach(array('MembershipCategories','MembershipPages','MembershipPosts','MembershipComments') AS $Option){
				$Content=$this->GetOption($Option);
				$Content[$to]=$Content[$from];
				$this->SaveOption($Option,$Content);
			}
		}
		// -----------------------------------------
		// Set Post Page Levels
		function SetContentLevels($ContentType,$id,$levels){
			$wpm_levels=$this->GetOption('wpm_levels');
			$oldpost=$_POST;
			$_POST=array(
				'ContentType'=>$ContentType,
				'ID'=>array($oldpost['post_ID']=>0)
			);
			foreach(array_keys($wpm_levels) AS $key){
				if(in_array($key,$levels)){
					$_POST['Checked']=array($oldpost['post_ID']=>1);
				}else{
					unset($_POST['Checked']);
				}
				$_POST['Level']=$key;
				$this->SaveMembershipContent();
			}
			$_POST=$oldpost;
		}
		
		// -----------------------------------------
		// Return Post/Page Levels
		function GetContentLevels($ContentType,$id,$names=false){
			switch($ContentType){
				case 'categories':
					$Option='MembershipCategories';
				break;
				case 'pages':
					$Option='MembershipPages';
				break;
				case 'posts':
					$Option='MembershipPosts';
				break;
				case 'comments':
					$Option='MembershipComments';
				break;
			}
			$Content=(array)$this->GetOption($Option);
			$levels=array();
			foreach(array_keys($Content) AS $key){
				if(strpos(','.$Content[$key].',',",{$id},")!==false){
					$levels[]=$key;
				}
			}
			if($names){
				$wpm_levels=$this->GetOption('wpm_levels');
				$names=array();
				foreach($levels AS $level){
					$names[]=$wpm_levels[$level]['name'];
				}
				return implode(', ',$names);
			}else{
				return $levels;
			}
		}
		
		// -----------------------------------------
		// Sync Content Data
		function SyncContent($ContentType){
			global $wpdb;
			switch($ContentType){
				case 'categories':
					$ids=get_all_category_ids();
				break;
				case 'pages':
					$ids=get_all_page_ids();
				break;
				case 'posts':
				case 'comments':
					$ids=$wpdb->get_col("SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_type`='post'");
				break;
				default:
					$ids='';
			}
			if($ids==='')return false;
			$Content=$this->GetMembershipContent($ContentType);
			$echo=0;
			foreach(array_keys($Content) AS $k){
				if($Content[$k]){
					$x=array_intersect($Content[$k],$ids);
					$Checked=count($x)?wlm_array_combine($x,array_fill(0,count($x),1)):array();
					$ID=count($Content[$k])?wlm_array_combine($Content[$k],array_fill(0,count($Content[$k]),0)):array();
					$data=array(
						'ContentType'=>$ContentType,
						'Checked'=>$Checked,
						'ID'=>$ID,
						'Level'=>$k
					);
					$this->SaveMembershipContent($data);
				}
			}
		}
		
		// -----------------------------------------
		// Set/Get Post/Page Protection
		function Protect($id,$value=''){
			$Protect=explode(',',$this->GetOption('Protect'));
			if($value){
				switch(strtoupper($value)){
					case 'Y':
						$Protect[]=$id;
					break;
					case 'N':
						$key=array_search($id,$Protect);
						if($key!==false)unset($Protect[$key]);
					break;
				}
				$Protect=array_unique($Protect);
				$this->SaveOption('Protect',implode(',',$Protect));
			}
			return in_array($id,$Protect);
		}
	
		// -----------------------------------------
		// Save Member Data
		function SaveMembersData(){
			extract($_POST);
			$members=(array)$this->GetOption('Members');
			$wpm_levels=$this->GetOption('wpm_levels');
			
			if($wpm_member_id){
				if((int)$wpm_membership_to){
					// change membership level
					if($wpm_change_membership){
						foreach($wpm_member_id AS $id){
							$this->SetMembershipLevels($id,$wpm_membership_to);
						}
						$members=(array)$this->GetOption('Members');
						$_POST['msg']='<b>Selected members MOVED to '.$wpm_levels[$wpm_membership_to]['name'].'.</b>';
					}
					
					// add to membership level
					if($wpm_add_membership){
						foreach($wpm_member_id AS $id){
							$levels=$this->GetMembershipLevels($id);
							$levels[]=$wpm_membership_to;
							$this->SetMembershipLevels($id,array_unique($levels));
						}
						$members=(array)$this->GetOption('Members');
						$_POST['msg']='<b>Selected members ADDED to '.$wpm_levels[$wpm_membership_to]['name'].'.</b>';
					}
					
					// remove membership level
					if($wpm_del_membership){
						foreach($wpm_member_id AS $id){
							$levels=$this->GetMembershipLevels($id);
							$levels=array_diff($levels,(array)$wpm_membership_to);
							$this->SetMembershipLevels($id,array_unique($levels));
						}
						$members=(array)$this->GetOption('Members');
						$_POST['msg']='<b>Selected members Removed from '.$wpm_levels[$wpm_membership_to]['name'].'.</b>';
					}
					
					// cancel/uncancel membership level
					if($wpm_cancel_membership || $wpm_uncancel_membership){
						$status=$wpm_cancel_membership?true:false;
						$this->LevelCancelled($wpm_membership_to,$wpm_member_id,$status);
						$_POST['msg']='<b>Selected members Cancelled from '.$wpm_levels[$wpm_membership_to]['name'].'.</b>';
					}
				}
				
				// set as pending
				if($wpm_pending_selected){
					$members['pending']=implode(',',array_unique(array_merge(explode(',',$members['pending']),$wpm_member_id)));
					$_POST['msg']='<b>Selected members marked as PENDING.</b>';
				}
				
				// set as active
				if($wpm_approve_selected){
					$m=",{$members[pending]},";
					$ids=$wpm_member_id;
					foreach($ids AS $key=>$id)$ids[$key]=",{$id},";
					$m=str_replace($ids,',',$m);
					$members['pending']=substr($m,1,-1);
					$_POST['msg']='<b>Selected members marked as ACTIVE.</b>';
				}
				
				// turn off sequential upgrade
				if($wpm_disable_sequential){
					$members['nonsequential']=implode(',',array_unique(array_merge(explode(',',$members['nonsequential']),$wpm_member_id)));
					$_POST['msg']='<b>Sequential Upgrade DISABLED for selected members.</b>';
				}
				
				// turn on sequential upgrade
				if($wpm_enable_sequential){
					$m=",{$members[nonsequential]},";
					$ids=$wpm_member_id;
					foreach($ids AS $key=>$id)$ids[$key]=",{$id},";
					$m=str_replace($ids,',',$m);
					$members['nonsequential']=substr($m,1,-1);
					$_POST['msg']='<b>Sequential Upgrade ENABLED for selected members.</b>';
				}
				
				// make sure we don't have double commas and commas in the beginning and the end
				foreach(array_keys($members) AS $key) $members[$key]=trim(preg_replace(array('/^,/','/,$/','/,,/'),'',$members[$key]));
				
				// delete selected members
				if($wpm_delete_member){
					require_once(ABSPATH.'/wp-admin/includes/user.php');
					foreach($wpm_member_id AS $id){
						if($id>1)wp_delete_user($id,1);
					}
					$_POST['msg']='<b>Selected members DELETED.</b>';
				}
				
				// synchronize membership
				$this->SaveOption('Members',$members);
			}
			$this->SyncMembership();
		}
		
		// -----------------------------------------
		// Check Member for Pending Status
		function IsPending($id){
			$members=$this->GetOption('Members');
			return strpos(",{$members[pending]},",",{$id},")!==false;
		}
		
		// -----------------------------------------
		// Return Number of Pending Members
		function PendingCount(){
			$members=$this->GetOption('Members');
			return $members['pending']?substr_count($members['pending'],',')+1:0;
		}
		
		// -----------------------------------------
		// Return Number of Non Members
		function NonMemberCount(){
			global $wpdb;
			// total users in database
			$x=$wpdb->get_var("SELECT COUNT(*) FROM `{$wpdb->users}`");
			// total users as members
			$y=$this->MemberCount();
			return $x-$y;
		}
		
		// -----------------------------------------
		// Return Number Members
		function MemberCount(){
			return count($this->MemberIDs(true));
		}
		
		// -----------------------------------------
		// Return Number Members
		function MemberIDs($nozero=false){
			$members=$this->GetOption('Members');
			unset($members['pending']);
			unset($members['nonsequential']);
			
			$y=array();
			foreach($members AS $m){
				if($m){
					$m=@explode(',',$m);
					$y=array_merge($y,$m);
				}
			}
			$y[]=0;
			$y=array_unique($y);
			$key=array_search('',$y);
			if($key!==false)unset($y[$key]);
			
			if($nozero){
				$key=array_search(0,$y);
				if($key!==false)unset($y[$key]);
			}
			
			return $y;
		}
		
		// -----------------------------------------
		// Sync Membership Count
		function SyncMembership(){
			global $wpdb;
			$members=$this->GetOption('Members');
			$wpm_levels=$this->GetOption('wpm_levels');
			$ids=$wpdb->get_col("SELECT `ID` FROM `{$wpdb->users}`");
			foreach(array_keys($members) AS $k){
				$members[$k]=implode(',',$x=array_intersect(explode(',',$members[$k]),$ids));
				if(isset($wpm_levels[$k]) && (int)$k){
					$wpm_levels[$k]['count']=count($x);
				}
			}
			$this->SaveOption('Members',$members);
			$this->SaveOption('wpm_levels',$wpm_levels);
		}
		
		// -----------------------------------------
		// Check Member for Sequential Upgrade Status
		function IsSequential($id){
			$members=$this->GetOption('Members');
			return !(strpos(",{$members[nonsequential]},",",{$id},")!==false);
		}
		
		// -----------------------------------------
		// Save Sequential Config
		function SaveSequential(){
			extract($_POST);
			$wpm_levels=$this->GetOption('wpm_levels');
			foreach($upgradeTo AS $key=>$value){
				$wpm_levels[$key]['upgradeTo']=$value;
				$wpm_levels[$key]['upgradeMethod']=$upgradeMethod[$key];
				$wpm_levels[$key]['upgradeAfter']=$value?$upgradeAfter[$key]:'0';
			}
			$this->SaveOption('wpm_levels',$wpm_levels);
			$_POST['msg']='Sequential Delivery Configuration Updated';
		}
		
		// -----------------------------------------
		// Return Member's Membership Levels
		function GetMembershipLevels($id,$names=false){
			$members=$this->GetOption('Members');
			unset($members['pending']);
			unset($members['nonsequential']);
			$levels=array();
			foreach(array_keys((array)$members) AS $key){
				if(strpos(','.$members[$key].',',",{$id},")!==false){
					$levels[]=$key;
				}
			}
			if($names){
				$wpm_levels=$this->GetOption('wpm_levels');
				$names=array();
				foreach($levels AS $level){
					$name=$wpm_levels[$level]['name'];
					if($this->LevelCancelled($level,$id)){
						$name='<strike>'.$name.'</strike>';
					}
					$names[]=$name;
				}
				return implode(', ',$names);
			}else{
				return $levels;
			}
		}
		
		// -----------------------------------------
		// Set Member's Membership Levels
		function SetMembershipLevels($id,$levels){
			$levels=array_unique((array)$levels);
			$current_levels=$this->GetMembershipLevels($id);
			$removed_levels=array_diff($current_levels,$levels);
			$new_levels=array_diff($levels,$current_levels);

			$wpm_levels=$this->GetOption('wpm_levels');
			foreach($levels AS $levelkey=>$level){
				if(!$wpm_levels[$level]){
					unset($levels[$levelkey]);
				}
			}
			$members=$this->GetOption('Members');
			
			// remove pending and nonsequential for now...
			$pending=$members['pending'];
			$nonsequential=$members['nonsequential'];
			unset($members['pending']);
			unset($members['nonsequential']);
			
			// add timestamp for level
			$ts=$this->UserLevelTimestamp($id);
			foreach($levels AS $level){
				if(!$ts[$level]){
					$ts[$level]=time();
				}
			}
			$this->UserLevelTimestamp($id,$ts);
			
			// remove from all levels
			foreach(array_keys((array)$members) AS $key){
				$members[$key]=substr(str_replace(','.$id.',',',',','.$members[$key].','),1,-1);
			}
			// add to specified levels
			foreach($levels AS $level){
				$members[$level].=','.$id;
			}
			
			// put back pending and nonsequential...
			$members['pending']=$pending;
			$members['nonsequential']=$nonsequential;
			$this->SaveOption('Members',$members);
			
			// autoresponder
			$usr=get_userdata($id);
			if($usr->ID){
				// unsubscribe from autoresponder
				foreach($removed_levels AS $rl){
					$this->ARUnsubscribe($usr->first_name,$usr->last_name,$usr->user_email,$rl);
				}
				// subscribe to autoresponder
				foreach($new_levels AS $nl){
					if(!$this->LevelCancelled($nl,$id)){
						$this->ARSubscribe($usr->first_name,$usr->last_name,$usr->user_email,$nl);
					}
				}
			}
			$this->SyncMembership();
		}
		
		// -----------------------------------------
		// Set Member's Membership Levels Timestamp
		function UserLevelTimestamp($id,$levels=''){
			if(is_array($levels)){
				foreach($levels AS $key=>$ts){
					$u=new WP_User($id);
					if($ts<strtotime($u->user_registered)) $levels[$key]=time();
				}
				update_usermeta($id,'wpm_leveltimestamp',$levels);
			}
			$ts=get_usermeta($id,'wpm_leveltimestamp');
			if(!is_array($ts)){
				$levels=$this->GetMembershipLevels($id);
				$ts=wlm_array_combine($levels,array_fill(0,count($levels),$ts));
				update_usermeta($current_user->ID,'wpm_leveltimestamp',$ts);
			}
			return $ts;
		}
		
		// -----------------------------------------
		// Move Membership
		function MoveMembership(){
			extract($_POST);
			$members=$this->GetOption('Members');
			$wpm_levels=$this->GetOption('wpm_levels');
			if($wpm_move || $wpm_add){
				$members[$wpm_to].=','.$members[$wpm_from];
				if($wpm_move){
					$members[$wpm_from]='';
					$wpm_levels[$wpm_from]['count']=0;
				}
				if($members[$wpm_to][0]==',')$members[$wpm_to]=substr($members[$wpm_to],1);
				$members[$wpm_to]=trim($members[$wpm_to]);
				if($members[$wpm_to]){
					$members[$wpm_to]=implode(',',array_unique(explode(',',$members[$wpm_to])));
					$wpm_levels[$wpm_to]['count']=substr_count($members[$wpm_to],',')+1;
				}
				$_POST['msg']='<b>Membership level access updated.</b>';
				$this->SaveOption('wpm_levels',$wpm_levels);
				$this->SaveOption('Members',$members);
			}
		}
		
		// -----------------------------------------
		// New User Registration
		function WPMRegister($data,&$wpm_errmsg,$sendmail=true,$notifyadmin=true){
			require_once(ABSPATH.WPINC.'/pluggable.php');
			require_once(ABSPATH.WPINC.'/registration.php');
			$wpm_levels=$this->GetOption('wpm_levels');
			$blacklist=$this->CheckBlackList($data['email']);
			if(!$blacklist){
				if(trim($data['username'])){
					if(is_null(username_exists($data['username']))){
						if(trim($data['firstname'] && trim($data['lastname']))){
							if(trim($data['email'])){
								if(email_exists($data['email'])===false){
									if(strlen(trim($data['password1']))>=8 && trim($data['password1'])==$data['password1']){
										if($data['password1']==$data['password2']){
											$userdata=array(
												'user_pass'=>trim($data['password1']),
												'user_login'=>trim($data['username']),
												'user_email'=>trim($data['email']),
												'first_name'=>trim($data['firstname']),
												'last_name'=>trim($data['lastname']),
												'display_name'=>trim($data['firstname']).' '.trim($data['lastname'])
											);

											$id=wp_insert_user($userdata);

											// user role subscriber,contributor,author,editor
											if($wpm_levels[$data['wpm_id']]['role'] && $id>0){
												$role=$wpm_levels[$data['wpm_id']]['role'];
												$x=new WP_User($id);
												$x->set_role($role);
												unset($x);
											}

											if($id>0) {
												// save registration IP
												update_usermeta($id,'wpm_registration_ip',$_SERVER['REMOTE_ADDR']);
												// add new member to right level
												$this->SetMembershipLevels($id,$data['wpm_id']);
												
												//save address
												update_usermeta($id,'wpm_useraddress',$_POST['wpm_useraddress']);
												
												// update level count
												$wpm_levels[$data['wpm_id']]['count']++;
												
												// set status (pending/active)
												$members=$this->GetOption('Members');
												$x=(int)$this->GetOption('pending_period');
												if($x>0){
													if(!$members['pending']){
														$members['pending']=$id;
													}else{
														$members['pending'].=','.$id;
													}
												}
												
												$this->SaveOption('Members',$members);
												$this->SaveOption('wpm_levels',$wpm_levels);
												
												$macros=array(
													'firstname'=>trim($data['firstname']),
													'lastname'=>trim($data['lastname']),
													'email'=>trim($data['email']),
													'username'=>trim($data['username']),
													'password'=>trim($data['password1']),
													'memberlevel'=>trim($wpm_levels[$data['wpm_id']]['name'])
												);
												if($sendmail){
													$this->SendMail($data['email'],$this->GetOption('register_email_subject'),$this->GetOption('register_email_body'),$macros);
												}
												if($notifyadmin){
													if($this->GetOption('notify_admin_of_newuser')){
														$this->SendMail($this->GetOption('newmembernotice_email_recipient'),$this->GetOption('newmembernotice_email_subject'),$this->GetOption('newmembernotice_email_message'),$macros);
													}
												}
												if($_POST['wpmtheadminkhas78ajd']!='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$'){
													$this->WPMAutoLogin($id);
												}
												
												return $id;
											}else{
												$wpm_errmsg='An unknown error occured.  Please try again.';
											}
										}else{
											$wpm_errmsg='The passwords you entered do not match.';
										}
									}else{
										$wpm_errmsg='Password has to be at least 8 characters long and must not contain spaces.';
									}
								}else{
									$wpm_errmsg='The email you entered is already in our database.';
								}
							}else{
								$wpm_errmsg='Please enter your email address.';
							}
						}else{
							$wpm_errmsg='Please enter your first name and your last name.';
						}
					}else{
						$wpm_errmsg='The username you chose already exists.  Please try another one.';
						if($_GET['reg']) $wpm_errmsg.='<br /><br />If you are already a member and are upgrading your membership access, please click the "Existing Members" link below.';
					}
				}else{
					$wpm_errmsg='Please enter a username';
				}
			}else{
				switch($blacklist){
					case 1:
						$wpm_errmsg=$this->GetOption('blacklist_email_message');
					break;
					case 2:
						$wpm_errmsg=$this->GetOption('blacklist_ip_message');
					break;
					case 3:
						$wpm_errmsg=$this->GetOption('blacklist_email_ip_message');
					break;
				}
			}
			return false;
		}
		
		// -----------------------------------------
		// Existing Member Registration
		function WPMRegisterExisting($data,&$wpm_errmsg,$sendmail=true,$notifyadmin=true){
			$blacklist=0;
			if($data['wpmtheadminkhas78ajd']=='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$'){
				$validuser=username_exists($data['username']);
				$data['password']='User your current password';
			}else{
				$validuser=wp_login($data['username'],$data['password']);
				if($validuser){
					$user=new WP_User($data['username']);
					$blacklist=$this->CheckBlackList($user->user_email);
				}
			}
			if(!$blacklist){
				if($validuser){
					$wpm_levels=$this->GetOption('wpm_levels');
					$levels=$this->GetMembershipLevels($user->ID);
					$levels[]=$data['wpm_id'];
					$this->SetMembershipLevels($user->ID,$levels);
					
					$macros=array(
						'firstname'=>trim($user->first_name),
						'lastname'=>trim($user->last_name),
						'email'=>trim($user->user_email),
						'username'=>trim($user->user_login),
						'password'=>$data['password'],
						'memberlevel'=>trim($wpm_levels[$data['wpm_id']]['name'])
					);
					if($sendmail){
						$this->SendMail($user->user_email,$this->GetOption('register_email_subject'),$this->GetOption('register_email_body'),$macros);
					}
					if($notifyadmin){
						if($this->GetOption('notify_admin_of_newuser')){
							$this->SendMail($this->GetOption('newmembernotice_email_recipient'),$this->GetOption('newmembernotice_email_subject'),$this->GetOption('newmembernotice_email_message'),$macros);
						}
					}
					
					if($data['wpmtheadminkhas78ajd']!='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$'){
						$this->WPMAutoLogin($user->ID);
					}
					
					return $user->ID;
				}else{
					$wpm_errmsg='Invalid username and/or password.';
					return false;
				}
			}else{
				switch($blacklist){
					case 1:
						$wpm_errmsg=$this->GetOption('blacklist_email_message');
					break;
					case 2:
						$wpm_errmsg=$this->GetOption('blacklist_ip_message');
					break;
					case 3:
						$wpm_errmsg=$this->GetOption('blacklist_email_ip_message');
					break;
				}
				return false;
			}
		}
		
		// -----------------------------------------
		// sets the current user - called by WPMRegister and WPMRegisterExisting
		function WPMAutoLogin($id){
			$x=new WP_User($id);
			wp_set_auth_cookie($id);
			// save login IP
			update_usermeta($id,'wpm_login_ip',$_SERVER['REMOTE_ADDR']);
			update_usermeta($id,'wpm_login_date',time()-get_option('gmt_offset')*3600);
		}
		
		// -----------------------------------------
		// Import Members
		function ImportMembers(){
			if(is_uploaded_file($_FILES['File']['tmp_name'])){
				$wpm_levels=$this->GetOption('wpm_levels');
				$f=fopen($_FILES['File']['tmp_name'],'r');
				$errmsgs=array();
				$imports=$duplicates=$errors=$row=0;
				$_POST['wpm_id']=$_POST['wpm_to'];
				while(($data=fgetcsv($f,1024))!==false){
					set_time_limit(30);
					$row++;
					foreach($data AS $k=>$v)$data[$k]=trim($v);
					list($uname,$fname,$lname,$email,$password)=$data;
					if($uname && $fname && $lname && $email && strtolower($uname)!='username' && strpos($email,'@')){
						$_POST['firstname']=$fname;
						$_POST['lastname']=$lname;
						$_POST['username']=$uname;
						$_POST['email']=$email;
						$notify=$_POST['notify']+0;
						if(!$password){
							if($_POST['password']){
								$password=$_POST['password'];
							}else{
								$password=$this->PassGen();
								$notify=1;
							}
						}
						$_POST['password1']=$_POST['password2']=$password;
						
						// tell that we're admin so no autologin happens
						$_POST['wpmtheadminkhas78ajd']='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$';
						
						if($this->WPMRegister($_POST,&$wpm_errmsg,(bool)$notify,false)){
							$imports++;
						}else{
							if($_POST['duplicates']){
								$members=$this->GetOption('Members');
								$user=new WP_User($uname);
								if(!$user)$user=new WP_User($email);
								$user=$user->ID;
								foreach(array_keys($members) AS $mkey){
									$members[$mkey]=substr(str_replace(",{$user},",',',','.$members[$mkey].','),1,-1);
								}
								if(!$members[$_POST['wpm_to']]){
									$members[$_POST['wpm_to']]=$user;
								}else{
									$members[$_POST['wpm_to']].=",{$user}";
								}
								$this->SaveOption('Members',$members);
							}
							$duplicates++;
						}
					}else{
						$errors++;
						$errmsgs[]="Incomplete data on row #{$row}.";
					}
				}
				fclose($f);
				$dupmsg=$_POST['duplicates']?'users moved to Membership Level '.$wpm_levels[$_POST['wpm_to']]['name']:'duplicates ignored';
				$_POST['msg']="{$imports} new users imported.<br />{$duplicates} {$dupmsg}.<br />{$errors} errors encountered.<br />{$row} total rows processed.";
				if($errors) $_POST['err']="<b>Errors</b><br />".implode('<br />',$errmsgs);
				
				// synchronize membership
				$this->SyncMembership();
			}
		}
		
		// -----------------------------------------
		// Export Members
		function ExportMembers(){
			extract($_POST);
			if($wpm_to){
				$wpm_levels=$this->GetOption('wpm_levels');
				$ids=$this->GetOption('Members');
				$ids=$ids[$wpm_to];
				$ids=array_unique(explode(',',$ids));
				$fname='members_'.preg_replace('/[^a-z0-9]/i','',$wpm_levels[$wpm_to]['name']).'.csv';
			}else{
				$ids='';
				$fname='members_All.csv';
			}
			$wp_user_search=new WishListMemberUserSearch('','','',$ids,'user_login','ASC','');
			header("Content-type:text/csv");
			header("Content-disposition: attachment; filename=".$fname);
			if($wp_user_search->total_users_for_query){
				foreach($wp_user_search->results AS $uid){
					$user=get_userdata($uid);
					$data=array(
						$user->user_login,
						$user->first_name,
						$user->last_name,
						$user->user_email,
						'',
						$this->GetMembershipLevels($uid,true)
					);
					echo '"'.implode('","',str_replace('"','""',$data)).'"'."\n";
				}
			}
			exit;
		}
		
		// -----------------------------------------
		// Sample Import CSV
		function SampleImportCSV(){
			header("Content-type:text/csv");
			header("Content-disposition: attachment; filename=import_file_template.csv");
			echo "\"UserName\",\"FirstName\",\"LastName\",\"Email\",\"Password (Optional)\"\n";
			exit;
		}
		
		// -----------------------------------------
		// Email Function
		function SendMail($recipient,$subject,$body,$data){
			$data['loginurl']=get_bloginfo('wpurl').'/wp-login.php';
			$search=array_keys($data);
			$header='Content-Type: text/plain; charset='.$this->BlogCharset."\n";
			
			foreach($search AS $k=>$v)$search[$k]='['.$v.']';
			$tries=3;
			
			$mailed=false;
			while($tries-- && !$mailed) $mailed=wp_mail($recipient,str_replace($search,$data,$subject),str_replace($search,$data,$body),$header);
		}
		
		// -----------------------------------------
		// Form Values Functions
		function Checked($value1,$value2){
			$string=' checked="true" ';
			if(is_array($value2)){
				if(in_array($value1,$value2)) echo $string;
			}else{
				if($value1==$value2) echo $string;
			}
		}
		function Selected($value1,$value2){
			$string=' selected="true" ';
			if(is_array($value2)){
				if(in_array($value1,$value2)) echo $string;
			}else{
				if($value1==$value2) echo $string;
			}
		}
		function Value($value,$default){
			if(!$value)$value=$default;
			echo htmlentities($value,ENT_QUOTES);
		}
		
		// -----------------------------------------
		// Sort Levels By Name
		function SortLevels(&$wpm_levels,$sortorder){
			$names=array();
			foreach($wpm_levels AS $key=>$level){
				$wpm_levels[$key]['key']=$key;
				$names[$key]=$level['name'];
			}
			$ls=$wpm_levels;
			array_multisort($names,$sortorder=='d'?SORT_DESC:SORT_ASC,$ls);
			$wpm_levels=array();
			foreach($ls AS $l){
				$key=$l['key'];
				unset($l['key']);
				$wpm_levels[$key]=$l;
			}
		}
		
		// -----------------------------------------
		// Return list of Magic Pages
		function MagicPage($link=true){
			$wpmpage=$this->GetOption('magic_page');
			if(!get_page($wpmpage)){
				$wpmpage=wp_insert_post(
					array(
						'post_title'=>'WishList Member',
						'post_content'=>'<p>This page is auto-generated by the WishList Member Plugin. Do not delete this page.</p>',
						'post_status'=>'publish',
						'post_author'=>'1',
						'post_type'=>'page'
					)
				);
				$this->SaveOption('magic_page',$wpmpage);
			}
			if($link){
				return get_permalink($wpmpage);
			}else{
				return $wpmpage;
			}
		}
		
		// -----------------------------------------
		// The Feed Key
		function FeedKey($id=null){
			$wpm_current_user=wp_get_current_user();
			$public='';
			if(is_null($id)){
				$user=$wpm_current_user;
			}else{
				$user=new WP_User($id);
			}
			if($user->ID){
				$sk=$this->GetOption('rss_secret_key');
				$public=$user->ID.';'.md5($user->ID.';'.implode(',',$this->GetMembershipLevels($user->ID)).';'.$sk);
			}
			return $public;
		}

		// -----------------------------------------
		// Check for Category Protection Status
		function CatProtected($id){
			$Protect=explode(',',$this->GetOption('CatProtect'));
			return !in_array($id,$Protect);
		}
		
		// -----------------------------------------
		// Generate Password
		function PassGen(){
			return implode('',array_rand(array_flip(array_merge(range('A','Z'),range('a','z'),range(0,9))),8));
		}

		// -----------------------------------------
		// Get Unsubscribe Confirmation URL
		function UnsubscribeURL(){
			$url=$this->GetOption('unsubscribe_internal');
			$url=$url?get_permalink($url):$this->GetOption('unsubscribe');
			return $url;
		}

		// -----------------------------------------
		// Get Non-Members URL
		function NonMembersURL(){
			$url=$this->GetOption('non_members_error_page_internal');
			$url=$url?get_permalink($url):$this->GetOption('non_members_error_page');
			if(!$url)$url=get_bloginfo('url');
			return $url;
		}

		// -----------------------------------------
		// Get Wrong Level URL
		function CancelledURL(){
			$url=$this->GetOption('membership_cancelled_internal');
			$url=$url?get_permalink($url):$this->GetOption('membership_cancelled');
			if(!$url)$url=get_bloginfo('url');
			return $url;
		}

		// -----------------------------------------
		// Get Wrong Level URL
		function WrongLevelURL(){
			$url=$this->GetOption('wrong_level_error_page_internal');
			$url=$url?get_permalink($url):$this->GetOption('wrong_level_error_page');
			if(!$url)$url=get_bloginfo('url');
			return $url;
		}

		// -----------------------------------------
		// Cancel a user's membership level
		function LevelCancelled($level,$uid,$status=null){
			$cancel=(array)$this->GetOption('Cancelled');
			$uid=(array)$uid;
			$time=time();
			$uidt=array();
			if(!is_null($status)){
				$c=explode(',',$cancel[$level]);
				if($status){
					foreach($uid AS $u){
						$clevels=$this->GetMembershipLevels($u);
						if(in_array($level,$clevels)){
							$uidt[]=$u.';'.$time;
							
							// unsubscribe from AR
							if(preg_match('/,'.$u.';[0-9]*,/',','.$cancel[$level].',')<1){
								$usr=get_userdata($u);
								if($usr->ID) $this->ARUnsubscribe($usr->first_name,$usr->last_name,$usr->user_email,$level);
							}
						}
					}
					$c=array_merge($c,$uidt);
				}else{
					$uidt=array();
					foreach($uid AS $u){
						$clevels=$this->GetMembershipLevels($u);
						if(in_array($level,$clevels)){
							if(preg_match('/,('.$u.';([0-9]*)),/',','.$cancel[$level].',',$match)){
								$ts=$this->UserLevelTimestamp($u);
								$ts[$level]=$time-($match[2]-$ts[$level]);
								$this->UserLevelTimestamp($u,$ts);
								$uidt[]=$match[1];
								
								// subscribe to AR
								$usr=get_userdata($u);
								if($usr->ID) $this->ARSubscribe($usr->first_name,$usr->last_name,$usr->user_email,$level);
							}
						}
					}
					$c=array_diff($c,$uidt);
				}
				$cancel[$level]=implode(',',array_unique($c));
				$this->SaveOption('Cancelled',$cancel);
			}
			list($uid)=$uid;
			return(preg_match('/,'.$uid.';[0-9]*,/',','.$cancel[$level].',')>0);
		}

		// -----------------------------------------
		// Shopping Cart Registration
		function ShoppingCartRegistration(){
			// expects values in $_POST
			$wpm_levels=$this->GetOption('wpm_levels');
			if(isset($wpm_levels[$_POST['wpm_id']])){
				$wpm_errmsg='';
				$registered=$this->WPMRegister($_POST,$wpm_errmsg);
				if(!$registered){
					$xid=email_exists($_POST['email']);
					if(!$xid)$xid=username_exists($_POST['username']);
					if($xid){
						$_POST['wpmtheadminkhas78ajd']='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$';
						$this->WPMRegisterExisting($_POST,$wpm_errmsg);
						$registered=true;
					}
				}
				if($registered){
					// uncancel "cancelled" members when they "re-pay"
					$this->ShoppingCartReactivate();
				}
				// redirect to "processing" page
				$url=$this->MagicPage();
				$qe=strpos($url,'?')===false?'?':'&';
				header("Location:".$url.$qe.'reg='.$_POST['wpm_id'].'&registered=1');
				exit;
			}else{
				// we got an invalid membership level ID
				header("Location:".get_bloginfo('url'));
				exit;
			}
		}

		// -----------------------------------------
		// Shopping Cart Membership De-activation
		function ShoppingCartDeactivate(){
			// expects values in $_POST
			// add member to level's cancelled list
			$wpm_levels=$this->GetOption('wpm_levels');
			$user=new WP_User($_POST['username']);
			if($user){
				$levels=$this->GetMembershipLevels($user->ID);
				foreach($levels AS $level){
					if(!$wpm_levels[$level]['isfree']){
						$this->LevelCancelled($level,$user->ID,true);
					}
				}
				return true;
			}
			header("Location:".get_bloginfo('url')); exit;
		}

		// -----------------------------------------
		// Shopping Cart Membership Re-activation
		function ShoppingCartReactivate(){
			// expects values in $_POST
			// remove member from level's cancelled list
			$user=new WP_User($_POST['username']);
			if($user){
				$levels=$this->GetMembershipLevels($user->ID);
				foreach($levels AS $level){
					$this->LevelCancelled($level,$user->ID,false);
				}
				return true;
			}
			header("Location:".get_bloginfo('url')); exit;
		}

		// -----------------------------------------
		// Redirects to the correct Level Registration URL
		function RegistrationURL(){
			$levels=$this->GetOption('wpm_levels');
			$reg=explode('/register/',$_SERVER['REQUEST_URI']);
			list($reg)=split('[\?&/]',$reg[1]);
			foreach($levels AS $id=>$level){
				if($level['url']==$reg){
					$redir=$this->GetRegistrationURL($id);
					header("Location:".$redir);
					exit;
				}
			}
			return $reg;
		}
		function GetRegistrationURL($id){
			$redir=$this->MagicPage();
			$qe=strpos($redir,'?')===false?'?':'&';
			$redir.=$qe.'reg='.$id;
			return $redir;
		}

		// -----------------------------------------
		// 1ShoppingCart Registration
		function OneShoppingCart(){
			if(in_array(strtolower(trim($_POST['status'])),array('accepted','approved'))){
				if(!trim($_POST['name']))$_POST['name']='Firstname Lastname';
				$name=explode(' ',$_POST['name']);
				$_POST['lastname']=array_pop($name);
				$_POST['firstname']=implode(' ',$name);
				$_POST['action']='wpm_register';
				$_POST['wpm_id']=$_POST['sku1'];
				$_POST['username']=$_POST['email1'];
				$_POST['email']=$_POST['email1'];
				$_POST['password1']=$_POST['password2']=$this->PassGen();
				
				$address=array();
				$address['company']=$_POST['shipCompany'];
				$address['address1']=$_POST['shipAddress1'];
				$address['address2']=$_POST['shipAddress2'];
				$address['city']=$_POST['shipCity'];
				$address['state']=$_POST['shipState'];
				$address['zip']=$_POST['shipZip'];
				$address['country']=$_POST['shipCountry'];

				$_POST['wpm_useraddress']=$address;

				$this->ShoppingCartRegistration();
			}
		}
		
		// -----------------------------------------
		// QuickPayPro
		function QuickPayPro(){
			$cmd=$_POST['cmd']['cmd'];
			$hash=$_POST['hash']['hash'];
			$secret=$this->GetOption('qppsecret');
			$myhash=md5($cmd.'__'.$secret);
			$_POST['action']='wpm_register';
			$_POST['lastname']=$_POST['info']['last_name'];
			$_POST['firstname']=$_POST['info']['first_name'];
			$_POST['wpm_id']=$_POST['info']['level'];
			$_POST['username']=$_POST['info']['email'];
			$_POST['email']=$_POST['info']['email'];
			$_POST['password1']=$_POST['password2']=$this->PassGen();
			if($hash==$myhash){
				add_filter('rewrite_rules_array',array(&$this,'RewriteRules'));
				$GLOBALS['wp_rewrite']->flush_rules();
				switch($cmd){
					case 'add':
						$this->ShoppingCartRegistration();
					break;
					case 'delete':
					case 'deactivate':
						$this->ShoppingCartDeactivate();
					break;
					case 'activate':
						$this->ShoppingCartReactivate();
					break;
					default:
						header("Location:".get_bloginfo('url'));
						exit;
				}
			}
		}
		
		// -----------------------------------------
		// ClickBank
		function ClickBank(){
			$key=$this->GetOption('cbsecret');
			$rcpt=$_REQUEST['cbreceipt'];
			$time=$_REQUEST['time'];
			$item=$_REQUEST['item'];
			$cbpop=$_REQUEST['cbpop'];
			$xxpop=sha1("$key|$rcpt|$time|$item");
			$xxpop=strtoupper(substr($xxpop,0,8));
			if($cbpop==$xxpop){
				if(!trim($_REQUEST['cname']))$_REQUEST['cname']='Firstname Lastname';
				$name=explode(' ',$_REQUEST['cname']);
				$_POST['lastname']=array_pop($name);
				$_POST['firstname']=implode(' ',$name);
				$_POST['action']='wpm_register';
				$_POST['wpm_id']=$_REQUEST['sku'];
				$_POST['username']=$_REQUEST['cemail'];
				$_POST['email']=$_REQUEST['cemail'];
				$_POST['password1']=$_POST['password2']=$this->PassGen();

				add_filter('rewrite_rules_array',array(&$this,'RewriteRules'));
				$GLOBALS['wp_rewrite']->flush_rules();

				$this->ShoppingCartRegistration();
			}else{
				$key=$this->GetOption('cbsecret');
				$ccustname=$_REQUEST['ccustname'];
				$ccustemail=$_REQUEST['ccustemail'];
				$ccustcc=$_REQUEST['ccustcc'];
				$ccuststate=$_REQUEST['ccuststate'];
				$ctransreceipt=$_REQUEST['ctransreceipt'];
				$cproditem=$_REQUEST['cproditem'];
				$ctransaction=$_REQUEST['ctransaction'];
				$ctransaffiliate=$_REQUEST['ctransaffiliate'];
				$ctranspublisher=$_REQUEST['ctranspublisher'];
				$cprodtype=$_REQUEST['cprodtype'];
				$cprodtitle=$_REQUEST['cprodtitle'];
				$ctranspaymentmethod=$_REQUEST['ctranspaymentmethod'];
				$ctransamount=$_REQUEST['ctransamount'];
				$caffitid=$_REQUEST['caffitid'];
				$cvendthru=$_REQUEST['cvendthru'];
				$cbpop=$_REQUEST['cverify'];

				$xxpop=sha1("$ccustname|$ccustemail|$ccustcc|$ccuststate|$ctransreceipt|$cproditem|$ctransaction|$ctransaffiliate|$ctranspublisher|$cprodtype|$cprodtitle|$ctranspaymentmethod|$ctransamount|$caffitid|$cvendthru|$key");
				$xxpop=strtoupper(substr($xxpop,0,8));

				if($cbpop==$xxpop){
					if(!trim($_REQUEST['ccustname']))$_REQUEST['ccustname']='Firstname Lastname';
					$name=explode(' ',$_REQUEST['ccustname']);
					$_POST['lastname']=array_pop($name);
					$_POST['firstname']=implode(' ',$name);
					$_POST['action']='wpm_register';

					// the passed sku...
					$passedparams=parse_str($_REQUEST['cvendthru']);

					$_POST['wpm_id']=$passedparams['sku'];
					$_POST['username']=$_REQUEST['ccustemail'];
					$_POST['email']=$_REQUEST['ccustemail'];

					add_filter('rewrite_rules_array',array(&$this,'RewriteRules'));
					$GLOBALS['wp_rewrite']->flush_rules();

					switch($_REQUEST['ctransaction']){
						case 'SALE':
						case 'BILL':
							// we do nothing because registration is handled by the regular thank you url...
						break;
						case 'UNCANCEL-REBILL':
							$this->ShoppingCartReactivate();
						break;
						case 'RFND':
						case 'CKBK':
						case 'INSF':
						case 'CANCEL-REBILL':
							$this->ShoppingCartDeactivate();
						break;
					}

				}
			}
		}
		
		// -----------------------------------------
		// Paypal
		function Paypal(){
			// prepare validation
			$req='cmd=_notify-validate';
			foreach($_POST AS $key=>$value) $req.=('&'.$key.'='.urlencode(stripslashes($value)));
			
			// prepare postback validation
			$header="POST /cgi-bin/webscr HTTP/1.0\r\n";
			$header.="Content-Type: application/x-www-form-urlencoded\r\n";
			$header.="Content-Length: ".strlen($req)."\r\n\r\n";
			$url='ssl://www.paypal.com';
			$fp=fsockopen($url,443,$errno,$errstr,30);
			
			if($fp){
				fputs($fp,$header.$req);
				while(!feof($fp)){
					$res=fgets($fp,1024);
				}
				fclose($fp);
				if(strcmp($res,"VERIFIED")==0){
					add_filter('rewrite_rules_array',array(&$this,'RewriteRules'));
					$GLOBALS['wp_rewrite']->flush_rules();
					
					$_POST['lastname']=$_POST['last_name'];
					$_POST['firstname']=$_POST['first_name'];
					$_POST['action']='wpm_register';
					
					$_POST['wpm_id']=$_POST['item_number'];
					$_POST['username']=$_POST['payer_email'];
					$_POST['email']=$_POST['payer_email'];
					$_POST['password1']=$_POST['password2']=$this->PassGen();
					
					$status=$_POST['payment_status']?$_POST['payment_status']:$_POST['txn_type'];
					
					switch($status){
						case 'subscr_signup':
							// we have a subscription sign-up so we register it...
							$this->ShoppingCartRegistration();
							// but we deactivate it first until we receive the subscr_payment notice
							$this->ShoppingCartDeactivate();
						break;
						case 'Completed':
							if($_POST['txn_type']=='subscr_payment'){
								// we reactivate the account for any subscr_payment notice
								$this->ShoppingCartReactivate();
							}else{
								// if txn_type is not subscr_payment then it's a one-time payment so we register the user
								$this->ShoppingCartRegistration();
							}
						break;
						case 'Canceled-Reversal':
							$this->ShoppingCartReactivate();
						break;
						case 'Expired':
						case 'Failed':
						case 'Refunded':
						case 'Reversed':
						case 'subscr_cancel':
						case 'subscr_failed':
						case 'subscr_eot':
							$this->ShoppingCartDeactivate();
						break;
					}
				}else{
					// redirect to "processing" page
					$url=$this->MagicPage();
					$qe=strpos($url,'?')===false?'?':'&';
					header("Location:".$url.$qe.'reg='.$_GET['item_number'].'&registered=1');
					exit;
				}
			}
		}
		
		// -----------------------------------------
		// Registration Form
		function RegContent(){
			remove_filter('the_content','wptexturize');
			$wpm_levels=$this->GetOption('wpm_levels');
			$wpm_level_id=$_GET['reg'];
			$wpm_level=$wpm_levels[$wpm_level_id];

			$wpm_errmsg='';
			$registered=false;
			if($_POST['action']=='wpm_register'){
				$registered=$this->WPMRegister($_POST,$wpm_errmsg);
				if(!$registered){
					extract($_POST);
				}
			}elseif($_POST['action']=='wpm_register_existing'){
				$registered=$this->WPMRegisterExisting($_POST,$wpm_errmsg);
				if(!$registered){
					extract($_POST);
				}
			}

			$wpm_content_ok=true;

			$afterreg=$this->GetOption('after_registration_internal');
			$afterreg=$afterreg?get_permalink($afterreg):$this->GetOption('after_registration');
			// if no after registration url specified then set it to homepage 
			if(!$afterreg)$afterreg=get_bloginfo('url');

			if($_GET['existing']){
				$qstring=str_replace('&existing=1','',$_SERVER['QUERY_STRING']);
				$form=<<<STRING
				<p class="wpm_err">{$wpm_errmsg}</p>
				<div id="wlmreginstructions">
					<p>To complete your registration, please select one of the two options:</p>
					<ol>
						<li>New members, please <a href="?{$qstring}">click here</a>.</li>
						<li>Existing members, please fill in the form below to complete<br />your <b>{$wpm_level[name]}</b> application.</li>
					</ol>
				</div>
				<h3 style="margin:0">Existing Member Login</h3>
				<br />
				<form method="post">
					<input type="hidden" name="action" value="wpm_register_existing" />
					<input type="hidden" name="wpm_id" value="{$wpm_level_id}" />
					<table class="wpm_registration">
						<tr valign="top">
							<td><b>Username:</b>&nbsp;</td>
							<td><input type="text" name="username" value="{$username}" size="10" /></td>
						</tr>
						<tr valign="top">
							<td><b>Password:</b>&nbsp;</td>
							<td><input type="password" name="password" size="10" /></td>
						</tr>
						<tr valign="top">
							<td></td>
							<td><input type="submit" value="Login" /></td>
						</tr>
					</table>
				</form>
STRING;
			}else{
				$existingurl=$this->QueryString('existing');
				$regbefore=$this->GetOption('regpage_before');
				$regbefore=$regbefore[$wpm_level_id];
				$regafter=$this->GetOption('regpage_after');
				$regafter=$regafter[$wpm_level_id];
				$form=<<<STRING
				{$regbefore}
				<p class="wpm_err">{$wpm_errmsg}</p>
				<div id="wlmreginstructions">
					<p>To complete your registration, please select one of the two options:</p>
					<ol>
						<li>Existing members, please <a href="?{$_SERVER[QUERY_STRING]}&existing=1">click here</a>.</li>
						<li>New members, please fill in the form below to complete<br />your <b>{$wpm_level[name]}</b> application.</li>
					</ol>
				</div>
				<h3 style="margin:0">New Member Registration</h3>
				<br />
				<form method="post">
					<input type="hidden" name="action" value="wpm_register" />
					<input type="hidden" name="wpm_id" value="{$wpm_level_id}" />
					<table class="wpm_registration">
						<tr valign="top">
							<td><b>Username (required):</b>&nbsp;</td>
							<td><input type="text" name="username" value="{$username}" size="10" /></td>
						</tr>
						<tr valign="top">
							<td><b>First Name:</b>&nbsp;</td>
							<td><input type="text" name="firstname" value="{$firstname}" size="15" /></td>
						</tr>
						<tr valign="top">
							<td><b>Last Name:</b>&nbsp;</td>
							<td><input type="text" name="lastname" value="{$lastname}" size="15" /></td>
						</tr>
						<tr valign="top">
							<td><b>E-mail (required):</b>&nbsp;</td>
							<td><input type="text" name="email" value="{$email}" size="25" /></td>
						</tr>
						<tr valign="top">
							<td><b>Password (twice):</b>&nbsp;</td>
							<td><input type="password" name="password1" size="10" /></td>
						</tr>
						<tr valign="top">
							<td></td>
							<td>
								<input type="password" name="password2" size="10" />
								<br />
								<small>Password has to be at least 8 characters long<br />and must not contain spaces</small>
							</td>
						</tr>
						<tr valign="top">
							<td></td>
							<td><input type="submit" value="Submit Registration" /></td>
						</tr>
					</table>
				</form>
				{$regafter}
STRING;
			}

			$redirectcount=5;

			$welcome=<<<STRING
			<meta http-equiv="refresh" content="{$redirectcount};url={$afterreg}">
			<script type="text/javascript">
				function wlmredirect(){
					document.location='{$afterreg}';
				}
				window.setTimeout(wlmredirect,{$redirectcount}000)
			</script>
			<p>Please wait while we process your submission and kindly do not click your browser's back or refresh button.</p>
			<p><a href="{$afterreg}">Click here</a> if you are not redirected in {$redirectcount} seconds.</p>
STRING;

            if($registered||$_GET['registered']||$_POST['WLMRegHookIDs']){
                $text=apply_filters('wishlistmember_after_registration_page',$welcome,&$this);
            }else{
    			$text=$form;
            }

			$css=<<<STRING
			<style type="text/css">
			.wpm_registration{
				clear:both;
				padding:0;
				margin:10px 0;
			}
			.wpm_registration td{
				text-align:left;
			}
			.wpm_err{
				color:#f00;
				font-weight:bold;
			}
			#wlmreginstructions{
				background:#ffffdd;
				border:1px solid #ff0000;
				padding:0 1em 1em 1em;
				margin:0 auto 1em auto;
				font-size:1em;
				width:450px;
				color:#333333;
			}
			#wlmreginstructions a{
				color:#0066CC;
			}
			#wlmreginstructions ol{
				margin:0 0 0 1em;
				padding:0 0 0 1em;
			}
			#wlmreginstructions li{
				margin:0;
				padding:0;
			}
			</style>
STRING;
			return $css.$text;
		}
		
		// -----------------------------------------
		// Email Broadcast Routine
		function EmailBroadcast(){
            $include_pending=in_array('p',$_POST['otheroptions']);
            $include_cancelled=in_array('c',$_POST['otheroptions']);
            
			$members=$this->GetOption('Members');
			$cancelled=$this->GetOption('Cancelled');
			$recipients=array();
			foreach($_POST['sendto'] AS $id){
				$xmembers=explode(',',$members[$id]);
				
				// exclude cancelled levels unless specified otherwise
				if(!$include_cancelled){
					$cancel=explode(',',preg_replace('/;[0-9]*/','',$cancelled[$id]));
					$xmembers=array_diff($xmembers,$cancel);
				}
				$recipients=array_merge($recipients,$xmembers);
			}
			
			// exclude pending members unless specified otherwise
			if(!$include_pending){
				$recipients=array_diff($recipients,explode(',',$members['pending']));
			}
			
			$recipients=array_diff(array_unique($recipients),array(0));
			$data=array('loginurl'=>get_bloginfo('url'));

            // we add can spam requirements
            $canspamaddress='';
            $canspamaddress=trim($_POST['canspamaddr1'])."\n";
            if(trim($_POST['canspamaddr2']))$canspamaddress.=trim($_POST['canspamaddr2'])."\n";
            $canspamaddress.=trim($_POST['canspamcity']).", ";
            $canspamaddress.=trim($_POST['canspamstate'])."\n";
            $canspamaddress.=trim($_POST['canspamzip'])."\n";
            $canspamaddress.=trim($_POST['canspamcountry']);

            $msg=trim($_POST['message'])."\n\n".trim($_POST['signature'])."\n\n".$canspamaddress;

            // save the signature and can spam address info
            $broadcast=array();
            foreach($_POST AS $k=>$v){
                if(substr($k,0,7)=='canspam'){
                    $broadcast[$k]=$v;
                }
            }
            $broadcast['signature']=$_POST['signature'];
            $this->SaveOption('broadcast',$broadcast);
            
			foreach($recipients AS $id){
				$user=new WP_User($id);
				if($user && $user->wlm_unsubscribe!=1){
					
                    // add unsubscribe and profile links
                    $fullmsg=$msg."\n\n".sprintf(WLMCANSPAM,$user->ID.'/'.substr(md5($user->ID.WLMUNSUBKEY),0,10));

					$data['firstname']=$user->first_name;
					$data['lastname']=$user->last_name;
					$data['email']=$user->user_email;
					$data['username']=$user->user_login;
					$data['memberlevel']=strip_tags($this->GetMembershipLevels($id,true));
					$this->SendMail($user->user_email,stripslashes($_POST['subject']),stripslashes($fullmsg),$data);
				}
			}
			header("Location:".$_SERVER['REQUEST_URI'].'&msg=Message sent to members of selected levels.');
			exit;
		}
		
		// -----------------------------------------
		// Blacklist Check
		function CheckBlackList($email){
			if($_POST['wpmtheadminkhas78ajd']=='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$')return 0;
			$emails=trim($this->GetOption('blacklist_email'));
			$ips=trim($this->GetOption('blacklist_ip'));
			$return=0;
			if($emails){
				$emails=explode("\n",$emails);
				foreach($emails AS $p){
					$p='/^'.str_replace('\*','.*?',preg_quote(trim($p),'/')).'$/i';
					if(preg_match($p,$email)){
						$return+=1;
						break;
					}
				}
			}
			if($ips){
				$ips=explode("\n",$ips);
				foreach($ips AS $p){
					$p='/^'.str_replace('\*','.*?',preg_quote(trim($p),'/')).'$/i';
					if(preg_match($p,$_SERVER['REMOTE_ADDR'])){
						$return+=2;
						break;
					}
				}
			}
			return $return;
		}
		
		// -----------------------------------------
		// Login Counter.  Limits the number of different
		// IPs that can login per user per day
		function LoginCounter($user){
			$id=$user->ID;
			if($user->caps['administrator'])return true;
			$counter=get_usermeta($id,'wpm_login_counter');
			if(!is_array($counter))$counter=array();
			
			// remove counts for the previous day
			$now=date('Ymd');
			foreach($counter AS $d){
				if($d<$now)unset($counter[$d]);
			}
			
			// get user limit
			$limit=get_usermeta($id,'wpm_login_limit')+0;
			if($limit<0)return true; // <- no login limits
			
			if(!$limit){
				$limit=$this->GetOption('login_limit')+0;
			}
			
			if(count($counter)>=$limit && $limit>0 && !isset($counter[$_SERVER['REMOTE_ADDR']])){
				wp_logout();
				header("Location:".site_url('wp-login.php?loginlimit=1'));
				exit;
				return false;
			}
			
			if(!in_array($_SERVER['REMOTE_ADDR'],array_keys($counter))){
				$counter[$_SERVER['REMOTE_ADDR']]=$now;
			}

			update_usermeta($id,'wpm_login_counter',$counter);
			return true;
		}

		// -----------------------------------------
		// Registration Hook IDs
        // Used by Extensions that wish to integrate with after registration process
        function AfterRegHookID($id){
            $return='';
            if(is_array($_POST['WLMRegHookIDs'])){
                foreach($_POST['WLMRegHookIDs'] AS $RHI){
                    $return.='<input type="hidden" name="WLMRegHookIDs[]" value="'.$RHI.'" />';
                }
            }
            $return.='<input type="hidden" name="WLMRegHookIDs[]" value="'.$id.'" />';
            return $return;
        }
        
        function ARSubscribe($fname,$lname,$email,$wpm_id){
			// Autoresponder subscription
			$this->ARSender=array('name'=>"{$fname} {$lname}",'email'=>"{$email}");
			$ar=$this->GetOption('Autoresponders');
			$arp=$ar['ARProvider'];
			$ar=$ar[$arp];
			switch($arp){
				case 'aweber':
					$this->AutoResponderAweber($ar,$wpm_id,$email,false);
					break;
				case 'arp':
					$this->AutoResponderARP($ar,$wpm_id,$email,false);
					break;
			}
			$this->ARSender='';
        }
        function ARUnsubscribe($fname,$lname,$email,$wpm_id){
			$this->ARSender=array('name'=>"{$fname} {$lname}",'email'=>"{$email}");
        	$ar=$this->GetOption('Autoresponders');
			$arp=$ar['ARProvider'];
			$ar=$ar[$arp];
			switch($arp){
				case 'aweber':
					$this->AutoResponderAweber($ar,$wpm_id,$email,true);
					break;
				case 'arp':
					$this->AutoResponderARP($ar,$wpm_id,$email,true);
					break;
			}
			$this->ARSender='';
        }
        
        function AutoResponderAweber($ar,$wpm_id,$email,$unsub=false){
        	if($ar['email'][$wpm_id]){
	        	if(!$unsub){
					wp_mail($ar['email'][$wpm_id],'','');
	        	}else{
					$this->ARSender=array('name'=>"Aweber Remove",'email'=>$ar['remove'][$wpm_id]);
					$subject='REMOVE#'.$email.'#WLMember';
					wp_mail($ar['email'][$wpm_id],$subject,'');
	        	}
        	}
        }
        function AutoResponderARP($ar,$wpm_id,$email,$unsub=false){
        	if(function_exists('curl_init')){
        		$autoresponderID=$ar['arID'][$wpm_id];
        		if($autoresponderID){
					$fullName=$this->ARSender['name'];
					$emailAddress=$this->ARSender['email'];
					
					$httpAgent="ARPAgent";
					$arpURL=$ar['arpurl'];
					$postData="id={$autoresponderID}&full_name={$fullName}&split_name={$fullName}&email={$emailAddress}&subscription_type=E";
					if($unsub)$postData.='&arp_action=UNS';
					
					$ch=curl_init();
					curl_setopt($ch,CURLOPT_USERAGENT,$httpAgent);
					curl_setopt($ch,CURLOPT_FOLLOWLOCATION,0);
					curl_setopt($ch,CURLOPT_URL,$arpURL);
					curl_setopt($ch,CURLOPT_POST,true);
					curl_setopt($ch,CURLOPT_POSTFIELDS,$postData);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
					curl_exec($ch);
					curl_close($ch);
        		}
        	}
        }

	}
}
?>
