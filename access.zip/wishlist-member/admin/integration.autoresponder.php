<!-- Autoresponder integration -->
<?php
	$data=$this->GetOption('Autoresponders');
	if($_POST['saveAR']=='saveAR' && $_POST['ar']){
		$data[$data['ARProvider']]=$_POST['ar'];
		$this->SaveOption('Autoresponders',$data);
		echo "<div class='updated fade'><p>Your autoresponder settings have been updated.</p></div>";
	}elseif(isset($_POST['ARProvider'])){
		$data['ARProvider']=$_POST['ARProvider'];
		$this->SaveOption('Autoresponders',$data);
		echo "<div class='updated fade'><p>Your autoresponder provider has been changed.</p></div>";
	}
?>
<h2 style="font-size:18px;border-bottom:none">Autoresponder Integration</h2>
<p>Automatically sign-up newly registered members to your auto-responder.</p>
<form method="post">
<table class="form-table">
	<tr valign="top">
		<th scope="row">AR Provider</th>
		<td width="1">
			<select name="ARProvider">
				<option value="">None</option>
				<option value="<?php echo $x="arp"; ?>"<?php if($data['ARProvider']==$x) echo " selected='true'"; ?>>AutoResponse Plus</option>
				<option value="<?php echo $x="aweber"; ?>"<?php if($data['ARProvider']==$x) echo " selected='true'"; ?>>AWeber</option>
			</select>
		</td>
		<td>
			<p class="submit" style="margin:0;padding:0"><input type="submit" value="Set Autoresponder Provider" /></p>
		</td>
	</tr>
</table>
<br />
<hr />
<br />
</form>
<?php if($data['ARProvider']=='aweber'): ?>
<form method="post">
<input type="hidden" name="saveAR" value="saveAR" />
<table class="widefat">
	<thead>
		<tr>
			<th scope="col">Membership Level</th>
			<th scope="col">Autoresponder Email</th>
			<th scope="col">Unsubscribe Email</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($wpm_levels AS $levelid=>$level): ?>
		<tr>
			<th scope="row"><?php echo $level['name']; ?></th>
			<td><input type="text" name="ar[email][<?php echo $levelid; ?>]" value="<?php echo $data['aweber']['email'][$levelid]; ?>" size="40" /></td>
			<td><input type="text" name="ar[remove][<?php echo $levelid; ?>]" value="<?php echo $data['aweber']['remove'][$levelid]; ?>" size="40" /></td>
		<?php endforeach; ?>
	</tbody>
</table>
<p class="submit">
	<input type="submit" value="Update Autoresponder Settings" />
</p>
</form>
<?php elseif($data['ARProvider']=='arp'): ?>
<?php if(function_exists('curl_init')): ?>
<form method="post">
<input type="hidden" name="saveAR" value="saveAR" />
<table class="form-table">
	<tr valign="top">
		<th scope="row">ARP Application URL</th>
		<td>
			<input type="text" name="ar[arpurl]" value="<?php echo $data['arp']['arpurl']; ?>" size="60" />
			<br />
			<small>Example: http://www.yourdomain.com/cgi-bin/arp3/arp3-formcapture.pl</small>
		</td>
	</tr>
</table>
<table class="widefat">
	<thead>
		<tr>
			<th scope="col">Membership Level</th>
			<th scope="col">Autoresponder ID</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($wpm_levels AS $levelid=>$level): ?>
		<tr>
			<th scope="row"><?php echo $level['name']; ?></th>
			<td><input type="text" name="ar[arID][<?php echo $levelid; ?>]" value="<?php echo $data['arp']['arID'][$levelid]; ?>" size="10" /></td>
		<?php endforeach; ?>
	</tbody>
</table>
<p>To get the value for the Autoresponder ID field:</p>
<ul style="list-style:disc;margin-left:20px">
	<li>Go into your AutoResponse Plus system and view the autoresponder list</li>
	<li>Move your mouse over any of the options in the 'actions' column and look at the URL in the status bar.</li>
	<li>The ID number is shown as id= in the URL</li>
	<li>The URL will look something like this:<br /><strong>http://yourdomain.com/cgi-bin/arp3/arp3.pl?a0=aut&amp;a1=edi&amp;a2=pro&amp;<span style="background:yellow;">id=1</span></strong></li>
</ul>
<p class="submit">
	<input type="submit" value="Update Autoresponder Settings" />
</p>
</form>
<?php else: ?>
<p>AutoResponse Plus requires PHP to have the CURL extension enabled.  Please contact your system administrator.</p>
<?php endif; ?>
<?php endif; ?>