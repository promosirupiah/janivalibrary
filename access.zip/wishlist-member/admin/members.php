<?php
	// Get Membership Levels
	$wpm_levels=$this->GetOption('wpm_levels');
    if($_POST){
        foreach($_POST as $pk=>$pv){
            if(!is_array($pv))$_POST[$pk]=trim($pv);
        }
    }
?>
<h2>WL Member &raquo; Manage Members</h2>
<ul class="view-switch">
	<li<?php echo (!$_GET['mode'])?' class="current"':''?>><a href="?<?php echo $this->QueryString('usersearch','mode','level')?>">Manage Members</a></li>
	<li<?php echo ($_GET['mode']=='import')?' class="current"':''?>><a href="?<?php echo $this->QueryString('usersearch','mode','level')?>&mode=import">Import</a></li>
	<li<?php echo ($_GET['mode']=='export')?' class="current"':''?>><a href="?<?php echo $this->QueryString('usersearch','mode','level')?>&mode=export">Export</a></li>
	<li<?php echo ($_GET['mode']=='broadcast')?' class="current"':''?>><a href="?<?php echo $this->QueryString('usersearch','mode','level')?>&mode=broadcast">Email Broadcast</a></li>
	<li<?php echo ($_GET['mode']=='blacklist')?' class="current"':''?>><a href="?<?php echo $this->QueryString('usersearch','mode','level')?>&mode=blacklist">Blacklist</a></li>
</ul>
<?php if($_GET['mode']=='blacklist'): ?>
	<h2 style="font-size:18px">Registration Blacklisting</h2>
	<p>This page allows you to blacklist certain email and IP addresses from registering.</p>
	<?php if($_GET['append'] || $_GET['eappend']): ?>
	<script type="text/javascript">
		window.onload=function(){
			document.getElementById('blacklistform').submit();
		}
	</script>
	<?php endif; ?>
	<form method="post" id="blacklistform" action="?<?php echo $this->QueryString('append','eappend'); ?>">
	<table class="form-table">
		<tr valign="top">
			<th scope="row" colspan="2"><b>Blacklists</b></th>
		</tr>
		<tr valign="top">
			<th scope="row"><u>E-mail BlackList</u><p>Enter e-mail addresses to blacklist.  One email per line.</p><p>Example:</p>user@domain.com<br />*@domain.com<br />*.com</th>
			<td><textarea name="<?php $this->Option('blacklist_email'); ?>" cols="40" rows="10"><?php echo trim($this->OptionValue(true)."\n".$_GET['eappend']); ?></textarea></td>
		</tr>
		<tr valign="top">
			<th scope="row"><u>IP BlackList</u><p>Enter IP addresses to blacklist.  One IP per line.</p><p>Example:</p>192.168.0.1<br />192.168.0.*<br />192.168.*</th>
			<td><textarea name="<?php $this->Option('blacklist_ip'); ?>" cols="40" rows="10"><?php echo trim($this->OptionValue(true)."\n".$_GET['append']); ?></textarea></td>
		</tr>
	</table>
	<table class="form-table">
		<tr valign="top">
			<th scope="row" colspan="2"><b>Blacklist Messages</b></th>
		</tr>
		<tr valign="top">
			<th scope="row" class="WLRequired">Email Blacklist</th>
			<td><input type="text" name="<?php $this->Option('blacklist_email_message',true); ?>" size="60" value="<?php $this->OptionValue(false,'Your email address is blacklisted.'); ?>" /></td>
		</tr>
		<tr valign="top">
			<th scope="row" class="WLRequired">IP Blacklist</th>
			<td><input type="text" name="<?php $this->Option('blacklist_ip_message',true); ?>" size="60" value="<?php $this->OptionValue(false,'Your IP address is blacklisted.'); ?>" /></td>
		</tr>
		<tr valign="top">
			<th scope="row" class="WLRequired">Email and IP Blacklist</th>
			<td><input type="text" name="<?php $this->Option('blacklist_email_ip_message',true); ?>" size="60" value="<?php $this->OptionValue(false,'Your email and IP addresses are blacklisted.'); ?>" /></td>
		</tr>
	</table>
	<p class="submit">
		<?php $this->Options(); $this->RequiredOptions(); ?>
		<input type="hidden" name="WishListMemberAction" value="Save" />
		<input type="submit" value="Save Settings" />
	</p>
	</form>
<?php elseif($_GET['mode']=='broadcast'): ?>
	<h2 style="font-size:18px">E-mail Broadcast</h2>
	<?php
		$sender=$this->GetOption('email_sender_name');
		$senderemail=$this->GetOption('email_sender_address');
		if($sender && $senderemail):
	?>
	<form method="post" action="?<?php echo $this->QueryString('msg'); ?>">
		<?php
            if(!$_POST){
                $_POST=$this->GetOption('broadcast');
            }
			$_POST['subject']=trim($_POST['subject']);
			$_POST['message']=trim($_POST['message']);
			if($_POST['preview']){
				echo "<h3>Preview Message</h3>";
				$previewclass='style="display:none"';
			}else{
				$previewclass='';
			}
		?>
		<table class="form-table">
			<tr valign="top">
				<th scope="row" style="border-bottom:none">Subject</th>
				<td style="border-bottom:none">
					<input <?php echo $previewclass; ?> type="text" name="subject" value="<?php _e(htmlentities(stripslashes($_POST['subject']),ENT_QUOTES)); ?>" size="60" />
					<?php if($_POST['preview']) _e(stripslashes($_POST['subject']?$_POST['subject']:'<font color="red">(no subject)</font>')); ?>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">Message</th>
				<td>
					<textarea  <?php echo $previewclass; ?> name="message" id="broadcastmessage" cols="60" rows="20" style="float:left;margin-right:10px"><?php _e(stripslashes($_POST['message'])); ?></textarea>
					<div <?php echo $previewclass; ?>>
						<a href="javascript:;" onclick="wpm_insertHTML('[firstname]','broadcastmessage')">Insert First Name</a><br />
						<a href="javascript:;" onclick="wpm_insertHTML('[lastname]','broadcastmessage')">Insert Last Name</a><br />
						<a href="javascript:;" onclick="wpm_insertHTML('[email]','broadcastmessage')">Insert Email</a><br />
						<a href="javascript:;" onclick="wpm_insertHTML('[username]','broadcastmessage')">Insert Username</a><br />
						<a href="javascript:;" onclick="wpm_insertHTML('[loginurl]','broadcastmessage')">Insert Login URL</a><br />
						<a href="javascript:;" onclick="wpm_insertHTML('[memberlevel]','broadcastmessage')">Insert Membership Level</a><br />
					</div>
					<?php if($_POST['preview']) _e(nl2br(wordwrap(stripslashes($_POST['message']?$_POST['message']:'<font color="red">(no message)</font>')))); ?>
				</td>
			</tr>
            <tr valign="top">
                <th scope="row">Signature</th>
                <td>
                    <textarea <?php echo $previewclass; ?> name="signature" id="broadcastsignature" cols="60" rows="10"><?php _e(stripslashes($_POST['signature'])); ?></textarea>
                    <?php if($_POST['preview']) _e(nl2br(wordwrap(stripslashes($_POST['signature']?$_POST['signature']:'')))); ?>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row">CAN SPAM<br /><p><small>You must provide a physical address before you can send this message</small></p></th>
                <td>
                    <div <?php echo $previewclass; ?>>
                        Address 1:<br />
                        <input size="40" type="text" name="canspamaddr1" value="<?php _e(stripslashes($_POST['canspamaddr1'])); ?>" /><br />
                        Address 2:<br />
                        <input size="40" type="text" name="canspamaddr2" value="<?php _e(stripslashes($_POST['canspamaddr2'])); ?>" /><br />
                        City:<br />
                        <input size="30" type="text" name="canspamcity" value="<?php _e(stripslashes($_POST['canspamcity'])); ?>" /><br />
                        State:<br />
                        <input size="30" type="text" name="canspamstate" value="<?php _e(stripslashes($_POST['canspamstate'])); ?>" /><br />
                        ZIP:<br />
                        <input size="10" type="text" name="canspamzip" value="<?php _e(stripslashes($_POST['canspamzip'])); ?>" /><br />
                        Country:<br />
                        <input size="30" type="text" name="canspamcountry" value="<?php _e(stripslashes($_POST['canspamcountry'])); ?>" /><br />
                    </div>
                    <?php
                        if($_POST['preview']){
                            $address='';
                            if($_POST['canspamaddr1'] && $_POST['canspamcity'] && $_POST['canspamstate'] && $_POST['canspamzip'] && $_POST['canspamcountry']){
                                $address=$_POST['canspamaddr1']."\n";
                                if($_POST['canspamaddr2'])$address.=$_POST['canspamaddr2']."\n";
                                $address.=$_POST['canspamcity'].", ";
                                $address.=$_POST['canspamstate']."\n";
                                $address.=$_POST['canspamzip']."\n";
                                $address.=$_POST['canspamcountry'];
                                $addressok=true;
                            }else{
                                $address='<font color="red">(incomplete address)</font>';
                                $addressok=false;
                            }
                            _e(nl2br(stripslashes($address)));

                            echo "<br /><br />";

                            _e(sprintf(nl2br(WLMCANSPAM),'xxxxxxxx'));
                        }
                    ?>
                </td>
            </tr>
			<tr valign="top">
				<th scope="row">Membership Level</th>
				<td>
					<div <?php echo $previewclass; ?>>
						<label><input type="checkbox" onclick="var c=document.getElementById('allwpmlevels').getElementsByTagName('input');for(var i=0;i < c.length;i++)c[i].checked=this.checked;" /> Select/Unselect All Levels</label>
						<hr />
						<div id="allwpmlevels">
						<?php
							foreach($wpm_levels AS $id=>$level){
								$checked=in_array($id,$_POST['sendto'])?' checked="true"':'';
								echo "<label><input type='checkbox' name='sendto[]' value='{$id}'{$checked} /> {$level[name]}</label><br />";
							}
						?>
						</div>
					</div>
					<?php
						if($_POST['preview']){
							if(count($_POST['sendto'])){
								foreach($_POST['sendto'] AS $id){
									echo $wpm_levels[$id]['name'].'<br />';
								}
							}else{
								echo "(no level selected)";
							}
						}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row">Include</th>
				<td>
					<div <?php echo $previewclass; ?>>
						<label><input type="checkbox" name="otheroptions[]" value="p" <?php if(in_array('p',$_POST['otheroptions'])) echo ' checked="true" '; ?> /> Pending Members</label><br />
						<label><input type="checkbox" name="otheroptions[]" value="c" <?php if(in_array('c',$_POST['otheroptions'])) echo ' checked="true" '; ?> /> Cancelled Levels</label><br />
					</div>
					<?php
						if($_POST['preview']){
							if(in_array('p',$_POST['otheroptions'])){
								echo "Pending Members<br />";
							}
							if(in_array('c',$_POST['otheroptions'])){
								echo "Cancelled Levels<br />";
							}
							if(!isset($_POST['otheroptions'])){
								echo "Send only to Active members";
							}
						}
					?>
				</td>
			</tr>
		</table>
		<p class="submit">
			<?php if($_POST['preview']): $disabled=(!$_POST['subject']||!$_POST['message']||!count($_POST['sendto'])||!$addressok)?'disabled="true"':''; ?>
			<input type="hidden" name="WishListMemberAction" value="EmailBroadcast" />
			<?php if(!$disabled): ?>
			<small><b>Note:</b> This may take several minutes to complete if you have many members.<br /></small>
			<input type="submit" value="Send Message to Members" />
			<?php endif; ?>
			<input type="button" value="Go Back and Edit" onclick="this.form.WishListMemberAction.value='';this.form.submit()" />
			<?php else : ?>
			<input type="submit" name="preview" value="Preview Message" />
			<?php endif; ?>
		</p>
	</form>
	<?php else: ?>
		<p>You need to specify a sender's name and sender's email address before you can use this feature.</p>
		<p>You can do this by going to the <a href="<?php $x=$this->GetMenu('settings'); echo $x->URL; ?>&mode=email">WL Member Settings Page</a>.</p> 
	<?php endif; ?>
<?php elseif($_GET['mode']=='import'): ?>
	<h2 style="font-size:18px">Import Members</h2>
	<form method="post" enctype="multipart/form-data">
		<table class="form-table">
			<tr valign="top">
				<th scope="row" style="border-bottom:none">Select CSV File</th>
				<td style="border-bottom:none">
					<input type="file" name="File" />
					<p>Click the "Browse..." button to select a .csv file that contains the information of the members you would like to import.</p>
					<p><a href="?<?php echo $this->QueryString(); ?>&wpm_download_sample_csv=1">Click here to download a sample .csv file</a>. Your file should follow this format.</p>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row" style="border-bottom:none">Membership Level<br />to Import to</th>
				<td style="border-bottom:none">
					<select name="wpm_to">
						<?php foreach($wpm_levels AS $key=>$level): ?>
						<option value="<?php echo $key; ?>"><?php echo $level['name']; ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">How to handle<br />Duplicates</th>
				<td>
					<label><input type="radio" name="duplicates" value="0" checked="checked" /> Do not import duplicate usernames or emails</label><br />
					<label><input type="radio" name="duplicates" value="1" /> Import duplicate usernames or emails and change their membership level</label>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row" style="border-bottom:none">Default Password<br />for New Users</th>
				<td style="border-bottom:none">
					<input type="text" name="password" />
					<p>Leave this field blank to generate random passwords for each member.</p>
					<p>Note: This field will be ignored if your CSV file contains passwords for each user.</p>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">Notify New Users<br />via Email</th>
				<td>
					<label><input type="radio" name="notify" value="1" checked="checked"> Yes, send email notification to new users.</label><br />
					<label><input type="radio" name="notify" value="2"> No. (Email notification will still be sent to new users with randomly generated passwords)</label>
				</td>
			</tr>
		</table>
		<p class="submit">
			<input type="hidden" name="WishListMemberAction" value="ImportMembers" />
			<input type="submit" value="Import Members" />
		</p>
	</form>
<?php elseif($_GET['mode']=='export'): ?>
	<h2 style="font-size:18px">Export Members</h2>
	<p>Please select a Membership Level and click "Export Members" to download a CSV file of all the Members for that Membership Level.</p>
	<form method="post">
		<table class="form-table">
			<tr valign="top">
				<th scope="row">Membership Level</th>
				<td>
					<select name="wpm_to">
						<option value="0">All</option>
						<?php foreach($wpm_levels AS $key=>$level): ?>
						<option value="<?php echo $key; ?>"><?php echo $level['name']; ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<p class="submit">
			<input type="hidden" name="WishListMemberAction" value="ExportMembers" />
			<input type="submit" value="Export Members" />
		</p>
	</form>
<?php else: ?>
	<?php if($_POST['WishListMemberAction']!='WPMRegister' && !$_POST['err']): ?>
	<?php
		require_once($this->pluginDir.'/core/User.php');
		// sorting
		list($_GET['s'],$sortorder)=explode(';',$_GET['s']);
		if($sortorder!='d')$sortorder='a';
		$sortorderflip=($sortorder=='d')?'a':'d';
		switch($_GET['s']){
			case 'n':
				$sortby='display_name';
			break;
			case 'u':
				$sortby='user_login';
			break;
			case 'e':
				$sortby='user_email';
			break;
			case 'r':
				$sortby='user_registered';
			break;
			default:
				$sortby='';
		}
		$sortord=$sortorder=='d'?'DESC':'ASC';
		
		// grouping
		$members=$this->GetOption('Members');
		$lvl=$_GET['level'];
		if(!$lvl)$lvl='%';
		switch($lvl){
			case 'nonmembers':
				$ids=array('-');
				foreach($members AS $k=>$m){
					if($k!='pending')$ids=array_merge($ids,explode(',',$m));
				}
				if(!count($ids))$ids='';
			break;
			case 'pending':
				$ids=array_unique(explode(',',$members['pending']));
				if(count($ids)==1 && !$ids[0])$ids=array();
			break;
			default:
				if($lvl!='%'){
					$ids=array_unique(explode(',',$members[$lvl]));
					if(count($ids)==1 && !$ids[0])$ids=array();
				}else{
					$ids='';
				}
		}
		
		$wp_user_search=new WishListMemberUserSearch($_GET['usersearch'],$_GET['offset'],'',$ids,$sortby,$sortord);
		// pagination
		$offset=$_GET['offset']-1;
		if($offset<0)$offset=0;
		$perpage=$wp_user_search->users_per_page;  // posts per page
		$offset=$offset*$perpage;
		$page_links=paginate_links(array(
			'base'=>add_query_arg('offset','%#%'),
			'format'=>'',
			'total'=>ceil($wp_user_search->total_users_for_query/$perpage),
			'current'=>$offset/$perpage+1
		));
	
	?>
	<form onsubmit="document.location='?<?php echo $this->QueryString('usersearch','offset'); ?>&usersearch='+this.usersearch.value; return false;">
	<p>
	<?php if($page_links) echo '<div style="display:block;float:right;line-height:2em;margin:0 0 0 30px;">'.$page_links.'</div>'; ?>
	<?php if(count($wpm_levels)) echo '<div style="display:block;float:right;line-height:2em"><a href="#add">Add New Member</a></div>'; ?>
		<label for="post-search-input" class="hidden">Search Users:</label>
		<input type="text" value="<?php echo attribute_escape(stripslashes($_GET['usersearch']))?>" name="usersearch" id="post-search-input"/>
		<input type="submit" class="button" value="Search Users" />
	</p>
	</form>
	
	<ul class="subsubsub">
		<li><a href="?<?php echo $this->QueryString('usersearch','level','mode','offset')?>"<?php echo $lvl=='%'?' class="current"':'';?>>All Users</a></li>
		<li>| <a href="?<?php echo $this->QueryString('usersearch','level','mode','offset')?>&level=nonmembers"<?php echo $lvl=='nonmembers'?' class="current"':'';?>>Non-Members (<?php echo $this->NonMemberCount(); ?>)</a></li>
		<li> | <a href="?<?php echo $this->QueryString('usersearch','level','mode','offset')?>&level=pending"<?php echo $lvl=='pending'?' class="current"':'';?>>Pending Users (<?php echo $this->PendingCount(); ?>)</a></li>
		<?php foreach($wpm_levels AS $id=>$level): ?>
		<li> | <a href="?<?php echo $this->QueryString('usersearch','level','mode','offset')?>&level=<?php echo $id?>"<?php echo $lvl==$id?' class="current"':'';?>><?php echo $level['name']?> (<?php echo (int)$level['count']?>)</a></li>
		<?php endforeach; ?>
	</ul>
	
	<form method="post" action="?<?php echo $this->QueryString('msg'); ?>">
		<div class="tablenav">
			<div class="alignleft" style="margin-right:20px">
				<select class="postform" name="wpm_membership_to" style="width:160px">
					<option>Membership Levels...</option>
					<?php foreach($wpm_levels AS $id=>$level): ?>
					<option value="<?php echo $id?>"><?php echo $level['name']?></option>
					<?php endforeach; ?>
				</select>
				<input class="button-secondary" type="submit" name="wpm_change_membership" value="Move" onclick="if(this.form.wpm_membership_to.selectedIndex>0){return confirm('Are you sure you want to move the selected members to '+this.form.wpm_membership_to[wpm_membership_to.selectedIndex].text+'?')}else{alert('Please select a member level to change to first');return false}" /><input class="button-secondary" type="submit" name="wpm_add_membership" value="Add" onclick="if(this.form.wpm_membership_to.selectedIndex>0){return confirm('Are you sure you want to add the selected members to '+this.form.wpm_membership_to[wpm_membership_to.selectedIndex].text+'?')}else{alert('Please select a member level to add to first');return false}" /><input class="button-secondary" type="submit" name="wpm_del_membership" value="Remove" onclick="if(this.form.wpm_membership_to.selectedIndex>0){return confirm('Are you sure you want to remove the selected members from '+this.form.wpm_membership_to[wpm_membership_to.selectedIndex].text+'?')}else{alert('Please select a member level to remove first');return false}" />
				<input class="button-secondary" type="submit" name="wpm_cancel_membership" value="Cancel" onclick="if(this.form.wpm_membership_to.selectedIndex>0){return confirm('Are you sure you want to cancel the membership of the selected members for '+this.form.wpm_membership_to[wpm_membership_to.selectedIndex].text+'?')}else{alert('Please select a member level to cancel first');return false}" /><input class="button-secondary" type="submit" name="wpm_uncancel_membership" value="UnCancel" onclick="if(this.form.wpm_membership_to.selectedIndex>0){return confirm('Are you sure you want to uncancel the membership of the selected members for '+this.form.wpm_membership_to[wpm_membership_to.selectedIndex].text+'?')}else{alert('Please select a member level to uncancel first');return false}" />
			</div>
			
			<div class="alignleft" style="margin-right:20px">
				<input class="button-secondary" type="submit" name="wpm_approve_selected" value="Active" onclick="return confirm('Are you sure you want to move the selected members\nfrom Pending to Active Status?')" /><input class="button-secondary" type="submit" name="wpm_pending_selected" value="Pending" onclick="return confirm('Are you sure you want to move the selected members\nfrom Active to Pending Status?')" />
			</div>
			
			
			<div class="alignleft">
				<input class="button-secondary" type="submit" name="wpm_enable_sequential" value="Sequential On" onclick="return confirm('Are you sure you want to ENABLE Sequential Upgrade for the selected members?')" /><input class="button-secondary" type="submit" name="wpm_disable_sequential" value="Sequential Off" onclick="return confirm('Are you sure you want to DISABLE Sequential Upgrade for the selected members?')" />
			</div>
			
			<div class="alignright">
				<input class="button-secondary" type="submit" name="wpm_delete_member" value="Delete" onclick="return (confirm('Warning!\n\nAre you sure you want to delete the selected members?') && confirm('Last Warning!\n\nAre you really sure that you want to delete the selected members?\nNote that this action cannot be undone.'))" />
			</div>
			
			<br clear="all" />
		</div>
		<br clear="all" />
		<table class="widefat" id='wpm_members'>
			<thead>
				<tr>
					<th scope="col" class="check-column"><input type="checkbox" onclick="wpm_selectAll(this,'wpm_members')" /></th>
					<th scope="col"><a class="wpm_header_link<?php echo $_GET['s']=='n'?' wpm_header_sort'.$sortorder:'';?>" href="?<?php echo $this->QueryString('s')?>&s=n<?php echo $_GET['s']=='n'?';'.$sortorderflip:'';?>">Name</a></th>
					<th scope="col"><a class="wpm_header_link<?php echo $_GET['s']=='u'?' wpm_header_sort'.$sortorder:'';?>" href="?<?php echo $this->QueryString('s')?>&s=u<?php echo $_GET['s']=='u'?';'.$sortorderflip:'';?>">Username</a></th>
					<th scope="col"><a class="wpm_header_link<?php echo $_GET['s']=='e'?' wpm_header_sort'.$sortorder:'';?>" href="?<?php echo $this->QueryString('s')?>&s=e<?php echo $_GET['s']=='e'?';'.$sortorderflip:'';?>">Email</a></th>
					<th scope="col" class="num"><a class="wpm_header_link<?php echo $_GET['s']=='r'?' wpm_header_sort'.$sortorder:'';?>" href="?<?php echo $this->QueryString('s')?>&s=r<?php echo $_GET['s']=='r'?';'.$sortorderflip:'';?>">Member Since</a></th>
					<th scope="col" class="num">Status</th>
					<th scope="col" class="num">Sequential</th>
					<th scope="col" class="num">Membership Level</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach($wp_user_search->results AS $uid): $user=new WP_User($uid); ?>
				<tr class="<?php echo $alt++%2?'':'alternate'; ?>">
					<th scope="row" class="check-column"><input type="checkbox" name="wpm_member_id[]" value="<?php echo $user->ID?>" /></th>
					<td><?php echo $user->display_name?></td>
					<td><strong><a href="<?php echo get_bloginfo('wpurl')?>/wp-admin/user-edit.php?user_id=<?php echo $user->ID?>&wp_http_referer=wlm"><?php echo $user->user_login?></a></strong></td>
					<td><a href="mailto:<?php echo $user->user_email?>"><?php echo $user->user_email?></a></td>
					<td class="num"><?php echo preg_replace('/(\d+)-(\d+)-(\d+).+/i','\2/\3/\1', $user->user_registered)?></td>
					<td class="num"><?php echo $this->IsPending($user->ID)?'Pending':'Active'?></td>
					<td class="num"><?php echo $this->IsSequential($user->ID)?'On':'Off'?></td>
					<td class="num"><?php echo $this->GetMembershipLevels($user->ID,true)?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<input type="hidden" name="WishListMemberAction" value="SaveMembersData" />
	</form>
	<?php endif; ?>
	<br />
	<?php if(count($wpm_levels)): ?>
	<a name="add"></a>
	<h3 style="margin:0">Add New Member</h3>
	<?php if($_POST) extract($_POST); ?>
	<form method="post" action="?<?php echo $this->QueryString(); ?>">
		<input type="hidden" name="WishListMemberAction" value="WPMRegister" />
		<input type="hidden" name="wpmtheadminkhas78ajd" value="kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$" />
		<table class="form-table">
			<tr valign="top">
				<th scope="col">Username (required)</th>
				<td><input type="text" name="username" value="<?php echo $username?>" size="10" <?php echo 'autocomplete="off"'; ?> /></td>
			</tr>
			<tr valign="top">
				<th scope="col">First name<br /><br />Last name</th>
				<td><input type="text" name="firstname" value="<?php echo $firstname?>" <?php echo 'autocomplete="off"'; ?> /><br /><input type="text" name="lastname" value="<?php echo $lastname?>" <?php echo 'autocomplete="off"'; ?> /></td>
			</tr>
			<tr valign="top">
				<th scope="col">E-mail (required)</th>
				<td><input type="text" name="email" value="<?php echo $email?>" <?php echo 'autocomplete="off"'; ?> /></td>
			</tr>
			<tr valign="top">
				<th scope="col">Password (twice)</th>
				<td><input type="password" name="password1" size="10" <?php echo 'autocomplete="off"'; ?> /><br /><input type="password" name="password2" size="10" <?php echo 'autocomplete="off"'; ?> /></td>
			</tr>
			<tr valign="top">
				<th scope="col">Membership Level</th>
				<td>
					<select name="wpm_id">
						<?php foreach($wpm_levels AS $id=>$level): ?>
						<option value="<?php echo $id?>"<?php echo ($id==$wpm_id)?' selected="true"':'';?>><?php echo $level['name']?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		<p class="submit"><input type="submit" value="Add Member" /></p>
	</form>
	<?php endif; ?>
<?php endif; ?>