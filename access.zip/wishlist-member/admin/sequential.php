<?php
	$wpm_levels=$this->GetOption('wpm_levels');
?>
<h2>WL Member &raquo; Sequential Upgrade</h2> 
<form method="post">
<table class="widefat">
	<thead>
		<tr valign="top">
			<th scope="row">Membership Level</th>
			<th scope="row">Upgrade To</th>
			<th scope="row">Method</th>
			<th scope="row">After</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($wpm_levels AS $key=>$level): ?>
		<tr valign="top" class="<?php echo $alt++%2?'':'alternate'; ?>">
			<td><b><?php echo $level['name']; ?></b></td>
			<td>
				<select name="upgradeTo[<?php echo $key; ?>]">
					<option value="0">No auto-upgrade</option>
					<?php foreach(array_keys($wpm_levels) AS $k): if($k!=$key): ?>
					<option value="<?php echo $k; ?>" <?php $this->Selected($k,$level['upgradeTo']); ?>><?php echo $wpm_levels[$k]['name']; ?></option>
					<?php endif; endforeach; ?>
				</select>
			</td>
			<td>
				<select name="upgradeMethod[<?php echo $key; ?>]">
					<option value="MOVE">Move</option>
					<option value="ADD" <?php $this->Selected('ADD',$level['upgradeMethod']); ?>>Add</option>
				</select>
			</td>
			<td>
				<input name="upgradeAfter[<?php echo $key; ?>]" value="<?php echo (int)$level['upgradeAfter']; ?>" size="3" />
				Days(s)
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<p class="submit">
	<input type="hidden" name="WishListMemberAction" value="SaveSequential" />
	<input type="submit" value="Update Sequential Delivery Configuration" />
</p>
</form>