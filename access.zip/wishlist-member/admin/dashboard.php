<?php

	$wpm_levels=(array)$this->GetOption('wpm_levels');
?>
<h2>WishList Member Dashboard</h2> 

<table>
	<tr valign="top">
		<td>
			<table class="widefat" style="width:400px">
				<thead>
					<tr>
						<th scope="col">Your Membership Stats</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
							You are currently running on WishList Member v<?php echo $this->Version?>.<br />
							<table width="100%" cellpadding="3" cellspacing="5">
								<tr valign="top">
									<td style="border:1px solid #eee;background:#f8f8f8;line-height:1.5em" width="50%">
										<h3 style="margin:0 0 5px 0">Members</h3>
										<?php $totalmembers=0;foreach($wpm_levels AS $id=>$level): ?>
										<div style="float:left"><a href="<?php $x=$this->GetMenu('members'); echo $x->URL; ?>&level=<?php echo $id?>">&middot; <?php echo $level['name']?></a></div>
										<div style="float:right"><?php echo (int)$level['count']?></div>
										<br clear="all" />
										<?php $totalmembers+=$level['count'];endforeach; ?>
										<hr style="border:none;border-top:1px solid #888" />
										<div style="float:left"><a href="<?php $x=$this->GetMenu('members'); echo $x->URL; ?>">&middot; Total Members</a></div>
										<div style="float:right"><?php echo $totalmembers;?></div>
										<br clear="all" />
										<br clear="all" />
										<div style="float:left"><a href="<?php $x=$this->GetMenu('members'); echo $x->URL; ?>&level=pending">&middot; Pending</a></div>
										<div style="float:right"><?php echo $this->PendingCount();?></div>
									</td>
									<td style="border:1px solid #eee;background:#f8f8f8;line-height:1.5em" width="50%">
										<h3 style="margin:0 0 5px 0">Support</h3>
										<a href="http://www.wpwishlist.com/support" target="_blank">&raquo; Customer Support</a><br />
										<a href="http://www.wpwishlist.com/videos" target="_blank">&raquo; Video Tutorials</a><br />
										<a href="http://www.wpwishlist.com/guides" target="_blank">&raquo; Help Guide</a><br />
										<a href="http://www.wpwishlist.com/faq" target="_blank">&raquo; FAQ's</a><br />
										&nbsp;<br />
									</td>
								</tr>
							</table>
							<strong><?php $this->GetMenu('settings',true); ?></strong> - Adjust the main settings for your membership<br />
							<strong><?php $this->GetMenu('members',true); ?></strong> - See and manage your members<br />
							<strong><?php $this->GetMenu('membershiplevels',true); ?></strong> - Control the content your members see<br />
							<strong><?php $this->GetMenu('sequential',true); ?></strong> - Setup sequential upgrading of members<br />
							<strong><?php $this->GetMenu('integration',true); ?></strong> - Integrate with 1ShoppingCart<br />
						</td>
					</tr>
				</tbody>
			</table>
		</td>
		<td>
			<table class="widefat" style="width:400px">
				<thead>
					<tr>
						<th scope="col">WishList Members News</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
						To see latest news, open in browser: <br>
						http://www.wpwishlist.com/?feed=rss2
						</td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
</table>

<br clear="all" />