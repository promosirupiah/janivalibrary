<h2>WL Member &raquo; Settings</h2>
<ul class="view-switch">
	<li<?php echo (!$_GET['mode'])?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode','level')?>">Configuration</a></li>
	<li<?php echo ($_GET['mode']=='email')?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode','level')?>&mode=email">Email Settings</a></li>
	<li<?php echo ($_GET['mode']=='regpage')?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode','level')?>&mode=regpage">Registration Page</a></li>
</ul>
<?php if($_GET['mode']=='regpage'): ?>
<!-- Registration Page -->
<?php
	$regpage_before=$this->GetOption('regpage_before');
	$regpage_after=$this->GetOption('regpage_after'); 
	if(isset($_POST['wlm_regpage_before'])){
		$regpage_before[$_POST['level']]=stripslashes($_POST['wlm_regpage_before']);
		$regpage_after[$_POST['level']]=stripslashes($_POST['wlm_regpage_after']);
		$this->SaveOption('regpage_before',$regpage_before);
		$this->SaveOption('regpage_after',$regpage_after);
		echo "<div class='updated fade'><p>Registration Form Customization Settings Saved.</p></div>";
	} 
?>
<h2 style="font-size:18px;width:100%">Step 1. Select Membership Level</h2>
<form method="get">
<table class="form-table">
	<?php
		parse_str($this->QueryString('level'),$fields);
		foreach($fields AS $field=>$value){
			echo "<input type='hidden' name='{$field}' value='{$value}' />";
		}
		$wpm_levels=$this->GetOption('wpm_levels');
	?>
	<tr>
		<th scope="row">Membership Level</th>
		<td width="1">
			<select name="level" onchange="this.form.submit()">
				<option value="">---</option>
				<?php
					foreach($wpm_levels AS $levelid=>$level){
						$selected=$_GET['level']==$levelid?' selected="true" ':'';
						echo "<option value='{$levelid}'{$selected}>{$level[name]}</option>";
					}
				?>
			</select>
		</td>
		<td>
			<noscript><p class="submit" style="margin:0;padding:0"><input type="submit" value="Select Membership Level" /></p></noscript>
		</td>
	</tr>
</table>
</form>
<?php if(isset($wpm_levels[$_GET['level']])): ?>
<h2 style="font-size:18px;width:100%">Step 2. Edit Code for Level's Registration Form</h2>
<form method="post">
<input type="hidden" name="level" value="<?php echo $_GET['level']; ?>" />
<table class="form-table">
	<tr valign="top">
		<th scope="row">HTML Code to insert BEFORE the Registration Form</th>
		<td><textarea cols="60" rows="10" name="wlm_regpage_before"><?php echo $regpage_before[$_GET['level']]; ?></textarea></td>
	</tr>
	<tr valign="top">
		<th scope="row">HTML Code to insert AFTER the Registration Form</th>
		<td><textarea cols="60" rows="10" name="wlm_regpage_after"><?php echo $regpage_after[$_GET['level']]; ?></textarea></td>
	</tr>
</table>
<p class="submit">
	<input type="submit" value="Save Settings" />
</p>
</form>
<?php endif; ?>

<?php elseif($_GET['mode']=='email'): ?>
<!-- Email Settings -->
<form method="post">
<table class="form-table">
	<tr valign="top">
		<td colspan="2" style="border:none">Please enter the sender that information that will be used when WishList Member sends out an email:</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none" class="WLRequired">Sender Name</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('email_sender_name',true); ?>" value="<?php $this->OptionValue(); ?>" size="40" /></td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none" class="WLRequired">Sender E-mail</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('email_sender_address',true); ?>" value="<?php $this->OptionValue(); ?>" size="40" /></td>
	</tr>
</table>
<br />
<h3 style="margin-bottom:0">Registration</h3>
<table class="form-table">
	<tr valign="top">
		<td colspan="2" style="border:none">Please enter the email you would like to be sent to a member once they register:</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none" class="WLRequired">Subject</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('register_email_subject',true); ?>" value="<?php $this->OptionValue(); ?>" size="40" /></td>
	</tr>
	<tr valign="top">
		<th scope="row" class="WLRequired">Body</th>
		<td>
			<textarea name="<?php $this->Option($x='register_email_body'); ?>" id="<?php echo $x; ?>" cols="40" rows="10" style="float:left;margin-right:10px"><?php $this->OptionValue(); ?></textarea>
			<div>
				<a href="javascript:;" onclick="wpm_insertHTML('[firstname]','<?php echo $x; ?>')">Insert First Name</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[lastname]','<?php echo $x; ?>')">Insert Last Name</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[email]','<?php echo $x; ?>')">Insert Email</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[username]','<?php echo $x; ?>')">Insert Username</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[password]','<?php echo $x; ?>')">Insert Password</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[loginurl]','<?php echo $x; ?>')">Insert Login URL</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[memberlevel]','<?php echo $x; ?>')">Insert Membership Level</a><br />
			</div>
			<br clear="all" />
			If you would like to insert info for the individual member<br />
			please click the merge field codes on the right.
		</td>
	</tr>
</table>
<br />
<h3 style="margin-bottom:0">Lost Info</h3>
<table class="form-table">
	<tr valign="top">
		<td colspan="2" style="border:none">Please enter the email you would like to be sent to a member if they request their login info to be sent to them:</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none" class="WLRequired">Subject</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('lostinfo_email_subject',true); ?>" value="<?php $this->OptionValue(); ?>" size="40" /></td>
	</tr>
	<tr valign="top">
		<th scope="row" class="WLRequired">Body</th>
		<td>
			<textarea name="<?php $this->Option($x='lostinfo_email_message',true); ?>" id="<?php echo $x; ?>" cols="40" rows="10" style="float:left;margin-right:10px"><?php $this->OptionValue(); ?></textarea>
			<div>
				<a href="javascript:;" onclick="wpm_insertHTML('[firstname]','<?php echo $x; ?>')">Insert First Name</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[lastname]','<?php echo $x; ?>')">Insert Last Name</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[email]','<?php echo $x; ?>')">Insert Email</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[username]','<?php echo $x; ?>')">Insert Username</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[reseturl]','<?php echo $x; ?>')">Insert Reset URL</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[loginurl]','<?php echo $x; ?>')">Insert Login URL</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[memberlevel]','<?php echo $x; ?>')">Insert Membership Level</a><br />
			</div>
			<br clear="all" />
			If you would like to insert info for the individual member<br />
			please click the merge field codes on the right.
		</td>
	</tr>
</table>
<br />
<h3 style="margin-bottom:0">New Member Notification</h3>
<table class="form-table">
	<tr valign="top">
		<td colspan="2" style="border:none">Please enter the email you would like to be sent to the admin if a new user has registered:</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none" class="WLRequired">Admin's Email</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('newmembernotice_email_recipient',true); ?>" value="<?php $this->OptionValue(); ?>" size="40" /></td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none" class="WLRequired">Subject</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('newmembernotice_email_subject',true); ?>" value="<?php $this->OptionValue(); ?>" size="40" /></td>
	</tr>
	<tr valign="top">
		<th scope="row" class="WLRequired">Body</th>
		<td>
			<textarea name="<?php $this->Option($x='newmembernotice_email_message',true); ?>" id="<?php echo $x; ?>" cols="40" rows="10" style="float:left;margin-right:10px"><?php $this->OptionValue(); ?></textarea>
			<div>
				<a href="javascript:;" onclick="wpm_insertHTML('[firstname]','<?php echo $x; ?>')">Insert First Name</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[lastname]','<?php echo $x; ?>')">Insert Last Name</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[email]','<?php echo $x; ?>')">Insert Email</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[username]','<?php echo $x; ?>')">Insert Username</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[password]','<?php echo $x; ?>')">Insert Password</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[loginurl]','<?php echo $x; ?>')">Insert Login URL</a><br />
				<a href="javascript:;" onclick="wpm_insertHTML('[memberlevel]','<?php echo $x; ?>')">Insert Membership Level</a><br />
			</div>
			<br clear="all" />
			If you would like to insert info for the individual member<br />
			please click the merge field codes on the right.
		</td>
	</tr>
</table>

<p class="submit">
	<?php $this->Options(); $this->RequiredOptions(); ?>
	<input type="hidden" name="WishListMemberAction" value="Save" />
	<input type="submit" value="Save Settings" />
</p>
</form>
<?php else: ?>
<!-- Configuration -->
<form method="post">
<?php $pages=get_pages('exclude='.implode(',',$this->ExcludePages(array(),true))); ?>
<table class="form-table">
	<tr valign="top">
		<td colspan="2" style="border:none">
			Please specify the error pages that people will see when they try to access your membership site:
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none">Non-Members:</th>
		<td style="border:none">
			<select name="<?php $this->Option('non_members_error_page_internal')?>" onchange="this.form.non_members_error_page.disabled=this.selectedIndex>0">
				<option value="0">Enter an external URL below</option>
				<?php foreach ($pages AS $page): ?>
				<option value="<?php echo $page->ID?>"<?php $this->OptionSelected($page->ID); ?>><?php echo $page->post_title?></option>
				<?php endforeach; ?>
			</select><br />
			<input<?php if($this->GetOption('non_members_error_page_internal'))echo ' disabled="true"'; ?> type="text" name="<?php $this->Option('non_members_error_page'); ?>" value="<?php $this->OptionValue(); ?>" size="60" /><br />
			Non-members will see this error page when they try to access content in your members area.
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">Wrong Membership Level:</th>
		<td>
			<select name="<?php $this->Option('wrong_level_error_page_internal')?>" onchange="this.form.wrong_level_error_page.disabled=this.selectedIndex>0">
				<option value="0">Enter an external URL below</option>
				<?php foreach ($pages AS $page): ?>
				<option value="<?php echo $page->ID?>"<?php $this->OptionSelected($page->ID); ?>><?php echo $page->post_title?></option>
				<?php endforeach; ?>
			</select><br />
			<input<?php if($this->GetOption('wrong_level_error_page_internal'))echo ' disabled="true"'; ?> type="text" name="<?php $this->Option('wrong_level_error_page'); ?>" value="<?php $this->OptionValue(); ?>" size="60" /><br />
			If you have more than one level of membership, this is the error page someone will see if they try to access content that their membership level does not have permission to view.
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">Membership Cancelled:</th>
		<td>
			<select name="<?php $this->Option('membership_cancelled_internal')?>" onchange="this.form.membership_cancelled.disabled=this.selectedIndex>0">
				<option value="0">Enter an external URL below</option>
				<?php foreach ($pages AS $page): ?>
				<option value="<?php echo $page->ID?>"<?php $this->OptionSelected($page->ID); ?>><?php echo $page->post_title?></option>
				<?php endforeach; ?>
			</select><br />
			<input<?php if($this->GetOption('membership_cancelled_internal'))echo ' disabled="true"'; ?> type="text" name="<?php $this->Option('membership_cancelled'); ?>" value="<?php $this->OptionValue(); ?>" size="60" /><br />
			This page will be displayed when a user's membership has been cancelled by one of the supported shopping carts.
		</td>
	</tr>
	<tr valign="top">
		<td colspan="2" style="border:none">
			Please specify the the page to which a newly registered member will be redirected to:
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">After Registration Page:</th>
		<td>
			<select name="<?php $this->Option('after_registration_internal')?>" onchange="this.form.after_registration.disabled=this.selectedIndex>0">
				<option value="0">Enter an external URL below</option>
				<?php foreach ($pages AS $page): ?>
				<option value="<?php echo $page->ID?>"<?php $this->OptionSelected($page->ID); ?>><?php echo $page->post_title?></option>
				<?php endforeach; ?>
			</select><br />
			<input<?php if($this->GetOption('after_registration_internal'))echo ' disabled="true"'; ?> type="text" name="<?php $this->Option('after_registration'); ?>" value="<?php $this->OptionValue(); ?>" size="60" /><br />
			Newly registered members will see this page after they register.
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">Custom Unsubscribe Confirmation Page:</th>
		<td>
			<select name="<?php $this->Option('unsubscribe_internal')?>" onchange="this.form.unsubscribe.disabled=this.selectedIndex>0">
				<option value="0">Enter an external URL below</option>
				<?php foreach ($pages AS $page): ?>
				<option value="<?php echo $page->ID?>"<?php $this->OptionSelected($page->ID); ?>><?php echo $page->post_title?></option>
				<?php endforeach; ?>
			</select><br />
			<input<?php if($this->GetOption('unsubscribe_internal'))echo ' disabled="true"'; ?> type="text" name="<?php $this->Option('unsubscribe'); ?>" value="<?php $this->OptionValue(); ?>" size="60" /><br />
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">Pending Period for New Registrations:</th>
		<td>
			<input type="text" name="<?php $this->Option('pending_period'); ?>" value="<?php $this->OptionValue(); ?>" size="4" />
			Days<br />
			Newly registered members will be able to access the level of membership of that they've registered with for the number of days specified above.  To disable this feature, simply enter 0 (zero) in the field above or just leave it blank.
		</td>
	</tr>
	<tr valign="top">
		<th scope="row">RSS Secret Key:</th>
		<td>
			<input type="text" name="<?php $this->Option('rss_secret_key'); ?>" value="<?php $this->OptionValue(false,md5(time())); ?>" size="40" /><br />
			This key will be used to generate the unique RSS Feed URL for each member.  Do not give this key to anyone.
		</td>
	</tr>
</table>
<table class="form-table">
	<tr valign="top">
		<th scope="row" style="white-space:nowrap;">Only show content for each membership level:</th>
		<td>
			<label><input type="radio" name="<?php $this->Option('only_show_content_for_level'); ?>" value="1"<?php $this->OptionChecked(1); ?> />
			Yes</label>
			&nbsp;
			<label><input type="radio" name="<?php $this->Option(); ?>" value="0"<?php $this->OptionChecked(0); ?> />
			No</label>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="white-space:nowrap;border:none">Protect all content after the "more" tags:</th>
		<td style="border:none">
			<label><input type="radio" name="<?php $this->Option('protect_after_more'); ?>" value="1"<?php $this->OptionChecked(1); ?> />
			Yes</label>
			&nbsp;
			<label><input type="radio" name="<?php $this->Option(); ?>" value="0"<?php $this->OptionChecked(0); ?> />
			No</label>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none">Do you want to automatically protect content if the "more" tag is not inserted into any post?</th>
		<td style="border:none">
			<label><input type="radio" name="<?php $this->Option('auto_insert_more'); ?>" value="1"<?php $this->OptionChecked(1); ?> />
			Yes</label>
			&nbsp;
			<label><input type="radio" name="<?php $this->Option(); ?>" value="0"<?php $this->OptionChecked(0); ?> />
			No</label>
		</td>
	</tr>
	<tr valign="top">
		<td colspan="2">
			Note: if you select "Yes", WishList Member will automatically insert the "more" tag after the first 50 words if a "more" tag is not found.
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none">Text to display for content protected with private tags</th>
		<td style="border:none">
			<input type="text" name="<?php $this->Option('private_tag_protect_msg'); ?>" value="<?php $this->OptionValue(); ?>" style="width:90%" /><br />
			Merge code [level] will be automatically replaced with the level of membership.
		</td>
	</tr>
	<tr valign="top">
		<td colspan="2">
			If you would like to protect part of your posts you can use the "private tags".  Just place [private_level] before and [/private_level] after the text you wish to protect.  Please note that these tags will differ depending on your membership levels.  For example, if you have a membership level called "silver", the tags would be [private_silver] and [/private_silver].  Therefore only anyone in the silver would be able to view this content.
		</td>
	</tr>
	
	<tr valign="top">
		<th scope="row" style="border:none">Default Login Limit:</th>
		<td style="border:none"><input type="text" name="<?php $this->Option('login_limit'); ?>" value="<?php $this->OptionValue(); ?>" size="3" /> IPs per day<br />Enter 0 (zero) or leave it blank to disable</td>
	</tr>
	<tr valign="top">
		<th scope="row">Login Limit Message:</th>
		<td><input type="text" name="<?php $this->Option('login_limit_error'); ?>" value="<?php $this->OptionValue(false,'<b>Error:</b> You have reached your daily login limit.'); ?>" size="80" /></td>
	</tr>

	<tr valign="top">
		<th scope="row" style="white-space:nowrap">Notify admin of new user registration:</th>
		<td>
			<label><input type="radio" name="<?php $this->Option('notify_admin_of_newuser'); ?>" value="1"<?php $this->OptionChecked(1); ?> />
			Yes</label>
			&nbsp;
			<label><input type="radio" name="<?php $this->Option(); ?>" value="0"<?php $this->OptionChecked(0); ?> />
			No</label>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="white-space:nowrap">Members can update their info:</th>
		<td>
			<label><input type="radio" name="<?php $this->Option('members_can_update_info'); ?>" value="1"<?php $this->OptionChecked(1); ?> />
			Yes</label>
			&nbsp;
			<label><input type="radio" name="<?php $this->Option(); ?>" value="0"<?php $this->OptionChecked(0); ?> />
			No</label>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="border:none;white-space:nowrap">Show Affiliate Link in Footer:</th>
		<td style="border:none">
			<label><input type="radio" name="<?php $this->Option('show_linkback'); ?>" value="1"<?php $this->OptionChecked(1); ?> />
			Yes</label>
			&nbsp;
			<label><input type="radio" name="<?php $this->Option(); ?>" value="0"<?php $this->OptionChecked(0); ?> />
			No</label>
		</td>
	</tr>
	<tr valign="top">
		<th scope="row" style="white-space:nowrap">Affiliate ID:</th>
		<td>
			<input type="text" name="<?php $this->Option('affiliate_id'); ?>" value="<?php $this->OptionValue(); ?>" /> <a href="http://www.wpwishlist.com/affiliates/" target="_blank">Sign Up Now</a>
		</td>
	</tr>
</table>
<p class="submit">
	<?php $this->Options(); $this->RequiredOptions(); ?>
	<input type="hidden" name="WishListMemberAction" value="Save" />
	<input type="submit" value="Save Settings" />
</p>
</form>
<?php endif; ?>
