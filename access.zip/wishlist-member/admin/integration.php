<?php
	$wpm_levels=$this->GetOption('wpm_levels');
	$wpm_scregister=get_bloginfo('url').'/index.php?/register/';
?>
<h2>WL Member &raquo; Integration</h2>
<ul class="view-switch">
	<li<?php echo (!$_GET['mode'])?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode')?>">Shopping Cart</a></li>
	<li<?php echo ($_GET['mode']=='ar')?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode')?>&mode=ar">AutoResponder</a></li>
    <?php do_action('wishlistmember_integration_menu',$_GET['mode'],'<li><a href="?'.$this->QueryString('mode').'&mode=%s">','<li class="current"><a href="?'.$this->QueryString('mode').'&mode=%s">','</a></li>'); ?>
</ul>
<br />
<?php
	if($_GET['mode']=='ar'){
		include('integration.autoresponder.php');
	}elseif($_GET['mode']==''){
		include('shoppingcart.php');
	}
	do_action('wishlistmember_integration_page',$_GET['mode'],$this);
?>