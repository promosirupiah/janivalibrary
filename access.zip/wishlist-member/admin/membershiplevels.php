<?php
	/* Registration URL */
	$registerurl=get_bloginfo('url').'/?/register';
	
	/* new ID */
	$wpm_newid=time();sleep(1);
	
	/* WL Member Levels */
	$wpm_levels=$this->GetOption('wpm_levels');
	
	$prevurls=array();
	foreach(array_keys($wpm_levels) AS $level){
		$prevurls[]=$level['url'];
	}
	
	/* new URL */
	$found=false;
	while(!$found){
		srand((float)microtime()*10000000);
		$newurl=implode('',array_rand(array_flip(array_merge(range('A','Z'),range('a','z'),range(0,9))),6));
		$found=!in_array($newurl,$prevurls);
	}
	
	/* headings */
	$heading['']='Manage Membership Levels';
	$heading['content']='Manage Membership Content';
	$heading['movemembership']='Move Membership Levels';
?>
<h2>WL Member &raquo; <?php echo $heading[$_GET['mode']]; ?></h2>
<ul class="view-switch">
	<li<?php echo (!$_GET['mode'])?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode','level','offset','s')?>">Membership Levels</a></li>
	<li<?php echo ($_GET['mode']=='content')?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode','level','offset','s')?>&mode=content">Membership Content</a></li>
	<li<?php echo ($_GET['mode']=='movemembership')?' class="current"':''?>><a href="?<?php echo $this->QueryString('mode','level','offset','s')?>&mode=movemembership">Move Membership Levels</a></li>
</ul>
<br />
<?php if($_GET['mode']=='movemembership'): ?>
<p>To move all users from one membership level to another, just select the level you want to move them to from the drop menu on the right.</p>
<table class="widefat">
	<thead>
		<tr>
			<th scope="col">Membership Level</th>
			<th scope="col" style="text-align:center">Members</th>
			<th scope="col" style="white-space:nowrap">Move/Add All Members To...</th>
		</tr>
	</thead>
	<tbody>
		<?php $alt=0; $wpmls=$wpm_levels; foreach($wpm_levels AS $id=>$level): echo '<form method="post">'; ?>
		<tr class="<?php echo $alt++%2?'':'alternate'; ?>">
			<td><span style="font-size:1.2em;font-weight:bold"><?php echo $level['name']; ?></span></td>
			<td style="text-align:center"><?php echo $level['count']; ?></td>
			<td width="10" style="white-space:nowrap">
				<input type="hidden" name="WishListMemberAction" value="MoveMembership" />
				<input type="hidden" name="wpm_from" value="<?php echo $id; ?>" />
				<select name="wpm_to" style="width:100px">
					<?php foreach($wpmls AS $xid=>$lvl): if($xid!=$id): ?>
					<option value="<?php echo $xid; ?>"><?php echo $lvl['name']; ?></option>
					<?php endif; endforeach; ?>
				</select>
				<input type="submit" name="wpm_move" class="button-secondary" value="Move" onclick="return confirm('Are you sure you want to MOVE all <?=htmlentities(addslashes($level['name']))?> members to '+this.form.wpm_to[this.form.wpm_to.selectedIndex].text)" />
				<input type="submit" name="wpm_add" class="button-secondary" value="Add" onclick="return confirm('Are you sure you want to ADD all <?=htmlentities(addslashes($level['name']))?> members to '+this.form.wpm_to[this.form.wpm_to.selectedIndex].text)" />
			</td>
		</tr>
		<?php echo '</form>'; endforeach; ?>
	</tbody>
</table>
	
<?php elseif($_GET['mode']=='content'): ?>
	<?php
		$cprotect=$_GET['level']=='Protection';
		$show=$_GET['show'];
		$contents=array('pages','categories','comments','posts');
		if(!in_array($show,$contents) || ($cprotect && $show=='comments')){
			$show='posts';
			unset($_GET['show']);
		}
?>
	<form>
		Please select a membership level to manage below or select "Content Protection" to simply manage content protection:<br />
		<blockquote>
			<select name="wpm_content_level" onchange="top.location='?<?=$this->QueryString('level')?>&level='+this.value">
				<option>---</option>
				<option value="<?=$x='Protection';?>" <?php if($_GET['level']==$x)echo ' selected="true" ';?>>Content Protection</option>
				<?php foreach($wpm_levels AS $id=>$level) : ?>
				<option value="<?=$id?>"<?=$id==$_GET['level']?' selected="true"':'';?>><?=$level['name']?></option>
				<?php endforeach; ?>
			</select>
		</blockquote>
	</form>
	<?php if($wpm_levels[$_GET['level']] || $cprotect) : $level=&$wpm_levels[$_GET['level']]; ?>
		<h2 style="font-size:18px;"><a name="specific"></a><?=$cprotect?'Manage Content Protection':'Manage Specific Membership Content';?> &raquo; <?=ucwords(strtolower($show))?></h2>
		<ul class="view-switch">
			<li<?=($_GET['show']=='categories')?' class="current"':''?>><a href="?<?=$this->QueryString('show','offset')?>&show=categories">Categories</a></li>
			<li<?=($_GET['show']=='pages')?' class="current"':''?>><a href="?<?=$this->QueryString('show','offset')?>&show=pages">Pages</a></li>
			<li<?=(!$_GET['show'])?' class="current"':''?>><a href="?<?=$this->QueryString('show','offset')?>">Posts</a></li>
			<?php if(!$cprotect): ?>
			<li<?=($_GET['show']=='comments')?' class="current"':''?>><a href="?<?=$this->QueryString('show','offset')?>&show=comments">Comments</a></li>
			<?php endif; ?>
		</ul>
		
		<?php
			if(!$_GET['show'])$_GET['show']='posts';
			switch($_GET['show']){
				case 'pages':
					echo $cprotect?'<p>Select which pages to protect:</p>':'<p>Please select the pages that members of this level can access:</p>';
					if($level['allpages']) $allchecked=' checked="true" disabled="true" ';
				break;
				case 'categories':
					echo $cprotect?'<p>Select which categories to protect:</p>':'<p>Please select the categories that members of this level can access:</p>';
					if($level['allcategories']) $allchecked=' checked="true" disabled="true" ';
				break;
				case 'comments':
					echo '<p>Please select the posts that members of this level can comment on:</p>';
					if($level['allcomments']) $allchecked=' checked="true" disabled="true" ';
				break;
				case 'posts':
					echo $cprotect?'<p>Select which posts to protect:</p>':'<p>Please select the posts that members of this level can access:</p>';
					if($level['allposts']) $allchecked=' checked="true" disabled="true" ';
				break;
			}
			$this->SyncContent($_GET['show']);
		?>
		<?php if($_GET['show']=='categories'): ?>
			<?php
				$objs=get_categories('hide_empty=0');
				$objcount=count($objs);
			?>
			<?php if($objcount): $Checked=$this->GetMembershipContent('categories',$_GET['level']); ?>
				<form method="post">
				<div class="tablenav">
					<div class="alignleft"><input type="submit" class="button-secondary" value="<?=$cprotect?'Set Protection':'Grant Access';?>" /></div>
				</div>
				<br clear="all" />
				<table class="widefat" id="wpm_post_page_table">
					<thead>
					<tr valign="top">
						<th class="check-column" scope="row"><input <?php echo $allchecked; ?> type="checkbox" onclick="wpm_selectAll(this,'wpm_post_page_table')" /></th>
						<th scope="row">Name</th>
						<th scope="row">Description</th>
						<th scope="row" style="text-align:center">Posts</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($objs AS $obj): ?>
					<tr valign="top" class="<?php echo $alt++%2?'':'alternate'; ?>">
						<th class="check-column" scope="row"><input type="checkbox" name="Checked[<?php echo $obj->cat_ID; ?>]" value="1" <?php echo $allchecked; if($cprotect)$this->Checked($this->CatProtected($obj->cat_ID),true);else $this->Checked($obj->cat_ID,$Checked); ?> /><input type="hidden" name="ID[<?php echo $obj->cat_ID; ?>]" value="0" /></th>
						<td><a href="<?php echo get_category_link($obj->cat_ID); ?>"><b><?php echo $obj->name; ?></b></a></td>
						<td><?php echo $obj->description; ?></td>
						<td style="text-align:center"><?php echo $obj->count; ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<div class="tablenav">
					<div class="alignleft"><input type="submit" class="button-secondary" value="<?=$cprotect?'Set Protection':'Grant Access';?>" /></div>
				</div>
				<br clear="all" />
				<input type="hidden" name="WishListMemberAction" value="SaveMembershipContent" />
				<input type="hidden" name="Level" value="<?php echo $_GET['level']; ?>" />
				<input type="hidden" name="ContentType" value="categories" />
				</form>
			<?php endif; ?>
		<?php else : ?>
			<?php
				$status=array(
					'publish'=>'Published',
					'pending'=>'Pending',
					'draft'=>'Unpublished',
					'private'=>'Private',
					'future'=>'Scheduled'
				);
				$post_type=$_GET['show']=='pages'?'page':'post';
				$totalcount=array_sum((array)wp_count_posts($post_type));
				$offset=$_GET['offset']-1;
				if($offset<0)$offset=0;
				$perpage=15;  // posts per page
				$offset=$offset*$perpage;
				$args=array(
					'numberposts'=>$perpage,
					'post_status'=>implode(',',array_keys($status)),
					'post_type'=>$post_type,
					'offset'=>$offset,
					'exclude'=>implode(',',$this->ExcludePages(array()))
				);
				$objs=get_posts($args);
				$objcount=count($objs);
				
				$page_links=paginate_links(array(
					'base'=>add_query_arg('offset','%#%'),
					'format'=>'',
					'total'=>ceil($totalcount/$perpage),
					'current'=>$offset/$perpage+1
				));
			?>
			<?php if($objcount): $Checked=$this->GetMembershipContent($_GET['show'],$_GET['level']);?>
				<form method="post">
				<div class="tablenav">
					<div class="alignleft"><input type="submit" class="button-secondary" value="<?=$cprotect?'Set Protection':'Grant Access';?>" /></div>
					<?php if($page_links) echo "<div class='tablenav-pages'>$page_links</div>"; ?>
				</div>
				<br clear="all" />
				<table class="widefat" id="wpm_post_page_table">
					<thead>
					<tr valign="top">
						<th class="check-column" scope="row"><input <?php echo $allchecked; ?> type="checkbox" onclick="wpm_selectAll(this,'wpm_post_page_table')" /></th>
						<th scope="row">Date</th>
						<th scope="row">Title</th>
						<th scope="row">Author</th>
						<?php if($_GET['show']!='pages'): ?><th scope="row">Categories</th><?php endif; ?>
						<th scope="row">Status</th>
					</tr>
					</thead>
					<tbody>
					<?php foreach($objs AS $GLOBALS['post']): setup_postdata($GLOBALS['post']);?>
					<tr valign="top" class="<?php echo $alt++%2?'':'alternate'; ?>">
						<th class="check-column" scope="row"><input type="checkbox" name="Checked[<?php the_ID(); ?>]" value="1" <?php echo $allchecked; if($cprotect)$this->Checked($this->Protect(get_the_ID()),true);else $this->Checked(get_the_ID(),$Checked); ?> /><input type="hidden" name="ID[<?php the_ID(); ?>]" value="0" /></th>
						<td><?php echo the_time('m/d/Y'); ?></td>
						<td><a href="<?php the_permalink(); ?>"><b><?php echo the_title(); ?></b></a></td>
						<td><?php the_author(); ?></td>
						<?php if($_GET['show']!='pages'): ?><td><?php the_category(', '); ?></td><?php endif; ?>
						<td><?php echo $status[$GLOBALS['post']->post_status]; ?></td>
					</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<div class="tablenav">
					<div class="alignleft"><input type="submit" class="button-secondary" value="<?=$cprotect?'Set Protection':'Grant Access';?>" /></div>
					<?php if($page_links) echo "<div class='tablenav-pages'>$page_links</div>"; ?>
				</div>
				<br clear="all" />
				<input type="hidden" name="WishListMemberAction" value="SaveMembershipContent" />
				<input type="hidden" name="Level" value="<?php echo $_GET['level']; ?>" />
				<input type="hidden" name="ContentType" value="<?php echo $_GET['show']; ?>" />
				</form>
			<?php endif; ?>
		<?php endif; ?>
	<?php endif; ?>
<?php else: ?>
	<?php
		// retrieve pages for login redirection
		$pages=get_pages('exclude='.implode(',',$this->ExcludePages(array(),true)));
		
		// sorting part 1
		list($_GET['s'],$sortorder)=explode(';',$_GET['s']);
		if($sortorder!='d')$sortorder='a';
		$sortorderflip=($sortorder=='d')?'a':'d';
	?>
	<script type="text/javascript">
	function wlm_memberdelete(f){
		var d=f['delete[]'];
		for(var i=0;i<d.length;i++){
			if(d[i].checked){
				if(confirm('Warning! Delete selected membership levels?')){
					return confirm('Last Warning! Are you really sure?\nDeleting membership levels cannot be undone!');
				}else{
					return false;
				}
			}
		}
		return true;
	}
	</script>
	<form method="post" onsubmit="return wlm_memberdelete(this)">
	<table class="widefat wpm_nowrap" id="wpm_membership_levels">
		<thead>
			<tr>
				<th scope="col" class="check-column" style="color:#f00">&nbsp;(X)</th>
				<th scope="col"><a class="wpm_header_link<?php echo $_GET['s']=='n'?' wpm_header_sort'.$sortorder:'';?>" href="?<?php echo $this->QueryString('s')?>&s=n<?php echo $_GET['s']=='n'?';'.$sortorderflip:'';?>">Membership Level</a></th>
				<th scope="col">Role</th>
				<th scope="col">Registration URL</th>
				<th scope="col">Login Redirect</th>
				<th scope="col">Access to</th>
				<th scope="col" class="num">Length of Subscription</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$prevlevels=$prevurls=array();
				// sorting part 2
				ksort($wpm_levels);
				if($_GET['s']=='n') $this->SortLevels($wpm_levels,$sortorder);
				
				foreach($wpm_levels AS $id=>$level):
				
					$errlevel=in_array(strtolower($level['name']),$prevlevels);
					$errurl=in_array($level['url'],$prevurls);
					$prevlevels[]=strtolower($level['name']);
					$prevurls[]=$level['url'];
					
					if($level[wpm_newid]==$id && (!trim($level['name']) || !trim($level['url']))){
						unset($wpm_levels[$id]);
						continue;
					}
					if($level['noexpire']){
						unset($level['expire']);
						unset($level['calendar']);
					}
			?>
			<tr class="<?php echo $alt++%2?'':'alternate'; ?>" id="wpm_level_row_<?php echo $id?>">
				<th class="check-column" scope="row"><input <?php if($level['count'])echo 'disabled="true" ';?>type="checkbox" value="<?php echo $id?>" name="delete[]" onclick="wpm_delete_level(this,'<?php echo $id?>')" />&nbsp;</th>
				<td<?php if($errlevel) echo ' style="background:#ff8888"'; ?>>
					<input type="text" name="wpm_levels[<?php echo $id?>][name]" value="<?php echo attribute_escape($level['name'])?>" id="wpm_inputID()" size="15" />
					<br /><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $id?>][isfree]" value="1" <?php $this->Checked(1,$level['isfree']); ?> /> Free Level</label>
				</td>
				<td>
					<select name="wpm_levels[<?php echo $id?>][role]">
						<option value="<?php echo $x="subscriber"?>"<?php $this->Selected($x,$level['role']); ?>>Subscriber</option>
						<option value="<?php echo $x="contributor"?>"<?php $this->Selected($x,$level['role']); ?>>Contributor</option>
						<option value="<?php echo $x="author"?>"<?php $this->Selected($x,$level['role']); ?>>Author</option>
					</select>
				</td>
				<td<?php if($errurl) echo ' style="background:#ff8888"'; ?>>
					<?php echo $registerurl?>/<input type="text" name="wpm_levels[<?php echo $id?>][url]" value="<?php echo attribute_escape($level['url'])?>" size="6" />
					<br /><br />
					<a href="<?php echo $registerurl?>/<?php echo $level['url']?>" target="_blank"><?php echo $registerurl?>/<?php echo $level['url']?></a>
				</td>
				<td>
				<select name="wpm_levels[<?php echo $id?>][loginredirect]">
					<option value=''>Home Page</option>
					<?php foreach($pages AS $page): ?>
					<option value="<?php echo $page->ID?>"<?php $this->Selected($page->ID,$level['loginredirect']); ?>><?php echo $page->post_title?></option>
					<?php endforeach; ?>
				</select>
				</td>
				<td>
					<label><input type="checkbox" name="wpm_levels[<?php echo $id?>][allpages]" <?php echo ($level['allpages'])?' checked="true"':'';?> />
					All Pages</label><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $id?>][allcategories]" <?php echo ($level['allcategories'])?' checked="true"':'';?> />
					All Categories</label><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $id?>][allposts]" <?php echo ($level['allposts'])?' checked="true"':'';?> />
					All Posts</label><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $id?>][allcomments]" <?php echo ($level['allcomments'])?' checked="true"':'';?> />
					All Comments</label><br />
				</td>
				<td class="num"<?php if(!$level['noexpire'] && $level['expire']<1) echo ' style="background:#ff8888"'; ?>><input type="text" name="wpm_levels[<?php echo $id?>][expire]" value="<?php echo attribute_escape($level['expire'])?>" size="3"<?php echo ($level['noexpire'])?' disabled="true"':'';?> /><select name="wpm_levels[<?php echo $id?>][calendar]"<?php echo ($level['noexpire'])?' disabled="true"':'';?>>
						<option<?php echo ($level['calendar']=='Days')?' selected="true"':''; ?>>Days</option>
						<option<?php echo ($level['calendar']=='Weeks')?' selected="true"':''; ?>>Weeks</option>
						<option<?php echo ($level['calendar']=='Months')?' selected="true"':''; ?>>Months</option>
						<option<?php echo ($level['calendar']=='Years')?' selected="true"':''; ?>>Years</option>
					</select><br />
					<br />
					&nbsp;<label><input type="checkbox" name="wpm_levels[<?php echo $id?>][noexpire]" value="1"<?php echo ($level['noexpire'])?' checked="true"':'';?> onclick="this.parentNode.parentNode.childNodes[0].disabled=this.parentNode.parentNode.childNodes[1].disabled=this.checked" />
					No Expiry Date</label>
					<input type="hidden" name="wpm_levels[<?php echo $id?>][upgradeTo]" value="<?php echo $level['upgradeTo']?>" />
					<input type="hidden" name="wpm_levels[<?php echo $id?>][upgradeAfter]" value="<?php echo $level['upgradeAfter']?>" />
					<input type="hidden" name="wpm_levels[<?php echo $id?>][count]" value="<?php echo $level['count']?>" />
				</td>
				
			</tr>
			<?php endforeach; $this->SaveOption('wpm_levels',$wpm_levels);?>
			<tr>
				<td colspan="6"><h3 style="margin-bottom:0">&raquo; Add New Membership Level</h3></td>
			</tr>
			<tr class="<?php echo $alt++%2?'':'alternate'; ?>" id="wpm_new_row">
				<th class="check-column" scope="row"></th>
				<td>
					<input type="hidden" name="wpm_levels[<?php echo $wpm_newid?>][wpm_newid]" value="<?php echo $wpm_newid?>" /><input type="text" name="wpm_levels[<?php echo $wpm_newid?>][name]" size="15" /><br />&nbsp;(Level Name)
					<br /><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $wpm_newid?>][isfree]" value="1" /> Free Level</label>
				</td>
				<td>
					<select name="wpm_levels[<?php echo $wpm_newid?>][role]">
						<option value="subscriber">Subscriber</option>
						<option value="contributor">Contributor</option>
						<option value="author">Author</option>
					</select>
				</td>
				<td><?php echo $registerurl?>/<input type="text" name="wpm_levels[<?php echo $wpm_newid?>][url]" value="<?php echo $newurl?>" size="6" />
					<br />
				<label for="doclone" style="display:block;margin:5px 0 0 1px;"><input style="float:left;margin:1px 5px 0 0" type="checkbox" name="doclone" id="doclone" value="<?php echo $wpm_newid?>" onclick="wpm_clone_level(this.form)" /> <a>Copy an Existing Membership Level</a></label>
				<div style="margin:0 0 0 18px">
				<select name="clonefrom" style="width:200px" onchange="wpm_clone_level(this.form)">
					<?php foreach($wpm_levels AS $key=>$level): ?>
					<option value="<?php echo $key?>"><?php echo $level['name']?></option>
					<?php endforeach; ?>
				</select>
				</div>
				</td>
				<td>
					<select name="wpm_levels[<?php echo $wpm_newid?>][loginredirect]">
						<option value=''>Home Page</option>
						<?php foreach($pages AS $page): ?>
						<option value="<?php echo $page->ID?>"><?php echo $page->post_title?></option>
						<?php endforeach; ?>
					</select>
				</td>
				<td>
					<label><input type="checkbox" name="wpm_levels[<?php echo $wpm_newid?>][allpages]" />
					All Pages</label><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $wpm_newid?>][allcategories]" />
					All Categories</label><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $wpm_newid?>][allposts]" />
					All Posts</label><br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $wpm_newid?>][allcomments]" />
					All Comments</label><br />
				</td>
				<td class="num"><input type="text" name="wpm_levels[<?php echo $wpm_newid?>][expire]" size="3" /><select name="wpm_levels[<?php echo $wpm_newid?>][calendar]">
						<option>Days</option>
						<option>Weeks</option>
						<option>Months</option>
						<option>Years</option>
					</select><br />
					<br />
					<label><input type="checkbox" name="wpm_levels[<?php echo $wpm_newid?>][noexpire]" value="1" onclick="this.parentNode.parentNode.childNodes[0].disabled=this.parentNode.parentNode.childNodes[1].disabled=this.checked" />
					No Expiry Date</label>
				</td>
			</tr>
		</tbody>
	</table>
	<p class="submit">
		<?php echo '<!-- '; $this->Option('wpm_levels'); echo ' -->'; $this->Options(); $this->RequiredOptions(); ?>
		
		<input type="hidden" name="WLSaveMessage" value="Membership Levels Updated" />
		<input type="hidden" name="WishListMemberAction" value="SaveMembershipLevels" />
		<input type="submit" value="Save Settings" />
	</p>
	</form>
<?php endif; ?>