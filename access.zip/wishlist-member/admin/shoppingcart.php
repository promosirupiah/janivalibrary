<!--  Shopping Carts -->
<?php 
	switch($_GET['cart']){
		case 'pp':
			$ppthankyou=$this->GetOption('ppthankyou');
			if(!$ppthankyou){
				$this->SaveOption('ppthankyou',$ppthankyou=implode('',array_rand(array_flip(array_merge(range('A','Z'),range('a','z'),range(0,9))),6)));
			}
		
			// save POST URL
			if($_POST['ppthankyou']){
				$_POST['ppthankyou']=trim($_POST['ppthankyou']);
				$wpmx=trim(preg_replace('/[^A-Za-z0-9]/','',$_POST['ppthankyou']));
				if($wpmx==$_POST['ppthankyou']){
					$this->SaveOption('ppthankyou',$ppthankyou=$wpmx);
					echo "<div class='updated fade'><p>PayPal Thank You URL Changed.&nbsp; Make sure to update your PayPal products with the same Thank You URL to make it work.</p></div>";
				}else{
					echo "<div class='updated fade'><p><b>Error:</b>PayPal Thank You URL may only contain letters and numbers.</p></div>";
				}
			}
			$ppthankyou_url=$wpm_scregister.$ppthankyou;
			break;
		case 'cb':
			$cbthankyou=$this->GetOption('cbthankyou');
			if(!$cbthankyou){
				$this->SaveOption('cbthankyou',$cbthankyou=implode('',array_rand(array_flip(array_merge(range('A','Z'),range('a','z'),range(0,9))),6)));
			}
			$cbsecret=$this->GetOption('cbsecret');
			if(!$cbsecret){
			  $this->SaveOption('cbsecret',$cbsecret=strtoupper($this->PassGen().$this->PassGen()));
			}
		
			// save POST URL
			if($_POST['cbthankyou']){
				$_POST['cbthankyou']=trim($_POST['cbthankyou']);
				$wpmx=trim(preg_replace('/[^A-Za-z0-9]/','',$_POST['cbthankyou']));
				if($wpmx==$_POST['cbthankyou']){
					$this->SaveOption('cbthankyou',$cbthankyou=$wpmx);
					echo "<div class='updated fade'><p>Thank You URL Changed.&nbsp; Make sure to update your ClickBank products with the same Thank You URL to make it work.</p></div>";
				}else{
					echo "<div class='updated fade'><p><b>Error:</b> Thank You URL may only contain letters and numbers.</p></div>";
				}
			}
			// save Secret Key
			if($_POST['cbsecret']){
				$_POST['cbsecret']=trim(strtoupper($_POST['cbsecret']));
				$wpmy=trim(preg_replace('/[^A-Za-z0-9]/','',$_POST['cbsecret']));
				if($wpmy==$_POST['cbsecret']){
					$this->SaveOption('cbsecret',$cbsecret=$wpmy);
					echo "<div class='updated fade'><p>Secret Key Changed.&nbsp; Make sure to update ClickBank with the same Secret key to make it work.</p></div>";
				}else{
					echo "<div class='updated fade'><p><b>Error:</b> Secret key may only contain letters and numbers.</p></div>";
				}
			}
			$cbthankyou_url=$wpm_scregister.$cbthankyou;
			break;
		case 'qpp':
			$qppthankyou=$this->GetOption('qppthankyou');
			if(!$qppthankyou){
				$this->SaveOption('qppthankyou',$qppthankyou=implode('',array_rand(array_flip(array_merge(range('A','Z'),range('a','z'),range(0,9))),6)));
			}
			$qppsecret=$this->GetOption('qppsecret');
			if(!$qppsecret){
			  $this->SaveOption('qppsecret',$qppsecret=$this->PassGen().$this->PassGen());
			}
		
			// save POST URL
			if($_POST['qppthankyou']){
				$_POST['qppthankyou']=trim($_POST['qppthankyou']);
				$wpmx=trim(preg_replace('/[^A-Za-z0-9]/','',$_POST['qppthankyou']));
				if($wpmx==$_POST['qppthankyou']){
					$this->SaveOption('qppthankyou',$qppthankyou=$wpmx);
					echo "<div class='updated fade'><p>Post To URL Changed.&nbsp; Make sure to update QuickPayPro with the same Post To URL to make it work.</p></div>";
				}else{
					echo "<div class='updated fade'><p><b>Error:</b> Post To URL may only contain letters and numbers.</p></div>";
				}
			}
			// save Secret Key
			if($_POST['qppsecret']){
				$_POST['qppsecret']=trim($_POST['qppsecret']);
				$wpmy=trim(preg_replace('/[^A-Za-z0-9]/','',$_POST['qppsecret']));
				if($wpmy==$_POST['qppsecret']){
					$this->SaveOption('qppsecret',$qppsecret=$wpmy);
					echo "<div class='updated fade'><p>Secret Key Changed.&nbsp; Make sure to update QuickPayPro with the same Secret key to make it work.</p></div>";
				}else{
					echo "<div class='updated fade'><p><b>Error:</b> Secret key may only contain letters and numbers.</p></div>";
				}
			}
			$qppthankyou_url=$wpm_scregister.$qppthankyou;
			break;
		case '':
			$scthankyou=$this->GetOption('scthankyou');
			if(!$scthankyou){
				$this->SaveOption('scthankyou',$scthankyou=implode('',array_rand(array_flip(array_merge(range('A','Z'),range('a','z'),range(0,9))),6)));
			}
			if($_POST['scthankyou']){
				$_POST['scthankyou']=trim($_POST['scthankyou']);
				$wpmx=trim(preg_replace('/[^A-Za-z0-9]/','',$_POST['scthankyou']));
				if($wpmx==$_POST['scthankyou']){
					$this->SaveOption('scthankyou',$wpmx);
					$scthankyou=$wpmx;
					echo "<div class='updated fade'><p>Thank You URL Changed.&nbsp; Make sure to update 1ShoppingCart with the new Thank You URL to make it work.</p></div>";
				}else{
					echo "<div class='updated fade'><p><b>Error:</b> Thank You URL may only contain letters and numbers.</p></div>";
				}
			}
			$scthankyou_url=$wpm_scregister.$scthankyou.'.php';
			break;
	}
?>
<h2 style="font-size:18px;width:100%;border:none;">Shopping Cart Integration</h2>
<form method="get">
<table class="form-table">
	<?php
		parse_str($this->QueryString('cart'),$fields);
		foreach($fields AS $field=>$value){
			echo "<input type='hidden' name='{$field}' value='{$value}' />";
		}
	?>
	<tr>
		<th scope="row">Select Shopping Cart</th>
		<td width="1">
			<select name="cart" onchange="this.form.submit()">
				<option value="">1ShoppingCart</option>
				<option value="cb"<?php if($_GET['cart']=='cb')echo ' selected="true" ';?>>Clickbank</option>
				<option value="pp"<?php if($_GET['cart']=='pp')echo ' selected="true" ';?>>Paypal</option>
				<option value="qpp"<?php if($_GET['cart']=='qpp')echo ' selected="true" ';?>>QuickPayPro</option>
			</select>
		</td>
		<td>
			<noscript><p class="submit" style="margin:0;padding:0"><input type="submit" value="Select Shopping Cart" /></p></noscript>
		</td>
	</tr>
</table>
</form>
<hr />
<blockquote>

<?php if($_GET['cart']=='pp'): ?>

	<!-- PayPal -->
	<h2 style="font-size:18px;width:100%">Paypal Integration</h2>
	<p>Integrating WL Member to PayPal can be done in 2 steps</p>
	<blockquote>
	<h2 style="font-size:18px;width:100%;border:none;">Step 1. Create a "Buy Now" or "Subscribe" Button in Merchant Services Section of PayPal.<br />Create a button for each membership level using the Item/Subscription ID specified below.</h2>
	<table class="widefat">
		<thead>
			<tr>
				<th scope="col" width="200">Membership Level</th>
				<th scope="col">Item/Subscription ID</th>
			</tr>
		</thead>
		<tbody>
			<?php $alt=0; foreach($wpm_levels AS $sku=>$level): ?>
			<tr class="<?php echo $alt++%2?'':'alternate'; ?>" id="wpm_level_row_<?php echo $sku?>">
				<td><b><?php echo $level['name']?></b></td>
				<td><u style="font-size:1.2em"><?php echo $sku?></u></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<form method="post">
	<h2 style="font-size:18px;width:100%">Step 2. Set the "Thank You URL" of each product to the following URL:</h2>
	<p>&nbsp;&nbsp;<a href="<?php echo $ppthankyou_url?>" onclick="return false"><?php echo $ppthankyou_url?></a> &nbsp; (<a href="javascript:;" onclick="document.getElementById('ppthankyou').style.display='block';">change</a>)</p>
	<div id="ppthankyou" style="display:none">
	<p>&nbsp;&nbsp;<?php echo $wpm_scregister?><input type="text" name="ppthankyou" value="<?php echo $ppthankyou?>" size="8" /><input type="submit" value="Change" /></p>
	</div>
	<h2 style="font-size:18px;width:100%">Step 3. Paste the code below in the "Add advanced variables" field:</h2>
	<p><b>notify_url=<?php echo $ppthankyou_url?></b></p>
	<p>* This is located in PayPal's step 3 of creating a "Buy Now" button. It will say "Customize advanced features (optional)".</p>
	</form>
	</blockquote>

<?php elseif($_GET['cart']=='cb'): ?>

	<!-- Clickbank -->
	<h2 style="font-size:18px;width:100%">Clickbank Integration</h2>
	<p>Integrating WL Member to Clickbank can be done in 3 steps</p>
	<blockquote>
	<form method="post">
	<h2 style="font-size:18px;">Step 1. Set the "Thank You URL" of your ClickBank products to the following:</h2>
	<p>&nbsp;&nbsp;<a href="<?php echo $cbthankyou_url?>" onclick="return false"><?php echo $cbthankyou_url?></a> &nbsp; (<a href="javascript:;" onclick="document.getElementById('cbthankyou').style.display='block';">change</a>)</p>
	<div id="cbthankyou" style="display:none">
	<p>&nbsp;&nbsp;<?php echo $wpm_scregister?><input type="text" name="cbthankyou" value="<?php echo $cbthankyou?>" size="8" /> <input type="submit" value="Change" /></p>
	</div>
	</form>
	<form method="post">
	<h2 style="font-size:18px;width:100%;border:none;">Step 2. Specify a Secret Word.</h2>
	<p>&nbsp;&nbsp;<input type="text" name="cbsecret" value="<?php echo $cbsecret?>" size="20" maxlength='16' /> <input type="submit" value="Change" /></p>
	</form>
	<h2 style="font-size:18px;width:100%;border:none;">Step 3. Create a product for each membership level you want to integrate and use the Payment Links specified for each product below.  Replace <font color="red">ITEM</font> with the item name assigned by Clickbank and <font color="blue">PUBLISHER</font> with your Clickbank Publisher ID.</h2>
	<table class="widefat">
		<thead>
			<tr>
				<th scope="col" width="200">Membership Level</th>
				<th scope="col">Payment Link</th>
			</tr>
		</thead>
		<tbody>
			<?php $alt=0; foreach($wpm_levels AS $sku=>$level): ?>
			<tr class="<?php echo $alt++%2?'':'alternate'; ?>" id="wpm_level_row_<?php echo $sku?>">
				<td><b><?php echo $level['name']?></b></td>
				<td><u style="font-size:1.2em">http://<font color="red">ITEM</font>.<font color="blue">PUBLISHER</font>.pay.clickbank.net?sku=<?php echo $sku?></u></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</blockquote>

<?php elseif($_GET['cart']=='qpp'): ?>

	<!-- Quick Pay Pro -->
	<h2 style="font-size:18px;width:100%">QuickPayPro Integration</h2>
	<p>Integrating WL Member to QuickPayPro can be done in 2 steps</p>
	<blockquote>
	<form method="post">
	<h2 style="font-size:18px;">Step 1. Set the "Post To URL" of your QuickPayPro account<br />or the "Post To URL" of each product to the following URL:</h2>
	<p>&nbsp;&nbsp;<a href="<?php echo $qppthankyou_url?>" onclick="return false"><?php echo $qppthankyou_url?></a> &nbsp; (<a href="javascript:;" onclick="document.getElementById('qppthankyou').style.display='block';">change</a>)</p>
	<div id="qppthankyou" style="display:none">
	<p>&nbsp;&nbsp;<?php echo $wpm_scregister?><input type="text" name="qppthankyou" value="<?php echo $qppthankyou?>" size="8" /> <input type="submit" value="Change" /></p>
	</div>
	</form>
	<form method="post">
	<h2 style="font-size:18px;width:100%;border:none;">Step 2. Specify a Secret Word.</h2>
	<p>&nbsp;&nbsp;<input type="text" name="qppsecret" value="<?php echo $qppsecret?>" size="20" maxlength='16' /> <input type="submit" value="Change" /></p>
	</form>
	<h2 style="font-size:18px;width:100%;border:none;">Step 3. Create a product for each membership level using the Level IDs specified below</h2>
	<table class="widefat">
		<thead>
			<tr>
				<th scope="col" width="200">Membership Level</th>
				<th scope="col">Level ID</th>
			</tr>
		</thead>
		<tbody>
			<?php $alt=0; foreach($wpm_levels AS $sku=>$level): ?>
			<tr class="<?php echo $alt++%2?'':'alternate'; ?>" id="wpm_level_row_<?php echo $sku?>">
				<td><b><?php echo $level['name']?></b></td>
				<td><u style="font-size:1.2em"><?php echo $sku?></u></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</blockquote>

<?php elseif($_GET['cart']==''): ?>

	<!-- 1ShoppingCart -->
	<h2 style="font-size:18px;width:100%">1ShoppingCart Integration</h2>
	<p>Integrating WL Member to 1ShoppingCart can be done in 2 steps</p>
	<blockquote>
	<form method="post">
	<h2 style="font-size:18px;">Step 1. Set the "Thank You URL" of your 1ShoppingCart account<br />or the "Thank You URL" of each product to the following URL:</h2>
	<p>&nbsp;&nbsp;<a href="<?php echo $scthankyou_url?>" onclick="return false"><?php echo $scthankyou_url?></a> &nbsp; (<a href="javascript:;" onclick="document.getElementById('scthankyou').style.display='block';">change</a>)</p>
	<div id="scthankyou" style="display:none">
	<p>&nbsp;&nbsp;<?php echo $wpm_scregister?><input type="text" name="scthankyou" value="<?php echo $scthankyou?>" size="8" />.php <input type="submit" value="Change" /></p>
	</div>
	</form>
	<h2 style="font-size:18px;width:100%;border:none;">Step 2. Create a product for each membership level using the SKU specified below</h2>
	<table class="widefat">
		<thead>
			<tr>
				<th scope="col" width="200">Membership Level</th>
				<th scope="col">SKU</th>
			</tr>
		</thead>
		<tbody>
			<?php $alt=0; foreach($wpm_levels AS $sku=>$level): ?>
			<tr class="<?php echo $alt++%2?'':'alternate'; ?>" id="wpm_level_row_<?php echo $sku?>">
				<td><b><?php echo $level['name']?></b></td>
				<td><u style="font-size:1.2em"><?php echo $sku?></u></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	</blockquote>

<?php endif; ?>

</blockquote>