<?php
/*
Plugin Name: WishList Member
Plugin URI: http://www.wpwishlist.com/
Description: WishList Member is the most comprehensive membership plugin for Wordpress users. It allows you to create multiple membership levels, protect desired content and much more. For more Wordpress tools please visit the <a href="http://www.wpwishlist.com/blog" target="_blank">Wordpress WishList Blog</a>
Author: Wordpress WishList
Version: 2.16.01
Author URI: http://www.wpwishlist.com/
*/

error_reporting(0);
require_once('core/Functions.php');
require_once('core/Class.php');
require_once('core/PluginMethods.php');

// -----------------------------------------
// Our plugin class
if(!class_exists('WishListMember')){
	class WishListMember extends WishListMemberPluginMethods{
		var $countries=array('Afghanistan','Aland Islands','Albania','Algeria','American Samoa','Andorra','Angola','Anguilla','Antarctica','Antigua And Barbuda','Argentina','Armenia','Aruba','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Belize','Benin','Bermuda','Bhutan','Bolivia','Bosnia And Herzegovina','Botswana','Bouvet Island','Brazil','British Indian Ocean Territory','Brunei Darussalam','Bulgaria','Burkina Faso','Burundi','Cambodia','Cameroon','Canada','Cape Verde','Cayman Islands','Central African Republic','Chad','Channel Islands','Chile','China','Christmas Island','Cocos (Keeling) Islands','Colombia','Comoros','Congo','Congo The Dem. Rep. Of The','Cook Islands','Costa Rica','Cote Divoire','Croatia','Cuba','Cyprus','Czech Republic','Denmark','Djibouti','Dominica','Dominican Republic','East Timor','Ecuador','Egypt','El Salvador','Equatorial Guinea','Eritrea','Estonia','Ethiopia','Falkland Islands (Malvinas)','Faroe Islands','Fiji','Finland','France','French Guiana','French Polynesia','French Southern Territories','Gabon','Gambia','Georgia','Germany','Ghana','Gibraltar','Greece','Greenland','Grenada','Guadeloupe','Guam','Guatemala','Guersney','Guinea','Guinea-Bissau','Guyana','Haiti','Heard Island And Mcdonald Islands','Holy See (Vatican City State)','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran Islamic Republic Of','Iraq','Ireland','Isle of Man','Israel','Italy','Jamaica','Japan','Jersey','Jordan','Kazakstan','Kenya','Kiribati','Korea Democratic Peoples Republic','Kuwait','Kyrgyzstan','Lao Peoples Democratic Republic','Latvia','Lebanon','Lesotho','Liberia','Libya','Libyan Arab Jamahiriya','Liechtenstein','Lithuania','Luxembourg','Macau','Macedonia','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Marshall Islands','Martinique','Mauritania','Mauritius','Mayotte','Mexico','Micronesia Federated States Of','Moldova Republic Of','Monaco','Mongolia','Montenegro','Montserrat','Morocco','Mozambique','Myanmar','Namibia','Nauru','Nepal','Netherlands','Netherlands Antilles','New Caledonia','New Zealand','Nicaragua','Niger','Nigeria','Niue','Norfolk Island','Northern Mariana Islands','Norway','Oman','Pakistan','Palau','Palestinian Territory Occupied','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Pitcairn','Poland','Portugal','Puerto Rico','Qatar','Reunion','Romania','Russia','Russian Federation','Rwanda','Saint Helena','Saint Kitts And Nevis','Saint Lucia','Saint Pierre And Miquelon','Saint Vincent And The Grenadines','Samoa','San Marino','Sao Tome And Principe','Saudi Arabia','Senegal','Serbia','Serbia &amp; Montenegro','Seychelles','Sierra Leone','Singapore','Slovakia','Slovenia','Solomon Islands','Somalia','South Africa','South Georgia / South Sandwich Islands','South Korea','Spain','Sri Lanka','Sudan','Suriname','Svalbard And Jan Mayen','Swaziland','Sweden','Switzerland','Syrian Arab Republic','Taiwan','Tajikistan','Tanzania United Republic Of','Thailand','Timor-Leste','Togo','Tokelau','Tonga','Trinidad And Tobago','Tunisia','Turkey','Turkmenistan','Turks And Caicos Islands','Tuvalu','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States','United States Minor Outlying Islands','Uruguay','Uzbekistan','Vanuatu','Venezuela','Vietnam','Virgin Islands British','Virgin Islands U.S.','Wallis And Futuna','Western Sahara','Yemen','Yugoslavia','Zambia','Zimbabwe');
		
		// -----------------------------------------
		// Constructor call
		function WishListMember(){
			$x=func_get_args();
			$this->AllCategories=get_all_category_ids();
			$this->Constructor(__FILE__,$x[0],$x[1],$x[2],$x[3]);
            // constant
            define('WLMCANSPAM',"If you no longer wish to receive communication from us:\n".get_bloginfo("siteurl")."/?wlmunsub=%s\n\nTo update your contact information:\n".get_bloginfo('wpurl')."/wp-admin/profile.php");
            define('WLMUNSUBKEY','ffa4017f6494a6637ca2636031d29eb7');
		}

		// -----------------------------------------
		// Plugin activation
		function Activate(){
			// This is where you place code that runs on plugin activation
			$this->AddOption('pending_period','');
			$this->AddOption('rss_secret_key',md5(microtime()));
			$this->AddOption('protect_after_more','1');
			$this->AddOption('auto_insert_more','0');
			$this->AddOption('private_tag_protect_msg','<i>[Content protected for [level] members only]</i>');
			$this->AddOption('notify_admin_of_newuser','1');
			$this->AddOption('members_can_update_info','1');

			$this->AddOption('show_linkback','1');

			$this->AddOption('wpm_levels',array());

			$user=new WP_User(1);
			$name=trim($user->first_name.' '.$user->last_name);
			if(!$name)$name=$user->user_nicename;
			if(!$name)$name=$user->user_login;

			$this->AddOption('email_sender_name',$name);
			$this->AddOption('email_sender_address',$user->user_email);

			$this->AddOption('register_email_subject','Congrats - You are registered!');
			$this->AddOption('register_email_body',"Dear [firstname],\n\nYou have successfully registered as one of our [memberlevel] members.\n\nPlease keep this information safe as it contains your username and password.\n\nYour Membership Info:\nU: [username]\nP: [password]\n\nLogin URL: [loginurl]\n\nBe sure to drop by the site as we are continuously adding to the members area.\n\nTo your success!");

			$this->AddOption('lostinfo_email_subject','RE: Your membership login info');
			$this->AddOption('lostinfo_email_message',"Dear [firstname],\n\nOur records show that you recently asked to reset the password for your account.\n\nYour current information is:\nUsername: [username]\nMembership: [memberlevel]\n\nAs a security measure all passwords are encrypted in our database and cannot be retrieved. However, you can easily reset it.\n\nTo reset your password visit the following URL, otherwise just ignore this email and your membership info will remain the same.\n\n[reseturl]\n\nThanks again!");

			$this->AddOption('newmembernotice_email_recipient',$user->user_email);
			$this->AddOption('newmembernotice_email_subject','A New Member has Registered');
			$this->AddOption('newmembernotice_email_message',"A new member has registered with the following info:\n\nFirst Name: [firstname]\nLast Name: [lastname]\nEmail: [email]\nMembership Level: [memberlevel]\nUsername: [username]\nPassword: [password]\n\nThank you.");
		}

		// -----------------------------------------
		// Plugin Deactivation
		function Deactivate(){
			// we delete magic page.
			wp_delete_post($this->MagicPage(false));
		}

		// -----------------------------------------
		// Admin Head
		function AdminHead(){
			if($_GET['page']==$this->MenuID){
				echo "<link rel='stylesheet' type='text/css' href='{$this->pluginURL}/css/admin_main.css' />";
				echo "<script type='text/javascript' src='{$this->pluginURL}/js/admin_main.js'></script>";
				echo "<link rel='stylesheet' type='text/css' href='{$this->pluginURL}/css/admin_more.css' />";
				echo "<script type='text/javascript' src='{$this->pluginURL}/js/admin_more.js'></script>";
			}elseif(basename($_SERVER['PHP_SELF'])=='categories.php'){
				echo "<script type='text/javascript' src='{$this->pluginURL}/js/admin_main.js'></script>";
				echo "<script type='text/javascript' src='{$this->pluginURL}/js/admin_more.js'></script>";
			}
			if(!$GLOBALS['current_user']->caps['administrator']){
				echo "<style type=\"text/css\">\n\n/* WishList Member */\ndiv#user_info,ul#dashmenu{ display:none; }\n#wphead{ border-top-width:2px; }\n#menu-dashboard{display:none;}\n</style>\n";
			}
		}

		// -----------------------------------------
		// Init Hook
		function UnsubJavaScript(){
            echo '<script type="text/javascript">alert("You have been unsubscribed from our mailing list.");</script>';
        }

		// -----------------------------------------
		// Init Hook
		function Init(){
			global $wpdb;
			$error_reporting=error_reporting(0);

            if($_GET['wlmunsub']){
                list($uid,$key)=explode('/',$_GET['wlmunsub']);
                $mykey=substr(md5($uid.WLMUNSUBKEY),0,10);
                $user=new WP_User($uid);
                if($user->ID && $mykey==$key){
                    update_usermeta($user->ID,'wlm_unsubscribe',1);
                    $url=$this->UnsubscribeURL();
                    if($url){
                        header('Location:'.$url);
                        exit;
                    }else{
                        add_action('wp_head',array(&$this,'UnsubJavaScript'));
                    }
                }

            }
			if($_GET['loginlimit']){
				$GLOBALS['error']=$this->GetOption('login_limit_error');
			}
			$GLOBALS['wp_rewrite']->flush_rules();

			// process registration URL...			
			$scuri=$this->RegistrationURL();
			
			if($_GET['wpm_download_sample_csv']==1) $this->SampleImportCSV();
			
			if($scuri){
				// 1shoppingcart post url?
				$do1sc=$this->GetOption('scthankyou').'.php'==$scuri;
				if($do1sc)$_POST['WishListMemberAction']='WPMRegister';

				// quickpaypro post url?
				$doqpp=$this->GetOption('qppthankyou')==$scuri;
				if($doqpp)$_POST['WishListMemberAction']='WPMRegister';

				// clickbank post url?
				$doclickbank=$this->GetOption('cbthankyou')==$scuri;
				if($doclickbank)$_POST['WishListMemberAction']='WPMRegister';

				// clickbank post url?
				$dopaypal=$this->GetOption('ppthankyou')==$scuri;
				if($dopaypal)$_POST['WishListMemberAction']='WPMRegister';
			}
			
			switch($_POST['WishListMemberAction']){
				case 'SaveMembershipLevels':
					$this->SaveOptions();
					// do we clone?
					if($_POST['doclone']){
						$this->CloneMembershipContent($_POST['clonefrom'],$_POST['doclone']);
					}
				break;
				case 'SaveMembershipContent':
					$this->SaveMembershipContent();
				break;
				case 'SaveMembersData':
					$this->SaveMembersData();
				break;
				case 'MoveMembership':
					$this->MoveMembership();
				break;
				case 'ImportMembers':
					require_once($this->pluginDir.'/core/User.php');
					$this->ImportMembers();
				break;
				case 'ExportMembers':
					require_once($this->pluginDir.'/core/User.php');
					$this->ExportMembers();
				break;
				case 'SaveSequential':
					$this->SaveSequential();
				break;
				case 'WPMRegister':
					// Added by Admin
					if($_POST['wpmtheadminkhas78ajd']=='kjhad7kjghadjjhgas72jga878uayjahsd72uy3yg*&^&%@J$'){
						$wpm_errmsg='';
						$registered=$this->WPMRegister($_POST,$wpm_errmsg);
						if($registered){
							$_POST=array('msg'=>'<b>New Member Added.</b>');
						}else{
							$_POST['err']=$wpm_errmsg;
						}
					}elseif($_POST){
						if($do1sc)$this->OneShoppingCart();
						if($doqpp)$this->QuickPayPro();
						if($doclickbank)$this->ClickBank();
						if($dopaypal)$this->Paypal();
					}
				break;
				case 'EmailBroadcast':
					// email broadcast
					$this->EmailBroadcast();
				break;
			}

			// no levels configured
			$wpm_levels=(array)$this->GetOption('wpm_levels');
			if(!count($wpm_levels)){
				add_action('admin_notices',array(&$this,'ErrNoLevels'));
			}

			// widget setup
			if(function_exists('register_sidebar_widget')){
				register_sidebar_widget('WishList Member',array(&$this,'Widget'),null);
				register_widget_control('WishList Member',array(&$this,'WidgetAdmin'));
			}

			$current_user=wp_get_current_user();
			// No profile editing for members
			if($current_user->ID && basename(dirname($_SERVER['PHP_SELF']))=='wp-admin' && !$this->GetOption('members_can_update_info') && !$current_user->caps['administrator']){
				header('Location:'.get_bloginfo('url'));
				exit;
			}
			
			// Do not allow access to Dashboard for non-admins
			if($current_user->ID && basename(dirname($_SERVER['PHP_SELF'])).'/'.basename($_SERVER['PHP_SELF'])=='wp-admin/index.php' && !$current_user->caps['administrator']){
				header('Location:profile.php');
				exit;
			}

			// sequential upgrade
			if($current_user->ID && $this->IsSequential($current_user->ID) && !$this->IsPending($current_user->ID)){
				$levels=$this->GetMembershipLevels($current_user->ID);
				$current_user->wpm_leveltimestamp=$this->UserLevelTimestamp($current_user->ID);
				foreach($levels AS $levelkey=>$level){
                    if(!$this->LevelCancelled($level,$current_user->ID)){ // no sequential upgrades for cancelled memberships
                        if(isset($wpm_levels[$level])){
                            $xlevel=$level;
                            $level=$wpm_levels[$level];
                            $ts=(int)$current_user->wpm_leveltimestamp[$xlevel];

                            // if a timestamp for the level is not found, then set the level timestamp to the user's registration date...
                            if(!$ts)$ts=$current_user->wpm_leveltimestamp[$xlevel]=strtotime($current_user->user_registered);

                            $xnext=($ts+$level['upgradeAfter']*86400);
                            if($level['upgradeTo'] && $level['upgradeAfter'] && isset($wpm_levels[$level['upgradeTo']]) && $xnext<time()){
                                // sequential upgrade...
                                if($level['upgradeMethod']=='MOVE' || !$level['upgradeMethod']){
                                    $levels[$levelkey]=$level['upgradeTo']; // replace current level with new level
                                    unset($current_user->wpm_leveltimestamp[$xlevel]); // delete timestamp for current level
                                	$current_user->wpm_leveltimestamp[$level['upgradeTo']]=$xnext; // set timestamp for new level
                                }else{
                                	if(!in_array($level['upgradeTo'],$levels)){
                                    	$levels[]=$level['upgradeTo']; // add new level
                                    	$current_user->wpm_leveltimestamp[$level['upgradeTo']]=$xnext; // set timestamp for new level
                                	}
                                }
                                do_action('wishlistmember_sequential',$level['upgradeTo'],$current_user,$this);
                            }
                        }
                    }
				}
				$this->SetMembershipLevels($current_user->ID,array_unique($levels));
				$this->UserLevelTimestamp($current_user->ID,$current_user->wpm_leveltimestamp);
			}

			// recent comments widget hack
			$levels=$this->GetMembershipLevels($current_user->ID);
			$ids=$pids=$protect=array(0);
			/* get posts where comments can be viewed by this user */
				$comments=$this->GetMembershipContent('comments');
				foreach($levels AS $level) $ids=array_merge($ids,$comments[$level]);
				$ids=array_unique($ids);
			/* get posts that the user can view */
				$posts=$this->GetMembershipContent('posts');
				foreach($levels AS $level) $pids=array_merge($pids,$posts[$level]);
				$pids=array_unique($pids);
			/* check allowed comments against allowed posts.  we only want ids where the user is allowed to view the post and the comment */
				$ids=array_intersect($ids,$pids);
				$ids[]=0; // ticket 688436
			/* make sure the ids are all numeric.  otherwise, our query will fail */
				for($i=0;$i<count($ids);$i++)$ids[$i]+=0;
				$ids=implode(',',array_unique($ids));
				
			/* get protected posts */
				$protect=explode(',',$this->GetOption('Protect'));
				$protect[]=0; // ticket 688436
				for($i=0;$i<count($protect);$i++)$protect[$i]+=0;
				$protect=implode(',',array_unique($protect));
				
			/* get recent comment widget options:number */
				$number=get_option('widget_recent_comments');
				$number=(int)$number['number'];
				if(!$number)$number=5;
				elseif($number<1)$number=1;
				elseif($number>15)$number=15;
			/* let's fetch recent comments for this user */
				$comments=$wpdb->get_results($x="SELECT comment_author, comment_author_url, comment_ID, comment_post_ID FROM $wpdb->comments WHERE comment_approved = '1' AND (comment_post_ID IN ({$ids}) OR comment_post_ID NOT IN ({$protect})) ORDER BY comment_date_gmt DESC LIMIT $number");
				if(!$comments)$comments=true; // if no comments were returned, we set $comments to true to prevent recent comments widget from fetching comments
			/* push comments to cache so that recent_comments plugin will use it and not generate its own */
				wp_cache_add('recent_comments',$comments,'widget');

            /* load extensions */
            $extensions=glob($this->pluginDir.'/extensions/*.php');
            foreach($extensions AS $extension){
                include_once($extension);
            }

			error_reporting($error_reporting);
		}

		function ErrNoLevels(){
			$wl='membershiplevels';
			if($_GET['wl']!=$wl){
				$addlevelurl=$this->GetMenu($wl);
				echo '<div class="updated fade"><p><strong>WishList Member Notice:</strong> No Membership Levels added yet. <a href="admin.php'.$addlevelurl->URL.'">Click here</a> to add a new membership level now.</strong></p></div>';
			}
		}

		// -----------------------------------------
		// Post / Page Options Hook
		function PostPageOptions(){
			global $post;
			if($post->post_type=='page'){
				$allindex='allpages';
				$ContentType='pages';
			}else{
				$allindex='allposts';
				$ContentType='posts';
			}
			$wpm_levels=$this->GetOption('wpm_levels');
			$wpm_access=array_flip($this->GetContentLevels($ContentType,$post->ID));
			$wpm_protect=$this->Protect($post->ID)=='Y' | !$post->ID;
			?>
			<script type="text/javascript">
				function wpm_toggleAllLevels(o){
					var x=document.getElementById('allwpmlevels').getElementsByTagName('input');
					if(x.length){
						for(i=0;i<x.length;i++){
							if(!x[i].disabled) x[i].checked=o.checked;
						}
					}
				}
			</script>
			<div class="postbox" id="wpm_options_div">
				<h3><a class="togbox">+</a>WishList Member</h3>
				<div class="inside">
					<p>Do you want to protect this content?</p>
					<blockquote><label><input type="radio" name="wpm_protect" value="N"<?php if(!$wpm_protect)echo ' checked="true"'; ?> /> No, do not protect this content (non-members can access it)</label><br />
						<label><input type="radio" name="wpm_protect" value="Y"<?php if($wpm_protect)echo ' checked="true"'; ?> /> Yes, protect this content (members only)</label>
					</blockquote>
					<?php if(count($wpm_levels)): ?>
					<p>Select the membership level that can access this content:</p>
					<blockquote><label><input type="checkbox" onclick="wpm_toggleAllLevels(this)" /> Select/Unselect All Levels</label><br />
						<div id="allwpmlevels" style="border-top:1px solid #ddd;margin-top:3px;padding-top:3px">
						<?php foreach($wpm_levels AS $id=>$level): ?>
						<label><input type="checkbox" name="wpm_access[<?php echo $id?>]"<?php if(isset($wpm_access[$id])||isset($level[$allindex]))echo ' checked="true"'; if(isset($level[$allindex]))echo ' disabled="true"'; ?>  value="<?php echo $post->ID?>" /> <?php echo $level['name']?></label><br />
						<?php endforeach; ?>
						</div>
					</blockquote>
					<?php endif; ?>
					<p><b>NOTES</b>:</p>
					<p>Private Tags: You can hide parts of the post by adding [private_level] <code>your text goes here</code> [/private_level].  Remember to switch the word "level" with the membership level you would like to give access to.</p>
					<hr />
					<p>Registration Codes: You can insert a registration form for each level by adding [register_level] to your posts.</p>
					<hr />
					<p>Merge Codes: You can also insert the following merge codes in your post</p>
					<ul>
						<li><p>First Name: [firstname]</p></li>
						<li><p>Last Name: [lastname]</p></li>
						<li><p>Email: [email]</p></li>
						<li><p>Membership Level: [memberlevel]</p></li>
						<li><p>Username: [username]</p></li>
					</ul>
				</div>
			</div>
			<?php
		}

		// -----------------------------------------
		// Save Post / Page Hook
		function SavePostPage(){
			$ContentType=$_POST['post_type']=='page'?'pages':'posts';
			$this->Protect($_POST['post_ID'],$_POST['wpm_protect']);
			$this->SetContentLevels($ContentType,$_POST['post_ID'],$_POST['wpm_access']?array_keys($_POST['wpm_access']):array());
		}

		// -----------------------------------------
		// Delete user Hook
		function DeleteUser($id){
			$levels=$this->GetMembershipLevels($id);
			$usr=get_userdata($id);
			if($usr->ID){
				foreach($levels AS $level){
					$this->ARUnsubscribe($usr->first_name,$usr->last_name,$usr->user_email,$level);
				}
			}
			$this->SyncMembership();
		}

		// -----------------------------------------
		// Update profile Hook
		function ProfileUpdate(){
			$current_user=wp_get_current_user();
            if($current_user->ID){
                if($_POST['wlm_unsubscribe']){
                    delete_usermeta($_POST['user_id'],'wlm_unsubscribe');
                }else{
                    update_usermeta($_POST['user_id'],'wlm_unsubscribe',1);
                }
            }
			if($current_user->caps['administrator']){
				if($_POST['wpm_delete_member']){
					if($_POST['user_id']>1)wp_delete_user($_POST['user_id']);
					$msg='<b>User DELETED.</b>';
					$this->DeleteUser($_POST['user_id']);
				}else{
					$this->SetMembershipLevels($_POST['user_id'],$_POST['wpm_levels']);
					update_usermeta($_POST['user_id'],'wpm_login_limit',$_POST['wpm_login_limit']);
					$msg='<b>Member Profile UPDATED.</b>';
				}
			}
			// address
			foreach($_POST['wpm_useraddress'] AS $k=>$v){
				$_POST['wpm_useraddress'][$k]=stripslashes($v);
			}
			update_usermeta($_POST['user_id'],'wpm_useraddress',$_POST['wpm_useraddress']);
			
			if(in_array($_GET['wp_http_referer'],array('wlm','http://wlm'))){
				$link=$this->GetMenu('members');
				header("Location:admin.php".$link->URL.'&msg='.urlencode($msg));
				exit;
			}
		}

		// -----------------------------------------
		// Login Hook
		function Login(){
			$user=new WP_User($_POST['log']);
			if($this->LoginCounter($user)){
				// save IP
				update_usermeta($user->ID,'wpm_login_ip',$_SERVER['REMOTE_ADDR']);
				update_usermeta($user->ID,'wpm_login_date',time()-get_option('gmt_offset')*3600);
				if($_POST['redirect_to']=='wishlistmember' || !$user->caps['administrator']){
					$url=get_bloginfo('url');
					$levels=$this->GetMembershipLevels($user->ID);
					sort($levels);
					$wpm_levels=$this->GetOption('wpm_levels');
					foreach($levels AS $level){
						if($wpm_levels[$level]['loginredirect']){
							$url=get_permalink($wpm_levels[$level]['loginredirect']);
						}
					}
					header("Location:".$url);
					exit;
				}
			}
		}

		// -----------------------------------------
		// Logout Hook
		function Logout(){
			global $current_user;
			// remove current IP from the login counter list
			$counter=(array)get_usermeta($current_user->ID,'wpm_login_counter');
			unset($counter[$_SERVER['REMOTE_ADDR']]);
			update_usermeta($current_user->ID,'wpm_login_counter',$counter);
		}

		// -----------------------------------------
		// Reset Password Hook
		function RetrievePassword($user_login){
			global $wpdb;
			$wpm_levels=(array)$this->GetOption('wpm_levels');

			/* create our own reset key */
			/* start of code copied from wp-login.php */
			$key=$wpdb->get_var($wpdb->prepare("SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s",$user_login));
			if (empty($key)){
				// Generate something random for a key...
				$key=wp_generate_password(20,false);
				do_action('retrieve_password_key',$user_login,$key);
				// Now insert the new md5 key into the db
				$wpdb->query($wpdb->prepare("UPDATE $wpdb->users SET user_activation_key = %s WHERE user_login = %s",$key,$user_login));
			}
			/* end of copied code */

			$user=new WP_User($user_login);
			$macros=array();
			$macros['firstname']=$user->first_name;
			$macros['lastname']=$user->last_name;
			$macros['email']=$user->user_email;
			$macros['memberlevel']=$this->GetMembershipLevels($user->ID,true);
			$macros['username']=$user->user_login;
			$macros['reseturl']=get_bloginfo('wpurl').'/wp-login.php?action=rp&key='.$key;
			$this->SendMail($user->user_email,$this->GetOption('lostinfo_email_subject'),$this->GetOption('lostinfo_email_message'),$macros);
			header("Location:".get_bloginfo('wpurl').'/wp-login.php?checkemail=confirm');
			exit;
		}

		// -----------------------------------------
		// Footer Hook
		function Footer(){
			if($this->GetOption('show_linkback')){
				$aff=$this->GetOption('affiliate_id');
				$url=$aff?'http://member.wpwishlist.com/cmd.php?af='.$aff:'http://wishlistmember.com/';
				
			}
		}

		// -----------------------------------------
		// Exclude certain pages from the list
		function ExcludePages($pages,$noerror=false){
			$x=array_unique(array_merge($pages,array($this->MagicPage(false))));
			if(!$noerror){
				$x[]=$this->GetOption('non_members_error_page_internal');
				$x[]=$this->GetOption('wrong_level_error_page_internal');
				$x[]=$this->GetOption('after_registration_internal');
				$x[]=$this->GetOption('membership_cancelled_internal');
				$x[]=$this->GetOption('unsubscribe_internal');
			}
			return array_unique($x);
		}

		// -----------------------------------------
		// Registration: Handle 404
		function The404($content){
			// check if 404 is a category page request
			$cat=$GLOBALS['wp_query']->query_vars['cat'];
			if($cat){
				// if it's a category, check if the category has posts in it...
				$cat=get_category($cat);
				if($cat && $cat->count){
					// if the category has posts in it then chances are we are just hiding content
					// so we get the proper redirect URL...
					$redirect=is_user_logged_in()?$this->WrongLevelURL():$this->NonMembersURL();
					// and redirect
					header("Location:".$redirect);
					exit;
				}
			}

			return $content;
		}

		// -----------------------------------------
		// Registration Page Handling
		function RegistrationPage($content){
			$posts=$content;
			if(is_page()){
				$post=&$posts[0];
				if($post->ID==$this->MagicPage(false)){
					$reg=$_GET['reg'];
					$wpm_levels=$this->GetOption('wpm_levels');
					if(!$wpm_levels[$reg]){
						header("Location:".get_bloginfo('url'));
						exit;
					}
					$post->post_title=$wpm_levels[$reg]['name'].' Registration';
					$post->post_content=$this->RegContent();
				}
			}
			return $posts; 
		}

		// -----------------------------------------
		// The Heart of It All
		function Process($template){
			global $wp_query;

			// Construct Full Request URL
			list($wpm_request_url)=explode('/',strtolower($_SERVER['SERVER_PROTOCOL']),2);
			$wpm_request_url.='://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			if($_SERVER['QUERY_STRING'])$wpm_request_url.='?'.$_SERVER['QUERY_STRING'];

			// get all levels
			$wpm_levels=(array)$this->GetOption('wpm_levels');

			// check if the requested URL is a special URL
			$specialurl=false;
			$regurl=get_bloginfo('url').'/register/';
			foreach($wpm_levels AS $wpml) $specialurl=$specialurl|(bool)($regurl.$wpml['url']==$wpm_request_url);
			if($specialurl)return $template;

			// get current user
			$current_user=wp_get_current_user();
			// give everything is user is admin
			if($current_user->caps['administrator'])return $template;

			// process pages and posts
			if(is_page() OR is_single()){
				/* page/post becomes protected if a more tag is located and wpm_protect_after_more==1 */
				if($this->GetOption('protect_after_more') && strpos($wp_query->post->post_content,'<!--more-->')!==false){
					$protectmore=true;
				}else{
					$protectmore=false;
				}

				// is page or post protected?
				$protect=$this->Protect($wp_query->post->ID);

				/*
				// post is protected if category is protected
				$cats=wp_get_post_categories($wp_query->post->ID);
				$protectcat=false;
				foreach($cats AS $cat) $protectcat=$protectcat|$this->CatProtected($cat);
				*/
				
				// page / post not protected so give them all
				if(!$protect) return $template;

				// page / post is excluded (special page) so give all
				if(in_array($wp_query->post->ID,$this->ExcludePages(array()))) return $template;
			}

			// process categories
			if(is_category()){
				// go ahead for non-protected categories
				if(!$this->CatProtected($wp_query->query_vars['cat'])) return $template;
			}

			// retrieve page to display for non-members
			$nonmemberredirect=$this->NonMembersURL();

			if(!$current_user->ID){
				$redirect=$nonmemberredirect;
				// redirect non-members
				if($redirect!=$wpm_request_url){
					header('Location:'.$redirect);
					exit;
				}
			}else{
				// user is a member

				// check if any of the current user's membership levels have expired
				$thelevels2=$thelevels=(array)$this->GetMembershipLevels($current_user->ID);
				$time=time();
				foreach($thelevels AS $key=>$thelevelid){
					$thelevel=$wpm_levels[$thelevelid];
					if(!$thelevel['noexpire']){
						$start=strtotime($current_user->user_registered);
						$expire=strtotime('+'.$thelevel['expire'].' '.$thelevel['calendar'],$start);
						if($expire<$time){
							// remove level if expired
							unset($thelevels[$key]);
						}
					}
				}
				// no more levels left for this member? if so, redirect
				if(!count($thelevels)){
					$redirect=$nonmemberredirect;
					if($redirect!=$wpm_request_url){
						header('Location:'.$redirect);
						exit;
					}
				}
				
				// check if any of the levels are cancelled
				foreach($thelevels2 AS $key=>$thelevelid){
					if($this->LevelCancelled($thelevelid,$current_user->ID)){
						unset($thelevels2[$key]);
					}
				}
				// no more levels left for this member? if so, redirect to cancelled page
				if(!count($thelevels2)){
					$redirect=$this->CancelledURL();
					if($redirect!=$wpm_request_url){
						header('Location:'.$redirect);
						exit;
					}
				}

				// check for pending status
				if($this->IsPending($current_user->ID)){
					$start=strtotime($current_user->user_registered);
					$expire=$start+$this->GetOption('pending_period')*86400;
					if($expire<time()){
						$redirect=$nonmemberredirect;
						if($redirect!=$wpm_request_url){
							header('Location:'.$redirect);
							exit;
						}
					}
				}

				// check viewing status for each level (if all is selected for any)
				$canviewpage=$canviewcategory=$canviewpost=$canviewcomment=false;
				foreach($thelevels AS $thelevelid){
					if(!$this->LevelCancelled($thelevelid,$current_user->ID)){
						$thelevel=$wpm_levels[$thelevelid];
						$canviewpage=$canviewpage|isset($thelevel['allpages']);
						$canviewcategory=$canviewcategory|isset($thelevel['allcategories']);
						$canviewpost=$canviewpost|isset($thelevel['allposts']);
						$canviewcomment=$canviewcomment|isset($thelevel['allcomments']);
					}
				}

				// check individual viewing status for each content type (post, page, category, comment)
				$wronglevel=$cancelled=false;
				if(!$canviewpage && is_page()){
					$access=$this->GetContentLevels('pages',$wp_query->post->ID);
					foreach($thelevels AS $thelevelid){
						if(!$this->LevelCancelled($thelevelid,$current_user->ID)){
							$canviewpage=$canviewpage|in_array($thelevelid,$access);
						}else{
							$cancelled=true;
						}
					}
					$wronglevel=!$canviewpage;
				}elseif(!$canviewcategory && is_category()){
					$access=$this->GetContentLevels('categories',$wp_query->query_vars['cat']);
					foreach($thelevels AS $thelevelid){
						if(!$this->LevelCancelled($thelevelid,$current_user->ID)){
							$canviewcategory=$canviewcategory|in_array($thelevelid,$access);
						}else{
							$cancelled=true;
						}
					}
					$wronglevel=!$canviewcategory;
				}elseif(!$canviewpost && is_single()){
					$access=$this->GetContentLevels('posts',$wp_query->post->ID);
					foreach($thelevels AS $thelevelid){
						if(!$this->LevelCancelled($thelevelid,$current_user->ID)){
							$canviewpost=$canviewpost|in_array($thelevelid,$access);
						}else{
							$cancelled=true;
						}
					}
					$wronglevel=!$canviewpost;
				}
				if(!$canviewcomment && is_single()){
					$access=$this->GetContentLevels('comments',$wp_query->post->ID);
					foreach($thelevels AS $thelevelid){
						if(!$this->LevelCancelled($thelevelid,$current_user->ID)){
							$canviewcomment=$canviewcomment|in_array($thelevelid,$access);
						}else{
							$cancelled=true;
						}
					}
					if(!$canviewcomment || $cancelled){
						add_filter('comments_template',array(&$this,'NoComments'));
					}
				}
				if($wronglevel){
					$redirect=$cancelled?$this->CancelledURL():$this->WrongLevelURL();
					if($redirect!=$wpm_request_url){
						header('Location:'.$redirect);
						exit;
					}
				}
			}
			return $template;
		}

		// -----------------------------------------
		// Process Private Tags
		function TheContent($content){
			$current_user=$wpm_current_user=$GLOBALS['current_user'];
			$wpm_levels=(array)$this->GetOption('wpm_levels');

			// generate tags
			$tags=$regtags=array();
			foreach($wpm_levels AS $id=>$level){
				$tags[$id]=preg_quote('private_'.strtolower($level['name']),'/');
				$regtags[$id]=preg_quote('register_'.strtolower($level['name']),'/');
			}
			$alltags=$tags;

			// pick our tags
			$thelevels=$this->GetMembershipLevels($current_user->ID);
			$mytags=array();
			foreach($thelevels AS $thelevelid){
				$mytags[]=$tags[$thelevelid];
				unset($tags[$thelevelid]);
			}

			// strip private tags for unprotected posts and if user is admin
			// if(!$this->Protect($GLOBALS['post']->ID) || $current_user->caps['administrator']){
			// just strip private tags for admins and not for unprotected posts so that private tags still work on unprotected posts
			if($current_user->caps['administrator']){
				$content=preg_replace('/\[\/{0,1}private_.+?\]/i','',$content);
			}
			/* remove all private tags inside user's private blocks */
			foreach($mytags AS $mytag){
				$myblocks=preg_match_all('/\['.$tag.'\](.*?)\[\/'.$mytag.'\]/is',$content,$matches);
				foreach($matches[1] AS $match){
					$content=str_replace($match,preg_replace('/\[\/{0,1}private_.+?\]/i','',$match),$content);
				}
			}

			/* fix tag nesting */
			$xtags=$alltags;
			$prevtags=array();
			foreach($tags AS $id=>$tag){
				unset($xtags[$id]);
				preg_match_all('/\['.$tag.'\].*?\[\/'.$tag.'\]/is',$content,$matches);
				foreach($matches[0] AS $match){
					$xmatch=preg_replace('/\[\/{0,1}'.$tag.'\]/i','',$match);
					foreach($xtags AS $xtag){
						$xmatch=preg_replace('/\['.$xtag.'\]/i','[/'.$tag.']\0',$xmatch);
						$xmatch=preg_replace('/\[\/'.$xtag.'\]/i','\0['.$tag.']',$xmatch);
					}
					foreach($prevtags AS $prevtag){
						$xmatch=preg_replace('/\[\/{0,1}'.$prevtag.'\]/i','',$xmatch);
					}
					$content=str_replace($match,'['.$tag.']'.$xmatch.'[/'.$tag.']',$content);
					$prevtags[]=$tag;
				}
			}

			/* remove tags with whitespace only and empty tags */
			foreach($alltags AS $tag){
				$content=preg_replace('/\['.$tag.'\]\[\/'.$tag.'\]/is','',$content);
				$content=preg_replace('/\['.$tag.'\](<\/p>\s<p>)\[\/'.$tag.'\]/is','\1',$content);
			}

			/* remove blocks enclosed in private tags that don't belong to the user */
			$protectmsg=$this->GetOption('private_tag_protect_msg');
			foreach($tags AS $id=>$tag){
				$pmsg=str_replace('[level]',ucwords(strtolower($wpm_levels[$id]['name'])),$protectmsg);
				$content=preg_replace('/\['.$tag.'\].+?\[\/'.$tag.'\]/is',$pmsg,$content);
			}

			/* cleanup remaining private tags if any */
			$content=preg_replace('/\[\/{0,1}private_.+?\]/i','',$content);

			/* process merge codes */

			$replace=array();
			$replace['[firstname]']=$current_user->first_name;
			$replace['[lastname]']=$current_user->last_name;
			$replace['[email]']=$current_user->user_email;
			$replace['[memberlevel]']=$this->GetMembershipLevels($current_user->ID,true);
			$replace['[username]']=$current_user->user_login;

			$content=str_replace(array_keys($replace),$replace,$content);
			
			// in-page registration form
			foreach($regtags AS $level=>$regtag){
				$url=$this->GetRegistrationURL($level);
				$form=<<<STRING
<form method="post" action="{$url}" autocomplete="off"> 
	<input type="hidden" name="action" value="wpm_register" /> 
	<input type="hidden" name="wpm_id" value="{$level}" /> 
	<table class="wpm_registration" style="text-align:left"> 
		<tr valign="top"> 
			<td><b>Username (required):</b>&nbsp;</td> 
			<td><input type="text" name="username" value="" size="10" /></td> 
		</tr> 
		<tr valign="top"> 
			<td><b>First Name:</b>&nbsp;</td> 
			<td><input type="text" name="firstname" value="" size="15" /></td> 
		</tr> 
		<tr valign="top"> 
			<td><b>Last Name:</b>&nbsp;</td> 
			<td><input type="text" name="lastname" value="" size="15" /></td> 
		</tr> 
		<tr valign="top"> 
			<td><b>E-mail (required):</b>&nbsp;</td> 
			<td><input type="text" name="email" value="" size="25" /></td> 
		</tr> 
		<tr valign="top"> 
			<td><b>Password (twice):</b>&nbsp;</td> 
			<td><input type="password" name="password1" value="" size="10" /></td> 
		</tr> 
		<tr valign="top"> 
			<td></td> 
			<td><input type="password" name="password2" value="" size="10" /><br /><small>Password has to be at least 8 characters long<br />and must not contain spaces</small></td> 
		</tr> 
		<tr valign="top"> 
			<td></td> 
			<td><input type="submit" value="Submit Registration" /></td> 
		</tr> 
	</table>
</form>
STRING;
				$content=preg_replace('/\['.$regtag.'\]/i',$form,$content);
			}

			return $content;
		}

		// -----------------------------------------
		// Auto insert more tag
		function TheMore($posts){
			if(is_page()||is_single())return $posts;
			
			$isfeed=is_feed();
			$authenticatedfeed=false;
			if($isfeed && isset($_GET['wpmfeedkey'])){
				list($xid)=explode(';',$_GET['wpmfeedkey']);
				$authenticatedfeed=($this->FeedKey($xid)==$_GET['wpmfeedkey']);
			}
			
			if($this->GetOption('auto_insert_more')){
				$insertat=50;
				for($i=0;$i<count($posts);$i++){
					if(stristr('<!--more-->',$posts[$i]->post_content)===false){
						$content=preg_split('(\s)',trim($posts[$i]->post_content));
						$tag=false;
						$wordcnt=0;
						for($ii=0;$ii<count($content);$ii++){
							$start=substr($content[$ii],0,1);
							$end=substr($content[$ii],-1);
							if($start=='<'||$start=='[')$tag=true;
							if($end=='>'||$end==']')$tag=false;
							if(!$tag)$wordcnt++;
							if($wordcnt>=$insertat){
								$content[$ii].=' <!--more--> ';
								break;
							}
						}
						// make sure that tags are balanced
						$content=explode('<!--more-->',implode(' ',$content));
						$content[0]=force_balance_tags($content[0]);
						// we return full content on posts and authenticated feeds and only an excerpt on public feeds
						$content=($isfeed && !$authenticatedfeed)?$content[0]:implode('<!--more-->',$content);
						
						$posts[$i]->post_content=$content;
					}
				}
			}
			return $posts;
		}

		// -----------------------------------------
		// Feed Links
		function FeedLink($link){
            $key=$this->FeedKey();
			if($key){
				$param='wpmfeedkey='.$key;
				if(!strpos($link,'?')){
					$param='?'.$param;
				}else{
					$param='&'.$param;
				}
				$link.=$param;
			}
			return $link;
		}

		// -----------------------------------------
		// We want all mails sent by Wordpress to have our configured sender's name and address
		// Overridden by the AR
		function MailFrom($c){
			if(is_array($this->ARSender)){
				$x=$this->ARSender['email'];
			}else{
				$x=$this->GetOption('email_sender_address');
			}
			if(!$x)$x=$c;
			return $x;
		}
		function MailFromName($c){
			if(is_array($this->ARSender)){
				$x=$this->ARSender['name'];
			}else{
				$x=$this->GetOption('email_sender_name');
			}
			if(!$x)$x=$c;
			return $x;
		}

		// -----------------------------------------
		// Widget
		function Widget($args){
			extract($args);
			$wpm_levels=$this->GetOption('wpm_levels');
			$current_user=$wpm_current_user=wp_get_current_user();
			if(!$_GET['reg']){

			echo $before_widget.$before_title;
				if($current_user->ID){
					echo $this->GetOption('widget_title');
				}else{
					echo $this->GetOption('widget_title2');
				}
				echo $after_title;
				echo "<div id='wlmember_loginwidget'>";
				if($current_user->ID){
					$name=$current_user->first_name;
					if(!$name)$name=$current_user->user_nicename;
					if(!$name)$name=$current_user->user_login;
					echo "<p>Welcome, {$name}</p>";
					$levels=$this->GetMembershipLevels($GLOBALS['current_user']->ID);
					echo '&raquo; Level';
					if(count($levels)>1) echo 's';
					echo ': ';
					echo $this->GetMembershipLevels($GLOBALS['current_user']->ID,true);
					echo '<br />';

					if($this->GetOption('members_can_update_info')){
						echo '&raquo; <a href="'.get_bloginfo('wpurl').'/wp-admin/profile.php">Membership Details</a><br />';
					}
					echo '&raquo; <a href="'.get_bloginfo('rss2_url').'">RSS Feed</a><br />';
					if(function_exists('wp_logout_url')){
						$logout=wp_logout_url(get_bloginfo('url'));
					}else{
						$logout=wp_nonce_url(site_url('wp-login.php?action=logout&redirect_to='.urlencode(get_bloginfo('url')),'login'),'log-out');
					}
					echo '&raquo; <a href="'.$logout.'">Logout</a><br />';
				}else{
					$register=$this->GetOption('non_members_error_page_internal');
					$register=$register?get_permalink($register):$this->GetOption('non_members_error_page');

					echo '<form method="post" action="'.get_bloginfo('wpurl').'/wp-login.php"><p>You are not currently logged in.</p>';
					echo '<label>Username:<br /><input type="text" name="log" size="15" /></label><br />';
					echo '<label>Password:<br /><input type="password" name="pwd" size="15" /></label><br />';
					echo '<label><input type="checkbox" name="rememberme" value="forever" /> Remember Me</label><br />';
					echo '<input type="submit" name="wp-submit" value="Login" /><br /><br />';
					echo '&raquo; <a href="'.$register.'">Register</a><br />';
					echo '&raquo; <a href="'.get_bloginfo('wpurl').'/wp-login.php?action=lostpassword">Lost your Password?</a>';
					echo '<input type="hidden" name="redirect_to" value="wishlistmember" /></form>';
				}
				echo "</div>";
				echo $after_widget;
			}
		}

		// -----------------------------------------
		// Widget Admin
		function WidgetAdmin(){
			$title=$this->GetOption('widget_title');
			$title2=$this->GetOption('widget_title2');
			echo '<p><label for="wpm-widget-title">Title when logged in: <input type="text" value="'.$title.'" name="wpm_widget_title" id="wpm-widget-title" class="widefat"/></label></p>';
			echo '<p><label for="wpm-widget-title2">Title when logged out: <input type="text" value="'.$title2.'" name="wpm_widget_title2" id="wpm-widget-title2" class="widefat"/></label></p>';
			if(isset($_POST['wpm_widget_title'])){
				if(!trim($_POST['wpm_widget_title']))$_POST['wpm_widget_title']='Membership Detail';
				if(!trim($_POST['wpm_widget_title2']))$_POST['wpm_widget_title2']='Login Status';
				$this->SaveOption('widget_title',$_POST['wpm_widget_title']);
				$this->SaveOption('widget_title2',$_POST['wpm_widget_title2']);
			}
		}

		// -----------------------------------------
		// Hide's Content as per Configuration
		function OnlyShowContentForLevel($content){
			global $wpdb;

			// if we're trying to view post or page content then just return the content to be processed by our the_content page.  this avoids 404 pages to be displayed on hidden pages.
			if((is_single() && $content->query['name'] || $content->query['p']) || (is_page() && $content->query['page_id'])) return $content;

			if($this->GetOption('only_show_content_for_level')||(is_feed() && isset($_GET['wpmfeedkey']))){
				$id=$GLOBALS['current_user']->ID;
				if(is_feed() && isset($_GET['wpmfeedkey'])){
					$wpmfeedkey=$_GET['wpmfeedkey'];
					list($xid)=explode(';',$wpmfeedkey);
					if($this->FeedKey($xid)==$wpmfeedkey)$id=$xid;
				}
				if($id){
					if(!$GLOBALS['current_user']->caps['administrator']||is_feed()){
						$wpm_levels=$this->GetOption('wpm_levels');
						$levels=$this->GetMembershipLevels($id);

						// include even excluded pages
						$ids=$this->ExcludePages(array());

						// get all unprotected pages
						$protected=array_unique(array_merge(array("0"),explode(',',trim($this->GetOption('Protect')))));
						$k=array_search('',$protected);if($k!==false)unset($protected[$k]);
						$protected=implode(',',$protected);
						$unp=$wpdb->get_col("SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_type` IN ('post','page') AND `ID` NOT IN ({$protected})");
						$ids=array_merge($ids,$unp);

						// do we have all posts/pages enabled for any of the member's levels?
						$allpages=$allposts=false;
						foreach($levels AS $level){
							$allposts=$allposts|isset($wpm_levels[$level]['allposts']);
							$allpages=$allpages|isset($wpm_levels[$level]['allpages']);
						}

						// retrieve page ids
						if($allpages){
							$ids=array_merge($ids,$wpdb->get_col("SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_type`='page' AND `post_status` IN ('publish','private')"));
						}else{
							foreach($levels AS $level) $ids=array_merge($ids,$x=$this->GetMembershipContent('pages',$level));
						}

						// retrieve post ids
						if($allposts){
							$ids=array_merge($ids,$wpdb->get_col("SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_type`='post' AND `post_status` IN ('publish','private')"));
						}else{
							foreach($levels AS $level) $ids=array_merge($ids,$x=$this->GetMembershipContent('posts',$level));
						}

						// make sure our array of IDs is unique
						$ids=array_unique($ids);

						// remove '' entries
						$k=array_search('',$ids);
						if($k!==false)unset($ids[$k]);

						$content->query_vars['post__in']=$ids;
					}
				}else{
					$ids=explode(',',$this->GetOption('Protect'));
					$k=array_search('',$ids);
					if($k!==false)unset($ids[$k]);
					$exclude=$this->ExcludePages(array());
					foreach($exclude AS $ex){
						if($ex){
							$k=array_search($ex,$ids);
							if($k!==false)unset($ids[$k]);
						}
					}
					$content->query_vars['post__not_in']=$ids;
				}
			}
		}

		function OnlyListPagesForLevel($pages){
			if($this->GetOption('only_show_content_for_level') && !$GLOBALS['current_user']->caps['administrator']){
				if($GLOBALS['current_user']->ID){
					$wpm_levels=$this->GetOption('wpm_levels');
					$levels=$this->GetMembershipLevels($GLOBALS['current_user']->ID);
					// is the user a member of a level that can view all pages?
					$allpages=false;
					foreach($levels AS $level){
						$allpages=$allpages|isset($wpm_levels[$level]['allpages']);
					}
					if($allpages)return $pages;

					// retrieve pages that the user can't view
					$protect=explode(',',$this->GetOption('Protect'));
					$xpages=$this->GetMembershipContent('pages');
					$allowed=array();
					foreach($levels AS $level){
						$allowed=array_merge($allowed,$xpages[$level]);
					}
					$pages=array_merge($pages,array_diff($protect,$allowed));
				}else{
					$pages=array_merge($pages,explode(',',$this->GetOption('Protect')));
				}
				$pages=array_unique($pages);
				$k=array_search('',$pages);
				if($k!==false)unset($pages[$k]);
			}
			return $pages;
		}
		
		function OnlyListCatsForLevel($cats){
			if($this->GetOption('only_show_content_for_level') && !$GLOBALS['current_user']->caps['administrator']){
				if(is_category() && !defined('ONLYLISTCATS')){
					define('ONLYLISTCATS',1);
					return $cats;
				}
				$current_user=wp_get_current_user();
				
				$allowed=$this->GetMembershipContent('categories',$this->GetMembershipLevels($GLOBALS['current_user']->ID));
				$notallowed=$this->AllCategories;
				
				foreach($notallowed AS $i=>$cat){
					if(in_array($cat,$allowed) || !$this->CatProtected($cat)){
						unset($notallowed[$i]);
					}
				}
				
				if(count($notallowed)){
					$notallowed=implode(',',$notallowed);
					$cats.=" AND t.term_id NOT IN ({$notallowed}) ";
				}
			}
			return $cats;
		}
		
		// -----------------------------------------
		// Category Protection Form
		function CategoryForm($id){
			$id=$id->cat_ID;
			$checked=(int)$this->CatProtected($id);
			echo <<<STRING
			<script type="text/javascript">
				wpm_category_form({$checked});
			</script>
STRING;
		}
		// -----------------------------------------
		// Save Category
		function SaveCategory($id){
			$Protect=array_unique(explode(',',$this->GetOption('CatProtect')));
			if($_POST['wlmember_protect_category']=='yes'){
				$key=array_search($id,$Protect);
				if($key!==false)unset($Protect[$key]);
			}elseif($_POST['wlmember_protect_category']=='no'){
				$Protect[]=$id;
				$Protect=array_unique($Protect);
			}
			$this->SaveOption('CatProtect',implode(',',$Protect));
		}

		// -----------------------------------------
		// Edit Profile Page
		function ProfilePage(){
			global $profileuser, $current_user;

            $mailcheck=$profileuser->wlm_unsubscribe==1?'':'checked="true"';
			$mailinglist=<<<STRING
            <tr valign="top">
                <th scope="row">Mailing List Subscription</th>
                <td><label><input type="checkbox" name="wlm_unsubscribe" value="1" {$mailcheck} /> Subscribe</label></td>
            </tr>
STRING;

			if($current_user->caps['administrator']){

				$wpm_levels=$this->GetOption('wpm_levels');
				$options=array();
				$mlevels=$this->GetMembershipLevels($profileuser->ID);;
				foreach($wpm_levels AS $id=>$level){
					$checked=in_array($id,$mlevels)?'checked="true"':'';
					$options[]='<label><input type="checkbox" name="wpm_levels[]" value="'.$id.'" '.$checked.' /> '.$level['name'].'<br />';
				}
				$options=implode('',$options);

				$registered=date("F d, Y h:ia",strtotime($profileuser->user_registered)+get_option('gmt_offset')*3600);
				$regip=$profileuser->wpm_registration_ip;
				$lastlogin=date("F d, Y h:ia",$profileuser->wpm_login_date+get_option('gmt_offset')*3600);
				$loginip=$profileuser->wpm_login_ip;
				
				$blacklisturl=$this->GetMenu('members');
				$blacklisturl=$blacklisturl->URL.'&mode=blacklist';
				$eblacklisturl=$blacklisturl.'&eappend='.$profileuser->user_email;
				$blacklisturl=$blacklisturl.'&append=';

				if(!$profile_user->caps['administrator']){
					$loginlimit=<<<STRING
					<tr valign="top">
						<th scope="row">Login Limit</th>
						<td>
							<input type="text" name="wpm_login_limit" value="{$profileuser->wpm_login_limit}" size="3" style="width:50px" /> IPs per day<br />
							Special Values:<br />
								&raquo; <b>0</b> or Blank: Use default settings<br />
								&raquo; <b>-1</b>: No limit for this user
						</td>
					</tr>
STRING;
				}
				
				$delete='';
				if($current_user->ID!=$profileuser->ID && $profileuser->ID>1){
					$delete=<<<STRING
					<tr valign="top">
						<th scope="row"></th>
						<td>
							<input class="button-secondary" type="submit" value="Update Member Profile" />
							<input class="button-secondary" type="submit" name="wpm_delete_member" value="Delete This Member" onclick="if(confirm('Warning!\\n\\nAre you sure you want to delete this user?') && confirm('Last Warning!\\n\\nAre you really sure that you want to delete this user?\\nNote that this action cannot be undone.')){this.form.pass1.value='';return true;}" />
						</td>
					</tr>
STRING;
				}
				

				// retrieve address
				$wpm_useraddress=$profileuser->wpm_useraddress;
				$countries='<select name="wpm_useraddress[country]">';
				foreach($this->countries AS $country){
					$selected=$country==$profileuser->wpm_useraddress['country']?' selected="true" ':'';
					$countries.='<option'.$selected.'>'.$country.'</option>';
				}
				$wpmstuff=<<<STRING
				<h3>WishList Member</h3>
				<table class="form-table">
					<tr valign="top">
						<th scope="row">Membership Level</th>
						<td>{$options}</td>
					</tr>
                    {$mailinglist}
					<tr valign="top">
						<th scope="row">Registered</th>
						<td>E-mail: {$profileuser->user_email} &nbsp; <a href="admin.php{$eblacklisturl}">add to blacklist &raquo;</a><br />Date: {$registered}<br />IP: {$regip} &nbsp; <a href="admin.php{$blacklisturl}{$regip}">add to blacklist &raquo;</a></td>
					</tr>
					<tr valign="top">
						<th scope="row">Last Login</th>
						<td>Date: {$lastlogin}<br />IP: {$loginip} &nbsp; <a href="admin.php{$blacklisturl}{$loginip}">add to blacklist &raquo;</a></td>
					</tr>
					{$loginlimit}
					{$delete}
				</table>
				<h3>Address</h3>
				<table class="form-table">
					<tr valign="top">
						<th scope="row">Company</th>
						<td><input type="text" name="wpm_useraddress[company]" value="{$wpm_useraddress[company]}" /></td>
					</tr>
					<tr valign="top">
						<th scope="row">Address</th>
						<td><input type="text" name="wpm_useraddress[address1]" value="{$wpm_useraddress[address1]}" /><br /><input type="text" name="wpm_useraddress[address2]" value="{$wpm_useraddress[address2]}" /></td>
					</tr>
					<tr valign="top">
						<th scope="row">City</th>
						<td><input type="text" name="wpm_useraddress[city]" value="{$wpm_useraddress[city]}" /></td>
					</tr>
					<tr valign="top">
						<th scope="row">State</th>
						<td><input type="text" name="wpm_useraddress[state]" value="{$wpm_useraddress[state]}" /></td>
					</tr>
					<tr valign="top">
						<th scope="row">Zip</th>
						<td><input type="text" name="wpm_useraddress[zip]" value="{$wpm_useraddress[zip]}" style="width:100px" /></td>
					</tr>
					<tr valign="top">
						<th scope="row">Country</th>
						<td>{$countries}</td>
					</tr>
					</table>
STRING;
			}else{
               $wpmstuff="<h3>WishList Member</h3><table class='form-table'>{$mailinglist}</table>";
            }
            echo <<<STRING
				<div id="WishListMemberUserProfile">
                    {$wpmstuff}
				</div>

				<script type="text/javascript">
					function MoveWLMember(){
						try{
							var x=document.getElementById('WishListMemberUserProfile');
							var p=x.parentNode;
							var s=p.getElementsByTagName('h3');
							p.insertBefore(x,s[0]);
						}catch(e){}
					}
					MoveWLMember();
				</script>
STRING;
		}

		// -----------------------------------------
		// So that we can choose to return either a 404 or a 200 when viewing registration pages...
		function RewriteRules($x){
			$x['register/(.+?)']='index.php';
			return $x;
		}

		// -----------------------------------------
		// Don't show comments...
		function NoComments(){
			return ($this->pluginDir.'/comments.php');
		}

		// -----------------------------------------
		// WP Head Hook
		function WPHead(){
			global $post;
			if($post->ID==$this->MagicPage(false)){
				echo '<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW" />';
				echo '<META NAME="GOOGLEBOT" CONTENT="NOARCHIVE"/ >';
				echo '<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE"/ >';
				echo '<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE"/ >';
				echo '<META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 02 Aug 1999 01:02:03 GMT">';
			}
		}
	}
}

// -----------------------------------------
// initiate our plugin class
if(class_exists('WishListMember')){
	$WishListMemberInstance=&new WishListMember(8901,'WishListMember','WishList Member','WL Member');
	// add menus
	$WishListMemberInstance->AddMenu('settings','Settings','settings.php');
	$WishListMemberInstance->AddMenu('members','Members','members.php');
	$WishListMemberInstance->AddMenu('membershiplevels','Membership Levels','membershiplevels.php');
	$WishListMemberInstance->AddMenu('sequential','Sequential Upgrade','sequential.php');
	$WishListMemberInstance->AddMenu('integration','Integration','integration.php');
}

// -----------------------------------------
// hook on to wordpress
if(isset($WishListMemberInstance)){
	register_activation_hook(__FILE__,array(&$WishListMemberInstance,'Activate'));
	register_deactivation_hook(__FILE__,array(&$WishListMemberInstance,'Deactivate'));
	add_action('admin_head',array(&$WishListMemberInstance,'AdminHead'),1);
		/* my hooks */
			// init
			add_action('init',array(&$WishListMemberInstance,'Init'));

			// user handling
			add_action('delete_user',array(&$WishListMemberInstance,'DeleteUser'));
			add_action('profile_update',array(&$WishListMemberInstance,'ProfileUpdate'));

			// Content Handling
			add_action('edit_form_advanced',array(&$WishListMemberInstance,'PostPageOptions'));
			add_action('edit_page_form',array(&$WishListMemberInstance,'PostPageOptions'));
			add_action('wp_insert_post',array(&$WishListMemberInstance,'SavePostPage'));

			// Cateogry Protection
			add_action('edit_category_form',array(&$WishListMemberInstance,'CategoryForm'));
			add_action('create_category',array(&$WishListMemberInstance,'SaveCategory'));
			add_action('edit_category',array(&$WishListMemberInstance,'SaveCategory'));

			// Miscellaneous
			add_action('wp_login',array(&$WishListMemberInstance,'Login'));
			add_action('wp_logout',array(&$WishListMemberInstance,'Logout'));
			add_action('retrieve_password',array(&$WishListMemberInstance,'RetrievePassword'));
			add_action('wp_footer',array(&$WishListMemberInstance,'Footer'));
			add_action('wp_head',array(&$WishListMemberInstance,'WPHead'));

			// excluded pages
			add_filter('wp_list_pages_excludes',array(&$WishListMemberInstance,'ExcludePages'));

			// 404
			add_filter('404_template',array(&$WishListMemberInstance,'The404'));
			// registration stuff
			add_filter('the_posts',array(&$WishListMemberInstance,'RegistrationPage'));

			// template hooks
			add_filter('page_template',array(&$WishListMemberInstance,'Process'));
			add_filter('single_template',array(&$WishListMemberInstance,'Process'));
			add_filter('category_template',array(&$WishListMemberInstance,'Process'));

			// auto insert more tag
			add_filter('the_posts',array(&$WishListMemberInstance,'TheMore'));

			// feed link
			add_filter('feed_link',array(&$WishListMemberInstance,'FeedLink'));

			// handling of private and register tags
			add_filter('the_content',array(&$WishListMemberInstance,'TheContent'));
			add_filter('the_rss_content',array(&$WishListMemberInstance,'TheContent'));

			// mail sender information
			add_filter('wp_mail_from',array(&$WishListMemberInstance,'MailFrom'));
			add_filter('wp_mail_from_name',array(&$WishListMemberInstance,'MailFromName'));

			// hooks for the "Only show content for each membership level" setting
			add_action('pre_get_posts',array(&$WishListMemberInstance,'OnlyShowContentForLevel'));
			add_action('wp_list_pages_excludes',array(&$WishListMemberInstance,'OnlyListPagesForLevel'));
			add_filter('list_terms_exclusions',array(&$WishListMemberInstance,'OnlyListCatsForLevel'));

			add_action('edit_user_profile',array(&$WishListMemberInstance,'ProfilePage'));
			add_action('show_user_profile',array(&$WishListMemberInstance,'ProfilePage'));
	}
?>