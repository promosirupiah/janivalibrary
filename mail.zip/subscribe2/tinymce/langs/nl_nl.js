// NL lang variables

tinyMCE.addToLang('subscribe2quicktags',{
subscribe2 : 'Subscribe2 teken invoegen'
});
