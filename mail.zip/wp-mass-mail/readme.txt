=== Plugin Name ===
Contributors: Julian Widya Perdana
Donate link: http://mr.hokya.com/donate
Tags: email, mail, notify, notification, mass, author, post, plugin, comments, spam, dashboard, plugin
Requires at least: 2.0.2
Tested up to: 2.8.2
Stable tag: 4.3

It allows you to send bulk mail messages to multiple commentators addresses at once via DashBoard Menu.


== Description ==

Help you send bulk email messages to multiple address on your comment database. This plugin uses webmail php mail() function so you can determine the name of your address (ex:anyname@yourdomain.com)

You can also set the reply-to header so when the mailed person wants to reply, they will reply to your Gmail, or Ymail, or the others.

You have all access to set cc,bcc,reply-to, and from headers


== Installation ==


1. Upload the zipped file to yoursite/wp-content/plugins
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Check out the pages on Dashboard Menu