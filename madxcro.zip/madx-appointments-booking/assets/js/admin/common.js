(function () {

	"use strict";

	Vue.component( 'madx-apb-go-to-setup', {
		template: '#madx-apb-go-to-setup',
		data: function() {
			return {
				setupURL: window.madxAPBConfig.setup.setup_url,

			};
		}
	} );

})();