const { __ } = wp.i18n;

const options = {
	appointment_service_field: [
		{
			value: 'current_post_id',
			label: __( 'Current Post ID', 'madx-appointments-booking' ),
		},
		{
			value: 'form_field',
			label: __( 'Form Field', 'madx-appointments-booking' ),
		},
		{
			value: 'manual_input',
			label: __( 'Manual Input', 'madx-appointments-booking' )
		}
	],
};

const label = {
	appointment_service_field: __( 'Get Service ID From:', 'madx-appointments-booking' ),
	appointment_form_field: __( 'Select Service Field:', 'madx-appointments-booking' ),
	appointment_service_id: __( 'Set Service ID:', 'madx-appointments-booking' ),
};

export {
	options,
	label
};