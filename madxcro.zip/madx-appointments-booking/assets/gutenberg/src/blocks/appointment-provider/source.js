import { label as globalLabel, options } from '../source';

const { __ } = wp.i18n;

const label = {
	appointment_provider_custom_template: __( 'Use Custom Template For Items:', 'madx-appointments-booking' ),
	appointment_provider_custom_template_id: __( 'Custom Template ID:', 'madx-appointments-booking' ),
	switch_on_change: __( 'Switch Page on Change:', 'madx-appointments-booking' ),
	...globalLabel
};


export {
	label,
	options
};

