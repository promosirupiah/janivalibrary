import { label as globalLabel, options } from '../source';

const { __ } = wp.i18n;

const label = {
	appointment_provider_field: __( 'Get Provider ID From:', 'madx-appointments-booking' ),
	appointment_provider_form_field: __( 'Select Provider Field:', 'madx-appointments-booking' ),
	appointment_provider_id: __( 'Set Provider ID:', 'madx-appointments-booking' ),
	...globalLabel
};


export {
	label,
	options,
};

