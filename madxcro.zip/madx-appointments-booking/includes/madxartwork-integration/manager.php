<?php
namespace madx_APB\madxartwork_Integration;

use madx_APB\Plugin;

class Manager {

	public function __construct() {
		add_action( 'madxartwork/init', array( $this, 'init_components' ) );
	}

	public function init_components() {
		add_filter( 'madx-engine/madxartwork-view/dynamic-link/generel-options', array( $this, 'register_dynamic_link_option' ) );
	}

	public function register_dynamic_link_option( $options ) {
		$options[ Plugin::instance()->google_cal->query_var ] = __( 'madx Appointments Booking: add booking to Google calendar', 'madx-appointments-booking' );
		return $options;
	}

}
