<?php


namespace madx_APB\Form_Fields;


use madx_APB\Vendor\Fields_Core\Smart_Field_Trait;

class Date_Field_Render {

	use Smart_Field_Trait;
	use Date_Field_Template_Trait;

}