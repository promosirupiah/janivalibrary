<?php
namespace madx_APB\Admin\Settings;

use madx_APB\Plugin;
use madx_APB\Admin\Settings\Appointment_Settings_Base as Appointment_Settings_Base;
use madx_APB\Integrations\Manager as Integrations_Manager;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Integrations extends Appointment_Settings_Base {

	/**
	 * Returns module slug
	 *
	 * @return void
	 */
	public function get_page_slug() {
		return 'madx-apb-integrations';
	}

	/**
	 * [get_page_name description]
	 * @return [type] [description]
	 */
	public function get_page_name() {
		return esc_html__( 'Integrations', 'madx-appointments-booking' );
	}

	public function page_assets() {

		Integrations_Manager::instance()->assets();
	
		wp_enqueue_script(
			'madx-apb-integrations',
			madx_APB_URL . 'assets/js/admin/integrations.js',
			[ 'wp-api-fetch' ],
			madx_APB_VERSION,
			true
		);

		wp_enqueue_style( 'madx-apb-integrations' );

		wp_localize_script( 'madx-apb-integrations', 'madxAPBIntegrationsData', [
			'integrations' => Integrations_Manager::instance()->get_integrations_for_js(),
			'api'          => Plugin::instance()->rest_api->get_url( 'update-appointment-integrations', false ),
		] );
	}

	/**
	 * [page_templates description]
	 * @param  array  $templates [description]
	 * @param  string $subpage   [description]
	 * @return [type]            [description]
	 */
	public function page_templates( $templates = array(), $page = false, $subpage = false ) {
		
		$templates['madx-apb-integrations'] = madx_APB_PATH . 'templates/admin/madx-apb-settings/settings-integrations.php';
		
		return array_merge( $templates, Integrations_Manager::instance()->get_templates() );
	}
}
