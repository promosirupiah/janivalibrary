<div class="madx-apb-appointments-wrap">
	<header class="madx-apb-header">
		<h1 class="madx-apb-title"><?php esc_html_e( 'Appointments', 'madx-appointments-booking' ); ?></h1>
		<madx-apb-add-new-appointment
			v-if="isSet"
			:class="{ 'madx-apb-loading': isLoading, 'madx-apb-add-new': true, 'transition': true }"
		></madx-apb-add-new-appointment>
		<madx-apb-appointments-config v-if="isSet"></madx-apb-appointments-config>
		<div
			v-if="isLoading"
			class="madx-apb-main-notice">
			<h2><?php esc_html_e( 'Appointments is loading...', 'madx-appointments-booking' ); ?></h2>
		</div>
		<div
			v-else-if="! itemsList.length"
			class="madx-apb-main-notice madx-apb-main-notice-naf">
			<h2><?php esc_html_e( 'No appointments found.', 'madx-appointments-booking' ); ?></h2>
		</div>
		<madx-apb-appointments-view
			v-if="isSet"
			:class="{ 'madx-apb-loading': isLoading }"
		></madx-apb-appointments-view>
	</header>
	<div
		v-if="isSet"
		:class="{ 'madx-apb-loading': isLoading }"
	>
		<madx-apb-appointments-filter></madx-apb-appointments-filter>
		<component
			:is="curentView">
		</component>
		<madx-apb-popup></madx-apb-popup>
	</div>
	<div class="cx-vui-panel" v-else>
		<madx-apb-go-to-setup></madx-apb-go-to-setup>
	</div>
</div>
