<div
        class="madx-apb-pagination-wrapper"
>
    <h4 class="madx-apb-prepage-count">
        {{perPageInfo}}
    </h4>
    <cx-vui-pagination
            v-if="perPage < totalItems"
            :total="totalItems"
            :page-size="perPage"
            :current="pageNumber"
            @on-change="changePage"
    ></cx-vui-pagination>

    <div class="madx-apb-prepage">
        <h4 class="madx-apb-prepage-text">
            <?php esc_html_e( 'Results per page', 'madx-appointments-booking' ); ?>
        </h4>
        <input
            class="madx-apb-prepage-input"
            type="number"
            min="1"
            max="1000"
            v-model.number.lazy="perPage"
        >
    </div>
</div>