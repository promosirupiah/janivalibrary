<?php
/**
 * Form appointment calendar
 */
?>
<div class="madx-apb-calendar-wrapper">
	<div class="appointment-calendar madx-apb-calendar" data-args="<?php echo htmlspecialchars( json_encode( $dataset ) ) ?>"></div>

	<?php if( 'recurring' === $dataset['booking_type'] ){  ?>
		<div class="madx-apb-recurrence-app-settings-wrapper" style="display: none" >
			<div class="<?php echo $this->scopeClass( '__heading' ) ?>">
				<span class="<?php echo $this->scopeClass( '__label-text' ) ?>"><?php esc_html_e( 'Repeat appointment:', 'madx-appointments-booking' ); ?></span>
			</div>
			<div class="madx-apb-recurrence-app-settings madx-form-row"></div>
		</div>
	<?php } ?>
	<div class="madx-apb-calendar-appointments-list-wrapper" style="display: none">
		<div class="<?php echo $this->scopeClass( '__heading' ) ?>">
			<span class="<?php echo $this->scopeClass( '__label-text' ) ?>"><?php esc_html_e( 'Appointment details:', 'madx-appointments-booking' ); ?></span>
		</div>
		<div class="madx-apb-calendar-appointments-list"></div>
	</div>
	<div class="madx-apb-calendar-notification" style="display: none">
		<div class="madx-apb-calendar-notification-service"><?php esc_html_e( 'Please, select the service first.', 'madx-appointments-booking' ); ?></div>
		<div class="madx-apb-calendar-notification-provider"><?php esc_html_e( 'Please, select the provider first.', 'madx-appointments-booking' ); ?></div>
		<div class="madx-apb-calendar-notification-service-field"><?php esc_html_e( 'Please set service field for current calendar', 'madx-appointments-booking' ); ?></div>
		<div class="madx-apb-calendar-notification-max-slots"><?php esc_html_e( 'Sorry. You have the max number of appointments.', 'madx-appointments-booking' ); ?></div>
	</div>
</div>
