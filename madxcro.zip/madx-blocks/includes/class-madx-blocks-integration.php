<?php
/**
 * Class description
 *
 * @package   package_name
 * @author    Cherry Team
 * @license   GPL-2.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'madx_Blocks_Integration' ) ) {

	/**
	 * Define madx_Blocks_Integration class
	 */
	class madx_Blocks_Integration {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * Check if processing madxartwork widget
		 *
		 * @var boolean
		 */
		private $is_madxartwork_ajax = false;

		/**
		 * Initalize integration hooks
		 *
		 * @return void
		 */
		public function init() {

			add_action( 'madxartwork/elements/categories_registered', array( $this, 'register_category' ) );

			if ( defined( 'madxartwork_VERSION' ) && version_compare( madxartwork_VERSION, '3.5.0', '>=' ) ) {
				add_action( 'madxartwork/widgets/register', array( $this, 'register_widgets' ), 10 );

				add_action( 'madxartwork/widgets/register', array( $this, 'register_vendor_widgets' ), 20 );
			} else {
				add_action( 'madxartwork/widgets/widgets_registered', array( $this, 'register_widgets' ), 10 );

				add_action( 'madxartwork/widgets/widgets_registered', array( $this, 'register_vendor_widgets' ), 20 );
			}

			add_action( 'madxartwork/controls/controls_registered', array( $this, 'add_controls' ), 10 );

			add_action( 'madxartwork/editor/after_enqueue_styles', array( $this, 'font_styles' ) );
			add_action( 'madxartwork/preview/enqueue_styles',      array( $this, 'font_styles' ) );

			// Init madx madxartwork Extension module
			$ext_module_data = madx_blocks()->module_loader->get_included_module_data( 'madx-madxartwork-extension.php' );

			madx_madxartwork_Extension\Module::get_instance(
				array(
					'path' => $ext_module_data['path'],
					'url'  => $ext_module_data['url'],
				)
			);

		}

		/**
		 * Enqueue icon font styles
		 *
		 * @return void
		 */
		public function font_styles() {

			wp_enqueue_style(
				'madx-blocks-font',
				madx_blocks()->plugin_url( 'assets/css/madx-blocks-icons.css' ),
				array(),
				madx_blocks()->get_version()
			);

		}

		/**
		 * Check if we currently in madxartwork mode
		 *
		 * @return void
		 */
		public function in_madxartwork() {

			$result = false;

			if ( wp_doing_ajax() ) {
				$result = ( isset( $_REQUEST['action'] ) && 'madxartwork_ajax' === $_REQUEST['action'] );
			} elseif ( madxartwork\Plugin::instance()->editor->is_edit_mode()
				&& 'wp_enqueue_scripts' === current_filter() ) {
				$result = true;
			} elseif ( madxartwork\Plugin::instance()->preview->is_preview_mode() && 'wp_enqueue_scripts' === current_filter() ) {
				$result = true;
			}

			/**
			 * Allow to filter result before return
			 *
			 * @var bool $result
			 */
			return apply_filters( 'madx-blocks/in-madxartwork', $result );
		}

		/**
		 * Add new controls.
		 *
		 * @param  object $controls_manager Controls manager instance.
		 * @return void
		 */
		public function add_controls( $controls_manager ) {

			$grouped = array(
				'madx-blocks-box-style' => 'madx_Blocks_Group_Control_Box_Style',
			);

			foreach ( $grouped as $control_id => $class_name ) {
				if ( $this->include_control( $class_name, true ) ) {
					$controls_manager->add_group_control( $control_id, new $class_name() );
				}
			}

		}

		/**
		 * Include control file by class name.
		 *
		 * @param  [type] $class_name [description]
		 * @return [type]             [description]
		 */
		public function include_control( $class_name, $grouped = false ) {

			$filename = sprintf(
				'includes/controls/%2$sclass-%1$s.php',
				str_replace( '_', '-', strtolower( $class_name ) ),
				( true === $grouped ? 'groups/' : '' )
			);

			if ( ! file_exists( madx_blocks()->plugin_path( $filename ) ) ) {
				return false;
			}

			require madx_blocks()->plugin_path( $filename );

			return true;
		}

		/**
		 * Register plugin widgets
		 *
		 * @param  object $widgets_manager madxartwork widgets manager instance.
		 * @return void
		 */
		public function register_widgets( $widgets_manager ) {

			$avaliable_widgets = madx_blocks_settings()->get( 'avaliable_widgets' );

			require madx_blocks()->plugin_path( 'includes/base/class-madx-blocks-base.php' );

			foreach ( glob( madx_blocks()->plugin_path( 'includes/widgets/' ) . '*.php' ) as $file ) {

				$slug    = basename( $file, '.php' );
				$enabled = isset( $avaliable_widgets[ $slug ] ) ? $avaliable_widgets[ $slug ] : '';

				if ( filter_var( $enabled, FILTER_VALIDATE_BOOLEAN ) || ! $avaliable_widgets ) {
					$this->register_widget( $file, $widgets_manager );
				}
			}
		}

		/**
		 * Register vendor widgets
		 *
		 * @param  object $widgets_manager madxartwork widgets manager instance.
		 * @return void
		 */
		public function register_vendor_widgets( $widgets_manager ) {

			$woo_conditional = array(
				'cb'  => 'class_exists',
				'arg' => 'WooCommerce',
			);

			$allowed_vendors = apply_filters(
				'madx-blocks/allowed-vendor-widgets',
				array(
					'woo_cart' => array(
						'file' => madx_blocks()->plugin_path(
							'includes/widgets/vendor/madx-blocks-woo-cart.php'
						),
						'conditional' => $woo_conditional,
					),
				)
			);

			foreach ( $allowed_vendors as $vendor ) {
				if ( is_callable( $vendor['conditional']['cb'] )
					&& true === call_user_func( $vendor['conditional']['cb'], $vendor['conditional']['arg'] ) ) {
					$this->register_widget( $vendor['file'], $widgets_manager );
				}
			}
		}

		/**
		 * Register addon by file name
		 *
		 * @param  string $file            File name.
		 * @param  object $widgets_manager Widgets manager instance.
		 * @return void
		 */
		public function register_widget( $file, $widgets_manager ) {

			$base  = basename( str_replace( '.php', '', $file ) );
			$class = ucwords( str_replace( '-', ' ', $base ) );
			$class = str_replace( ' ', '_', $class );
			$class = sprintf( 'madxartwork\%s', $class );

			require $file;

			if ( class_exists( $class ) ) {
				if ( method_exists( $widgets_manager, 'register' ) ) {
					$widgets_manager->register( new $class );
				} else {
					$widgets_manager->register_widget_type( new $class );
				}
			}
		}

		/**
		 * Register cherry category for madxartwork if not exists
		 *
		 * @return void
		 */
		public function register_category( $elements_manager ) {

			$cherry_cat = 'madx-blocks';

			$elements_manager->add_category(
				$cherry_cat,
				array(
					'title' => esc_html__( 'madxBlocks', 'madx-blocks' ),
					'icon'  => 'font',
				),
				1
			);
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance( $shortcodes = array() ) {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self( $shortcodes );
			}
			return self::$instance;
		}
	}

}

/**
 * Returns instance of madx_Blocks_Integration
 *
 * @return object
 */
function madx_blocks_integration() {
	return madx_Blocks_Integration::get_instance();
}
