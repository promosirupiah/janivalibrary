<div
	class="madx-dashboard-page__alerts"
	v-if="visible"
>
	<madx-dashboard-alert-item
		v-for="( alertConfig, index ) in alertList"
		:key="index"
		:config="alertConfig"
	></madx-dashboard-alert-item>
</div>
