<?php
/**
 * Main dashboard template
 */
?><div
	id="madx-dashboard-page"
	class="madx-dashboard-page"
	ref="madxDashboardPage"
>

	<div class="madx-dashboard-page__body">

		<madx-dashboard-alert-list
			:alert-list="alertNoticeList"
		></madx-dashboard-alert-list>

		<madx-dashboard-before-content
			:config="beforeContentConfig"
		></madx-dashboard-before-content>

		<div class="madx-dashboard-page__content">

			<madx-dashboard-header
				:config="headerConfig"
			></madx-dashboard-header>

			<div class="madx-dashboard-page__component">

				<madx-dashboard-before-component
					:config="beforeComponentConfig"
				></madx-dashboard-before-component>

				<component
					:is="pageModule"
					:subpage="subPageModule"
				></component>

				<madx-dashboard-after-component
					:config="afterComponentConfig"
				></madx-dashboard-after-component>

			</div>

		</div>

		<div
			class="madx-dashboard-page__sidebar-container"
			v-if="sidebarVisible"
		>

			<madx-dashboard-before-sidebar
				:config="beforeSidebarConfig"
			></madx-dashboard-before-sidebar>

			<madx-dashboard-sidebar
				:config="sidebarConfig"
				:guide="guideConfig"
				:help-center="helpCenterConfig"
			></madx-dashboard-sidebar>

			<madx-dashboard-after-sidebar
				:config="afterSidebarConfig"
			></madx-dashboard-after-sidebar>

		</div>

	</div>

	<transition name="popup">
		<cx-vui-popup
			class="service-actions-popup"
			v-model="serviceActionsVisible"
			:footer="false"
			body-width="400px"
		>
			<div slot="title">
				<div class="cx-vui-popup__header-label">Service Actions</div>
			</div>
			<div class="service-actions-popup__form" slot="content">
				<cx-vui-select
					size="fullwidth"
					placeholder="Choose Action"
					:prevent-wrap="true"
					:options-list="serviceActionOptions"
					v-model="serviceAction"
				></cx-vui-select>
				<cx-vui-button
					button-style="accent"
					size="mini"
					:loading="serviceActionProcessed"
					@click="executeServiceAction"
				>
					<span slot="label">Go</span>
				</cx-vui-button>
			</div>
		</cx-vui-popup>
	</transition>

</div>
