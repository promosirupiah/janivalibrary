<?php

use madxartwork\Core\Responsive\Files\Frontend as FrontendFile;
use madxartwork\Core\Responsive\Responsive;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'madx_Blocks_Assets' ) ) {

	/**
	 * Define madx_Blocks_Assets class
	 */
	class madx_Blocks_Assets {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * Constructor for the class
		 */
		public function init() {
			add_action( 'madxartwork/frontend/before_enqueue_styles',  array( $this, 'enqueue_styles' ) );
			add_action( 'madxartwork/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			add_action( 'madxartwork/editor/before_enqueue_scripts',   array( $this, 'editor_scripts' ) );
			add_action( 'madxartwork/editor/after_enqueue_styles',     array( $this, 'editor_styles' ) );

			add_filter( 'madxartwork/core/responsive/get_stylesheet_templates', array( $this, 'add_responsive_css_templates' ) );
		}

		/**
		 * Enqueue public-facing stylesheets.
		 *
		 * @since 1.0.0
		 * @access public
		 * @return void
		 */
		public function enqueue_styles() {

			$direction_suffix = is_rtl() ? '-rtl' : '';

			$file_name = 'madx-blocks' . $direction_suffix . '.css';

			$frontend_file = new FrontendFile( 'custom-' . $file_name, madx_blocks()->plugin_path( 'assets/css/templates/' . $file_name ) );

			$time = $frontend_file->get_meta( 'time' );

			if ( ! $time ) {
				$frontend_file->update();
			}

			$style_url = $frontend_file->get_url();

			wp_enqueue_style(
				'madx-blocks',
				$style_url,
				false,
				madx_blocks()->get_version()
			);

		}

		/**
		 * Enqueue plugin scripts only with madxartwork scripts
		 *
		 * @return void
		 */
		public function enqueue_scripts() {

			$min_suffix = madx_blocks_tools()->is_script_debug() ? '' : '.min';

			do_action( 'madx-blocks/frontend/before_enqueue_scripts' );

			wp_enqueue_script(
				'madx-blocks',
				madx_blocks()->plugin_url( 'assets/js/madx-blocks' . $min_suffix . '.js' ),
				array( 'jquery', 'madxartwork-frontend' ),
				madx_blocks()->get_version(),
				true
			);

			$localize_data = apply_filters( 'madx-blocks/frontend/localize-data', array() );

			if ( ! empty( $localize_data ) ) {
				wp_localize_script(
					'madx-blocks',
					'madxBlocksData',
					$localize_data
				);
			}

			$rest_api_url = apply_filters( 'madx-blocks/rest/url', get_rest_url() );

			wp_localize_script( 'madx-blocks', 'madxHamburgerPanelSettings', array(
				'ajaxurl'        => esc_url( admin_url( 'admin-ajax.php' ) ),
				'isMobile'       => filter_var( wp_is_mobile(), FILTER_VALIDATE_BOOLEAN ) ? 'true' : 'false',
				'templateApiUrl' => $rest_api_url . 'madx-blocks-api/v1/madxartwork-template',
				'devMode'        => is_user_logged_in() ? 'true' : 'false',
				'restNonce'      => wp_create_nonce( 'wp_rest' ),
			) );
		}

		/**
		 * Enqueue elemnetor editor-related styles
		 *
		 * @return void
		 */
		public function editor_styles() {

			wp_enqueue_style(
				'madx-blocks-editor',
				madx_blocks()->plugin_url( 'assets/css/madx-blocks-editor.css' ),
				array(),
				madx_blocks()->get_version()
			);

		}

		/**
		 * Enqueue plugin scripts only with madxartwork scripts
		 *
		 * @return void
		 */
		public function editor_scripts() {

			$min_suffix = madx_blocks_tools()->is_script_debug() ? '' : '.min';

			wp_enqueue_script(
				'madx-blocks-editor',
				madx_blocks()->plugin_url( 'assets/js/madx-blocks-editor' . $min_suffix . '.js' ),
				array( 'jquery' ),
				madx_blocks()->get_version(),
				true
			);

		}

		/**
		 * Add responsive css templates.
		 *
		 * @param array $templates CSS templates.
		 *
		 * @return array
		 */
		function add_responsive_css_templates( $templates = array() ) {
			$templates_paths = glob( madx_blocks()->plugin_path( 'assets/css/templates' ) . '*.css' );

			foreach ( $templates_paths as $template_path ) {
				$file_name = 'custom-' . basename( $template_path );

				$templates[ $file_name ] = $template_path;
			}

			return $templates;
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
	}

}

/**
 * Returns instance of madx_Blocks_Assets
 *
 * @return object
 */
function madx_blocks_assets() {
	return madx_Blocks_Assets::get_instance();
}
