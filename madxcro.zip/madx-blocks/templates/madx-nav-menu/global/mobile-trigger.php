<?php
/**
 * Mobile menu trigger template
 */
?>

<div class="madx-nav__mobile-trigger madx-nav-mobile-trigger-align-<?php echo esc_attr( $trigger_align ); ?>">
	<?php $this->__icon( 'mobile_trigger_icon', '<span class="madx-nav__mobile-trigger-open madx-blocks-icon">%s</span>' ); ?>
	<?php $this->__icon( 'mobile_trigger_close_icon', '<span class="madx-nav__mobile-trigger-close madx-blocks-icon">%s</span>' ); ?>
</div>