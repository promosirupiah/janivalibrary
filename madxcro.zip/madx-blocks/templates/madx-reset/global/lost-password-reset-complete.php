<?php
	$settings   = $this->get_settings_for_display();
	$form_title = wp_kses_post( $settings['form_title'] );

	if ( 'yes' === $settings['login_link'] ) {
		$login_url  = $this->get_login_url( $settings );
		$login_text = isset( $settings['form_login_button_text'] ) ? wp_kses_post( $settings['form_login_button_text'] ) : '';
		$login_link = '<a class="madx-reset__login-link" href="' . $login_url . '">' . $login_text . '</a>';
	} else {
		$login_link = '';
	}
?>

<div class="madx-reset">

	<div class="madx-reset__success-message">
		<?php if ( ! empty( $form_title ) ):?>

			<legend class="madx-reset__form-title"><?php echo $form_title; ?></legend>

		<?php endif;?>

		<p>
			<?php printf( __( 'Your password has been reset. %s', 'madx-blocks' ), $login_link ); ?>
		</p>
	</div>

</div>