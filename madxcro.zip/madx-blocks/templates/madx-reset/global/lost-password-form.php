<?php
	$settings                   = $this->get_settings_for_display();
	$allowed_tags               = $this->get_allowed_html_tags();
	$form_title                 = isset ( $settings['form_title'] ) ? wp_kses_post ( $settings['form_title'] ) : '';
	$email_username_field_label = isset ( $settings['email_username_field_label'] ) ? wp_kses_post( $settings['email_username_field_label'] ) : '';
	$lost_form_text             = isset ( $settings['lost_form_text'] ) ? wp_kses_post( $settings['lost_form_text'] ) : '';
	$lost_form_text_output      = wpautop( wp_kses( $lost_form_text, $allowed_tags ) );
	$minimum_password_length    = isset ( $settings['minimum_password_length'] ) ? $settings['minimum_password_length'] : '';
	$form_button_text           = isset ( $settings['form_button_text'] ) ? wp_kses_post( $settings['form_button_text'] ) : '';
	$btn_justify                = '';

	if ( isset( $settings['submit_alignment'] ) ) {
		$btn_justify = 'justify' === $settings['submit_alignment'] ? 'madx-reset__button-full' : '';
	}
?>

<div class="madx-reset">

	<?php if ( ! empty( $errors ) ) : ?>

		<?php if ( is_array( $errors ) ) : ?>

			<?php foreach ( $errors as $error ) : ?>
				<p class="madx-reset__error-message">
					<span><?php echo $error; ?></span>
				</p>
			<?php endforeach; ?>

		<?php endif; ?>

	<?php endif; ?>

	<?php if ( $email_confirmed ) : ?>

		<p class="madx-reset__success-message">
			<?php echo esc_html__( 'An email has been sent. Please check your inbox.' , 'madx-blocks' ); ?>
		</p>

	<?php endif; ?>

	<form id="lostpasswordform" class="madx-reset__form" name="lostpasswordform" method="post">

		<?php if ( ! empty( $form_title ) ):?>

			<legend class="madx-reset__form-title"><?php echo $form_title; ?></legend>

		<?php endif;?>

		<?php if ( ! empty( $lost_form_text_output ) ):?>

			<div class="madx-reset__form-text">
				<?php echo $lost_form_text_output;?>
			</div>

		<?php endif;?>

		<p class="madx_reset__user-info">

			<label for="madx_reset_user_info"><?php echo $email_username_field_label; ?></label>
			<input class="input" type="text" name="madx_reset_user_info" id="madx_reset_user_info">

		</p>

		<div class="madx-reset__submit">

			<?php wp_nonce_field( 'madx_reset_lost_pass', 'madx_reset_nonce' ); ?>
			<input type="hidden" name="submitted" id="submitted" value="true">
			<input type="hidden" name="madx_reset_action" id="madx_reset_post_action" value="madx_reset_lost_pass">
			<button type="submit" id="madx-reset-pass-submit" name="madx-reset-pass-submit" class="button button-primary madx-reset__button <?php echo $btn_justify; ?>"><?php echo $form_button_text; ?></button>

		</div>

	</form>

	<?php
		if ( madx_blocks()->madxartwork()->editor->is_edit_mode() ){
			include $this->__get_global_template( 'demo-messages' );
		}
	?>

</div>