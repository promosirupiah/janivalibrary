<?php
/**
 * Login messages
 */

$message = wp_cache_get( 'madx-login-messages' );

if ( ! $message ) {
	return;
}

?>
<div class="madx-login-message"><?php
	echo $message;
?></div>