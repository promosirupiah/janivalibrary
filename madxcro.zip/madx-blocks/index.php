<?php
/**
 * Silence is golden
 *
 * @package  madx-blocks
 * @category Core
 * @author   Zemez
 * @license  GPL-2.0+
 */
