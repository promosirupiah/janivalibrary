( function( $ ) {

	'use strict';

	var madxBlocksEditor = {

		activeSection: null,

		modal: false,

		init: function() {

			madxartwork.channels.editor.on( 'section:activated', madxBlocksEditor.onAuthSectionActivated );
			madxartwork.channels.editor.on( 'section:activated', madxBlocksEditor.onSearchSectionActivated );
			madxartwork.channels.editor.on( 'section:activated', madxBlocksEditor.onCartSectionActivated );

			window.madxartwork.on( 'preview:loaded', function() {
				madxartwork.$preview[0].contentWindow.madxBlocksEditor = madxBlocksEditor;

				madxBlocksEditor.onPreviewLoaded();
			});
		},

		onCartSectionActivated: function( sectionName, editor ) {

			var editedElement = editor.getOption( 'editedElementView' );

			if ( 'madx-blocks-cart' !== editedElement.model.get( 'widgetType' ) ) {
				return;
			}

			window.madxBlocksEditor.activeSection = sectionName;

			var isCart = -1 !== [ 'cart_list_style', 'cart_list_items_style', 'cart_buttons_style' ].indexOf( sectionName );

			if ( isCart ) {
				editedElement.$el.find( '.madx-blocks-cart' ).addClass( 'madx-cart-hover' );
			} else {
				editedElement.$el.find( '.madx-blocks-cart' ).removeClass( 'madx-cart-hover' );
			}

		},

		onSearchSectionActivated: function( sectionName, editor ) {

			var editedElement = editor.getOption( 'editedElementView' );

			if ( 'madx-search' !== editedElement.model.get( 'widgetType' ) ) {
				return;
			}

			window.madxBlocksEditor.activeSection = sectionName;

			var isPopup = -1 !== [ 'section_popup_style', 'section_popup_close_style', 'section_form_style' ].indexOf( sectionName );

			if ( isPopup ) {
				editedElement.$el.find( '.madx-search' ).addClass( 'madx-search-popup-active' );
			} else {
				editedElement.$el.find( '.madx-search' ).removeClass( 'madx-search-popup-active' );
			}

		},

		onAuthSectionActivated: function( sectionName, editor ) {

			var editedElement = editor.getOption( 'editedElementView' );

			if ( 'madx-auth-links' !== editedElement.model.get( 'widgetType' ) ) {
				return;
			}

			window.madxBlocksEditor.activeSection = sectionName;

			var isLogout     = -1 !== [ 'section_logout_link', 'section_logout_link_style' ].indexOf( sectionName );
			var isRegistered = -1 !== [ 'section_registered_link', 'section_registered_link_style' ].indexOf( sectionName );

			if ( isLogout ) {
				editedElement.$el.find( '.madx-auth-links__logout' ).css( 'display', 'flex' );
				editedElement.$el.find( '.madx-auth-links__login' ).css( 'display', 'none' );
			} else {
				editedElement.$el.find( '.madx-auth-links__logout' ).css( 'display', 'none' );
				editedElement.$el.find( '.madx-auth-links__login' ).css( 'display', 'flex' );
			}

			if ( isRegistered ) {
				editedElement.$el.find( '.madx-auth-links__registered' ).css( 'display', 'flex' );
				editedElement.$el.find( '.madx-auth-links__register' ).css( 'display', 'none' );
			} else {
				editedElement.$el.find( '.madx-auth-links__registered' ).css( 'display', 'none' );
				editedElement.$el.find( '.madx-auth-links__register' ).css( 'display', 'flex' );
			}

		},

		onPreviewLoaded: function() {
			var $previewContents = window.madxartwork.$previewContents,
				madxartworkFrontend = $('#madxartwork-preview-iframe')[0].contentWindow.madxartworkFrontend;

			madxartworkFrontend.hooks.addAction( 'frontend/element_ready/madx-hamburger-panel.default', function( $scope ){
				$scope.find( '.madx-blocks__edit-cover' ).on( 'click', madxBlocksEditor.showTemplatesModal );

				$scope.find( '.madx-blocks-new-template-link' ).on( 'click', function( event ) {
					//window.location.href = $( this ).attr( 'href' );
					window.open( $( this ).attr( 'href' ) ); // changed on this for the opened link in new tab
				} );
			} );

			madxBlocksEditor.getModal().on( 'hide', function() {
				window.madxartwork.reloadPreview();
			});
		},

		showTemplatesModal: function() {
			var editLink = $( this ).data( 'template-edit-link' );

			madxBlocksEditor.showModal( editLink );
		},

		showModal: function( link ) {
			var $iframe,
				$loader;

			madxBlocksEditor.getModal().show();

			$( '#madx-blocks-edit-template-modal .dialog-message' ).html( '<iframe src="' + link + '" id="madx-blocks-edit-frame" width="100%" height="100%"></iframe>' );
			$( '#madx-blocks-edit-template-modal .dialog-message' ).append( '<div id="madx-blocks-loading"><div class="madxartwork-loader-wrapper"><div class="madxartwork-loader"><div class="madxartwork-loader-boxes"><div class="madxartwork-loader-box"></div><div class="madxartwork-loader-box"></div><div class="madxartwork-loader-box"></div><div class="madxartwork-loader-box"></div></div></div><div class="madxartwork-loading-title">Loading</div></div></div>' );

			$iframe = $( '#madx-blocks-edit-frame' );
			$loader = $( '#madx-blocks-loading' );

			$iframe.on( 'load', function() {
				$loader.fadeOut( 300 );
			} );
		},

		getModal: function() {

			if ( ! madxBlocksEditor.modal ) {
				this.modal = madxartwork.dialogsManager.createWidget( 'lightbox', {
					id: 'madx-blocks-edit-template-modal',
					closeButton: true,
					closeButtonClass: 'eicon-close',
					hide: {
						onBackgroundClick: false
					}
				} );
			}

			return madxBlocksEditor.modal;
		}

	};

	$( window ).on( 'madxartwork:init', madxBlocksEditor.init );

	window.madxBlocksEditor = madxBlocksEditor;

}( jQuery ) );
