;( function( $, madxartwork, settings ) {

	"use strict";

	var madxBlog = {

		YT: null,
		updateCurrentPage: {},

		init: function() {

			var widgets = {
				'madx-blog-smart-listing.default': madxBlog.initSmartListing,
				'madx-blog-smart-tiles.default': madxBlog.initSmartTiles,
				'madx-blog-text-ticker.default': madxBlog.initTextTicker,
				'madx-blog-video-playlist.default': madxBlog.initPlayList
			};

			$.each( widgets, function( widget, callback ) {
				madxartwork.hooks.addAction( 'frontend/element_ready/' + widget, callback );
			});

		},

		initPlayList: function( $scope ) {
			var $target            = $( '.madx-blog-playlist', $scope ),
				$indexContainer    = $( '.madx-blog-playlist__item-index', $target ),
				hideIndex          = $target.data( 'hide-index' ),
				$durationContainer = $( '.madx-blog-playlist__item-duration', $target ),
				hideDuration       = $target.data( 'hide-duration' ),
				$imageContainer    = $( '.madx-blog-playlist__item-thumb', $target ),
				hideImage          = $target.data( 'hide-image' ),
				deviceMode         = madxartworkFrontend.getCurrentDeviceMode();

			if ( -1 != hideIndex.indexOf( deviceMode ) ) {
				$indexContainer.css( 'display', 'none' );
			}

			if ( -1 != hideDuration.indexOf( deviceMode ) ) {
				$durationContainer.css( 'display', 'none' );
			}

			if ( -1 != hideImage.indexOf( deviceMode ) ) {
				$imageContainer.css( 'display', 'none' );
			}

			$( window ).on( 'resize orientationchange', function() {
				deviceMode = madxartworkFrontend.getCurrentDeviceMode();

				if ( -1 != hideIndex.indexOf( deviceMode ) ) {
					$indexContainer.css( 'display', 'none' );
				} else {
					$indexContainer.css( 'display', 'block' );
				}

				if ( -1 != hideDuration.indexOf( deviceMode ) ) {
					$durationContainer.css( 'display', 'none' );
				} else {
					$durationContainer.css( 'display', 'block' );
				}

				if ( -1 != hideImage.indexOf( deviceMode ) ) {
					$imageContainer.css( 'display', 'none' );
				} else {
					$imageContainer.css( 'display', 'block' );
				}
			} )

			if ( 'undefined' !== typeof YT.Player ) {
				madxBlog.initPlayListCb( $scope, YT );
			} else {
				$( document ).on( 'madxYouTubeIframeAPIReady', function( event, YT ) {
					madxBlog.initPlayListCb( $scope, YT );
				} );
			}

		},

		initPlayListCb: function( $scope, YT ) {

			if ( null === madxBlog.YT ) {
				madxBlog.YT = YT;
			}

			if ( $scope.hasClass( 'players-initialized' ) ) {
				return;
			}

			$scope.addClass( 'players-initialized' );

			madxBlog.switchVideo( $scope.find( '.madx-blog-playlist__item.madx-blog-active' ) );

			$scope.on( 'click.madxBlog', '.madx-blog-playlist__item', function() {
				$scope.find( '.madx-blog-playlist__canvas' ).addClass( 'madx-blog-canvas-active' );
				madxBlog.switchVideo( $( this ) );
			} );

			$scope.on( 'click.madxBlog', '.madx-blog-playlist__canvas-overlay', madxBlog.stopVideo );
		},

		initTextTicker: function( $scope ) {
			var timer          = null,
				$ticker        = $scope.find( '.madx-text-ticker__posts' ),
				isTypingEffect = $ticker.data( 'typing' ),
				sliderSettings = $ticker.data( 'slider-atts' );

			/**
			 * Typing effect with JS
			 *
			 * @since 2.1.17
			 */
			if ( isTypingEffect ) {
				$ticker.on( 'init', function( event, slick ) {
					var $currentTyping = $( '[data-slick-index="' + slick.currentSlide + '"] .madx-text-ticker__item-typed-inner', $ticker );

					typing( $currentTyping );
				} );

				$ticker.on( 'beforeChange', function( event, slick, currentSlide, nextSlide ) {
					var $typedItem     = $( '[data-slick-index="' + currentSlide + '"] .madx-text-ticker__item-typed', $ticker ),
						$currentTyping = $( '[data-slick-index="' + currentSlide + '"] .madx-text-ticker__item-typed-inner', $ticker ),
						$nextTyping    = $( '[data-slick-index="' + nextSlide + '"] .madx-text-ticker__item-typed-inner', $ticker );

					clearInterval( timer );
					$typedItem.removeClass( 'madx-text-typing' );
					$currentTyping.text( '' );

					typing( $nextTyping );
				} );
			}
			/** End */

			$ticker.slick( sliderSettings );

			// Typing function
			function typing( $selector ) {

				if ( !$selector.length ) {
					return;
				}

				var typingCounter    = 0,
					$typedItem       = $selector.closest( '.madx-text-ticker__item-typed' ),
					typingText       = $selector.data( 'typing-text' ),
					typingTextLength = typingText.length;

				$typedItem.addClass( 'madx-text-typing' );
				$selector.text( typingText.substr( 0, typingCounter++ ) );

				timer = setInterval( function() {
					if ( typingCounter <= typingTextLength ) {
						$selector.text( typingText.substr( 0, typingCounter++ ) );
					} else {
						clearInterval( timer );
						$typedItem.removeClass( 'madx-text-typing' );
					}
				}, 40 );
			}
		},

		initSmartListing: function( $scope ) {
			var deviceMode     = madxartworkFrontend.getCurrentDeviceMode(),
				editMode       = window.madxartworkFrontend.isEditMode(),
				id             = $scope.data('id'),
				$wrapper       = $( '.madx-smart-listing-wrap', $scope ),
				$settings      = $wrapper.data( 'settings' );

			if ( !madxBlog.updateCurrentPage[id] ) {
				madxBlog.updateCurrentPage[id] = { updatePage: 0 }
			}

			$scope.on( 'click.madxBlog', '.madx-smart-listing__filter-item a', madxBlog.handleSmartListingFilter );
			$scope.on( 'click.madxBlog', '.madx-smart-listing__arrow', madxBlog.handleSmartListingPager );

			var $filter = $scope.find( '.madx-smart-listing__filter' ),
				rollup  = $filter.data( 'rollup' );

			if ( rollup ) {
				$filter.madxBlogMore();
			}

			$( document ).trigger( 'madx-blog-smart-list/init', [ $scope, madxBlog ] );

			var devicesPosts = madxBlog.breakpointsPosts( $wrapper );

			function updatePosts() {
				var deviceMode   = madxartworkFrontend.getCurrentDeviceMode(),
					filter       = $('.madx-smart-listing__filter', $scope ),
					filterTerm   = filter.find('.madx-active-item a').data('term'),
					data         = {};

				devicePosts = madxBlog.currentBreakpointPosts( devicesPosts, deviceMode );

				madxBlog.updateCurrentPage[id].updatePage = 1;

				if ( $wrapper.hasClass( 'madx-processing' ) ) {
					return;
				}

				$wrapper.addClass( 'madx-processing' );

				data = { paged: 1, posts_per_page: devicePosts };

				if ( filter[0] ) {
					data.term = filterTerm;
				}

				$.ajax({
					url: settings.ajaxurl,
					type: 'POST',
					dataType: 'json',
					data: {
						action: 'madx_blog_smart_listing_get_posts',
						madx_request_data: data,
						madx_widget_settings: $settings
					},
				}).done( function( response ) {

					var $arrows = $wrapper.find( '.madx-smart-listing__arrows' );

					$wrapper
						.removeClass( 'madx-processing' )
						.find( '.madx-smart-listing' )
						.html( response.data.posts );

					if ( $arrows.length ) {
						$arrows.replaceWith( response.data.arrows );
					}

				}).fail(function() {
					$wrapper.removeClass( 'madx-processing' );
				});
			}

			if ( 'yes' != $settings['is_archive_template'] ) {

				if ( editMode ) {
					$( window ).on( 'resize.madxBlog orientationchange.madxBlog', madxBlog.debounce( 50, updatePosts ) );
				} else {
					$( window ).on( 'orientationchange.madxBlog', madxBlog.debounce( 50, updatePosts ) );
				}

				if ( 'desktop' != deviceMode ) {
					var devicePosts = madxBlog.currentBreakpointPosts( devicesPosts, deviceMode );

					if ( $wrapper.hasClass( 'madx-processing' ) ) {
						return;
					}

					$wrapper.addClass( 'madx-processing' );

					$.ajax({
						url: settings.ajaxurl,
						type: 'POST',
						dataType: 'json',
						data: {
							action: 'madx_blog_smart_listing_get_posts',
							madx_request_data: { posts_per_page: devicePosts },
							madx_widget_settings: $wrapper.data( 'settings' )
						},
					}).done( function( response ) {

						var $arrows = $wrapper.find( '.madx-smart-listing__arrows' );

						$wrapper
							.removeClass( 'madx-processing' )
							.find( '.madx-smart-listing' )
							.html( response.data.posts );

						if ( $arrows.length ) {
							$arrows.replaceWith( response.data.arrows );
						}

					}).fail(function() {
						$wrapper.removeClass( 'madx-processing' );
					});
				}
			}
		},

		initSmartTiles: function( $scope ) {

			var $carousel = $scope.find( '.madx-smart-tiles-carousel' );

			if ( 0 === $carousel.length ) {
				return false;
			}

			var sliderSettings = $carousel.data( 'slider-atts' );

			$carousel.slick( sliderSettings );

		},

		stopVideo: function( event ) {
			var $target         = $( event.currentTarget ),
				$canvas         = $target.closest( '.madx-blog-playlist__canvas' ),
				currentPlayer   = $canvas.data( 'player' ),
				currentProvider = $canvas.data( 'provider' );

			if ( $canvas.hasClass( 'madx-blog-canvas-active' ) ) {
				$canvas.removeClass( 'madx-blog-canvas-active' );
				madxBlog.pauseCurrentPlayer( currentPlayer, currentProvider );
			}

		},

		switchVideo: function( $el ) {

			var $canvas         = $el.closest( '.madx-blog-playlist' ).find( '.madx-blog-playlist__canvas' ),
				$counter        = $el.closest( '.madx-blog-playlist' ).find( '.madx-blog-playlist__counter-val' ),
				id              = $el.data( 'id' ),
				$iframeWrap     = $canvas.find( '#embed_wrap_' + id ),
				newPlayer       = $el.data( 'player' ),
				newProvider     = $el.data( 'provider' ),
				currentPlayer   = $canvas.data( 'player' ),
				currentProvider = $canvas.data( 'provider' );

			if ( newPlayer ) {
				madxBlog.startNewPlayer( newPlayer, newProvider );
				$canvas.data( 'provider', newProvider );
				$canvas.data( 'player', newPlayer );
			}

			if ( currentPlayer ) {
				madxBlog.pauseCurrentPlayer( currentPlayer, currentProvider );
			}

			if ( $counter.length ) {
				$counter.html( $el.data( 'video_index' ) );
			}

			$el.siblings().removeClass( 'madx-blog-active' );

			if ( ! $el.hasClass( 'madx-blog-active' ) ) {
				$el.addClass( 'madx-blog-active' );
			}

			if ( ! $iframeWrap.length ) {

				$iframeWrap = $( '<div id="embed_wrap_' + id + '"></div>' ).appendTo( $canvas );

				switch ( newProvider ) {

					case 'youtube':
						madxBlog.intYouTubePlayer( $el, {
							id: id,
							canvas: $canvas,
							currentPlayer: currentPlayer,
							playerTarget: $iframeWrap,
							height: $el.data( 'height' ),
							videoId: $el.data( 'video_id' )
						} );
					break;

					case 'vimeo':
						madxBlog.intVimeoPlayer( $el, {
							id: id,
							canvas: $canvas,
							currentPlayer: currentPlayer,
							playerTarget: $iframeWrap,
							html: $.parseJSON( $el.data( 'html' ) )
						} );
					break;

				}

				$iframeWrap.addClass( 'madx-blog-playlist__embed-wrap' );

			}

			$iframeWrap.addClass( 'madx-blog-active' ).siblings().removeClass( 'madx-blog-active' );

		},

		intYouTubePlayer: function( $el, plSettings ) {

			var $iframe = $( '<div id="embed_' + plSettings.id + '"></div>' ).appendTo( plSettings.playerTarget );
			var player  = new madxBlog.YT.Player( $iframe[0], {
				height: plSettings.height,
				width: '100%',
				videoId: plSettings.videoId,
				playerVars: { 'showinfo': 0, 'rel': 0 },
				events: {
					onReady: function( event ) {
						$el.data( 'player', event.target );

						if ( plSettings.currentPlayer ) {
							event.target.playVideo();
						}

						plSettings.canvas.data( 'provider', 'youtube' );
						plSettings.canvas.data( 'player', event.target );

					},
					onStateChange: function( event ) {

						var $index  = $el.find( '.madx-blog-playlist__item-index' );

						if ( ! $index.length ) {
							return;
						}

						switch ( event.data ) {

							case 1:
								$index.removeClass( 'madx-is-paused' ).addClass( 'madx-is-playing' );
								if ( ! plSettings.canvas.hasClass( 'madx-blog-canvas-active' ) ) {
									plSettings.canvas.addClass( 'madx-blog-canvas-active' );
								}
							break;

							case 2:
								$index.removeClass( 'madx-is-playing' ).addClass( 'madx-is-paused' );
							break;

						}
					}
				}
			});

		},

		intVimeoPlayer: function( $el, plSettings ) {

			var $iframe = $( plSettings.html ).appendTo( plSettings.playerTarget );
			var player  = new Vimeo.Player( $iframe[0] );
			var $index  = $el.find( '.madx-blog-playlist__item-index' );

			player.on( 'loaded', function( event ) {

				$el.data( 'player', this );
				if ( plSettings.currentPlayer ) {
					this.play();
				}

				plSettings.canvas.data( 'provider', 'vimeo' );
				plSettings.canvas.data( 'player', this );
			});

			player.on( 'play', function() {
				if ( $index.length ) {
					$index.removeClass( 'madx-is-paused' ).addClass( 'madx-is-playing' );
					if ( ! plSettings.canvas.hasClass( 'madx-blog-canvas-active' ) ) {
						plSettings.canvas.addClass( 'madx-blog-canvas-active' );
					}
				}
			});

			player.on( 'pause', function() {
				if ( $index.length ) {
					$index.removeClass( 'madx-is-playing' ).addClass( 'madx-is-paused' );
				}
			});

		},

		pauseCurrentPlayer: function( currentPlayer, currentProvider ) {

			switch ( currentProvider ) {
				case 'youtube':
					currentPlayer.pauseVideo();
				break;

				case 'vimeo':
					currentPlayer.pause();
				break;
			}
		},

		startNewPlayer: function( newPlayer, newProvider ) {

			switch ( newProvider ) {
				case 'youtube':
					setTimeout( function() {
						newPlayer.playVideo();
					}, 300);
				break;

				case 'vimeo':
					newPlayer.play();
				break;
			}

		},

		handleSmartListingFilter: function( event ) {

			var $this = $( this ),
				$item = $this.closest( '.madx-smart-listing__filter-item' ),
				term  = $this.data( 'term' );

			event.preventDefault();

			$item.closest('.madx-smart-listing__filter').find( '.madx-active-item' ).removeClass( 'madx-active-item' );
			$item.addClass( 'madx-active-item' );

			madxBlog.requestPosts( $this, { term: term, paged: 1 } );

		},

		handleSmartListingPager: function() {

			var $this        = $( this ),
				$wrapper     = $this.closest( '.madx-smart-listing-wrap' ),
				id           = $wrapper.closest('.madxartwork-widget-madx-blog-smart-listing').data('id'),
				currentPage  = parseInt( $wrapper.data( 'page' ), 10 ),
				newPage      = 1,
				currentTerm  = parseInt( $wrapper.data( 'term' ), 10 ),
				direction    = $this.data( 'dir' ),
				scrollTop    = $wrapper.data(  'scroll-top' );

			if ( $this.hasClass( 'madx-arrow-disabled' ) ) {
				return;
			}

			if ( 1 === madxBlog.updateCurrentPage[id].updatePage ) {
				currentPage = 1;
				madxBlog.updateCurrentPage[id].updatePage = 0;
			}

			if ( 'next' === direction ) {
				newPage = currentPage + 1;
			}

			if ( 'prev' === direction ) {
				newPage = currentPage - 1;
			}

			madxBlog.requestPosts( $this, { term: currentTerm, paged: newPage } );

			if ( scrollTop ) {
				$( 'html, body' ).stop().animate( { scrollTop: $wrapper.offset().top }, 500 );
			}

		},

		breakpointsPosts: function( $wrapper ) {

			var wrapper_settings  = $wrapper.data( 'settings' ),
				deviceMode        = madxartworkFrontend.getCurrentDeviceMode(),
				activeBreakpoints = madxartwork.config.responsive.activeBreakpoints,
				rows              = wrapper_settings['posts_rows'],
				breakpointPosts   = [],
				featuredPost      = 'yes' === wrapper_settings['featured_post'] ? 1 : 0,
				prevDevice;

				breakpointPosts['desktop'] = [];
				breakpointPosts['desktop'] = wrapper_settings['posts_columns'] * rows + featuredPost;
				prevDevice = 'desktop';

			Object.keys( activeBreakpoints ).reverse().forEach( function( breakpointName ) {

				if ( 'widescreen' === breakpointName ) {
					breakpointPosts[breakpointName] = wrapper_settings['posts_columns_' + breakpointName] ? wrapper_settings['posts_columns_' + breakpointName] * rows + featuredPost : breakpointPosts['desktop'];
				} else {
					breakpointPosts[breakpointName] = wrapper_settings['posts_columns_' + breakpointName] ? wrapper_settings['posts_columns_' + breakpointName] * rows + featuredPost : breakpointPosts[prevDevice];

					prevDevice = breakpointName;
				}
			} )

			return breakpointPosts;
		},

		currentBreakpointPosts: function( columnsArray, deviceMode ) {
			return columnsArray[deviceMode];
		},

		requestPosts: function( $trigger, data ) {

			var $wrapper = $trigger.closest( '.madx-smart-listing-wrap' ),
				$loader  = $wrapper.next( '.madx-smart-listing-loading' ),
				deviceMode   = madxartworkFrontend.getCurrentDeviceMode(),
				devicesPosts = madxBlog.breakpointsPosts( $wrapper ),
				devicePosts  = madxBlog.currentBreakpointPosts( devicesPosts, deviceMode );

			if ( $wrapper.hasClass( 'madx-processing' ) ) {
				return;
			}

			$wrapper.addClass( 'madx-processing' );

			data['posts_per_page'] = devicePosts;

			$.ajax({
				url: settings.ajaxurl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'madx_blog_smart_listing_get_posts',
					madx_request_data: data,
					madx_widget_settings: $wrapper.data( 'settings' )
				},
			}).done( function( response ) {

				var $arrows = $wrapper.find( '.madx-smart-listing__arrows' );

				$wrapper
					.removeClass( 'madx-processing' )
					.find( '.madx-smart-listing' )
					.html( response.data.posts );

				if ( $arrows.length ) {
					$arrows.replaceWith( response.data.arrows );
				}

			}).fail(function() {
				$wrapper.removeClass( 'madx-processing' );
			});

			if ( 'undefined' !== typeof data.paged ) {
				$wrapper.data( 'page', data.paged );
			}

			if ( 'undefined' !== typeof data.term ) {
				$wrapper.data( 'term', data.term );
			}

		},

		/**
		 * Debounce the function call
		 *
		 * @param  {number}   threshold The delay.
		 * @param  {Function} callback  The function.
		 */
		debounce: function ( threshold, callback ) {
			var timeout;

			return function debounced( $event ) {
				function delayed() {
					callback.call( this, $event );
					timeout = null;
				}

				if ( timeout ) {
					clearTimeout( timeout );
				}

				timeout = setTimeout( delayed, threshold );
			};
		}

	};

	$( window ).on( 'madxartwork/frontend/init', madxBlog.init );

	var madxBlogMore = function( el ) {

		this.$el        = $( el );
		this.$container = this.$el.closest( '.madx-smart-listing__heading' );

		if ( this.$container.find( '.madx-smart-listing__title' ).length ) {
			this.$heading = this.$container.find( '.madx-smart-listing__title' );
		} else {
			this.$heading = this.$container.find( '.madx-smart-listing__title-placeholder' );
		}

		this.settings = $.extend( {
			icon:      '<span class="madx-blog-icon"><i class="fa fa-ellipsis-h"></i></span>',
			className: 'madx-smart-listing__filter-item madx-smart-listing__filter-more'
		}, this.$el.data( 'more' ) );

		this.containerWidth = 0;
		this.itemsWidth     = 0;
		this.heading        = 0;

		this.init();

	};

	madxBlogMore.prototype = {

		constructor: madxBlogMore,

		init: function() {

			var self = this;

			this.containerWidth = this.$container.width();
			this.heading        = this.$heading.outerWidth();

			this.$hiddenWrap = $( '<div class="' + this.settings.className + '" hidden="hidden">' + this.settings.icon + '</div>' ).appendTo( this.$el );
			this.$hidden = $( '<div class="madx-smart-listing__filter-hidden-items"></div>' ).appendTo( this.$hiddenWrap );

			this.iter = 0;

			this.rebuildItems();

			setTimeout( function() {
				self.watch();
				self.rebuildItems();
			}, 300 );

		},

		watch: function() {

			var delay = 100;

			$( window ).on( 'resize.madxBlogMore orientationchange.madxBlogMore', madxBlog.debounce( delay, this.watcher.bind( this ) ) );
		},

		/**
		 * Responsive menu watcher callback.
		 *
		 * @param  {Object} Resize or Orientationchange event.
		 * @return {void}
		 */
		watcher: function( event ) {

			this.containerWidth = this.$container.width();
			this.itemsWidth     = 0;

			this.$hidden.html( '' );
			this.$hiddenWrap.attr( 'hidden', 'hidden' );

			this.$el.find( '> div[hidden]:not(.madx-smart-listing__filter-more)' ).each( function() {
				$( this ).removeAttr( 'hidden' );
			});

			this.rebuildItems();
		},

		rebuildItems: function() {

			var self            = this,
				$items          = this.$el.find( '> div:not(.madx-smart-listing__filter-more):not([hidden])' ),
				contentWidth    = 0,
				hiddenWrapWidth = parseInt( this.$hiddenWrap.outerWidth(), 10 );

			this.itemsWidth = 0;

			$items.each( function() {

				var $this  = $( this ),
					$clone = null;

				self.itemsWidth += $this.outerWidth();
				contentWidth = self.$heading.outerWidth() + hiddenWrapWidth + self.itemsWidth;

				if ( 0 > self.containerWidth - contentWidth && $this.is( ':visible' ) ) {

					$clone = $this.clone();

					$this.attr( { 'hidden': 'hidden' } );
					self.$hidden.append( $clone );
					self.$hiddenWrap.removeAttr( 'hidden' );
				}

			} );

		}

	};

	$.fn.madxBlogMore = function() {
		return this.each( function() {
			new madxBlogMore( this );
		} );
	};

}( jQuery, window.madxartworkFrontend, window.madxBlogSettings ) );

if ( 1 === window.hasmadxBlogPlaylist ) {

	function onYouTubeIframeAPIReady() {
		jQuery( document ).trigger( 'madxYouTubeIframeAPIReady', [ YT ] );
	}

}
