<?php
/**
 * Admin View: Header
 *
 * @package ClassicCommerce\Admin\Importers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
	</div>
</div>
