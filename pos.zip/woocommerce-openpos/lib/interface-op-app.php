<?php
/**
 * Created by PhpStorm.
 * User: anhvnit
 * Date: 3/19/19
 * Time: 23:36
 */
Interface OP_App {

    public function get_key();
    public function get_name();
    public function get_thumb();
    public function render();
}