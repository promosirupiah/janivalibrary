<?php
if(!class_exists('OP_Stock'))
{
    class OP_Stock{
        public function __construct()
        {
            add_action( 'openpos_daily_event', array($this, 'openpos_daily_event') );
        }
        public function registers(){

        }
        public function delete($id){

        }
        public function save(){

        }
        public function openpos_daily_event(){
            global $OPENPOS_CORE;
            global $wpdb;
            $current_date_from =  date('Y-m-d'); 
            $current_time_zone_from = strtotime($current_date_from);
            $current_time_zone_to = strtotime($current_date_from) + 86400;
            
            
            $meta_key = '_sale_price_dates_from';
            $sql = "SELECT * FROM {$wpdb->postmeta} WHERE meta_key = '".$meta_key."' AND (meta_value <> '' AND meta_value >".($current_time_zone_from - 100)." AND meta_value < ".($current_time_zone_to + 86400).") ORDER BY meta_value ASC ";
            $rows = $wpdb->get_results(  $sql, ARRAY_A);
            foreach($rows as $row)
            {
                $product_id = $row['post_id'];
                $warehouse_id = 0;
                $OPENPOS_CORE->addProductChange($product_id,$warehouse_id);
            }
            $meta_key = '_sale_price_dates_to';
            $sql = "SELECT * FROM {$wpdb->postmeta} WHERE meta_key = '".$meta_key."' AND (meta_value <> '' AND meta_value >".($current_time_zone_from - 86400)." AND meta_value < ".($current_time_zone_to + 100).") ORDER BY meta_value ASC ";
            $rows = $wpdb->get_results(  $sql, ARRAY_A);
            foreach($rows as $row)
            {
                $product_id = $row['post_id'];
                $warehouse_id = 0;
                $OPENPOS_CORE->addProductChange($product_id,$warehouse_id);
            }
            //$date_on_sale_from = date( 'Y-m-d 00:00:00', strtotime( $date_on_sale_from ) ); 
            //_sale_price_dates_from
            //_sale_price_dates_to
        }
    }
}
?>