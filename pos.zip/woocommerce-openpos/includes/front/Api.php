<?php
if(!class_exists('Openpos_Api'))
{
    class Openpos_Api{
        public function __construct()
        {
           
        }
        public function init()
        {
            // rest api
            add_action( 'rest_api_init', function () {
                // staff  route         
                register_rest_route( 'openpos/v1', '/staff/login/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => '__return_true',
                    ) 
                );
                register_rest_route( 'openpos/v1', '/staff/login-register/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => '__return_true',
                    ) 
                );
                register_rest_route( 'openpos/v1', '/staff/login-session/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => '__return_true',
                    ) 
                );
                register_rest_route( 'openpos/v1', '/staff/logout/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/staff/logoff/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/staff/logon/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                // product route
                register_rest_route( 'openpos/v1', '/product/products/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/product/scan/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/product/stock-overview/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/product/update-qty/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                //cart route
                register_rest_route( 'openpos/v1', '/cart/save/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/cart/carts/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/cart/cart/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/cart/get-discount/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/cart/get-shipping/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/cart/check-coupon/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                // order route
                register_rest_route( 'openpos/v1', '/order/create/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/orders/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/order/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/latest/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/check/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/close/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/refund/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/pickup/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/draft/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/transactions/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/add-transaction/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/order/send-receipt/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                // transaction route
                register_rest_route( 'openpos/v1', '/transaction/transactions/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/transaction/create/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                
                // customer route
                register_rest_route( 'openpos/v1', '/customer/create/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/customer/save/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/customer/customers/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/customer/searcy-by/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/customer/get-field/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                register_rest_route( 'openpos/v1', '/customer/orders/(?P<id>\d+)', array(
                    'methods' => 'GET',
                    'callback' => array($this,'test_api'),
                    'permission_callback' => array($this,'permission_callback'),
                    ) 
                );
                
                // table route


            });
        }
        public function permission_callback()
        {
            return true;
        }
        public function test_api(WP_REST_Request $request){
            $param = $request->get_param( 'some_param' );
            return new WP_Error( 'empty_category', 'There are no posts to display', array('status' => 404) );
        }
    }
}