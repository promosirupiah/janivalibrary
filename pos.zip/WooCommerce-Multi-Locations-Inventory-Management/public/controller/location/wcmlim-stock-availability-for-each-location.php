<?php

$stock = $product->get_stock_quantity();
		$terms = get_terms(array('taxonomy' => 'locations', 'hide_empty' => false, 'parent' => 0));
		$manage_stock = get_post_meta($product->get_id(), '_manage_stock', true);
		$arr_stock = array();
		foreach ($terms as $term) {
				$allow_specific_location = get_post_meta($product->get_id(), 'wcmlim_allow_specific_location_at_' . $term->term_id, true);
				if ($allow_specific_location  == 'Yes') {
				$loc_stock_val = intval(get_post_meta( $product->get_id(), "wcmlim_stock_at_{$term->term_id}" , true ));
				array_push($arr_stock, $loc_stock_val);
			}	
		}									
		$total_stock_qty = array_sum($arr_stock);
			if ($total_stock_qty  > 0 && $manage_stock =='yes') {
				$stock_text = $total_stock_qty .' is instock';
		}
		return $stock_text;
		