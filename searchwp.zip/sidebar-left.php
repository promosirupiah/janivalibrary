<div id="sidebar-left">
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/form.php">
	<input type="text" id="s" name="s" value="<?php the_search_query(); ?>"  /><br>
		
<?php 
$args=array(
  'orderby' => 'name',
  'order' => 'ASC',
  'hide_empty'=>1,
  );
$categories=get_categories($args);
foreach($categories as $category){
echo '-<input type="checkbox" name="cat[]" value="-'.$category->cat_ID.'"> +';
echo '<input type="checkbox" name="cat[]" value="'.$category->cat_ID.'">'.$category->cat_name.'<br>';
/*echo $category->cat_ID;echo'<br>'*/
;}
echo '<p>pengarang:</p>';
$args=array(
  'orderby' => 'name',
  'order' => 'ASC',
  'hide_empty'=>1,
  'taxonomy'=>'pengarang',
  );
$categories=get_categories($args);

foreach($categories as $category){
echo '<input type="radio" name="'.$category->taxonomy.'" value="'.$category->name.'">'.$category->cat_name.'<br>';
;}
echo '<p>type:</p>';
$args=array(
  'orderby' => 'name',
  'order' => 'ASC',
  'hide_empty'=>1,
  'taxonomy'=>'type',
  );
$categories=get_categories($args);

foreach($categories as $category){
echo '<input type="radio" name="'.$category->taxonomy.'" value="'.$category->name.'">'.$category->cat_name.'<br>';
;}
/*
$args=array(
  'orderby' => 'name',
  'order' => 'ASC',
  'hide_empty'=>1,
  'taxonomy'=>'type',
  );
$categories=get_categories($args);
echo'<select size="1" name="type">';
foreach($categories as $category){
echo '<option value="'.$category->name.'">'.$category->cat_name.'</option>';
;}
echo '</select>'
*/
?>
<input type="submit" id="searchsubmit" value="Search" />
</form>		
    <ul>
    <?php if ( !function_exists('dynamic_sidebar')
|| !dynamic_sidebar(Left) ) : ?>

						
            
            <li>
			<?php /* If this is a 404 page */ if (is_404()) { ?>
			
			<?php } ?>
			     </li>

		

			<?php /* If this is the frontpage */ if ( is_home() || is_page() ) { ?>		
		
				
			
			<?php } ?>
			<?php endif; ?>
			
			
		</ul>
	</div>
