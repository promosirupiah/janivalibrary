<?php
$first = 1;
foreach((array)$_GET as $name => $values){

if($first == 1){
if(is_array($values)){
$output .= '?'.$name.'=';
unset($comma);
foreach($values as $value){
$comma .=1;
if ($comma > 1){$output .=',';}
$output .= $value;
};
$first .=1;}
else {
$output .= '?'.$name.'='.$values;}
$first .=1;}

else {
if(is_array($values)){
$output .= '&'.$name.'=';
unset($comma);
foreach($values as $value){
$comma .=1;
if ($comma > 1){$output .=',';};
$output .= $value;};}
else {
$output .= '&'.$name.'='.$values;}
$first .=1;
}
}
/* echo $output;*/
$path = str_replace('form.php','',$_SERVER["SCRIPT_NAME"]);
/* header("HTTP/1.1 301 Moved Permanently");*/
header( 'Location: http://'.$_SERVER["SERVER_NAME"].$path.$output );

?>