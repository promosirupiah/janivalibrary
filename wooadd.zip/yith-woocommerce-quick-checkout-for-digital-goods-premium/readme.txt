=== YITH WooCommerce Quick Checkout For Digital Goods ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, yithemes, e-commerce, shop, checkout, digital, virtual, quick checkout, digital goods
Requires at least: 5.3
Tested up to: 5.6
Stable tag: 1.3.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.3.9 - Released: 03 February 2021 =

* New: support for WooCommerce 5.0
* Update: YITH plugin framework

= 1.3.8 - Released: 07 January 2021 =

* New: support for WooCommerce 4.9
* Update: YITH plugin framework

= 1.3.7 - Released: 03 December 2020 =

* New: support for WooCommerce 4.8
* Update: YITH plugin framework

= 1.3.6 - Released: 09 November 2020 =

* New: support for WordPress 5.6
* New: support for WooCommerce 4.7
* New: Possibility to update plugin via WP-CLI
* Update: YITH plugin framework

= 1.3.5 - Released: 21 September 2020 =

* New: support for WooCommerce 4.5
* Update: YITH plugin framework

= 1.3.4 - Released: 21 September 2020 =

* New: support for WooCommerce 4.5
* Update: YITH plugin framework

= 1.3.3 - Released: 20 August 2020 =

* New: support for WordPress 5.5
* New: support for WooCommerce 4.4
* Update: YITH plugin framework

= 1.3.2 - Released: 08 July 2020 =

* New: support for WooCommerce 4.3
* Update: YITH plugin framework

= 1.3.1 - Released: 27 May 2020 =

* New: support for WooCommerce 4.2
* Update: YITH plugin framework

= 1.3.0 - Released: 29 April 2020 =

* New: support for WooCommerce 4.1
* Update: YITH plugin framework

= 1.2.9 - Released: 27 February 2020 =

* New: support for WordPress 5.4
* New: support for WooCommerce 4.0
* Update: YITH plugin framework

= 1.2.8 - Released: 18 December 2019 =

* New: support for WooCommerce 3.9
* Update: YITH plugin framework

= 1.2.7 - Released: 13 November 2019 =

* Update: YITH plugin framework

= 1.2.6 - Released: 30 October 2019 =

* Update: YITH plugin framework

= 1.2.5 - Released: 25 October 2019 =

* New: support for WordPress 5.3
* New: support for WooCommerce 3.8
* Update: YITH plugin framework

= 1.2.4 - Released: 31 July 2019 =

* New: support for WooCommerce 3.7.0 RC1
* Update: YITH plugin framework
* Update: Italian language

= 1.2.3 - Released: 29 May 2019 =

* New: support for WordPress 5.2
* Update: YITH plugin framework
* Update: Spanish language

= 1.2.2 - Released: 30 March 2019 =

* New: support for WooCommerce 3.6.0 RC1
* Update: YITH plugin framework

= 1.2.1 - Released: 28 January 2019 =

* Update: YITH plugin framework

= 1.2.0 - Released: 05 December 2018 =

* New: support for Wordpress 5.0
* Update: YITH plugin framework

= 1.1.9 - Released: 23 October 2018 =

* Update: YITH plugin framework

= 1.1.8 - Released: 16 October 2018 =

* New: support for WooCommerce 3.5.0 RC2
* Update: YITH plugin framework

= 1.1.7 - Released: 02 October 2018 =

* Update: YITH plugin framework

= 1.1.6 - Released: 31 August 2018 =

* Update: YITH plugin framework

= 1.1.5 - Released: 24 May 2018 =

* New: support for Wordpress 4.9.6
* New: support for WooCommerce 3.4.0
* New: "Enable all users" option
* Update: YITH plugin framework
* Update: Spanish language
* Update: Italian language

= 1.1.4 - Released: 24 April 2018 =

* Tweak: added "ywqcdg_post_content" filter

= 1.1.3 - Released: 13 April 2018 =

* New: Spanish translation
* Fix: checkout script loading

= 1.1.2 - Released: 31 January 2018 =

* New: support for WooCommerce 3.3.0

= 1.1.1 - Released: 09 January 2017 =

* New: Italian translation
* New: Dutch translation
* Update: YITH plugin framework
* Tweak: added "ywqcdg_double_shortcode_loading" filter
* Fix: shortcode lightbox not working

= 1.1.0 - Released: 11 October 2017 =

* New: support for WooCommerce 3.2.0 RC2
* Update: YITH plugin framework

= 1.0.9 - Released: 20 September 2017 =

* Fix: compatibility issue when using YITH WooCommerce Multi-Step Checkout

= 1.0.8 - Released: 21 June 2017 =

* Fix: total checkout on product page

= 1.0.7 - Released: 16 May 2017 =

* Fix: total on shortcode
* Update: YITH plugin framework

= 1.0.6 - Released: 22 March 2017 =

* Tweak: support for WooCommerce 3.0.0-RC 1

= 1.0.5 - Released: 21 November 2016 =

* Fix: automatic add to cart of every product

= 1.0.4 - Released: 17 October 2016 =

* Fix: double shortcode button
* Fix: product page option not working

= 1.0.3 - Released: 13 July 2016 =

* New: option to add a product to the cart automatically when quick checkout has been set in product page

= 1.0.2 - Released: 15 June 2016 =

* Fix: double page loading with shortcode

= 1.0.1 - Released: 06 June 2016 =

* New: support for WooCommerce 2.6.0 beta 4

= 1.0.0 - Released: 18 April 2016 =

* Initial Release
