<?php
/**
 * Notes class
 *
 * @author  Yithemes
 * @package YITH Dynamic Payment per Methods for WooCommerce
 * @version 1.0.0
 */

if ( ! defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}


if ( !class_exists( 'YITH_WCDPPM_Functions_Premium' ) ) {
    /**
     * YITH_WCDPPM_Functions
     *
     * @since 1.0.0
     */
    class YITH_WCDPPM_Functions_Premium extends YITH_WCDPPM_Functions{

        /**
         * Single instance of the class
         *
         * @var \YITH_WCDPPM_Functions
         * @since 1.0.0
         */
        protected static $_instance;


        /**
         * Returns single instance of the class
         *
         * @return \YITH_WCDPPM_Functions_Premium
         * @since 1.0.0
         */
        public static function get_instance() {
            $self = __CLASS__ . ( class_exists( __CLASS__ . '_Premium' ) ? '_Premium' : '' );

            if ( is_null( $self::$_instance ) ) {
                $self::$_instance = new $self;
            }

            return $self::$_instance;
        }

        /**
         * Constructor
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function __construct() {
            add_filter('yith_wcdppm_get_type_dynamic_pricing',array($this,'yith_add_type_dynamic_pricing'));
            add_filter('yith_wcdppm_post_type_field',array($this,'yith_add_data_to_custom_post_type'));
            add_filter('yit_fw_metaboxes_type_args',array($this,'add_select2_yit_metabox'));
            add_filter('yith_wcdppm_apply_rule',array($this,'apply_rule_if_products_in_cart'),10,2);

            parent::__construct();
        }

        /**
         * Get a posts by $args
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * return array of posts
         */
        function yith_wcdppm_get_rules($args) {

            $defaults = apply_filters( 'yith_wcdppm_get_rule',array(
                'posts_per_page' => -1,
                'post_type' => 'yith-wcdppm-rule',
            ));

            $params = wp_parse_args( $args, $defaults );
            $results = get_posts( $params );

            return $results;
        }

        /**
         * Query post by type of payment method and by user role.
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        function yith_wcdppm_get_post_type_by_type($type,$roles) {
            $args = array(
                'meta_query' => array(
                    'relation' => 'AND',
                    array(
                        'key' => '_payment_methods',
                        'value' => $type,
                        'compare' => '='
                    ),
                ),
                'suppress_filters' => false,
            );
            if (!!$roles) {
                $roles_query = array();
                foreach ($roles as $role) {
                    $roles_query[] = array(
                        'key' => '_yith_wcdppm_user_role',
                        'value' => $role,
                        'compare' => 'LIKE'
                    );
                }
                //Get rule if role is empty
                $roles_query[] = array(
                    'key' => '_yith_wcdppm_user_role',
                    'compare' => 'NOT EXISTS',
                );

                $roles_query = array_merge(array('relation' => 'OR'), $roles_query);
                $args['meta_query'][] = $roles_query;
            }
            else {
                // Not user role
                $roles_query = array(
                    array(
                        'key' => '_yith_wcdppm_user_role',
                        'compare' => 'NOT EXISTS',
                    ),
                );
                $args['meta_query'][] = $roles_query;
            }

            return $this->yith_wcdppm_get_rules( $args );
        }


        /**
         * Add type dynamic pricing
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function yith_add_type_dynamic_pricing ( $type_dynamic_pricing ) {

            $new_type_dynamic_pricing = array(
                'dec_percent' => esc_html__('Decrease by percentage','yith-dynamic-pricing-per-payment-method-for-woocommerce'),
                'inc_value' => esc_html__('Increase by value','yith-dynamic-pricing-per-payment-method-for-woocommerce'),
                'inc_percent' => esc_html__('Increase by percentage','yith-dynamic-pricing-per-payment-method-for-woocommerce'),
            );

            $type_dynamic_pricing = array_merge($type_dynamic_pricing,$new_type_dynamic_pricing);

            return $type_dynamic_pricing;
        }

        /**
         * Get amount
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function yith_wcdppm_get_amount($type,$roles,$return_split_fee = false)
        {

			$amount = 0;
			$tax_fee = 0;

			if( apply_filters('yith_wcdppm_calculate_get_amount',true) ) {
				$rules      = $this->yith_wcdppm_get_post_type_by_type( $type, $roles );
				$date_order = time();
				$subtotal   = WC()->cart->cart_contents_total;
				$tax        = WC()->cart->tax_total;

				$total_orders_task = apply_filters( 'yith_wcgpf_order_total_with_shipping', $subtotal + $tax, WC()->cart );
				$amount            = 0;
				$tax_fee           = 0;
				foreach ( $rules as $rule ) {
					$apply_rule   = false;
					$payment_rule = $this->yith_wcdppm_get_dynamic_payment_method_object( $rule->ID );
					if ( ( $date_order >= strtotime( $payment_rule->schedule_from ) || ! $payment_rule->schedule_from ) && ( $date_order <= strtotime( $payment_rule->schedule_to ) || ! $payment_rule->schedule_to ) ) {
						if ( $payment_rule->include_tax ) {

							if ( ( $total_orders_task >= $payment_rule->min_cart || ! $payment_rule->min_cart ) && ( $total_orders_task <= $payment_rule->max_cart || ! $payment_rule->max_cart ) ) {
								$apply_rule = apply_filters( 'yith_wcdppm_apply_rule', true, $payment_rule );
							}

						} else {
							if ( ( $subtotal >= $payment_rule->min_cart || ! $payment_rule->min_cart ) && ( $subtotal <= $payment_rule->max_cart || ! $payment_rule->max_cart ) ) {
								$apply_rule = apply_filters( 'yith_wcdppm_apply_rule', true, $payment_rule );;
							}
						}
					}
					if ( $apply_rule ) {
						//Description rule
						$type = $payment_rule->dynamic_type;
						switch ( $type ) {
							case 'dec_percent':
								if ( $payment_rule->include_tax ) {
									$rule_amount   = ( $total_orders_task * $payment_rule->amount ) / 100;
									$amount_object = $this->yith_wcdppm_get_amount_and_tax( $payment_rule, $rule_amount );
									$amount        -= $amount_object[0];
									$tax_fee       -= $amount_object[1];

								} else {

									$rule_amount = ( $subtotal * $payment_rule->amount ) / 100;

									$amount_object = $this->yith_wcdppm_get_amount_and_tax( $payment_rule, $rule_amount );
									$amount        -= $amount_object[0];
									$tax_fee       -= $amount_object[1];

								}
								break;
							case 'inc_percent':
								if ( $payment_rule->include_tax ) {

									$rule_amount   = ( $total_orders_task * $payment_rule->amount ) / 100;
									$amount_object = $this->yith_wcdppm_get_amount_and_tax( $payment_rule, $rule_amount );
									$amount        += $amount_object[0];
									$tax_fee       += $amount_object[1];

								} else {

									$rule_amount   = ( $subtotal * $payment_rule->amount ) / 100;
									$amount_object = $this->yith_wcdppm_get_amount_and_tax( $payment_rule, $rule_amount );
									$amount        += $amount_object[0];
									$tax_fee       += $amount_object[1];
								}
								break;
							case 'inc_value':
								$rule_amount   = apply_filters( 'yith_wcdppm_get_amount_rule', $payment_rule->amount );
								$amount_object = $this->yith_wcdppm_get_amount_and_tax( $payment_rule, $rule_amount );
								$amount        += wc_format_decimal( $amount_object[0] );
								$tax_fee       += apply_filters( 'yith_wcdppm_get_tax_fee_rule', $amount_object[1] );
								break;
							default: //dec_value
								$rule_amount   = apply_filters( 'yith_wcdppm_get_amount_rule', $payment_rule->amount );
								$amount_object = $this->yith_wcdppm_get_amount_and_tax( $payment_rule, $rule_amount );
								$amount        -= wc_format_decimal( $amount_object[0] );
								$tax_fee       -= apply_filters( 'yith_wcdppm_get_tax_fee_rule', $amount_object[1] );
						}

					}
				}

				if ( $return_split_fee ) {
					return array( $amount, $tax_fee );
				}
			}
            return ( $amount + $tax_fee );
        }

        function yith_wcdppm_get_amount_and_tax($payment_rule,$rule_amount) {
            $tax_fee_object = array($rule_amount,0);


                if ( !empty( $payment_rule->tax_fee ) ) {

                    if ( $payment_rule->apply_tax_rule ) {
                        $tax_fee_object =  $this->yith_wcdppm_get_fee_amount_with_tax( $rule_amount,$payment_rule->tax_fee );
                    } else {
                        $tax_fee_object = $this->yith_wcdppm_get_fee_amount_without_tax( $rule_amount, $payment_rule->tax_fee );
                    }

                } else {
                    $tax_class = $payment_rule->fee_payment_tax_class;
                    
                    if ( 'none' == $tax_class ) {
                        $tax_fee_object = array($rule_amount,0);
                    } else {
                        $tax_class = 'standard' == $tax_class ? '' : $tax_class;
                        $tax_location = WC_Tax::get_rates($tax_class);
                        $first_taxes = !empty( $tax_location ) ? $tax_location[array_keys($tax_location)[0]] : 0 ;
                        if ( $payment_rule->apply_tax_rule ) {
                            $tax_fee_object =  $this->yith_wcdppm_get_fee_amount_with_tax($rule_amount, $first_taxes['rate']);
                        } else {
                            $tax_fee_object = $this->yith_wcdppm_get_fee_amount_without_tax( $rule_amount,  $first_taxes['rate'] );
                        }
                    }

                }

            return $tax_fee_object;

        }
        /**
         * Get tax if amount doesn't have tax
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function yith_wcdppm_get_fee_amount_without_tax($amount,$tax_for_fee) {

            if( $tax_for_fee ) {

                $tax = ($amount * $tax_for_fee)/100;
                return array($amount,$tax);

            } else {
                $tax = 0;
                return array($amount,$tax);
            }
        }

        /**
         * Get tax if amount has tax
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function yith_wcdppm_get_fee_amount_with_tax($amount,$tax_for_fee) {

            if( $tax_for_fee ) {
                $amount_without_tax = (100*$amount)/(100+$tax_for_fee);
                $tax = $amount - $amount_without_tax;
                return array($amount_without_tax,$tax);
            } else {
                $tax = 0;
                return array($amount,$tax);
            }

        }

    /**
         * Get Description
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function yith_wcdppm_get_desc($type,$roles,$description)
        {
            $rules = $this->yith_wcdppm_get_post_type_by_type($type, $roles);
            $date_order = time();
            $subtotal = WC()->cart->cart_contents_total;
            $tax = WC()->cart->tax_total;
            $total_orders_task = $subtotal + $tax;
            $desc = ($description) ? $description : false;
            foreach ($rules as $rule) {
                $apply_rule = false;
                $payment_rule = $this->yith_wcdppm_get_dynamic_payment_method_object($rule->ID);
                if ( ( $date_order >= strtotime($payment_rule->schedule_from) || !$payment_rule->schedule_from ) && ( $date_order <= strtotime($payment_rule->schedule_to) || !$payment_rule->schedule_to ) ) {
                    if ( $payment_rule->include_tax ) {

                        if ( ( $total_orders_task >= $payment_rule->min_cart || !$payment_rule->min_cart ) && ( $total_orders_task <= $payment_rule-> max_cart || !$payment_rule->max_cart ) ) {
                            $apply_rule = apply_filters('yith_wcdppm_apply_rule',true,$payment_rule);;
                        }

                    } else {
                        if ( ( $subtotal >= $payment_rule->min_cart || !$payment_rule->min_cart ) && ( $subtotal <= $payment_rule-> max_cart || !$payment_rule->max_cart ) ) {
                            $apply_rule = apply_filters('yith_wcdppm_apply_rule',true,$payment_rule);;
                        }
                    }
                }
                if ( $apply_rule ) {

                    //Description rule
                    if ( $payment_rule->custom_text ) {
                        $desc = $desc.' <br>'. $payment_rule->custom_text;
                    }
                }

            }

            return $desc;

        }
        /**
         * Add data to custom post type
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function yith_add_data_to_custom_post_type($data) {
            $functions = YITH_Dynamic_Pricing_Payments_Methods()->functions;
            $currency_simbol = get_woocommerce_currency_symbol();

            $amount = array_pop($data);


            $post_type_data = array(
                'dynamic_type'       => array(
                    'label' => esc_html__( 'Type', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => '',
                    'type'  => 'select',
                    'options' => $functions->yith_wcdppm_get_type_dynamic_pricing(),
                ),

                'amount' => $amount,

                'custom_text'       => array(
                    'label' => esc_html__( 'Custom text', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => '',
                    'type'  => 'textarea',
                ),
                'yith_wcdppm_user_role'       => array(
                    'label' => esc_html__( 'User role', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => '',
                    'type'  => 'yith_wcdppm_select2',
                    'multiple' => 'multiple',
                    'options' => $functions->yith_wcdppm_get_user_roles(),
                    'std' => array(),
                ),
                'include_tax'       => array(
                    'label' => esc_html__( 'Include tax', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc' => '',
                    'type'  => 'checkbox',
                ),
                'min_cart'       => array(
                    'label' => esc_html__( 'Min cart total', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => $currency_simbol,
                    'type'  => 'text',
                ),
                'max_cart'       => array(
                    'label' => esc_html__( 'Max cart total', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => $currency_simbol,
                    'type'  => 'text',
                ),
                'product_selected'        => array(
                    'label' => esc_html__( 'Product in cart','yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => esc_html__( 'Apply the rule if the products are in the cart', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'type'  => 'yith_wcdppm_ajax_product',
                ),
                'schedule_from'       => array(
                    'label' => esc_html__( 'Schedule FROM', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => '',
                    'type'  => 'text',
                ),
                'schedule_to'       => array(
                    'label' => esc_html__( 'Schedule TO', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  =>'',
                    'type'  => 'text',
                ),

                'tax_fee'       => array(
                    'label' => esc_html__( 'Tax rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => esc_html__( '% ( Insert a percentage value that will be applied basing on the amount rule. Leave blank to apply the tax class to the rule )', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'type'  => 'text',
                ),

                'fee_payment_tax_class'     => array(
                    'label' => esc_html__( 'Tax class', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc'  => esc_html__( 'Select the tax class that will be applied on the amount rule. This tax is applied if "Tax rule" field is empty ', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'type'  => 'select',
                    'options' => $functions->get_tax_class(),
                ),

                'apply_tax_rule'       => array(
                    'label' => esc_html__( 'Amount include tax?', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'desc' =>  esc_html__( 'Check this option if the amount include tax', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                    'type'  => 'checkbox',
                ),
            );

            $data = array_merge($data,$post_type_data);

            return $data;
        }


        /**
         * Get Description
         *
         * @since  1.1.3
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function get_tax_class() {
            
            $classes = WC_Tax::get_tax_classes();
            // Add standard class
            $tax_classes = array(
                 'none'      =>esc_html__('None','yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                 'standard' =>esc_html__( 'Standard rate', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
            );

            foreach ( $classes as $class ) {
                $tax_classes[ sanitize_title( $class )] = $class;
            }

            return apply_filters('yith_wcdppm_tax_classes',$tax_classes);
        }

        public function add_select2_yit_metabox( $args ) {
            if('yith_wcdppm_select2' == $args['type'] || 'yith_wcdppm_ajax_product' == $args['type']) {
                $args['basename'] = YITH_WCDPPM_PATH;
                $args['path'] ='metaboxes/types/';
            }
            return $args;
        }
        /**
         * Apply rule if products in cart
         *
         * @since  1.1.7
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        public function apply_rule_if_products_in_cart($apply_rule, $payment_rule) {

            if( !empty($payment_rule->product_selected) ) {
                $item_cart = WC()->cart->get_cart();

                $products_in_cart = array();
                foreach ( $item_cart as $cart_item_key => $cart_item ) {
                    $product_id = apply_filters('yith_wcdppm_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                    $products_in_cart[] = $product_id;
                    $variation_id = apply_filters('yith_wcdppm_cart_item_variation_id', $cart_item['variation_id'], $cart_item, $cart_item_key);
                    $products_in_cart[] = $variation_id;
                }
                if( ! empty( $products_in_cart ) ){
                    foreach( (array) $payment_rule->product_selected as $product ){
                        if( ! in_array( $product, $products_in_cart ) ){
                            $apply_rule =  false;
                            break;
                        }
                    }
                }
            }

            return $apply_rule;
        }

	    /**
	     * Loops all yith-wcdppm-rule post types and checks that payment method is defined on rules
	     * @access public
	     * @since 1.1.9
	     * @author   Francisco Javier Mateo
	     */
	    public function exist_payment ( $payment_method, $roles){

		    $rules = $this->yith_wcdppm_get_post_type_by_type($payment_method, $roles);

		    $exist_payment = !empty($rules) ? true : false;

		    return $exist_payment;
	    }

        /**
         * Get the tax class
         * @since  1.2.2
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         */
        //TODO improve how to get the tax class for each payment rule
        public function get_tax_class_payment_rule( $payment_method,$roles ) {

            $rules = $this->yith_wcdppm_get_post_type_by_type($payment_method, $roles);
            foreach ($rules as $rule) {
                $payment_rule = $this->yith_wcdppm_get_dynamic_payment_method_object($rule->ID);
                $tax_class = $payment_rule->fee_payment_tax_class;
            }
            if( !empty($tax_class) && 'none' != $tax_class ) {
                return $tax_class;

            }else {
                return '';
            }


        }

    }
}