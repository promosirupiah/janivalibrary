<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( !defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
 *
 */

if ( !class_exists( 'YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium' ) ) {
    /**
     * Class YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium
     *
     * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
     */
    class YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium  extends YITH_Dynamic_Pricing_Payments_Methods_Admin{

        
        /**
         * Single instance of the class
         *
         * @var \YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium
         * @since 1.0.0
         */
        protected static $_instance = null;

        /**
         * Returns single instance of the class
         *
         * @return \YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium
         * @since 1.0.0
         */
        public static function get_instance()
        {
            $self = __CLASS__ . ( class_exists( __CLASS__ . '_Premium' ) ? '_Premium' : '' );

            if ( is_null( $self::$_instance ) ) {
                $self::$_instance = new $self;
            }

            return $self::$_instance;
        }


        /**
         * Construct
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * @since 1.0
         */
        public function __construct() {
            /* === Register Panel Settings === */
            $this->show_premium_landing = false;
            
            parent::__construct();

        }

        /**
         * Plugin Row Meta
         *
         *
         * @return void
         * @since    1.2.1
         * @author   Carlos Rodríguez <carlos.rodriguez@youirinspiration.it>
         */
        public function plugin_row_meta( $new_row_meta_args, $plugin_meta, $plugin_file, $plugin_data, $status, $init_file = 'YITH_WCDPPM_INIT' ) {
            $new_row_meta_args = parent::plugin_row_meta( $new_row_meta_args, $plugin_meta, $plugin_file, $plugin_data, $status, $init_file );

            if ( defined( $init_file ) && constant( $init_file ) == $plugin_file ){
                $new_row_meta_args['is_premium'] = true;
            }

            return $new_row_meta_args;
        }
        /**
         * Regenerate auction prices
         *
         * Action Links
         *
         * @return void
         * @since    1.2.1
         * @author   Carlos Rodríguez <carlos.rodriguez@youirinspiration.it>
         */
        public function action_links( $links ) {
            $links = yith_add_action_links( $links, $this->_panel_page, true, YITH_WCDPPM_SLUG );
            return $links;
        }

    }


}

/**
 * Unique access to instance of YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium class
 *
 * @return \YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium
 * @since 1.0.0
 */
function YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium() {

    return YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium::get_instance();
}