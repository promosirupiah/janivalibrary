<?php
/**
 * Post Types class
 *
 * @author  Yithemes
 * @package YITH Dynamic Payments Methods for WooCommerce
 * @version 1.0.0
 */

if ( !defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit;
} // Exit if accessed directly

if ( !class_exists( 'YITH_WCDPPM_Post_Types' ) ) {
    /**
     * YITH Dynamic Payments Methods for WooCommerce Premium Post Types
     *
     * @since 1.0.0
     */
    class YITH_WCDPPM_Post_Types {


        /**
         * Dynamic Payment Post Type
         *
         * @var string
         * @static
         */
        public static $dynamic_payments = 'yith-wcdppm-rule';

        /**
         * Hook in methods.
         */
        public function __construct() {
            add_action( 'init', array($this, 'register_post_types' ));
            add_action( 'init', array( $this, 'add_style_metabox' ));
            add_action( 'edit_form_advanced', array( $this, 'add_return_to_list_button' ) );
        }

        /**
         * Register core post types.
         */
        public function register_post_types() {
            if ( post_type_exists( self::$dynamic_payments ) ) {
                return;
            }

            do_action( 'yith_wcdppm_register_post_type' );

            /*  DYNAMIC PRICING PAYMENTS METHODS  */

            $labels = array(
                'name'               => esc_html__( 'Dynamic Price per Payment Methods', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'singular_name'      => esc_html__( 'Dynamic Price per Payment Methods', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'add_new'            => esc_html__( 'Add new rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'add_new_item'       => esc_html__( 'Add New Rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'edit'               => esc_html__( 'Edit', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'edit_item'          => esc_html__( 'Edit Rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'new_item'           => esc_html__( 'New Rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'view'               => esc_html__( 'View Rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'view_item'          => esc_html__( 'View Rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'search_items'       => esc_html__( 'Search Rules', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'not_found'          => esc_html__( 'No Rules found', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'not_found_in_trash' => esc_html__( 'No Rules found in trash', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'parent'             => esc_html__( 'Parent Rules', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'menu_name'          => esc_html_x( 'YITH Rules', 'Admin menu name', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'all_items'          => esc_html__( 'All YITH Rules', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
            );

            $dynamic_payments_post_type_args = array(
                'label'               => esc_html__( 'Dynamic Payment Methods', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'labels'              => $labels,
                'description'         => esc_html__( 'This is where rules are stored.', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
                'public'              => true,
                'show_ui'             => true,
                'capability_type'     => 'product',
                'map_meta_cap'        => true,
                'publicly_queryable'  => false,
                'exclude_from_search' => true,
                'show_in_menu'        => false,
                'hierarchical'        => false,
                'show_in_nav_menus'   => false,
                'rewrite'             => false,
                'query_var'           => false,
                'supports'            => array( 'title' ),
                'has_archive'         => false,
                'menu_icon'           => 'dashicons-edit',
            );

            register_post_type( self::$dynamic_payments, apply_filters( 'yith_wcdppm_register_post_type_dynamic_payments_methods', $dynamic_payments_post_type_args ) );

        }
        /**
         * Add style metabox custom post type.
         */
        public function add_style_metabox() {

            if ( $this->check_valid_admin_page( YITH_WCDPPM_Post_Types::$dynamic_payments ) ) {
                $currency_simbol = get_woocommerce_currency_symbol();
                $functions = YITH_Dynamic_Pricing_Payments_Methods()->functions;
                $args = array(
                    'label' => esc_html__('Payment method price rule', 'yith-dynamic-pricing-per-payment-method-for-woocommerce'),
                    'pages' => self::$dynamic_payments,
                    'context' => 'normal',
                    'priority' => 'high',
                    'tabs' => apply_filters('yith_wcdppm_dynamic_pricing_per_payments_settings', array(
                        'style' => array(
                            'label' => esc_html__('Dynamic pricing per payments - form', 'yith-dynamic-pricing-per-payment-method-for-woocommerce'),
                            'fields' => apply_filters('yith_wcdppm_post_type_field', array(
                                'payment_methods' => array(
                                    'label' => esc_html__('Payment method', 'yith-dynamic-pricing-per-payment-method-for-woocommerce'),
                                    'desc' => '',
                                    'type' => 'select',
                                    'options' => $functions->yith_wcdppm_get_payment_gateway(),
                                ),
                                'amount' => array(
                                    'label' => esc_html__('Amount', 'yith-dynamic-pricing-per-payment-method-for-woocommerce'),
                                    'desc' => '',
                                    'type' => 'text',
                                ),
                            ))
                        )
                    ))
                );

                $metabox = YIT_Metabox('yith-wcdppm-search-form-style');
                $metabox->init($args);
            }

        }

        /**
         * Check if is a valid plugin page
         *
         * @since  1.2.0
         *
         * @param $post_type_name
         *
         * @return bool
         * @author Alberto Ruggiero
         */
        public function check_valid_admin_page( $post_type_name ) {
            global $pagenow;
            $post = isset( $_REQUEST['post'] ) ? $_REQUEST['post'] : ( isset( $_REQUEST['post_ID'] ) ? $_REQUEST['post_ID'] : 0 );
            $post = get_post( $post );

            if ( ( $post && $post->post_type == $post_type_name ) || ( $pagenow == 'post-new.php' && isset( $_REQUEST['post_type'] ) && $_REQUEST['post_type'] == $post_type_name ) ) {
                return true;
            }

            return false;
        }



        public function add_return_to_list_button() {
            global $post;

            if ( isset( $post ) && self::$dynamic_payments === $post->post_type ) {
                $admin_url = admin_url( 'admin.php' );
                $params = array(
                    'page' => 'yith_wcdppm_panel',
                    'tab' => 'settings'
                );

                $list_url = apply_filters( 'yith_wcdppm_rule_back_link', esc_url( add_query_arg( $params, $admin_url ) ) );
                $button = sprintf( '<a class="button-secondary" href="%s">%s</a>', $list_url,
                    esc_html__( 'Back to rules',
                        'yith-dynamic-pricing-per-payment-method-for-woocommerce' ) );
                echo $button;
            }
        }
    }
}

return new YITH_WCDPPM_Post_Types();