<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_WCDPPM_EU_VAT_Compatibility
 * @package    Yithemes
 * @since      Version 1.1.5
 * @author     Your Inspiration Themes
 *
 */
if ( ! class_exists( 'YITH_WCDPPM_EU_VAT_Compatibility' ) ) {

    class YITH_WCDPPM_EU_VAT_Compatibility
    {

        public function __construct()
        {
            add_filter('yith_wcdppm_eu_vat_exempt_amount', array($this,'eu_vat_exempt_amount'));
            add_action('yith_wcdppm_after_calculate_totals', array ( $this,'after_calculate_totals_call_back_yith_ywev' ),99,2 );
        }

        /**
         * EU VAT exempt amount
         *
         * return if the cart has exemption amount
         *
         * @param $value
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * @since  1.2.8
         *
         * @return double
         * @access public
         */
        public function eu_vat_exempt_amount ($value) {

            $value = WC ()->session->get ( "ywev_vat_exemption_amount" );

            return $value;
        }

        /**
         * After calculate totals call back
         *
         * Calculate totals an include eu vat if exits
         *
         * @param WC_Order $order , array $amount
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * @since  1.2.8
         *
         * @return void
         * @access public
         */
        public function after_calculate_totals_call_back_yith_ywev($order) {

            $post_data_array = array();
            //  Need $_POST['post_data'] to be set in order to extract checkout data
            if (isset($_POST['post_data'])) {

                parse_str ( $_POST['post_data'], $post_data_array );
                $billing_country = isset( $post_data_array['billing_country'] ) ? $post_data_array['billing_country'] : '';
                $ywev_vat_number = isset( $post_data_array['billing_yweu_vat'] ) ? $post_data_array['billing_yweu_vat'] : '';

            } else {
                $billing_country = isset($_POST['billing_country']) ? sanitize_text_field($_POST['billing_country']) : '';
                $ywev_vat_number = isset($_POST['billing_yweu_vat']) ? sanitize_text_field($_POST['billing_yweu_vat']) : '';
            }

            $ywev_vat_number = str_replace(' ', '', $ywev_vat_number);

            //  Without billing country and VAT number, no exemption can be calculated
            if ($billing_country && $ywev_vat_number) {

                $eu_vat_frontend = YITH_YWEV_Frontend_Premium::get_instance();

                //  If the billing country is not an EU country, nothing has to be calculated
                if (YITH_YWEV()->is_eu_country_code($billing_country)) {

                    //  Check if there is a VAT number and if it was validated, if it is affirmative, remove the taxes for digital goods
                    if (WC()->session->get("ywev_validated") == $eu_vat_frontend->get_full_vat_number($ywev_vat_number, $billing_country)) {

                        $geo_country = $eu_vat_frontend->get_geolocated_country_code();

                        $remove_tax = apply_filters('yith_ywev_customer_taxes_exemption', true, $geo_country, $billing_country);

                        if ($remove_tax) {

                            $allow_physical = 'yes' == get_option('ywev_apply_to_physical', 'no');

                            if ($order instanceof WC_Order) {
                                $save_order = false;
                                $tax_total = 0;
                                $tax_total_array = array();
                                $tax_data = array(
                                    'total' => 0,
                                    'subtotal' => 0,
                                );

                                foreach ($order->get_items(array( 'line_item', 'fee' )) as $order_item_id => $order_item_data) {

                                    $product_id = $order_item_data["product_id"];
                                    $product = wc_get_product($product_id);

                                    if( $product && $product instanceof WC_Product ) {
                                        if (!$product->is_taxable()) {
                                            continue;
                                        }

                                        if (!$product->is_virtual() && !$allow_physical) {
                                            continue;
                                        }
                                    }

                                    $item_taxes = $order_item_data->get_taxes();
                                    if (!empty($item_taxes['total'])) {
                                        $tax_total += array_sum($item_taxes['total']);
                                        foreach ($item_taxes['total'] as $tax_rate_id => $tax_amount) {
                                            if (!isset($tax_total_array[$tax_rate_id])) {
                                                $tax_total_array[$tax_rate_id] = 0;
                                            }

                                            $tax_total_array[$tax_rate_id] += $tax_amount;
                                        }
                                    }
                                    $order_item_data->set_taxes($tax_data);
                                    $order_item_data->save();
                                    $save_order = true;


                                }

                                if ($save_order) {
                                    $order_total_tax = $order->get_tax_totals();


                                    if (!empty($order_total_tax)) {
                                        $order_total_tax_temp = $order_total_tax;
                                        foreach ($order_total_tax_temp as $tax_id => $tax_object) {
                                            if (!empty($tax_total_array[$tax_object->rate_id])) {
                                                $order_total_tax[$tax_object->rate_id] = ($order_total_tax[$tax_id]->amount - $tax_total_array[$tax_object->rate_id]);
                                            }
                                        }

                                        foreach ($order->get_taxes() as $tax_item_id => $tax) {
                                            /** @var WC_Order_Item_Tax $tax */
                                            if (isset($order_total_tax[$tax->get_rate_id()])) {
                                                $tax->set_tax_total($order_total_tax[$tax->get_rate_id()]);
                                                $tax->save();
                                            }
                                        }
                                    }

                                    $order->set_total($order->get_total() - $tax_total);
                                    $order->save();

                                }

                            }

                        }

                    }

                }

            }

        }

    }
}

return new YITH_WCDPPM_EU_VAT_Compatibility();
