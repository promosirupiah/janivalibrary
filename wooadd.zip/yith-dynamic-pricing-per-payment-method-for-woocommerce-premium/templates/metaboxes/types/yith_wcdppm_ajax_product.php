<?php

wp_enqueue_script( 'yith-enhanced-select' );
wp_enqueue_style( 'woocommerce_admin_styles' );

extract( $args );
$multiple = true;
$class    = 'wc-product-search';
/**
 * @var string       $id
 * @var string       $name
 * @var string|array $value
 */

// populate data-selected by value
$data_selected = array();
if ( !empty( $value ) ) {
    if ( $multiple ) {
        $value = is_array( $value ) ? $value : explode( ',', $value );
        foreach ( $value as $post_id ) {
            $data_selected[ $post_id ] = get_the_title( $post_id );
        }
    } else {
        $post_id                   = absint( $value );
        $data_selected[ $post_id ] = get_the_title( $post_id );
    }
}

// parse $value to string to prevent issue with wc2.6
$value = is_array( $value ) ? implode( ',', $value ) : $value;
?>
<label for="<?php echo $id ?>"><?php echo $label ?></label>

<?php
if ( function_exists( 'yit_add_select2_fields' ) ) {
    yit_add_select2_fields( array(
        'id'               => $id,
        'name'             => $name,
        'class'            => $class,
        'data-multiple'    => $multiple,
        'data-placeholder' => esc_html__( 'Search for a product&hellip;', 'woocommerce' ),
        'data-allow_clear' => false,
        'style'            => 'width:30%',
        'value'            => $value,
        'data-selected'    => $data_selected,
    ) );
}
?>
<span class="desc inline"><?php echo $desc ?></span>

