=== YITH Dynamic Pricing per Payment Method for WooCommerce Premium  ===

== Changelog ==

= 1.2.21 – Released on 09 February 2021 =

* New: Support for WooCommerce 5.0
* Update: YITH plugin framework

= 1.2.20 – Released on 13 January 2021 =

* New: Support to WooCommerce 4.9
* Update: Plugin-fw

= 1.2.19 – Released on 28 December 2020 =

* New: French translation
* Update: plugin framework
* Update: Deutsch language

= 1.2.18 – Released on 04 December 2020 =

* New: Support to WooCommerce 4.8
* Update: Plugin-fw

= 1.2.17 – Released on 04 November 2020 =

* New: Support to WooCommerce 4.7
* New: Support for WordPress 5.6
* Update: Plugin-fw
* Dev: Filter yith_wcdppm_calculate_get_amount

= 1.2.16 – Released on 14 September 2020 =

* New: Support to WooCommerce 4.6
* Update: Plugin-fw
* Tweak: Add gateway title on some gateways that doesn't have a title registered

= 1.2.15 – Released on 14 September 2020 =

* New: Support to WooCommerce 4.5
* New: Support for WordPress 5.5
* Update: Plugin-fw
* Update: .pot file

= 1.2.14 – Released on 07 July 2020 =

* New: Support to WooCommerce 4.3
* Update: Plugin-fw

= 1.2.13 – Released on 21 May 2020 =

* New: Support to WooCommerce 4.2
* Update: Plugin-fw

= 1.2.12 – Released on 04 March 2020 =

* New: Support to WooCommerce 4.1
* Update: Plugin-fw
* Update: .pot file
* Update: Italian language
* Dev: Escape all strings

= 1.2.11 - Released on 04 March 2020 =

* Update: Plugin-fw
* Update: .pot file
* Fix: Js issue with non logged user

= 1.2.10 - Released on 27 February 2020 =

* New: Support to WordPress 5.4
* New: Support to WooCommerce 4.0
* Update: Plugin-fw

= 1.2.9 - Released on 23 December 2019 =

* New: Support to WooCommerce 3.9.0
* New: Integration YITH WooCommerce EU VAT
* Update: Plugin-Fw

= 1.2.8 - Released on 06 November 2019 =

* Tweak : get payment method fee
* Update: Plugin-Fw

= 1.2.7 - Released on 24 October 2019 =

* New: Support to WooCommerce 3.8.0 RC1
* New: Allow apply rules also to guest users
* Update: Plugin-Fw

= 1.2.6 - Released on 22 May 2019 =

* New: Support to WooCommerce 3.7.0 RC2
* Update: Plugin-Fw

= 1.2.5 - Released on 22 May 2019 =

* New: Support to WooCommerce 3.6.0 RC1
* Update: Plugin-Fw
* Update. Italian language
* Update: Spanish language

= 1.2.4 - Released on 11 April 2019 =

* New: Support to WooCommerce 3.6.0 RC1
* Update: Plugin-Fw
* Update. Italian language
* Update: Spanish language

= 1.2.3 - Released on 18 February 2019 =

* Fix: Disable tax on rule if set it to none
* Update: Dutch translation
* Update: Update Plugin-fw
* Dev: filter yith_wcdppm_order_fee_title

= 1.2.2 - Released on 31 December 2018 =

* Tweak: Add tax when order complete
* Tweak: Improve get total row payment method
* Update: Dutch translation
* Update: Plugin framework
* Update: .pot language

= 1.2.1 - Released on 23 October 2018 =

* Update: Dutch translation
* Update: Plugin framework

= 1.2.0 - Released on 24 May 2018 =

* New: Support to WordPress 4.9.6
* New: Support to WooCommerce 3.4.0
* New: Persian translation thanks to Sadra
* Fix: Problem if the rule doesn't have tax
* Fix: Display tax when the product has the tax included
* Update: Spanish language
* Update: Plugin Framework
* Dev : yith_wcdppm_recalculate_taxes_and_total

= 1.1.12 - Released on 09 February 2018 =

* New: support to WordPress 4.9.4
* New: support to WooCommerce 3.3.1
* New: Spanish translation
* Fix: recalculate tax amount in order
* Fix: calculate totals in order

= 1.1.11 - Released on 01 February 2018 =

* New: support to WordPress 4.9.2
* New: support to WooCommerce 3.3.0
* New: Italian translation
* New: Dutch translation
* Update: plugin framework 3.0.11

= 1.1.10 - Released on 08 January 2018 =

* New: added condition to check if in current page plugin scripts should be loaded
* Fix: get amount and the tax if the amount doesn't include tax
* Fix: check if exists payment method
* Dev: added filter yith_wcgpf_order_total_with_shipping

= 1.1.9 - Released on 10 October 2017 =

* New: Support to WooCommerce 3.2.0 RC2
* Update: Plugin core

= 1.1.8 - Released on 19 September 2017 =

* Fix - Problem with order total
* Fix - Compatibility issue with  WooCommerce version < 3.0.0
* Dev - Filter yith_wcdppm_add_tax_in_amount

= 1.1.7 - Released on 28 August 2017 =

* New - apply rule if products are in cart
* Fix - amount if aelia currency switcher plugin is installed
* Dev - filter yith_wcdppm_localized_frontend_dom

= 1.1.6 - Released on 10 August 2017 =

* New - compatibility with YITH WooCommerce Account Funds
* Fix - Price rounding issue on checkout page

= 1.1.5 - Released on 18 July 2017 =

* New - compatibility with Aelia Currency Switcher Plugin
* Dev - added new filter yith_wcdppm_get_amount_rule
* Dev - added new filter yith_wcdppm_get_tax_fee_rule

= 1.1.4 - Released on 12 June 2017 =

* New - possibility to apply tax to rule using WooCommerce tax class
* New - added fee row to order received page
* Fix - total amount issues

= 1.1.3 - Released on 16 May 2017 =

* New - apply tax to a payment method fee
* Update - YITH Plugin Framework
* Fix - total amount issues
* Dev - filter yith_wcdppm_gateway_title added 

= 1.1.2 - Released on 21 March 2017 =

* Fix - total amount with Paypal gateway

= 1.1.1 - Released on 17 March 2017 =

* New - support to WooCommerce 3.0.0-RC1
* Update - YITH Plugin Framework

= 1.1.0 - Released on 09 March 2017 =

* New - support to WooCommerce 2.7.0-RC1
* Update - YITH Plugin Framework
* Fix - total amount issues
* Fix - pagination on payment method rules

= 1.0.1 - Released on 20 January 2017 =

* Fix - textdomain.

= 1.0.0 - Released on 18 January 2017 =

* Initial release