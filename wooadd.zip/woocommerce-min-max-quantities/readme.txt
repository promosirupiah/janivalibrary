=== WooCommerce Min Max Quantities ===
Author: WooThemes
Tags: woocommerce
Requires at least: 4.0
Tested up to: 4.1
Requires WooCommerce at least: 2.2
Tested WooCommerce up to: 2.2

Specify minimum and maximum allowed product quantities for orders to be completed.

See http://docs.woothemes.com/document/minmax-quantities/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-min-max-quantities' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

