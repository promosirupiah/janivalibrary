Storefront Checkout Customiser
===================

Adds settings to the customer giving you additional control over the checkout appearance.

### Features

* Distraction free checkout
* Checkout layout selector
* Two step checkout