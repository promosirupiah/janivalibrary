== Changelog ==
= 2.0.8 =
Add a new feature - A quantity box on the archive pages.
Bug fix 

= 2.0.7 =
Add c new feature - Add product Include/Exclude option in cart page condition section
Add a new feature - A quantity box on the archive pages.
Bug Fix

= 2.0.6 =
Add new feature -Price multiply by min quantity
Bug Fix

= 2.0.0 =
new feature added

= 1.9.0 =
When variation changed input value should be updated as per min, max attr

= 1.8.7 =
New version fixed

= 1.8.2 (6/9/2020)=
Some Issue fixed 
Added Variation QTY Control

= 1.7.2 =
 Port or Other theme conflict issue fixed working for wcmmq_set_min_qt_in_shop_loop function

=1.7.1=
wc minmax option hide for grouped product and min max step working for Guteberg Block
Loader function name fixed

= 1.3 (04/14/2019)=
0 Quantity setting

= 1.2 =
Bug Fix

= 1.1 =
Bug Fix

= 1.0 (12/12/2018)=
Initial Released
