(function($){
    'use strict';
    $(document).ready(function(){
        //Admin script will here
    });
})(jQuery);