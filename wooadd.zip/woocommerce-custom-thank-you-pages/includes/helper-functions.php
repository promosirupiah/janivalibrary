<?php
namespace WooCommerce_Custom_Thank_You_Pages;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Check given URL validity.
 *
 * Check if the passed URL is a valid URL. If so return true, false otherwise.
 *
 * @since 1.0.0
 *
 * @param  string $url URL to verify and validate.
 * @return bool        True when the URL is valid, false otherwise.
 */
function is_url( $url ) {

	if ( filter_var( $url, FILTER_VALIDATE_URL ) === false ) {
		return false;
	}

	return true;

}


/**
 * Update excluded pages.
 *
 * Update the pages that should be excluded from the search results.
 * This is generally called when saving a product to update the cached value of the pages.
 *
 * @since NEWVERSION
 *
 * @return void
 */
function update_excluded_thank_you_pages() {
	global $wpdb;

	$pages = $wpdb->get_results( "SELECT DISTINCT(meta_value) from {$wpdb->prefix}postmeta WHERE meta_key='_custom_thank_you_page';", ARRAY_A );
	$pages = wp_list_pluck( $pages, 'meta_value', 'key' );
	$pages = array_map( 'absint', $pages ); // Removes any URLs
	$pages = array_filter( array_combine( $pages, $pages ) );
	update_option( 'wcctyp_pages', $pages );

	do_action( 'WCCTYP/update_excluded_thank_you_pages', $pages );
}
