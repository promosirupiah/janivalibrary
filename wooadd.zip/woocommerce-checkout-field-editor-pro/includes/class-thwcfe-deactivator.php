<?php
/**
 * Fired during plugin deactivation.
 *
 * @link       https://themehigh.com
 * @since      2.9.0
 *
 * @package    woocommerce-checkout-field-editor-pro
 * @subpackage woocommerce-checkout-field-editor-pro/includes
 */
if(!defined('WPINC')){	die; }

if(!class_exists('THWCFE_Deactivator')):

class THWCFE_Deactivator {

	/**
	 *
	 * @since    2.3.0
	 */
	public static function deactivate() {

	}

}

endif;