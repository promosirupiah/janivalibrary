<?php return array('dependencies' => array(), 'version' => 'e1318ac32f88f56757de');
