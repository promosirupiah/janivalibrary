<?php

namespace WPAdminify\Inc\Modules\AdminPages;

use WPAdminify\Inc\Base_Model;

abstract class AdminPagesModel extends Base_Model {

	protected $prefix = '_wp_adminify_';
}
