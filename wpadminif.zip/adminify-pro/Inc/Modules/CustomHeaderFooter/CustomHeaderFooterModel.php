<?php

namespace WPAdminify\Inc\Modules\CustomHeaderFooter;

use WPAdminify\Inc\Base_Model;

abstract class CustomHeaderFooterModel extends Base_Model {

	protected $prefix = '_wpadminify_custom_js_css';
}
