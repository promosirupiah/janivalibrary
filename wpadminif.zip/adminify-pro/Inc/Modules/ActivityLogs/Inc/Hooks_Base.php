<?php

namespace WPAdminify\Inc\Modules\ActivityLogs\Inc;

// no direct access allowed
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Hook_Base
 *
 * @author Jewel Theme <support@jeweltheme.com>
 */
abstract class Hooks_Base {

	public function __construct() {
	}
}
