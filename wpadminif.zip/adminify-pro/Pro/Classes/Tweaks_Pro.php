<?php

namespace WPAdminify\Pro\Classes;

use WPAdminify\Inc\Classes\Tweaks;
// no direct access allowed
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @module Tweaks
 * @package WP Adminify
 *
 * @author WP Adminify <support@wpadminify.com>
 */

class Tweaks_Pro {

}
