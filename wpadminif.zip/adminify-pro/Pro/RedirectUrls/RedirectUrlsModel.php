<?php

namespace WPAdminify\Pro\RedirectUrls;

use WPAdminify\Inc\Base_Model;

abstract class RedirectUrlsModel extends Base_Model {

	protected $prefix = '_wpadminify_redirect_urls';
}
