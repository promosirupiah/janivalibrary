<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/web?v=1.0&rsz=4&key='.$google_web_api.'&q=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $value) 
{ ?>
<div class="post">
<?php echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($value->titleNoFormatting)).'">'.CleanFileNameBan($value->titleNoFormatting).'</a></h2>'; ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode($value->titleNoFormatting); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($content->titleNoFormatting));?>"><img alt="<?php echo CleanFileNameBan($content->titleNoFormatting) ?>"src="<?php echo $content->unescapedUrl; ?>"></a>

<?php } ?>
<br style="clear:both">
<?php echo $value->content; ?>
<br style="clear:both">
<a rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$value->url ?>">read more</a>
</div>
<?php } ?> 


