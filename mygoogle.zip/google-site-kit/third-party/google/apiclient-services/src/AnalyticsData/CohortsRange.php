<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace Google\Site_Kit_Dependencies\Google\Service\AnalyticsData;

class CohortsRange extends \Google\Site_Kit_Dependencies\Google\Model
{
    /**
     * @var int
     */
    public $endOffset;
    /**
     * @var string
     */
    public $granularity;
    /**
     * @var int
     */
    public $startOffset;
    /**
     * @param int
     */
    public function setEndOffset($endOffset)
    {
        $this->endOffset = $endOffset;
    }
    /**
     * @return int
     */
    public function getEndOffset()
    {
        return $this->endOffset;
    }
    /**
     * @param string
     */
    public function setGranularity($granularity)
    {
        $this->granularity = $granularity;
    }
    /**
     * @return string
     */
    public function getGranularity()
    {
        return $this->granularity;
    }
    /**
     * @param int
     */
    public function setStartOffset($startOffset)
    {
        $this->startOffset = $startOffset;
    }
    /**
     * @return int
     */
    public function getStartOffset()
    {
        return $this->startOffset;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(\Google\Site_Kit_Dependencies\Google\Service\AnalyticsData\CohortsRange::class, 'Google\\Site_Kit_Dependencies\\Google_Service_AnalyticsData_CohortsRange');
