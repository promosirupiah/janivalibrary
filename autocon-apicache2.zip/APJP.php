<?php
/*
APJP, A PHP/JAVA PROXY
Copyright (C) 2009 Jeroen Van Steirteghem

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

// INPUT

$handle1 = null;
$handle1 = fopen('php://input', 'r');

if($handle1)
{
	stream_filter_prepend($handle1, 'convert.base64-decode', STREAM_FILTER_READ);
	stream_filter_prepend($handle1, 'string.rot13', STREAM_FILTER_READ);
	
	$buffer1 = '';
	$buffer2 = '';
	
	while($buffer1 = fgets($handle1))
	{
		$buffer2 = $buffer2.$buffer1;
		
		if(!chop($buffer1))
		{
			break;
		}
	}
	
	$handle2 = null;
	
	if(preg_match('/\r\nHost: ([0-9a-z\.\-]+)(?:\:([0-9]+))?\r\n/i', $buffer2, $matches) != 0) 
	{
		if(preg_match('/^[A-Z]+ http:\/\//i', $buffer2) != 0)
		{
			if(count($matches) == 2)
			{
				$handle2 = fsockopen($matches[1], 80);
			}
			else
			{
				$handle2 = fsockopen($matches[1], $matches[2]);
			}
		}
		else
		{
			if(count($matches) == 2)
			{
				$handle2 = fsockopen('ssl://'.$matches[1], 443);
			}
			else
			{
				$handle2 = fsockopen('ssl://'.$matches[1], $matches[2]);
			}
		}
	}
	
	if($handle2)
	{
		$buffer2 = preg_replace('/^([A-Z]+) https?:\/\/[^\/]+\//i', '$1 /', $buffer2);
		$buffer2 = preg_replace('/HTTP\/1\.1\r\n/i', 'HTTP/1.0'."\r\n", $buffer2);
		$buffer2 = preg_replace('/\r\nConnection: [^\r\n]+\r\n/i', "\r\n", $buffer2);
		$buffer2 = preg_replace('/\r\nProxy-Connection: [^\r\n]+\r\n/i', "\r\n", $buffer2);
		$buffer2 = preg_replace('/\r\nProxy-Authorization: [^\r\n]+\r\n/i', "\r\n", $buffer2);
		$buffer2 = preg_replace('/\r\nTE: [^\r\n]+\r\n/i', "\r\n", $buffer2);
		$buffer2 = preg_replace('/\r\nKeep-Alive: [^\r\n]+\r\n/i', "\r\n", $buffer2);
		$buffer2 = preg_replace('/\r\n\r\n/i', "\r\n".'Connection: close'."\r\n\r\n", $buffer2);
		
		fwrite($handle2, $buffer2);
		
		$buffer1 = '';
		$buffer2 = '';
		
		while($buffer1 = fread($handle1, 5120))
		{
			fwrite($handle2, $buffer1);
		}
		
		// OUTPUT
		
		$handle3 = null;
		$handle3 = fopen('php://output', 'w');
		
		if($handle3)
		{
		
			stream_filter_append($handle3, 'convert.base64-encode', STREAM_FILTER_WRITE);
			stream_filter_append($handle3, 'string.rot13', STREAM_FILTER_WRITE);
			
			$buffer1 = '';
			$buffer2 = '';
			
			while($buffer1 = fread($handle2, 5120))
			{
				fwrite($handle3, $buffer1);
			}
			
			fclose($handle3);
		}
		
		fclose($handle2);
	}
	
	fclose($handle1);
}
?>