<?php
$termstring = ubah_tanda(CleanFileNameBan(str_replace(array('?utm_source=twitterfeed&utm_medium=statusnet','?utm_source=twitterfeed&utm_medium=twitter'),'',$_SERVER["REQUEST_URI"])));
$termstring = str_replace(array("-","--","---","----")," ",$termstring);
$displaytitle = $termstring;

?>
<?php
function pete_curl_get($url, $params){$post_params = array();
foreach ($params as $key => &$val) {
if (is_array($val)) $val = implode(',', $val);
$post_params[] = $key.'='.urlencode($val);
}
$post_string = implode('&', $post_params);
$fullurl = $url."?".$post_string;
$ch = curl_init();curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);curl_setopt($ch, CURLOPT_URL, $fullurl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7) Gecko/20040608'); //choose user agent, see www.user-agents.org
$result = curl_exec($ch);curl_close($ch);
return $result;
}

 ?>
 <?php if (($_SERVER["REQUEST_URI"]) !='/'){ //rss generated for title from blogsearch.google.com ?>
<link rel="alternate" type="application/rss+xml" title="<?php echo $termstring ?>" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/feedmask.php?http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).'&ie=utf-8&num=20&output=rss' ?>" />
<?php } ?>
<title><?php echo $displaytitle .'|'.$main_title; ?></title>

</head>
<body>
<div id="header">
<h1 style="clear:both"><a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"];?>"><?php echo $main_title ?></a></h1>
</div>
<div id="content">

<?php 

if (($_SERVER["REQUEST_URI"]) =='/'){
include ('./blogsearch.php');//for frontpage
}
else if (in_array(str_replace('/','',$_SERVER["REQUEST_URI"]), $categories)) {
include ('./catblogsearch.php'); //for categories
}
else {
include ('./bing.php'); //for all uri
include ('./google.php');
}
 ?>
</div> <?php //end of div content ?>



