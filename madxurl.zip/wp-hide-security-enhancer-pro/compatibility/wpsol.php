<?php

    if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
    
    /**
    * Compatibility for Plugin Name: WP Speed of Light
    * Compatibility checked on Version: 2.6.3
    */

    class WPH_conflict_handle_wpsol
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active() )
                        return FALSE;
                    
                    add_filter( 'wpsol_minify_content_return',      array( 'WPH_conflict_handle_wpsol', 'wpsol_minify_content_return'), 999 );       
           
                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if(is_plugin_active( 'wp-speed-of-light/wp-speed-of-light.php' ))
                        return TRUE;
                        else
                        return FALSE;
                }
                
                
            static function wpsol_minify_content_return( $buffer )
                {
                                            
                    global $wph;
                    
                    $buffer =   $wph->ob_start_callback( $buffer );
                    
                    return $buffer;
                    
                }                            
        }

    WPH_conflict_handle_wpsol::init();
?>