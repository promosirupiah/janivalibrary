<?php


    class WPH_conflict_handle_wp_rocket
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active() )
                        return FALSE;
                    
                    add_filter( 'rocket_buffer',                    array( 'WPH_conflict_handle_wp_rocket', 'rocket_buffer'), 999 );       
                    
                    add_filter( 'rocket_js_url',                    array( 'WPH_conflict_handle_wp_rocket', 'rocket_js_url'), 999 );
                    add_filter( 'rocket_css_content',                array( 'WPH_conflict_handle_wp_rocket', 'rocket_css_content'), 999 );             
                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if(is_plugin_active( 'wp-rocket/wp-rocket.php' ))
                        return TRUE;
                        else
                        return FALSE;
                }
                
                
            static function rocket_buffer( $buffer )
                {
                                            
                    global $wph;
                    
                    $buffer =   $wph->ob_start_callback( $buffer );
                    
                    return $buffer;
                    
                }
                
                
                        /**
            * Replace static inline cached file urls
            *     
            * @param mixed $url
            */
            static function rocket_js_url( $content )
                {
                    global $wph;
                    
                    //retrieve the replacements list
                    $replacement_list   =   $wph->functions->get_replacement_list();
                                            
                    //replace the urls
                    $content =   $wph->functions->content_urls_replacement($content,  $replacement_list );   
                    
                    return $content ;   
                }
            
            
            
            static public function rocket_css_content( $content )
                {
                    global $wph;
                    
                    //retrieve the replacements list
                    $replacement_list   =   $wph->functions->get_replacement_list();
                                            
                    //replace the urls
                    $content =   $wph->functions->content_urls_replacement( $content,  $replacement_list );   
                    
                    return $content;   
                }

                            
        }


?>