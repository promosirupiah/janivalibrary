<?php

/**
* Compatibility for Plugin Name: JS Composer
* Compatibility checked on Version: 2.5.16
*/
    
    class WPH_conflict_js_composer
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active())
                        return FALSE;
                    
                    global $wph;
                    
                    if ( isset( $_GET['vc_editable'] ) )
                        {
                            add_filter ('wph/components/css_combine_code', '__return_false');
                            add_filter ('wph/components/_init/', array( 'WPH_conflict_js_composer',    'wph_components_init'), 999, 2 );
                        }
                        
                        
                    if ( isset( $_POST['action'] )  &&  $_POST['action']    ==  'vc_edit_form' )
                        {
                            add_filter ('wph/components/css_combine_code', '__return_false');
                            add_filter ('wph/components/js_combine_code', '__return_false');
                            
                            add_filter ('wph/components/_init/', array( 'WPH_conflict_js_composer',    'wph_components_init'), 999, 2 );
                        }
                                        
                    add_filter( 'wph/components/components_run/ignore_field_id', array( 'WPH_conflict_js_composer',    'ignore_field_id'), 999, 3 );

                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if(is_plugin_active( 'js_composer/js_composer.php' ))
                        return TRUE;
                        else
                        return FALSE;
                }
                
            
            static function ignore_field_id( $ignore_field, $field_id, $saved_field_value )
                {
                    
                    if  ( in_array( $field_id, array( 'js_combine_code', 'css_combine_code' ) ) )
                        {
                            if  (  isset( $_GET['vc_editable'] )    &&  isset( $_GET['vc_post_id'] ) )
                                {
                                    $ignore_field   =   TRUE;
                                }
                            
                        }
                    
                    return $ignore_field;
                    
                }
                
                
            static function wph_components_init( $status, $component )
                {
                    if ( $component ==  'rewrite_default' )
                        return FALSE;
                        
                        
                    return $status;
                    
                }
    
        }
        
        
    WPH_conflict_js_composer::init();


?>