<?php

/**
* Compatibility for Plugin Name: YITH WooCommerce Multi Vendor Premium
* Compatibility checked on Version: 3.4.0
*/

    class WPH_conflict_handle_yith_wmvp
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active() )
                        return FALSE;
                    
                    if ( count ( $_POST ) < 1 )
                        return;
                        
                    if ( ! isset($_POST['update_vendor_id'])) 
                        return;
                        
                    if ( ! isset($_POST['action'])   ||  strpos( $_POST['action'], '_admin_save_fields') ===  FALSE ) 
                        return;
                    
                    add_filter( 'wph/components/force_run_on_admin',  '__return_true' );
                    
                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if( is_plugin_active( 'yith-woocommerce-multi-vendor-premium/init.php' ) )
                        return TRUE;
                        else
                        return FALSE;
                }
                       
            static function smush_filter_generate_cdn_url( $src )
                {
                                            
                    global $wph;
                    
                    $src    =   $wph->functions->content_urls_replacement( $src,  $wph->functions->get_replacement_list() );
                       
                    return $src; 
                    
                }

           
        }
        
        
    WPH_conflict_handle_yith_wmvp::init();


?>