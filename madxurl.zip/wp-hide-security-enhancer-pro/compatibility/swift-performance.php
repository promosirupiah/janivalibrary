<?php

/**
* Compatibility for Plugin Name: Swift Performance
* Compatibility checked on Version: 
*/

    class WPH_conflict_handle_swift_performance
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active())
                        return FALSE;
                        
                    add_filter( 'swift_performance_buffer', array( 'WPH_conflict_handle_swift_performance' , 'swift_performance_buffer' ), 99 );   
                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if(is_plugin_active( 'swift-performance/performance.php' ))
                        return TRUE;
                        else
                        return FALSE;
                }
            
            static function swift_performance_buffer( $buffer )
                {                    
                    global $wph;
                    
                    $buffer =   $wph->ob_start_callback( $buffer );                    
                                        
                    return $buffer;
                        
                }
   
        }
        
    WPH_conflict_handle_swift_performance::init();


?>