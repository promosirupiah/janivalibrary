<?php


    class WPH_conflict_handle_wpml
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active())
                        return FALSE;
                                            
                    add_action('plugins_loaded',        array('WPH_conflict_handle_wpml', '_normalize_replacement_urls') , 0 );
                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if(is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ))
                        return TRUE;
                        else
                        return FALSE;
                }

                          
            
            /**
            * adjust the replacements
            *     
            */
            static function _normalize_replacement_urls()
                {
                    global $sitepress, $wph;
                    
                    if (!$sitepress) 
                        return;
                    
                    $current_lang       = apply_filters( 'wpml_current_language', NULL );
                    $default_lang       = apply_filters('wpml_default_language', NULL );
                    $domain_per_lang    = $sitepress->get_setting( 'language_negotiation_type' ) == WPML_LANGUAGE_NEGOTIATION_TYPE_DOMAIN ? true : false;
                    if ($current_lang == $default_lang || $domain_per_lang)
                        return;
                    
                    if ( $sitepress->get_setting( 'language_negotiation_type' ) == WPML_LANGUAGE_NEGOTIATION_TYPE_PARAMETER )
                        {
                            $default_home_url   =   $sitepress->convert_url( $sitepress->get_wp_api()->get_home_url(), $default_lang );
                            $default_home_url   =   str_replace( array ( 'https:', 'http:' ), '', $default_home_url );
                            
                            $home_url   =    home_url();
                            $home_url   =   str_replace( array ( 'https:', 'http:' ), '', $home_url );
                            
                            if  ( $home_url ==  $default_home_url ) 
                                return;
                                
                            foreach ( $wph->urls_replacement  as  $priority   =>  $list )
                                {
                                    if ( count ( $list ) > 0 )
                                        {
                                            foreach ( $list as  $replaced   =>  $replacement )
                                                {
                                                    $_replacement   =   str_replace( trailingslashit ( $home_url ) , trailingslashit ( $default_home_url ) ,  $replacement );
                                                    if ( $_replacement != $replacement )
                                                        $wph->urls_replacement[$priority][$replaced]  =   $_replacement;
                                                }
                                        }
                                }   
                        }
                        else
                        {
                            $default_home_url   =   $sitepress->convert_url( $sitepress->get_wp_api()->get_home_url(), $default_lang );
                            $default_home_url   =   str_replace( array ( 'https:', 'http:' ), '', $default_home_url );
                            
                            foreach ( $wph->urls_replacement  as  $priority   =>  $list )
                                {
                                    if ( count ( $list ) > 0 )
                                        {
                                            foreach ( $list as  $replaced   =>  $replacement )
                                                {
                                                    $_replacement   =   str_replace( trailingslashit ( $default_home_url ) . $current_lang  .'/' , trailingslashit ( $default_home_url )    ,  $replacement );
                                                    if ( $_replacement != $replacement )
                                                        $wph->urls_replacement[$priority][$replaced]  =   $_replacement;
                                                }
                                        }
                                }
                        }
                    
                }
  
                            
        }
        
        
        
?>