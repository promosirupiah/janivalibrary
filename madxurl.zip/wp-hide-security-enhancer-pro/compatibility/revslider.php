<?php

    /**
    * Plugin Compatibility      :   Slider Revolution
    * Introduced at version     :   6.1.2
    */


    class WPH_conflict_handle_revslider
        {
                        
            static function init()
                {
                    if( !   self::is_plugin_active())
                        return FALSE;
                                        
                    
                    add_filter( 'wp-hide/module/general_css_variables_replace/placeholder_ignore_css', array( 'WPH_conflict_handle_revslider' , 'placeholder_ignore_css' ),  10, 3 );
                    
                }                        
            
            static function is_plugin_active()
                {
                    
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                    
                    if(is_plugin_active( 'revslider/revslider.php' ))
                        return TRUE;
                        else
                        return FALSE;
                }
                
                
            static function placeholder_ignore_css ( $ignore_status, $element_content, $element_href )
                {
                    
                    if  ( empty ( $element_content ) )
                        return $ignore_status;
                    
                    if ( preg_match( "/id\='rs\-plugin\-settings\-inline\-css'/i" , $element_content))   
                        $ignore_status  =   TRUE;
                        
                    return $ignore_status;
                       
                }
            
                            
        }
        
        
        
    WPH_conflict_handle_revslider::init();


?>