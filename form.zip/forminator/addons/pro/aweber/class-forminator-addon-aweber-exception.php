<?php

/**
 * Class Forminator_Addon_Aweber_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Aweber Addon
 */
class Forminator_Addon_Aweber_Exception extends Exception {

}