=== Autocomplete Google Address ===
Contributors: nishathbd31
Donate link: https://www.facebook.com/nishat.rafi.60
Tags: Autocomplete,Google Address Autocomplete,Autocomplete Google Address,Address Autocomplete
Requires at least: 5.0
Tested up to: 6.1.1
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin will help you to use Place Autocomplete API key.

== Description ==

This plugin will help you to use Place Autocomplete API key to enable address auto-completion to any text input fields.You just need to fill the text input ID. You can add multiple input by using " , ".
[youtube https://www.youtube.com/watch?v=j9sKJJhtULM]

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)



== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)

== Frequently Asked Questions ==

= Can i use multiple text ID? =

Yes,you can use by separating comma.

= Is this a paid plugin? =

No, It's totally free. No paid version is available.


== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif).
2. This is the second screen shot

== Upgrade Notice ==
= 1.9.3=
version compatablity 
== Changelog ==
= 1.9.2=
multiple autocomplete issue solved.
= 1.9.1=
Missing address solved (Ninja Form,Gravity form and all froms)


== Upgrade Notice ==
= 1.9.1=
tested with wp 6.1.1 nothing changed

= 1.9.1=
jquery bug fixed you will not lose any data after update
= 1.8 =
jQuery On load function updated to support latest jQuery version
== Upgrade Notice ==
= 1.9 =
WordPress 5.7 version compatibility