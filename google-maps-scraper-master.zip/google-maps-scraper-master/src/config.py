queries = [
    {
        "keyword": "kecantikan semarang",
        "max_results" : 1000
    },
   
]

number_of_scrapers = 1