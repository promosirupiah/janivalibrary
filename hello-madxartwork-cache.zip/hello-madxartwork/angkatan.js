jQuery(document).ready(function($){
   // Global click listener untuk menutup dropdown suggestion
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.madx_suggestions, .angkatan').length) {
            $('.madx_suggestions').remove();
        }
    });

    // Helper: Convert input text ke select dropdown (untuk mode edit)
    function convertToSelect($input, initialValue, placeholder) {
        if ($input.is('input:text') && initialValue) {
            var $select = $('<select></select>');
            $select.attr('name', $input.attr('name'));
            $select.attr('class', $input.attr('class'));
            $select.html('<option value="">' + placeholder + '</option>');
            $input.replaceWith($select);
            return $select;
        }
        return $input;
    }

    // Helper: Menampilkan dropdown suggestion
    function showSuggestions($input, items, $suggestionRef, onSelect, displayField = 'name') {
        if ($suggestionRef.current) $suggestionRef.current.remove();
        
        var $list = $('<div class="madx_suggestions"></div>');
        $list.css({
            'position': 'absolute',
            'background': '#fff',
            'border': '1px solid #ccc',
            'z-index': 9999,
            'max-height': '150px',
            'overflow-y': 'auto',
            'width': $input.outerWidth() + 'px',
            'box-sizing': 'border-box',
            'box-shadow': '0 4px 6px rgba(0,0,0,0.1)'
        });
        
        if (items.length === 0) {
            $list.append('<p style="margin:0; padding:8px; color:#999;">Tidak ada hasil</p>');
        } else {
            $.each(items, function(i, item) {
                var displayText = item[displayField];
                if (item.code && displayField !== 'code') {
                    displayText = item.code + ' - ' + item.locality_name;
                }
                
                var $p = $('<p></p>').text(displayText).css({
                    'margin': '0', 
                    'padding': '8px', 
                    'cursor': 'pointer',
                    'border-bottom': '1px solid #eee'
                });
                $p.hover(
                    function(){ $(this).css('background', '#f0f0f0'); }, 
                    function(){ $(this).css('background', '#fff'); }
                );
                $p.on('click', function() {
                    onSelect(item);
                    $list.remove();
                    $suggestionRef.current = null;
                });
                $list.append($p);
            });
        }
        
        var offset = $input.offset();
        $list.css({
            'top': (offset.top + $input.outerHeight()) + 'px',
            'left': offset.left + 'px'
        });
        
        $('body').append($list);
        $suggestionRef.current = $list;
    }

    function hideSuggestions($suggestionRef) {
        if ($suggestionRef.current) {
            $suggestionRef.current.remove();
            $suggestionRef.current = null;
        }
    }

    function showWarning($input, $suggestionRef, message) {
        if ($suggestionRef.current) $suggestionRef.current.remove();
        var $list = $('<div class="madx_suggestions"></div>').css({
            'position': 'absolute', 'background': '#fff', 'border': '1px solid #ccc', 
            'z-index': 9999, 'width': $input.outerWidth() + 'px', 'box-sizing': 'border-box'
        });
        $list.append('<p style="margin:0; padding:8px; color:#999;">' + message + '</p>');
        var offset = $input.offset();
        $list.css({ 'top': (offset.top + $input.outerHeight()) + 'px', 'left': offset.left + 'px' });
        $('body').append($list);
        $suggestionRef.current = $list;
    }
 

   

    // Looping untuk setiap form
    $('form').each(function(){
        var $form = $(this);     
        var $angkatanField = $form.find('.angkatan');    
        if(!$angkatanField.length) return; 
        
        // Simpan value awal (untuk mode edit)
        var initialangkatanValue = $angkatanField.val() || '1996';

  //      var initialPostcodeValue = $postcodeField.val() || '';
        
        // Deteksi mode: jika ada value awal, convert ke select (mode edit)
        var isEditMode = (initialangkatanValue);
        
        if (isEditMode) {
            $angkatanField = convertToSelect($angkatanField, initialangkatanValue, 'Pilih Angkatan');

        }
        
        // Deteksi tipe input setelah konversi
        var isangkatanText = $angkatanField.is('input:text');

 //       var isPostcodeText = $postcodeField.is('input:text');

        // Variabel status
        var selectedangkatanCode = isEditMode ? initialangkatanValue : '';
     
        var ajaxangkatan = false;

        var angkatanSuggestionRef = { current: null };


        // INISIALISASI - Load data untuk mode edit
        if (isEditMode) {
            madx_gff_fetch_angkatan();
        } else {
            if (!isangkatanText) madx_gff_fetch_angkatan();

        }

        // EVENT LISTENER - Angkatan
        if (isangkatanText) {
            $angkatanField.on('keyup', function() {
                var val = $(this).val();
                if (val.length >= 1) madx_gff_fetch_angkatan(val);
                else hideSuggestions(angkatanSuggestionRef);
            }).on('focus', function() {
                if ($(this).val().length >= 1) madx_gff_fetch_angkatan($(this).val());
            });
        } else {
            $angkatanField.on('change', function() {
                selectedangkatanCode = $(this).val();
            });
        }
  
        // FUNGSI AJAX - ANGKATAN
        function madx_gff_fetch_angkatan(angkatanInput = ''){
            if(ajaxangkatan) return;
            var data = { 'action': 'madx_gff_fetch_angkatan' };
            if(angkatanInput != '') data['madxname'] = angkatanInput;
            
            ajaxangkatan = true;
            $.ajax({
                url: '/madxajax/angkatan/',
                type: "GET",
                data: data,
                success: function(response){
                    try {
                        var angkatan = JSON.parse(response);
                        if (isangkatanText) {
                            showSuggestions($angkatanField, angkatan, angkatanSuggestionRef, function(item) {
                                $angkatanField.val(item.name);
                                selectedangkatanCode = item.name;
 
                            });
                        } else {
                            var html = "<option value=''>Pilih Angkatan</option>";
                            $.each(angkatan, function(i, item) {
                                var selected = (item.name == selectedangkatanCode) ? 'selected' : '';
                                html += '<option value="'+item.name+'" '+selected+'>'+item.name+'</option>';
                            });
                            $angkatanField.html(html);
                            

                        }
                    } catch(e) { console.error('Error parsing angkatan:', response); }
                    ajaxangkatan = false;
                },
                error: function(xhr, status, error){ console.error('Error fetching angkatan:', error); ajaxangkatan = false; }
            });
        }


  
    }); //form each
}); //document ready
