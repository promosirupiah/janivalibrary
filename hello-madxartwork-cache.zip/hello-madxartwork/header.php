<?php
/**
 * The template for displaying the header
 *
 * This is the template that displays all of the <head> section, opens the <body> tag and adds the site's header.
 *
 * @package Hellomadxartwork
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<?php $viewport_content = apply_filters( 'hello_madxartwork_viewport_content', 'width=device-width, initial-scale=1' ); ?>
	<meta name="viewport" content="<?php echo esc_attr( $viewport_content ); ?>">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php handleAdvancedCacheFunc(function(){
	wp_head(); 
	}, 'wphead', 'madxcache/'.$_SERVER['SERVER_NAME'], true, true, -1); ?>
</head>
<body <?php body_class(); ?>>

<?php hello_madxartwork_body_open();

handleAdvancedCacheFunc(function(){
//start cache
if ( ! function_exists( 'madxartwork_theme_do_location' ) || ! madxartwork_theme_do_location( 'header' ) ) {
	if ( did_action( 'madxartwork/loaded' ) && hello_header_footer_experiment_active() ) {
		get_template_part( 'template-parts/dynamic-header' );
	} else {
		get_template_part( 'template-parts/header' );
	}
}
//end cache
}, 'header', 'madxcache/'.$_SERVER['SERVER_NAME'], false, true, -1);