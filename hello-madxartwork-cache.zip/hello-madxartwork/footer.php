<?php
/**
 * The template for displaying the footer.
 *
 * Contains the body & html closing tags.
 *
 * @package Hellomadxartwork
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
handleAdvancedCacheFunc(function(){
if ( ! function_exists( 'madxartwork_theme_do_location' ) || ! madxartwork_theme_do_location( 'footer' ) ) {
	if ( did_action( 'madxartwork/loaded' ) && hello_header_footer_experiment_active() ) {
		get_template_part( 'template-parts/dynamic-footer' );
	} else {
		get_template_part( 'template-parts/footer' );
	}
}
}, 'footer', 'madxcache/'.$_SERVER['SERVER_NAME'], false, false, -1);
?>

<?php 
handleAdvancedCacheFunc(function(){wp_footer(); }, 'wpfooter','madxcache/'.$_SERVER['SERVER_NAME'], true, true, -1);
?>

</body>
</html>
