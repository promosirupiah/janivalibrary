<?php
/**
 * Theme functions and definitions
 *
 * @package Hellomadxartwork
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'HELLO_madxartwork_VERSION', '2.4.1' );

if ( ! isset( $content_width ) ) {
	$content_width = 800; // Pixels.
}

if ( ! function_exists( 'hello_madxartwork_setup' ) ) {
	/**
	 * Set up theme support.
	 *
	 * @return void
	 */
	function hello_madxartwork_setup() {
		if ( is_admin() ) {
			hello_maybe_update_theme_version_in_db();
		}

		$hook_result = apply_filters_deprecated( 'madxartwork_hello_theme_load_textdomain', [ true ], '2.0', 'hello_madxartwork_load_textdomain' );
		if ( apply_filters( 'hello_madxartwork_load_textdomain', $hook_result ) ) {
			load_theme_textdomain( 'hello-madxartwork', get_template_directory() . '/languages' );
		}

		$hook_result = apply_filters_deprecated( 'madxartwork_hello_theme_register_menus', [ true ], '2.0', 'hello_madxartwork_register_menus' );
		if ( apply_filters( 'hello_madxartwork_register_menus', $hook_result ) ) {
			register_nav_menus( [ 'menu-1' => __( 'Header', 'hello-madxartwork' ) ] );
			register_nav_menus( [ 'menu-2' => __( 'Footer', 'hello-madxartwork' ) ] );
		}

		$hook_result = apply_filters_deprecated( 'madxartwork_hello_theme_add_theme_support', [ true ], '2.0', 'hello_madxartwork_add_theme_support' );
		if ( apply_filters( 'hello_madxartwork_add_theme_support', $hook_result ) ) {
			add_theme_support( 'post-thumbnails' );
			add_theme_support( 'automatic-feed-links' );
			add_theme_support( 'title-tag' );
			add_theme_support(
				'html5',
				[
					'search-form',
					'comment-form',
					'comment-list',
					'gallery',
					'caption',
				]
			);
			add_theme_support(
				'custom-logo',
				[
					'height'      => 100,
					'width'       => 350,
					'flex-height' => true,
					'flex-width'  => true,
				]
			);

			/*
			 * Editor Style.
			 */
			add_editor_style( 'classic-editor.css' );

			/*
			 * Gutenberg wide images.
			 */
			add_theme_support( 'align-wide' );

			/*
			 * WooCommerce.
			 */
			$hook_result = apply_filters_deprecated( 'madxartwork_hello_theme_add_woocommerce_support', [ true ], '2.0', 'hello_madxartwork_add_woocommerce_support' );
			if ( apply_filters( 'hello_madxartwork_add_woocommerce_support', $hook_result ) ) {
				// WooCommerce in general.
				add_theme_support( 'woocommerce' );
				// Enabling WooCommerce product gallery features (are off by default since WC 3.0.0).
				// zoom.
				add_theme_support( 'wc-product-gallery-zoom' );
				// lightbox.
				add_theme_support( 'wc-product-gallery-lightbox' );
				// swipe.
				add_theme_support( 'wc-product-gallery-slider' );
			}
		}
	}
}
add_action( 'after_setup_theme', 'hello_madxartwork_setup' );

function hello_maybe_update_theme_version_in_db() {
	$theme_version_option_name = 'hello_theme_version';
	// The theme version saved in the database.
	$hello_theme_db_version = get_option( $theme_version_option_name );

	// If the 'hello_theme_version' option does not exist in the DB, or the version needs to be updated, do the update.
	if ( ! $hello_theme_db_version || version_compare( $hello_theme_db_version, HELLO_madxartwork_VERSION, '<' ) ) {
		update_option( $theme_version_option_name, HELLO_madxartwork_VERSION );
	}
}

if ( ! function_exists( 'hello_madxartwork_scripts_styles' ) ) {
	/**
	 * Theme Scripts & Styles.
	 *
	 * @return void
	 */
	function hello_madxartwork_scripts_styles() {
		$enqueue_basic_style = apply_filters_deprecated( 'madxartwork_hello_theme_enqueue_style', [ true ], '2.0', 'hello_madxartwork_enqueue_style' );
		$min_suffix          = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		if ( apply_filters( 'hello_madxartwork_enqueue_style', $enqueue_basic_style ) ) {
			wp_enqueue_style(
				'hello-madxartwork',
				get_template_directory_uri() . '/style' . $min_suffix . '.css',
				[],
				HELLO_madxartwork_VERSION
			);
		}

		if ( apply_filters( 'hello_madxartwork_enqueue_theme_style', true ) ) {
			wp_enqueue_style(
				'hello-madxartwork-theme-style',
				get_template_directory_uri() . '/theme' . $min_suffix . '.css',
				[],
				HELLO_madxartwork_VERSION
			);
		}
	}
}
add_action( 'wp_enqueue_scripts', 'hello_madxartwork_scripts_styles' );

if ( ! function_exists( 'hello_madxartwork_register_madxartwork_locations' ) ) {
	/**
	 * Register madxartwork Locations.
	 *
	 * @param madxartworkPro\Modules\ThemeBuilder\Classes\Locations_Manager $madxartwork_theme_manager theme manager.
	 *
	 * @return void
	 */
	function hello_madxartwork_register_madxartwork_locations( $madxartwork_theme_manager ) {
		$hook_result = apply_filters_deprecated( 'madxartwork_hello_theme_register_madxartwork_locations', [ true ], '2.0', 'hello_madxartwork_register_madxartwork_locations' );
		if ( apply_filters( 'hello_madxartwork_register_madxartwork_locations', $hook_result ) ) {
			$madxartwork_theme_manager->register_all_core_location();
		}
	}
}
add_action( 'madxartwork/theme/register_locations', 'hello_madxartwork_register_madxartwork_locations' );

if ( ! function_exists( 'hello_madxartwork_content_width' ) ) {
	/**
	 * Set default content width.
	 *
	 * @return void
	 */
	function hello_madxartwork_content_width() {
		$GLOBALS['content_width'] = apply_filters( 'hello_madxartwork_content_width', 800 );
	}
}
add_action( 'after_setup_theme', 'hello_madxartwork_content_width', 0 );

if ( is_admin() ) {
	require get_template_directory() . '/includes/admin-functions.php';
}

/**
 * If madxartwork is installed and active, we can load the madxartwork-specific Settings & Features
*/

// Allow active/inactive via the Experiments
require get_template_directory() . '/includes/madxartwork-functions.php';

/**
 * Include customizer registration functions
*/
function hello_register_customizer_functions() {
	if ( hello_header_footer_experiment_active() && is_customize_preview() ) {
		require get_template_directory() . '/includes/customizer-functions.php';
	}
}
add_action( 'init', 'hello_register_customizer_functions' );

if ( ! function_exists( 'hello_madxartwork_check_hide_title' ) ) {
	/**
	 * Check hide title.
	 *
	 * @param bool $val default value.
	 *
	 * @return bool
	 */
	function hello_madxartwork_check_hide_title( $val ) {
		if ( defined( 'madxartwork_VERSION' ) ) {
			$current_doc = madxartwork\Plugin::instance()->documents->get( get_the_ID() );
			if ( $current_doc && 'yes' === $current_doc->get_settings( 'hide_title' ) ) {
				$val = false;
			}
		}
		return $val;
	}
}
add_filter( 'hello_madxartwork_page_title', 'hello_madxartwork_check_hide_title' );

/**
 * Wrapper function to deal with backwards compatibility.
 */
if ( ! function_exists( 'hello_madxartwork_body_open' ) ) {
	function hello_madxartwork_body_open() {
		if ( function_exists( 'wp_body_open' ) ) {
			wp_body_open();
		} else {
			do_action( 'wp_body_open' );
		}
	}
}


//cache custom
function is_uri_excluded($current_uri_path, $exclude_uris) {
    if (empty($exclude_uris) || !is_array($exclude_uris)) {
        return false;
    }

    foreach ($exclude_uris as $pattern) {
        $pattern = trim($pattern);
        if (empty($pattern)) continue;

        // Ubah pola wildcard menjadi regex
        // Contoh: /member/* -> ^\/member\/.*$
        $regex = '/^' . str_replace('\*', '.*', preg_quote($pattern, '/')) . '$/i';

        if (preg_match($regex, $current_uri_path)) {
            return true;
        }
    }
    return false;
}

/**
* 1. FUNGSI UTAMA (Versi Fungsi PHP)
* 
* @param callable $dosemething   Fungsi anonim berisi konten/HTML murni
* @param string   $name          Nama unik grup cache
* @param string   $folder        Nama induk folder di dalam /wp-content/cache/
* @param bool     $use_uri       Apakah cache dipisah per alamat URL halaman
* @param bool     $use_role      Apakah cache dipisah berdasarkan role user
* @param int      $ttl           Masa berlaku cache dalam detik (-1 untuk UNLIMITED)
* @param array    $exclude_uris  Array daftar URI yang tidak boleh di-cache (BYPASS)
*/
function handleAdvancedCacheFunc($dosemething, $name, $folder = 'madxcache', $use_uri = false, $use_role = true, $ttl = 3600, $exclude_uris = array()) {
    
    // ============================================================
    // CEK EXCLUDE URI (BYPASS CACHE)
    // ============================================================
    if (!empty($exclude_uris)) {
        // Ambil path URL saja (tanpa query string seperti ?id=123)
        $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        if (is_uri_excluded($uri_path, $exclude_uris)) {
            // Jika URI termasuk dalam daftar exclude, langsung jalankan fungsi tanpa caching
            if (is_callable($dosemething)) {
                $dosemething();
            } else {
                echo "Error: Argumen pertama harus berupa fungsi yang valid.";
            }
            return;
        }
    }

    // 1. Tentukan user role (jika diaktifkan)
    $user_role = '';
    if ($use_role) {
        $user_role = 'guest'; // Default
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            if (!empty($current_user->roles)) {
			$user_role = '';
               // $user_role = $current_user->roles[0];
			   foreach($current_user->roles as $user_all_role ){$user_role .= $user_all_role;}
            }
        }
    }
//cookies untuk early cache mu plugins	
        $expire = time() + YEAR_IN_SECONDS;
        setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        $_COOKIE['my_site_role'] = $user_role;
		
    // 2. Logika penamaan file cache
    if ($use_uri) {
        $current_uri = $_SERVER['REQUEST_URI'];
        $filename_only = md5($current_uri) . $user_role . '.txt';
    } else {
        $filename_only = $use_role ? $user_role . '.txt' : 'global.txt';
    }

    // 3. Setup Jalur Direktori Baru: /wp-content/cache/{folder}/{name}/
    $base_cache_dir = WP_CONTENT_DIR . '/cache';
    $target_folder  = $folder;
    $target_name    = sanitize_title($name);
    $dirPath        = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename       = $dirPath . '/' . $filename_only;

    // ============================================================
    // CEK CACHE & TTL
    // ============================================================
    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            readfile($filename);
			echo '<!-- '.$filename.' read cache by function -->';
            return;
        }
    }

    // Jika folder belum ada, buat foldernya secara berjenjang (recursive)
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);
        // Proteksi keamanan di folder induk dan sub-folder
        file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
        file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }

    // Mulai proses Output Buffering
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();

    // Simpan dan Tampilkan
    file_put_contents($filename, $output);
    echo $output ;
	echo '<!-- '.$filename.' save cache by function -->';
};

/* 
==========================================================================
CONTOH PENGGUNAAN FUNGSI PHP DI THEME/PLUGIN ANDA
==========================================================================

handleAdvancedCacheFunc(function() {
    ?>
    <div class="my-widget">
        <h3>Konten Dinamis</h3>
        <p>Ini akan di-cache kecuali di halaman member.</p>
    </div>
    <?php
}, 'widget_sidebar', 'madxcache', false, true, 3600, array(
    '/member/*',      // Exclude semua halaman di bawah /member/
    '/my-account',    // Exclude halaman spesifik /my-account
    '/checkout/*'     // Exclude semua halaman checkout
));

*/


/**
* 2. VERSI WORDPRESS SHORTCODE
* Atribut tambahan: 'folder', 'exclude'
*/
function handle_advanced_cache_shortcode($atts, $content = null) {
    $args = shortcode_atts(array(
        'name'    => 'default_cache',
        'folder'  => 'custom-cache', 
        'uri'     => 'false',
        'role'    => 'true',
        'ttl'     => '3600',
        'exclude' => '' // Parameter baru untuk exclude URI (dipisah koma)
    ), $atts);

    $name         = $args['name'];
    $folder       = $args['folder'];
    $use_uri      = filter_var($args['uri'], FILTER_VALIDATE_BOOLEAN);
    $use_role     = filter_var($args['role'], FILTER_VALIDATE_BOOLEAN);
    $ttl          = intval($args['ttl']);
    
    // Parsing string exclude menjadi array
    $exclude_uris = array();
    if (!empty($args['exclude'])) {
        $exclude_uris = array_map('trim', explode(',', $args['exclude']));
    }

    ob_start();
    
    // Memasukkan argumen $exclude_uris ke dalam fungsi utama
    handleAdvancedCacheFunc(function() use ($content) {
        echo do_shortcode($content);
    }, $name, $folder, $use_uri, $use_role, $ttl, $exclude_uris);
    
    return ob_get_clean();
}
add_shortcode('advanced_cache', 'handle_advanced_cache_shortcode');

/* 
==========================================================================
CONTOH PENGGUNAAN SHORTCODE DI POST/PAGE/WIDGET
==========================================================================

[advanced_cache name="sidebar_widget" folder="madxcache" exclude="/member/*, /my-account"]
    <p>Konten ini akan di-cache, KECUALI jika user berada di halaman /member/* atau /my-account.</p>
[/advanced_cache]

*/
