<?php
    if($debug == 'true') {
	$debug = 'checked="checked"';
    } else {
	$debug = '';
    }
?>
<div class="wrap">
    <h2>Coming soon!!!</h2>
    <!--<h2>Cache</h2>
    <div class="postbox">
	<div style="margin: 7px;">
	    <form method="post" action="<?php echo bloginfo('wpurl'); ?>/wp-admin/admin.php?page=useragent-template">
		<input type="hidden" name="usts_action" value="updatedebug" />
		<p><label>Cache active: <input type="checkbox" name="uats_debug" <?php echo $debug; ?> /></label></p>
		<p><input type="submit" value="update" class="button bold" /></p>
	    </form>
	</div>
    </div>
    <?php include('useragent-donation.php'); ?>-->
</div>
<br/>
<br/>
<br/>