<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>

<h2><?php _e('Nope', 'memberpress'); ?></h2>

