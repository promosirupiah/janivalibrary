<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>
<span class="mepr-form-has-errors"><?php _ex('Please fix the errors above', 'ui', 'memberpress'); ?></span>

