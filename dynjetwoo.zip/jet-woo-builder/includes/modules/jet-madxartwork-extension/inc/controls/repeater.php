<?php

namespace Jet_madxartwork_Extension;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Repeater_Control extends \madxartwork\Control_Repeater {

	public function get_type() {
		return 'jet-repeater';
	}
}
