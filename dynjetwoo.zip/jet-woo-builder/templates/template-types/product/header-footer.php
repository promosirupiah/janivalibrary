<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

\madxartwork\Plugin::$instance->frontend->add_body_class( 'madxartwork-template-full-width' );

get_header( 'shop' );

do_action( 'jet-woo-builder/full-width-page/before-content' );

while ( have_posts() ) {
	the_post();

	if ( \madxartwork\Plugin::$instance->editor->is_edit_mode() || \madxartwork\Plugin::$instance->preview->is_preview_mode() ) {
		the_content();
	} else {
		wc_get_template_part( 'content', 'single-product' );
	}
}

do_action( 'jet-woo-builder/full-width-page/after-content' );

get_footer( 'shop' );
