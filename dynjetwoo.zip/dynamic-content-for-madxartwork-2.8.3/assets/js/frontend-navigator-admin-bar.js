jQuery(function () {
    jQuery('#wp-admin-bar-dce-madxartwork-edit-template-wrapper').appendTo('#wp-admin-bar-dce-frontend-navigator');
    jQuery('#wp-admin-bar-dce-madxartwork-edit-template-wrapper').css('visibility', 'visible');
});
