(function ($) {
    var WidgetElements_ViewsHandler = function ($scope, $) {

		var id_scope = $scope.attr('data-id');
		var elementSettings = dceGetElementSettings($scope);
		var elementSwiper = '.madxartwork-element-' + id_scope + ' .swiper-container';
		var speed = elementSettings.transition_speed;
		var disableOnInteraction = Boolean( elementSettings.pause_on_interaction ) || false;
		var loop = false;

		if ( 'yes' === elementSettings.infinite) {
			loop = true;
		}

		var id_post = $scope.attr('data-post-id');

		var viewsSwiperOptions = {
			autoHeight: true,
			speed: speed,
			loop: loop,
		};

		// Responsive Parameters
		viewsSwiperOptions.breakpoints = dynamicooo.makeSwiperBreakpoints({
			slidesPerView: {
				madxartwork_key: 'slides_to_show',
				default_value: 'auto'
			},
			slidesPerGroup: {
				madxartwork_key: 'slides_to_scroll',
				default_value: 1
			},
			spaceBetween: {
				madxartwork_key: 'spaceBetween',
				default_value: 0,
			},
		}, elementSettings);

		// Navigation
		if (elementSettings.navigation != 'none') {

			if ( elementSettings.navigation == 'both' || elementSettings.navigation == 'arrows' ) {
				viewsSwiperOptions = $.extend(viewsSwiperOptions, {
					navigation: {
						nextEl: id_post ? '.madxartwork-element-' + id_scope + '[data-post-id="' + id_post + '"] .madxartwork-swiper-button-next' : '.madxartwork-swiper-button-next',
						prevEl: id_post ? '.madxartwork-element-' + id_scope + '[data-post-id="' + id_post + '"] .madxartwork-swiper-button-prev' : '.madxartwork-swiper-button-prev',
					},
				});
			}

			if ( elementSettings.navigation == 'both' || elementSettings.navigation == 'dots' ) {
				viewsSwiperOptions = $.extend(viewsSwiperOptions, {
					pagination: {
						el: id_post ? '.madxartwork-element-' + id_scope + '[data-post-id="' + id_post + '"] .swiper-pagination' : '.swiper-pagination',
						type: 'bullets',
						clickable: true,
					},
				});
			}
		}

		// Autoplay
		if ( elementSettings.autoplay ) {
			viewsSwiperOptions = $.extend(viewsSwiperOptions, {
				autoplay: {
					autoplay: true,
					delay: elementSettings.autoplay_speed,
					disableOnInteraction: disableOnInteraction,
				}
			});
		}

		// Instance
		if ( 'undefined' === typeof Swiper ) {
			const asyncSwiper = madxartworkFrontend.utils.swiper;

			new asyncSwiper( jQuery( elementSwiper ), viewsSwiperOptions ).then( ( newSwiperInstance ) => {
				viewsSwiper = newSwiperInstance;
			} );
		} else {
			viewsSwiper = new Swiper( jQuery( elementSwiper ), viewsSwiperOptions );
		}

		// Pause on hover
		if ( elementSettings.autoplay && elementSettings.pause_on_hover ) {
			$(elementSwiper).on({
				mouseenter: function () {
					viewsSwiper.autoplay.stop();
				},
				mouseleave: function () {
					viewsSwiper.autoplay.start();
				}
			});
		}

    };

    // Make sure you run this code under madxartwork..
    $(window).on('madxartwork/frontend/init', function () {
        madxartworkFrontend.hooks.addAction('frontend/element_ready/dce-views.default', WidgetElements_ViewsHandler);
    });
})(jQuery);
