    
    
    jQuery(document).ready(function()
        {
            jQuery( '.tips' ).tipTip({
                    'attribute': 'data-tip',
                    'fadeIn': 50,
                    'fadeOut': 50,
                    'delay': 200
                });

    });
        
        
        