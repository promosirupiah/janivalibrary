<?php
function handlegeoCacheFunc($dosemething, $name, $folder = 'madxcache', $use_uri = false, $use_role = true, $ttl = 3600) {
$user_role = '';
$current_uri = $_SERVER['REQUEST_URI'];
$filename_only = md5($current_uri . $user_role) . '.txt';

    $base_cache_dir = 'wp-content/geo';
    $target_folder  = $folder;
    $target_name    = $name;
    
    $dirPath  = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename = $dirPath . '/' . $filename_only;

    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            readfile($filename);
            return;
        }
    }
    
    // Jika folder belum ada, buat foldernya secara berjenjang (recursive)
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);
        // Proteksi keamanan di folder induk dan sub-folder
     //   file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
      //  file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }
    
    // Mulai proses Output Buffering
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();
    
    // Simpan dan Tampilkan
    file_put_contents($filename, $output);
    echo $output;
}


handlegeoCacheFunc(function(){
define('SHORTINIT', true);
require_once('./wp-load.php');

global $wpdb, $table_prefix;


if (isset($_REQUEST['action'])){
if( $_REQUEST['action'] == 'madx_gff_fetch_countries'){
$wp_madx_countries = $table_prefix.'countries';
if(isset($_REQUEST['madxname'])){
$country_name = esc_sql(sanitize_text_field($_REQUEST['madxname']));
}
if (isset($_REQUEST['madxname'])){
$query = "SELECT `id`,`name`,`iso3`,`iso2`,`phonecode`  FROM `$wp_madx_countries` WHERE `name` LIKE '%".$country_name."%' OR `iso3` LIKE '%".$country_name."%' ORDER BY `name`;";
}
else{
$query = "SELECT `id`,`name`,`iso3`,`iso2`,`phonecode`    FROM `".$wp_madx_countries."` ORDER BY `name`;";
}
$countries = $wpdb->get_results($query);
echo json_encode($countries);
}// end madx_gff_fetch_countries

if( $_REQUEST['action'] == 'madx_gff_fetch_states'){
$wp_madx_states = $table_prefix.'states';
if(isset($_REQUEST['madxname'])){     $state_name = esc_sql(sanitize_text_field($_REQUEST['madxname']));	}
if(isset($_REQUEST['country_code'])){     $country_code = esc_sql(sanitize_text_field($_REQUEST['country_code']));	}
if (isset($_REQUEST['madxname'])){
$query = "SELECT `id`,`name`, `iso2`  FROM `".$wp_madx_states."` WHERE country_code = '$country_code' AND name LIKE '%$state_name%' AND fips_code > 0 ORDER BY `name`;";}
else{
$query = "SELECT `id`,`name`, `iso2`  FROM `".$wp_madx_states."` WHERE country_code = '$country_code' AND fips_code > 0 ORDER BY `name`;";
}
$states = $wpdb->get_results($query);
echo json_encode($states);
}// end madx_gff_fetch_states

if( $_REQUEST['action'] == 'madx_gff_fetch_cities'){
$wp_madx_cities = $table_prefix.'cities';
// PERBAIKAN: Ubah $state_name menjadi $city_name
if(isset($_REQUEST['madxname'])){     $city_name = esc_sql(sanitize_text_field($_REQUEST['madxname']));	}
if(isset($_REQUEST['state_code'])){     $state_code = esc_sql(sanitize_text_field($_REQUEST['state_code']));	}
if(isset($_REQUEST['country_code'])){     $country_code = esc_sql(sanitize_text_field($_REQUEST['country_code']));	}
if (isset($_REQUEST['madxname'])){
$query = "SELECT `id`,`name`  FROM `".$wp_madx_cities."` WHERE state_code = '$state_code' AND country_code = '$country_code' AND name LIKE '%$city_name%' ORDER BY `name`;";
} else {
$query = "SELECT `id`,`name`  FROM `".$wp_madx_cities."` WHERE state_code = '$state_code' AND country_code = '$country_code' ORDER BY `name`;";
}
$cities = $wpdb->get_results($query);
echo json_encode($cities);
}// end madx_gff_fetch_cities

// TAMBAHAN: Endpoint untuk postcodes
if( $_REQUEST['action'] == 'madx_gff_fetch_postcodes'){
$wp_madx_postcodes = $table_prefix.'postcodes';
if(isset($_REQUEST['madxname'])){     $postcode_search = esc_sql(sanitize_text_field($_REQUEST['madxname']));	}
if(isset($_REQUEST['state_code'])){     $state_code = esc_sql(sanitize_text_field($_REQUEST['state_code']));	}
if(isset($_REQUEST['country_code'])){     $country_code = esc_sql(sanitize_text_field($_REQUEST['country_code']));	}

// Hanya filter berdasarkan country_code dan state_code
if (isset($_REQUEST['madxname']) && $_REQUEST['madxname'] != ''){
    // Search by postcode code
    $query = "SELECT DISTINCT `code`, `locality_name`, `city_id` FROM `".$wp_madx_postcodes."` WHERE country_code = '$country_code' AND state_code = '$state_code' AND code LIKE '$postcode_search%' GROUP BY `code` ORDER BY `code`;";
} else {
    // Get all unique postcodes untuk state ini
    $query = "SELECT DISTINCT `code`, `locality_name`, `city_id` FROM `".$wp_madx_postcodes."` WHERE country_code = '$country_code' AND state_code = '$state_code' GROUP BY `code` ORDER BY `code`;";
}
$postcodes = $wpdb->get_results($query);
echo json_encode($postcodes);
}// end madx_gff_fetch_postcodes

} // $_REQUEST['action']
}, 'geo', 'geo',true, false, -1);
exit;
?>