<?php
/**
 * Plugin Name: Master Early Page Cache & Role Cookie
 * Description: Sistem cache full-page berdasarkan role. Intercept di awal (muplugins_loaded) dan sinkronisasi cookie role otomatis.
 * Version: 4.0 (Master)
 */
 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. Definisikan direktori cache
define( 'MY_CUSTOM_CACHE_DIR', WP_CONTENT_DIR . '/cache/madxcache/'.$_SERVER['SERVER_NAME'].'/complete/' );

/**
 * ==========================================
 * BAGIAN A: INTERCEPTOR CACHE (LOADING AWAL)
 * ==========================================
 */
function my_mu_early_cache_check() {
    
    // DAFTAR URI YANG TIDAK AKAN DI-CACHE
    $excluded_uris = array(
        '/member/',
        '/wp-admin/',
        '/wp-login.php',
        '/cart/',
        '/checkout/',
        '/my-account/',
        '/api/',
    );

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
    
    // Cek pengecualian URI
    foreach ( $excluded_uris as $excluded_uri ) {
        if ( strpos( $request_uri, $excluded_uri ) !== false ) {
            return; // Batalkan cache, biarkan WordPress load normal
        }
    }

    // Jangan cache untuk POST, AJAX, Cron, REST API
    if ( ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] !== 'GET' ) ||
         ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ||
         ( defined( 'DOING_CRON' ) && DOING_CRON ) ||
         ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
        return;
    }
    // --- VALIDASI USER & GENERATE NAMA FILE ---
   // $uri = strtok( $request_uri, '?' ); 
    $uri = $request_uri;
    $user_role = 'guest';
    $has_wp_login_cookie = false;
    
    // Cek cookie login WordPress asli
    foreach ( $_COOKIE as $key => $value ) {
        if ( strpos( $key, 'wordpress_logged_in_' ) === 0 ) {
            $has_wp_login_cookie = true;
            break;
        }
    }

    // Jika ada cookie login WP DAN ada cookie custom role, gunakan role tersebut
    if ( $has_wp_login_cookie && isset( $_COOKIE['my_site_role'] ) && ! empty( $_COOKIE['my_site_role'] ) ) {
        $user_role =  $_COOKIE['my_site_role'];
    }

    $cache_filename = md5( $uri ) . $user_role . '.txt';
    $cache_filepath = MY_CUSTOM_CACHE_DIR . $cache_filename;

    // --- CEK & SAJIKAAN CACHE ---
    if ( file_exists( $cache_filepath ) ) {
        header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
        header( 'X-Cache-Status: HIT' );
        
        readfile( $cache_filepath );
		echo '<!-- mu cache -->';
        
        // PENTING: exit di sini. Sisa kode di bawah file ini TIDAK akan dieksekusi.
        // Ini TIDAK masalah karena jika cache HIT, user tidak sedang login/logout.
        exit; 
    }
else{echo '<!-- '.$cache_filepath.' -->';}

}
// Hook paling awal
add_action( 'muplugins_loaded', 'my_mu_early_cache_check', 1 );
