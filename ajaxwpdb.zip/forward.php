<?php
$targetUrl = 'https://ikaspega.my03.com/wp-json/bit-integrations/v1/callback/d62e8c70-0d58-4c68-8bd4-52da4a3591ed';


$data = $_REQUEST;
// $data = array_merge($_GET, $_POST);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $targetUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data)); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
$response = curl_exec($ch);
if(curl_errno($ch)){
    echo 'Terjadi error cURL: ' . curl_error($ch);
} else {
    echo "Data berhasil dikirim. Response dari server tujuan:<br>";
    echo $response;
}
curl_close($ch);