<?php

handleAdvancedCacheFunc(function(){echo json_encode($_REQUEST);}, 'capture', 'madxcache'], true, false, -1)

?>