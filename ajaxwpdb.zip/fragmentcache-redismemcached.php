<?php
/**
 * Plugin Name: Custom Role & URI Fragment Cache (Redis/Memcached/File)
 * Description: Plugin fragment caching berdasarkan User Role dan URI. Mendukung Redis/Memcached dengan fallback ke File Cache. File cache tetap selalu disimpan.
 * Version:     2.0.0
 * Author:      AI Collaborator
 * License:     GPL2
 */

// Keluar jika diakses langsung di luar WordPress
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Helper: Cek apakah URI saat ini ada di dalam daftar exclude
 * Mendukung wildcard (*) untuk pencocokan pola
 */
function is_uri_excluded($current_uri_path, $exclude_uris) {
    if (empty($exclude_uris) || !is_array($exclude_uris)) {
        return false;
    }
    foreach ($exclude_uris as $pattern) {
        $pattern = trim($pattern);
        if (empty($pattern)) continue;
        
        // Ubah pola wildcard menjadi regex
        $regex = '/^' . str_replace('\*', '.*', preg_quote($pattern, '/')) . '$/i';
        if (preg_match($regex, $current_uri_path)) {
            return true;
        }
    }
    return false;
}

/**
 * Helper: Mendapatkan Koneksi Cache Engine (Redis -> Memcached -> File)
 * Menggunakan Singleton pattern agar koneksi hanya dibuat sekali per request.
 */
function get_fragment_cache_engine() {
    static $engine = null;
    if ($engine !== null) {
        return $engine;
    }

    // 1. Coba Redis
    if (class_exists('Redis')) {
        $redis = new Redis();
        try {
            // Timeout 1 detik agar tidak memperlambat site jika Redis down
            if (@$redis->connect('127.0.0.1', 6379, 1.0)) {
                $engine = ['type' => 'redis', 'conn' => $redis];
                return $engine;
            }
        } catch (Exception $e) {
            // Abaikan error, lanjut ke Memcached
        }
    }

    // 2. Coba Memcached
    if (class_exists('Memcached')) {
        $memcached = new Memcached();
        $memcached->setOption(Memcached::OPT_CONNECT_TIMEOUT, 1000); // Timeout 1 detik
        $memcached->addServer('127.0.0.1', 11211);
        
        // Cek apakah server benar-benar merespon
        $stats = $memcached->getStats();
        if (!empty($stats)) {
            $engine = ['type' => 'memcached', 'conn' => $memcached];
            return $engine;
        }
    }

    // 3. Fallback ke File Cache
    $engine = ['type' => 'file', 'conn' => null];
    return $engine;
}

/**
 * 1. FUNGSI UTAMA (Versi Fungsi PHP)
 */
function handleAdvancedCacheFunc($dosemething, $name, $folder = 'madxcache', $use_uri = false, $use_role = true, $ttl = 3600, $exclude_uris = array()) {
    
    // ============================================================
    // CEK EXCLUDE URI (BYPASS CACHE)
    // ============================================================
    if (!empty($exclude_uris)) {
        $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        if (is_uri_excluded($uri_path, $exclude_uris)) {
            if (is_callable($dosemething)) {
                $dosemething();
            } else {
                echo "Error: Argumen pertama harus berupa fungsi yang valid.";
            }
            return;
        }
    }

    // 1. Tentukan user role (jika diaktifkan)
    $user_role = '';
    if ($use_role) {
        $user_role = 'guest';
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            if (!empty($current_user->roles)) {
                $user_role = '';
                foreach($current_user->roles as $user_all_role ){
                    $user_role .= $user_all_role;
                }
            }
        }
    }

    // cookies untuk early cache mu plugins
    $expire = time() + YEAR_IN_SECONDS;
    setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
    $_COOKIE['my_site_role'] = $user_role;

    // 2. Logika penamaan file cache
    if ($use_uri) {
        $current_uri = $_SERVER['REQUEST_URI'];
        $filename_only = md5($current_uri . $user_role) . '.txt';
    } else {
        $filename_only = $use_role ? $user_role . '.txt' : 'global.txt';
    }

    // 3. Setup Jalur Direktori File: /wp-content/cache/{folder}/{name}/
    $base_cache_dir = WP_CONTENT_DIR . '/cache';
    $target_folder  = sanitize_title($folder);
    $target_name    = sanitize_title($name);
    $dirPath        = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename       = $dirPath . '/' . $filename_only;

    // 4. Inisialisasi Cache Engine & Cache Key
    $engine    = get_fragment_cache_engine();
    $cache_key = 'frag_' . md5($target_folder . '_' . $target_name . '_' . $filename_only);

    // ============================================================
    // CEK MEMORY CACHE (REDIS / MEMCACHED)
    // ============================================================
    if ($engine['type'] !== 'file') {
        $cached_data = false;
        try {
            if ($engine['type'] === 'redis') {
                $cached_data = $engine['conn']->get($cache_key);
            } elseif ($engine['type'] === 'memcached') {
                $cached_data = $engine['conn']->get($cache_key);
            }
        } catch (Exception $e) {
            // Jika error saat read, biarkan fallback ke file
        }

        if ($cached_data !== false && $cached_data !== null) {
            echo $cached_data;
            echo '<!-- read memory cache (' . $engine['type'] . ') ' . $cache_key . ' -->';
            return;
        }
    }

    // ============================================================
    // CEK FILE CACHE (FALLBACK)
    // ============================================================
    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            $file_content = file_get_contents($filename);
            
            // Jika file ada tapi memory cache kosong, masukkan ke memory cache
            if ($engine['type'] !== 'file') {
                try {
                    if ($engine['type'] === 'redis') {
                        $ttl_redis = ($ttl === -1) ? 0 : $ttl;
                        if ($ttl_redis > 0) $engine['conn']->setex($cache_key, $ttl_redis, $file_content);
                        else $engine['conn']->set($cache_key, $file_content);
                    } elseif ($engine['type'] === 'memcached') {
                        $engine['conn']->set($cache_key, $file_content, $ttl);
                    }
                } catch (Exception $e) {}
            }

            echo $file_content;
            echo '<!-- read file cache ' . $filename . ' -->';
            return;
        }
    }

    // Jika folder belum ada, buat foldernya secara berjenjang
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);
        file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
        file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }

    // ============================================================
    // GENERATE KONTEN & SIMPAN CACHE
    // ============================================================
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();

    // A. SIMPAN KE FILE CACHE (SELALU DILAKUKAN SESUAI PERMINTAAN)
    file_put_contents($filename, $output);

    // B. SIMPAN KE MEMORY CACHE (JIKA TERSEDIA)
    if ($engine['type'] !== 'file') {
        try {
            if ($engine['type'] === 'redis') {
                if ($ttl > 0) {
                    $engine['conn']->setex($cache_key, $ttl, $output);
                } else {
                    $engine['conn']->set($cache_key, $output); // Unlimited
                }
            } elseif ($engine['type'] === 'memcached') {
                $engine['conn']->set($cache_key, $output, $ttl);
            }
        } catch (Exception $e) {
            // Abaikan jika gagal menyimpan ke memory, file cache sudah aman
        }
    }

    echo $output;
    echo '<!-- save by function (file + ' . $engine['type'] . ') ' . $filename . ' -->';
}

/**
 * 2. VERSI WORDPRESS SHORTCODE
 */
function handle_advanced_cache_shortcode($atts, $content = null) {
    $args = shortcode_atts(array(
        'name'    => 'default_cache',
        'folder'  => 'custom-cache',
        'uri'     => 'false',
        'role'    => 'true',
        'ttl'     => '3600',
        'exclude' => ''
    ), $atts);

    $name         = $args['name'];
    $folder       = $args['folder'];
    $use_uri      = filter_var($args['uri'], FILTER_VALIDATE_BOOLEAN);
    $use_role     = filter_var($args['role'], FILTER_VALIDATE_BOOLEAN);
    $ttl          = intval($args['ttl']);

    $exclude_uris = array();
    if (!empty($args['exclude'])) {
        $exclude_uris = array_map('trim', explode(',', $args['exclude']));
    }

    ob_start();
    handleAdvancedCacheFunc(function() use ($content) {
        echo do_shortcode($content);
    }, $name, $folder, $use_uri, $use_role, $ttl, $exclude_uris);
    
    return ob_get_clean();
}
add_shortcode('advanced_cache', 'handle_advanced_cache_shortcode');

// ============================================================
// COOKIE MANAGEMENT (TIDAK DIUBAH)
// ============================================================
add_action( 'set_logged_in_cookie', 'my_sync_role_cookie_on_login', 10, 4 );
function my_sync_role_cookie_on_login( $logged_in_cookie, $expire, $expiration, $user_id ) {
    $user = get_userdata( $user_id );
    if ( $user && ! empty( $user->roles ) ) {
        $user_role = '';
        foreach($user->roles as $user_all_role ){
            $user_role .= $user_all_role;
        }
        setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        $_COOKIE['my_site_role'] = $user_role;
    }
}

add_action( 'wp_logout', 'my_clear_role_cookie_on_logout' );
function my_clear_role_cookie_on_logout() {
    if ( isset( $_COOKIE['my_site_role'] ) ) {
        setcookie( 'my_site_role', ' ', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        unset( $_COOKIE['my_site_role'] );
    }
}

add_action( 'profile_update', 'my_update_role_cookie_on_profile_update', 10, 2 );
function my_update_role_cookie_on_profile_update( $user_id, $old_user_data ) {
    if ( get_current_user_id() == $user_id ) {
        $user = get_userdata( $user_id );
        if ( $user && ! empty( $user->roles ) ) {
            $user_role = '';
            foreach($user->roles as $user_all_role ){
                $user_role .= $user_all_role;
            }
            $expire = time() + YEAR_IN_SECONDS;
            setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
            $_COOKIE['my_site_role'] = $user_role;
        }
    }
}