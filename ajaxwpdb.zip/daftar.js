jQuery(document).ready(function($){
    // Global click listener untuk menutup dropdown suggestion
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.madx_suggestions, .country, .state, .city, .postcode').length) {
            $('.madx_suggestions').remove();
        }
    });

    // Helper: Convert input text ke select dropdown (untuk mode edit)
    function convertToSelect($input, initialValue, placeholder) {
        if ($input.is('input:text') && initialValue) {
            var $select = $('<select></select>');
            $select.attr('name', $input.attr('name'));
            $select.attr('class', $input.attr('class'));
            $select.html('<option value="">' + placeholder + '</option>');
            $input.replaceWith($select);
            return $select;
        }
        return $input;
    }

    // Helper: Menampilkan dropdown suggestion
    function showSuggestions($input, items, $suggestionRef, onSelect, displayField = 'name') {
        if ($suggestionRef.current) $suggestionRef.current.remove();
        
        var $list = $('<div class="madx_suggestions"></div>');
        $list.css({
            'position': 'absolute',
            'background': '#fff',
            'border': '1px solid #ccc',
            'z-index': 9999,
            'max-height': '150px',
            'overflow-y': 'auto',
            'width': $input.outerWidth() + 'px',
            'box-sizing': 'border-box',
            'box-shadow': '0 4px 6px rgba(0,0,0,0.1)'
        });
        
        if (items.length === 0) {
            $list.append('<p style="margin:0; padding:8px; color:#999;">Tidak ada hasil</p>');
        } else {
            $.each(items, function(i, item) {
                var displayText = item[displayField];
                if (item.code && displayField !== 'code') {
                    displayText = item.code + ' - ' + item.locality_name;
                }
                
                var $p = $('<p></p>').text(displayText).css({
                    'margin': '0', 
                    'padding': '8px', 
                    'cursor': 'pointer',
                    'border-bottom': '1px solid #eee'
                });
                $p.hover(
                    function(){ $(this).css('background', '#f0f0f0'); }, 
                    function(){ $(this).css('background', '#fff'); }
                );
                $p.on('click', function() {
                    onSelect(item);
                    $list.remove();
                    $suggestionRef.current = null;
                });
                $list.append($p);
            });
        }
        
        var offset = $input.offset();
        $list.css({
            'top': (offset.top + $input.outerHeight()) + 'px',
            'left': offset.left + 'px'
        });
        
        $('body').append($list);
        $suggestionRef.current = $list;
    }

    function hideSuggestions($suggestionRef) {
        if ($suggestionRef.current) {
            $suggestionRef.current.remove();
            $suggestionRef.current = null;
        }
    }

    function showWarning($input, $suggestionRef, message) {
        if ($suggestionRef.current) $suggestionRef.current.remove();
        var $list = $('<div class="madx_suggestions"></div>').css({
            'position': 'absolute', 'background': '#fff', 'border': '1px solid #ccc', 
            'z-index': 9999, 'width': $input.outerWidth() + 'px', 'box-sizing': 'border-box'
        });
        $list.append('<p style="margin:0; padding:8px; color:#999;">' + message + '</p>');
        var offset = $input.offset();
        $list.css({ 'top': (offset.top + $input.outerHeight()) + 'px', 'left': offset.left + 'px' });
        $('body').append($list);
        $suggestionRef.current = $list;
    }

    // Looping untuk setiap form
    $('form').each(function(){
        var $form = $(this);
        
        var $countryField = $form.find('.country');
		var $prefixField = $form.find('.prefix');
        var $stateField = $form.find('.state');
        var $cityField = $form.find('.city');
  //      var $postcodeField = $form.find('.postcode');
        
        if(!$countryField.length) return; 
        
        // Simpan value awal (untuk mode edit)
        var initialCountryValue = $countryField.val() || 'ID';
		var initialprefixValue = $prefixField.val() || '62';
        var initialStateValue = $stateField.val() || 'JT';
        var initialCityValue = $cityField.val() || 'Semarang';
  //      var initialPostcodeValue = $postcodeField.val() || '';
        
        // Deteksi mode: jika ada value awal, convert ke select (mode edit)
        var isEditMode = (initialCountryValue || initialprefixValue || initialStateValue || initialCityValue);
        
        if (isEditMode) {
            $countryField = convertToSelect($countryField, initialCountryValue, 'Pilih Negara');
			$prefixField = convertToSelect($prefixField, initialprefixValue, 'Pilih Prefix');
            $stateField = convertToSelect($stateField, initialStateValue, 'Pilih Provinsi');
            $cityField = convertToSelect($cityField, initialCityValue, 'Pilih Kota');
   //         $postcodeField = convertToSelect($postcodeField, initialPostcodeValue, 'Pilih Kode Pos');
        }
        
        // Deteksi tipe input setelah konversi
        var isCountryText = $countryField.is('input:text');
		var isprefixText = $prefixField.is('input:text');
        var isStateText = $stateField.is('input:text');
        var isCityText = $cityField.is('input:text');
 //       var isPostcodeText = $postcodeField.is('input:text');

        // Variabel status
        var selectedCountryCode = isEditMode ? initialCountryValue : '';
		var selectedprefixCode = isEditMode ? initialprefixValue : '';
        var selectedStateCode = isEditMode ? initialStateValue : '';
        var selectedCityName = isEditMode ? initialCityValue : '';
        var selectedCityId = '';
        
        var ajaxCountry = false;
		var ajaxprefix = false;
        var ajaxState = false;
        var ajaxCity = false;
 //       var ajaxPostcode = false;

        var countrySuggestionRef = { current: null };
		var prefixSuggestionRef = { current: null };
        var stateSuggestionRef = { current: null };
        var citySuggestionRef = { current: null };
 //       var postcodeSuggestionRef = { current: null };

        // INISIALISASI - Load data untuk mode edit
        if (isEditMode) {
            madx_gff_fetch_countries(); madx_gff_fetch_prefix();
            // State dan city akan di-load setelah country selesai
        } else {
            if (!isCountryText) madx_gff_fetch_countries();
			if (!isprefixText) madx_gff_fetch_prefix();
            if (!isStateText && selectedCountryCode) madx_gff_fetch_states();
            if (!isCityText && selectedCountryCode && selectedStateCode) madx_gff_fetch_cities();
    //        if (!isPostcodeText && selectedCountryCode && selectedStateCode) madx_gff_fetch_postcodes();
        }

        // EVENT LISTENER - COUNTRY
        if (isCountryText) {
            $countryField.on('keyup', function() {
                var val = $(this).val();
                if (val.length >= 1) madx_gff_fetch_countries(val);
                else hideSuggestions(countrySuggestionRef);
            }).on('focus', function() {
                if ($(this).val().length >= 1) madx_gff_fetch_countries($(this).val());
            });
        } else {
            $countryField.on('change', function() {
                selectedCountryCode = $(this).val();
                selectedStateCode = '';
                selectedCityName = '';
                selectedCityId = '';
                if($cityField.length && !isCityText) $cityField.html('<option value="">Pilih Kota</option>');
       //         if($postcodeField.length && !isPostcodeText) $postcodeField.html('<option value="">Pilih Kode Pos</option>');
                if(isStateText) $stateField.val(''); 
                else madx_gff_fetch_states();
            });
        }
        // EVENT LISTENER - Prefix
        if (isprefixText) {
            $prefixField.on('keyup', function() {
                var val = $(this).val();
                if (val.length >= 1) madx_gff_fetch_prefix(val);
                else hideSuggestions(prefixSuggestionRef);
            }).on('focus', function() {
                if ($(this).val().length >= 1) madx_gff_fetch_prefix($(this).val());
            });
        } 
        // EVENT LISTENER - STATE
        if (isStateText) {
            $stateField.on('keyup', function() {
                if (!selectedCountryCode) {
                    showWarning($stateField, stateSuggestionRef, 'Pilih negara terlebih dahulu');
                    return;
                }
                var val = $(this).val();
                if (val.length >= 1) madx_gff_fetch_states(val);
                else hideSuggestions(stateSuggestionRef);
            }).on('focus', function() {
                if ($(this).val().length >= 1 && selectedCountryCode) madx_gff_fetch_states($(this).val());
            });
        } else {
            $stateField.on('change', function() {
                selectedStateCode = $(this).val();
                selectedCityName = '';
                selectedCityId = '';
                if(isCityText) $cityField.val('');
       //         if(isPostcodeText) $postcodeField.val('');
      //          else madx_gff_fetch_postcodes();
                if(!isCityText) madx_gff_fetch_cities();
            });
        }

        // EVENT LISTENER - CITY
        if (isCityText) {
            $cityField.on('keyup', function() {
                if (!selectedStateCode) {
                    showWarning($cityField, citySuggestionRef, 'Pilih provinsi terlebih dahulu');
                    return;
                }
                var val = $(this).val();
                if (val.length >= 1) madx_gff_fetch_cities(val);
                else hideSuggestions(citySuggestionRef);
            }).on('focus', function() {
                if ($(this).val().length >= 1 && selectedStateCode) madx_gff_fetch_cities($(this).val());
            });
        } else {
            $cityField.on('change', function() {
                var selectedOption = $(this).find(':selected');
                selectedCityId = selectedOption.data('id') || '';
                selectedCityName = selectedOption.val() || '';
                
     //           if(isPostcodeText) $postcodeField.val('');
      //          else madx_gff_fetch_postcodes();
            });
        }

        // EVENT LISTENER - POSTCODE
 /*       if (isPostcodeText) {
            $postcodeField.on('keyup', function() {
                if (!selectedStateCode) {
                    showWarning($postcodeField, postcodeSuggestionRef, 'Pilih provinsi terlebih dahulu');
                    return;
                }
                var val = $(this).val();
                if (val.length >= 1) madx_gff_fetch_postcodes(val);
                else hideSuggestions(postcodeSuggestionRef);
            }).on('focus', function() {
                if ($(this).val().length >= 1 && selectedStateCode) madx_gff_fetch_postcodes($(this).val());
            });
        }
*/
        // FUNGSI AJAX - COUNTRIES
        function madx_gff_fetch_countries(countryInput = ''){
            if(ajaxCountry) return;
            var data = { 'action': 'madx_gff_fetch_countries' };
            if(countryInput != '') data['madxname'] = countryInput;
            
            ajaxCountry = true;
            $.ajax({
                url: '/madxajax/geo/',
                type: "GET",
                data: data,
                success: function(response){
                    try {
                        var countries = JSON.parse(response);
                        if (isCountryText) {
                            showSuggestions($countryField, countries, countrySuggestionRef, function(item) {
                                $countryField.val(item.name);
                                selectedCountryCode = item.iso2;
                                selectedStateCode = '';
                                selectedCityName = '';
                                selectedCityId = '';
                                if($cityField.length && !isCityText) $cityField.html('<option value="">Pilih Kota</option>');
           //                     if($postcodeField.length && !isPostcodeText) $postcodeField.html('<option value="">Pilih Kode Pos</option>');
                                if(isStateText) $stateField.val(''); 
                                else madx_gff_fetch_states();
                            });
                        } else {
                            var html = "<option value=''>Pilih Negara</option>";
                            $.each(countries, function(i, item) {
                                var selected = (item.iso2 == selectedCountryCode) ? 'selected' : '';
                                html += '<option value="'+item.iso2+'" '+selected+'>'+item.name+'</option>';
                            });
                            $countryField.html(html);
                            
                            // Setelah country di-load, load state untuk mode edit
                            if (isEditMode && selectedCountryCode) {
                                madx_gff_fetch_states();
                            }
                        }
                    } catch(e) { console.error('Error parsing countries:', response); }
                    ajaxCountry = false;
                },
                error: function(xhr, status, error){ console.error('Error fetching countries:', error); ajaxCountry = false; }
            });
        }

	// FUNGSI AJAX - PREFIX
        function madx_gff_fetch_prefix(prefixInput = ''){
            if(ajaxprefix) return;
            var data = { 'action': 'madx_gff_fetch_countries' };
          //  if(prefixInput != '') data['madxname'] = prefixInput;
            
            ajaxprefix = true;
            $.ajax({
                url: '/madxajax/geo/',
                type: "GET",
                data: data,
                success: function(response){
                    try {
                        var prefix = JSON.parse(response);
                        if (isprefixText) {
                            showSuggestions($prefixField, prefix, prefixSuggestionRef, function(item) {
                                $prefixField.val(item.phonecode);
                                selectedprefixCode = item.phonecode;

                            });
                        } else {
                            var html = "<option value=''>Pilih Prefix</option>";
                            $.each(prefix, function(i, item) {
                                var selected = (item.phonecode == selectedprefixCode) ? 'selected' : '';
                                html += '<option value="'+item.phonecode+'" '+selected+'>'+item.name+' +'+item.phonecode+'</option>';
                            });
                            $prefixField.html(html);
                            
                            // Setelah country di-load, load state untuk mode edit
                            if (isEditMode && selectedprefixCode) {
                               // madx_gff_fetch_states();
                            }
                        }
                    } catch(e) { console.error('Error parsing countries:', response); }
                    ajaxprefix = false;
                },
                error: function(xhr, status, error){ console.error('Error fetching prefix:', error); ajaxprefix = false; }
            });
        }

        // FUNGSI AJAX - STATES
        function madx_gff_fetch_states(stateInput = ''){
            if(!selectedCountryCode || ajaxState) return;
            var data = { 'action': 'madx_gff_fetch_states', 'country_code': selectedCountryCode };
            if(stateInput != '') data['madxname'] = stateInput;
            
            ajaxState = true;
            $.ajax({
                url: '/madxajax/geo/',
                type: "GET",
                data: data,
                success: function(response){
                    try {
                        var states = JSON.parse(response);
                        if (isStateText) {
                            showSuggestions($stateField, states, stateSuggestionRef, function(item) {
                                $stateField.val(item.name);
                                selectedStateCode = item.iso2;
                                selectedCityName = '';
                                selectedCityId = '';
                                if(isCityText) $cityField.val('');
               //                 if(isPostcodeText) $postcodeField.val('');
                //                else madx_gff_fetch_postcodes();
                                if(!isCityText) madx_gff_fetch_cities();
                            });
                        } else {
                            var html = "<option value=''>Pilih Provinsi</option>";
                            $.each(states, function(i, item) {
                                var selected = (item.iso2 == selectedStateCode) ? 'selected' : '';
                                html += '<option value="'+item.iso2+'" '+selected+'>'+item.name+'</option>';
                            });
                            $stateField.html(html);
                            
                            // Setelah state di-load, load city untuk mode edit
                            if (isEditMode && selectedStateCode) {
                                madx_gff_fetch_cities();
                            }
                        }
                    } catch(e) { console.error('Error parsing states:', response); }
                    ajaxState = false;
                },
                error: function(xhr, status, error){ console.error('Error fetching states:', error); ajaxState = false; }
            });
        }

        // FUNGSI AJAX - CITIES
        function madx_gff_fetch_cities(cityInput = ''){
            if(!selectedCountryCode || !selectedStateCode || ajaxCity) return;
            var data = { 
                'action': 'madx_gff_fetch_cities', 
                'country_code': selectedCountryCode, 
                'state_code': selectedStateCode 
            };
            if(cityInput != '') data['madxname'] = cityInput;
            
            ajaxCity = true;
            $.ajax({
                url: '/madxajax/geo/',
                type: "GET",
                data: data,
                success: function(response){
                    try {
                        var cities = JSON.parse(response);
                        if (isCityText) {
                            showSuggestions($cityField, cities, citySuggestionRef, function(item) {
                                $cityField.val(item.name);
                                selectedCityName = item.name;
                                selectedCityId = item.id;
              //                  if(isPostcodeText) $postcodeField.val('');
              //                  else madx_gff_fetch_postcodes();
                            });
                        } else {
                            var html = "<option value=''>Pilih Kota</option>";
                            $.each(cities, function(i, item) {
                                var selected = (item.name == selectedCityName) ? 'selected' : '';
                                html += '<option value="'+item.name+'" data-id="'+item.id+'" '+selected+'>'+item.name+'</option>';
                            });
                            $cityField.html(html);
                            
                            // Setelah city di-load, load postcode untuk mode edit
                            if (isEditMode && selectedStateCode) {
              //                  madx_gff_fetch_postcodes();
                            }
                        }
                    } catch(e) { console.error('Error parsing cities:', response); }
                    ajaxCity = false;
                },
                error: function(xhr, status, error){ console.error('Error fetching cities:', error); ajaxCity = false; }
            });
        }

        // FUNGSI AJAX - POSTCODES
        function madx_gff_fetch_postcodes(postcodeInput = ''){
            if(!selectedCountryCode || !selectedStateCode || ajaxPostcode) return;
            var data = { 
                'action': 'madx_gff_fetch_postcodes', 
                'country_code': selectedCountryCode, 
                'state_code': selectedStateCode 
            };
            if(postcodeInput != '') data['madxname'] = postcodeInput;
            
            ajaxPostcode = true;
            $.ajax({
                url: '/madxajax/geo/',
                type: "GET",
                data: data,
                success: function(response){
                    try {
                        var postcodes = JSON.parse(response);
                        if (isPostcodeText) {
                            showSuggestions($postcodeField, postcodes, postcodeSuggestionRef, function(item) {
                                $postcodeField.val(item.code);
                            }, 'code');
                        } else {
                            var html = "<option value=''>Pilih Kode Pos</option>";
                            $.each(postcodes, function(i, item) {
                                var selected = (item.code == initialPostcodeValue) ? 'selected' : '';
                                html += '<option value="'+item.code+'" '+selected+'>'+item.code;
                                if(item.locality_name) html += ' - ' + item.locality_name;
                                html += '</option>';
                            });
                            $postcodeField.html(html);
                        }
                    } catch(e) { console.error('Error parsing postcodes:', response); }
                    ajaxPostcode = false;
                },
                error: function(xhr, status, error){ console.error('Error fetching postcodes:', error); ajaxPostcode = false; }
            });
        }
    });
});
