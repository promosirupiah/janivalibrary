<?php
handleAdvancedCacheFunc(function(){

global $wpdb, $table_prefix;
if (isset($_REQUEST['action'])){
if( $_REQUEST['action'] == 'madx_gff_fetch_angkatan'){
$wp_madx_angkatan = $table_prefix.'pods_angkatan';
if(isset($_REQUEST['madxname'])){
$angkatan_name = esc_sql(sanitize_text_field($_REQUEST['madxname']));
}
if (isset($_REQUEST['madxname'])){
$query = "SELECT `name`  FROM `$wp_madx_angkatan` WHERE `name` LIKE '%".$angkatan_name."%'  ORDER BY `name`;";
}
else{
$query = "SELECT `name` FROM `".$wp_madx_angkatan."` ORDER BY `name`;";
}
$angkatan = $wpdb->get_results($query);
echo json_encode($angkatan);
}// end madx_gff_fetch_angkatan


} // $_REQUEST['action']
}, 'angkatan', 'madxcache',true, false, -1)
?>