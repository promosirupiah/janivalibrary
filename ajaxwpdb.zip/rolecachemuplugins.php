<?php
/**
 * Plugin Name: Master Early Page Cache & Role Cookie
 * Description: Sistem cache full-page berdasarkan role. Intercept di awal (muplugins_loaded) dan sinkronisasi cookie role otomatis.
 * Version: 4.0 (Master)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. Definisikan direktori cache
define( 'MY_CUSTOM_CACHE_DIR', WP_CONTENT_DIR . '/my-page-cache/' );

/**
 * ==========================================
 * BAGIAN A: INTERCEPTOR CACHE (LOADING AWAL)
 * ==========================================
 */
function my_mu_early_cache_check() {
    
    // DAFTAR URI YANG TIDAK AKAN DI-CACHE
    $excluded_uris = array(
        '/current-role.php', 
        '/member/',
        '/wp-admin/',
        '/wp-login.php',
        '/cart/',
        '/checkout/',
        '/my-account/',
        '/api/',
    );

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
    
    // Cek pengecualian URI
    foreach ( $excluded_uris as $excluded_uri ) {
        if ( strpos( $request_uri, $excluded_uri ) !== false ) {
            return; // Batalkan cache, biarkan WordPress load normal
        }
    }

    // Jangan cache untuk POST, AJAX, Cron, REST API
    if ( ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] !== 'GET' ) ||
         ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ||
         ( defined( 'DOING_CRON' ) && DOING_CRON ) ||
         ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
        return;
    }
    // --- VALIDASI USER & GENERATE NAMA FILE ---
    $uri = strtok( $request_uri, '?' ); 
    
    $roles = 'guest';
    $has_wp_login_cookie = false;
    
    // Cek cookie login WordPress asli
    foreach ( $_COOKIE as $key => $value ) {
        if ( strpos( $key, 'wordpress_logged_in_' ) === 0 ) {
            $has_wp_login_cookie = true;
            break;
        }
    }

    // Jika ada cookie login WP DAN ada cookie custom role, gunakan role tersebut
    if ( $has_wp_login_cookie && isset( $_COOKIE['my_site_role'] ) && ! empty( $_COOKIE['my_site_role'] ) ) {
        $roles = sanitize_text_field( $_COOKIE['my_site_role'] );
    }

    $cache_filename = md5( $uri ) . '_' . $roles . '.html';
    $cache_filepath = MY_CUSTOM_CACHE_DIR . $cache_filename;

    // --- CEK & SAJIKAAN CACHE ---
    if ( file_exists( $cache_filepath ) ) {
        header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
        header( 'X-Cache-Status: HIT' );
        
        readfile( $cache_filepath );
        
        // PENTING: exit di sini. Sisa kode di bawah file ini TIDAK akan dieksekusi.
        // Ini TIDAK masalah karena jika cache HIT, user tidak sedang login/logout.
        exit; 
    }

    // --- MULAI OUTPUT BUFFER ---
    header( 'X-Cache-Status: MISS' );
    ob_start();

    global $my_mu_cache_filepath;
    $my_mu_cache_filepath = $cache_filepath;

    add_action( 'shutdown', 'my_mu_save_cache_on_shutdown', 999 );
}
// Hook paling awal
add_action( 'muplugins_loaded', 'my_mu_early_cache_check', 1 );


/**
 * ==========================================
 * BAGIAN B: MENYIMPAN CACHE (SHUTDOWN) * ==========================================
 */
function my_mu_save_cache_on_shutdown() {
    global $my_mu_cache_filepath;

    if ( empty( $my_mu_cache_filepath ) ) return;

    if ( ob_get_level() > 0 ) {
        $html_output = ob_get_clean();

        if ( ! is_dir( MY_CUSTOM_CACHE_DIR ) ) {
            wp_mkdir_p( MY_CUSTOM_CACHE_DIR );
        }

        if ( ! empty( $html_output ) && strpos( $html_output, '<html' ) !== false ) {
            file_put_contents( $my_mu_cache_filepath, $html_output );
        }

        echo $html_output;
    }
}


/**
 * ==========================================
 * BAGIAN C: MEMBERSIHKAN CACHE (INVALIDATION)
 * ==========================================
 */
function my_mu_clear_page_cache_on_save( $post_id ) {
    if ( wp_is_post_revision( $post_id ) || get_post_status( $post_id ) === 'auto-draft' ) {
        return;
    }

    if ( is_dir( MY_CUSTOM_CACHE_DIR ) ) {
        $files = glob( MY_CUSTOM_CACHE_DIR . '*.html' );
        if ( ! empty( $files ) ) {
            foreach ( $files as $file ) {
                if ( is_file( $file ) ) {
                    unlink( $file );
                }
            }
        }
    }
}
add_action( 'save_post', 'my_mu_clear_page_cache_on_save' );


/**
 * ==========================================
 * BAGIAN D: SINKRONISASI COOKIE ROLE * (Hook ini didaftarkan di sini, tapi baru dieksekusi nanti saat user login/logout)
 * ==========================================
 */

// 1. Set cookie saat login
add_action( 'set_logged_in_cookie', 'my_sync_role_cookie_on_login', 10, 4 );
function my_sync_role_cookie_on_login( $logged_in_cookie, $expire, $expiration, $user_id ) {
    $user = get_userdata( $user_id );
    
    if ( $user && ! empty( $user->roles ) ) {
        $role_string = implode( '_', (array) $user->roles );
        
        // Set cookie (httponly = true untuk keamanan)
        setcookie( 'my_site_role', $role_string, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        $_COOKIE['my_site_role'] = $role_string;
    }
}

// 2. Hapus cookie saat logout
add_action( 'wp_logout', 'my_clear_role_cookie_on_logout' );
function my_clear_role_cookie_on_logout() {
    if ( isset( $_COOKIE['my_site_role'] ) ) {
        setcookie( 'my_site_role', ' ', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        unset( $_COOKIE['my_site_role'] );
    }
}

// 3. Update cookie jika admin mengubah role user dari dashboard
add_action( 'profile_update', 'my_update_role_cookie_on_profile_update', 10, 2 );
function my_update_role_cookie_on_profile_update( $user_id, $old_user_data ) {
    if ( get_current_user_id() == $user_id ) {
        $user = get_userdata( $user_id );
        if ( $user && ! empty( $user->roles ) ) {
            $role_string = implode( '_', (array) $user->roles );
            $expire = time() + YEAR_IN_SECONDS; 
            setcookie( 'my_site_role', $role_string, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
            $_COOKIE['my_site_role'] = $role_string;
        }
    }
}