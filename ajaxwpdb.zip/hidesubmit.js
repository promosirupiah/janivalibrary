jQuery(document).ready(function(){
jQuery('#fromapprove button.jet-form-builder__submit.submit-type-ajax').on('click', function() {
    jQuery(this).hide(500);
});
})
