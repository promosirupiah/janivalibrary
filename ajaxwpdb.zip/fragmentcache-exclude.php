<?php
/**
* Plugin Name: Custom Role & URI Fragment Cache
* Description: Plugin fragment caching berdasarkan User Role dan URI dengan struktur folder custom.
* Version:     1.3.0
* Author:      AI Collaborator
* License:     GPL2
*/

// Keluar jika diakses langsung di luar WordPress
if (!defined('ABSPATH')) {
    exit;
}

/**
* Helper: Cek apakah URI saat ini ada di dalam daftar exclude
* Mendukung wildcard (*) untuk pencocokan pola
*/
function is_uri_excluded($current_uri_path, $exclude_uris) {
    if (empty($exclude_uris) || !is_array($exclude_uris)) {
        return false;
    }

    foreach ($exclude_uris as $pattern) {
        $pattern = trim($pattern);
        if (empty($pattern)) continue;

        // Ubah pola wildcard menjadi regex
        // Contoh: /member/* -> ^\/member\/.*$
        $regex = '/^' . str_replace('\*', '.*', preg_quote($pattern, '/')) . '$/i';

        if (preg_match($regex, $current_uri_path)) {
            return true;
        }
    }
    return false;
}

/**
* 1. FUNGSI UTAMA (Versi Fungsi PHP)
* 
* @param callable $dosemething   Fungsi anonim berisi konten/HTML murni
* @param string   $name          Nama unik grup cache
* @param string   $folder        Nama induk folder di dalam /wp-content/cache/
* @param bool     $use_uri       Apakah cache dipisah per alamat URL halaman
* @param bool     $use_role      Apakah cache dipisah berdasarkan role user
* @param int      $ttl           Masa berlaku cache dalam detik (-1 untuk UNLIMITED)
* @param array    $exclude_uris  Array daftar URI yang tidak boleh di-cache (BYPASS)
*/
function handleAdvancedCacheFunc($dosemething, $name, $folder = 'madxcache', $use_uri = false, $use_role = true, $ttl = 3600, $exclude_uris = array()) {
    
    // ============================================================
    // CEK EXCLUDE URI (BYPASS CACHE)
    // ============================================================
    if (!empty($exclude_uris)) {
        // Ambil path URL saja (tanpa query string seperti ?id=123)
        $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        if (is_uri_excluded($uri_path, $exclude_uris)) {
            // Jika URI termasuk dalam daftar exclude, langsung jalankan fungsi tanpa caching
            if (is_callable($dosemething)) {
                $dosemething();
            } else {
                echo "Error: Argumen pertama harus berupa fungsi yang valid.";
            }
            return;
        }
    }

    // 1. Tentukan user role (jika diaktifkan)
    $user_role = '';
    if ($use_role) {
        $user_role = 'guest'; // Default
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            if (!empty($current_user->roles)) {
			$user_role = '';
               // $user_role = $current_user->roles[0];
			   foreach($current_user->roles as $user_all_role ){$user_role .= $user_all_role;}
            }
        }
    }
//cookies untuk early cache mu plugins	

        $expire = time() + YEAR_IN_SECONDS;
        setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        $_COOKIE['my_site_role'] = $user_role;
/* 
for mu early cache:
handleAdvancedCacheFunc(function(){ //start cache // }, 'complete', $folder = 'madxcache/'.$_SERVER['SERVER_NAME'], true, true, -1,array('/member/*'));
*/
		

    // 2. Logika penamaan file cache
    if ($use_uri) {
        $current_uri = $_SERVER['REQUEST_URI'];
        $filename_only = md5($current_uri . $user_role) . '.txt';
    } else {
        $filename_only = $use_role ? $user_role . '.txt' : 'global.txt';
    }

    // 3. Setup Jalur Direktori Baru: /wp-content/cache/{folder}/{name}/
    $base_cache_dir = WP_CONTENT_DIR . '/cache';
    $target_folder  = sanitize_title($folder);
    $target_name    = sanitize_title($name);
    $dirPath        = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename       = $dirPath . '/' . $filename_only;

    // ============================================================
    // CEK CACHE & TTL
    // ============================================================
    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            readfile($filename);
            return;
        }
    }

    // Jika folder belum ada, buat foldernya secara berjenjang (recursive)
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);
        // Proteksi keamanan di folder induk dan sub-folder
        file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
        file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }

    // Mulai proses Output Buffering
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();

    // Simpan dan Tampilkan
    file_put_contents($filename, $output);
    echo $output;
}

/* 
==========================================================================
CONTOH PENGGUNAAN FUNGSI PHP DI THEME/PLUGIN ANDA
==========================================================================

handleAdvancedCacheFunc(function() {
    ?>
    <div class="my-widget">
        <h3>Konten Dinamis</h3>
        <p>Ini akan di-cache kecuali di halaman member.</p>
    </div>
    <?php
}, 'widget_sidebar', 'madxcache', false, true, 3600, array(
    '/member/*',      // Exclude semua halaman di bawah /member/
    '/my-account',    // Exclude halaman spesifik /my-account
    '/checkout/*'     // Exclude semua halaman checkout
));

*/


/**
* 2. VERSI WORDPRESS SHORTCODE
* Atribut tambahan: 'folder', 'exclude'
*/
function handle_advanced_cache_shortcode($atts, $content = null) {
    $args = shortcode_atts(array(
        'name'    => 'default_cache',
        'folder'  => 'custom-cache', 
        'uri'     => 'false',
        'role'    => 'true',
        'ttl'     => '3600',
        'exclude' => '' // Parameter baru untuk exclude URI (dipisah koma)
    ), $atts);

    $name         = $args['name'];
    $folder       = $args['folder'];
    $use_uri      = filter_var($args['uri'], FILTER_VALIDATE_BOOLEAN);
    $use_role     = filter_var($args['role'], FILTER_VALIDATE_BOOLEAN);
    $ttl          = intval($args['ttl']);
    
    // Parsing string exclude menjadi array
    $exclude_uris = array();
    if (!empty($args['exclude'])) {
        $exclude_uris = array_map('trim', explode(',', $args['exclude']));
    }

    ob_start();
    
    // Memasukkan argumen $exclude_uris ke dalam fungsi utama
    handleAdvancedCacheFunc(function() use ($content) {
        echo do_shortcode($content);
    }, $name, $folder, $use_uri, $use_role, $ttl, $exclude_uris);
    
    return ob_get_clean();
}
add_shortcode('advanced_cache', 'handle_advanced_cache_shortcode');

/* 
==========================================================================
CONTOH PENGGUNAAN SHORTCODE DI POST/PAGE/WIDGET
==========================================================================

[advanced_cache name="sidebar_widget" folder="madxcache" exclude="/member/*, /my-account"]
    <p>Konten ini akan di-cache, KECUALI jika user berada di halaman /member/* atau /my-account.</p>
[/advanced_cache]

*/

add_action( 'set_logged_in_cookie', 'my_sync_role_cookie_on_login', 10, 4 );
function my_sync_role_cookie_on_login( $logged_in_cookie, $expire, $expiration, $user_id ) {
    $user = get_userdata( $user_id );
    
    if ( $user && ! empty( $user->roles ) ) {
                    if (!empty($current_user->roles)) {
			$user_role = '';
               // $user_role = $current_user->roles[0];
			   foreach($current_user->roles as $user_all_role ){$user_role .= $user_all_role;}
            }
        
        // Set cookie (httponly = true untuk keamanan)
        setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        $_COOKIE['my_site_role'] = $user_role;
    }
}

// 2. Hapus cookie saat logout
add_action( 'wp_logout', 'my_clear_role_cookie_on_logout' );
function my_clear_role_cookie_on_logout() {
    if ( isset( $_COOKIE['my_site_role'] ) ) {
        setcookie( 'my_site_role', ' ', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        unset( $_COOKIE['my_site_role'] );
    }
}

// 3. Update cookie jika admin mengubah role user dari dashboard
add_action( 'profile_update', 'my_update_role_cookie_on_profile_update', 10, 2 );
function my_update_role_cookie_on_profile_update( $user_id, $old_user_data ) {
    if ( get_current_user_id() == $user_id ) {
        $user = get_userdata( $user_id );
        if ( $user && ! empty( $user->roles ) ) {
           		$user_role = '';
               // $user_role = $current_user->roles[0];
			   foreach($current_user->roles as $user_all_role ){$user_role .= $user_all_role;}
            $expire = time() + YEAR_IN_SECONDS; 
            setcookie( 'my_site_role', $user_role, $expire, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
            $_COOKIE['my_site_role'] = $user_role;
        }
    }
}