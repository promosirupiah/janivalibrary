<?php
/**
 * Plugin Name: Custom Role & URI Fragment Cache
 * Description: Plugin fragment caching berdasarkan User Role dan URI dengan struktur folder custom.
 * Version:     1.2.0
 * Author:      AI Collaborator
 * License:     GPL2
 */

// Keluar jika diakses langsung di luar WordPress
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1. FUNGSI UTAMA (Versi Fungsi PHP)
 * * @param callable $dosemething Fungsi anonim berisi konten/HTML murni (bisa tutup-buka PHP)
 * @param string   $name        Nama unik grup cache (nama sub-folder kedua)
 * @param string   $folder      Nama induk folder di dalam /wp-content/cache/ (nama sub-folder pertama)
 * @param bool     $use_uri     Apakah cache dipisah per alamat URL halaman (default: false)
 * @param bool     $use_role    Apakah cache dipisah berdasarkan role user (default: true)
 * @param int      $ttl         Masa berlaku cache dalam detik. Set ke -1 untuk UNLIMITED (default: 3600)
 */
function handleAdvancedCacheFunc($dosemething, $name, $folder = 'custom-cache', $use_uri = false, $use_role = true, $ttl = 3600) {
    // 1. Tentukan user role (jika diaktifkan)
    $user_role = '';
    if ($use_role) {
        $user_role = 'guest'; // Default
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            if (!empty($current_user->roles)) {
                $user_role = $current_user->roles[0]; 
            }
        }
    }
    
    // 2. Logika penamaan file cache
    if ($use_uri) {
        $current_uri = $_SERVER['REQUEST_URI'];
        $filename_only = md5($current_uri . $user_role) . '.txt';
    } else {
        $filename_only = $use_role ? $user_role . '.txt' : 'global.txt';
    }
    
    // 3. Setup Jalur Direktori Baru: /wp-content/cache/{folder}/{name}/
    $base_cache_dir = WP_CONTENT_DIR . '/cache';
    $target_folder  = sanitize_title($folder);
    $target_name    = sanitize_title($name);
    
    $dirPath  = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename = $dirPath . '/' . $filename_only;
    
    // ============================================================
    // CEK CACHE & TTL
    // ============================================================
    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            readfile($filename);
            return;
        }
    }
    
    // Jika folder belum ada, buat foldernya secara berjenjang (recursive)
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);
        // Proteksi keamanan di folder induk dan sub-folder
        file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
        file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }
    
    // Mulai proses Output Buffering
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();
    
    // Simpan dan Tampilkan
    file_put_contents($filename, $output);
    echo $output;
}

/**
 * 2. VERSI WORDPRESS SHORTCODE
 * Atribut tambahan: 'folder'
 */
function handle_advanced_cache_shortcode($atts, $content = null) {
    $args = shortcode_atts(array(
        'name'   => 'default_cache',
        'folder' => 'custom-cache', // Parameter folder baru
        'uri'    => 'false',
        'role'   => 'true',
        'ttl'    => '3600'
    ), $atts);
    
    $name     = $args['name'];
    $folder   = $args['folder'];
    $use_uri  = filter_var($args['uri'], FILTER_VALIDATE_BOOLEAN);
    $use_role = filter_var($args['role'], FILTER_VALIDATE_BOOLEAN);
    $ttl      = intval($args['ttl']);
    
    ob_start();
    
    // Memasukkan argumen $folder ke dalam fungsi utama
    handleAdvancedCacheFunc(function() use ($content) {
        echo do_shortcode($content);
    }, $name, $folder, $use_uri, $use_role, $ttl);
    
    return ob_get_clean();
}
add_shortcode('advanced_cache', 'handle_advanced_cache_shortcode');
