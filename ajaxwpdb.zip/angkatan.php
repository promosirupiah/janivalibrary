<?php

function handleAngkatanCacheFunc($dosemething, $name, $folder = 'madxcache', $use_uri = false, $use_role = false, $ttl = 3600) {


    $user_role = '';

    
    // 2. Logika penamaan file cache
    if ($use_uri) {
        $current_uri = $_SERVER['REQUEST_URI'];
        $filename_only = md5($current_uri). $user_role . '.txt';
    } else {
        $filename_only = $use_role ? $user_role . '.txt' : 'global.txt';
    }
    
    // 3. Setup Jalur Direktori Baru: /wp-content/cache/{folder}/{name}/
    $base_cache_dir = 'wp-content/cache';
    $target_folder  = $folder;
    $target_name    = $name;
    
    $dirPath  = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename = $dirPath . '/' . $filename_only;
    
    // ============================================================
    // CEK CACHE & TTL
    // ============================================================
    if (file_exists($filename)) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            readfile($filename);
            return;
        }
    }
    
    // Jika folder belum ada, buat foldernya secara berjenjang (recursive)
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);

    }

    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo "Error: Argumen pertama harus berupa fungsi yang valid.";
    }
    $output = ob_get_clean();
    
    // Simpan dan Tampilkan
    file_put_contents($filename, $output);
    echo $output;
}

handleAngkatanCacheFunc(function(){
define('SHORTINIT', true);
require_once('./wp-load.php');

global $wpdb, $table_prefix;
if (isset($_REQUEST['action'])){
if( $_REQUEST['action'] == 'madx_gff_fetch_angkatan'){
$wp_madx_angkatan = $table_prefix.'pods_angkatan';
if(isset($_REQUEST['madxname'])){
$angkatan_name = esc_sql(sanitize_text_field($_REQUEST['madxname']));
}
if (isset($_REQUEST['madxname'])){
$query = "SELECT `name`  FROM `$wp_madx_angkatan` WHERE `name` LIKE '%".$angkatan_name."%'  ORDER BY `name`;";
}
else{
$query = "SELECT `name` FROM `".$wp_madx_angkatan."` ORDER BY `name`;";
}
$angkatan = $wpdb->get_results($query);
echo json_encode($angkatan);
}// end madx_gff_fetch_angkatan


} // $_REQUEST['action']
}, 'angkatan', 'madxcache',true, false, -1)
?>