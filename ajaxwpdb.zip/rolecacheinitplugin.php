<?php
/**
 * Plugin Name: Early Page Cache with Role Support
 * Description: Sistem cache halaman full-page berdasarkan URI dan Role User. Menggunakan hook 'init' untuk akurasi role real-time.
 * Version: 2.0
 */

// Pastikan file ini diakses langsung dari WordPress
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. Definisikan direktori untuk menyimpan file cache
define( 'MY_CUSTOM_CACHE_DIR', WP_CONTENT_DIR . '/my-page-cache/' );

/**
 * A. FUNGSI UTAMA: CEK CACHE & MULAI BUFFER
 * Menggunakan hook 'init' agar fungsi wp_get_current_user() sudah aman digunakan.
 */
function my_mu_early_cache_check() {
    
    // ==========================================
    // DAFTAR URI YANG TIDAK AKAN DI-CACHE
    // ==========================================
    $excluded_uris = array(
        '/member/',
        '/wp-admin/',
        '/wp-login.php',
        '/cart/',
        '/checkout/',
        '/my-account/',
        '/api/',
    );

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
    
    // Cek apakah URI saat ini mengandung salah satu string di dalam array $excluded_uris
    foreach ( $excluded_uris as $excluded_uri ) {
        if ( strpos( $request_uri, $excluded_uri ) !== false ) {
            return; // URI ditemukan di daftar pengecualian, batalkan proses cache.
        }
    }

    // Jangan cache untuk POST request, AJAX, Cron, REST API
    if ( ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] !== 'GET' ) ||
         ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ||
         ( defined( 'DOING_CRON' ) && DOING_CRON ) ||
         ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
        return;
    }

    // --- 2. GENERATE NAMA FILE CACHE ---
    $uri = strtok( $request_uri, '?' ); // Hapus query string agar cache tidak dobel
    
    // Ambil role user secara real-time menggunakan fungsi bawaan WordPress
    $roles = 'guest';
    if ( function_exists( 'wp_get_current_user' ) ) {
        $user = wp_get_current_user();
        if ( $user->exists() && ! empty( $user->roles ) ) {
            // Gabungkan semua role jika user punya lebih dari 1 role (misal: editor_author)
            $roles = implode( '_', (array) $user->roles );
        }
    }

    // Format nama file: md5(uri)_role.html
    $cache_filename = md5( $uri ) . '_' . $roles . '.html';
    $cache_filepath = MY_CUSTOM_CACHE_DIR . $cache_filename;

    // --- 3. CEK & SAJIKAAN CACHE (JIKA ADA) ---
    if ( file_exists( $cache_filepath ) ) {
        // Kirim header agar browser tahu ini file HTML
        header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
        header( 'X-Cache-Status: HIT' );
        
        readfile( $cache_filepath );
        exit; // MATIKAN WORDPRESS SELANJUTNYA. Plugin lain & Theme tidak akan di-render!
    }

    // --- 4. MULAI OUTPUT BUFFER (JIKA TIDAK ADA CACHE) ---
    header( 'X-Cache-Status: MISS' );
    ob_start();

    // Simpan path file ke global variable agar bisa dibaca di hook shutdown
    global $my_mu_cache_filepath;
    $my_mu_cache_filepath = $cache_filepath;

    // Daftarkan hook shutdown untuk menyimpan cache nanti
    add_action( 'shutdown', 'my_mu_save_cache_on_shutdown', 999 );
}
// Hook 'init' dengan prioritas 1 (sangat awal di siklus init)
add_action( 'init', 'my_mu_early_cache_check', 1 );


/**
 * B. FUNGSI MENUTUP BUFFER & MENYIMPAN FILE
 * Dijalankan di hook 'shutdown' (akhir siklus WordPress).
 */
function my_mu_save_cache_on_shutdown() {
    global $my_mu_cache_filepath;

    // Jika global variable kosong, berarti halaman ini di-exclude atau cache hit
    if ( empty( $my_mu_cache_filepath ) ) {
        return;
    }

    // Pastikan buffer aktif
    if ( ob_get_level() > 0 ) {
        $html_output = ob_get_clean(); // Ambil isi buffer dan bersihkan

        // Pastikan direktori cache ada dan bisa ditulis
        if ( ! is_dir( MY_CUSTOM_CACHE_DIR ) ) {
            wp_mkdir_p( MY_CUSTOM_CACHE_DIR );
        }

        // Simpan HTML ke dalam file
        // Pengecekan tambahan: Pastikan output tidak kosong dan merupakan halaman HTML valid
        if ( ! empty( $html_output ) && strpos( $html_output, '<html' ) !== false ) {
            file_put_contents( $my_mu_cache_filepath, $html_output );
        }

        // Cetak kembali HTML ke browser
        echo $html_output;
    }
}


/**
 * C. FUNGSI MEMBERSIHKAN CACHE (INVALIDATION)
 * PENTING: Cache harus dihapus saat ada konten yang diupdate!
 */
function my_mu_clear_page_cache_on_save( $post_id ) {
    // Hanya jalankan jika bukan revisi dan bukan auto-draft
    if ( wp_is_post_revision( $post_id ) || get_post_status( $post_id ) === 'auto-draft' ) {
        return;
    }

    // Hapus semua file di dalam direktori cache
    if ( is_dir( MY_CUSTOM_CACHE_DIR ) ) {
        $files = glob( MY_CUSTOM_CACHE_DIR . '*.html' );
        if ( ! empty( $files ) ) {
            foreach ( $files as $file ) {
                if ( is_file( $file ) ) {
                    unlink( $file );
                }
            }
        }
    }
}
// Hook ini akan membersihkan semua cache setiap kali ada post/page yang di-publish atau di-update
add_action( 'save_post', 'my_mu_clear_page_cache_on_save' );