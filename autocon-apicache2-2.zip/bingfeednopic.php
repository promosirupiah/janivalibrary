
<?php 
require_once './magpie/rss_fetch.inc';

$url = 'http://www.bing.com/search?q='.urlencode($termstring).urlencode($addsearch).'&form=OSDSRC&format=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>
<div class="post">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($item['title'])).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
echo '<br style="clear:both"><p>'.clean_desc($item['description']).'</p><br style="clear:both">';
?>
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($item['link']) ?>">read more</a>
</div>
<?php } ?>


