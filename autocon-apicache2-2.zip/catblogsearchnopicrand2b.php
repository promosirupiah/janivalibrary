<div class="post">
<?php 
require_once './magpie/rss_fetch.inc';
$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).urlencode($addsearch).'&ie=utf-8&num=20&output=rss';
$rss = fetch_rss($url);
if ($rss) {
foreach ( $rss->items as $item ) { ?>

<?php
$gblogtittles[] = '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
if (rand(0,4)== 0 ) {
$gbdescs .= '</p>'.clean_desc(ucfirst($item['description'])).'<p>';
} else {$gbdescs .= clean_desc(ucfirst($item['description']));}
 } ?>

<?php 
echo '<p>'.clean_desc($gbdescs).'</p>';
foreach (array_unique($gblogtittles) as $gbtitles) {
echo $gbtitles;
}
}
?>
</div>
