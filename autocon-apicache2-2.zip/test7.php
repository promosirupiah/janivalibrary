<?php
require_once './magpie/rss_fetch.inc';
require_once('./simple_html_dom.php');
require_once ('./Readability.php');


$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; U; Linux i686; en-US) AppleWebKit/532.4 (KHTML, like Gecko) Chrome/4.0.237.0 Safari/532.4 Debian");
//curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729)");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $_REQUEST['u']);
$response = curl_exec($ch);



//domain check for known unhandle website
//$domainscheck[]='youtube.com';
//$domainscheck[]='google.com';
//$domainscheck[]='facebook.com';
//$domainscheck[]='twitter.com';
//$domainscheck[]='launchpad.net';


$exceptextension[]='.rpm';
$exceptextension[]='.pdf';
$exceptextension[]='.sig';
$exceptextension[]='.spl';
$exceptextension[]='.class';
$exceptextension[]='.torrent';
$exceptextension[]='.dvi';
$exceptextension[]='.gz';
$exceptextension[]='.pac';
$exceptextension[]='.swf';
$exceptextension[]='.tar.gz';
$exceptextension[]='.tgz';
$exceptextension[]='.tar';
$exceptextension[]='.zip';
$exceptextension[]='.mp3';
$exceptextension[]='.m3u';
$exceptextension[]='.wma';
$exceptextension[]='.wax';
$exceptextension[]='.ogg';
$exceptextension[]='.wav';
$exceptextension[]='.gif';
$exceptextension[]='.jar';
$exceptextension[]='.jpg';
$exceptextension[]='.jpeg';
$exceptextension[]='.png';
$exceptextension[]='.xbm';
$exceptextension[]='.xpm';
$exceptextension[]='.xwd';
$exceptextension[]='.css';
$exceptextension[]='.js';
$exceptextension[]='.asc';
$exceptextension[]='.cpp';
$exceptextension[]='.log';
$exceptextension[]='.conf';
$exceptextension[]='.text';
$exceptextension[]='.txt';
$exceptextension[]='.dtd';
$exceptextension[]='.xml';
$exceptextension[]='.mpeg';
$exceptextension[]='.mpg';
$exceptextension[]='.mov';
$exceptextension[]='.qt';
$exceptextension[]='.exe';
//$exceptextension[]='https://';
//$exceptextension[]='ftp://';
$exceptextension[]='#';
$exceptextension[]='mailto:';
$exceptextension[]='skype:';
$exceptextension[]='javascript:';
$maindomain = $_REQUEST['u'];
if (strpos($_REQUEST['u'],'http://') !== false){$serverdomain = 'http://';}
if (strpos($_REQUEST['u'],'https://') !== false){$serverdomain = 'https://';}
if (strpos($_REQUEST['u'],'ftp://') !== false){$serverdomain = 'ftp://';}


$maindomain = str_ireplace('http://','',$maindomain);
$maindomain = str_ireplace('https://','',$maindomain);
$maindomain = str_ireplace('ftp://','',$maindomain);
$maindomainx = explode("/",$maindomain);
$maindomain = $maindomainx[0];


//foreach ($domainscheck as $domaincheck){
//$exception = false;
//$pos = stripos($_REQUEST['u'],$domaincheck);
//if ($pos !== false)$domainexception = true;
//}


if ($domainexception != true){

$html = str_get_html($response);
$hrefcount = 0;
foreach ($html->find('a') as $alink) {
$exception = false;
foreach ($exceptextension as $except) {
$pos = strpos($alink->href,$except);
if ($pos !== false)$exception = true;
}
if ($exception != true){

if (strpos($alink->href,'://') == false && $alink->href !== false){
if (strpos($alink->href,'/') == 0){$html->find('a',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,$maindomain) !== false){$html->find('a',$hrefcount)->href = $alink->href; } 
else {$html->find('a',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}

$html->find('a',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test7.php?u='.urlencode($alink->href);
}
else {
if (strpos($alink->href,'://') == false && $alink->href !== false){
if (strpos($alink->href,'/') == 0){$html->find('a',$hrefcount)->href = $serverdomain.$maindomain.$alink->href; }
else if (strpos($alink->href,$maindomain) !== false){$html->find('a',$hrefcount)->href = $alink->href; } 
else {$html->find('a',$hrefcount)->href = $serverdomain.$maindomain.'/'.$alink->href; }
}

$html->find('a',$hrefcount)->target = "_blank"; $html->find('a',$hrefcount)->rel = "nofollow";}


$hrefcount = $hrefcount + 1;
}

$hrefcount = 0;
foreach ($html->find('script') as $ascript){ 
if (strpos($ascript->src,'://') == false && $ascript->src !== false){
if (strpos($ascript->src,'/') == 0){$html->find('script',$hrefcount)->src = $serverdomain.$maindomain.$ascript->src; }
else if (strpos($ascript->src,$maindomain) !== false){$html->find('script',$hrefcount)->src = $ascript->src; } 
else {$html->find('script',$hrefcount)->src = $serverdomain.$maindomain.'/'.$ascript->src; }
}
$hrefcount = $hrefcount + 1;}

$hrefcount = 0;
foreach ($html->find('link') as $ascript){ 
if (strpos($ascript->href,'://') == false && $ascript->href !== false){
if (strpos($ascript->href,'/') == 0){$html->find('link',$hrefcount)->href = $serverdomain.$maindomain.$ascript->href; }
else if (strpos($ascript->href,$maindomain) !== false){$html->find('link',$hrefcount)->href = $ascript->href; } 
else {$html->find('link',$hrefcount)->href = $serverdomain.$maindomain.'/'.$ascript->href; }
}
$hrefcount = $hrefcount + 1;}

$hrefcount = 0;
foreach ($html->find('form') as $ascript){ 
if (strpos($ascript->action,'://') == false && $ascript->action !== false){
if (strpos($ascript->action,'/') == 0){$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.$ascript->action; }
else if (strpos($ascript->action,$maindomain) !== false){$html->find('form',$hrefcount)->action = $ascript->action; } 
else {$html->find('form',$hrefcount)->action = $serverdomain.$maindomain.'/'.$ascript->action; }
}
$hrefcount = $hrefcount + 1;}

$hrefcount = 0;
foreach ($html->find('img') as $ascript){ 
if (strpos($ascript->src,'://') == false && $ascript->src !== false){
if (strpos($ascript->src,'/') == 0 ){$html->find('img',$hrefcount)->src = $serverdomain.$maindomain.$ascript->src; }
else if (strpos($ascript->src,$maindomain) !== false){$html->find('img',$hrefcount)->src = $ascript->src; } 
else {$html->find('img',$hrefcount)->src = $serverdomain.$maindomain.'/'.$ascript->src; }
}
$hrefcount = $hrefcount + 1;}

$hrefcount = 0;
foreach ($html->find('embed') as $ascript){ 
if (strpos($ascript->src,'://') == false && $ascript->src !== false){
if (strpos($ascript->src,'/') == 0){$html->find('embed',$hrefcount)->src = $serverdomain.$maindomain.$ascript->src; }
else if (strpos($ascript->src,$maindomain) !== false){$html->find('embed',$hrefcount)->src = $ascript->src; } 
else {$html->find('embed',$hrefcount)->src = $serverdomain.$maindomain.'/'.$ascript->src; }
}
$hrefcount = $hrefcount + 1;}

//foreach ($html->find('link') as $link){echo $link->outertext;}
//echo $html->find('div',0)->outertext; 
//echo $html->find('div',1)->outertext;
$html->find('head title',0)->outertext = '';
echo $html->find('head',0)->innertext;
echo $html->find('body',0)->innertext; 

$html->clear(); 
unset($html);
}

else { ?>
<script type="text/javascript">
window.location = "http://<?php echo $_SERVER["SERVER_NAME"]; ?>"
</script>

<?php }

?>