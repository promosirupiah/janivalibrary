<?php
header('Content-Type: text/xml; charset=UTF-8', true);
function hilangkan_spesial_karakter($result) { //fungsi hilangkan semua spesial karakter pada Title
	$result = strip_tags($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', ' ', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
	$result = preg_replace('|-+|', ' ', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
		$result = str_replace(array('    ','   ','  '), ' ', $result);
	$result = trim($result, ' ');
	return $result;
}
function ubah_tanda($result) { //fungsi ubah spasi jadi plus pada permalink title
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
		$result = str_replace(array('----','---','--'), '-', $result);
	$result = trim($result, '-');
	return $result;
}
?>
<?php 
require_once './magpie/rss_fetch.inc';

$url=$_SERVER['QUERY_STRING'];
$rss = fetch_rss($url);
?>
<?php echo '<?xml version="1.0" encoding="UTF-8"'.'?'.'>'; ?>

<rss version="2.0" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">
<channel><title><?php echo str_replace('Google Blog Search','',htmlentities($rss->channel['title'])); ?></title><link><?php echo 'http://'.$_SERVER["SERVER_NAME"];?></link><description><?php echo str_replace('Google Blog Search Results:','',$rss->channel['description']);?></description>
<?php foreach ( $rss->items as $item ) { 
$item['title']= str_replace(array('<b>','</b>','...','..'),'',$item['title']);
$item['description']= str_replace(array('<b>','</b>','...','..'),'',$item['description']);
?>
<item><title><?php echo $item['title']; ?></title><pubDate><?php if ($item['pubdate'] == '') {echo $item['dc']['date'];} else {echo $item['pubdate'];}; ?></pubDate><link><?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(urlencode($item['title']));?></link><description><?php echo hilangkan_spesial_karakter($item['description']); ?></description><dc:publisher><?php echo $item['dc']['publisher']; ?></dc:publisher><dc:creator><?php echo $item['dc']['creator']; ?></dc:creator><dc:date><?php echo $item['dc']['date']; ?></dc:date></item>
<?php } ?>
</channel></rss>