<?php
$ping_urls[] = 'http://api.moreover.com/RPC2';
$ping_urls[] = 'http://bblog.com/ping.php';
$ping_urls[] = 'http://blogsearch.google.com/ping/RPC2';
$ping_urls[] = 'http://ping.weblogalot.com/rpc.php';
$ping_urls[] = 'http://ping.feedburner.com';
$ping_urls[] = 'http://ping.syndic8.com/xmlrpc.php';
$ping_urls[] = 'http://ping.bloggers.jp/rpc/';
$ping_urls[] = 'http://rpc.pingomatic.com/';
$ping_urls[] = 'http://rpc.weblogs.com/RPC2';
$ping_urls[] = 'http://rpc.technorati.com/rpc/ping';
$ping_urls[] = 'http://topicexchange.com/RPC2';
$ping_urls[] = 'http://www.blogpeople.net/servlet/weblogUpdates';
$ping_urls[] = 'http://xping.pubsub.com/ping';




$weblog_name = $posters[$counter]['title'];
$weblog_url = $posters[$counter]['url'];
$request = '<?xml version="1.0" encoding="iso-8859-1"?>'
.'<methodCall>'
.'<methodName>weblogUpdates.ping</methodName>'
.'<params>'
 .'<param>'
  .'<value>'
   .'<string>'.$weblog_name.'</string>'
  .'</value>'
 .'</param>'
 .'<param>'
  .'<value>'
  .'<string>'.$weblog_url.'</string>'
  .'</value>'
 .'</param>'
.'</params>'
.'</methodCall>';
$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, 
				array('Content-type: text/xml'
				, 'Content-length: '.strlen($request)
,'User-Agent: Mozilla/5.0 (Windows; U;
 Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729' ));
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $request); 

foreach ($ping_urls as $ping_url){
curl_setopt($ch, CURLOPT_URL, $ping_url);
$result = curl_exec($ch);
// echo $result;
}
curl_close($ch); 
?>
