<?php
require_once './magpie/rss_fetch.inc';
require_once('./simple_html_dom.php');


$url = 'http://'.$_SERVER["SERVER_NAME"].'/full-text-rss-master/makefulltextfeed.php?url='.urlencode($_REQUEST['u']).'&max=1&links=preserve&submit=Create+Feed';
$url = str_replace('%26amp%3B','%26',$url);


$rss = fetch_rss($url);
if ($rss) {
foreach ( $rss->items as $item ) {
$scrape = $item['description'];
}
}
$scrapecheck = stripos($scrape,'Sorry, Readability was unable to parse this page for content');
if ($scrapecheck == false){
$html = str_get_html($scrape);
$hrefcount = 0;
$exceptextension[]='.rpm';
$exceptextension[]='.pdf';
$exceptextension[]='.sig';
$exceptextension[]='.spl';
$exceptextension[]='.class';
$exceptextension[]='.torrent';
$exceptextension[]='.dvi';
$exceptextension[]='.gz';
$exceptextension[]='.pac';
$exceptextension[]='.swf';
$exceptextension[]='.tar.gz';
$exceptextension[]='.tgz';
$exceptextension[]='.tar';
$exceptextension[]='.zip';
$exceptextension[]='.mp3';
$exceptextension[]='.m3u';
$exceptextension[]='.wma';
$exceptextension[]='.wax';
$exceptextension[]='.ogg';
$exceptextension[]='.wav';
$exceptextension[]='.gif';
$exceptextension[]='.jar';
$exceptextension[]='.jpg';
$exceptextension[]='.jpeg';
$exceptextension[]='.png';
$exceptextension[]='.xbm';
$exceptextension[]='.xpm';
$exceptextension[]='.xwd';
$exceptextension[]='.css';
$exceptextension[]='.js';
$exceptextension[]='.asc';
$exceptextension[]='.cpp';
$exceptextension[]='.log';
$exceptextension[]='.conf';
$exceptextension[]='.text';
$exceptextension[]='.txt';
$exceptextension[]='.dtd';
$exceptextension[]='.xml';
$exceptextension[]='.mpeg';
$exceptextension[]='.mpg';
$exceptextension[]='.mov';
$exceptextension[]='.qt';
$exceptextension[]='.exe';
$exceptextension[]='launchpad.net';
$exceptextension[]='google.com';
$exceptextension[]='facebook.com';
$exceptextension[]='twitter.com';
$exceptextension[]='youtube.com';
$exceptextension[]='#';
$exceptextension[]='mailto:';
foreach ($html->find('a') as $alink) {
$exception = false;
foreach ($exceptextension as $except) {
$pos = strpos($alink->href,$except);
if ($pos !== false)$exception = true;
}
if ($exception != true){
$html->find('a',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test3.php?u='.urlencode($alink->href);}
else {$html->find('a',$hrefcount)->target = "_blank"; $html->find('a',$hrefcount)->rel = "nofollow";}
$hrefcount = $hrefcount + 1;

}
echo $html;

}
else { ?>
<iframe style="width:75%;height:500px;" src="<?php echo $_REQUEST['u']; ?>"/>
<?php }
$html->clear(); 
unset($html);
?>