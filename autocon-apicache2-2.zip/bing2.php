<?php
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_web_api.'&sources=web&Web.Count=6&query=' .urlencode($termstring).urlencode($addsearch); 
if (file_exists('apicache/bing_web_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_web_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/bing_web_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_web_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Web->Results as $value) 
{ 
$bposttittles .= '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($value->Title)).'">'.ucwords(CleanFileNameBan(ubah_space($value->Title))).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=6&query=' .urlencode($value->Title); 
if (file_exists('apicache/bing_img_'.ubah_tanda($value->Title).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_img_'.ubah_tanda($value->Title).'.txt')))
{
$response = file_get_contents('apicache/bing_img_'.ubah_tanda($value->Title).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_img_'.ubah_tanda($value->Title).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ 
$bimages .= '<a href="http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($content->Title)).'"><img alt="'.ucwords(CleanFileNameBan(ubah_space($content->Title))).'" title="'.ucwords(CleanFileNameBan(ubah_space($content->Title))).'"src="'.$content->MediaUrl.'"></a>||';
 } 
$bdescriptions .= $value->Description; 
$blinks .= '<a target=_blank rel="nofollow" href="http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$value->Url .'">read more</a>';

 } ?>
<div class="post">
<?php
echo clean_desc($bdescriptions).'<br style="clear:both;">';
echo $bposttittles;
$bimage = explode('||',$bimages);
$bimage = array_unique($bimage);
foreach ($bimage as $bimg){
echo $bimg;
}
?>
</div>