<div class="post">
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/video?v=1.0&rsz=1&key='.$google_video_api.'&q=' .urlencode($termstring); 
if (file_exists('apicache/g_vid_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/g_vid_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/g_vid_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_vid_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<h2><?php echo $content->title; ?></h2>

<object width="<?php echo $content->tbWidth;?>" height="<?php echo $content->tbHeight;?>">
<param name="movie" value="<?php echo $content->playurl; ?>"></param>
<param name="allowFullScreen" value="true"></param>
<param name="allowScriptAccess" value="always"></param>
<embed src="<?php echo $content->playUrl; ?>"
  type="application/x-shockwave-flash"
  allowfullscreen="true"
  allowscriptaccess="always"
  width="<?php echo $content->tbWidth;?>" height="<?php echo $content->tbHeight;?>">
</embed>
</object>
<br style="clear:both">
<p><?php echo $content->content; ?></p>
<br style="clear:both">
<?php } ?>
</div>

