
<?php 
require_once './magpie/rss_fetch.inc';

$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($main_title).urlencode($addsearch).'&ie=utf-8&num=50&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>
<div class="post">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
echo '<br style="clear:both"><p>'.clean_desc($item['description']).'</p><br style="clear:both">';
?>
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($item['link']) ?>">read more</a>
</div>
<?php } ?>


