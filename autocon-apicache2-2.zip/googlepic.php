<div class="post">
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=8&key='.$google_image_api.'&q=' .urlencode($termstring); 
if (file_exists('apicache/g_img_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/g_img_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/g_img_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_img_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($content->titleNoFormatting));?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))) ?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting))) ?> "src="<?php echo $content->unescapedUrl; ?>"></a>

<?php } ?>
</div>

