<?php
require_once './magpie/rss_fetch.inc';
require_once('./simple_html_dom.php');
require_once ('./Readability.php');


$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5 (.NET CLR 3.5.30729)");
curl_setopt($ch, CURLOPT_COOKIEJAR, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'x_cookies.txt');
curl_setopt($ch, CURLOPT_URL, $_REQUEST['u']);
$response = curl_exec($ch);



//domain check for known unhandle website
$domainscheck[]='youtube.com';
$domainscheck[]='google.com';
$domainscheck[]='facebook.com';
$domainscheck[]='twitter.com';
$domainscheck[]='launchpad.net';

$exceptextension[]='.rpm';
$exceptextension[]='.pdf';
$exceptextension[]='.sig';
$exceptextension[]='.spl';
$exceptextension[]='.class';
$exceptextension[]='.torrent';
$exceptextension[]='.dvi';
$exceptextension[]='.gz';
$exceptextension[]='.pac';
$exceptextension[]='.swf';
$exceptextension[]='.tar.gz';
$exceptextension[]='.tgz';
$exceptextension[]='.tar';
$exceptextension[]='.zip';
$exceptextension[]='.mp3';
$exceptextension[]='.m3u';
$exceptextension[]='.wma';
$exceptextension[]='.wax';
$exceptextension[]='.ogg';
$exceptextension[]='.wav';
$exceptextension[]='.gif';
$exceptextension[]='.jar';
$exceptextension[]='.jpg';
$exceptextension[]='.jpeg';
$exceptextension[]='.png';
$exceptextension[]='.xbm';
$exceptextension[]='.xpm';
$exceptextension[]='.xwd';
$exceptextension[]='.css';
$exceptextension[]='.js';
$exceptextension[]='.asc';
$exceptextension[]='.cpp';
$exceptextension[]='.log';
$exceptextension[]='.conf';
$exceptextension[]='.text';
$exceptextension[]='.txt';
$exceptextension[]='.dtd';
$exceptextension[]='.xml';
$exceptextension[]='.mpeg';
$exceptextension[]='.mpg';
$exceptextension[]='.mov';
$exceptextension[]='.qt';
$exceptextension[]='.exe';
$exceptextension[]='#';
$exceptextension[]='mailto:';

$maindomain = str_ireplace('http://','',$_REQUEST['u']);
$maindomainx = explode("/",$maindomain);
$maindomain = $maindomainx[0];


foreach ($domainscheck as $domaincheck){
$exception = false;
$pos = stripos($_REQUEST['u'],$domaincheck);
if ($pos !== false)$domainexception = true;
}


if ($domainexception != true){
$readability = new Readability($response, $url);
$readability->debug = false;
$readability->convertLinksToFootnotes = false;
$result = $readability->init();
if ($result) {
	
	$content = $readability->getContent()->innerHTML;
	// if we've got Tidy, let's clean it up for output
	if (function_exists('tidy_parse_string')) {
		$tidy = tidy_parse_string($content, array('indent'=>true, 'show-body-only' => true), 'UTF8');
		$tidy->cleanRepair();
		$content = $tidy->value;
	}
echo $content;
} 

else { 

$html = str_get_html($response);
$hrefcount = 0;
foreach ($html->find('a') as $alink) {
$exception = false;
foreach ($exceptextension as $except) {
$pos = strpos($alink->href,$except);
if ($pos !== false)$exception = true;
}
if ($exception != true){

$dmcheck = strpos($alink->href,'http://');
if ($dmcheck !== 0 ){$alink->href = 'http://'.$maindomain.$alink->href;}

$html->find('a',$hrefcount)->href = 'http://'.$_SERVER["SERVER_NAME"].'/test4.php?u='.urlencode($alink->href);
}
else {$html->find('a',$hrefcount)->target = "_blank"; $html->find('a',$hrefcount)->rel = "nofollow";}
$hrefcount = $hrefcount + 1;

}
echo $html;
$html->clear(); 
unset($html);
}
}

else { ?>
<script type="text/javascript">
window.location = "http://<?php echo $_SERVER["SERVER_NAME"]; ?>"
</script>

<?php }

?>