
<?php 
require_once './magpie/rss_fetch.inc';

$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).urlencode($addsearch).'&ie=utf-8&num=20&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>

<?php
$gblogtittles .= '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>'.'<a target=_blank rel="nofollow" href="http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($item['link']) .'">read more</a>';;
$gbdescs .= clean_desc($item['description']);
 } ?>
<div class="post">
<?php 
echo clean_desc($gbdescs);
echo $gblogtittles;

?>
</div>
