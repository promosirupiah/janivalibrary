<?php


$twitlogins[] = array ('username'=>'xxx','password'=>'xxx');
$twitlogins[] = array ('username'=>'xxx','password'=>'xxx');

foreach ($twitlogins as $twitlogin){
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1A543a Safari/419.3 ");
curl_setopt($ch, CURLOPT_COOKIEJAR, $twitlogin['username'].'_cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, $twitlogin['username'].'_cookies.txt');



curl_setopt($ch, CURLOPT_URL, 'https://mobile.twitter.com/session/new');
$response = curl_exec($ch);


$html = str_get_html($response);
$authz = $html->find('input[name="authenticity_token"]',0)->value;
$twitlogin['authenticity_token'] = $html->find('input[name="authenticity_token"]',0)->value;
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($twitlogin));
curl_setopt($ch, CURLOPT_URL, 'https://mobile.twitter.com/session');
$response = curl_exec($ch);
//echo $response;
$html = str_get_html($response);
$authz = $html->find('input[name="authenticity_token"]',0)->value;
foreach ($postings as $posting) {

$twitposter = array("authenticity_token" => $authz, "tweet[text]"=>$posting['url'].' '.$posting['title']);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($twitposter));
curl_setopt($ch, CURLOPT_URL, 'https://mobile.twitter.com/');
$response = curl_exec($ch);

}
$html->clear(); 
unset($html);
}
?>