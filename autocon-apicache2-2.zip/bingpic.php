<div class="post">
<?php
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=6&query=' .urlencode($termstring); 
if (file_exists('apicache/bing_img_'.ubah_tanda($termstring).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_img_'.ubah_tanda($termstring).'.txt')))
{
$response = file_get_contents('apicache/bing_img_'.ubah_tanda($termstring).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_img_'.ubah_tanda($termstring).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>

<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.ubah_tanda(CleanFileNameBan($content->Title));?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title))) ?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title))) ?>" src="<?php echo $content->MediaUrl; ?>"></a>


<?php } ?>
</div>