<?php


//multiple livejournal account
$ljcount .= 1;
$lj[$ljcount]['username'] = "xxx";
$lj[$ljcount]['password'] = "xxx";
$lj[$ljcount]['url'] = "http://www.livejournal.com";
$ljcount .= 1;
$lj[$ljcount]['username'] = "xxx";
$lj[$ljcount]['password'] = "xxx";
$lj[$ljcount]['url'] = "http://www.livejournal.com";

foreach ($lj as $ljx) {
$BLOGURL = $ljx['url'];
$USERNAME = $ljx['username'];
$PASSWORD = $ljx['password'];


  $title = $posters[$counter]['title'];
  $description = '<a href="'.$posters[$counter]['url'].'">'.$posters[$counter]['title'].'</a><br>'.$posters[$counter]['desc'];
  

$params = array("username" => $ljx['username'], "password" => $ljx['password'],
"event" => $description, "subject" => $title, "lineendings" => "unix",
"year" => date("Y"), "mon" => date("n"), "day" => date("j"), "hour" => date("G"), "min" => date("i"));
$request = xmlrpc_encode_request('LJ.XMLRPC.postevent', $params);
$xmlresponse = get_response($BLOGURL."/interface/xmlrpc", $request);

 $response = xmlrpc_decode($xmlresponse);
  /*Printing the response on to the console*/
 // print_r($response);
// echo "\n";

}
  ?>