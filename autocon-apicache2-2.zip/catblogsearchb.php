
<?php 
require_once './magpie/rss_fetch.inc';

$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).urlencode($addsearch).'&ie=utf-8&num=20&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>
<div class="post">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($item['title']))).'">'.ucwords(ubah_space(CleanFileNameBan($item['title']))).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode(CleanFileNameBan($item['title'])); 
if (file_exists('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt') && (time() - $apicachetime < filemtime('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt')))
{
$response = file_get_contents('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/bing_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($content->Title)));?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title)));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->Title)));?>" src="<?php echo $content->MediaUrl; ?>"></a>

<?php } ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode(CleanFileNameBan($item['title'])); 
if (file_exists('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt') && (time() - $apicachetime < filemtime('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt')))
{
$response = file_get_contents('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt');}
else {
$response = pete_curl_get($request, array());
$fcache = fopen('apicache/g_img_'.ubah_tanda(CleanFileNameBan($item['title'])).'.txt', 'w');
fwrite($fcache, $response);
fclose($fcache);
}
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/?q='.base64_encode(ubah_tanda(CleanFileNameBan($content->titleNoFormatting)));?>"><img alt="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting)));?>" title="<?php echo ucwords(CleanFileNameBan(ubah_space($content->titleNoFormatting)));?>" src="<?php echo $content->unescapedUrl; ?>"></a>

<?php } ?>
<?php
echo '<br style="clear:both"><p>'.clean_desc($item['description']).'</p><br style="clear:both">';
?>
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto2.php?'.base64_encode($item['link']) ?>">read more</a>
</div>
<?php } ?>


