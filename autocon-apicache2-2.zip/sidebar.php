<div id="sidebar">
<form name="myform" method="get" action="http://<?php echo $_SERVER["SERVER_NAME"] ?>/">
Search: <input type="text" name="s"><br>
<input type="submit" value="Submit">
</form> 
<?php foreach ($categories as $category) { ?>
<li><a href="http://<?php echo $_SERVER["SERVER_NAME"] ?>/<?php echo ubah_tanda($category) ?>"><?php echo ucwords($category) ?></a></li>
<?php } ?>
</div>
<div id="footer">
<a href="http://<?php echo $_SERVER["SERVER_NAME"] ?>/privacy-policy.html">Privacy Policy</a><br>
copyright <?php echo $_SERVER["SERVER_NAME"] ?>
</div>

