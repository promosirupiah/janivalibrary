<?php
//multiple wordpress account
$wpcount = 1;
$wp[$wpcount]['username'] = "xxx";
$wp[$wpcount]['password'] = "xxx";
$wp[$wpcount]['url'] = "http://xxx.wordpress.com";
$wpcount .= 1;
$wp[$wpcount]['username'] = "xxx";
$wp[$wpcount]['password'] = "xxx";
$wp[$wpcount]['url'] = "http://xxx.gblog.cl";



foreach ($wp as $wpx) {
$BLOGURL = $wpx['url'];
$USERNAME = $wpx['username'];
$PASSWORD = $wpx['password'];


  $title = $posters[$counter]['title'];
 $description = '<a href="'.$posters[$counter]['url'].'">'.$posters[$counter]['title'].'</a><br>'.$posters[$counter]['desc'];
 
  $content['title'] = $title;
  $content['description'] = $description;
  $content['categories'] = array("Blogging", "general");
  $toPublish = true;
  $request = xmlrpc_encode_request("metaWeblog.newPost",
    array(1,$USERNAME, $PASSWORD, $content, $toPublish));

  $xmlresponse = get_response($BLOGURL."/xmlrpc.php", $request);

 // $response = xmlrpc_decode($xmlresponse);
  /*Printing the response on to the console*/
 // print_r($response);
// echo "\n";

}
  ?>