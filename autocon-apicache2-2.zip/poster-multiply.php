<?php

$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);


$multiplyaccounts[] = array('multiplyurl' => 'http://xxx.multiply.com/api/post','multiplypassword' => 'xxx','multiplyapi' => 'xxx');
$multiplyaccounts[] = array('multiplyurl' => 'http://xxx.multiply.com/api/post','multiplypassword' => 'xxx','multiplyapi' => 'xxx');

//get multiply api from http://multiply.com/apis/developer-key

foreach ($multiplyaccounts as $multiplyaccount) {
$content = array("api_key" => $multiplyaccount['multiplyapi'],"password" => $multiplyaccount['multiplypassword'],"type" => "journal","subject" => $posters[$counter]['title'],"body" => '<a href="'.$posters[$counter]['url'].'">'.$posters[$counter]['title'].'</a> '.$posters[$counter]['desc']);
curl_setopt($ch, CURLOPT_URL, $multiplyaccount['multiplyurl']);

//posting journal
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($content));
$response = curl_exec($ch);

//posting notes
$contentnote = array("api_key" => $multiplyaccount['multiplyapi'],"password" => $multiplyaccount['multiplypassword'],"type" => "notes","subject" => $posters[$counter]['url']);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($contentnote));
$response = curl_exec($ch);
//echo $response;
}

?>