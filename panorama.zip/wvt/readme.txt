Change Log :

== 13.06.2023 - Version 1.2.1 ==
- [BUG] Add Error Handling Check.

== 18.07.2022 - Version 1.2.0 ==
- [IMPROVEMENT] Compatibility with WordPress 6
- [BUG] Fixed image issue on the tooltip

== 27.04.2022 - Version 1.1.0 ==
- [IMPROVEMENT] Compatibility with WordPress 5.9
- [IMPROVEMENT] Compatibility with PHP 8
- [IMPROVEMENT] Compatibility with WPBakery Page Builder 6.9
- [IMPROVEMENT] Compatibility with Elementor 3.6
- [IMPROVEMENT] Compatibility with WooCommerce 6.4
- [IMPROVEMENT] Add support and documentation link on plugin dashboard
- [IMPROVEMENT] Refreshing plugin dashboard style
- [BUG] Fixed tooltip issue issue

== 25.05.2021 - Version 1.0.9 ==
- [IMPROVEMENT] Magnific popup support at fullscreen mode
- [BUG] Gallery on new hotspot issue
- [BUG] Fix safari z-index issue
- [BUG] Fix hotspot image style issue
- [BUG] Fix tooltip shows scrollbar
- [BUG] Fix tooltip overlapped by hotspot
- [BUG] Incorrect image size after inserting image hotpot icon

== 12.02.2021 - Version 1.0.8 ==
- [BUG] Fix update notification & auto update issue
- [BUG] Fix tooltip not showing on fullscreen

== 26.01.2021 - Version 1.0.7 ==
- [IMPROVEMENT] Add fallback panorama image option
- [BUG] Fix slider control issue
- [BUG] Fix image icon issue

== 09.10.2020 - Version 1.0.6 ==
- [NEW FEATURE] Ability to show edit button on the panorama preview
- [BUG] Fix custom image icon for hotspot
- [BUG] Fix custom image icon for tour

== 28.08.2020 - Version 1.0.5 ==
- [IMPROVEMENT] Compatibility with WordPress 5.5
- [IMPROVEMENT] Optimize image display on panorama dashboard
- [IMPROVEMENT] Update default setting for panorama map
- [BUG] Fix wpColorPickerL10n issue

== 27.06.2020 - Version 1.0.4 ==
- [NEW FEATURE] Ability to show add to cart button on WooCommerce product popup
- [NEW FEATURE] Ability to use ajax on add to cart button
- [NEW FEATURE] Ability to update cart item for WooCommerce fragment by using ajax
- [IMPROVEMENT] Update element icon for WPBakery and Elementor
- [BUG] Fix duplicate id attribute of checkbox control on the DOM element

== 13.06.2020 - Version 1.0.3 ==
- [NEW FEATURE] Ability to use image URL for panorama image ( hosted, external resource, or CDN )
- [IMPROVEMENT] Add register activation plugin
- [IMPROVEMENT] Optimize backend speed performance
- [IMPROVEMENT] Enable open link in new tab for documentation page link
- [BUG] Fix duplicate id attribute on the DOM element

== 21.04.2020 - Version 1.0.2 ==
- [IMPROVEMENT] String translation update for backend option
- [IMPROVEMENT] Compatibility with WordPress 5.4
- [IMPROVEMENT] Compatibility with PHP 7.4
- [IMPROVEMENT] Compatibility with WPBakery Page Builder 6.1
- [IMPROVEMENT] Compatibility with Elementor 2.9.7
- [IMPROVEMENT] Compatibility with WooCommerce 4.0.1

== 13.11.2019 - Version 1.0.1 ==
- [IMPROVEMENT] String translation update
- [IMPROVEMENT] Thumbnail dimension update for post and product

== 28.10.2019 - Version 1.0.0 ==
- First Release
