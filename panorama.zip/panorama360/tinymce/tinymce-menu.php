<?php

/* Enqueue panorama requirements in admin section */
function panorama360_admin_enqueue_scripts( $hook ) {
	wp_localize_script( 'wp-tinymce', 'panorama360_l10n', panorama360_get_l10n() );

	if ( 'true' == get_user_option( 'rich_editing' ) ) {
		wp_enqueue_style( 'panorama360-shortcodes-style', PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-popup-style.css' );
		wp_enqueue_script( 'media-upload' );
	}
}
add_action( 'admin_enqueue_scripts', 'panorama360_admin_enqueue_scripts' );

/* Enqueue panorama requirements in frontend */
function panorama360_front_enqueue_scripts() {
	wp_localize_script( 'wp-tinymce', 'panorama360_l10n', panorama360_get_l10n() );

	// wp_enqueue_style( 'panorama360-shortcodes-style', PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-popup-style.css', array( 'editor-buttons') );
}
add_action( 'wp_enqueue_scripts', 'panorama360_front_enqueue_scripts' );

/* Add tinyMCE plugin */
function panorama360_add_plugin( $plugin_array ) {
	$plugin_array['panorama360'] = PANORAMA360_PLUGIN_URL . 'tinymce/tinymce.panorama360.js';
	return $plugin_array;
}
add_filter( 'mce_external_plugins', 'panorama360_add_plugin' );

/* Add tinyMCE button */
function panorama360_register_button( $buttons ) {
	array_push( $buttons, '!', 'panorama360' );
	return $buttons;
}
add_filter( 'mce_buttons', 'panorama360_register_button' );

function panorama360_get_l10n() {
	return array(
		'buttonTitle' => esc_html__( '360° panorama', 'panorama360' ),
		'buttonTitleFlat' => esc_html__( 'Flat panorama', 'panorama360' ),
		'buttonTitleEquirectangular' => esc_html__( 'Equirectangular panorama', 'panorama360' ),
		'submitButton' => esc_html__( 'Insert Shortcode', 'panorama360' ),
		'cancelButton' => esc_html__( 'Cancel', 'panorama360' ),
		'image' => esc_html__( 'Image', 'panorama360' ),
		'imageUpload' => esc_html__( 'Upload', 'panorama360' ),
		'imageRemove' => esc_html__( 'Remove', 'panorama360' ),
		'imageAlt' => esc_html__( 'Image Alt Attribute', 'panorama360' ),
		'imageWidth' => esc_html__( 'Image Width', 'panorama360' ),
		'imageHeight' => esc_html__( 'Image Height', 'panorama360' ),
		'imageType' => esc_html__( 'Panorama Type', 'panorama360' ),
		'imageTypeDescription' => esc_html__( 'Determine the type of rotation of the panorama image.', 'panorama360' ),
		'cssStyle' => esc_html__( 'Extra CSS Style', 'panorama360' ),
		'cssStyleDescription' => esc_html__( 'Add extra CSS style to the panorama container.', 'panorama360' ),
		'startPosition' => esc_html__( 'Start Position', 'panorama360' ),
		'startPositionDescription' => esc_html__( 'Initial horizontal position of the panoramic viewer.', 'panorama360' ),
		'title' => esc_html__( 'Title', 'panorama360' ),
		'titleLink' => esc_html__( 'Title Link', 'panorama360' ),
		'titleLinkTarget' => esc_html__( 'Title Link Target', 'panorama360' ),
		'titleLinkTargetSame' => esc_html__( 'Open in same tab/window', 'panorama360' ),
		'titleLinkTargetNew' => esc_html__( 'Open in new tab/window', 'panorama360' ),
		'mouseWheel' => esc_html__( 'Mouse Wheel', 'panorama360' ),
		'mouseWheelDescription' => esc_html__( 'Determine if the panorama can be controlled with the mouse wheel.', 'panorama360' ),
		'mouseWheelMultiplier' => esc_html__( 'Mouse Wheel Multiplier', 'panorama360' ),
		'mouseWheelMultiplierDescription' => esc_html__( 'Determine the mouse wheel scrolling factor.', 'panorama360' ),
		'slidingControls' => esc_html__( 'Sliding Controls', 'panorama360' ),
		'slidingControlsDescription' => esc_html__( 'Determine if the sliding controls are visible at the bottom of the panoramic viewer.', 'panorama360' ),
		'slidingDirection' => esc_html__( 'Automatic Sliding', 'panorama360' ),
		'slidingDirectionNo' => esc_html__( 'No', 'panorama360' ),
		'slidingDirectionLeft' => esc_html__( 'Left side', 'panorama360' ),
		'slidingDirectionRight' => esc_html__( 'Right side', 'panorama360' ),
		'slidingFactor' => esc_html__( 'Sliding Factor', 'panorama360' ),
		'slidingFactorDescription' => esc_html__( 'Sets the movement factor, slows it down if lower (between 0.1 and 2).', 'panorama360' ),
		'slidingFactorEquirectangularDescription' => esc_html__( 'Sets the movement factor, slows it down if lower (between 1 and 50).', 'panorama360' ),
		'fullscreenControl' => esc_html__( 'Fullscreen Control', 'panorama360' ),
		'zoomControls' => esc_html__( 'Zoom Controls', 'panorama360' ),
		'blockContextMenu' => esc_html__( 'Block Context Menu', 'panorama360' ),
		'blockContextMenuDescription' => esc_html__( 'Determines if the context menu is blocked (right click on the panoramic viewer).', 'panorama360' ),
		'popupDescription' => esc_html__( 'For more details please consult the ', 'panorama360' ) . '<a href="https://docs.liviucerchez.com/panorama360/" target="_blank">' . esc_html__( 'complete documentation', 'panorama360' ),
	);
}
