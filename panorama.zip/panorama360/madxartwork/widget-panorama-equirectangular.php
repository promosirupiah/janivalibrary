<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class madxartwork_Panorama_Equirectangular_Widget extends \madxartwork\Widget_Base {

	/* Get widget name. */
	public function get_name() {
		return 'panorama360-equirectangular';
	}

	/* Get widget title. */
	public function get_title() {
		return __( 'Equirectangular Panorama', 'panorama360' );
	}

	/* Get widget icon. */
	public function get_icon() {
		return 'eicon-image'; 
	}

	/* Get custom help URL. */
	public function get_custom_help_url() {
		return 'http://codecanyon.net/user/liviu_cerchez/';
	}

	/* Get widget categories. */
	public function get_categories() {
		return [ 'general' ];
	}

	/* Get widget keywords. */
	public function get_keywords() {
		return [ 'panorama' ];
	}

	/* Register list widget controls. */
	protected function register_controls() {
		$this->start_controls_section(
			'image_section',
			[
				'label' => esc_html__( 'Image', 'panorama360' ),
				'tab' => \madxartwork\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'src',
			[
				'type' => \madxartwork\Controls_Manager::MEDIA,
				'label' => esc_html__( 'Choose Image', 'panorama360' ),
			]
		);

		$this->add_control(
			'element_height',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Element Height', 'panorama360' ),
				'description' => esc_html__( 'Determine the height of the widget element.', 'panorama360' ),
				'step'        => '10',
				'default'     => '400',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'basic_section',
			[
				'label' => esc_html__( 'Basic Options', 'panorama360' ),
				'tab'   => \madxartwork\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'sliding_controls',
			[
				'type'    => \madxartwork\Controls_Manager::SWITCHER,
				'label'   => esc_html__( 'Sliding controls', 'panorama360' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sliding_direction',
			[
				'type'        => \madxartwork\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Sliding direction', 'panorama360' ),
				'description' => esc_html__( 'Determine the automatic sliding direction.', 'panorama360' ),
				'label_block' => true,
				'options'     => [
					'0'  => esc_html__( 'No automatic slide effect', 'panorama360' ),
					'1'  => esc_html__( 'Right automatic slide effect', 'panorama360' ),
					'-1' => esc_html__( 'Left automatic slide effect', 'panorama360' ),
				],
				'default'     => '0',
			]
		);

		$this->add_control(
			'fullscreen_control',
			[
				'type' => \madxartwork\Controls_Manager::SWITCHER,
				'label'=> esc_html__( 'Fullscreen control', 'panorama360' ),
			]
		);

		$this->add_control(
			'zoom_control',
			[
				'type' => \madxartwork\Controls_Manager::SWITCHER,
				'label'=> esc_html__( 'Zoom control', 'panorama360' ),
			]
		);

		$this->add_control(
			'title',
			[
				'type'        => \madxartwork\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Title', 'panorama360' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'title_link',
			[
				'type'    => \madxartwork\Controls_Manager::URL,
				'label'   => esc_html__( 'Title link', 'panorama360' ),
				'options' => [ 'url', 'is_external' ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'more_options_section',
			[
				'label' => esc_html__( 'More Options', 'panorama360' ),
				'tab'   => \madxartwork\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'start_position',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Start position', 'panorama360' ),
				'description' => esc_html__( 'Initial start position angle for the view (in degrees).', 'panorama360' ),
				'min'         => -359,
				'max'         => 359,
				'step'        => 1,
			]
		);

		$this->add_control(
			'sliding_factor',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Sliding factor', 'panorama360' ),
				'description' => esc_html__( 'Determine the automatic sliding multiplier factor (use this with care).', 'panorama360' ),
				'min'         => '1',
				'max'         => '50',
				'step'        => '1',
				'default'     => '8',
			]
		);

		$this->add_control(
			'sliding_drag_stop',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Sliding drag stop', 'panorama360' ),
				'description' => esc_html__( 'Determine if automatic sliding is stopped on mouse/touch dragging events.', 'panorama360' ),
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'mousewheel',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Mousewheel', 'panorama360' ),
				'description' => esc_html__( 'Use mouse wheel to control the scroll.', 'panorama360' ),
			]
		);

		$this->add_control(
			'block_contextmenu',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Block right click', 'panorama360' ),
				'description' => esc_html__( 'Determine if the context menu is blocked (right click).', 'panorama360' ),
			]
		);

		$this->add_control(
			'bind_resize',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Bind resize', 'panorama360' ),
				'description' => esc_html__( 'Determine if window resize affects panorama viewport (making it responsive).', 'panorama360' ),
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'invert_colors',
			[
				'type'  => \madxartwork\Controls_Manager::SWITCHER,
				'label' => esc_html__( 'Invert colors', 'panorama360' ),
			]
		);

		$this->end_controls_section();
	}

	/* Render list widget output on the frontend (generate the final HTML). */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$attributes = '';

		if ( $settings['start_position'] ) {
			$attributes .= ' data-start-position="' . esc_attr( $settings['start_position'] ) . '"';
		}

		if ( $settings['src'] ) {
			$attributes .= ' data-src="' . esc_url( $settings['src']['url'] ) . '"';
		}

		if ( 'yes' !== $settings['sliding_controls'] ) {
			$attributes .= ' data-sliding-controls="false"';
		}

		if ( '0' !== $settings['sliding_direction'] ) {
			$attributes .= ' data-sliding-direction="' . esc_attr( $settings['sliding_direction'] ) . '"';
		}

		if ( '8' !== $settings['sliding_factor'] ) {
			$attributes .= ' data-sliding-factor="' . esc_attr( $settings['sliding_factor'] ) . '"';
		}

		if ( 'yes' !== $settings['sliding_drag_stop'] ) {
			$attributes .= ' data-sliding-drag-stop="false"';
		}

		if ( 'yes' === $settings['fullscreen_control'] ) {
			$attributes .= ' data-fullscreen-control="true"';
		}

		if ( 'yes' === $settings['zoom_control'] ) {
			$attributes .= ' data-zoom-control="true"';
		}

		if ( 'yes' === $settings['mousewheel'] ) {
			$attributes .= ' data-mousewheel="true"';
		}

		if ( 'yes' !== $settings['bind_resize'] ) {
			$attributes .= ' data-bind-resize="false"';
		}

		if ( 'yes' === $settings['block_contextmenu'] ) {
			$attributes .= ' data-block-contextmenu="true"';
		}

		$output  = '<div class="panorama360 type-equirectangular' . ( 'yes' === $settings['invert_colors'] ? ' light-colors' : '' ) . '"' . ( ! empty( $settings['element_height'] ) ? ' style="height:' . esc_attr( $settings['element_height'] ) . 'px"' : '300px' ) . $attributes . '>';

		if ( \madxartwork\Plugin::$instance->editor->is_edit_mode() && ! empty ( $settings['src']['url'] ) ) {
			$output .= '<div class="panorama-view">';
			if ( ! empty ( $settings['src']['url'] ) ) {
				$output .=   '<img src="' . esc_url( $settings['src']['url'] ) . '" alt="' . \madxartwork\Control_Media::get_image_alt( $settings['src'] ) . '"' . ( ! empty( $settings['src']['id'] ) ? ' data-id="' . esc_attr( $settings['src']['id'] ) . '"' : '' ) . '>';
			}
			$output .=  '<div class="panorama-spinner"></div>';
			$output .= '</div>';
		} else {
			$output .= '<div class="panorama-spinner"></div>';
		}
		if ( ! empty( $settings['title'] ) ) {
			$output .= '<div class="panorama-title"><a' . ( ! empty( $settings['title_link']['url'] ) ? ' href="' . esc_url( $settings['title_link']['url'] ) . '"' : '' ) . ( ! empty( $settings['title_link']['url'] ) && false !== $settings['title_link']['is_external'] ? ' target="_blank"' : '' ) . '>' . $settings['title'] . '</a></div>';
		}
		if ( \madxartwork\Plugin::$instance->editor->is_edit_mode() ) {
			if ( 'yes' === $settings['sliding_controls'] ) {
				$output .= '<div class="panorama-controls"><a class="panorama-controls-up"><span></span></a><a class="panorama-controls-right"><span></span></a><a class="panorama-controls-down"><span></span></a><a class="panorama-controls-left"><span></span></a><a class="panorama-controls-stop"><span></span></a></div>';
			}
			if ( 'yes' === $settings['fullscreen_control'] ) {
				$output .= '<div class="panorama-fullscreen"><a><span></span></a></div>';
			}
			if ( 'yes' === $settings['zoom_control'] ) {
				$output .= '<div class="panorama-zoom"><a class="panorama-zoom-in"><span></span></a><a class="panorama-zoom-out"><span></span></a></div>';
			}
		}
		$output .= '</div>';

		echo $output;

		$dependencies = array( 'jquery' );
		if ( 'yes' === $settings['mousewheel'] ) {
			$dependencies[] = 'panorama360-mousewheel';
			wp_register_script( 'panorama360-mousewheel', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.mousewheel.js', array( 'jquery' ) );
		}
		if ( 'yes' === $settings['fullscreen_control'] ) {
			$dependencies[] = 'panorama360-fullscreen';
			wp_register_script( 'panorama360-fullscreen', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.fullscreen.js', array( 'jquery' ) );
		}
		wp_register_style( 'panorama360-equirectangular', PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-equirectangular.css' );
		wp_register_script( 'panorama360-threejs', PANORAMA360_PLUGIN_URL . 'assets/js/three.min.js', $dependencies );
		$dependencies[] = 'panorama360-threejs';
		wp_register_script( 'panorama360-equirectangular', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.panorama360-equirectangular.js', $dependencies );
	}

	public function get_script_depends() {
		$dependencies = array();

		if ( ! \madxartwork\Plugin::$instance->preview->is_preview_mode() ) {
			$settings = $this->get_settings_for_display();
			if ( 'yes' === $settings['fullscreen_control'] ) {
				$dependencies[] = 'panorama360-fullscreen';
			}

			if ( 'yes' === $settings['mousewheel'] ) {
				$dependencies[] = 'panorama360-mousewheel';
			}

			$dependencies[] = 'panorama360-threejs';
			$dependencies[] = 'panorama360-equirectangular';
		}

		return $dependencies;
	}

	public function get_style_depends() {
		return [ 'panorama360-equirectangular' ];
	}

}
