<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class madxartwork_Panorama_Flat_Widget extends \madxartwork\Widget_Base {

	/* Get widget name. */
	public function get_name() {
		return 'panorama360-flat';
	}

	/* Get widget title. */
	public function get_title() {
		return __( 'Flat Panorama', 'panorama360' );
	}

	/* Get widget icon. */
	public function get_icon() {
		return 'eicon-image'; 
	}

	/* Get custom help URL. */
	public function get_custom_help_url() {
		return 'http://codecanyon.net/user/liviu_cerchez/';
	}

	/* Get widget categories. */
	public function get_categories() {
		return [ 'general' ];
	}

	/* Get widget keywords. */
	public function get_keywords() {
		return [ 'panorama' ];
	}

	/* Register list widget controls. */
	protected function register_controls() {
		$this->start_controls_section(
			'image_section',
			[
				'label' => esc_html__( 'Image', 'panorama360' ),
				'tab' => \madxartwork\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'src',
			[
				'type' => \madxartwork\Controls_Manager::MEDIA,
				'label' => esc_html__( 'Choose Image', 'panorama360' ),
			]
		);

		$this->add_control(
			'src_width',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Image width', 'panorama360' ),
				'description' => esc_html__( 'The original image width must be defined when the image is not from the local Media Library.', 'panorama360' ),
			]
		);

		$this->add_control(
			'src_height',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Image height', 'panorama360' ),
				'description' => esc_html__( 'The original image height must be defined when the image is not from the local Media Library.', 'panorama360' ),
			]
		);

		$this->add_control(
			'element_height',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Element Height', 'panorama360' ),
				'description' => esc_html__( 'Determine the height of the widget element.', 'panorama360' ),
				'step'        => '10',
				'default'     => '350',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'basic_section',
			[
				'label' => esc_html__( 'Basic Options', 'panorama360' ),
				'tab'   => \madxartwork\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'is360',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( '360° image', 'panorama360' ),
				'description' => esc_html__( 'Determine the rotation type: simple 180° image or 360° (glue left and right to make it scrollable)', 'panorama360' ),
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'sliding_controls',
			[
				'type'    => \madxartwork\Controls_Manager::SWITCHER,
				'label'   => esc_html__( 'Sliding controls', 'panorama360' ),
				'default' => 'yes',
			]
		);

		$this->add_control(
			'sliding_direction',
			[
				'type'        => \madxartwork\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Sliding direction', 'panorama360' ),
				'description' => esc_html__( 'Determine the automatic sliding direction.', 'panorama360' ),
				'label_block' => true,
				'options'     => [
					'0'  => esc_html__( 'No automatic slide effect', 'panorama360' ),
					'1'  => esc_html__( 'Right automatic slide effect', 'panorama360' ),
					'-1' => esc_html__( 'Left automatic slide effect', 'panorama360' ),
				],
				'default'     => '0',
			]
		);

		$this->add_control(
			'fullscreen_control',
			[
				'type'  => \madxartwork\Controls_Manager::SWITCHER,
				'label' => esc_html__( 'Fullscreen control', 'panorama360' ),
			]
		);

		$this->add_control(
			'title',
			[
				'type'        => \madxartwork\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Title', 'panorama360' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'title_link',
			[
				'type'    => \madxartwork\Controls_Manager::URL,
				'label'   => esc_html__( 'Title link', 'panorama360' ),
				'options' => [ 'url', 'is_external' ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'more_options_section',
			[
				'label' => esc_html__( 'More Options', 'panorama360' ),
				'tab'   => \madxartwork\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'start_position',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Start position', 'panorama360' ),
				'description' => esc_html__( 'Initial start position for the view (in pixels).', 'panorama360' ),
			]
		);

		$this->add_control(
			'start_position_centered',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Fullscreen control', 'panorama360' ),
				'description' => esc_html__( 'Start position gets centered with the viewport.', 'panorama360' ),
			]
		);

		$this->add_control(
			'sliding_factor',
			[
				'type'        => \madxartwork\Controls_Manager::NUMBER,
				'label'       => esc_html__( 'Sliding factor', 'panorama360' ),
				'description' => esc_html__( 'Determine the automatic sliding multiplier factor (use this with care).', 'panorama360' ),
				'min'         => '1',
				'max'         => '20',
				'step'        => '1',
				'default'     => '8',
			]
		);

		$this->add_control(
			'sliding_drag_stop',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Sliding drag stop', 'panorama360' ),
				'description' => esc_html__( 'Determine if automatic sliding is stopped on mouse/touch dragging events.', 'panorama360' ),
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'mousewheel',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Mousewheel', 'panorama360' ),
				'description' => esc_html__( 'Use mouse wheel to control the scroll.', 'panorama360' ),
			]
		);

		$this->add_control(
			'block_contextmenu',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Block right click', 'panorama360' ),
				'description' => esc_html__( 'Determine if the context menu is blocked (right click).', 'panorama360' ),
			]
		);

		$this->add_control(
			'bind_resize',
			[
				'type'        => \madxartwork\Controls_Manager::SWITCHER,
				'label'       => esc_html__( 'Bind resize', 'panorama360' ),
				'description' => esc_html__( 'Determine if window resize affects panorama viewport (making it responsive).', 'panorama360' ),
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'usemap',
			[
				'type'        => \madxartwork\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Image map', 'panorama360' ),
				'description' => esc_html__( 'Assign a "usemap" attribute to the image markup (use it in conjunction with a HTML widget having a <map id="map1" name="map1"> tag, where "map1" is unique, it will be the "usemap" value).', 'panorama360' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'invert_colors',
			[
				'type'  => \madxartwork\Controls_Manager::SWITCHER,
				'label' => esc_html__( 'Invert colors', 'panorama360' ),
			]
		);

		$this->end_controls_section();
	}

	/* Render list widget output on the frontend (generate the final HTML). */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$output  = '<div class="panorama360 type-flat' . ( 'yes' === $settings['invert_colors'] ? ' light-colors' : '' ) . '"' . ( ! empty( $settings['element_height'] ) ? ' style="height:' . esc_attr( $settings['element_height'] ) . 'px"' : '300px' ) .'>';
		$attributes = '';
		if ( $settings['src']['id'] ) {
			$image_meta = wp_get_attachment_metadata( $settings['src']['id'] );
			$size_array = wp_image_src_get_dimensions( $settings['src']['url'], $image_meta, $settings['src']['id'] );
			if ( $size_array ) {
				$attributes .= ' data-width="' . esc_attr( $size_array[0] ) . '" data-height="' . esc_attr( $size_array[1] ) . '"';
			}
		} else {
			// obtain upload dir
			$upload_info  = wp_upload_dir();
			$upload_dir   = $upload_info['basedir'];
			$upload_url   = $upload_info['baseurl'];
			$http_prefix  = 'http://';
			$https_prefix = 'https://';
			/* if the $src scheme differs from $upload_url scheme, make them match; if the schemes differ, images don't show up. */
			if ( ! strncmp( $settings['src']['url'], $https_prefix, strlen( $https_prefix ) ) ) {
				// if src begins with https:// make $upload_url begin with https:// as well
				$upload_url = str_replace( $http_prefix, $https_prefix, $upload_url );
			} elseif ( ! strncmp( $settings['src']['url'], $http_prefix, strlen( $http_prefix ) ) ) {
				// if src begins with http:// make $upload_url begin with http:// as well
				$upload_url = str_replace( $https_prefix, $http_prefix, $upload_url );
			}
			// check if defined image is local
			$is_remote_image = ( false === strpos( $settings['src']['url'], $upload_url ) );
			if ( $is_remote_image && ( ! is_numeric( $settings['src_width'] ) || ! is_numeric( $settings['src_height'] ) ) ) {
				if ( ! \madxartwork\Plugin::$instance->editor->is_edit_mode() ) {
					$output .= esc_html__( 'Please define valid width and height attributes for remote images.', 'panorama360' );
				}
			} else {
				$rel_path = str_replace( $upload_url, '', $settings['src']['url'] );
				$img_path = $upload_dir . $rel_path;
				if ( file_exists( $img_path ) && ( ! is_numeric( $settings['src_width'] ) || ! is_numeric( $settings['src_height'] ) ) ) {
					list( $orig_w, $orig_h ) = getimagesize( $args['src'] );
					$settings['src_width']   = $orig_w;
					$settings['src_height']  = $orig_h;
				}
			}

			if ( $settings['src_width'] && $settings['src_height'] ) {
				$attributes .= ' data-width="' . esc_attr( $settings['src_width'] ) . '" data-height="' . esc_attr( $settings['src_height'] ) . '"';
			}
		}

		if ( 'yes' !== $settings['is360'] ) {
			$attributes .= ' data-is360="false"';
		}

		if ( $settings['start_position'] ) {
			$attributes .= ' data-start-position="' . esc_attr( $settings['start_position'] ) . '"';
		}

		if ( 'yes' === $settings['start_position_centered'] ) {
			$attributes .= ' data-start-position-centered="true"';
		}

		if ( 'yes' !== $settings['sliding_controls'] ) {
			$attributes .= ' data-sliding-controls="false"';
		}

		if ( '0' !== $settings['sliding_direction'] ) {
			$attributes .= ' data-sliding-direction="' . esc_attr( $settings['sliding_direction'] ) . '"';
		}

		if ( '8' !== $settings['sliding_factor'] ) {
			$attributes .= ' data-sliding-factor="' . esc_attr( $settings['sliding_factor'] ) . '"';
		}

		if ( 'yes' !== $settings['sliding_drag_stop'] ) {
			$attributes .= ' data-sliding-drag-stop="false"';
		}

		if ( 'yes' === $settings['fullscreen_control'] ) {
			$attributes .= ' data-fullscreen-control="true"';
		}

		if ( 'yes' === $settings['mousewheel'] ) {
			$attributes .= ' data-mousewheel="true"';
		}

		if ( 'yes' !== $settings['bind_resize'] ) {
			$attributes .= ' data-bind-resize="false"';
		}

		if ( 'yes' === $settings['block_contextmenu'] ) {
			$attributes .= ' data-block-contextmenu="true"';
		}

		$output .=  '<div class="panorama-view"' . $attributes . '>';
		$output .=   '<div class="panorama-container">';
		if ( ! empty ( $settings['src']['url'] ) ) {
			$output .=    '<img src="' . esc_url( $settings['src']['url'] ) . '" alt="' . \madxartwork\Control_Media::get_image_alt( $settings['src'] ) . '"' . ( ! empty( $settings['usemap'] ) ? ' usemap="#' . esc_attr( $settings['usemap'] ) . '"' : '' ) . '>';
		}
		$output .=   '</div>';
		$output .=   '<div class="panorama-spinner"></div>';
		$output .=  '</div>';
		if ( ! empty( $settings['title'] ) ) {
			$output .= '<div class="panorama-title"><a' . ( ! empty( $settings['title_link']['url'] ) ? ' href="' . esc_url( $settings['title_link']['url'] ) . '"' : '' ) . ( ! empty( $settings['title_link']['url'] ) && false !== $settings['title_link']['is_external'] ? ' target="_blank"' : '' ) . '>' . $settings['title'] . '</a></div>';
		}
		if ( \madxartwork\Plugin::$instance->editor->is_edit_mode() ) {
			if ( 'yes' === $settings['fullscreen_control'] ) {
				$output .= '<div class="panorama-fullscreen"><a><span></span></a></div>';
			}
			if ( 'yes' === $settings['sliding_controls'] ) {
				$output .= '<div class="panorama-controls"><a class="panorama-controls-prev"><span></span></a><a class="panorama-controls-stop"><span></span></a><a class="panorama-controls-next"><span></span></a></div>';
			}
			$output .= '<a class="panorama-type">' . ( '-1' === $settings['sliding_direction'] ? esc_html__( '← ', 'panorama360' ) : '' ) . ( 'yes' === $settings['is360'] ? esc_html__( '360°', 'panorama360' ) : esc_html__( '180°', 'panorama360' ) ) . ( '1' === $settings['sliding_direction'] ? esc_html__( ' →', 'panorama360' ) : '' ) . '</a>';
		}
		$output .= '</div>';

		echo $output;

		$dependencies = array( 'jquery' );
		if ( 'yes' === $settings['mousewheel'] ) {
			$dependencies[] = 'panorama360-mousewheel';
			wp_register_script( 'panorama360-mousewheel', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.mousewheel.js', array( 'jquery' ) );
		}
		if ( 'yes' === $settings['fullscreen_control'] ) {
			$dependencies[] = 'panorama360-fullscreen';
			wp_register_script( 'panorama360-fullscreen', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.fullscreen.js', array( 'jquery' ) );
		}
		wp_register_style( 'panorama360-flat', PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-flat.css' );
		wp_register_script( 'panorama360-flat', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.panorama360-flat.js', $dependencies );
	}

	public function get_script_depends() {
		$dependencies = array();

		if ( ! \madxartwork\Plugin::$instance->preview->is_preview_mode() ) {
			$settings = $this->get_settings_for_display();
			if ( 'yes' === $settings['fullscreen_control'] ) {
				$dependencies[] = 'panorama360-fullscreen';
			}

			if ( 'yes' === $settings['mousewheel'] ) {
				$dependencies[] = 'panorama360-mousewheel';
			}

			$dependencies[] = 'panorama360-flat';
		}

		return $dependencies;
	}

	public function get_style_depends() {
		return [ 'panorama360-flat' ];
	}

}
