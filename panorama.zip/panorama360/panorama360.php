<?php
/*
Plugin Name: 360&deg; Panoramic Viewer
Plugin URI: http://codecanyon.net/user/liviu_cerchez/
Version: 3.2
Description: Embed panoramic images into your website and view them on any device.
Author: Liviu Cerchez
Author URI: http://codecanyon.net/user/liviu_cerchez/
Requires at least: 4.9
Tested up to: 6.2
Text Domain: panorama360
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! defined( 'PANORAMA360_PLUGIN_URL' ) ) {
	define( 'PANORAMA360_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'PANORAMA360_PLUGIN_DIR' ) ) {
	define( 'PANORAMA360_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

function panorama360_load_textdomain() {
	load_plugin_textdomain( 'panorama360', false, basename( dirname( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'panorama360_load_textdomain' );

/* process shortcode atrributes and output panorama */
function panorama360_shortcode( $atts, $content = null ) {
	$args = shortcode_atts( array(
		'type'                    => 'flat', // flat, equirectangular
		'src'                     => '',
		'src_width'               => '',
		'src_height'              => '',
		'src_alt'                 => '',
		'id'                      => '',
		'title'                   => '',
		'title_link'              => '',
		'title_link_target'       => '',
		'style'                   => '',
		'mousewheel'              => false,
		'mousewheel_multiplier'   => 10,
		'bind_resize'             => true,
		'is360'                   => true,
		'start_position'          => '',
		'start_position_centered' => false,
		'sliding_controls'        => true,
		'sliding_direction'       => 0,
		'sliding_interval'        => 10,
		'sliding_factor'          => 0,
		'sliding_drag_stop'       => true,
		'fullscreen_control'      => false,
		'zoom_controls'           => false,
		'map'                     => '',
		'block_contextmenu'       => false,
		'invert_colors'           => false,
	), $atts, 'panorama360' );

	// use general notice variable for any warnings/errors
	$notice = '';

	// check if source image is defined
	if ( $args['src'] ) {
		if ( 'flat' === $args['type'] ) {
			// obtain upload dir
			$upload_info  = wp_upload_dir();
			$upload_dir   = $upload_info['basedir'];
			$upload_url   = $upload_info['baseurl'];
			$http_prefix  = 'http://';
			$https_prefix = 'https://';
			/* if the $src scheme differs from $upload_url scheme, make them match; if the schemes differ, images don't show up. */
			if ( ! strncmp( $args['src'], $https_prefix, strlen( $https_prefix ) ) ) {
				// if src begins with https:// make $upload_url begin with https:// as well
				$upload_url = str_replace( $http_prefix, $https_prefix, $upload_url );
			} elseif ( ! strncmp( $args['src'], $http_prefix, strlen( $http_prefix ) ) ) {
				// if src begins with http:// make $upload_url begin with http:// as well
				$upload_url = str_replace( $https_prefix, $http_prefix, $upload_url );
			}
			// check if defined image is local
			$is_remote_image = ( false === strpos( $args['src'], $upload_url ) );
			if ( $is_remote_image && ( ! is_numeric( $args['src_width'] ) || ! is_numeric( $args['src_height'] ) ) ) {
				$notice = esc_html__( 'Please define valid width and height attributes for remote images.', 'panorama360' );
			} else {
				$rel_path = str_replace( $upload_url, '', $args['src'] );
				$img_path = $upload_dir . $rel_path;
				if ( file_exists( $img_path ) && ( ! is_numeric( $args['src_width'] ) || ! is_numeric( $args['src_height'] ) ) ) {
					list( $orig_w, $orig_h ) = getimagesize( $args['src'] );
					$args['src_width']       = $orig_w;
					$args['src_height']      = $orig_h;
				}
				if ( $args['map'] ) {
					$usemap = ' usemap="#' . esc_attr( $args['map'] ) . '"';
				} else {
					$usemap = '';
				}
				$img = '<img src="' . esc_url( $args['src'] ) . '"' . $usemap . ' alt="' . esc_attr( $args['src_alt'] ) . '">';
			}
		}
	} else {
		$notice = esc_html__( 'Please define a valid source image (src attribute).', 'panorama360' );
	}

	if ( $notice ) {
		return '<strong>' . $notice . '</strong>';
	} else {

		// check if title attribute exists and add link+target attributes as well
		if ( $args['title'] ) {
			if ( $args['title_link'] ) {
				$title_link = ' href="' . esc_url( $args['title_link'] ) . '"';
			} else {
				$title_link = '';
			}
			if ( $args['title_link_target'] ) {
				$title_link_target = ' target="' . esc_attr( $args['title_link_target'] ) . '"';
			} else {
				$title_link_target = '';
			}
			$title = '<div class="panorama-title"><a' . $title_link . $title_link_target . '>' . esc_attr( $args['title'] ) . '</a></div>';
		} else {
			$title = '';
		}

		if ( $args['id'] ) {
			$id = ' id="' . esc_attr( $args['id'] ) . '"';
		} else {
			$id = '';
		}
		if ( $args['style'] ) {
			$style = ' style="' . esc_attr( $args['style'] ) . '"';
		} else {
			$style = '';
		}
		$add_classes = ' type-' . $args['type'];
		if ( panorama360_string_to_bool( $args['invert_colors'] ) ) {
			$add_classes .= ' light-colors';
		}
		$data_atrribs = '';
		if ( 'flat' === $args['type'] ) {
			if ( $args['src_width'] ) {
				$data_atrribs .= ' data-width="' . esc_attr( $args['src_width'] ) . '"';
			}
			if ( $args['src_height'] ) {
				$data_atrribs .= ' data-height="' . esc_attr( $args['src_height'] ) . '"';
			}
			if ( $args['src_width'] ) {
				$data_atrribs .= ' data-width="' . esc_attr( $args['src_width'] ) . '"';
			}
			if ( $args['start_position'] ) {
				$data_atrribs .= ' data-start-position="' . esc_attr( $args['start_position'] ) . '"';
			}
			if ( panorama360_string_to_bool( $args['start_position_centered'] ) ) {
				$data_atrribs .= ' data-start-position-centered="true"';
			}
		} else if ( 'equirectangular' === $args['type'] ) {
			if ( $args['src'] ) {
				$data_atrribs .= ' data-src="' . esc_url( $args['src'] ) . '"';
			}
			if ( $args['start_position'] ) {
				$data_atrribs .= ' data-start-position="' . esc_attr( $args['start_position'] ) . '"';
			}
		}
		if ( panorama360_string_to_bool( $args['mousewheel'] ) ) {
			$data_atrribs .= ' data-mousewheel="true"';
		}
		if ( $args['mousewheel_multiplier'] && 10 !== $args['mousewheel_multiplier'] ) {
			$data_atrribs .= ' data-mousewheel-multiplier="' . esc_attr( $args['mousewheel_multiplier'] ) . '"';
		}
		if ( ! panorama360_string_to_bool( $args['bind_resize'] ) ) {
			$data_atrribs .= ' data-bind-resize="false"';
		}
		if ( 'flat' === $args['type'] ) {
			if ( ! panorama360_string_to_bool( $args['is360'] ) ) {
				$data_atrribs .= ' data-is360="false"';
			}
		}
		if ( ! panorama360_string_to_bool( $args['sliding_controls'] ) ) {
			$data_atrribs .= ' data-sliding-controls="false"';
		}
		if ( $args['sliding_direction'] ) {
			$data_atrribs .= ' data-sliding-direction="' . esc_attr( $args['sliding_direction'] ) . '"';
		}
		if ( ! $args['sliding_drag_stop'] ) {
			$data_atrribs .= ' data-sliding-drag-stop="' . esc_attr( $args['sliding_drag_stop'] ) . '"';
		}
		if ( 'flat' === $args['type'] ) {
			if ( $args['sliding_interval'] && 10 !== $args['sliding_interval'] ) {
				$data_atrribs .= ' data-sliding-interval="' . esc_attr( $args['sliding_interval'] ) . '"';
			}
			if ( $args['sliding_factor'] && is_numeric( $args['sliding_factor'] ) && 0.8 !== $args['sliding_factor'] ) {
				$data_atrribs .= ' data-sliding-factor="' . esc_attr( $args['sliding_factor'] ) . '"';
			}
		} else if ( 'equirectangular' === $args['type'] ) {
			if ( $args['sliding_factor'] && is_numeric( $args['sliding_factor'] ) && 8 !== $args['sliding_factor'] ) {
				$data_atrribs .= ' data-sliding-factor="' . esc_attr( $args['sliding_factor'] ) . '"';
			}
		}
		if ( panorama360_string_to_bool( $args['fullscreen_control'] ) ) {
			$data_atrribs .= ' data-fullscreen-control="true"';
		}
		if ( 'equirectangular' === $args['type'] && panorama360_string_to_bool( $args['zoom_controls'] ) ) {
			$data_atrribs .= ' data-zoom-controls="true"';
		}
		if ( panorama360_string_to_bool( $args['block_contextmenu'] ) ) {
			$data_atrribs .= ' data-block-contextmenu="true"';
		}

		$dependencies = array( 'jquery' );
		if ( panorama360_string_to_bool( $args['mousewheel'] ) ) {
			$dependencies[] = 'panorama360-mousewheel';
			wp_enqueue_script( 'panorama360-mousewheel', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.mousewheel.js', array( 'jquery' ) );
		}
		if ( panorama360_string_to_bool( $args['fullscreen_control'] ) ) {
			$dependencies[] = 'panorama360-fullscreen';
			wp_enqueue_script( 'panorama360-fullscreen', PANORAMA360_PLUGIN_URL . 'assets/js/jquery.fullscreen.js', array( 'jquery' ) );
		}
		wp_enqueue_style( 'panorama360-' . $args['type'] , PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-' . $args['type'] . '.css' );
		if ( 'equirectangular' === $args['type'] ) {
			$dependencies[] = 'panorama360-threejs';
			wp_enqueue_script( 'panorama360-threejs', PANORAMA360_PLUGIN_URL . 'assets/js/three.min.js', array() );
		}
		wp_enqueue_script( 'panorama360-' . $args['type'], PANORAMA360_PLUGIN_URL . 'assets/js/jquery.panorama360-' . $args['type'] . '.js', $dependencies );

		if ( 'flat' === $args['type'] ) {
			return '<div class="panorama360' . $add_classes . '"' . $id . $style . '><div class="panorama-view"' . $data_atrribs . '><div class="panorama-container">' . $img . do_shortcode( $content ) . '</div><div class="panorama-spinner"></div></div>' . $title . '</div>';
		} else if ( 'equirectangular' === $args['type'] ) {
			return '<div class="panorama360' . $add_classes . '"' . $id . $style . $data_atrribs . '><div class="panorama-spinner"></div>' . do_shortcode( $content ) . $title . '</div>';
		}
	}
}
add_shortcode( 'panorama360', 'panorama360_shortcode' );

/* extract boolean attribute values from shortcodes */
function panorama360_string_to_bool( $value ) {
	return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
}

/* Add tinyMCE menu for Classic editor */
require( PANORAMA360_PLUGIN_DIR . 'tinymce/tinymce-menu.php' );

/* Add blocks for Gutenberg editor */
require( PANORAMA360_PLUGIN_DIR . 'blocks/panorama360-flat-image.php' );
require( PANORAMA360_PLUGIN_DIR . 'blocks/panorama360-equirectangular-image.php' );

/* Add madxartwork widgets for Classic editor */

function panorama360_register_new_widgets( $widgets_manager ) {
	require_once( PANORAMA360_PLUGIN_DIR . '/madxartwork/widget-panorama-flat.php' );
	require_once( PANORAMA360_PLUGIN_DIR . '/madxartwork/widget-panorama-equirectangular.php' );
	$widgets_manager->register( new \madxartwork_Panorama_Flat_Widget() );
	$widgets_manager->register( new \madxartwork_Panorama_Equirectangular_Widget() );
}
add_action( 'madxartwork/widgets/register', 'panorama360_register_new_widgets' );
