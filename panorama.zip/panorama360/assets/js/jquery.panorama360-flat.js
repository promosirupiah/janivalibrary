/*!
 * 360 Panoramic Viewer - Flat Image
 * https://codecanyon.net/item/360-panoramic-viewer-wordpress-plugin/5054590
 * by Liviu Cerchez
 */
( function( $ ) {
	$.fn.panorama360 = function( options ) {
		return this.each( function() {
			var settings = {
				image_width: 0,
				image_height: 0,
				mouse_wheel_active: 0,
				mouse_wheel_multiplier: 10,
				bind_resize: true, // determine if window resize affects panorama viewport
				is360: true, // glue left and right and make it scrollable
				start_position: 0, // initial start position for the view
				start_position_centered: false, // start position gets centered with the viewport
				sliding_controls: true, // determine if UI controls for sliding are created
				sliding_direction: 0, // determines the automatic sliding direction: 0 - no automatic slide effect, 1 - right side effect, -1 - left side effect
				sliding_factor: 0.8, // determines the automatic sliding multiplier factor
				sliding_drag_stop: true, // determines if automatic sliding is stopped on mouse/touch dragging events
				fullscreen_control: 0, // determine if UI control for toggling fullscreen is enabled
				block_contextmenu: 0, // determines if the context menu is blocked (right click)
				setPanoramaPosition: function ( panoramaContainer, posX ) {
					panoramaContainer.data( 'posX', posX ).css( 'marginLeft', posX + 'px' );
				}
			};
			var browserPrefixes = 'transform WebkitTransform MozTransform OTransform msTransform'.split( ' ' ), testDiv = document.createElement( 'div' ), transformSupport = false;
			for ( var i = 0; i < browserPrefixes.length; i++ ) {
				if ( testDiv && testDiv.style[browserPrefixes[i]] !== undefined ) {
					transformSupport = browserPrefixes[i];
					break;
				}
			}
			if ( transformSupport ) {
				settings.setPanoramaPosition = function ( panoramaContainer, posX ) {
					panoramaContainer.data( 'posX', posX );
					panoramaContainer[0].style[transformSupport] = 'translateX(' + posX + 'px)';
				};
			}
			if ( options ) {
				$.extend( settings, options );
			}
			var viewport = $( this ),
				panoramaContainer = viewport.children( '.panorama-container' ),
				viewportImage = panoramaContainer.children( 'img:first-child' );
			if ( settings.image_width <= 0 && settings.image_height <= 0 ) {
				settings.image_width  = parseInt( viewport.data( 'width' ) );
				settings.image_height = parseInt( viewport.data( 'height' ) );
				if ( ! ( settings.image_width ) || ! ( settings.image_height ) ) {
					return;
				}
			}
			var image_ratio = settings.image_height / settings.image_width,
				elem_height = parseInt( viewport.height() ),
				elem_width = parseInt( elem_height / image_ratio ),
				image_map = viewportImage.attr( 'usemap' ),
				image_areas,
				isDragged = false,
				mouseXprev = 0,
				scrollDelta = 0,
				resize_binded = false;
			if ( settings.is360 ) {
				viewportImage.removeAttr( 'usemap' ).css( 'left', 0 ).clone().css( 'left', elem_width - 0.8 + 'px' ).insertAfter( viewportImage );
			}
			if ( settings.start_position_centered ) {
				var newMarginLeft = ( - settings.start_position * ( elem_height / settings.image_height ) + ( viewport.width() / 2 ) );
				if ( newMarginLeft > 0 ) {
					newMarginLeft = -elem_width + newMarginLeft;
				}
				settings.setPanoramaPosition( panoramaContainer, newMarginLeft);
			} else {
				settings.setPanoramaPosition( panoramaContainer, - settings.start_position * elem_height / settings.image_height );
			}
			panoramaContainer.css( {
				'width'  : ( elem_width * 2 ) + 'px',
				'height' : ( elem_height ) + 'px'
			} );
			if ( settings.block_contextmenu ) {
				panoramaContainer.addClass( 'no-contextmenu' );
			}

			viewport.off( 'mousedown mouseup mousemove mouseout mousewheel contextmenu touchmove touchend' );
			viewport.on( 'mousedown', function( e ) {
				if ( isDragged ) {
					return false;
				}
				$( this ).addClass( 'grab' );
				isDragged = true;
				mouseXprev = e.clientX;
				return false;
			}).on( 'mouseup', function() {
				$( this ).removeClass( 'grab' );
				isDragged = false;
				if ( settings.sliding_direction ) {
					settings.sliding_direction = scrollDelta > 0 ? -1 : 1;
				}
				scrollDelta = scrollDelta * 0.45;
				if ( settings.sliding_drag_stop ) {
					settings.sliding_direction = 0;
				}
				return false;
			}).on( 'mousemove', function(e) {
				if ( ! isDragged) {
					return false;
				}
				scrollDelta = parseInt( ( e.clientX - mouseXprev ) );
				mouseXprev = e.clientX;
				if ( settings.is360 ) {
					scrollView360( panoramaContainer, elem_width, scrollDelta, settings );
				} else {
					scrollView180( panoramaContainer, elem_width, scrollDelta, settings );
				}
				return false;
			}).on( 'mouseout', function( e ) {
				isDragged = false;
			}).on( 'mousewheel', function( e, distance ) {
				if ( ! settings.mouse_wheel_active ) {
					return;
				}
				var delta = Math.ceil( Math.sqrt( Math.abs( distance ) ) );
				if ( settings.sliding_direction != 0 ) {
					settings.sliding_direction = distance < 0 ? 1 : -1;
				}
				delta = distance < 0 ? -delta : delta;
				scrollDelta = scrollDelta + delta * 5;
				if ( settings.is360 )
					scrollView360( panoramaContainer, elem_width, delta * settings.mouse_wheel_multiplier, settings );
				else
					scrollView180( panoramaContainer, elem_width, delta * settings.mouse_wheel_multiplier, settings );
				settings.sliding_direction = 0;
				return false;
			}).on( 'contextmenu', function (e) {
				if ( settings.block_contextmenu ) {
					e.preventDefault();
					return false;
				}
			}).on( 'touchstart', function(e) {
				if (isDragged) {
					return false;
				}
				isDragged = true;
				mouseXprev = e.originalEvent.touches[0].pageX;
			}).on( 'touchmove', function(e) {
				if ( ! isDragged ) {
					return false;
				}
				var touch_x = e.originalEvent.touches[0].pageX;
				scrollDelta = parseInt( ( touch_x - mouseXprev ) );
				if ( Math.abs( scrollDelta ) > 5 ) {
					e.preventDefault();
				}
				mouseXprev = touch_x;
				if ( settings.is360 ) {
					scrollView360( panoramaContainer, elem_width, scrollDelta, settings );
				} else {
					scrollView180( panoramaContainer, elem_width, scrollDelta, settings );
				}
			}).on( 'touchend', function(e) {
				isDragged = false;
				if ( settings.sliding_direction ) {
					settings.sliding_direction = scrollDelta > 0 ? -1 : 1;
				}
				scrollDelta = scrollDelta * 0.45;
				settings.sliding_direction = 0;
			});
			if ( image_map ) {
				if ( image_map.indexOf( '#' ) < 0 ) {
					image_map = '#' + image_map;
				}
				new_area = $( 'a' ).addClass( 'area' );
				$( 'map' + image_map ).children( 'area' ).each( function() {
					switch ( $( this ).attr( 'shape' ).toLowerCase() ) {
						case 'rect':
							var area_coord = $( this ).attr( 'coords' ).split( ',' );
							var new_area = $( document.createElement( 'a' ) ).addClass( 'area' );
							new_area.attr( 'href', $( this ).attr( 'href' ) );
							new_area.attr( 'title', $( this ).attr( 'alt' ) );
							new_area.attr( 'target', $( this ).attr( 'target' ) );
							if ($( this ).attr( 'rel' ) ) new_area.attr( 'rel', $( this ).attr( 'rel' ) );
							new_area.addClass( $( this ).attr( 'class' ) );
							panoramaContainer.append( new_area.data( 'stitch', 1 ).data( 'coords', area_coord ) );
							if ( settings.is360 ) {
								panoramaContainer.append( new_area.clone().data( 'stitch', 2 ).data( 'coords', area_coord ) );
							}
							break;
					}
				});
				$( 'map' + image_map ).remove();
				image_areas = panoramaContainer.children( '.area' );
				image_areas.on( 'mouseup', stopEvent ).on( 'mousemove', stopEvent ).on( 'mousedown', stopEvent );
				repositionHotspots( image_areas, settings.image_height, elem_height, elem_width );
			}
			if ( settings.sliding_controls ) {
				var controls = viewport.parent().find( '.panorama-controls' );
				if ( controls.length == 0 ) {
					controls = $( '<div class="panorama-controls"><a class="panorama-controls-prev"><span></span></a><a class="panorama-controls-stop"><span></span></a><a class="panorama-controls-next"><span></span></a></div>' ).insertAfter( viewport );
				} else {
					controls.appendTo( viewport );
					viewport.find( 'p:empty' ).remove();
				}
				$( '.panorama-controls-prev', controls ).on( 'click', function( e ) {
					settings.sliding_direction = -1;
					scrollDelta = 0;
					e.preventDefault();
				});
				$( '.panorama-controls-stop', controls ).on( 'click', function( e ) {
					settings.sliding_direction = 0;
					scrollDelta = 0;
					e.preventDefault();
				});
				$( '.panorama-controls-next', controls ).on( 'click', function( e ) {
					settings.sliding_direction = 1;
					scrollDelta = 0;
					e.preventDefault();
				});
			}
			if ( settings.bind_resize && ! resize_binded ) {
				resize_binded = true;
				$( window ).on( 'resize', function() {
					$parent = viewport.parent();
					elem_height = parseInt( $parent.height() );
					elem_width = parseInt( elem_height / image_ratio );
					panoramaContainer.css({
						'width' : elem_width + 'px',
						'height': elem_height + 'px'
					});
					var diff_left = ( parseInt( elem_width ) - elem_width - 0.45 ) * 2;
					viewportImage.css( 'left', 0 ).next().css( 'left', ( elem_width + diff_left ) + 'px' );
					if ( image_map ) {
						repositionHotspots( image_areas, settings.image_height, elem_height, elem_width );
					}
				});
			}
			if ( settings.fullscreen_control && $(document).fullScreen() != null ) {
				var fullscreen = viewport.parent().find( '.panorama-fullscreen' );
				if ( fullscreen.length == 0 ) {
					$( '<div class="panorama-fullscreen"><a class="panorama-fullscreen-toggle"><span></span></a></div>' ).insertAfter( viewport );
				} else {
					fullscreen.appendTo( viewport );
					viewport.find( 'p:empty' ).remove();
				}
				$( '.panorama-fullscreen-toggle', viewport.parent() ).on( 'click', function( e ) {
					viewport.parent().toggleFullScreen();
					e.preventDefault();
				});
				$( viewport.parent() ).on( 'fullscreenchange', function() {
					viewport.parent().toggleClass( 'is-fullscreen', $(document).fullScreen() );
					if ( settings.bind_resize ) {
						jQuery( window ).trigger( 'resize' );
					}
					if ( settings.is360 ) {
						scrollView360( panoramaContainer, elem_width, scrollDelta, settings );
					} else {
						scrollView180( panoramaContainer, elem_width, scrollDelta, settings );
					}
				});
				viewport.on( 'dblclick', function( e ) {
					viewport.parent().toggleFullScreen();
				} );
			}

			function panoramaAnimate() {
				window.requestAnimFrame( panoramaAnimate );
				if ( isDragged ) {
						return false;
				}
				if ( scrollDelta < -2 || 2 < scrollDelta ) {
					scrollDelta *= ( settings.is360 ? 0.97 : 0.98 );
				} else {
					scrollDelta = -settings.sliding_direction * 2 * settings.sliding_factor;
				}
				if ( scrollDelta ) {
					if ( settings.is360 ) {
						scrollView360( panoramaContainer, elem_width, scrollDelta, settings );
					} else {
						scrollView180( panoramaContainer, elem_width, scrollDelta, settings );
					}
				}
			}
			panoramaAnimate();
		});

		function stopEvent( e ) {
			e.preventDefault();
			return false;
		}

		function scrollView180( panoramaContainer, elem_width, delta, settings ) {
			var newMarginLeft = panoramaContainer.data( 'posX' ) + delta;
			var right = - ( elem_width - panoramaContainer.parent().width() );
			if ( newMarginLeft > 0 ) {
				newMarginLeft = 0;
				if ( settings.sliding_direction ) {
					settings.sliding_direction *= -1;
				}
			}
			if ( newMarginLeft < right ) {
				newMarginLeft = right;
				if ( settings.sliding_direction ) {
					settings.sliding_direction *= -1;
				}
			}
			settings.setPanoramaPosition( panoramaContainer, newMarginLeft );
		}

		function scrollView360( panoramaContainer, elem_width, delta, settings ) {
			var newMarginLeft = panoramaContainer.data( 'posX' ) + delta;
			if ( newMarginLeft > 0 ) {
				newMarginLeft = -elem_width;
			}
			if ( newMarginLeft < -elem_width ) {
				newMarginLeft = 0;
			}
			settings.setPanoramaPosition( panoramaContainer, newMarginLeft );
		}

		function repositionHotspots( areas, image_height, elem_height, elem_width ) {
			var percent = elem_height / image_height;
			areas.each( function() {
				area_coord = $( this ).data( 'coords' );
				stitch = $( this ).data( 'stitch' );
				switch ( stitch ) {
					case 1:
						$( this ).css({
							'left'  : ( area_coord[0] * percent ) + 'px',
							'top'   : ( area_coord[1] * percent ) + 'px',
							'width' : ( ( area_coord[2] - area_coord[0] ) * percent ) + 'px',
							'height': ( ( area_coord[3] - area_coord[1] ) * percent ) + 'px'
						});
						break;
					case 2:
						$( this ).css({
							'left'  : ( elem_width + parseInt( area_coord[0] ) * percent ) + 'px',
							'top'   : ( area_coord[1] * percent ) + 'px',
							'width' : ( ( area_coord[2] - area_coord[0] ) * percent ) + 'px',
							'height': ( ( area_coord[3] - area_coord[1] ) * percent ) + 'px'
						});
						break;
				}
			});
		}
	};

})( jQuery );

function triggerPanoramaInit( target ) {
	jQuery( '.wp-block-panorama360-flat-image .panorama-view, .panorama360.type-flat .panorama-view', target ).each( function() {
		$this = jQuery( this );
		if ( $this.hasClass( 'panorama-view-init' ) ) {
			return;
		}

		$this.addClass( 'panorama-view-init' );
		var $defaults = {};
		if ( typeof $this.data( 'width' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { image_width : $this.data( 'width' ) } );
		}
		if ( typeof $this.data( 'height' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { image_height : $this.data( 'height' ) } );
		}
		if ( typeof $this.data( 'start-position' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { start_position : $this.data( 'start-position' ) } );
		}
		if ( typeof $this.data( 'start-position-centered' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { start_position_centered : $this.data( 'start-position-centered' ) } );
		}
		if ( typeof $this.data( 'mousewheel-multiplier' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { mouse_wheel_multiplier : $this.data( 'mousewheel-multiplier' ) } );
		}
		if ( typeof $this.data( 'mousewheel' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { mouse_wheel_active : $this.data( 'mousewheel' ) } );
		}
		if ( typeof $this.data( 'bind-resize' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { bind_resize : $this.data( 'bind-resize' ) } );
		}
		if ( typeof $this.data( 'is360' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { is360 : $this.data( 'is360' ) } );
		}
		if ( typeof $this.data( 'sliding-controls' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_controls : $this.data( 'sliding-controls' ) } );
		}
		if ( typeof $this.data( 'sliding-controls' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_controls : $this.data( 'sliding-controls' ) } );
		}
		if ( typeof $this.data( 'fullscreen-control' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { fullscreen_control : $this.data( 'fullscreen-control' ) } );
		}
		if ( typeof $this.data( 'sliding-direction' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_direction : $this.data( 'sliding-direction' ) } );
		}
		if ( typeof $this.data( 'sliding-factor' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_factor : $this.data( 'sliding-factor' ) } );
		}
		if ( typeof $this.data( 'sliding-drag-stop' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_drag_stop : $this.data( 'sliding-drag-stop' ) } );
		}
		if ( typeof $this.data( 'block-contextmenu' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { block_contextmenu : $this.data( 'block-contextmenu' ) } );
		}
		$this.panorama360( $defaults );
	});
}

window.requestAnimFrame = (function() {
	return window.requestAnimationFrame  ||
		window.webkitRequestAnimationFrame ||
		window.mozRequestAnimationFrame    ||
		window.oRequestAnimationFrame      ||
		window.msRequestAnimationFrame     ||
		function( callback ){
			window.setTimeout(callback, 1000 / 60);
		};
})();

jQuery( function() {
	triggerPanoramaInit( document.body );
});

jQuery( document ).on( 'cerchezWidgetUpdate', function(e) {
	triggerPanoramaInit( e.target );
});
