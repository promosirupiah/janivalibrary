/*!
 * 360 Panoramic Viewer - Equirectangular Image
 * https://codecanyon.net/item/360-panoramic-viewer-wordpress-plugin/5054590
 * by Liviu Cerchez
 */
( function( $ ) {
	$.fn.panorama360EquiRect = function( options ) {
		return this.each( function() {
			var settings = {
				src: '',
				mouse_wheel_active: 0,
				mouse_wheel_multiplier: 10,
				bind_resize: true, // determine if window resize affects panorama viewport
				start_position: 0, // initial start position for the view
				sliding_controls: true, // determine if UI controls for sliding are created
				sliding_direction: 0, // determines the automatic sliding direction: 0 - no automatic slide effect, 1 - right side effect, -1 - left side effect
				sliding_factor: 8, // determines the automatic sliding multiplier factor
				sliding_drag_stop: true, // determines if automatic sliding is stopped on mouse/touch dragging events
				fullscreen_control: 0, // determine if UI control for toggling fullscreen is enabled
				zoom_controls: 0, // determine if UI controls for zooming
				block_contextmenu: 0, // determines if the context menu is blocked (right click)
				min_fov: 15,
				max_fov: 75,
				pointer_factor: 0.13
			};
			if ( options ) {
				$.extend( settings, options );
			}
			var panoramaContainer = $( this );
			var elem_width = parseInt( panoramaContainer.width() );
			var elem_height = parseInt( panoramaContainer.height() );
			var docIsVisible = true, resize_binded = false;
			var camera, scene, renderer,
				accelerationFactor = 1,
				isUserInteracting = false,
				isUserRotating = 0,
				onPointerDownMouseX = 0, onPointerDownMouseY = 0,
				lon = settings.start_position, onPointerDownLon = 0,
				lat = 0, onPointerDownLat = 0,
				phi = 0, theta = 0;

			var texture = THREE.ImageUtils.loadTexture( settings.src, new THREE.UVMapping(), function() {
				panoramaInit();
				panoramaAnimate();
			});

			function panoramaInit() {
				camera = new THREE.PerspectiveCamera( settings.max_fov, elem_width / elem_height, 1, 1000 );
				scene = new THREE.Scene();
				var mesh = new THREE.Mesh( new THREE.SphereGeometry( 500, 60, 40 ), new THREE.MeshBasicMaterial( { map: texture } ) );
				mesh.scale.x = -1;
				scene.add( mesh );
				renderer = new THREE.WebGLRenderer( { antialias: true } );
				renderer.setSize( elem_width, elem_height );
				panoramaContainer.append( renderer.domElement ).removeAttr( 'data-src' ).on( 'pointerdown', function( e ) {
					e.preventDefault();
					if ( jQuery ( e.target ).is( 'canvas' ) && 0 === e.originalEvent.button ) {
						isUserInteracting = true;
						onPointerDownMouseX = e.originalEvent.clientX;
						onPointerDownMouseY = e.originalEvent.clientY;
						onPointerDownLon = lon;
						onPointerDownLat = lat;
						panoramaContainer.addClass( 'grab' );
					}
				}).on( 'pointermove', function( e ) {
					if ( isUserInteracting ) {
						lon = ( onPointerDownMouseX - e.originalEvent.clientX ) * settings.pointer_factor + onPointerDownLon;
						lat = ( onPointerDownMouseY - e.originalEvent.clientY ) * settings.pointer_factor + onPointerDownLat;
					}
				}).on( 'pointerup', function( e ) {
					if ( isUserInteracting ) {
						isUserInteracting = false;
						if ( settings.sliding_drag_stop ) {
							settings.sliding_direction = 0;
						} else {
							if ( 0 !== settings.sliding_direction ) {
								settings.sliding_direction = ( onPointerDownMouseX - e.originalEvent.clientX > 0 ? 1 : -1 );
							}
						}
						panoramaContainer.removeClass( 'grab' );
					}
				}).on( 'mousewheel', function( e, distance ) {
					if ( ! settings.mouse_wheel_active ) {
						return;
					}
					var delta = Math.ceil( Math.sqrt( Math.abs( distance ) ) );
					delta = distance < 0 ? delta : -delta;
					window.cancelAnimationFrame( zoomRequestID );
					panoramaSmoothZoom( camera.fov + delta * settings.mouse_wheel_multiplier, 200 );
					return false;
				});

				if ( settings.sliding_controls ) {
					if ( panoramaContainer.find( '.panorama-controls' ).length == 0 ) {
						panoramaContainer.append( '<div class="panorama-controls"><a class="panorama-controls-up"><span></span></a><a class="panorama-controls-right"><span></span></a><a class="panorama-controls-down"><span></span></a><a class="panorama-controls-left"><span></span></a><a class="panorama-controls-stop"><span></span></a></div>' );
					}
					$( '.panorama-controls-left', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
						settings.sliding_direction = -1;
						accelerationFactor += THREE.Math.clamp( settings.sliding_factor / 2, 2, 6 );
						e.preventDefault();
					}).on( 'pointerup', function( e ) {
						accelerationFactor = 1;
						e.preventDefault();
					});
					$( '.panorama-controls-right', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
						settings.sliding_direction = 1;
						accelerationFactor += THREE.Math.clamp( settings.sliding_factor / 2, 3, 5 );
						e.preventDefault();
					}).on( 'pointerup', function( e ) {
						accelerationFactor = 1;
						e.preventDefault();
					});
					$( '.panorama-controls-up', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
						settings.sliding_direction = 0;
						isUserRotating = -1;
						accelerationFactor += THREE.Math.clamp( settings.sliding_factor / 2, 3, 5 );
						e.preventDefault();
					}).on( 'pointerup', function( e ) {
						isUserRotating = 0;
						accelerationFactor = 1;
						e.preventDefault();
					});
					$( '.panorama-controls-down', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
						settings.sliding_direction = 0;
						isUserRotating = 1;
						accelerationFactor += THREE.Math.clamp( settings.sliding_factor / 2, 3, 5 );
						e.preventDefault();
					}).on( 'pointerup', function( e ) {
						isUserRotating = 0;
						accelerationFactor = 1;
						e.preventDefault();
					});
					$( '.panorama-controls-stop', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
						settings.sliding_direction = 0;
						e.preventDefault();
					});
				}

				if ( settings.block_contextmenu ) {
					panoramaContainer.on( 'contextmenu', function( e ) {
						e.preventDefault();
					} );
				}

				if ( settings.bind_resize && ! resize_binded ) {
					resize_binded = true;
					$( window ).on( 'resize', function( e ) {
						elem_width = parseInt( panoramaContainer.width() );
						elem_height = parseInt( panoramaContainer.height() );
						camera.aspect = elem_width / elem_height;
						camera.updateProjectionMatrix();
						renderer.setSize( elem_width, elem_height );
					} );
				}

				if ( settings.fullscreen_control && $( document ).fullScreen() != null ) {
					if ( panoramaContainer.find( '.panorama-fullscreen' ).length == 0 ) {
						panoramaContainer.append( $( '<div class="panorama-fullscreen"><a class="panorama-fullscreen-toggle"><span></span></a></div>' ) );
					}
					$( '.panorama-fullscreen-toggle', panoramaContainer ).on( 'click', function( e ) {
						panoramaContainer.toggleFullScreen();
						e.preventDefault();
					} );
					$( panoramaContainer ).on( 'fullscreenchange', function() {
						panoramaContainer.toggleClass( 'is-fullscreen', $(document ).fullScreen() );
						if ( settings.bind_resize ) {
							$( window ).trigger( 'resize' );
						}
					});
					$( 'canvas', panoramaContainer ).on( 'dblclick', function( e ) {
						panoramaContainer.toggleFullScreen();
					} );
				}

				if ( settings.zoom_controls ) {
					if ( panoramaContainer.find( '.panorama-zoom' ).length == 0 ) {
						panoramaContainer.append( '<div class="panorama-zoom"><a class="panorama-zoom-in"><span></span></a><a class="panorama-zoom-out"><span></span></a></div>' );
					}
					$( '.panorama-zoom-in', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
							panoramaSmoothZoom( settings.min_fov, 1500 );
					}).on( 'pointerup', function( e ) {
						window.cancelAnimationFrame( zoomRequestID );
						e.preventDefault();
					});
					$( '.panorama-zoom-out', panoramaContainer ).on( 'pointerdown', function( e ) {
						if ( 0 !== e.originalEvent.button ) return;
							panoramaSmoothZoom( settings.max_fov, 1500 );
					}).on( 'pointerup', function( e ) {
						window.cancelAnimationFrame( zoomRequestID );
						e.preventDefault();
					});
				}

				$( document ).on( 'visibilitychange', function (event) {
					docIsVisible = ( document.visibilityState !== 'hidden' )
				});
			}

			// Performant smooth zooming using requestAnimationFrame
			var zoomRequestID;
			function panoramaSmoothZoom( level, animDuration = 200 ) {
				var start = camera.fov;
				var difference = level - start;
				var startTime = window.performance.now();

				function zoomStep() {
					var progress = ( window.performance.now() - startTime ) / animDuration - 1;
					var amount = progress * progress * progress + 1; // easeOutCubic
					camera.fov = THREE.Math.clamp( start + amount * difference, settings.min_fov, settings.max_fov );
					camera.updateProjectionMatrix();
					if ( progress < 0 ) {
						zoomRequestID = window.requestAnimFrame( zoomStep );
					}
				}
				zoomStep();
			}

			function panoramaAnimate() {
				window.requestAnimFrame( panoramaAnimate );
				if ( docIsVisible ) {
					panoramaRender();
				}
			}

			function panoramaRender() {
				if ( false === isUserInteracting && 0 !== settings.sliding_direction ) {
					lon += settings.sliding_direction * settings.sliding_factor / 100 * accelerationFactor;
				}
				if ( 0 !== isUserRotating ) {
					lat += isUserRotating * settings.sliding_factor / 100 * accelerationFactor;
				}
				lat = Math.max( -85, Math.min( 85, lat ) );
				phi = THREE.Math.degToRad( 90 - lat );
				theta = THREE.Math.degToRad( lon );
				camera.position.x = 100 * Math.sin( phi ) * Math.cos( theta );
				camera.position.y = 100 * Math.cos( phi );
				camera.position.z = 100 * Math.sin( phi ) * Math.sin( theta );
				camera.lookAt( scene.position );
				renderer.render( scene, camera );
			}
		});
	};
})( jQuery );

function triggerPanoramaEquiRectInit( target ) {
	jQuery( '.wp-block-panorama360-equirectangular-image .panorama360, .panorama360.type-equirectangular', target ).each( function() {
		$this = jQuery( this );
		if ( $this.hasClass( 'panorama-init' ) ) {
			return;
		}

		$this.addClass( 'panorama-init' );
		var $defaults = {};
		if ( typeof $this.data( 'src' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { src : $this.data( 'src' ) } );
		}
		if ( typeof $this.data( 'mousewheel' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { mouse_wheel_active : $this.data( 'mousewheel' ) } );
		}
		if ( typeof $this.data( 'mousewheel-multiplier' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { mouse_wheel_multiplier : $this.data( 'mousewheel-multiplier' ) } );
		}
		if ( typeof $this.data( 'bind-resize' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { bind_resize : $this.data( 'bind-resize' ) } );
		}
		if ( typeof $this.data( 'start-position' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { start_position : $this.data( 'start-position' ) } );
		}
		if ( typeof $this.data( 'sliding-controls' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_controls : $this.data( 'sliding-controls' ) } );
		}
		if ( typeof $this.data( 'sliding-direction' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_direction : $this.data( 'sliding-direction' ) } );
		}
		if ( typeof $this.data( 'sliding-factor' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_factor : $this.data( 'sliding-factor' ) } );
		}
		if ( typeof $this.data( 'sliding-drag-stop' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { sliding_drag_stop : $this.data( 'sliding-drag-stop' ) } );
		}
		if ( typeof $this.data( 'fullscreen-control' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { fullscreen_control : $this.data( 'fullscreen-control' ) } );
		}
		if ( typeof $this.data( 'zoom-controls' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { zoom_controls : $this.data( 'zoom-controls' ) } );
		}
		if ( typeof $this.data( 'block-contextmenu' ) !== 'undefined' ) {
			jQuery.extend( $defaults, { block_contextmenu : $this.data( 'block-contextmenu' ) } );
		}
		$this.panorama360EquiRect( $defaults );
	});
}

window.requestAnimFrame = (function() {
	return window.requestAnimationFrame  ||
		window.webkitRequestAnimationFrame ||
		window.mozRequestAnimationFrame    ||
		window.oRequestAnimationFrame      ||
		window.msRequestAnimationFrame     ||
		function( callback ){
			window.setTimeout(callback, 1000 / 60);
		};
})();

jQuery( function() {
	triggerPanoramaEquiRectInit( document.body );
});

jQuery( document ).on( 'cerchezWidgetUpdate', function( e ) {
	triggerPanoramaEquiRectInit( e.target );
});
