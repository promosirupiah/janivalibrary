var el = wp.element.createElement,
	__ = wp.i18n.__,
	blockAttributes = {
		src: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360',
			attribute: 'data-src',
		},
		src_id: {
			type: 'number',
		},
		id: {
			type: 'string',
		},
		title: {
			type: 'string',
			source: 'text',
			selector: '.panorama360 .panorama-title',
		},
		title_link: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360 .panorama-title',
			attribute: 'href',
		},
		title_link_target: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360 .panorama-title',
			attribute: 'target',
		},
		start_position: {
			type: 'number',
			default: 0,
		},
		sliding_controls: {
			type: 'boolean',
			default: true,
		},
		sliding_direction: {
			type: 'number',
			default: 0,
		},
		sliding_factor: {
			type: 'number',
			default: 8,
		},
		sliding_drag_stop: {
			type: 'boolean',
			default: true,
		},
		fullscreen_control: {
			type: 'boolean',
			default: false,
		},
		zoom_controls: {
			type: 'boolean',
			default: false,
		},
		style: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360',
			attribute: 'style',
		},
		mousewheel: {
			type: 'boolean',
			default: false,
		},
		mousewheel_multiplier: {
			type: 'number',
			default: 10,
		},
		bind_resize: {
			type: 'boolean',
			default: true,
		},
		block_contextmenu: {
			type: 'boolean',
			default: false,
		},
		align: {
			type: 'string',
		},
	},
	blockIcon = el(
		'svg', {
			width: 24,
			height: 24,
			role: 'img',
			focusable: 'false'
		},
		el( 'path', {
			d: "m23 9.9v4.1c0 0.8-0.5 1.4-1.1 1.8-0.3 0.2-0.6 0.4-0.9 0.5-1.6 3.4-5 5.7-9 5.7-4 0-7.4-2.3-9-5.7-0.3-0.1-0.7-0.3-1-0.4-0.6-0.4-1-1.1-1-1.8v-4.2c0-0.7 0.4-1.4 1.1-1.8 0.2-0.1 0.6-0.3 0.9-0.4 1.6-3.4 5-5.7 9-5.7 4 0 7.4 2.3 9 5.7 0.3 0.1 0.7 0.3 1 0.4 0.6 0.4 1 1.1 1 1.8zm-11-1.9c-3.5 0-6.8 0.7-9 1.9v4.2c2.2 1.2 5.5 1.9 9 1.9 3.5 0 6.8-0.7 9-1.9v-4.2c-2.2-1.2-5.5-1.9-9-1.9zm-5.9-1.3c1.7-0.5 3.8-0.7 5.9-0.7 2.1 0 4.2 0.2 6 0.7-1.5-1.7-3.6-2.7-6-2.7-2.4 0-4.5 1-5.9 2.7zm11.9 10.6c-1.8 0.5-3.9 0.7-6 0.7-2.1 0-4.2-0.2-5.9-0.7 1.4 1.7 3.5 2.7 5.9 2.7 2.4 0 4.5-1 6-2.7zm-1-3.3h-10l2.5-3.2 1.8 2.1 2.5-3.2z"
		})
	);

wp.blocks.registerBlockType('panorama360/equirectangular-image', {
	title: __( 'Equirectangular Panorama' ),
	description: __( 'Add an equirectangular panoramic image.' ),
	icon: blockIcon,
	category: 'media',
	keywords: [__( 'panorama' )],
	supports: {
		html: false
	},
	attributes: blockAttributes,
	transforms: {
		from: [
			{
				type: 'block',
				blocks: [ 'core/image' ],
				transform: function ( blockAttributes ) {
					var newStyle = '';
					if ( undefined !== blockAttributes.height && blockAttributes.height > 0 ) {
						newStyle = 'height: 400px; margin-bottom: 1.5em';
					}
					var newTitle = ( blockAttributes.caption && blockAttributes.caption.constructor === Array ? blockAttributes.caption[0]: undefined );
					var new_attributes = {
						src: blockAttributes.url,
						src_id: blockAttributes.id,
						style: newStyle,
						align: blockAttributes.align,
						title: newTitle,
						title_link: ( undefined !== newTitle && blockAttributes.hasOwnProperty( 'href' ) ? blockAttributes.href : undefined )
					};
					return wp.blocks.createBlock( 'panorama360/equirectangular-image', new_attributes );
				}
			}
		],
		to: [
			{
				type: 'block',
				blocks: [ 'core/image' ],
				transform: function ( blockAttributes ) {
					var new_attributes = {
						url: blockAttributes.src,
						id: blockAttributes.src_id,
						align: blockAttributes.align,
						caption: [ blockAttributes.title ],
						href: blockAttributes.title_link,
						linkDestination: ( blockAttributes.title_link && blockAttributes.title_link.length > 0 ? 'custom' : 'none' )
					};
					return wp.blocks.createBlock( 'core/image', new_attributes );
				},
			},
			{
				type: 'block',
				blocks: [ 'panorama360/flat-image' ],
				transform: function ( blockAttributes ) {
					var new_attributes = {
						src: blockAttributes.src,
						src_id: blockAttributes.src_id,
						align: blockAttributes.align,
						style: blockAttributes.style,
						title: blockAttributes.title,
						title_link: blockAttributes.title_link,
						title_link_target: blockAttributes.title_link,
						sliding_controls: blockAttributes.sliding_controls,
						sliding_direction: blockAttributes.sliding_direction,
						fullscreen_control: blockAttributes.fullscreen_control,
						mousewheel: blockAttributes.mousewheel,
						mousewheel_multiplier: blockAttributes.mousewheel_multiplier,
						bind_resize: blockAttributes.bind_resize,
						block_contextmenu: blockAttributes.block_contextmenu
					};
					return wp.blocks.createBlock( 'panorama360/flat-image', new_attributes );
				},
			},
			{
				type: 'block',
				blocks: [ 'core/cover' ],
				transform: function ( blockAttributes ) {
					var new_attributes = {
						url: blockAttributes.src,
						id: blockAttributes.src_id,
						align: blockAttributes.align,
						title: [ blockAttributes.title ],
					};
					return wp.blocks.createBlock( 'core/cover', new_attributes );
				},
			}
		]
	},

	getEditWrapperProps: function( attributes) {
		var align = attributes.align;
		if ('wide' === align || 'full' === align) {
			return {
				'data-align': align
			};
		}
	},

	edit: function( props ) {
		var attributes = props.attributes,
			setAttributes = props.setAttributes,
			focus = props.focus;

		if ( attributes.src && ! attributes.style ) {
			var img = new Image();
			img.onload = function() {
				if ( this.height > 0 ) {
					setAttributes({
						style: ( ! attributes.style || 0 == attributes.style.length ? 'height: 400px; margin-bottom: 1.5em;' : attributes.style )
					});
				}
			};
			img.src = attributes.src;
		}

		return [
			attributes.src && el(wp.blockEditor.BlockControls, {
					key: 'controls'
				},
				el(wp.blockEditor.BlockAlignmentToolbar, {
					value: attributes.align,
					controls: ['wide', 'full'],
					onChange: function( newAlignment ) {
						props.setAttributes({
							align: newAlignment
						});
					}
				}),
				el(wp.blockEditor.MediaReplaceFlow, {
					allowedTypes: [ 'image' ],
					accept: 'image/*',
					mediaId: attributes.src_id,
					mediaURL: attributes.src,
					onSelect: function( media ) {
						if ( ! media || ! media.url ) {
							return;
						}
						var el_style = 'height: 400px; margin-bottom: 1.5em;';
						setAttributes({
							src: media.url,
							src_id: media.id,
							style: ( ! attributes.style || 0 == attributes.style.length ? el_style : attributes.style )
						});
					},
					onSelectURL: function( newMedia ) {
						setAttributes({
							src: newMedia,
						});
					}
				})
			),
			attributes.src && el(wp.blockEditor.InspectorControls, {
					key: 'inspector'
				},
				el(wp.components.PanelBody, {
						title: __( 'Basic Options' ),
						initialOpen: true,
					},
					el(wp.components.ToggleControl, {
						label: __( 'Sliding controls' ),
						checked: attributes.sliding_controls,
						onChange: function( newVal ) {
							setAttributes({ sliding_controls: newVal });
						},
					}),
					el(wp.components.SelectControl, {
						label: __( 'Sliding direction' ),
						help: __( 'Determine the automatic sliding direction.' ),
						value: attributes.sliding_direction,
						options: [{
								value: 0,
								label: __( 'No automatic slide effect' )
							},
							{
								value: 1,
								label: __( 'Right automatic slide effect' )
							},
							{
								value: -1,
								label: __( 'Left automatic slide effect' )
							}
						],
						onChange: function( newVal ) {
							setAttributes({ sliding_direction: parseInt( newVal ) });
						},
					}),
					el(wp.components.ToggleControl, {
						label: __( 'Fullscreen control' ),
						checked: attributes.fullscreen_control,
						onChange: function( newVal ) {
							setAttributes({ fullscreen_control: newVal });
						},
					}),
					el(wp.components.ToggleControl, {
						label: __( 'Zoom controls' ),
						checked: attributes.zoom_controls,
						onChange: function( newVal ) {
							setAttributes({ zoom_controls: newVal });
						},
					}),
					el(wp.components.TextControl, {
						label: __( 'Title' ),
						value: attributes.title,
						onChange: function( newTitle ) {
							setAttributes({ title: newTitle });
						},
					}),
					el(wp.components.TextControl, {
						label: __( 'Title link' ),
						type: 'url',
						value: attributes.title_link,
						onChange: function( newLink) {
							setAttributes({ title_link: newLink });
						},
					}),
					el(wp.components.ToggleControl, {
						label: __( 'Open title link in new page/tab' ),
						checked: ( '' !== attributes.title_link_target ),
						onChange: function( newVal ) {
							setAttributes({ title_link_target: ( newVal ? '_blank' : '' ) });
						},
					}),
					el(wp.components.TextControl, {
						label: __( 'Style' ),
						help: __( 'Add specific CSS style to the panorama container (height, margin, etc).' ),
						type: 'text',
						value: attributes.style,
						onChange: function( newStyle ) {
							setAttributes({ style: newStyle });
						},
					})
				),
				el(wp.components.PanelBody, {
						title: __( 'More Options' ),
						initialOpen: true,
					},
					el(wp.components.RangeControl, {
						label: __( 'Start position' ),
						help: __( 'Initial start position angle for the view (in degrees).' ),
						type: 'number',
						value: attributes.start_position,
						min: -359,
						max: 359,
						step: 1,
						onChange: function( newLink ) {
							setAttributes({ start_position: newLink });
						},
					}),
					el(wp.components.RangeControl, {
						label: __( 'Sliding factor' ),
						help: __( 'Determine the automatic sliding multiplier factor (use this with care).' ),
						value: attributes.sliding_factor,
						min: 1,
						max: 50,
						step: 1,
						onChange: function( newVal ) {
							setAttributes({ sliding_factor: newVal });
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Sliding drag stop' ),
						help: __( 'Stop any automatic sliding on mouse/touch dragging events.' ),
						checked: attributes.sliding_drag_stop,
						onChange: function( newVal ) {
							setAttributes({
								sliding_drag_stop: newVal
							});
						},
					}),
					el(wp.components.ToggleControl, {
						label: __( 'Mousewheel' ),
						help: __( 'Use mouse wheel to control the scroll.' ),
						checked: attributes.mousewheel,
						onChange: function( newVal ) {
							setAttributes({ mousewheel: newVal });
						},
					}),
					el( wp.components.RangeControl, {
						label: __( 'Mousewheel factor' ),
						help: __( 'Determine the mousewheel scrolling factor.' ),
						value: attributes.mousewheel_multiplier,
						min: 1,
						max: 30,
						step: 1,
						onChange: function( newVal ) {
							setAttributes( { mousewheel_multiplier: newVal } );
						},
					} ),
					el(wp.components.ToggleControl, {
						label: __( 'Block right click' ),
						help: __( 'Determine if the context menu is blocked (right click).' ),
						checked: attributes.block_contextmenu,
						onChange: function( newVal ) {
							setAttributes({ block_contextmenu: newVal });
						},
					}),
					el(wp.components.ToggleControl, {
						label: __( 'Bind resize' ),
						help: __( 'Determine if window resize affects panorama viewport (making it responsive).' ),
						checked: attributes.bind_resize,
						onChange: function( newVal ) {
							setAttributes({ bind_resize: newVal });
						},
					}),
					el(wp.components.TextControl, {
						label: __( 'ID' ),
						help: __( 'Assign an ID attribute to the panorama markup.' ),
						type: 'text',
						value: attributes.id,
						onChange: function( newID ) {
							setAttributes({ id: newID });
						},
					})
				)
			),
			el( 'div', {
					className: props.className,
				},
				attributes.src && el( 'div', {
						className: 'panorama360',
						style: {
							cssText: attributes.style
						}
					},
					el( 'img', {
						src: attributes.src,
						'data-id': attributes.src_id,
					}),
					el( 'div', {
						className: 'panorama-spinner'
					}),
					attributes.title && attributes.title.length > 0 && el( 'div', {
						className: 'panorama-title'
					}, el( 'a', {
						href: attributes.title_link,
						target: attributes.title_link_target,
					}, attributes.title ) ),
					el( 'div', {
						className: 'sliding-direction'
					}, ( -1 == attributes.sliding_direction ? __( '←' ) : '' ) + ( 1 == attributes.sliding_direction ? __( '→' ) : '' ) ),
					attributes.sliding_controls && el( 'div', {
							className: 'panorama-controls'
						},
						el( 'a', {
							className: 'panorama-controls-up'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-controls-right'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-controls-down'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-controls-left'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-controls-stop'
						}, el( 'span' ))
					),
					attributes.fullscreen_control && el( 'div', {
							className: 'panorama-fullscreen'
						}, el( 'a', {
						}, el( 'span' ) )
					),
					attributes.zoom_controls && el( 'div', {
							className: 'panorama-zoom'
						},
						el( 'a', {
							className: 'panorama-zoom-in'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-zoom-out'
						}, el( 'span' ))
					)
				),
				! attributes.src && el(wp.blockEditor.MediaPlaceholder, {
					allowedTypes: ['image'],
					icon: blockIcon,
					labels: {
						title: __( 'Equirectangular Panorama' )
					},
					accept: "image/*",
					value: attributes.src_id,
					onSelect: function(media) {
						if ( ! media || ! media.url ) {
							return;
						}
						var el_style = 'height: 400px; margin-bottom: 1.5em;';
						setAttributes({
							src: media.url,
							src_id: media.id,
							style: ( ! attributes.style || 0 == attributes.style.length ? el_style : attributes.style )
						});
					},
					onSelectURL: function( newImage ) {
						setAttributes({
							src: newImage
						});
					}
				})
			)
		];
	},

	save: function( props ) {
		var attributes = props.attributes,
			classes = attributes.align ? 'align' + attributes.align : null;

		return el( 'div', {
				className: classes
			},
			el( 'div', {
					className: 'panorama360',
					'data-src': ( attributes.src ? attributes.src : undefined ),
					id: ("undefined" != typeof attributes.id && attributes.id && attributes.id.length > 0 ? attributes.id : undefined ),
					style: ("undefined" != typeof attributes.style && attributes.style && attributes.style.length > 0 ? attributes.style : undefined ),
					'data-start-position': ( attributes.start_position && 8 !== attributes.start_position ? attributes.start_position : undefined ),
					'data-sliding-controls': ( attributes.sliding_controls ? undefined : 'false' ),
					'data-sliding-direction': ( attributes.sliding_direction && 0 !== attributes.sliding_direction ? attributes.sliding_direction : undefined ),
					'data-sliding-factor': ( attributes.sliding_factor && 8 !== attributes.sliding_factor ? attributes.sliding_factor : undefined ),
					'data-sliding-drag-stop': ( attributes.sliding_drag_stop ? undefined : 'false' ),
					'data-fullscreen-control': ( attributes.fullscreen_control ? 'true' : undefined ),
					'data-zoom-controls': ( attributes.zoom_controls ? 'true' : undefined ),
					'data-mousewheel': ( attributes.mousewheel ? 'true' : undefined ),
					'data-mousewheel-multiplier': ( attributes.mousewheel_multiplier && 10 !== attributes.mousewheel_multiplier ? attributes.mousewheel_multiplier : undefined ),
					'data-bind-resize': ( attributes.bind_resize ? undefined : 'false' ),
					'data-block-contextmenu': ( attributes.block_contextmenu ? 'true' : undefined )
				},
				el( 'div', {
					className: 'panorama-spinner'
				}),
				attributes.title && attributes.title.length > 0 && el( 'div', {
					className: 'panorama-title'
				}, el( 'a', {
					href: ( attributes.title_link && attributes.title_link.length > 0 ? attributes.title_link : undefined ),
					target: ( attributes.title_link_target && attributes.title_link_target.length > 0 ? attributes.title_link_target : undefined ),
				}, attributes.title ) )
			)
		);
	},
});
