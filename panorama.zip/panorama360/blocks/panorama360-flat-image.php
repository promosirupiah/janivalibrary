<?php

function init_panorama_flat_image_block() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}

	wp_register_script(
		'panorama360-mousewheel',
		PANORAMA360_PLUGIN_URL . 'assets/js/jquery.mousewheel.js',
		array( 'jquery' )
	);
	wp_register_script(
		'panorama360-fullscreen',
		PANORAMA360_PLUGIN_URL . 'assets/js/jquery.fullscreen.js',
		array( 'jquery' )
	);
	wp_register_script(
		'panorama360-flat',
		PANORAMA360_PLUGIN_URL . 'assets/js/jquery.panorama360-flat.js',
		array( 'jquery', 'panorama360-mousewheel', 'panorama360-fullscreen' )
	);
	wp_register_script(
		'panorama360-flat-image-editor',
		PANORAMA360_PLUGIN_URL . 'blocks/flat-image/flat-block.js',
		array( 'wp-blocks', 'wp-element' ),
		filemtime( PANORAMA360_PLUGIN_DIR . 'blocks/flat-image/flat-block.js' )
	);

	wp_register_style(
		'panorama360-flat',
		PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-flat.css'
	);
	wp_register_style(
		'panorama360-flat-image-editor',
		PANORAMA360_PLUGIN_URL . 'blocks/flat-image/flat-editor.css',
		array( 'wp-edit-blocks' )
	);

	register_block_type( 'panorama360/flat-image', array(
		'style'         => 'panorama360-flat',
		'script'        => 'panorama360-flat',
		'editor_style'  => 'panorama360-flat-image-editor',
		'editor_script' => 'panorama360-flat-image-editor',
	) );
}
add_action( 'init', 'init_panorama_flat_image_block' );
