<?php

function init_panorama_equirectangular_image_block() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}

	wp_register_script(
		'panorama360-threejs',
		PANORAMA360_PLUGIN_URL . 'assets/js/three.min.js',
		array( 'jquery' )
	);
	wp_register_script(
		'panorama360-mousewheel',
		PANORAMA360_PLUGIN_URL . 'assets/js/jquery.mousewheel.js',
		array( 'jquery' )
	);
	wp_register_script(
		'panorama360-fullscreen',
		PANORAMA360_PLUGIN_URL . 'assets/js/jquery.fullscreen.js',
		array( 'jquery' )
	);
	wp_register_script(
		'panorama360-equirectangular',
		PANORAMA360_PLUGIN_URL . 'assets/js/jquery.panorama360-equirectangular.js',
		array( 'jquery', 'panorama360-threejs', 'panorama360-mousewheel', 'panorama360-fullscreen' )
	);
	wp_register_script(
		'panorama360-equirectangular-image-editor',
		PANORAMA360_PLUGIN_URL . 'blocks/equirectangular-image/equirectangular-block.js',
		array( 'wp-blocks', 'wp-element' ),
		filemtime( PANORAMA360_PLUGIN_DIR . 'blocks/equirectangular-image/equirectangular-block.js' )
	);

	wp_register_style(
		'panorama360-equirectangular',
		PANORAMA360_PLUGIN_URL . 'assets/css/panorama360-equirectangular.css'
	);
	wp_register_style(
		'panorama360-equirectangular-image-editor',
		PANORAMA360_PLUGIN_URL . 'blocks/equirectangular-image/equirectangular-editor.css',
		array( 'wp-edit-blocks' )
	);

	register_block_type( 'panorama360/equirectangular-image', array(
		'style'         => 'panorama360-equirectangular',
		'script'        => 'panorama360-equirectangular',
		'editor_style'  => 'panorama360-equirectangular-image-editor',
		'editor_script' => 'panorama360-equirectangular-image-editor',
	) );
}
add_action( 'init', 'init_panorama_equirectangular_image_block' );
