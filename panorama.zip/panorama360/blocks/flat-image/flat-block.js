var el = wp.element.createElement,
	__ = wp.i18n.__,
	blockAttributes = {
		src: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama-container img',
			attribute: 'src',
		},
		src_id: {
			type: 'number',
		},
		src_width: {
			type: 'number',
		},
		src_height: {
			type: 'number',
		},
		src_alt: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama-container img',
			attribute: 'alt',
		},
		id: {
			type: 'string',
		},
		title: {
			type: 'string',
			source: 'text',
			selector: '.panorama360 .panorama-title',
		},
		title_link: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360 .panorama-title',
			attribute: 'href',
		},
		title_link_target: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360 .panorama-title',
			attribute: 'target',
		},
		is360: {
			type: 'boolean',
			default: true,
		},
		start_position: {
			type: 'number',
			default: 0,
		},
		start_position_centered: {
			type: 'boolean',
			default: false,
		},
		sliding_controls: {
			type: 'boolean',
			default: true,
		},
		sliding_direction: {
			type: 'number',
			default: 0,
		},
		sliding_factor: {
			type: 'number',
			default: 0.8,
		},
		sliding_drag_stop: {
			type: 'boolean',
			default: true,
		},
		fullscreen_control: {
			type: 'boolean',
			default: false,
		},
		style: {
			type: 'string',
			source: 'attribute',
			selector: '.panorama360',
			attribute: 'style',
		},
		usemap: {
			type: 'string',
		},
		mousewheel: {
			type: 'boolean',
			default: false,
		},
		mousewheel_multiplier: {
			type: 'number',
			default: 10,
		},
		bind_resize: {
			type: 'boolean',
			default: true,
		},
		block_contextmenu: {
			type: 'boolean',
			default: false,
		},
		align: {
			type: 'string',
		},
	},
	blockIcon = el(
		'svg', {
			width: 24,
			height: 24,
			role: 'img',
			focusable: 'false'
		},
		el( 'path', {
			d: "M23,3.9v16.2c0,0.4-0.2,0.7-0.6,0.7c-0.1,0-0.2,0-0.3-0.1c-3.3-1.2-6.6-1.8-10.1-1.8c-3.4,0-6.8,0.6-10.1,1.8 c-0.1,0.1-0.2,0.1-0.3,0.1c-0.4,0-0.6-0.3-0.6-0.7V3.9c0-0.4,0.2-0.7,0.6-0.7c0.1,0,0.2,0,0.3,0.1C5.2,4.5,8.6,5.1,12,5.1 c3.4,0,6.8-0.6,10.1-1.8c0.1-0.1,0.2-0.1,0.3-0.1C22.8,3.2,23,3.4,23,3.9L23,3.9z M12,7.3C9,7.3,6.1,6.8,3.2,6v12 c2.9-0.8,5.8-1.2,8.8-1.2s5.9,0.4,8.8,1.2V6C17.9,6.9,15,7.3,12,7.3z M5.2,14.9h13.7l-4.4-5.9L11,13.5l-2.5-2.9L5.2,14.9z"
		})
	);

wp.blocks.registerBlockType( 'panorama360/flat-image', {
	title: __( 'Flat Panorama' ),
	description: __( 'Add a flat rectilinear panoramic image.' ),
	icon: blockIcon,
	category: 'media',
	keywords: [__( 'panorama' )],
	supports: {
		html: false
	},
	attributes: blockAttributes,
	transforms: {
		from: [
			{
				type: 'block',
				blocks: [ 'core/image' ],
				transform: function ( blockAttributes ) {
					var newStyle = '';
					if ( undefined !== blockAttributes.height && blockAttributes.height > 0 ) {
						newStyle = 'height: ' + blockAttributes.height + 'px; margin-bottom: 1.5em';
					}
					var newTitle = ( blockAttributes.caption && blockAttributes.caption.constructor === Array ? blockAttributes.caption[0]: undefined );
					var new_attributes = {
						src: blockAttributes.url,
						src_id: blockAttributes.id,
						src_width: blockAttributes.width,
						src_height: blockAttributes.height,
						src_alt: blockAttributes.alt,
						style: newStyle,
						align: blockAttributes.align,
						title: newTitle,
						title_link: ( undefined !== newTitle && blockAttributes.hasOwnProperty( 'href' ) ? blockAttributes.href : undefined )
					};
					return wp.blocks.createBlock( 'panorama360/flat-image', new_attributes );
				}
			},
			{
				type: 'shortcode',
				tag: 'panorama360',
				attributes: {
					src: {
						type: 'string',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'src' ) ? attr.named.src : '' );
						}
					},
					src_width: {
						type: 'number',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'src_width' ) ? attr.named.src_width : undefined );
						}
					},
					src_height: {
						type: 'number',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'src_height' ) ? attr.named.src_height : undefined );
						}
					},
					id: {
						type: 'string',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'id' ) ? attr.named.id : undefined );
						}
					},
					title: {
						type: 'string',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'title' ) ? attr.named.title : '' );
						}
					},
					title_link: {
						type: 'string',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'title_link' ) ? attr.named.title_link : '' );
						}
					},
					title_link_target: {
						type: 'string',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'title_link_target' ) ? attr.named.title_link_target : '' );
						}
					},
					is360: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'is360' ) ? attr.named.is360 : true );
						}
					},
					start_position: {
						type: 'number',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'start_position' ) ? attr.named.start_position : 0 );
						}
					},
					start_position_centered: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'start_position_centered' ) ? attr.named.start_position_centered : false );
						}
					},
					sliding_controls: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'sliding_controls' ) ? attr.named.sliding_controls : true );
						}
					},
					sliding_direction: {
						type: 'number',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'sliding_direction' ) ? attr.named.sliding_direction : 0 );
						}
					},
					sliding_factor: {
						type: 'number',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'sliding_factor' ) ? attr.named.sliding_factor : 0.8 );
						}
					},
					sliding_drag_stop: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'sliding_drag_stop' ) ? attr.named.sliding_drag_stop : true );
						}
					},
					fullscreen_control: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'fullscreen_control' ) ? attr.named.fullscreen_control : true );
						}
					},
					style: {
						type: 'string',
						shortcode: function( attr ) {
							var newStyle = ( attr.named.hasOwnProperty( 'style' ) ? attr.named.style : '' );
							if ( 0 == newStyle.length && attr.named.hasOwnProperty( 'src_height' ) ) {
								newStyle = 'height: ' + attr.named.src_height + 'px; margin-bottom: 1.5em;';
							}
							return newStyle;
						}
					},
					usemap: {
						type: 'string',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'usemap' ) ? attr.named.usemap : undefined );
						}
					},
					mousewheel: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'mousewheel' ) ? attr.named.mousewheel : true );
						}
					},
					mousewheel_multiplier: {
						type: 'number',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'mousewheel_multiplier' ) ? attr.named.mousewheel_multiplier : 10 );
						}
					},
					bind_resize: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'bind_resize' ) ? attr.named.bind_resize : true );
						}
					},
					block_contextmenu: {
						type: 'boolean',
						shortcode: function( attr ) {
							return ( attr.named.hasOwnProperty( 'block_contextmenu' ) ? attr.named.block_contextmenu : false );
						}
					}
				}
			}
		],
		to: [
			{
				type: 'block',
				blocks: [ 'panorama360/equirectangular-image' ],
				transform: function ( blockAttributes ) {
					var new_attributes = {
						src: blockAttributes.src,
						src_id: blockAttributes.src_id,
						align: blockAttributes.align,
						style: blockAttributes.style,
						title: blockAttributes.title,
						title_link: blockAttributes.title_link,
						title_link_target: blockAttributes.title_link,
						sliding_controls: blockAttributes.sliding_controls,
						sliding_direction: blockAttributes.sliding_direction,
						sliding_drag_stop: blockAttributes.sliding_drag_stop,
						fullscreen_control: blockAttributes.fullscreen_control,
						mousewheel: blockAttributes.mousewheel,
						mousewheel_multiplier: blockAttributes.mousewheel_multiplier,
						bind_resize: blockAttributes.bind_resize,
						block_contextmenu: blockAttributes.block_contextmenu
					};
					return wp.blocks.createBlock( 'panorama360/equirectangular-image', new_attributes );
				},
			},
			{
				type: 'block',
				blocks: [ 'core/image' ],
				transform: function ( blockAttributes ) {
					var new_attributes = {
						url: blockAttributes.src,
						id: blockAttributes.src_id,
						alt: blockAttributes.src_alt,
						align: blockAttributes.align,
						caption: [ blockAttributes.title ],
						href: blockAttributes.title_link,
						linkDestination: ( blockAttributes.title_link && blockAttributes.title_link.length > 0 ? 'custom' : 'none' )
					};
					return wp.blocks.createBlock( 'core/image', new_attributes );
				},
			},
			{
				type: 'block',
				blocks: [ 'core/cover' ],
				transform: function ( blockAttributes ) {
					var new_attributes = {
						url: blockAttributes.src,
						id: blockAttributes.src_id,
						alt: blockAttributes.src_alt,
						align: blockAttributes.align,
						title: [ blockAttributes.title ],
					};
					return wp.blocks.createBlock( 'core/cover', new_attributes );
				},
			}
		]
	},

	getEditWrapperProps: function( attributes) {
		var align = attributes.align;
		if ( 'wide' === align || 'full' === align) {
			return {
				'data-align': align
			};
		}
	},

	edit: function(props) {
		var attributes = props.attributes,
			setAttributes = props.setAttributes,
			focus = props.focus;

		if ( attributes.src && ( ! attributes.src_width || ! attributes.src_height ) ) {
			var img = new Image();
			img.onload = function() {
				if (this.width > 0 && this.height > 0) {
					setAttributes({
						src_width: this.width,
						src_height: this.height,
						style: (! attributes.style || 0 == attributes.style.length ? 'height: ' + this.height + 'px; margin-bottom: 1.5em' : attributes.style)
					});
				}
			};
			img.src = attributes.src;
		}

		return [
			attributes.src && el( wp.blockEditor.BlockControls, {
					key: 'controls'
				},
				el( wp.blockEditor.BlockAlignmentToolbar, {
					value: attributes.align,
					controls: ['wide', 'full'],
					onChange: function( newAlignment ) {
						props.setAttributes({
							align: newAlignment
						});
					}
				}),
				el( wp.blockEditor.MediaReplaceFlow, {
					allowedTypes: [ 'image' ],
					accept: 'image/*',
					mediaId: attributes.src_id,
					mediaURL: attributes.src,
					onSelect: function( media ) {
						if (!media || !media.url) {
							return;
						}
						var el_style = media.height ? 'height: ' + media.height + 'px; margin-bottom: 1.5em;' : 'height: 350px; margin-bottom: 1.5em;';
						setAttributes({
							src: media.url,
							src_id: media.id,
							src_width: media.width,
							src_height: media.height,
							src_alt: media.alt,
							style: (! attributes.style || 0 == attributes.style.length ? el_style : attributes.style)
						});
					},
					onSelectURL: function( newMedia ) {
						var img = new Image();
						img.onload = function() {
							if (this.width > 0 && this.height > 0) {
								setAttributes({
									src: newMedia,
									src_width: this.width,
									src_height: this.height
								});
							}
						};
						img.src = newMedia;
					}
				})
			),
			attributes.src && el( wp.blockEditor.InspectorControls, {
					key: 'inspector'
				},
				( attributes.src && (! attributes.src_width || ! attributes.src_height) ) && el( wp.components.PanelBody, {
						title: __( 'Mandatory Options' ),
						initialOpen: true,
					},
					el( wp.components.TextControl, {
						label: __( 'Image width' ),
						help: __( 'The original image width must be defined when the image is not from the local Media Library.' ),
						type: 'number',
						value: attributes.src_width,
						onChange: function( newWidth ) {
							setAttributes({
								src_width: newWidth
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'Image height' ),
						help: __( 'The original image height must be defined when the image is not from the local Media Library.' ),
						type: 'number',
						value: attributes.src_height,
						onChange: function( newHeight ) {
							setAttributes({
								src_height: newHeight
							});
						},
					})
				),
				el( wp.components.PanelBody, {
						title: __( 'Basic Options' ),
						initialOpen: true,
					},
					el( wp.components.ToggleControl, {
						label: __( '360° image' ),
						help: __( 'Determine the rotation type: simple 180° image or 360° (glue left and right to make it scrollable).' ),
						checked: attributes.is360,
						onChange: function( newVal ) {
							setAttributes({
								is360: newVal
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Sliding controls' ),
						checked: attributes.sliding_controls,
						onChange: function( newVal ) {
							setAttributes({
								sliding_controls: newVal
							});
						},
					}),
					el( wp.components.SelectControl, {
						label: __( 'Sliding direction' ),
						help: __( 'Determine the automatic sliding direction.' ),
						value: attributes.sliding_direction,
						options: [{
								value: 0,
								label: __( 'No automatic slide effect' )
							},
							{
								value: 1,
								label: __( 'Right automatic slide effect' )
							},
							{
								value: -1,
								label: __( 'Left automatic slide effect' )
							}
						],
						onChange: function( newVal ) {
							setAttributes({
								sliding_direction: parseInt( newVal )
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Fullscreen control' ),
						checked: attributes.fullscreen_control,
						onChange: function( newVal ) {
							setAttributes({
								fullscreen_control: newVal
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'Title' ),
						value: attributes.title,
						onChange: function( newTitle ) {
							setAttributes({
								title: newTitle
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'Title link' ),
						type: 'url',
						value: attributes.title_link,
						onChange: function(newLink) {
							setAttributes({
								title_link: newLink
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Open title link in new page/tab' ),
						checked: ( '' !== attributes.title_link_target),
						onChange: function( newVal ) {
							if (newVal) {
								newVal = '_blank';
							} else {
								newVal = '';
							}
							setAttributes({
								title_link_target: newVal
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'Style' ),
						help: __( 'Add specific CSS style to the panorama container (height, margin, etc).' ),
						type: 'text',
						value: attributes.style,
						onChange: function( newStyle ) {
							setAttributes({
								style: newStyle
							});
						},
					})
				),
				el( wp.components.PanelBody, {
						title: __( 'More Options' ),
						initialOpen: true,
					},
					el( wp.components.TextControl, {
						label: __( 'Start position' ),
						help: __( 'Initial start position for the view (in pixels).' ),
						type: 'number',
						value: attributes.start_position,
						onChange: function(newLink) {
							setAttributes({
								start_position: newLink
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Start position centered' ),
						help: __( 'Start position gets centered with the viewport.' ),
						checked: attributes.start_position_centered,
						onChange: function( newVal ) {
							setAttributes({
								start_position_centered: newVal
							});
						},
					}),
					el( wp.components.RangeControl, {
						label: __( 'Sliding factor' ),
						help: __( 'Determine the automatic sliding multiplier factor (use this with care).' ),
						value: attributes.sliding_factor,
						min: 0.1,
						max: 2,
						step: 0.1,
						onChange: function( newVal ) {
							setAttributes({
								sliding_factor: newVal
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Sliding drag stop' ),
						help: __( 'Stop any automatic sliding on mouse/touch dragging events.' ),
						checked: attributes.sliding_drag_stop,
						onChange: function( newVal ) {
							setAttributes({
								sliding_drag_stop: newVal
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Mousewheel' ),
						help: __( 'Use mouse wheel to control the scroll.' ),
						checked: attributes.mousewheel,
						onChange: function( newVal ) {
							setAttributes({
								mousewheel: newVal
							});
						},
					}),
					// el( wp.components.RangeControl, {
					// 	label: __( 'Mousewheel factor' ),
					// 	help: __( 'Determine the mousewheel scrolling factor.' ),
					// 	value: attributes.mousewheel_multiplier,
					// 	min: 1,
					// 	max: 100,
					// 	step: 1,
					// 	onChange: function( newVal ) {
					// 		setAttributes( { mousewheel_multiplier: newVal } );
					// 	},
					// } ),
					el( wp.components.ToggleControl, {
						label: __( 'Block right click' ),
						help: __( 'Determine if the context menu is blocked (right click).' ),
						checked: attributes.block_contextmenu,
						onChange: function( newVal ) {
							setAttributes({
								block_contextmenu: newVal
							});
						},
					}),
					el( wp.components.ToggleControl, {
						label: __( 'Bind resize' ),
						help: __( 'Determine if window resize affects panorama viewport (making it responsive).' ),
						checked: attributes.bind_resize,
						onChange: function( newVal ) {
							setAttributes({
								bind_resize: newVal
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'ID' ),
						help: __( 'Assign an ID attribute to the panorama markup.' ),
						type: 'text',
						value: attributes.id,
						onChange: function( newID ) {
							setAttributes({
								id: newID
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'Image textual alternative' ),
						help: __( 'Describe the purpose of the image. Leave empty if the image is not a key part of the content.' ),
						type: 'text',
						value: attributes.src_alt,
						onChange: function( newAlt ) {
							setAttributes({
								src_alt: newAlt
							});
						},
					}),
					el( wp.components.TextControl, {
						label: __( 'Image map' ),
						help: __( 'Assign a "usemap" attribute to the image markup (use it in conjunction with a Custom HTML block having a <map id="map1" name="map1"> tag, where "map1" is unique, it will be the "usemap" value).' ),
						type: 'text',
						value: attributes.usemap,
						onChange: function( newMap ) {
							setAttributes({
								usemap: newMap
							});
						},
					})
				)
			),
			el( 'div', {
					className: props.className,
				},
				attributes.src && el( 'div', {
						className: 'panorama360',
						style: {
							cssText: attributes.style
						}
					},
					el( 'div', {
							className: 'panorama-view'
						},
						el( 'div', {
								className: 'panorama-container'
							},
							el( 'img', {
								src: attributes.src,
								alt: attributes.src_alt,
								'data-id': attributes.src_id,
							})
						),
						el( 'div', {
							className: 'panorama-spinner'
						})
					),
					attributes.title && attributes.title.length > 0 && el( 'div', {
						className: 'panorama-title'
					}, el( 'a', {
						href: attributes.title_link,
						target: attributes.title_link_target,
					}, attributes.title) ),
					attributes.sliding_controls && el( 'div', {
							className: 'panorama-controls'
						},
						el( 'a', {
							className: 'panorama-controls-prev'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-controls-stop'
						}, el( 'span' ) ),
						el( 'a', {
							className: 'panorama-controls-next'
						}, el( 'span' ) )
					),
					attributes.fullscreen_control && el( 'div', {
							className: 'panorama-fullscreen'
						},
						el( 'a', {
						}, el( 'span' ) )
					),
					el( 'a', {
						className: 'panorama-type'
					}, ( -1 == attributes.sliding_direction ? __( '← ' ) : '' ) + ( attributes.is360 ? __( '360°' ) : __( '180°' ) ) + ( 1 == attributes.sliding_direction ? __( ' →' ) : '' ) )
				),
				! attributes.src && el( wp.blockEditor.MediaPlaceholder, {
					allowedTypes: ['image'],
					icon: blockIcon,
					labels: {
						title: __( 'Flat Panorama' )
					},
					accept: "image/*",
					value: attributes.src_id,
					onSelect: function( media ) {
						if (!media || !media.url) {
							return;
						}
						var el_style = media.height ? 'height: ' + media.height + 'px; margin-bottom: 1.5em;' : 'height: 200px; margin-bottom: 1.5em;';
						setAttributes({
							src: media.url,
							src_id: media.id,
							src_width: media.width,
							src_height: media.height,
							src_alt: media.alt,
							style: ( ! attributes.style || 0 == attributes.style.length ? el_style : attributes.style)
						});
					},
					onSelectURL: function( newImage ) {
						setAttributes({
							src: newImage
						});
					}
				})
			)
		];
	},

	save: function(props) {
		var attributes = props.attributes,
			classes = attributes.align ? 'align' + attributes.align : null;

		return el( 'div', {
				className: classes
			},
			el( 'div', {
					className: 'panorama360',
					id: ( "undefined" != typeof attributes.id && attributes.id && attributes.id.length > 0 ? attributes.id : undefined ),
					style: ( "undefined" != typeof attributes.style && attributes.style && attributes.style.length > 0 ? attributes.style : undefined)
				},
				el( 'div', {
						className: 'panorama-view',
						'data-width': attributes.src_width,
						'data-height': attributes.src_height,
						'data-is360': ( attributes.is360 ? undefined : 'false' ),
						'data-start-position': ( attributes.start_position && attributes.start_position > 0 ? attributes.start_position : undefined ),
						'data-start-position-centered': ( attributes.start_position_centered ? 'true' : undefined ),
						'data-sliding-controls': ( attributes.sliding_controls ? undefined : 'false' ),
						'data-sliding-direction': ( attributes.sliding_direction && 0 !== attributes.sliding_direction ? attributes.sliding_direction : undefined ),
						'data-sliding-factor': ( attributes.sliding_factor && 0.8 !== attributes.sliding_factor ? attributes.sliding_factor : undefined ),
						'data-sliding-drag-stop': ( attributes.sliding_drag_stop ? undefined : 'false' ),
						'data-fullscreen-control': ( attributes.fullscreen_control ? 'true' : undefined ),
						'data-mousewheel': ( attributes.mousewheel ? 'true' : undefined ),
						'data-mousewheel-multiplier': ( attributes.mousewheel_multiplier && 10 !== attributes.mousewheel_multiplier ? attributes.mousewheel_multiplier : undefined ),
						'data-bind-resize': ( attributes.bind_resize ? undefined : 'false' ),
						'data-block-contextmenu': ( attributes.block_contextmenu ? 'true' : undefined ),
					},
					el( 'div', {
							className: 'panorama-container'
						},
						el( 'img', {
							src: attributes.src,
							alt: attributes.src_alt,
							useMap: ( attributes.usemap && attributes.usemap.length > 0 ? ( attributes.usemap.indexOf( '#' ) < 0 ? '#' + attributes.usemap : attributes.usemap ) : undefined)
						})
					),
					el( 'div', {
						className: 'panorama-spinner'
					})
				),
				attributes.title && attributes.title.length > 0 && el( 'div', {
					className: 'panorama-title'
				}, el( 'a', {
					href: ( attributes.title_link && attributes.title_link.length > 0 ? attributes.title_link : undefined ),
					target: ( attributes.title_link_target && attributes.title_link_target.length > 0 ? attributes.title_link_target : undefined ),
				}, attributes.title ) )
			)
		);
	},
});