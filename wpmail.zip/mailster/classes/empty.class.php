<?php

class MailsterEmpty {

	/**
	 *
	 *
	 * @param unknown $method
	 * @param unknown $args
	 */
	public function __call( $method, $args ) {

	}


}
