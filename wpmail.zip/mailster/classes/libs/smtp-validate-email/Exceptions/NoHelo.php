<?php

namespace SMTPValidateEmail\Exceptions;

class NoHelo extends Exception
{

}
