<?php

namespace SMTPValidateEmail\Exceptions;

class NoResponse extends Exception
{

}
