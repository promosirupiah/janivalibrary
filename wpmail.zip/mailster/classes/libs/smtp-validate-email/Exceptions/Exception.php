<?php

namespace SMTPValidateEmail\Exceptions;

class Exception extends \Exception
{

}
