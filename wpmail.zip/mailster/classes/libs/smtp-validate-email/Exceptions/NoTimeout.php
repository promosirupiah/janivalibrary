<?php

namespace SMTPValidateEmail\Exceptions;

class NoTimeout extends Exception
{

}
