mailster = (function (mailster, $, window, document) {
	'use strict';

	return mailster;
})(mailster || {}, jQuery, window, document);
