<?php

namespace FluentCampaign\App\Services\Integrations\madxartworkFormIntegration;


class Bootstrap
{
    public function init()
    {

        add_action('init', function () {
            if (!defined('madxartwork_PRO_VERSION')) {
                return;
            }

            if (!class_exists('\madxartworkPro\Plugin') || apply_filters('fluent_crm/disable_madxartwork_form', false)) {
                return;
            }

            $formModule = \madxartworkPro\Plugin::instance()->modules_manager->get_modules('forms');

            if (!$formModule) {
                return;
            }

            $formWidget = new FormWidget();
            // Register the action with form widget
            if (version_compare(madxartwork_PRO_VERSION, '3.5.0', '>')) {
                $formModule->actions_registrar->register($formWidget, $formWidget->get_name());
            } else {
                $formModule->add_form_action($formWidget->get_name(), $formWidget);
            }
        });
    }
}
