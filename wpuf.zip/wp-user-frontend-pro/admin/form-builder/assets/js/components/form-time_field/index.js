/**
 * Field template: Time
 */
Vue.component('form-time_field', {
    template: '#tmpl-wpuf-form-time_field',

    mixins: [
        wpuf_mixins.form_field_mixin
    ]
});
