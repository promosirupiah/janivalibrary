<?php
$l['number'] 						= 'Reference';
$l['date'] 							= 'Billing date';
$l['due'] 							= 'Due date';
$l['to'] 							= 'Billing to';
$l['from'] 							= 'Our information';
$l['product'] 						= 'Product';
$l['amount'] 						= 'Amount';
$l['price'] 						= 'Price';
$l['discount'] 						= 'Discount';
$l['vat'] 							= 'Vat';
$l['total'] 						= 'Total';
$l['page'] 							= 'Page';
$l['page_of'] 						= 'of';
?>