<?php
$l['number'] 						= 'Riferimento';
$l['date'] 							= 'Data di fatturazione';
$l['due'] 							= 'Scadenza';
$l['to'] 							= 'Fatturazione per';
$l['from'] 							= 'Nostre informazioni';
$l['product'] 						= 'Prodotto';
$l['amount'] 						= 'Quantità';
$l['price'] 						= 'Prezzo';
$l['discount'] 						= 'Sconto';
$l['vat'] 							= 'Imposta';
$l['total'] 						= 'Totale';
$l['page'] 							= 'Pagina';
$l['page_of'] 						= 'di';
?>