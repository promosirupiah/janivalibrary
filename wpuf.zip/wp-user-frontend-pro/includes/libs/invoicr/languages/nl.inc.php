<?php
$l['number'] 						= 'Referentie';
$l['date'] 							= 'Aangemaakt';
$l['due'] 							= 'Vervaldatum';
$l['to'] 							= 'Begunstige';
$l['from'] 							= 'Onze gegevens';
$l['product'] 						= 'Product';
$l['amount'] 						= 'Aantal';
$l['price'] 						= 'Prijs';
$l['discount'] 						= 'Korting';
$l['vat'] 							= 'BTW';
$l['total'] 						= 'Totaal';
$l['page'] 							= 'Pagina';
$l['page_of'] 						= 'van de';
?>