=== WP User Frontend Pro - Mailpoet Add-on ===

Add subscribers to mailpoet mailing list when they registers via WP User Frontend Pro


== Instruction ==

 * Goto "User Frontend" -> "Registration Forms"
 * You'll have "Mailpoet" Tab
 * Turn on mailpoet and select the mailing list

== Changelog ==

= version 0.1 =

date: 26 May, 2014

 * Initial release
