<?php
/**
 * @package jet_cct\Upgrade
 */
global $wpdb;

if ( version_compare( $old_version, '1.2.6', '<' ) ) {
    // Add the "required" option
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN required BOOL default 0 AFTER sister_field_id" );

    // Add the "label" option
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN label VARCHAR(32) AFTER name" );

    // Fix table prefixes
    if ( !empty( $table_prefix ) ) {
        $result = $wpdb->get_results( "SHOW TABLES LIKE 'tbl_%'", ARRAY_N );

        foreach ( $result as $row ) {
            jet_cct_query( "RENAME TABLE `{$row[0]}` TO `@wp_{$row[0]}`" );
        }
    }

    // Change the "post_type" of all jet items
    $result = jet_cct_query( "SELECT id, name FROM @wp_jet_types" );

    foreach ( $result as $row ) {
        $datatypes[ $row->id ] = $row->name;
    }

    $result = jet_cct_query( "SELECT post_id, datatype FROM @wp_jet" );

    foreach ( $result as $row ) {
        $datatype = $datatypes[ $row->datatype ];

        jet_cct_query( "UPDATE @wp_posts SET post_type = '$datatype' WHERE ID = $row[0] LIMIT 1" );
    }

    update_option( 'jet_cct_version', '126' );
}

if ( version_compare( $old_version, '1.2.7', '<' ) ) {
    // Add the "comment" option
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN comment VARCHAR(128) AFTER label" );

    update_option( 'jet_cct_version', '127' );
}

if ( version_compare( $old_version, '1.3.1', '<' ) ) {
    $result = $wpdb->get_results( "SHOW TABLES LIKE '{$wpdb->prefix}tbl_%'", ARRAY_N );

    foreach ( $result as $row ) {
        $rename = explode( 'tbl_', $row[ 0 ] );
        jet_cct_query( "RENAME TABLE `{$row[0]}` TO `@wp_jet_tbl_{$rename[1]}`" );
    }

    update_option( 'jet_cct_version', '131' );
}

if ( version_compare( $old_version, '1.3.2', '<' ) ) {
    jet_cct_query( "UPDATE @wp_jet_pages SET phpcode = CONCAT('<" . "?" . "php\n', phpcode) WHERE phpcode NOT LIKE '" . "?" . ">%'" );
    jet_cct_query( "UPDATE @wp_jet_pages SET phpcode = SUBSTR(phpcode, 3) WHERE phpcode LIKE '" . "?" . ">%'" );
    jet_cct_query( "UPDATE @wp_jet_widgets SET phpcode = CONCAT('<" . "?" . "php\n', phpcode) WHERE phpcode NOT LIKE '" . "?" . ">%'" );
    jet_cct_query( "UPDATE @wp_jet_widgets SET phpcode = SUBSTR(phpcode, 3) WHERE phpcode LIKE '" . "?" . ">%'" );

    update_option( 'jet_cct_version', '132' );
}

if ( version_compare( $old_version, '1.4.3', '<' ) ) {
    $result = jet_cct_query( "SHOW COLUMNS FROM @wp_jet_types LIKE 'description'" );

    if ( 0 < count( $result ) )
        jet_cct_query( "ALTER TABLE @wp_jet_types CHANGE description label VARCHAR(32)" );

    jet_cct_query( "ALTER TABLE @wp_jet_types ADD COLUMN is_toplevel BOOL default 0 AFTER label" );

    update_option( 'jet_cct_version', '143' );
}

if ( version_compare( $old_version, '1.4.5', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_pages ADD COLUMN title VARCHAR(128) AFTER uri" );

    $sql = "
        CREATE TABLE @wp_jet_menu (
            id INT unsigned auto_increment primary key,
            uri VARCHAR(128),
            title VARCHAR(128),
            lft INT unsigned,
            rgt INT unsigned,
            weight TINYINT unsigned default 0)";
    jet_cct_query( $sql );

    jet_cct_query( "INSERT INTO @wp_jet_menu (uri, title, lft, rgt) VALUES ('/', 'Home', 1, 2)" );

    update_option( 'jet_cct_version', '145' );
}

if ( version_compare( $old_version, '1.4.8', '<' ) ) {
    add_option( 'jet_cct_roles' );

    update_option( 'jet_cct_version', '148' );
}

if ( version_compare( $old_version, '1.4.9', '<' ) ) {
    jet_cct_query( "RENAME TABLE @wp_jet_widgets TO @wp_jet_helpers" );

    update_option( 'jet_cct_version', '149' );
}

if ( version_compare( $old_version, '1.5', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN `unique` BOOL default 0 AFTER required" );
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN `multiple` BOOL default 0 AFTER `unique`" );
    jet_cct_query( "ALTER TABLE @wp_jet_pages ADD COLUMN page_template VARCHAR(128) AFTER phpcode" );
    jet_cct_query( "ALTER TABLE @wp_jet_helpers ADD COLUMN helper_type VARCHAR(16) AFTER name" );
    jet_cct_query( "ALTER TABLE @wp_jet ADD COLUMN name VARCHAR(128) AFTER datatype" );
    jet_cct_query( "ALTER TABLE @wp_jet ADD COLUMN created VARCHAR(128) AFTER name" );
    jet_cct_query( "ALTER TABLE @wp_jet ADD COLUMN modified VARCHAR(128) AFTER created" );
    jet_cct_query( "ALTER TABLE @wp_jet CHANGE row_id tbl_row_id INT unsigned" );
    jet_cct_query( "ALTER TABLE @wp_jet_rel CHANGE term_id tbl_row_id INT unsigned" );
    jet_cct_query( "ALTER TABLE @wp_jet_rel CHANGE post_id jet_id INT unsigned" );
    jet_cct_query( "ALTER TABLE @wp_jet_rel CHANGE sister_post_id sister_jet_id INT unsigned" );

    // Make all pick columns "multiple" for consistency
    jet_cct_query( "UPDATE @wp_jet_fields SET `multiple` = 1 WHERE coltype = 'pick'" );

    // Use "display" as the default helper type
    jet_cct_query( "UPDATE @wp_jet_helpers SET helper_type = 'display'" );

    // Replace all post_ids with its associated jet_id
    $sql = "
    SELECT
        p.id, p.post_id, r.post_title AS name, r.post_date AS created, r.post_modified AS modified
    FROM
        @wp_jet p
    INNER JOIN
        @wp_posts r ON r.ID = p.post_id
    ";

    $result = jet_cct_query( $sql );

    foreach ( $result as $row ) {
        $row = get_object_vars( $row );

        foreach ( $row as $key => $val ) {
            ${$key} = jet_cct_sanitize( trim( $val ) );
        }

        $posts_to_delete[] = $post_id;
        $all_jet_ids[ $post_id ] = $id;

        jet_cct_query( "UPDATE @wp_jet SET name = '$name', created = '$created', modified = '$modified' WHERE id = $id LIMIT 1" );
    }

    // Replace post_id with jet_id
    $result = jet_cct_query( "SELECT id, jet_id, sister_jet_id FROM @wp_jet_rel" );

    foreach ( $result as $row ) {
        $id = $row->id;
        $new_jet_id = $all_jet_ids[ $row->jet_id ];
        $new_sister_jet_id = $all_jet_ids[ $row->sister_jet_id ];

        jet_cct_query( "UPDATE @wp_jet_rel SET jet_id = '$new_jet_id', sister_jet_id = '$new_sister_jet_id' WHERE id = '$id' LIMIT 1" );
    }

    $posts_to_delete = implode( ',', $posts_to_delete );

    // Remove all traces from wp_posts
    jet_cct_query( "ALTER TABLE @wp_jet DROP COLUMN post_id" );
    jet_cct_query( "DELETE FROM @wp_posts WHERE ID IN ($posts_to_delete)" );

    update_option( 'jet_cct_version', '150' );
}

if ( version_compare( $old_version, '1.5.1', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN helper VARCHAR(32) AFTER label" );
    jet_cct_query( "ALTER TABLE @wp_jet_types ADD COLUMN before_helpers TEXT AFTER tpl_list" );
    jet_cct_query( "ALTER TABLE @wp_jet_types ADD COLUMN after_helpers TEXT AFTER before_helpers" );

    update_option( 'jet_cct_version', '151' );
}

if ( version_compare( $old_version, '1.6.0', '<' ) ) {
    // Add the "templates" table
    $sql = "
    CREATE TABLE IF NOT EXISTS @wp_jet_templates (
        id INT unsigned auto_increment primary key,
        name VARCHAR(32),
        code TEXT)";
    jet_cct_query( $sql );

    // Add list and detail template presets
    $tpl_list = '<p><a href="{@detail_url}">{@name}</a></p>';
    $tpl_detail = "<h2>{@name}</h2>\n{@body}";
    jet_cct_query( "INSERT INTO @wp_jet_templates (name, code) VALUES ('detail', '$tpl_detail'),('list', '$tpl_list')" );

    // Try to route old templates as best as possible
    $result = jet_cct_query( "SELECT name, tpl_detail, tpl_list FROM @wp_jet_types" );

    foreach ( $result as $row ) {
        // Create the new template, e.g. "dtname_list" or "dtname_detail"
        $row = jet_cct_sanitize( $row );

        jet_cct_query( "INSERT INTO @wp_jet_templates (name, code) VALUES ('{$row->name}_detail', '{$row->tpl_detail}'),('{$row->name}_list', '{$row->tpl_list}')" );
    }

    // Drop the "tpl_detail" and "tpl_list" columns
    jet_cct_query( "ALTER TABLE @wp_jet_types DROP COLUMN tpl_detail, DROP COLUMN tpl_list" );

    // Add the "pick_filter" column
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN pick_filter VARCHAR(128) AFTER pickval" );

    update_option( 'jet_cct_version', '160' );
}

if ( version_compare( $old_version, '1.6.2', '<' ) ) {
    // Remove all beginning and ending slashes from jet Pages
    jet_cct_query( "UPDATE @wp_jet_pages SET uri = TRIM(BOTH '/' FROM uri)" );

    update_option( 'jet_cct_version', '162' );
}

if ( version_compare( $old_version, '1.6.4', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN pick_orderby TEXT AFTER pick_filter" );
    jet_cct_query( "ALTER TABLE @wp_jet_fields CHANGE helper display_helper TEXT" );
    jet_cct_query( "ALTER TABLE @wp_jet_fields ADD COLUMN input_helper TEXT AFTER display_helper" );

    update_option( 'jet_cct_version', '164' );
}

if ( version_compare( $old_version, '1.6.7', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_pages ADD COLUMN precode LONGTEXT AFTER phpcode" );

    update_option( 'jet_cct_version', '167' );
}

if ( version_compare( $old_version, '1.7.3', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_types ADD COLUMN detail_page VARCHAR(128) AFTER is_toplevel" );

    update_option( 'jet_cct_version', '173' );
}

if ( version_compare( $old_version, '1.7.5', '<' ) ) {
    if ( empty( $jet_cct_roles ) && !is_array( $jet_cct_roles ) ) {
        $jet_cct_roles = @unserialize( get_option( 'jet_cct_roles' ) );

        if ( !is_array( $jet_cct_roles ) )
            $jet_cct_roles = array();
    }

    if ( is_array( $jet_cct_roles ) ) {
        foreach ( $jet_cct_roles as $role => $privs ) {
            if ( in_array( 'manage_jetpages', $privs ) ) {
                $jet_cct_roles[ $role ][] = 'manage_jet_pages';

                unset( $jet_cct_roles[ $role ][ 'manage_jetpages' ] );
            }
        }
    }

    delete_option( 'jet_cct_roles' );
    add_option( 'jet_cct_roles', serialize( $jet_cct_roles ) );

    update_option( 'jet_cct_version', '175' );
}

if ( version_compare( $old_version, '1.7.6', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_types CHANGE label label VARCHAR(128)" );
    jet_cct_query( "ALTER TABLE @wp_jet_fields CHANGE label label VARCHAR(128)" );

    $result = jet_cct_query( "SELECT f.id AS field_id, f.name AS field_name, f.datatype AS datatype_id, dt.name AS datatype FROM @wp_jet_fields AS f LEFT JOIN @wp_jet_types AS dt ON dt.id = f.datatype WHERE f.coltype='file'" );

    foreach ( $result as $row ) {
        $items = jet_cct_query( "SELECT t.id AS tbl_row_id, t.{$row->field_name} AS file, p.id AS jet_id FROM @wp_jet_tbl_{$row->datatype} AS t LEFT JOIN @wp_jet AS p ON p.tbl_row_id = t.id AND p.datatype = {$row->datatype_id} WHERE t.{$row->field_name} != '' AND t.{$row->field_name} IS NOT NULL" );
        $success = false;
        $rels = array();

        foreach ( (array) $items as $item ) {
            $filename = $item->file;

            if ( strpos( $filename, get_site_url() ) !== false && strpos( $filename, get_site_url() ) == 0 )
                $filename = ltrim( $filename, get_site_url() );

            $upload_dir = wp_upload_dir();

            if ( strpos( $filename, str_replace( get_site_url(), '', $upload_dir[ 'baseurl' ] ) ) === false ) {
                $success = false;

                break;
            }

            $file = str_replace( '//', '/', ( ABSPATH . $filename ) );

            $wp_filetype = wp_check_filetype( basename( $file ), null );

            $attachment = array(
                'post_mime_type' => $wp_filetype[ 'type' ],
                'post_title' => preg_replace( '/\.[^.]+$/', '', basename( $file ) ),
                'guid' => str_replace( '//wp-content/', '/wp-content/', get_site_url() . $filename ),
                'post_content' => '',
                'post_status' => 'inherit'
            );

            $attach_id = wp_insert_attachment( $attachment, $file, 0 );

            if ( $attach_id > 0 ) {
                require_once( ABSPATH . "wp-admin" . '/includes/image.php' );

                $attach_data = wp_generate_attachment_metadata( $attach_id, $file );

                wp_update_attachment_metadata( $attach_id, $attach_data );

                $sizes = array( 'thumb', 'medium', 'large' );

                foreach ( $sizes as $size ) {
                    image_downsize( $attach_id, $size );
                }

                $rels[] = array( 'jet_id' => $item->jet_id, 'tbl_row_id' => $item->tbl_row_id, 'attach_id' => $attach_id, 'field_id' => $row->field_id );

                $success = true;
            }
        }
        if ( false !== $success ) {
            foreach ( $rels as $rel ) {
                jet_cct_query( "INSERT INTO @wp_jet_rel (jet_id, field_id, tbl_row_id) VALUES({$rel['jet_id']}, {$rel['field_id']}, {$rel['attach_id']})" );
            }

            jet_cct_query( "ALTER TABLE @wp_jet_tbl_{$row->datatype} DROP COLUMN {$row->field_name}" );
        }
        else
            jet_cct_query( "UPDATE @wp_jet_fields SET coltype = 'txt' WHERE id = {$row->field_id}" );
    }

    update_option( 'jet_cct_version', '176' );
}

if ( version_compare( $old_version, '1.8.1', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_rel ADD COLUMN weight SMALLINT unsigned AFTER tbl_row_id" );
    jet_cct_query( "ALTER TABLE @wp_jet_types CHANGE before_helpers pre_save_helpers TEXT" );
    jet_cct_query( "ALTER TABLE @wp_jet_types CHANGE after_helpers post_save_helpers TEXT" );
    jet_cct_query( "ALTER TABLE @wp_jet_types ADD COLUMN pre_drop_helpers TEXT AFTER pre_save_helpers" );
    jet_cct_query( "ALTER TABLE @wp_jet_types ADD COLUMN post_drop_helpers TEXT AFTER post_save_helpers" );
    jet_cct_query( "UPDATE @wp_jet_helpers SET helper_type = 'pre_save' WHERE helper_type = 'before'" );
    jet_cct_query( "UPDATE @wp_jet_helpers SET helper_type = 'post_save' WHERE helper_type = 'after'" );

    update_option( 'jet_cct_version', '181' );
}

if ( version_compare( $old_version, '1.8.2', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet ADD COLUMN author_id INT unsigned AFTER modified" );
    jet_cct_query( "UPDATE @wp_jet_fields SET pickval = 'wp_taxonomy' WHERE pickval REGEXP '^[0-9]+$'" );
    jet_cct_query( "UPDATE @wp_jet_menu SET uri = '<root>' WHERE uri = '/' LIMIT 1" );

    // Remove beginning and trailing slashes
    $result = jet_cct_query( "SELECT id, uri FROM @wp_jet_menu" );

    foreach ( $result as $row ) {
        $uri = preg_replace( "@^([/]?)(.*?)([/]?)$@", "$2", $row->uri );
        $uri = jet_cct_sanitize( $uri );
        jet_cct_query( "UPDATE @wp_jet_menu SET uri = '$uri' WHERE id = {$row->id} LIMIT 1" );
    }

    update_option( 'jet_cct_version', '182' );
}

if ( version_compare( $old_version, '1.9.0', '<' ) ) {
    jet_cct_query( "ALTER TABLE @wp_jet_templates CHANGE `name` `name` VARCHAR(255)" );
    jet_cct_query( "ALTER TABLE @wp_jet_helpers CHANGE `name` `name` VARCHAR(255)" );
    jet_cct_query( "ALTER TABLE @wp_jet_fields CHANGE `comment` `comment` VARCHAR(255)" );

    // Remove beginning and trailing slashes
    $result = jet_cct_query( "SELECT id, uri FROM @wp_jet_pages" );

    foreach ( $result as $row ) {
        $uri = trim( $row->uri, '/' );
        $uri = jet_cct_sanitize( $uri );
        jet_cct_query( "UPDATE @wp_jet_pages SET uri = '$uri' WHERE id = {$row->id} LIMIT 1" );
    }

    update_option( 'jet_cct_version', '190' );
}

if ( version_compare( $old_version, '1.9.6', '<' ) ) {
    add_option( 'jet_cct_disable_file_browser', 0 );
    add_option( 'jet_cct_files_require_login', 0 );
    add_option( 'jet_cct_files_require_login_cap', 'upload_files' );
    add_option( 'jet_cct_disable_file_upload', 0 );
    add_option( 'jet_cct_upload_require_login', 0 );
    add_option( 'jet_cct_upload_require_login_cap', 'upload_files' );

    update_option( 'jet_cct_version', '196' );
}

if ( version_compare( $old_version, '1.9.7', '<' ) ) {
    jet_cct_query( "ALTER TABLE `@wp_jet` CHANGE `id` `id` BIGINT(15) UNSIGNED NOT NULL AUTO_INCREMENT" );
    jet_cct_query( "ALTER TABLE `@wp_jet` CHANGE `tbl_row_id` `tbl_row_id` BIGINT(15) UNSIGNED NULL DEFAULT NULL" );
    jet_cct_query( "ALTER TABLE `@wp_jet` CHANGE `author_id` `author_id` BIGINT(15) UNSIGNED NULL DEFAULT NULL" );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` CHANGE `id` `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT" );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` CHANGE `jet_id` `jet_id` BIGINT(15) UNSIGNED NULL DEFAULT NULL" );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` CHANGE `sister_jet_id` `sister_jet_id` BIGINT(15) UNSIGNED NULL DEFAULT NULL" );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` CHANGE `tbl_row_id` `tbl_row_id` BIGINT(15) UNSIGNED NULL DEFAULT NULL" );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` CHANGE `weight` `weight` INT(10) UNSIGNED NULL DEFAULT '0'" );

    update_option( 'jet_cct_version', '197' );
}

if ( version_compare( $old_version, '1.11', '<' ) ) {
    jet_cct_query( "ALTER TABLE `@wp_jet` CHANGE `datatype` `datatype` INT(10) UNSIGNED NULL DEFAULT NULL" );
    jet_cct_query( "ALTER TABLE `@wp_jet` DROP INDEX `datatype_idx`", false );
    jet_cct_query( "ALTER TABLE `@wp_jet` ADD INDEX `datatype_row_idx` (`datatype`, `tbl_row_id`)", false );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` DROP INDEX `field_id_idx`", false );
    jet_cct_query( "ALTER TABLE `@wp_jet_rel` ADD INDEX `field_jet_idx` (`field_id`, `jet_id`)", false );
    jet_cct_query( "ALTER TABLE `@wp_jet_fields` CHANGE `datatype` `datatype` INT(10) UNSIGNED NULL DEFAULT NULL" );
    $result = jet_cct_query( "SELECT id, name FROM @wp_jet_types" );
    foreach ( $result as $row ) {
        $jet = jet_cct_sanitize( $row->name );
        jet_cct_query( "ALTER TABLE `@wp_jet_tbl_{$jet}` CHANGE `id` `id` BIGINT(15) UNSIGNED NOT NULL AUTO_INCREMENT" );
    }
    update_option( 'jet_cct_version', '001011000' );
}
