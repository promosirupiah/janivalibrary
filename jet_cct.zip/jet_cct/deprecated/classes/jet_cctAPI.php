<?php
require_once( jet_cct_DIR . 'deprecated/deprecated.php' );

/**
 * @package jet_cct\Deprecated
 */
class jet_cctAPI_Deprecated {

    private $obj;

    var $snap = false;

    var $dt = 0;

    var $dtname = '';

    var $fields = array();

    var $use_jet_id = false;

    /**
     * Constructor - jet_cctAPI Deprecated functionality (pre 2.0)
     *
     * @param object $obj The jet_cctAPI object
     *
     * @license http://www.gnu.org/licenses/gpl-2.0.html
     * @since 2.0
     */
    public function __construct ( $obj ) {
        // backwards-compatibility with references to $this->var_name
        $vars = get_object_vars( $obj );

        foreach ( (array) $vars as $key => $val ) {
            $this->{$key} = $val;
        }

        // keeping references pointing back to the source
        $this->obj =& $obj;
    }

    /**
     * Add or edit a column within a jet
     *
     * $params['id'] int The field ID
     * $params['jet_id'] int The jet ID
     * $params['jet'] string The jet name
     * $params['name'] string The field name
     * $params['label'] string The field label
     * $params['type'] string The column type ("txt", "desc", "pick", etc)
     * $params['pick_object'] string The related PICK object name
     * $params['pick_val'] string The related PICK object value
     * $params['sister_id'] int (optional) The related field ID
     * $params['weight'] int The field weight
     * $params['options'] array The field options
     *
     * @param array $params An associative array of parameters
     * @since 1.7.9
     */
    public function save_column ($params) {
        jet_cct_deprecated( 'jet_cctAPI::save_field', '2.0' );

        return $this->obj->save_field( $params );
    }

    /**
     * Save the entire role structure
     *
     * @param array $params An associative array of parameters
     * @since 1.7.9
     */
    public function save_roles ($params) {
        jet_cct_deprecated( '[use WP roles and capabilities instead]', '2.0' );

        return false;
    }

    /**
     * Drop a jet and all its content
     *
     * $params['id'] int The jet ID
     * $params['name'] string The jet name
     *
     * @param array $params An associative array of parameters
     *
     * @since 1.7.9
     */
    public function drop_jet ( $params ) {
        jet_cct_deprecated( 'jet_cctAPI::delete_jet', '2.0' );

        return $this->obj->delete_jet( $params );
    }

    /**
     * Drop a column within a jet
     *
     * $params['id'] int The column ID
     * $params['name'] int The column name
     * $params['jet'] string The jet name
     * $params['jet_id'] string The jet name
     *
     * @param array $params An associative array of parameters
     *
     * @since 1.7.9
     */
    public function drop_column ( $params ) {
        jet_cct_deprecated( 'jet_cctAPI::delete_field', '2.0' );

        return $this->obj->delete_field( $params );
    }

    /**
     * Drop a jet Template
     *
     * $params['id'] int The template ID
     * $params['name'] string The template name
     *
     * @param array $params An associative array of parameters
     *
     * @since 1.7.9
     */
    public function drop_template ( $params ) {
        jet_cct_deprecated( 'jet_cctAPI::delete_template', '2.0' );

        return $this->obj->delete_template( $params );
    }

    /**
     * Drop a jet Page
     *
     * $params['id'] int The page ID
     * $params['uri'] string The page URI
     *
     * @param array $params An associative array of parameters
     *
     * @since 1.7.9
     */
    public function drop_page ( $params ) {
        jet_cct_deprecated( 'jet_cctAPI::delete_page', '2.0' );

        return $this->obj->delete_page( $params );
    }

    /**
     * Drop a jet Helper
     *
     * $params['id'] int The helper ID
     * $params['name'] string The helper name
     *
     * @param array $params An associative array of parameters
     *
     * @since 1.7.9
     */
    public function drop_helper ( $params ) {
        jet_cct_deprecated( 'jet_cctAPI::delete_helper', '2.0' );

        return $this->obj->delete_helper( $params );
    }

    /**
     * Drop a single jet item
     *
     * $params['id'] int (optional) The item's ID from the wp_jet_* table (used with datatype parameter)
     * $params['jet'] string (optional) The datatype name (used with id parameter)
     * $params['jet_id'] int (optional) The datatype ID (used with id parameter)
     * $params['bypass_helpers'] bool Set to true to bypass running pre-save and post-save helpers
     *
     * @param array $params An associative array of parameters
     *
     * @since 1.7.9
     */
    public function drop_jet_item ( $params ) {
        jet_cct_deprecated( 'jet_cctAPI::delete_jet_item', '2.0' );

        return $this->obj->delete_jet_item( $params );
    }

    /**
     * Load a column
     *
     * $params['jet_id'] int The jet ID
     * $params['id'] int The field ID
     * $params['name'] string The field name
     *
     * @param array $params An associative array of parameters
     * @since 1.7.9
     */
    public function load_column ($params) {
        jet_cct_deprecated( 'jet_cctAPI::load_column', '2.0', 'jet_cctAPI::load_field' );

        return $this->obj->load_field( $params );
    }
}
