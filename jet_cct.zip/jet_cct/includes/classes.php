<?php
/**
 * @package jet_cct\Global\Functions\Classes
 */
/**
 * Include and Init the jet_cct class
 *
 * @see jet_cct
 *
 * @param string $type The jet name
 * @param mixed $id (optional) The ID or slug, to load a single record; Provide array of $params to run 'find'
 * @param bool $strict (optional) If set to true, return false instead of an object if the jet doesn't exist
 *
 * @return bool|\jet_cct returns false if $strict, WP_DEBUG, jet_cct_STRICT or (jet_cct_DEPRECATED && jet_cct_STRICT_MODE) are true
 * @since 2.0
 * @link http://jet_cct.io/docs/jet_cct/
 */
function jet_cct ( $type = null, $id = null, $strict = null ) {
    require_once( jet_cct_DIR . 'classes/jet_cct.php' );

    $jet = new jet_cct( $type, $id );

    if ( null === $strict )
        $strict = jet_cct_strict();

    if ( true === $strict && null !== $type && !$jet->valid() )
        return false;

    return $jet;
}

/**
 * Easily create content admin screens with in-depth customization. This is the primary interface function that jet_cct
 * runs off of. It's also the only function required to be run in order to have a fully functional Manage interface.
 *
 * @see jet_cctUI
 *
 * @param array|string|jet_cct $obj (optional) Configuration options for the UI
 * @param boolean $deprecated (optional) Whether to enable deprecated options (used by jet_cct_ui_manage)
 *
 * @return jet_cctUI
 *
 * @since 2.0
 * @link http://jet_cct.io/docs/jet_cct-ui/
 */
function jet_cct_ui ( $obj, $deprecated = false ) {
    require_once( jet_cct_DIR . 'classes/jet_cctUI.php' );

    return new jet_cctUI( $obj, $deprecated );
}

/**
 * Include and get the jet_cctAPI object, for use with all calls that jet_cct makes for add, save, delete, and more.
 *
 * @see jet_cctAPI
 *
 * @param string $jet (optional) (deprecated) The jet name
 * @param string $format (optional) (deprecated) Format used in import() and export()
 *
 * @return jet_cctAPI
 *
 * @since 2.0
 * @link http://jet_cct.io/docs/jet_cct-api/
 */
function jet_cct_api ( $jet = null, $format = null ) {
    require_once( jet_cct_DIR . 'classes/jet_cctAPI.php' );

    return jet_cctAPI::init( $jet, $format );
}

/**
 * Include and Init the jet_cctData class
 *
 * @see jet_cctData
 *
 * @param string|\jet $jet The jet object to load
 * @param int $id (optional) Id of the jet to fetch
 * @param bool $strict (optional) If true throw an error if the jet does not exist
 * @param bool $unique (optional) If true always return a unique class
 *
 * @return jet_cctData
 *
 * @since 2.0
 */
function jet_cct_data ( $jet = null, $id = null, $strict = true, $unique = true ) {
    require_once( jet_cct_DIR . 'classes/jet_cctData.php' );

    if ( $unique && false !== $jet )
        return new jet_cctData( $jet, $id, $strict );

    return jet_cctData::init( $jet, $id, $strict );
}

/**
 * Include and Init the jet_cctFormUI class
 *
 * @see jet_cctForm
 *
 * @return jet_cctForm
 *
 * @since 2.0
 */
function jet_cct_form () {
    require_once( jet_cct_DIR . 'classes/jet_cctForm.php' );

    return jet_cctForm::init();
}

/**
 * Include and Init the jet_cct class
 *
 * @see jet_cctInit
 *
 * @return jet_cctInit
 *
 * @since 2.0
 */
function jet_cct_init () {
    require_once( jet_cct_DIR . 'classes/jet_cctInit.php' );

    return jet_cctInit::init();
}

/**
 * Include and Init the jet_cct Components class
 *
 * @see jet_cctComponents
 *
 * @return jet_cctComponents
 *
 * @since 2.0
 */
function jet_cct_components () {
    require_once( jet_cct_DIR . 'classes/jet_cctComponents.php' );
    require_once( jet_cct_DIR . 'classes/jet_cctComponent.php' );

    return jet_cctComponents::init();
}

/**
 * Include and Init the jet_cctAdmin class
 *
 * @see jet_cctAdmin
 *
 * @return jet_cctAdmin
 *
 * @since 2.0
 */
function jet_cct_admin () {
    require_once( jet_cct_DIR . 'classes/jet_cctAdmin.php' );

    return jet_cctAdmin::init();
}

/**
 * Include and Init the jet_cctMeta class
 *
 * @see jet_cctMeta
 *
 * @return jet_cctMeta
 *
 * @since 2.0
 */
function jet_cct_meta () {
    require_once( jet_cct_DIR . 'classes/jet_cctMeta.php' );

    return jet_cctMeta::init();
}

/**
 * Include and Init the jet_cctArray class
 *
 * @see jet_cctArray
 *
 * @param mixed $container Object (or existing Array)
 *
 * @return jet_cctArray
 *
 * @since 2.0
 */
function jet_cct_array ( $container ) {
    require_once( jet_cct_DIR . 'classes/jet_cctArray.php' );

    return new jet_cctArray( $container );
}

/**
 * Include a file that's child/parent theme-aware, and can be cached into object cache or transients
 *
 * @see jet_cctView::view
 *
 * @param string $view Path of the file to be included, this is relative to the current theme
 * @param array|null $data (optional) Data to pass on to the template, using variable => value format
 * @param int|bool $expires (optional) Time in seconds for the cache to expire, if false caching is disabled.
 * @param string $cache_mode (optional) Specify the caching method to use for the view, available options include cache, transient, or site-transient
 * @param bool $return (optional) Whether to return the view or not, defaults to false and will echo it
 *
 * @return string|bool The view output
 *
 * @since 2.0
 * @link http://jet_cct.io/docs/jet_cct-view/
 */
function jet_cct_view ( $view, $data = null, $expires = false, $cache_mode = 'cache', $return = false ) {
    require_once( jet_cct_DIR . 'classes/jet_cctView.php' );

    $view = jet_cctView::view( $view, $data, $expires, $cache_mode );

    if ( $return )
        return $view;

    echo $view;
}

/**
 * Include and Init the jet_cctMigrate class
 *
 * @see jet_cctMigrate
 *
 * @param string $type Export Type (php, json, sv, xml)
 * @param string $delimiter Delimiter for export type 'sv'
 * @param array $data Array of data
 *
 * @return jet_cctMigrate
 *
 * @since 2.2
 */
function jet_cct_migrate ( $type = null, $delimiter = null, $data = null ) {
    require_once( jet_cct_DIR . 'classes/jet_cctMigrate.php' );

    return new jet_cctMigrate( $type, $delimiter, $data );
}

/**
 * Include and Init the jet_cctUpgrade class
 *
 * @param string $version Version number of upgrade to get
 *
 * @see jet_cctUpgrade
 *
 * @return jet_cctUpgrade
 *
 * @since 2.1
 */
function jet_cct_upgrade ( $version = '' ) {
    include_once jet_cct_DIR . 'sql/upgrade/jet_cctUpgrade.php';

    $class_name = str_replace( '.', '_', $version );
    $class_name = "jet_cctUpgrade_{$class_name}";

    $class_name = trim( $class_name, '_' );

    if ( !class_exists( $class_name ) ) {
        $file = jet_cct_DIR . 'sql/upgrade/' . basename( $class_name ) . '.php';

        if ( file_exists( $file ) )
            include_once $file;
    }

    $class = false;

    if ( class_exists( $class_name ) )
        $class = new $class_name();

    return $class;
}
