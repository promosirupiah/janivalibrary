<?php
/**
 * @package jet_cct\Global\Functions\General
 */
/**
 * Standardize queries and error reporting. It replaces @wp_ with $wpdb->prefix.
 *
 * @see jet_cctData::query
 *
 * @param string $sql SQL Query
 * @param string $error (optional) The failure message
 * @param string $results_error (optional) Throw an error if a records are found
 * @param string $no_results_error (optional) Throw an error if no records are found
 *
 * @return array|bool|mixed|null|void
 * @since 2.0
 */
function jet_cct_query ( $sql, $error = 'Database Error', $results_error = null, $no_results_error = null ) {
    $jet_cctdata = jet_cct_data();

    $sql = apply_filters( 'jet_cct_query_sql', $sql, $error, $results_error, $no_results_error );
    $sql = $jet_cctdata->get_sql($sql);

    if ( is_array( $error ) ) {
        if ( !is_array( $sql ) )
            $sql = array( $sql, $error );

        $error = 'Database Error';
    }

    if ( 1 == jet_cct_v( 'jet_cct_debug_sql_all', 'get', 0 ) && is_user_logged_in() && jet_cct_is_admin( array( 'jet_cct' ) ) ) {
        $debug_sql = $sql;

        echo '<textarea cols="100" rows="24">';

        if ( is_array( $debug_sql ) ) {
            $debug_sql = print_r( $debug_sql, true );
        }

        echo esc_textarea( $debug_sql );

        echo '</textarea>';
    }

    return $jet_cctdata->query( $sql, $error, $results_error, $no_results_error );
}

/**
 * Standardize filters / actions
 *
 * @param string $scope Scope of the filter / action (ui for jet_cctUI, api for jet_cctAPI, etc..)
 * @param string $name Name of filter / action to run
 * @param mixed $args (optional) Arguments to send to filter / action
 * @param object $obj (optional) Object to reference for filter / action
 *
 * @return mixed
 * @since 2.0
 * @todo Need to figure out how to handle $scope = 'jet_cct' for the jet_cct class
 */
function jet_cct_do_hook ( $scope, $name, $args = null, $obj = null ) {
    // Add filter name
    array_unshift( $args, "jet_cct_{$scope}_{$name}" );

    // Add object
    $args[] = $obj;

    // Run apply_filters and give it all the arguments
    $args = call_user_func_array( 'apply_filters', $args );

    return $args;
}

/**
 * Message / Notice handling for Admin UI
 *
 * @param string $message The notice / error message shown
 * @param string $type Message type
 *
 * @return void
 */
function jet_cct_message ( $message, $type = null ) {
    if ( empty( $type ) || !in_array( $type, array( 'notice', 'error' ) ) )
        $type = 'notice';

    $class = '';

    if ( 'notice' == $type )
        $class = 'updated';
    elseif ( 'error' == $type )
        $class = 'error';

    echo '<div id="message" class="' . esc_attr( $class ) . ' fade"><p>' . $message . '</p></div>';
}

$GLOBALS['jet_cct_errors'] = array();

/**
 * Error Handling which throws / displays errors
 *
 * @param string|array        $error The error message(s) to be thrown / displayed.
 * @param object|boolean|null $obj   If $obj->display_errors is set and is set to true it will display errors, if boolean and is set to true it will display errors.
 *
 * @throws Exception Throws exception for developer-oriented error handling.
 *
 * @return mixed
 *
 * @since 2.0
 */
function jet_cct_error( $error, $obj = null ) {

	global $jet_cct_errors;

	$error_mode = 'exception';

	if ( is_object( $obj ) && isset( $obj->display_errors ) ) {
		if ( true === $obj->display_errors ) {
			$error_mode = 'exit';
		} elseif ( false === $obj->display_errors ) {
			$error_mode = 'exception';
		} else {
			$error_mode = $obj->display_errors;
		}
	} elseif ( true === $obj ) {
		$error_mode = 'exit';
	} elseif ( false === $obj ) {
		$error_mode = 'exception';
	} elseif ( is_string( $obj ) ) {
		$error_mode = $obj;
	}

	if ( is_object( $error ) && 'Exception' === get_class( $error ) ) {
		$error = $error->getMessage();

		$error_mode = 'exception';
	}

	/**
	 * @var string $error_mode Throw an exception, exit with the message, return false, or return WP_Error
	 */
	if ( ! in_array( $error_mode, array( 'exception', 'exit', 'false', 'wp_error' ), true ) ) {
		$error_mode = 'exception';
	}

	/**
	 * Filter the error mode used by jet_cct_error.
	 *
	 * @param string $error_mode Error mode
	 * @param string|array $error Error message(s)
	 * @param object|boolean|string|null $obj
	 */
	$error_mode = apply_filters( 'jet_cct_error_mode', $error_mode, $error, $obj );

	if ( is_array( $error ) ) {
		$error = array_map( 'wp_kses_post', $error );

		if ( 1 === count( $error ) ) {
			$error = current( $error );

			// Create WP_Error for use later.
			$wp_error = new WP_Error( 'jet_cct-error-' . md5( $error ), $error );
		} else {
			// Create WP_Error for use later.
			$wp_error = new WP_Error();

			foreach ( $error as $error_message ) {
				$wp_error->add( 'jet_cct-error-' . md5( $error_message ), $error_message );
			}

			if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
				$error = __( 'The following issue occurred:', 'jet_cct' )
						 . "\n\n- " . implode( "\n- ", $error );
			} else {
				$error = __( 'The following issues occurred:', 'jet_cct' )
						 . "\n<ul><li>" . implode( "</li>\n<li>", $error ) . "</li></ul>";
			}
		}
	} else {
		if ( is_object( $error ) ) {
			$error = __( 'An unknown error has occurred', 'jet_cct' );
		}

		$error = wp_kses_post( $error );

		// Create WP_Error for use later.
		$wp_error = new WP_Error( 'jet_cct-error-' . md5( $error ), $error );
	}

	$last_error = $jet_cct_errors;

	$jet_cct_errors = array();

	if ( $last_error === $error && 'exception' === $error_mode ) {
		$error_mode = 'exit';
	}

	if ( ! empty( $error ) ) {
		if ( 'exception' === $error_mode ) {
			$exception_bypass = apply_filters( 'jet_cct_error_exception', null, $error );

			if ( null !== $exception_bypass ) {
				return $exception_bypass;
			}

			$jet_cct_errors = $error;

			set_exception_handler( 'jet_cct_error' );

			throw new Exception( $error );
		} elseif ( 'exit' === $error_mode ) {
			$die_bypass = apply_filters( 'jet_cct_error_die', null, $error );

			if ( null !== $die_bypass ) {
				return $die_bypass;
			}

			// die with error
			if ( ! defined( 'DOING_AJAX' ) && ! headers_sent() && ( is_admin() || false !== strpos( $_SERVER['REQUEST_URI'], 'wp-comments-post.php' ) ) ) {
				wp_die( $error, '', array( 'back_link' => true ) );
			} else {
				die( sprintf( '<e>%s</e>', $error ) );
			}
		} elseif ( 'wp_error' === $error_mode ) {
			return $wp_error;
		}
	}

	return false;

}

/**
 * Debug variable used in jet_cct_debug to count the instances debug is used
 */
global $jet_cct_debug;
$jet_cct_debug = 0;
/**
 * Debugging common issues using this function saves a few lines and is compatible with
 *
 * @param mixed $debug The error message to be thrown / displayed
 * @param boolean $die If set to true, a die() will occur, if set to (int) 2 then a wp_die() will occur
 * @param string $prefix
 *
 * @return void
 *
 * @since 2.0
 */
function jet_cct_debug ( $debug = '_null', $die = false, $prefix = '_null' ) {
    global $jet_cct_debug;

    $jet_cct_debug++;

    ob_start();

    if ( '_null' !== $prefix )
        var_dump( $prefix );

    if ( '_null' !== $debug )
        var_dump( $debug );
    else
        var_dump( 'jet_cct Debug #' . $jet_cct_debug );

    $debug = ob_get_clean();

    if ( false === strpos( $debug, "<pre class='xdebug-var-dump'" ) && ( !ini_get( 'xdebug.overload_var_dump' ) && !ini_get( 'html_errors' ) ) ) {
        if ( !defined( 'DOING_AJAX' ) || !DOING_AJAX )
            $debug = esc_html( $debug );

        $debug = '<pre>' . $debug . '</pre>';
    }

    $debug = '<e>' . $debug;

    if ( 2 === $die )
        wp_die( $debug, '', array( 'back_link' => true ) );
    elseif ( true === $die )
        die( $debug );

    echo $debug;
}

/**
 * Determine if user has admin access
 *
 * @param string|array $cap Additional capabilities to check
 *
 * @return bool Whether user has admin access
 *
 * @since 2.3.5
 */
function jet_cct_is_admin ( $cap = null ) {
    if ( is_user_logged_in() ) {
        $jet_cct_admin_capabilities = array(
            'delete_users' // default is_super_admin checks against this
        );

        $jet_cct_admin_capabilities = apply_filters( 'jet_cct_admin_capabilities', $jet_cct_admin_capabilities, $cap );

        if ( is_multisite() && is_super_admin() )
            return apply_filters( 'jet_cct_is_admin', true, $cap, '_super_admin' );

        if ( empty( $cap ) )
            $cap = array();
        else
            $cap = (array) $cap;

        $cap = array_unique( array_filter( array_merge( $jet_cct_admin_capabilities, $cap ) ) );

        foreach ( $cap as $capability ) {
            if ( current_user_can( $capability ) )
                return apply_filters( 'jet_cct_is_admin', true, $cap, $capability );
        }
    }

    return apply_filters( 'jet_cct_is_admin', false, $cap, null );
}

/**
 * Determine if Developer Mode is enabled
 *
 * @return bool Whether Developer Mode is enabled
 *
 * @since 2.3
 */
function jet_cct_developer () {
    if ( defined( 'jet_cct_DEVELOPER' ) && jet_cct_DEVELOPER )
        return true;

    return false;
}

/**
 * Determine if Tableless Mode is enabled
 *
 * @return bool Whether Tableless Mode is enabled
 *
 * @since 2.3
 */
function jet_cct_tableless () {
    if ( defined( 'jet_cct_TABLELESS' ) && jet_cct_TABLELESS )
        return true;

    return false;
}

/**
 * Determine if Strict Mode is enabled
 *
 * @param bool $include_debug Whether to include WP_DEBUG in strictness level
 *
 * @return bool Whether Strict Mode is enabled
 *
 * @since 2.3.5
 */
function jet_cct_strict( $include_debug = true ) {

	if ( defined( 'jet_cct_STRICT' ) && jet_cct_STRICT ) {
		return true;
	}
	// @deprecated jet_cct_STRICT_MODE since 2.3.5
	elseif ( jet_cct_allow_deprecated( false ) && defined( 'jet_cct_STRICT_MODE' ) && jet_cct_STRICT_MODE ) {
		return true;
	}
	elseif ( $include_debug && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		return true;
	}

	return false;

}

/**
 * Determine if Deprecated Mode is enabled
 *
 * @param bool $include_debug Whether to include strict mode
 *
 * @return bool Whether Deprecated Mode is enabled
 *
 * @since 2.3.10
 */
function jet_cct_allow_deprecated( $strict = true ) {

	if ( $strict && jet_cct_strict() ) {
		return false;
	}
	elseif ( !defined( 'jet_cct_DEPRECATED' ) || jet_cct_DEPRECATED ) {
		return true;
	}

	return false;

}

/**
 * Determine if jet_cct API Caching is enabled
 *
 * @return bool Whether jet_cct API Caching is enabled
 *
 * @since 2.3.9
 */
function jet_cct_api_cache () {
    if ( defined( 'jet_cct_API_CACHE' ) && !jet_cct_API_CACHE )
        return false;

    return true;
}

/**
 * Marks a function as deprecated and informs when it has been used.
 *
 * There is a hook deprecated_function_run that will be called that can be used
 * to get the backtrace up to what file and function called the deprecated
 * function.
 *
 * The current behavior is to trigger a user error if WP_DEBUG is true.
 *
 * This function is to be used in every function that is deprecated.
 *
 * @uses do_action() Calls 'deprecated_function_run' and passes the function name, what to use instead,
 *   and the version the function was deprecated in.
 * @uses apply_filters() Calls 'deprecated_function_trigger_error' and expects boolean value of true to do
 *   trigger or false to not trigger error.
 *
 * @param string $function The function that was called
 * @param string $version The version of WordPress that deprecated the function
 * @param string $replacement Optional. The function that should have been called
 *
 * @since 2.0
 */
function jet_cct_deprecated ( $function, $version, $replacement = null ) {
    if ( !version_compare( $version, jet_cct_VERSION, '<=' ) && !version_compare( $version . '-a-0', jet_cct_VERSION, '<=' ) )
        return;

    do_action( 'deprecated_function_run', $function, $replacement, $version );

    // Allow plugin to filter the output error trigger
    if ( WP_DEBUG && apply_filters( 'deprecated_function_trigger_error', true ) ) {
        if ( !is_null( $replacement ) )
            $error = __( '%1$s has been <strong>deprecated</strong> since jet_cct version %2$s! Use %3$s instead.', 'jet_cct' );
        else
            $error = __( '%1$s has been <strong>deprecated</strong> since jet_cct version %2$s with no alternative available.', 'jet_cct' );

        trigger_error( sprintf( $error, $function, $version, $replacement ) );
    }
}

/**
 * Inline help
 *
 * @param string $text Help text
 * @param string $url Documentation URL
 *
 * @return void
 *
 * @since 2.0
 */
function jet_cct_help ( $text, $url = null ) {

	if ( ! wp_script_is( 'jquery-qtip2', 'registered' ) ) {
		wp_register_script( 'jquery-qtip2', jet_cct_URL . 'ui/js/jquery.qtip.min.js', array( 'jquery' ), '2.2' );
	}
	elseif ( ! wp_script_is( 'jquery-qtip2', 'queue' ) && ! wp_script_is( 'jquery-qtip2', 'to_do' ) && ! wp_script_is( 'jquery-qtip2', 'done' ) ) {
		wp_enqueue_script( 'jquery-qtip2' );
	}

	if ( ! wp_style_is( 'jquery-qtip2', 'registered' ) ) {
		wp_register_style( 'jquery-qtip2', jet_cct_URL . 'ui/css/jquery.qtip.min.css', array(), '2.2' );
	}
	elseif ( ! wp_style_is( 'jquery-qtip2', 'queue' ) && ! wp_style_is( 'jquery-qtip2', 'to_do' ) && ! wp_style_is( 'jquery-qtip2', 'done' ) ) {
		wp_enqueue_style( 'jquery-qtip2' );
	}

	if ( ! wp_script_is( 'jet_cct-qtip-init', 'registered' ) ) {
		wp_register_script( 'jet_cct-qtip-init', jet_cct_URL . 'ui/js/qtip.js', array(
			'jquery',
			'jquery-qtip2'
		), jet_cct_VERSION );
	}
	elseif ( ! wp_script_is( 'jet_cct-qtip-init', 'queue' ) && ! wp_script_is( 'jet_cct-qtip-init', 'to_do' ) && ! wp_script_is( 'jet_cct-qtip-init', 'done' ) ) {
		wp_enqueue_script( 'jet_cct-qtip-init' );
	}

	if ( is_array( $text ) ) {
		if ( isset( $text[ 1 ] ) ) {
			$url = $text[ 1 ];
		}

		$text = $text[ 0 ];
	}

	if ( 'help' == $text ) {
		return;
	}

	if ( 0 < strlen( $url ) ) {
		$text .= '<br /><br /><a href="' . $url . '" target="_blank">' . __( 'Find out more', 'jet_cct' ) . ' &raquo;</a>';
	}

    echo '<img src="' . esc_url( jet_cct_URL ) . 'ui/images/help.png" alt="' . esc_attr( $text ) . '" class="jet_cct-icon jet_cct-qtip" />';
}

/**
 * Check whether or not something is a specific version minimum and/or maximum
 *
 * @param string $minimum_version Minimum version
 * @param string $comparison Comparison operator
 * @param string $maximum_version Maximum version
 *
 * @return bool
 */
function jet_cct_version_check ( $what, $minimum_version, $comparison = '<=', $maximum_version = null ) {
    global $wp_version, $wpdb;

    if ( 'php' == $what )
        $version = phpversion();
    elseif ( 'mysql' === $what )
        $version = $wpdb->db_version();
    else
        $version = $wp_version;

    if ( !empty( $minimum_version ) && !version_compare( $minimum_version, $version, $comparison ) )
        return false;

    if ( !empty( $maximum_version ) && !version_compare( $version, $maximum_version, $comparison ) )
        return false;

    return true;
}

/**
 * Run a jet_cct Helper
 *
 * @param string $helper_name Helper Name
 * @param string $value Value to run Helper on
 * @param string $name Field name.
 *
 * @return bool
 * @since 1.7.5
 */
function jet_cct_helper ( $helper_name, $value = null, $name = null ) {
    return jet_cct()->helper( $helper_name, $value, $name );
}

/**
 * Get the full URL of the current page
 *
 * @return string Full URL of the current page
 * @since 2.3
 */
function jet_cct_current_url () {
    $url = 'http';

    if ( isset( $_SERVER[ 'HTTPS' ] ) && 'off' != $_SERVER[ 'HTTPS' ] && 0 != $_SERVER[ 'HTTPS' ] )
        $url = 'https';

    $url .= '://' . $_SERVER[ 'HTTP_HOST' ] . $_SERVER[ 'REQUEST_URI' ];

    return apply_filters( 'jet_cct_current_url', $url );
}

/**
 * Find out if the current page has a valid $jet_cct
 *
 * @param object $object The jet Object currently checking (optional)
 *
 * @return bool
 * @since 2.0
 */
function is_jet ( $object = null ) {
    global $jet_cct, $post;

    if ( is_object( $object ) && isset( $object->jet ) && !empty( $object->jet ) )
        return true;
    elseif ( is_object( $jet_cct ) && isset( $jet_cct->jet ) && !empty( $jet_cct->jet ) )
        return true;
    elseif ( is_object( $post ) && isset( $post->post_type ) && jet_cct_api()->jet_exists( $post->post_type, 'post_type' ) )
        return true;

    return false;
}

/**
 * See if the current user has a certain privilege
 *
 * @param mixed $privs The privilege name or names (array if multiple)
 * @param string $method The access method ("AND", "OR")
 *
 * @return bool
 * @since 1.2.0
 */
function jet_cct_access ( $privs, $method = 'OR' ) {
    // Convert $privs to an array
    $privs = (array) $privs;

    // Convert $method to uppercase
    $method = strtoupper( $method );

    $check = apply_filters( 'jet_cct_access', null, $privs, $method );
    if ( null !== $check && is_bool( $check ) )
        return $check;

    if ( !is_user_logged_in() )
        return false;

    if ( jet_cct_is_admin( array( 'jet_cct', 'jet_cct_content' ) ) )
        return true;

    // Store approved privs when using "AND"
    $approved_privs = array();

    // Loop through the user's roles
    foreach ( $privs as $priv ) {
        if ( 0 === strpos( $priv, 'jet_' ) )
            $priv = jet_cct_str_replace( 'jet_', 'jet_cct_edit_', $priv, 1 );

        if ( 0 === strpos( $priv, 'manage_' ) )
            $priv = jet_cct_str_replace( 'manage_', 'jet_cct_', $priv, 1 );

        if ( current_user_can( $priv ) ) {
            if ( 'OR' == $method )
                return true;

            $approved_privs[ $priv ] = true;
        }
    }
    if ( 'AND' == strtoupper( $method ) ) {
        foreach ( $privs as $priv ) {
            if ( 0 === strpos( $priv, 'jet_' ) )
                $priv = jet_cct_str_replace( 'jet_', 'jet_cct_edit_', $priv, 1 );

            if ( 0 === strpos( $priv, 'manage_' ) )
                $priv = jet_cct_str_replace( 'manage_', 'jet_cct_', $priv, 1 );

            if ( !isset( $approved_privs[ $priv ] ) )
                return false;
        }

        return true;
    }

    return false;
}

/**
 * Shortcode support for use anywhere that support WP Shortcodes
 *
 * @param array $tags An associative array of shortcode properties
 * @param string $content A string that represents a template override
 *
 * @return string
 * @since 1.6.7
 */
function jet_cct_shortcode ( $tags, $content = null ) {

	if ( defined( 'jet_cct_DISABLE_SHORTCODE' ) && jet_cct_DISABLE_SHORTCODE ) {
		return '';
	}

	// For enforcing pagination parameters when not displaying pagination
	$page = 1;
	$offset = 0;

	if ( isset( $tags['page'] ) ) {
		$page = (int) $tags['page'];
		$page = max( $page, 1 );
	}

	if ( isset( $tags['offset'] ) ) {
		$offset = (int) $tags['offset'];
		$offset = max( $offset, 0 );
	}

    $defaults = array(
    	'use_current' => false,
        'name' => null,
        'id' => null,
        'slug' => null,
        'select' => null,
        'join' => null,
        'order' => null,
        'orderby' => null,
        'limit' => null,
        'where' => null,
        'having' => null,
        'groupby' => null,
        'search' => true,
        'pagination' => false,
        'page' => null,
        'offset' => null,
        'filters' => false,
        'filters_label' => null,
        'filters_location' => 'before',
        'pagination_label' => null,
        'pagination_location' => 'after',
        'field' => null,
        'col' => null,
        'template' => null,
        'jet_cct_page' => null,
        'helper' => null,
        'form' => null,
        'fields' => null,
        'label' => null,
        'thank_you' => null,
        'view' => null,
        'cache_mode' => 'none',
        'expires' => 0,
		'shortcodes' => false
    );

    if ( !empty( $tags ) )
        $tags = array_merge( $defaults, $tags );
    else
        $tags = $defaults;

    $tags = apply_filters( 'jet_cct_shortcode', $tags );

	$tags[ 'pagination' ] = filter_var($tags[ 'pagination' ], FILTER_VALIDATE_BOOLEAN);
	$tags[ 'search' ] = filter_var($tags[ 'pagination' ], FILTER_VALIDATE_BOOLEAN);
	$tags[ 'use_current' ] = filter_var($tags[ 'use_current' ], FILTER_VALIDATE_BOOLEAN);

    if ( empty( $content ) )
        $content = null;

	// Allow views only if not targeting a file path (must be within theme)
    if ( 0 < strlen( $tags[ 'view' ] ) ) {
		$return = '';

		if ( !file_exists( $tags[ 'view' ] ) ) {
			$return = jet_cct_view( $tags[ 'view' ], null, (int) $tags[ 'expires' ], $tags[ 'cache_mode' ], true );

			if ( $tags[ 'shortcodes' ] && defined( 'jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES' ) && jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES ) {
				$return = do_shortcode( $return );
			}
		}

		return $return;
	}

    if ( ! $tags['use_current'] && empty( $tags[ 'name' ] ) ) {
        if ( in_the_loop() || is_singular() ) {
            $jet = jet_cct( get_post_type(), get_the_ID(), false );

            if ( !empty( $jet ) ) {
                $tags[ 'name' ] = get_post_type();
                $id = $tags[ 'id' ] = get_the_ID();
            }
        }

        if ( empty( $tags[ 'name' ] ) )
            return '<p>Please provide a jet name</p>';
    }

    if ( !empty( $tags[ 'col' ] ) ) {
        $tags[ 'field' ] = $tags[ 'col' ];

        unset( $tags[ 'col' ] );
    }

    if ( !empty( $tags[ 'order' ] ) ) {
        $tags[ 'orderby' ] = $tags[ 'order' ];

        unset( $tags[ 'order' ] );
    }

    if ( empty( $content ) && empty( $tags[ 'jet_cct_page' ] ) && empty( $tags[ 'template' ] ) && empty( $tags[ 'field' ] ) && empty( $tags[ 'form' ] ) ) {
        return '<p>Please provide either a template or field name</p>';
    }

    if ( ! $tags['use_current'] && !isset( $id ) ) {
        // id > slug (if both exist)
		$id = null;

		if ( !empty( $tags[ 'slug' ] ) ) {
			$id = $tags[ 'slug' ];

			if ( defined( 'jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS' ) && jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS ) {
				$id = jet_cct_evaluate_tags( $id );
			}
		}

        if ( !empty( $tags[ 'id' ] ) ) {
            $id = $tags[ 'id' ];

            if ( defined( 'jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS' ) && jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS ) {
                $id = jet_cct_evaluate_tags( $id );
            }

            if ( is_numeric( $id ) )
                $id = absint( $id );
        }
    }

    if ( !isset( $jet ) ) {
    	if ( ! $tags['use_current'] ) {
        	$jet = jet_cct( $tags[ 'name' ], $id );
    	} else {
    		$jet = jet_cct();
    		$id = $jet->id();
    	}
    }

    if ( empty( $jet ) || ! $jet->valid() )
        return '<p>jet not found</p>';

	$found = 0;

	$is_singular = ( ! empty( $id ) || $tags['use_current'] );

	if ( ! $is_singular ) {
		$params = array();

		if ( !defined( 'jet_cct_DISABLE_SHORTCODE_SQL' ) || !jet_cct_DISABLE_SHORTCODE_SQL ) {
			if ( 0 < strlen( $tags[ 'orderby' ] ) ) {
				$params[ 'orderby' ] = $tags[ 'orderby' ];
			}

			if ( 0 < strlen( $tags[ 'where' ] ) ) {
				$params[ 'where' ] = $tags[ 'where' ];

				if ( defined( 'jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS' ) && jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS ) {
					$params[ 'where' ] = jet_cct_evaluate_tags( $params[ 'where' ] );
				}
			}

			if ( 0 < strlen( $tags[ 'having' ] ) ) {
				$params[ 'having' ] = $tags[ 'having' ];

				if ( defined( 'jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS' ) && jet_cct_SHORTCODE_ALLOW_EVALUATE_TAGS ) {
					$params[ 'having' ] = jet_cct_evaluate_tags( $id );
				}
			}

			if ( 0 < strlen( $tags[ 'groupby' ] ) ) {
				$params[ 'groupby' ] = $tags[ 'groupby' ];
			}

			if ( 0 < strlen( $tags[ 'select' ] ) ) {
				$params[ 'select' ] = $tags[ 'select' ];
			}
			if ( 0 < strlen( $tags[ 'join' ] ) ) {
				$params[ 'join' ] = $tags[ 'join' ];
			}
		}

		// Forms require params set
		if ( ! empty( $params ) || empty( $tags[ 'form' ] ) ) {
			if ( !empty( $tags[ 'limit' ] ) ) {
				$params[ 'limit' ] = (int) $tags[ 'limit' ];
			}

			$params[ 'search' ] = $tags[ 'search' ];

			$params[ 'pagination' ] = $tags[ 'pagination' ];

			// If we aren't displaying pagination, we need to enforce page/offset
			if ( ! $params['pagination'] ) {
				$params['page']   = $page;
				$params['offset'] = $offset;

				// Force pagination on, we need it and we're enforcing page/offset
				$params['pagination'] = true;
			} else {
				// If we are displaying pagination, allow page/offset override only if *set*

				if ( isset( $tags['page'] ) ) {
					$params['page'] = (int) $tags['page'];
					$params['page'] = max( $params['page'], 1 );
				}

				if ( isset( $tags['offset'] ) ) {
					$params['offset'] = (int) $tags['offset'];
					$params['offset'] = max( $params['offset'], 0 );
				}
			}

			if ( !empty( $tags[ 'cache_mode' ] ) && 'none' != $tags[ 'cache_mode' ] ) {
				$params[ 'cache_mode' ] = $tags[ 'cache_mode' ];
				$params[ 'expires' ] = (int) $tags[ 'expires' ];
			}

			$params = apply_filters( 'jet_cct_shortcode_findrecords_params', $params, $jet, $tags );

			$jet->find( $params );

			$found = $jet->total();
		}
	}

    if ( !empty( $tags[ 'form' ] ) ) {
		if ( 'user' == $jet->jet ) {
			// Further hardening of User-based forms
			if ( false !== strpos( $tags[ 'fields' ], '_capabilities' ) || false !== strpos( $tags[ 'fields' ], '_user_level' ) ) {
				return '';
			}
			// Only explicitly allow user edit forms
			elseif ( $is_singular && ( !defined( 'jet_cct_SHORTCODE_ALLOW_USER_EDIT' ) || !jet_cct_SHORTCODE_ALLOW_USER_EDIT ) ) {
				return '';
			}
		}

        return $jet->form( $tags[ 'fields' ], $tags[ 'label' ], $tags[ 'thank_you' ] );
	}
    elseif ( !empty( $tags[ 'field' ] ) ) {
        if ( empty( $tags[ 'helper' ] ) )
            $return = $jet->display( $tags[ 'field' ] );
        else
            $return = $jet->helper( $tags[ 'helper' ], $jet->field( $tags[ 'field' ] ), $tags[ 'field' ] );

		if ( $tags[ 'shortcodes' ] && defined( 'jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES' ) && jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES ) {
			$return = do_shortcode( $return );
		}

		return $return;
    }
    elseif ( !empty( $tags[ 'jet_cct_page' ] ) && class_exists( 'jet_cct_Pages' ) ) {
        $jet_cct_page = jet_cct_Pages::exists( $tags[ 'jet_cct_page' ] );

        if ( empty( $jet_cct_page ) )
            return '<p>jet_cct Page not found</p>';

        $return = jet_cct_Pages::content( true, $jet_cct_page );

		if ( $tags[ 'shortcodes' ] && defined( 'jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES' ) && jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES ) {
			$return = do_shortcode( $return );
		}

		return $return;
    }

    ob_start();

    if ( ! $is_singular && false !== $tags[ 'filters' ] && 'before' == $tags[ 'filters_location' ] )
        echo $jet->filters( $tags[ 'filters' ], $tags[ 'filters_label' ] );

    if ( ! $is_singular && 0 < $found && true === $tags[ 'pagination' ] && in_array( $tags[ 'pagination_location' ], array( 'before', 'both' ) ) )
        echo $jet->pagination( $tags[ 'pagination_label' ] );

    echo $jet->template( $tags[ 'template' ], $content );

    if ( ! $is_singular && 0 < $found && true === $tags[ 'pagination' ] && in_array( $tags[ 'pagination_location' ], array( 'after', 'both' ) ) )
        echo $jet->pagination( $tags[ 'pagination_label' ] );

    if ( ! $is_singular && false !== $tags[ 'filters' ] && 'after' == $tags[ 'filters_location' ] )
        echo $jet->filters( $tags[ 'filters' ], $tags[ 'filters_label' ] );

	$return = ob_get_clean();

	if ( $tags[ 'shortcodes' ] && defined( 'jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES' ) && jet_cct_SHORTCODE_ALLOW_SUB_SHORTCODES ) {
		$return = do_shortcode( $return );
	}

	return $return;
}

/**
 * Form Shortcode support for use anywhere that support WP Shortcodes
 *
 * @param array $tags An associative array of shortcode properties
 * @param string $content Not currently used
 *
 * @return string
 * @since 2.3
 */
function jet_cct_shortcode_form ( $tags, $content = null ) {
    $tags[ 'form' ] = 1;

    return jet_cct_shortcode( $tags );
}

/**
 * Fork of WordPress do_shortcode that allows specifying which shortcodes are ran.
 *
 * Search content for shortcodes and filter shortcodes through their hooks.
 *
 * If there are no shortcode tags defined, then the content will be returned
 * without any filtering. This might cause issues when plugins are disabled but
 * the shortcode will still show up in the post or content.
 *
 * @since 2.4.3
 *
 * @uses $shortcode_tags
 * @uses get_shortcode_regex() Gets the search pattern for searching shortcodes.
 *
 * @param string $content Content to search for shortcodes
 * @param array $shortcodes Array of shortcodes to run
 * @return string Content with shortcodes filtered out.
 */
function jet_cct_do_shortcode( $content, $shortcodes ) {

	global $shortcode_tags;

	// No shortcodes in content
	if ( false === strpos( $content, '[' ) ) {
		return $content;
	}

	// No shortcodes registered
	if ( empty( $shortcode_tags ) || !is_array( $shortcode_tags ) ) {
		return $content;
	}

	if ( !empty( $shortcodes ) ) {
		$temp_shortcode_filter = function ( $return, $tag, $attr, $m ) use ( $shortcodes ) {
			if ( in_array( $m[2], $shortcodes ) ) {
				// If shortcode being called is in list, return false to allow it to run
				return false;
			}
			// Return original shortcode string if we aren't going to handle at this time
			return $m[0];
		};
		add_filter( 'pre_do_shortcode_tag', $temp_shortcode_filter, 10, 4 );
	}

	$content = do_shortcode( $content );

	if ( isset( $temp_shortcode_filter ) ) {
		remove_filter( 'pre_do_shortcode_tag', $temp_shortcode_filter );
	}

	return $content;

}

/**
 * Check if jet_cct is compatible with WP / PHP / MySQL or not
 *
 * @return bool
 *
 * @since 1.10
 */
function jet_cct_compatibility_check () {
    $compatible = true;

    if ( !jet_cct_version_check( 'wp', jet_cct_WP_VERSION_MINIMUM ) ) {
        $compatible = false;

        add_action( 'admin_notices', 'jet_cct_version_notice_wp' );
    }

    if ( !jet_cct_version_check( 'php', jet_cct_PHP_VERSION_MINIMUM ) ) {
        $compatible = false;

        add_action( 'admin_notices', 'jet_cct_version_notice_php' );
    }

    if ( !jet_cct_version_check( 'mysql', jet_cct_MYSQL_VERSION_MINIMUM ) ) {
        $compatible = false;

        add_action( 'admin_notices', 'jet_cct_version_notice_mysql' );
    }

    return $compatible;
}

/**
 * Show WP notice if WP version is incompatible
 *
 * @return void
 *
 * @since 1.10
 */
function jet_cct_version_notice_wp () {
    global $wp_version;
?>
    <div class="error fade">
        <p>
            <strong><?php _e( 'NOTICE', 'jet_cct' ); ?>:</strong> jet_cct <?php echo esc_html( jet_cct_VERSION ); ?> <?php _e( 'requires a minimum of', 'jet_cct' ); ?>
            <strong>WordPress <?php echo esc_html( jet_cct_WP_VERSION_MINIMUM ); ?>+</strong> <?php _e( 'to function. You are currently running', 'jet_cct' ); ?>
            <strong>WordPress <?php echo esc_html( $wp_version ); ?></strong> - <?php _e( 'Please upgrade your WordPress to continue.', 'jet_cct' ); ?>
        </p>
    </div>
<?php
}

/**
 * Show WP notice if PHP version is incompatible
 *
 * @return void
 *
 * @since 1.10
 */
function jet_cct_version_notice_php () {
?>
    <div class="error fade">
        <p>
            <strong><?php _e( 'NOTICE', 'jet_cct' ); ?>:</strong> jet_cct <?php echo esc_html( jet_cct_VERSION ); ?> <?php _e( 'requires a minimum of', 'jet_cct' ); ?>
            <strong>PHP <?php echo esc_html( jet_cct_PHP_VERSION_MINIMUM ); ?>+</strong> <?php _e( 'to function. You are currently running', 'jet_cct' ); ?>
            <strong>PHP <?php echo esc_html( phpversion() ); ?></strong> - <?php _e( 'Please upgrade (or have your Hosting Provider upgrade it for you) your PHP version to continue.', 'jet_cct' ); ?>
        </p>
    </div>
<?php
}

/**
 * Show WP notice if MySQL version is incompatible
 *
 * @return void
 *
 * @since 1.10
 */
function jet_cct_version_notice_mysql () {
    global $wpdb;
    $mysql = $wpdb->db_version();
?>
    <div class="error fade">
        <p><strong><?php _e( 'NOTICE', 'jet_cct' ); ?>:</strong> jet_cct <?php echo esc_html( jet_cct_VERSION ); ?> <?php _e( 'requires a minimum of', 'jet_cct' ); ?>
            <strong>MySQL <?php echo esc_html( jet_cct_MYSQL_VERSION_MINIMUM ); ?>+</strong> <?php _e( 'to function. You are currently running', 'jet_cct' ); ?>
            <strong>MySQL <?php echo esc_html( $mysql ); ?></strong> - <?php _e( 'Please upgrade (or have your Hosting Provider upgrade it for you) your MySQL version to continue.', 'jet_cct' ); ?>
        </p>
    </div>
<?php
}

/**
 * Check if a Function exists or File exists in Theme / Child Theme
 *
 * @param string $function_or_file Function or file name to look for.
 * @param string $function_name (optional) Function name to look for.
 * @param string $file_dir (optional) Drectory to look into
 * @param string $file_name (optional) Filename to look for
 *
 * @return mixed
 *
 * @since 1.12
 */
function jet_cct_function_or_file ( $function_or_file, $function_name = null, $file_dir = null, $file_name = null ) {
    $found = false;
    $function_or_file = (string) $function_or_file;
    if ( false !== $function_name ) {
        if ( null === $function_name )
            $function_name = $function_or_file;
        $function_name = str_replace( array(
            '__',
            '__',
            '__'
        ), '_', preg_replace( '/[^a-z^A-Z^_][^a-z^A-Z^0-9^_]*/', '_', (string) $function_name ) );
        if ( function_exists( 'jet_cct_custom_' . $function_name ) )
            $found = array( 'function' => 'jet_cct_custom_' . $function_name );
        elseif ( function_exists( $function_name ) )
            $found = array( 'function' => $function_name );
    }
    if ( false !== $file_name && false === $found ) {
        if ( null === $file_name )
            $file_name = $function_or_file;
        $file_name = str_replace( array(
            '__',
            '__',
            '__'
        ), '_', preg_replace( '/[^a-z^A-Z^0-9^_]*/', '_', (string) $file_name ) ) . '.php';
        $custom_location = apply_filters( 'jet_cct_file_directory', null, $function_or_file, $function_name, $file_dir, $file_name );
        if ( defined( 'jet_cct_FILE_DIRECTORY' ) && false !== jet_cct_FILE_DIRECTORY )
            $custom_location = jet_cct_FILE_DIRECTORY;
        if ( !empty( $custom_location ) && locate_template( trim( $custom_location, '/' ) . '/' . ( !empty( $file_dir ) ? $file_dir . '/' : '' ) . $file_name ) )
            $found = array( 'file' => trim( $custom_location, '/' ) . '/' . ( !empty( $file_dir ) ? $file_dir . '/' : '' ) . $file_name );
        elseif ( locate_template( 'jet_cct/' . ( !empty( $file_dir ) ? $file_dir . '/' : '' ) . $file_name ) )
            $found = array( 'file' => 'jet_cct/' . ( !empty( $file_dir ) ? $file_dir . '/' : '' ) . $file_name );
        elseif ( locate_template( 'jet_cct-' . ( !empty( $file_dir ) ? $file_dir . '-' : '' ) . $file_name ) )
            $found = array( 'file' => 'jet_cct-' . ( !empty( $file_dir ) ? $file_dir . '-' : '' ) . $file_name );
        elseif ( locate_template( 'jet_cct/' . ( !empty( $file_dir ) ? $file_dir . '-' : '' ) . $file_name ) )
            $found = array( 'file' => 'jet_cct/' . ( !empty( $file_dir ) ? $file_dir . '-' : '' ) . $file_name );
    }

    return apply_filters( 'jet_cct_function_or_file', $found, $function_or_file, $function_name, $file_name );
}

/**
 * Redirects to another page.
 *
 * @param string $location The path to redirect to
 * @param int $status Status code to use
 *
 * @return void
 *
 * @since 2.0
 */
function jet_cct_redirect ( $location, $status = 302 ) {
    if ( !headers_sent() ) {
        wp_redirect( $location, $status );
        die();
    }
    else {
        die( '<script type="text/javascript">'
            . 'document.location = "' . str_replace( '&amp;', '&', esc_js( $location ) ) . '";'
            . '</script>' );
    }
}

/**
 * Check if a user has permission to be doing something based on standard permission options
 *
 * @param array $options
 *
 * @return bool Whether the user has permissions
 *
 * @since 2.0.5
 */
function jet_cct_permission ( $options ) {
    global $current_user;

    wp_get_current_user();

    $permission = false;

    if ( isset( $options[ 'options' ] ) )
        $options = $options[ 'options' ];

    if ( jet_cct_is_admin() )
        $permission = true;
    elseif ( 0 == jet_cct_v( 'restrict_role', $options, 0 ) && 0 == jet_cct_v( 'restrict_capability', $options, 0 ) && 0 == jet_cct_v( 'admin_only', $options, 0 ) )
        $permission = true;

    if ( !$permission && 1 == jet_cct_v( 'restrict_role', $options, 0 ) ) {
        $roles = jet_cct_v( 'roles_allowed', $options );

        if ( !is_array( $roles ) )
            $roles = explode( ',', $roles );

        $roles = array_unique( array_filter( $roles ) );

        foreach( $roles as $role ) {
            if ( is_user_logged_in() && in_array( $role, $current_user->roles ) ) {
                $permission = true;

                break;
            }
        }
    }

    if ( !$permission && 1 == jet_cct_v( 'restrict_capability', $options, 0 ) ) {
        $capabilities = jet_cct_v( 'capability_allowed', $options );

        if ( !is_array( $capabilities ) )
            $capabilities = explode( ',', $capabilities );

        $capabilities = array_unique( array_filter( $capabilities ) );

        foreach( $capabilities as $capability ) {
            $must_have_capabilities = explode( '&&', $capability );
            $must_have_capabilities = array_unique( array_filter( $must_have_capabilities ) );

            $must_have_permission = true;

            foreach ( $must_have_capabilities as $must_have_capability ) {
                if ( !current_user_can( $must_have_capability ) ) {
                    $must_have_permission = false;

                    break;
                }
            }

            if ( $must_have_permission && is_user_logged_in() ) {
                $permission = true;

                break;
            }
        }
    }

    return $permission;
}

/**
 * Check if permissions are restricted
 *
 * @param array $options
 *
 * @return bool Whether the permissions are restricted
 *
 * @since 2.3.4
 */
function jet_cct_has_permissions ( $options ) {
    $permission = false;

    if ( isset( $options[ 'options' ] ) )
        $options = $options[ 'options' ];

    if ( 1 == jet_cct_v( 'restrict_role', $options, 0 ) || 1 == jet_cct_v( 'restrict_capability', $options, 0 ) || 1 == jet_cct_v( 'admin_only', $options, 0 ) )
        return true;

    return false;
}

/**
 * A fork of get_page_by_title that excludes items unavailable via access rights (by status)
 *
 * @see get_page_by_title
 *
 * @param string $title Title of item to get
 * @param string $output Optional. Output type. OBJECT, ARRAY_N, or ARRAY_A. Default OBJECT.
 * @param string $type Post Type
 * @param string|array $status Post statuses to include (default is what user has access to)
 *
 * @return WP_Post|null WP_Post on success or null on failure
 *
 * @since 2.3.4
 */
function jet_cct_by_title ( $title, $output = OBJECT, $type = 'page', $status = null ) {
    // @todo support jet item lookups, not just Post Types

    /**
     * @var $wpdb WPDB
     */
    global $wpdb;

    if ( empty( $status ) ) {
        $status = array(
            'publish'
        );

        if ( current_user_can( 'read_private_' . $type . 's') )
            $status[] = 'private';

        if ( current_user_can( 'edit_' . $type . 's' ) )
            $status[] = 'draft';
    }

    $status = (array) $status;

    $status_sql = ' AND `post_status` IN ( %s' . str_repeat( ', %s', count( $status ) -1 ) . ' )';

    $orderby_sql = ' ORDER BY ( `post_status` = %s ) DESC' . str_repeat( ', ( `post_status` = %s ) DESC', count( $status ) - 1 ) . ', `ID` DESC';

    $prepared = array_merge( array( $title, $type ), $status, $status ); // once for WHERE, once for ORDER BY

    $page = $wpdb->get_var( $wpdb->prepare( "SELECT `ID` FROM `{$wpdb->posts}` WHERE `post_title` = %s AND `post_type` = %s" . $status_sql . $orderby_sql, $prepared ) );

    if ( $page )
        return get_post( jet_cct_v( $page, 'post_id' ), $output );

    return null;
}

/**
 * Get a field value from a jet
 *
 * @param string $jet The jet name
 * @param mixed $id (optional) The ID or slug, to load a single record; Provide array of $params to run 'find'
 * @param string|array $name The field name, or an associative array of parameters
 * @param boolean $single (optional) For tableless fields, to return the whole array or the just the first item
 *
 * @return mixed Field value
 *
 * @since 2.1
 */
function jet_cct_field ( $jet, $id = false, $name = null, $single = false ) {
    // allow for jet_cct_field( 'field_name' );
    if ( null === $name ) {
        $name = $jet;
        $single = (boolean) $id;

        $jet = get_post_type();
        $id = get_the_ID();
    }

    $jet = jet_cct( $jet, $id );

	if ( is_object( $jet ) ) {
		return $jet->field( $name, $single );
	}

	return null;
}

/**
 * Get a field display value from a jet
 *
 * @param string $jet The jet name
 * @param mixed $id (optional) The ID or slug, to load a single record; Provide array of $params to run 'find'
 * @param string|array $name The field name, or an associative array of parameters
 * @param boolean $single (optional) For tableless fields, to return the whole array or the just the first item
 *
 * @return mixed Field value
 *
 * @since 2.1
 */
function jet_cct_field_display ( $jet, $id = false, $name = null, $single = false ) {
    // allow for jet_cct_field_display( 'field_name' );
    if ( null === $name ) {
        $name = $jet;
        $single = (boolean) $id;

        $jet = get_post_type();
        $id = get_the_ID();
    }

    $jet = jet_cct( $jet, $id );

	if ( is_object( $jet ) ) {
		return $jet->display( $name, $single );
	}

	return null;
}

/**
 * Get a field raw value from a jet
 *
 * @param string $jet The jet name
 * @param mixed $id (optional) The ID or slug, to load a single record; Provide array of $params to run 'find'
 * @param string|array $name The field name, or an associative array of parameters
 * @param boolean $single (optional) For tableless fields, to return the whole array or the just the first item
 *
 * @return mixed Field value
 *
 * @since 2.1
 */
function jet_cct_field_raw ( $jet, $id = false, $name = null, $single = false ) {
    // allow for jet_cct_field_raw( 'field_name' );
    if ( null === $name ) {
        $name = $jet;
        $single = (boolean) $id;

        $jet = get_post_type();
        $id = get_the_ID();
    }

    return jet_cct( $jet, $id )->raw( $name, $single );

}

/**
 * Set a cached value
 *
 * @see jet_cctView::set
 *
 * @param string $key Key for the cache
 * @param mixed $value Value to add to the cache
 * @param int $expires (optional) Time in seconds for the cache to expire, if 0 no expiration.
 * @param string $cache_mode (optional) Decides the caching method to use for the view.
 * @param string $group (optional) Key for the group
 *
 * @return bool|mixed|null|string|void
 *
 * @since 2.0
 */
function jet_cct_view_set ( $key, $value, $expires = 0, $cache_mode = 'cache', $group = '' ) {
    require_once( jet_cct_DIR . 'classes/jet_cctView.php' );

    return jet_cctView::set( $key, $value, $expires, $cache_mode, $group );
}

/**
 * Get a cached value
 *
 * @see jet_cctView::get
 *
 * @param string $key Key for the cache
 * @param string $cache_mode (optional) Decides the caching method to use for the view.
 * @param string $group (optional) Key for the group
 * @param string $callback (optional) Callback function to run to set the value if not cached
 *
 * @return bool|mixed|null|void
 *
 * @since 2.0
 */
function jet_cct_view_get ( $key, $cache_mode = 'cache', $group = '', $callback = null ) {
    require_once( jet_cct_DIR . 'classes/jet_cctView.php' );

    return jet_cctView::get( $key, $cache_mode, $group, $callback );
}

/**
 * Clear a cached value
 *
 * @see jet_cctView::clear
 *
 * @param string|bool $key Key for the cache
 * @param string $cache_mode (optional) Decides the caching method to use for the view.
 * @param string $group (optional) Key for the group
 *
 * @return bool
 *
 * @since 2.0
 */
function jet_cct_view_clear ( $key = true, $cache_mode = 'cache', $group = '' ) {
    require_once( jet_cct_DIR . 'classes/jet_cctView.php' );

    return jet_cctView::clear( $key, $cache_mode, $group );
}

/**
 * Set a cached value
 *
 * @see jet_cctView::set
 *
 * @param string $key Key for the cache
 * @param mixed $value Value to add to the cache
 * @param string $group (optional) Key for the group
 * @param int $expires (optional) Time in seconds for the cache to expire, if 0 no expiration.
 *
 * @return bool|mixed|null|string|void
 *
 * @since 2.0
 */
function jet_cct_cache_set ( $key, $value, $group = '', $expires = 0) {
    return jet_cct_view_set( $key, $value, $expires, 'cache', $group );
}

/**
 * Get a cached value
 *
 * @see jet_cctView::get
 *
 * @param string $key Key for the cache
 * @param string $group (optional) Key for the group
 * @param string $callback (optional) Callback function to run to set the value if not cached
 *
 * @return bool
 *
 * @since 2.0
 */
function jet_cct_cache_get ( $key, $group = '', $callback = null ) {
    return jet_cct_view_get( $key, 'cache', $group, $callback );
}

/**
 * Clear a cached value
 *
 * @see jet_cctView::clear
 *
 * @param string|bool $key Key for the cache
 * @param string $group (optional) Key for the group
 *
 * @return bool|mixed|null|void
 *
 * @since 2.0
 */
function jet_cct_cache_clear ( $key = true, $group = '' ) {
    return jet_cct_view_clear( $key, 'cache', $group );
}

/**
 * Set a cached value
 *
 * @see jet_cctView::set
 *
 * @param string $key Key for the cache
 * @param mixed $value Value to add to the cache
 * @param int $expires (optional) Time in seconds for the cache to expire, if 0 no expiration.
 *
 * @return bool|mixed|null|string|void
 *
 * @since 2.0
 */
function jet_cct_transient_set ( $key, $value, $expires = 0 ) {
    return jet_cct_view_set( $key, $value, $expires, 'transient' );
}

/**
 * Get a cached value
 *
 * @see jet_cctView::get
 *
 * @param string $key Key for the cache
 * @param string $callback (optional) Callback function to run to set the value if not cached
 *
 * @return bool|mixed|null|void
 *
 * @since 2.0
 */
function jet_cct_transient_get ( $key, $callback = null ) {
    return jet_cct_view_get( $key, 'transient', '', $callback );
}

/**
 * Clear a cached value
 *
 * @see jet_cctView::clear
 *
 * @param string|bool $key Key for the cache
 *
 * @return bool
 *
 * @since 2.0
 */
function jet_cct_transient_clear ( $key = true ) {
    return jet_cct_view_clear( $key, 'transient' );
}

/**
 * Set a cached value
 *
 * @see jet_cctView::set
 *
 * @param string $key Key for the cache
 * @param mixed $value Value to add to the cache
 * @param int $expires (optional) Time in seconds for the cache to expire, if 0 no expiration.
 *
 * @return bool|mixed|null|string|void
 *
 * @since 2.3.10
 */
function jet_cct_site_transient_set ( $key, $value, $expires = 0 ) {
    return jet_cct_view_set( $key, $value, $expires, 'site-transient' );
}

/**
 * Get a cached value
 *
 * @see jet_cctView::get
 *
 * @param string $key Key for the cache
 * @param string $callback (optional) Callback function to run to set the value if not cached
 *
 * @return bool|mixed|null|void
 *
 * @since 2.3.10
 */
function jet_cct_site_transient_get ( $key, $callback = null ) {
    return jet_cct_view_get( $key, 'site-transient', '', $callback );
}

/**
 * Clear a cached value
 *
 * @see jet_cctView::clear
 *
 * @param string|bool $key Key for the cache
 *
 * @return bool
 *
 * @since 2.3.10
 */
function jet_cct_site_transient_clear ( $key = true ) {
    return jet_cct_view_clear( $key, 'site-transient' );
}

/**
 * Set a cached value
 *
 * @see jet_cctView::set
 *
 * @param string $key Key for the cache
 * @param mixed $value Value to add to the cache
 * @param int $expires (optional) Time in seconds for the cache to expire, if 0 no expiration.
 * @param string $group (optional) Key for the group
 *
 * @return bool|mixed|null|string|void
 *
 * @since 2.3.10
 */
function jet_cct_option_cache_set ( $key, $value, $expires = 0, $group = '' ) {
    return jet_cct_view_set( $key, $value, $expires, 'option-cache', $group );
}

/**
 * Get a cached value
 *
 * @see jet_cctView::get
 *
 * @param string $key Key for the cache
 * @param string $group (optional) Key for the group
 * @param string $callback (optional) Callback function to run to set the value if not cached
 *
 * @return bool|mixed|null|void
 *
 * @since 2.3.10
 */
function jet_cct_option_cache_get ( $key, $group = '', $callback = null ) {
    return jet_cct_view_get( $key, 'option-cache', $group, $callback );
}

/**
 * Clear a cached value
 *
 * @see jet_cctView::clear
 *
 * @param string|bool $key Key for the cache
 * @param string $group (optional) Key for the group
 *
 * @return bool
 *
 * @since 2.3.10
 */
function jet_cct_option_cache_clear ( $key = true, $group = '' ) {
    return jet_cct_view_clear( $key, 'option-cache', $group );
}

/**
 * Scope variables and include a template like get_template_part that's child-theme aware
 *
 * @see get_template_part
 *
 * @param string|array $template Template names (see get_template_part)
 * @param array $data Data to scope to the include
 * @param bool $return Whether to return the output (echo by default)
 * @return string|null Template output
 *
 * @since 2.3.9
 */
function jet_cct_template_part ( $template, $data = null, $return = false ) {
    $part = jet_cctView::get_template_part( $template, $data );

    if ( !$return ) {
        echo $part;

        return null;
    }

    return $part;
}

/**
 * Add a new jet outside of the DB
 *
 * @see jet_cctMeta::register
 *
 * @param string $type The jet type ('post_type', 'taxonomy', 'media', 'user', 'comment')
 * @param string $name The jet name
 * @param array $object (optional) jet array, including any 'fields' arrays
 *
 * @return array|boolean jet data or false if unsuccessful
 * @since 2.1
 */
function jet_cct_register_type ( $type, $name, $object = null ) {
    if ( empty( $object ) )
        $object = array();

    if ( !empty( $name ) )
        $object[ 'name' ] = $name;

    return jet_cct_meta()->register( $type, $object );
}

/**
 * Add a new jet field outside of the DB
 *
 * @see jet_cctMeta::register_field
 *
 * @param string|array $jet The jet name or array of jet names
 * @param string $name The name of the jet
 * @param array $object (optional) jet array, including any 'fields' arrays
 *
 * @return array|boolean Field data or false if unsuccessful
 * @since 2.1
 */
function jet_cct_register_field ( $jet, $name, $field = null ) {
    if ( empty( $field ) )
        $field = array();

    if ( !empty( $name ) )
        $field[ 'name' ] = $name;

    return jet_cct_meta()->register_field( $jet, $field );
}

/**
 * Add a new jet field type
 *
 * @see jet_cctForm::register_field_type
 *
 * @param string $type The new field type identifier
 * @param string $file The new field type class file location
 *
 * @return array Field type array
 * @since 2.3
 */
function jet_cct_register_field_type ( $type, $file = null ) {
    return jet_cctForm::register_field_type( $type, $file );
}

/**
 * Register a related object
 *
 * @param string $name Object name
 * @param string $label Object label
 * @param array $options Object options
 *
 * @return array|boolean Object array or false if unsuccessful
 * @since 2.3
 */
function jet_cct_register_related_object ( $name, $label, $options = null ) {
    return jet_cctForm::field_method( 'pick', 'register_related_object', $name, $label, $options );
}

/**
 * Require a component (always-on)
 *
 * @param string $component Component ID
 *
 * @return void
 *
 * @since 2.3
 */
function jet_cct_require_component ( $component ) {
    add_filter( 'jet_cct_component_require_' . $component, '__return_true' );
}

/**
 * Add a meta group of fields to add/edit forms
 *
 * @see jet_cctMeta::group_add
 *
 * @param string|array $jet The jet or type of element to attach the group to.
 * @param string $label Title of the edit screen section, visible to user.
 * @param string|array $fields Either a comma separated list of text fields or an associative array containing field information.
 * @param string $context (optional) The part of the page where the edit screen section should be shown ('normal', 'advanced', or 'side').
 * @param string $priority (optional) The priority within the context where the boxes should show ('high', 'core', 'default' or 'low').
 * @param string $type (optional) Type of the post to attach to.
 *
 * @return void
 *
 * @since 2.0
 * @link http://jet_cct.io/docs/jet_cct-group-add/
 */
function jet_cct_group_add ( $jet, $label, $fields, $context = 'normal', $priority = 'default', $type = null ) {
    if ( !is_array( $jet ) && null !== $type ) {
        $jet = array(
            'name' => $jet,
            'type' => $type
        );
    }

    jet_cct_meta()->group_add( $jet, $label, $fields, $context, $priority );
}

/**
 * Check if a plugin is active on non-admin pages (is_plugin_active() only available in admin)
 *
 * @param string $plugin Plugin name.
 *
 * @return bool
 *
 * @since 2.0
 */
function jet_cct_is_plugin_active ( $plugin ) {
    $active = false;

    if ( function_exists( 'is_plugin_active' ) )
        $active = is_plugin_active( $plugin );

    if ( !$active ) {
        $active_plugins = (array) get_option( 'active_plugins', array() );

        if ( in_array( $plugin, $active_plugins ) )
            $active = true;

        if ( !$active && is_multisite() ) {
            $plugins = get_site_option( 'active_sitewide_plugins' );

            if ( isset( $plugins[ $plugin ] ) )
                $active = true;
        }
    }

    return $active;
}

/**
 * Check if jet_cct no conflict is on or not
 *
 * @param string $object_type
 *
 * @return bool
 *
 * @since 2.3
 */
function jet_cct_no_conflict_check ( $object_type = 'post' ) {
    if ( 'post_type' == $object_type )
        $object_type = 'post';
    elseif ( 'term' == $object_type )
        $object_type = 'taxonomy';

    if ( ! class_exists( 'jet_cctInit' ) )
        jet_cct_init();

    if ( !empty( jet_cctInit::$no_conflict ) && isset( jet_cctInit::$no_conflict[ $object_type ] ) && !empty( jet_cctInit::$no_conflict[ $object_type ] ) )
        return true;

    return false;
}

/**
 * Turn off conflicting / recursive actions for an object type that jet_cct hooks into
 *
 * @param string $object_type
 * @param string $object
 *
 * @return bool
 *
 * @since 2.0
 */
function jet_cct_no_conflict_on ( $object_type = 'post', $object = null ) {

    if ( 'post_type' == $object_type )
        $object_type = 'post';
    elseif ( 'term' == $object_type )
        $object_type = 'taxonomy';

    if ( ! class_exists( 'jet_cctInit' ) )
        jet_cct_init();

    if ( !empty( jet_cctInit::$no_conflict ) && isset( jet_cctInit::$no_conflict[ $object_type ] ) && !empty( jet_cctInit::$no_conflict[ $object_type ] ) )
        return true;

    if ( !is_object( jet_cctInit::$meta ) )
        return false;

    $no_conflict = array(
		'filter' => array()
	);

    // Filters = Usually get/update/delete meta functions
    // Actions = Usually insert/update/save/delete object functions
    if ( 'post' == $object_type ) {
		if ( apply_filters( 'jet_cct_meta_handler', true, 'post' ) ) {
            // Handle *_post_meta
			if ( apply_filters( 'jet_cct_meta_handler_get', true, 'post' ) ) {
				$no_conflict[ 'filter' ] = array(
					array( 'get_post_metadata', array( jet_cctInit::$meta, 'get_post_meta' ), 10, 4 ),
				);
			}

			if ( !jet_cct_tableless() ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'add_post_metadata', array( jet_cctInit::$meta, 'add_post_meta' ), 10, 5 ),
					array( 'update_post_metadata', array( jet_cctInit::$meta, 'update_post_meta' ), 10, 5 ),
					array( 'delete_post_metadata', array( jet_cctInit::$meta, 'delete_post_meta' ), 10, 5 )
				) );
			}
		}

        $no_conflict[ 'action' ] = array(
            array( 'transition_post_status', array( jet_cctInit::$meta, 'save_post_detect_new' ), 10, 3 ),
            array( 'save_post', array( jet_cctInit::$meta, 'save_post' ), 10, 2 )
        );
    }
    elseif ( 'taxonomy' == $object_type ) {
		if ( apply_filters( 'jet_cct_meta_handler', true, 'term' ) ) {
            // Handle *_term_meta
			if ( apply_filters( 'jet_cct_meta_handler_get', true, 'term' ) ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'get_term_metadata', array( jet_cctInit::$meta, 'get_term_meta' ), 10, 4 )
				) );
			}

			if ( !jet_cct_tableless() ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'add_term_metadata', array( jet_cctInit::$meta, 'add_term_meta' ), 10, 5 ),
					array( 'update_term_metadata', array( jet_cctInit::$meta, 'update_term_meta' ), 10, 5 ),
					array( 'delete_term_metadata', array( jet_cctInit::$meta, 'delete_term_meta' ), 10, 5 )
				) );
			}

			$no_conflict[ 'action' ] = array(
				array( 'edited_term', array( jet_cctInit::$meta, 'save_taxonomy' ), 10, 3 ),
				array( 'create_term', array( jet_cctInit::$meta, 'save_taxonomy' ), 10, 3 )
			);
		}
    }
    elseif ( 'media' == $object_type ) {
		$no_conflict[ 'filter' ] = array(
			array( 'wp_update_attachment_metadata', array( jet_cctInit::$meta, 'save_media' ), 10, 2 )
		);

		if ( apply_filters( 'jet_cct_meta_handler', true, 'post' ) ) {
            // Handle *_post_meta
			if ( apply_filters( 'jet_cct_meta_handler_get', true, 'post' ) ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'get_post_metadata', array( jet_cctInit::$meta, 'get_post_meta' ), 10, 4 )
				) );
			}

			if ( !jet_cct_tableless() ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'add_post_metadata', array( jet_cctInit::$meta, 'add_post_meta' ), 10, 5 ),
					array( 'update_post_metadata', array( jet_cctInit::$meta, 'update_post_meta' ), 10, 5 ),
					array( 'delete_post_metadata', array( jet_cctInit::$meta, 'delete_post_meta' ), 10, 5 )
				) );
			}

			$no_conflict[ 'action' ] = array();
		}
    }
    elseif ( 'user' == $object_type ) {
		if ( apply_filters( 'jet_cct_meta_handler', true, 'user' ) ) {
            // Handle *_term_meta
			if ( apply_filters( 'jet_cct_meta_handler_get', true, 'user' ) ) {
				$no_conflict[ 'filter' ] = array(
					array( 'get_user_metadata', array( jet_cctInit::$meta, 'get_user_meta' ), 10, 4 ),
				);
			}

			if ( !jet_cct_tableless() ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'add_user_metadata', array( jet_cctInit::$meta, 'add_user_meta' ), 10, 5 ),
					array( 'update_user_metadata', array( jet_cctInit::$meta, 'update_user_meta' ), 10, 5 ),
					array( 'delete_user_metadata', array( jet_cctInit::$meta, 'delete_user_meta' ), 10, 5 )
				) );
			}
		}

        $no_conflict[ 'action' ] = array(
            array( 'user_register', array( jet_cctInit::$meta, 'save_user' ) ),
            array( 'profile_update', array( jet_cctInit::$meta, 'save_user' ), 10, 2 )
        );
    }
    elseif ( 'comment' == $object_type ) {
		if ( apply_filters( 'jet_cct_meta_handler', true, 'comment' ) ) {
            // Handle *_term_meta
			if ( apply_filters( 'jet_cct_meta_handler_get', true, 'comment' ) ) {
				$no_conflict[ 'filter' ] = array(
					array( 'get_comment_metadata', array( jet_cctInit::$meta, 'get_comment_meta' ), 10, 4 ),
				);
			}

			if ( !jet_cct_tableless() ) {
				$no_conflict[ 'filter' ] = array_merge( $no_conflict[ 'filter' ], array(
					array( 'add_comment_metadata', array( jet_cctInit::$meta, 'add_comment_meta' ), 10, 5 ),
					array( 'update_comment_metadata', array( jet_cctInit::$meta, 'update_comment_meta' ), 10, 5 ),
					array( 'delete_comment_metadata', array( jet_cctInit::$meta, 'delete_comment_meta' ), 10, 5 )
				) );
			}
		}

        $no_conflict[ 'action' ] = array(
            array( 'pre_comment_approved', array( jet_cctInit::$meta, 'validate_comment' ), 10, 2 ),
            array( 'comment_post', array( jet_cctInit::$meta, 'save_comment' ) ),
            array( 'edit_comment', array( jet_cctInit::$meta, 'save_comment' ) )
        );
    }
    elseif ( 'settings' == $object_type ) {
        $no_conflict[ 'filter' ] = array();

        // @todo Better handle settings conflicts apart from each other
        /*if ( empty( $object ) ) {
            foreach ( jet_cctMeta::$settings as $setting_jet ) {
                foreach ( $setting_jet[ 'fields' ] as $option ) {
                    $no_conflict[ 'filter' ][] = array( 'pre_option_' . $setting_jet[ 'name' ] . '_' . $option[ 'name' ], array( jet_cctInit::$meta, 'get_option' ), 10, 1 );
                    $no_conflict[ 'filter' ][] = array( 'pre_update_option_' . $setting_jet[ 'name' ] . '_' . $option[ 'name' ], array( jet_cctInit::$meta, 'update_option' ), 10, 2 );
                }
            }
        }
        elseif ( isset( jet_cctMeta::$settings[ $object ] ) ) {
            foreach ( jet_cctMeta::$settings[ $object ][ 'fields' ] as $option ) {
                $no_conflict[ 'filter' ][] = array( 'pre_option_' . $object . '_' . $option[ 'name' ], array( jet_cctInit::$meta, 'get_option' ), 10, 1 );
                $no_conflict[ 'filter' ][] = array( 'pre_update_option_' . $object . '_' . $option[ 'name' ], array( jet_cctInit::$meta, 'update_option' ), 10, 2 );
            }
        }*/
    }

    $conflicted = false;

    foreach ( $no_conflict as $action_filter => $conflicts ) {
        foreach ( $conflicts as $k => $args ) {
            if ( call_user_func_array( 'has_' . $action_filter, array_slice( $args, 0, 2 ) ) ) {
                call_user_func_array( 'remove_' . $action_filter, array_slice( $args, 0, 3 ) );

                $conflicted = true;
            }
            else
                unset( $no_conflict[ $action_filter ][ $k ] );
        }
    }

    if ( $conflicted ) {
        jet_cctInit::$no_conflict[ $object_type ] = $no_conflict;

        return true;
    }

    return false;
}

/**
 * Turn on actions after running code during jet_cct_conflict
 *
 * @param string $object_type
 *
 * @return bool
 *
 * @since 2.0
 */
function jet_cct_no_conflict_off ( $object_type = 'post' ) {
    if ( 'post_type' == $object_type )
        $object_type = 'post';
    elseif ( 'term' == $object_type )
        $object_type = 'taxonomy';

    if ( ! class_exists( 'jet_cctInit' ) )
        jet_cct_init();

    if ( empty( jet_cctInit::$no_conflict ) || !isset( jet_cctInit::$no_conflict[ $object_type ] ) || empty( jet_cctInit::$no_conflict[ $object_type ] ) )
        return false;

    if ( !is_object( jet_cctInit::$meta ) )
        return false;

    $no_conflict = jet_cctInit::$no_conflict[ $object_type ];

    $conflicted = false;

    foreach ( $no_conflict as $action_filter => $conflicts ) {
        foreach ( $conflicts as $args ) {
            if ( !call_user_func_array( 'has_' . $action_filter, array_slice( $args, 0, 2 ) ) ) {
                call_user_func_array( 'add_' . $action_filter, $args );

                $conflicted = true;
            }
        }
    }

    if ( $conflicted ) {
        unset( jet_cctInit::$no_conflict[ $object_type ] );

        return true;
    }

    return false;
}

/**
 * Safely start a new session (without whitescreening on certain hosts,
 * which have no session path or isn't writable)
 *
 * @since 2.3.10
 */
function jet_cct_session_start() {

	$save_path = session_save_path();

	// Check if headers were sent
	if ( false !== headers_sent() ) {
		return false;
	}
	// Allow for bypassing jet_cct session autostarting
	elseif ( defined( 'jet_cct_SESSION_AUTO_START' ) && !jet_cct_SESSION_AUTO_START ) {
		return false;
	}
	// Allow for non-file based sessions, like Memcache
	elseif ( 0 === strpos( $save_path, 'tcp://' ) ) {
		// This is OK, but we don't want to check if file_exists on next statement
	}
	// Check if session path exists and can be written to, avoiding PHP fatal errors
	elseif ( empty( $save_path ) || !@file_exists( $save_path ) || !is_writable( $save_path ) ) {
		return false;
	}
	// Check if session ID is already set
	elseif ( '' != session_id() ) {
		return false;
	}

	// Start session
	@session_start();

	return true;

}
