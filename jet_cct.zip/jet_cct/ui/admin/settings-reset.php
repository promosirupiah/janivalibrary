<?php
    global $jet_cct_init;

	if ( isset( $_POST[ '_wpnonce' ] ) && false !== wp_verify_nonce( $_POST[ '_wpnonce' ], 'jet_cct-settings' ) ) {
		if ( isset( $_POST[ 'jet_cct_cleanup_1x' ] ) ) {
			jet_cct_upgrade( '2.0.0' )->cleanup();

			jet_cct_redirect( jet_cct_query_arg( array( 'jet_cct_cleanup_1x_success' => 1 ), array( 'page', 'tab' ) ) );
		} elseif ( isset( $_POST[ 'jet_cct_reset' ] ) ) {
			$jet_cct_init->reset();
			$jet_cct_init->setup();

			jet_cct_redirect( jet_cct_query_arg( array( 'jet_cct_reset_success' => 1 ), array( 'page', 'tab' ) ) );
		} elseif ( isset( $_POST[ 'jet_cct_reset_deactivate' ] ) ) {
			$jet_cct_init->reset();

			deactivate_plugins( jet_cct_DIR . 'init.php' );

			jet_cct_redirect( 'index.php' );
		} elseif ( 1 == jet_cct_v( 'jet_cct_reset_success' ) ) {
			jet_cct_message( 'jet_cct 2.x settings and data have been reset.' );
		} elseif ( 1 == jet_cct_v( 'jet_cct_cleanup_1x_success' ) ) {
			jet_cct_message( 'jet_cct 1.x data has been deleted.' );
		}
	}

	// Monday Mode
	$monday_mode = jet_cct_v( 'jet_cct_monday_mode', 'get', 0, true );

	if ( jet_cct_var( 'jet_cct_reset_weekend', 'post', jet_cct_var( 'jet_cct_reset_weekend', 'get', 0, null, true ), null, true ) ) {
        if ( $monday_mode ) {
            $html = '<br /><br /><iframe width="480" height="360" src="http://www.youtube-nocookie.com/embed/QH2-TGUlwu4?autoplay=1" frameborder="0" allowfullscreen></iframe>';
            jet_cct_message( 'The weekend has been reset and you have been sent back to Friday night. Unfortunately due to a tear in the fabric of time, you slipped back to Monday. We took video of the whole process and you can see it below..' . $html );
        }
        else {
            $html = '<br /><br /><iframe width="480" height="360" src="http://www.youtube-nocookie.com/embed/xhrBDcQq2DM?autoplay=1" frameborder="0" allowfullscreen></iframe>';
            jet_cct_message( 'Oops, sorry! You can only reset the weekend on a Monday before the end of the work day. Somebody call the Waaambulance!' . $html, 'error' );
        }
    }
    
    //Please Note:
    $please_note = __( 'Please Note:' );

    $old_version = get_option( 'jet_cct_version' );

    if ( !empty( $old_version ) ) {
?>
    <h3><?php _e( 'Delete jet_cct 1.x data', 'jet_cct' ); ?></h3>

    <p><?php _e( 'This will delete all of your jet_cct 1.x data, it\'s only recommended if you\'ve verified your data has been properly migrated into jet_cct 2.x.', 'jet_cct' ); ?></p>

    <p class="submit">
        <?php $confirm = __( "Are you sure you want to do this?\n\nThis is a good time to make sure you have a backup. We are deleting all of the data that surrounds 1.x, resetting it to a clean first install.", 'jet_cct' ); ?>
        <input type="submit" class="button button-primary" name="jet_cct_cleanup_1x" value=" <?php esc_attr_e( 'Delete jet_cct 1.x settings and data', 'jet_cct' ); ?> " onclick="return confirm( '<?php echo esc_js( $confirm ); ?>' );" />
    </p>

    <hr />

    <h3><?php _e( 'Reset jet_cct 2.x', 'jet_cct' ); ?></h3>

    <p><?php _e( 'This does not delete any jet_cct 1.x data, it simply resets the jet_cct 2.x settings, removes all of it\'s data, and performs a fresh install.', 'jet_cct' ); ?></p>
    <p><?php echo sprintf('<strong>%1$s</strong>', $please_note ) . __('This does not remove any items from any Post Types, Taxonomies, Media, Users, or Comments data you have added/modified. Any custom fields stored using the table storage component, content in Advanced Content Types, and relationships between posts will be lost.', 'jet_cct' ); ?></p>

    <p class="submit">
        <?php $confirm = __( "Are you sure you want to do this?\n\nThis is a good time to make sure you have a backup. We are deleting all of the data that surrounds 2.x, resetting it to a clean first install.", 'jet_cct' ); ?>
        <input type="submit" class="button button-primary" name="jet_cct_reset" value=" <?php esc_attr_e( 'Reset jet_cct 2.x settings and data', 'jet_cct' ); ?> " onclick="return confirm( '<?php echo esc_js( $confirm ); ?>' );" />
    </p>

    <hr />

    <h3><?php _e( 'Deactivate and Delete jet_cct 2.x data', 'jet_cct' ); ?></h3>

    <p><?php _e( 'This will delete jet_cct 2.x settings, data, and deactivate itself once done. Your database will be as if jet_cct 2.x never existed.', 'jet_cct' ); ?></p>
    <p><?php _e( '<strong>Please Note:</strong> This does not remove any items from any Post Types, Taxonomies, Media, Users, or Comments data you have added/modified.', 'jet_cct' ); ?></p>

    <p class="submit">
        <?php $confirm = __( "Are you sure you want to do this?\n\nThis is a good time to make sure you have a backup. We are deleting all of the data that surrounds 2.x with no turning back.", 'jet_cct' ); ?>
        <input type="submit" class="button button-primary" name="jet_cct_reset_deactivate" value=" <?php esc_attr_e( 'Deactivate and Delete jet_cct 2.x data', 'jet_cct' ); ?> " onclick="return confirm( '<?php echo esc_js( $confirm ); ?>' );" />
    </p>
<?php
    }
    else {
?>
    <h3><?php _e( 'Reset jet_cct', 'jet_cct' ); ?></h3>

    <p><?php _e( 'This will reset jet_cct settings, removes all of it\'s data, and performs a fresh install.', 'jet_cct' ); ?></p>
    <p><?php _e( '<strong>Please Note:</strong> This does not remove any items from any Post Types, Taxonomies, Media, Users, or Comments data you have added/modified.', 'jet_cct' ); ?></p>

    <p class="submit">
        <?php $confirm = __( "Are you sure you want to do this?\n\nThis is a good time to make sure you have a backup. We are deleting all of the data that surrounds jet_cct, resetting it to a clean, first install.", 'jet_cct' ); ?>
        <input type="submit" class="button button-primary" name="jet_cct_reset" value="<?php esc_attr_e( 'Reset jet_cct settings and data', 'jet_cct' ); ?> " onclick="return confirm( '<?php echo esc_js( $confirm ); ?>' );" />
    </p>

    <hr />

    <h3><?php _e( 'Deactivate and Delete jet_cct data', 'jet_cct' ); ?></h3>

    <p><?php _e( 'This will delete jet_cct settings, data, and deactivate itself once done. Your database will be as if jet_cct never existed.', 'jet_cct' ); ?></p>
    <p><?php _e( '<strong>Please Note:</strong> This does not remove any items from any Post Types, Taxonomies, Media, Users, or Comments data you have added/modified.', 'jet_cct' ); ?></p>

    <p class="submit">
        <?php $confirm = __( "Are you sure you want to do this?\n\nThis is a good time to make sure you have a backup. We are deleting all of the data that surrounds with no turning back.", 'jet_cct' ); ?>
        <input type="submit" class="button button-primary" name="jet_cct_reset_deactivate" value=" <?php esc_attr_e( 'Deactivate and Delete jet_cct data', 'jet_cct' ); ?> " onclick="return confirm( '<?php echo esc_js( $confirm ); ?>' );" />
    </p>
<?php
    }

    if ( $monday_mode ) {
?>
    <hr />

    <h3><?php _e( 'Reset Weekend', 'jet_cct' ); ?></h3>

    <p><?php _e( 'This feature has been exclusively built for jet_cct to help developers suffering from "Monday", and allows them to reset the weekend.', 'jet_cct' ); ?></p>
    <p><?php _e( "By resetting the weekend, you will be sent back to Friday night and the weekend you've just spent will be erased. You will retain all of your memories of the weekend, and be able to relive it in any way you wish.", 'jet_cct'); ?></p>

    <p class="submit">
        <?php $confirm = __( "Are you sure you want to Reset your Weekend?\n\nThere is no going back, you cannot reclaim anything you've gained throughout your weekend.\n\nYou are about to be groundhoggin' it", 'jet_cct' ); ?>
        <input type="submit" class="button button-primary" name="jet_cct_reset_weekend" value=" reset_weekend( '<?php echo esc_js( date_i18n( 'Y-m-d', strtotime( '-3 days' ) ) ); ?> 19:00:00' ); " onclick="return confirm( '<?php echo esc_js( $confirm ); ?>' );" />
    </p>
<?php
    }
?>
