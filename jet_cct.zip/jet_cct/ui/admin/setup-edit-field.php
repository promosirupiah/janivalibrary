<?php
    $field = array_merge( $field_settings[ 'field_defaults' ], $field );

    // Migrate pick object when saving
    if ( 'jet' == jet_cct_var( 'pick_object', $field ) ) {
        if ( isset( jet_cctMeta::$post_types[ $field[ 'pick_val' ] ] ) )
            $field[ 'pick_object' ] = 'post_type';
        elseif ( isset( jet_cctMeta::$taxonomies[ $field[ 'pick_val' ] ] ) )
            $field[ 'pick_object' ] = 'taxonomy';
        elseif ( 'user' == $field[ 'pick_val' ] && !empty( jet_cctMeta::$user ) ) {
            $field[ 'pick_object' ] = 'user';
            $field[ 'pick_val' ] = '';
        }
        elseif ( 'comment' == $field[ 'pick_val' ] && !empty( jet_cctMeta::$comment ) ) {
            $field[ 'pick_object' ] = 'comment';
            $field[ 'pick_val' ] = '';
        }
        elseif ( 'media' == $field[ 'pick_val' ] && !empty( jet_cctMeta::$media ) ) {
            $field[ 'pick_object' ] = 'media';
            $field[ 'pick_val' ] = '';
        }
    }

    $ignored_pick_objects = apply_filters( '', array( 'table' ) );

    if ( !in_array( jet_cct_var( 'pick_object', $field ), $ignored_pick_objects ) ) {
        // Set pick object
        $field[ 'pick_object' ] = trim( jet_cct_var( 'pick_object', $field ) . '-' . jet_cct_var( 'pick_val', $field ), '-' );
    }

    // Unset pick_val for the field to be used above
    if ( isset( $field[ 'pick_val' ] ) )
        unset( $field[ 'pick_val' ] );

    // Remove weight as we're going to allow reordering here
    unset( $field[ 'weight' ] );

    // Remove options, we don't need it in the JSON
    unset( $field[ 'options' ] );
    unset( $field[ 'table_info' ] );

    $data = array(
        'row' => $jet_cct_i
    );
?>
<tr id="row-<?php echo esc_attr( $jet_cct_i ); ?>" class="jet_cct-manage-row jet_cct-field-init jet_cct-field-<?php echo esc_attr( jet_cct_var( 'name', $field ) ) . ( '--1' === $jet_cct_i ? ' flexible-row' : ' jet_cct-submittable-fields' ); ?>" valign="top"<?php jet_cctForm::data( $data ); ?>>
    <th scope="row" class="check-field jet_cct-manage-sort">
        <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/handle.gif" alt="<?php esc_attr_e( 'Move', 'jet_cct' ); ?>" />
    </th>
    <td class="jet_cct-manage-row-label">
        <strong> <a class="jet_cct-manage-row-edit row-label" title="<?php esc_attr_e( 'Edit this field', 'jet_cct' ); ?>" href="#edit-field">
            <?php echo esc_html( jet_cct_var_raw( 'label', $field ) ); ?>
        </a> <abbr title="required" class="required<?php echo esc_attr( 1 == jet_cct_var_raw( 'required', $field ) ? '' : ' hidden' ); ?>">*</abbr> </strong>

        <?php
        if ( '__1' != jet_cct_var( 'id', $field ) ) {
            ?>
            <span class="jet_cct-manage-row-more">
                        [id: <?php echo esc_html( jet_cct_var( 'id', $field ) ); ?>]
                    </span>
            <?php
        }
        ?>

        <div class="row-actions">
                    <span class="edit">
                        <a title="<?php esc_attr_e( 'Edit this field', 'jet_cct' ); ?>" class="jet_cct-manage-row-edit" href="#edit-field"><?php _e( 'Edit', 'jet_cct' ); ?></a> |
                    </span>
                    <span class="duplicate">
                        <a title="<?php esc_attr_e( 'Duplicate this field', 'jet_cct' ); ?>" class="jet_cct-manage-row-duplicate" href="#duplicate-field"><?php _e( 'Duplicate', 'jet_cct' ); ?></a> |
                    </span>
                    <span class="trash jet_cct-manage-row-delete">
                        <a class="submitdelete" title="<?php esc_attr_e( 'Delete this field', 'jet_cct' ); ?>" href="#delete-field"><?php _e( 'Delete', 'jet_cct' ); ?></a>
                    </span>
        </div>
        <div class="jet_cct-manage-row-wrapper" id="jet_cct-manage-field-<?php echo esc_attr( $jet_cct_i ); ?>">
            <input type="hidden" name="field_data_json[<?php echo esc_attr( $jet_cct_i ); ?>]" value="<?php echo esc_attr( ( version_compare( PHP_VERSION, '5.4.0', '>=' ) ? json_encode( $field, JSON_UNESCAPED_UNICODE ) : json_encode( $field ) ) ); ?>" class="field_data" />

            <div class="jet_cct-manage-field jet_cct-dependency">
                <input type="hidden" name="field_data[<?php echo esc_attr( $jet_cct_i ); ?>][id]" value="<?php echo esc_attr( jet_cct_var_raw( 'id', $field ) ); ?>" />
            <div>
        </div>
    </td>
    <td class="jet_cct-manage-row-name">
        <a title="Edit this field" class="jet_cct-manage-row-edit row-name" href="#edit-field"><?php echo esc_html( jet_cct_var_raw( 'name', $field ) ); ?></a>
    </td>
    <td class="jet_cct-manage-row-type">
        <?php
            $type = 'Unknown';

            if ( isset( $field_types[ jet_cct_var( 'type', $field ) ] ) )
                $type = $field_types[ jet_cct_var( 'type', $field ) ][ 'label' ];

            echo esc_html( $type ) . ' <span class="jet_cct-manage-row-more">[type: ' . jet_cct_var( 'type', $field ) . ']</span>';

            $pick_object = trim( jet_cct_var( 'pick_object', $field ) . '-' . jet_cct_var( 'pick_val', $field ), '-' );

            if ( 'pick' == jet_cct_var( 'type', $field ) && '' != jet_cct_var( 'pick_object', $field, '' ) ) {
                $pick_object_name = null;

                foreach ( $field_settings[ 'pick_object' ] as $object => $object_label ) {
                    if ( null !== $pick_object_name )
                        break;

                    if ( '-- Select --' == $object_label )
                        continue;

                    if ( is_array( $object_label ) ) {
                        foreach ( $object_label as $sub_object => $sub_object_label ) {
                            if ( $pick_object == $sub_object ) {
                                $ies = strlen( $object ) - 3;

                                if ( $ies === strpos( $object, 'ies' ) )
                                    $object = substr( $object, 0, $ies ) . 'y';

                                $object = rtrim( $object, 's' );

                                $pick_object_name = esc_html( $sub_object_label ) . ' <small>(' . esc_html( $object ) . ')</small>';

                                break;
                            }
                        }
                    }
                    elseif ( jet_cct_var( 'pick_object', $field ) == $object ) {
                        $pick_object_name = $object_label;

                        break;
                    }
                }

                if ( null === $pick_object_name ) {
                    $pick_object_name = ucwords( str_replace( array( '-', '_' ), ' ', jet_cct_var_raw( 'pick_object', $field ) ) );

                    if ( 0 < strlen( jet_cct_var_raw( 'pick_val', $field ) ) )
                        $pick_object_name = jet_cct_var_raw( 'pick_val', $field ) . ' (' . $pick_object_name . ')';
                }
        ?>
            <br /><span class="jet_cct-manage-field-type-desc">&rsaquo; <?php echo $pick_object_name; ?></span>
        <?php
            }
        ?>
    </td>
</tr>