<?php
$field = array_merge( $field_settings[ 'field_defaults' ], $field );

$pick_object = trim( jet_cct_var( 'pick_object', $field ) . '-' . jet_cct_var( 'pick_val', $field ), '-' );
?>
<tr id="row-<?php echo esc_attr( $jet_cct_i ); ?>" class="jet_cct-manage-row jet_cct-field-new jet_cct-field-<?php echo esc_attr( jet_cct_var( 'name', $field ) ) . ( '--1' === $jet_cct_i ? ' flexible-row' : ' jet_cct-submittable-fields' ); ?>" valign="top" data-row="<?php echo esc_attr( $jet_cct_i ); ?>">
    <th scope="row" class="check-field jet_cct-manage-sort">
        <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/handle.gif" alt="<?php esc_attr_e( 'Move', 'jet_cct' ); ?>" />
    </th>
    <td class="jet_cct-manage-row-label">
        <strong> <a class="jet_cct-manage-row-edit row-label" title="<?php esc_attr_e( 'Edit this field', 'jet_cct' ); ?>" href="#edit-field">
            <?php _e( 'New Field', 'jet_cct' ); ?>
        </a> <abbr title="required" class="required hidden">*</abbr> </strong>

        <div class="row-actions">
            <span class="edit">
                <a title="<?php esc_attr_e( 'Edit this field', 'jet_cct' ); ?>" class="jet_cct-manage-row-edit" href="#edit-field"><?php _e( 'Edit', 'jet_cct' ); ?></a> |
            </span>
            <span class="duplicate">
                <a title="<?php esc_attr_e( 'Duplicate this field', 'jet_cct' ); ?>" class="jet_cct-manage-row-duplicate" href="#duplicate-field"><?php _e( 'Duplicate', 'jet_cct' ); ?></a> |
            </span>
            <span class="trash jet_cct-manage-row-delete">
                <a class="submitdelete" title="<?php esc_attr_e( 'Delete this field', 'jet_cct' ); ?>" href="#delete-field"><?php _e( 'Delete', 'jet_cct' ); ?></a>
            </span>
        </div>
        <div class="jet_cct-manage-row-wrapper" id="jet_cct-manage-field-<?php echo esc_attr( $jet_cct_i ); ?>">
            <input type="hidden" name="field_data_json[<?php echo esc_attr( $jet_cct_i ); ?>]" value="" class="field_data" />

            <div class="jet_cct-manage-field jet_cct-dependency">
                <div class="jet_cct-tabbed">
                    <ul class="jet_cct-tabs">
                        <?php
                            $default = 'basic';

                            foreach ( $field_tabs as $tab => $label ) {
                                if ( !in_array( $tab, array( 'basic', 'additional-field', 'advanced' ) ) && ( !isset( $field_tab_options[ $tab ] ) || empty( $field_tab_options[ $tab ] ) ) )
                                    continue;

                                $class = $extra_classes = '';

                                $tab = sanitize_title( $tab );

                                if ( $tab == $default )
                                    $class = ' selected';

                                if ( 'additional-field' == $tab )
                                    $extra_classes = ' jet_cct-excludes-on jet_cct-excludes-on-field-data-type jet_cct-excludes-on-field-data-type-' . implode( ' jet_cct-excludes-on-field-data-type-', $no_additional );
                        ?>
                            <li class="jet_cct-tab<?php echo esc_attr( $extra_classes ); ?>">
                                <a href="#jet_cct-<?php echo esc_attr( $tab ); ?>-options-<?php echo esc_attr( $jet_cct_i ); ?>" class="jet_cct-tab-link<?php echo esc_attr( $class ); ?>">
                                    <?php echo $label; ?>
                                </a>
                            </li>
                        <?php
                            }
                        ?>
                    </ul>

                    <div class="jet_cct-tab-group">
                        <div id="jet_cct-basic-options-<?php echo esc_attr( $jet_cct_i ); ?>" class="jet_cct-tab jet_cct-basic-options">
                            <div class="jet_cct-field-option">
                                <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][label]', __( 'Label', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
                                <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][label]', jet_cct_var_raw( 'label', $field, '' ), 'text', array( 'class' => 'jet_cct-validate jet_cct-validate-required' ) ); ?>
                            </div>
                            <div class="jet_cct-field-option">
                                <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][name]', __( 'Name', 'jet_cct' ), __( 'You will use this name to programatically reference this field throughout WordPress', 'jet_cct' ) ); ?>
                                <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][name]', jet_cct_var_raw( 'name', $field, '' ), 'db', array( 'attributes' => array( 'maxlength' => 50, 'data-sluggable' => 'field_data[' . $jet_cct_i . '][label]' ), 'class' => 'jet_cct-validate jet_cct-validate-required jet_cct-slugged-lower' ) ); ?>
                            </div>
                            <div class="jet_cct-field-option">
                                <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][description]', __( 'Description', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
                                <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][description]', jet_cct_var_raw( 'description', $field, '' ), 'text' ); ?>
                            </div>
                            <div class="jet_cct-field-option">
                                <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][type]', __( 'Field Type', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
                                <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][type]', jet_cct_var_raw( 'type', $field, '' ), 'pick', array( 'data' => jet_cct_var_raw( 'field_types_select', $field_settings ), 'class' => 'jet_cct-dependent-toggle' ) ); ?>
                            </div>
                            <div class="jet_cct-field-option-container jet_cct-depends-on jet_cct-depends-on-field-data-type jet_cct-depends-on-field-data-type-pick">
                                <div class="jet_cct-field-option">
                                    <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][pick_object]', __( 'Related To', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
                                    <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][pick_object]', $pick_object, 'pick', array( 'required' => true, 'data' => jet_cct_var_raw( 'pick_object', $field_settings ), 'class' => 'jet_cct-dependent-toggle' ) ); ?>
                                </div>
                                <div class="jet_cct-field-option jet_cct-depends-on jet_cct-depends-on-field-data-pick-object jet_cct-depends-on-field-data-pick-object-custom-simple">
                                    <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][pick_custom]', __( 'Custom Defined Options', 'jet_cct' ), __( 'One option per line, use <em>value|Label</em> for separate values and labels', 'jet_cct' ) ); ?>
                                    <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][pick_custom]', jet_cct_var_raw( 'pick_custom', $field, '' ), 'paragraph' ); ?>
                                </div>
                                <div class="jet_cct-field-option jet_cct-depends-on jet_cct-depends-on-field-data-pick-object jet_cct-depends-on-field-data-pick-object-table">
                                    <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][pick_table]', __( 'Related Table', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
                                    <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][pick_table]', jet_cct_var_raw( 'pick_table', $field, '' ), 'pick', array( 'required' => true, 'data' => jet_cct_var_raw( 'pick_table', $field_settings ) ) ); ?>
                                </div>
                                <div class="jet_cct-field-option jet_cct-depends-on jet_cct-depends-on-field-data-pick-object jet_cct-depends-on-field-data-pick-object-<?php echo esc_attr( str_replace( '_', '-', implode( ' jet_cct-depends-on-field-data-pick-object-', $bidirectional_objects ) ) ); ?>" data-dependency-trigger="jet_cct_sister_field">
                                    <?php echo jet_cctForm::label( 'field_data[' . $jet_cct_i . '][sister_id]', __( 'Bi-directional Field', 'jet_cct' ), __( 'Bi-directional fields will update their related field for any item you select. This feature is only available for two relationships between two jet_cct.<br /><br />For example, when you update a Parent jet item to relate to a Child item, when you go to edit that Child item you will see the Parent jet item selected.', 'jet_cct' ) ); ?>

                                    <div class="jet_cct-sister-field">
                                        <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][sister_id]', jet_cct_var_raw( 'sister_id', $field, '' ), 'text' ); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="jet_cct-field-option-group">
                                <p class="jet_cct-field-option-group-label">
                                    <?php _e( 'Options', 'jet_cct' ); ?>
                                </p>

                                <div class="jet_cct-pick-values jet_cct-pick-checkbox">
                                    <ul>
                                        <li>
                                            <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][required]', jet_cct_var_raw( 'required', $field, 0 ), 'boolean', array( 'class' => 'jet_cct-dependent-toggle', 'boolean_yes_label' => __( 'Required', 'jet_cct' ), 'help' => __( 'help', 'jet_cct' ) ) ); ?>
                                        </li>
                                        <?php
                                            if ( 'table' == $jet[ 'storage' ] ) {
                                        ?>
                                            <li class="jet_cct-excludes-on jet_cct-excludes-on-field-data-type jet_cct-excludes-on-field-data-type-pick jet_cct-excludes-on-field-data-type-file jet_cct-excludes-on-field-data-type-boolean jet_cct-excludes-on-field-data-type-date jet_cct-excludes-on-field-data-type-datetime jet_cct-excludes-on-field-data-type-time">
                                                <?php echo jet_cctForm::field( 'field_data[' . $jet_cct_i . '][unique]', jet_cct_var_raw( 'unique', $field, 0 ), 'boolean', array( 'class' => 'jet_cct-dependent-toggle', 'boolean_yes_label' => __( 'Unique', 'jet_cct' ), 'help' => __( 'help', 'jet_cct' ) ) ); ?>
                                            </li>
                                        <?php
                                            }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <?php
                            foreach ( $field_tabs as $tab => $tab_label ) {
                                $tab = sanitize_title( $tab );

                                if ( 'basic' == $tab || !isset( $field_tab_options[ $tab ] ) || empty( $field_tab_options[ $tab ] ) )
                                    continue;
                        ?>
                            <div id="jet_cct-<?php echo esc_attr( $tab ); ?>-options-<?php echo esc_attr( $jet_cct_i ); ?>" class="jet_cct-tab jet_cct-<?php echo esc_attr( $tab ); ?>-options">
                                <?php
                                    $field_tab_fields = $field_tab_options[ $tab ];

                                    if ( 'additional-field' == $tab ) {
                                        foreach ( $field_tab_fields as $field_type => $field_type_fields ) {
                                            $first_field = current( $field_type_fields );
                                        ?>
                                            <div class="jet_cct-depends-on jet_cct-depends-on-field-data-type jet_cct-depends-on-field-data-type-<?php echo esc_attr( sanitize_title( $field_type ) ); ?>">
                                        <?php
                                            if ( !isset( $first_field[ 'name' ] ) && !isset( $first_field[ 'label' ] ) ) {
                                                foreach ( $field_type_fields as $group => $group_fields ) {
                                                ?>
                                                    <h4><?php echo $group; ?></h4>
                                                <?php
                                                    $field_options = jet_cctForm::fields_setup( $group_fields );

                                                    include jet_cct_DIR . 'ui/admin/field-option.php';
                                                }
                                            }
                                            else {
                                                $field_options = jet_cctForm::fields_setup( $field_type_fields );

                                                include jet_cct_DIR . 'ui/admin/field-option.php';
                                            }
                                        ?>
                                            </div>
                                        <?php
                                        }
                                    }
                                    else {
                                        $first_field = current( $field_tab_fields );

                                        if ( !isset( $first_field[ 'name' ] ) && !isset( $first_field[ 'label' ] ) ) {
                                            foreach ( $field_tab_fields as $group => $group_fields ) {
                                            ?>
                                                <h4><?php echo $group; ?></h4>
                                            <?php
                                                $field_options = jet_cctForm::fields_setup( $group_fields );

                                                include jet_cct_DIR . 'ui/admin/field-option.php';
                                            }
                                        }
                                        else {
                                            $field_options = jet_cctForm::fields_setup( $field_tab_fields );

                                            include jet_cct_DIR . 'ui/admin/field-option.php';
                                        }
                                    }
                                ?>
                            </div>
                        <?php
                            }
                        ?>
                    </div>

                    <div class="jet_cct-manage-row-actions submitbox">
                        <div class="jet_cct-manage-row-delete">
                            <a class="submitdelete deletion" href="#delete-field"><?php _e( 'Delete Field', 'jet_cct' ); ?></a>
                        </div>
                        <p class="jet_cct-manage-row-save">
                            <a class="jet_cct-manage-row-cancel" href="#cancel-edit-field"><?php _e( 'Cancel', 'jet_cct' ); ?></a> &nbsp;&nbsp; <a href="#save-field" class="button-primary jet_cct-button-update"><?php _e( 'Update Field', 'jet_cct' ); ?></a><a href="#save-field" class="button-primary jet_cct-button-add"><?php _e( 'Add Field', 'jet_cct' ); ?></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </td>
    <td class="jet_cct-manage-row-name">
        <a title="Edit this field" class="jet_cct-manage-row-edit row-name" href="#edit-field"><?php echo esc_html( jet_cct_var_raw( 'name', $field ) ); ?></a>
    </td>
    <td class="jet_cct-manage-row-type">
        <?php
        $type = 'Unknown';

        if ( isset( $field_types[ jet_cct_var( 'type', $field ) ] ) )
            $type = $field_types[ jet_cct_var( 'type', $field ) ][ 'label' ];

        echo esc_html( $type ) . ' <span class="jet_cct-manage-row-more">[type: ' . jet_cct_var( 'type', $field ) . ']</span>';

        if ( 'pick' == jet_cct_var( 'type', $field ) && '' != jet_cct_var( 'pick_object', $field, '' ) ) {
            $pick_object_name = null;

            foreach ( $field_settings[ 'pick_object' ] as $object => $object_label ) {
                if ( null !== $pick_object_name )
                    break;

                if ( '-- Select --' == $object_label )
                    continue;

                if ( is_array( $object_label ) ) {
                    foreach ( $object_label as $sub_object => $sub_object_label ) {
                        if ( $pick_object == $sub_object ) {
                            $object = rtrim( $object, 's' );

                            if ( false !== strpos( $object, 'ies' ) )
                                $object = str_replace( 'ies', 'y', $object );

                            $pick_object_name = esc_html( $sub_object_label ) . ' <small>(' . esc_html( $object ) . ')</small>';

                            break;
                        }
                    }
                }
                elseif ( jet_cct_var( 'pick_object', $field ) == $object ) {
                    $pick_object_name = $object_label;

                    break;
                }
            }

            if ( null === $pick_object_name ) {
                $pick_object_name = ucwords( str_replace( array( '-', '_' ), ' ', jet_cct_var_raw( 'pick_object', $field ) ) );

                if ( 0 < strlen( jet_cct_var_raw( 'pick_val', $field ) ) )
                    $pick_object_name = jet_cct_var_raw( 'pick_val', $field ) . ' (' . $pick_object_name . ')';
            }
            ?>
            <br /><span class="jet_cct-manage-field-type-desc">&rsaquo; <?php echo $pick_object_name; ?></span>
            <?php
        }
        ?>
    </td>
</tr>
