<?php
global $jet_cct_i;

$api = jet_cct_api();

$jet = $api->load_jet( array( 'id' => $obj->id ) );

if ( 'taxonomy' == $jet[ 'type' ] && 'none' == $jet[ 'storage' ] && 1 == jet_cct_var( 'enable_extra_fields', 'get' ) ) {
    $api->save_jet( array( 'id' => $obj->id, 'storage' => 'table' ) );

    $jet = $api->load_jet( array( 'id' => $obj->id ) );

    unset( $_GET[ 'enable_extra_fields' ] );

    jet_cct_message( __( 'Extra fields were successfully enabled for this Custom Taxonomy.', 'jet_cct' ) );
}

$field_types = jet_cctForm::field_types();

$field_types_select = array();

foreach ( $field_types as $type => $field_type_data ) {
    /**
     * @var $field_type jet_cctField
     */
    $field_type = jet_cctForm::field_loader( $type, $field_type_data[ 'file' ] );

    $field_type_vars = get_class_vars( get_class( $field_type ) );

    if ( !isset( $field_type_vars[ 'jet_types' ] ) )
        $field_type_vars[ 'jet_types' ] = true;

    // Only show supported field types
    if ( true !== $field_type_vars[ 'jet_types' ] ) {
        if ( empty( $field_type_vars[ 'jet_types' ] ) )
            continue;
        elseif ( is_array( $field_type_vars[ 'jet_types' ] ) && !in_array( jet_cct_var( 'type', $jet ), $field_type_vars[ 'jet_types' ] ) )
            continue;
        elseif ( !is_array( $field_type_vars[ 'jet_types' ] ) && jet_cct_var( 'type', $jet ) != $field_type_vars[ 'jet_types' ] )
            continue;
    }

    if ( !empty( jet_cctForm::$field_group ) ) {
        if ( !isset( $field_types_select[ jet_cctForm::$field_group ] ) )
            $field_types_select[ jet_cctForm::$field_group ] = array();

        $field_types_select[ jet_cctForm::$field_group ][ $type ] = $field_type_data[ 'label' ];
    }
    else {
        if ( !isset( $field_types_select[ __( 'Other', 'jet_cct' ) ] ) )
            $field_types_select[ __( 'Other', 'jet_cct' ) ] = array();

        $field_types_select[ __( 'Other', 'jet_cct' ) ][ $type ] = $field_type_data[ 'label' ];
    }
}

$field_defaults = array(
    'name' => 'new_field',
    'label' => 'New Field',
    'description' => '',
    'type' => 'text',
    'pick_object' => '',
    'sister_id' => '',
    'required' => 0,
    'unique' => 0,
);

$pick_object = jet_cctForm::field_method( 'pick', 'related_objects', true );

$tableless_field_types = jet_cctForm::tableless_field_types();
$simple_tableless_objects = jet_cctForm::field_method( 'pick', 'simple_objects' );
$bidirectional_objects = jet_cctForm::field_method( 'pick', 'bidirectional_objects' );

foreach ( $jet[ 'options' ] as $_option => $_value ) {
    $jet[ $_option ] = $_value;
}

foreach ( $jet[ 'fields' ] as $_field => $_data ) {
    $_data[ 'options' ] = (array) $_data[ 'options' ];

    foreach ( $_data[ 'options' ] as $_option => $_value ) {
        $jet[ 'fields' ][ $_field ][ $_option ] = $_value;
    }
}

$field_defaults = apply_filters( 'jet_cct_field_defaults', apply_filters( 'jet_cct_field_defaults_' . $jet[ 'name' ], $field_defaults, $jet ) );

$pick_table = jet_cct_transient_get( 'jet_cct_tables' );

if ( empty( $pick_table ) ) {
    $pick_table = array(
        '' => __( '-- Select Table --', 'jet_cct' )
    );

    global $wpdb;

    $tables = $wpdb->get_results( "SHOW TABLES", ARRAY_N );

    if ( !empty( $tables ) ) {
        foreach ( $tables as $table ) {
            $pick_table[ $table[ 0 ] ] = $table[ 0 ];
        }
    }

    jet_cct_transient_set( 'jet_cct_tables', $pick_table );
}

$field_settings = array(
    'field_types_select' => $field_types_select,
    'field_defaults' => $field_defaults,
    'pick_object' => $pick_object,
    'pick_table' => $pick_table,
    'sister_id' => array( '' => __( 'No Related Fields Found', 'jet_cct' ) )
);

$field_settings = apply_filters( 'jet_cct_field_settings', apply_filters( 'jet_cct_field_settings_' . $jet[ 'name' ], $field_settings, $jet ) );

$jet[ 'fields' ] = apply_filters( 'jet_cct_fields_edit', apply_filters( 'jet_cct_fields_edit_' . $jet[ 'name' ], $jet[ 'fields' ], $jet ) );

global $wpdb;
$max_length_name = 64;
$max_length_name -= 10; // Allow for WP Multisite or prefix changes in the future
$max_length_name -= strlen( $wpdb->prefix . 'jet_cct_' );

$tabs = jet_cctInit::$admin->admin_setup_edit_tabs( $jet );
$tab_options = jet_cctInit::$admin->admin_setup_edit_options( $jet );

$field_tabs = jet_cctInit::$admin->admin_setup_edit_field_tabs( $jet );
$field_tab_options = jet_cctInit::$admin->admin_setup_edit_field_options( $jet );

$no_additional = array();

foreach ( $field_tab_options[ 'additional-field' ] as $field_type => $field_type_fields ) {
    if ( empty( $field_type_fields ) )
        $no_additional[] = $field_type;
}
?>
<div class="wrap jet_cct-admin">
<div id="icon-jet_cct" class="icon32"><br /></div>
<form action="" method="post" class="jet_cct-submittable jet_cct-nav-tabbed">
<div class="jet_cct-submittable-fields">
    <input type="hidden" name="action" value="jet_cct_admin" />
    <input type="hidden" name="method" value="save_jet" />
    <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'jet_cct-save_jet' ) ); ?>" />
    <input type="hidden" name="id" value="<?php echo esc_attr( (int) $jet[ 'id' ] ); ?>" />
    <input type="hidden" name="old_name" value="<?php echo esc_attr( $jet[ 'name' ] ); ?>" />

    <h2>
        Edit jet:
        <?php
            if ( ( in_array( $jet[ 'type' ], array( 'post_type', 'taxonomy' ) ) && !empty( $jet[ 'object' ] ) ) || in_array( $jet[ 'type' ], array( 'media', 'user', 'comment' ) ) ) {
        ?>
            <em><?php echo esc_html( $jet[ 'name' ] ); ?></em>
        <?php
        }
            else {
        ?>
            <span class="jet_cct-sluggable">
                <span class="jet_cct-slug">
                    <em><?php echo esc_html( $jet[ 'name' ] ); ?></em>
                    <input type="button" class="edit-slug-button button" value="Edit" />
                </span>
                <span class="jet_cct-slug-edit">
                    <?php echo jet_cctForm::field( 'name', jet_cct_var_raw( 'name', $jet ), 'db', array(
                    'attributes' => array(
                        'maxlength' => $max_length_name,
                        'size' => 25
                    ),
                    'class' => 'jet_cct-validate jet_cct-validate-required'
                ) ); ?>
                    <input type="button" class="save-button button" value="OK" /> <a class="cancel" href="#cancel-edit">Cancel</a>
                </span>
            </span>
        <?php
            }
        ?>
    </h2>

    <?php
        if ( !empty( $tabs ) ) {
    ?>

        <h2 class="nav-tab-wrapper jet_cct-nav-tabs">
            <?php
                $default = sanitize_title( jet_cct_var( 'tab', 'get', 'manage-fields', null, true ) );

                if ( !isset( $tabs[ $default ] ) ) {
                    $tab_keys = array_keys( $tabs );

                    $default = current( $tab_keys );
                }

                foreach ( $tabs as $tab => $label ) {
                    if ( !in_array( $tab, array( 'manage-fields', 'labels', 'extra-fields' ) ) && ( !isset( $tab_options[ $tab ] ) || empty( $tab_options[ $tab ] ) ) )
                        continue;

                    $class = '';

                    $tab = sanitize_title( $tab );

                    if ( $tab == $default )
                        $class = ' nav-tab-active';
            ?>
                <a href="#jet_cct-<?php echo esc_attr( $tab ); ?>" class="nav-tab<?php echo esc_attr( $class ); ?> jet_cct-nav-tab-link">
                    <?php echo $label; ?>
                </a>
            <?php
                }
            ?>
        </h2>
    <?php
        }
    ?>
</div>

<?php
if ( isset( $_GET[ 'do' ] ) ) {
    $action = __( 'saved', 'jet_cct' );

    if ( 'create' == jet_cct_var( 'do', 'get', 'save' ) )
        $action = __( 'created', 'jet_cct' );
    elseif ( 'duplicate' == jet_cct_var( 'do', 'get', 'save' ) )
        $action = __( 'duplicated', 'jet_cct' );

    $message = sprintf( __( '<strong>Success!</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );

    echo $obj->message( $message );
}
?>

<div id="poststuff">
<img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />
<!-- /inner-sidebar -->
<div id="post-body" class="meta-box-holder columns-2">
<div id="post-body-content" class="jet_cct-nav-tab-group">

<?php
    if ( isset( $tabs[ 'manage-fields' ] ) ) {
?>
<div id="jet_cct-manage-fields" class="jet_cct-nav-tab">
    <p class="jet_cct-manage-row-add jet_cct-float-right">
        <a href="#add-field" class="button-primary"><?php _e( 'Add Field', 'jet_cct' ); ?></a>
    </p>

    <?php
        if ( !empty( $tabs ) )
            echo '<h2>' . __( 'Manage Fields', 'jet_cct' ) . '</h2>';

		do_action( 'jet_cct_admin_ui_setup_edit_fields', $jet, $obj );
    ?>

    <!-- jet_cct table -->
    <table class="widefat fixed pages" cellspacing="0">
        <thead>
            <tr>
                <th scope="col" id="cb" class="manage-column field-cb check-column">
                    <span>&nbsp;</span>
                </th>
                <th scope="col" id="label" class="manage-column field-label">
                    <span>Label<?php jet_cct_help( __( "<h6>Label</h6>The label is the descriptive name to identify the jet field.", 'jet_cct' ) ); ?></span>
                </th>
                <th scope="col" id="machine-name" class="manage-column field-machine-name">
                    <span>Name<?php jet_cct_help( __( "<h6>Name</h6>The name attribute is what is used to identify and access the jet field programatically.", 'jet_cct' ) ); ?></span>
                </th>
                <th scope="col" id="field-type" class="manage-column field-field-type">
                    <span>Field Type<?php jet_cct_help( __( "<h6>Field Types</h6>Field types are used to determine what kind of data will be stored in the jet.  They can range from, dates, text, files, etc.", 'jet_cct' ) ); ?></span>
                </th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th scope="col" class="manage-column field-cb check-column">
                    <span>&nbsp;</span>
                </th>
                <th scope="col" class="manage-column field-label">
                    <span>Label<?php jet_cct_help( __( "<h6>Label</h6>The label is the descriptive name to identify the jet field.", 'jet_cct' ) ); ?></span>
                </th>
                <th scope="col" class="manage-column field-machine-name">
                    <span>Name<?php jet_cct_help( __( "<h6>Name</h6>The name attribute is what is used to identify and access the jet field programatically.", 'jet_cct' ) ); ?></span>
                </th>
                <th scope="col" class="manage-column field-field-type">
                    <span>Field Type<?php jet_cct_help( __( "<h6>Field Types</h6>Field types are used to determine what kind of data will be stored in the jet.  They can range from, dates, text, files, etc.", 'jet_cct' ) ); ?></span>
                </th>
            </tr>
        </tfoot>
        <tbody class="jet_cct-manage-list">
            <?php
                // Empty Row for Flexible functionality
                $jet_cct_i = '--1';

                $field = array(
                    'id' => '__1',
                    'name' => '',
                    'label' => '',
                    'type' => 'text'
                );

                include jet_cct_DIR . 'ui/admin/setup-edit-field-fluid.php';

                $jet_cct_i = 1;

                foreach ( $jet[ 'fields' ] as $field ) {
                    include jet_cct_DIR . 'ui/admin/setup-edit-field.php';

                    $jet_cct_i++;
                }
            ?>
            <tr class="no-items<?php echo esc_attr( 1 < $jet_cct_i ? ' hidden' : '' ); ?>">
                <td class="colspanchange" colspan="4">No fields have been added yet</td>
            </tr>
        </tbody>
    </table>
    <!-- /jet_cct table -->
    <p class="jet_cct-manage-row-add">
        <a href="#add-field" class="button-primary"><?php _e( 'Add Field', 'jet_cct' ); ?></a>
    </p>
</div>
<?php
    }

    $jet_cct_tab_form = true;

    if ( isset( $tabs[ 'labels' ] ) ) {
?>
<div id="jet_cct-labels" class="jet_cct-nav-tab jet_cct-manage-field jet_cct-dependency jet_cct-submittable-fields">
<?php
if ( strlen( jet_cct_var( 'object', $jet ) ) < 1 && 'settings' != jet_cct_var( 'type', $jet ) ) {
    ?>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label', __( 'Label', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label', jet_cct_var_raw( 'label', $jet ), 'text', array( 'text_max_length' => 30 ) ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_singular', __( 'Singular Label', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_singular', jet_cct_var_raw( 'label_singular', $jet, jet_cct_var_raw( 'label', $jet, ucwords( str_replace( '_', ' ', jet_cct_var_raw( 'name', $jet ) ) ) ) ), 'text', array( 'text_max_length' => 30 ) ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_add_new', __( 'Add New', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_add_new', jet_cct_var_raw( 'label_add_new', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_add_new_item', __( 'Add New <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_add_new_item', jet_cct_var_raw( 'label_add_new_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_new_item', __( 'New <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_new_item', jet_cct_var_raw( 'label_new_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_edit', __( 'Edit', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_edit', jet_cct_var_raw( 'label_edit', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_edit_item', __( 'Edit <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_edit_item', jet_cct_var_raw( 'label_edit_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_update_item', __( 'Update <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_update_item', jet_cct_var_raw( 'label_update_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_view', __( 'View', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_view', jet_cct_var_raw( 'label_view', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_view_item', __( 'View <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_view_item', jet_cct_var_raw( 'label_view_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_all_items', __( 'All <span class="jet_cct-slugged" data-sluggable="label">Items</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_all_items', jet_cct_var_raw( 'label_all_items', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_search_items', __( 'Search <span class="jet_cct-slugged" data-sluggable="label">Items</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_search_items', jet_cct_var_raw( 'label_search_items', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_not_found', __( 'Not Found', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_not_found', jet_cct_var_raw( 'label_not_found', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_feature_image', __( 'Featured Image', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_feature_image', jet_cct_var_raw( 'label_feature_image', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_set_featured_image', __( 'Set featured image', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_set_featured_image', jet_cct_var_raw( 'label_set_featured_image', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_remove_featured_image', __( 'Remove featured image', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_remove_featured_image', jet_cct_var_raw( 'label_remove_featured_image', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_use_featured_image', __( 'Use as featured image', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_use_featured_image', jet_cct_var_raw( 'label_use_featured_image', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_archives', __( '<span class="jet_cct-slugged" data-sluggable="label_singular">Item</span> Archives', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_archives', jet_cct_var_raw( 'label_archives', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_insert_into_item', __( 'Insert into <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_insert_into_item', jet_cct_var_raw( 'label_insert_into_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_uploaded_to_this_item', __( 'Uploaded to this <span class="jet_cct-slugged" data-sluggable="label_singular">Item</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_uploaded_to_this_item', jet_cct_var_raw( 'label_uploaded_to_this_item', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_filter_items_list', __( 'Filter <span class="jet_cct-slugged" data-sluggable="label">Items</span> lists', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_filter_items_list', jet_cct_var_raw( 'label_filter_items_list', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_items_list_navigation', __( '<span class="jet_cct-slugged" data-sluggable="label">Items</span> list navigation', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_items_list_navigation', jet_cct_var_raw( 'label_items_list_navigation', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_items_list', __( '<span class="jet_cct-slugged" data-sluggable="label">Items</span> list', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_items_list', jet_cct_var_raw( 'label_items_list', $jet ), 'text' ); ?>
    </div>
    <?php
    if ( in_array( jet_cct_var( 'type', $jet ), array( 'post_type', 'jet' ) ) ) {
        ?>
        <div class="jet_cct-field-option">
            <?php echo jet_cctForm::label( 'label_not_found_in_trash', __( 'Not Found in Trash', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
            <?php echo jet_cctForm::field( 'label_not_found_in_trash', jet_cct_var_raw( 'label_not_found_in_trash', $jet ), 'text' ); ?>
        </div>
        <?php
    }
    ?>

    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_popular_items', __( 'Popular <span class="jet_cct-slugged" data-sluggable="label">Items</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_popular_items', jet_cct_var_raw( 'label_popular_items', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_separate_items_with_commas', __( 'Separate <span class="jet_cct-slugged-lower" data-sluggable="label">items</span> with commas', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_separate_items_with_commas', jet_cct_var_raw( 'label_separate_items_with_commas', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_add_or_remove_items', __( 'Add or remove <span class="jet_cct-slugged-lower" data-sluggable="label">items</span>', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_add_or_remove_items', jet_cct_var_raw( 'label_add_or_remove_items', $jet ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label_choose_from_the_most_used', __( 'Choose from the most used', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label_choose_from_the_most_used', jet_cct_var_raw( 'label_choose_from_the_most_used', $jet ), 'text' ); ?>
    </div>
    <?php
}
elseif ( 'settings' == jet_cct_var( 'type', $jet ) ) {
    ?>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'label', __( 'Page Title', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'label', jet_cct_var_raw( 'label', $jet ), 'text', array( 'text_max_length' => 30 ) ); ?>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'menu_name', __( 'Menu Name', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'menu_name', jet_cct_var_raw( 'menu_name', $jet, jet_cct_var_raw( 'label', $jet, ucwords( str_replace( '_', ' ', jet_cct_var_raw( 'name', $jet ) ) ) ) ), 'text', array( 'text_max_length' => 30 ) ); ?>
    </div>
    <?php
}
?>
</div>
<?php
}

if ( isset( $tabs[ 'advanced' ] ) ) {
?>
<div id="jet_cct-advanced" class="jet_cct-nav-tab jet_cct-manage-field jet_cct-dependency jet_cct-submittable-fields">
<?php
if ( 'post_type' == jet_cct_var( 'type', $jet ) && strlen( jet_cct_var( 'object', $jet ) ) < 1 ) {
    $fields = $tab_options[ 'advanced' ];
    $field_options = jet_cctForm::fields_setup( $fields );
    $field = $jet;

    include jet_cct_DIR . 'ui/admin/field-option.php';
    ?>
    <div class="jet_cct-field-option-group">
        <p class="jet_cct-field-option-group-label">
            <?php _e( 'Supports', 'jet_cct' ); ?>
        </p>

        <div class="jet_cct-pick-values jet_cct-pick-checkbox">
            <ul>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_title', jet_cct_var_raw( 'supports_title', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Title', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_editor', jet_cct_var_raw( 'supports_editor', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Editor', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_author', jet_cct_var_raw( 'supports_author', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Author', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_thumbnail', jet_cct_var_raw( 'supports_thumbnail', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Featured Image', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_excerpt', jet_cct_var_raw( 'supports_excerpt', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Excerpt', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_trackbacks', jet_cct_var_raw( 'supports_trackbacks', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Trackbacks', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_custom_fields', jet_cct_var_raw( 'supports_custom_fields', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Custom Fields', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_comments', jet_cct_var_raw( 'supports_comments', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Comments', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_revisions', jet_cct_var_raw( 'supports_revisions', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Revisions', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_page_attributes', jet_cct_var_raw( 'supports_page_attributes', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Page Attributes', 'jet_cct' ) ) ); ?>
                    </div>
                </li>
                <li>
                    <div class="jet_cct-field jet_cct-boolean">
                        <?php echo jet_cctForm::field( 'supports_post_formats', jet_cct_var_raw( 'supports_post_formats', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Post Formats', 'jet_cct' ) ) ); ?>
                    </div>
                </li>

                <?php if ( function_exists( 'genesis' ) ) { ?>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'supports_genesis_seo', jet_cct_var_raw( 'supports_genesis_seo', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Genesis: SEO', 'jet_cct' ) ) ); ?>
                        </div>
                    </li>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'supports_genesis_layouts', jet_cct_var_raw( 'supports_genesis_layouts', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Genesis: Layouts', 'jet_cct' ) ) ); ?>
                        </div>
                    </li>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'supports_genesis_simple_sidebars', jet_cct_var_raw( 'supports_genesis_simple_sidebars', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Genesis: Simple Sidebars', 'jet_cct' ) ) ); ?>
                        </div>
                    </li>
                <?php } ?>

				<?php if ( defined( 'YARPP_VERSION' ) ) { ?>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'supports_yarpp_support', jet_cct_var_raw( 'supports_yarpp_support', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'YARPP Support', 'jet_cct' ) ) ); ?>
                        </div>
                    </li>
				<?php } ?>

				<?php if ( class_exists( 'Jetpack' ) ) { ?>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'supports_jetpack_publicize', jet_cct_var_raw( 'supports_jetpack_publicize', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Jetpack Publicize Support', 'jet_cct' ) ) ); ?>
                        </div>
                    </li>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'supports_jetpack_markdown', jet_cct_var_raw( 'supports_jetpack_markdown', $jet, false ), 'boolean', array( 'boolean_yes_label' => __( 'Jetpack Markdown Support', 'jet_cct' ) ) ); ?>
                        </div>
                    </li>
				<?php } ?>
            </ul>
        </div>
    </div>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'supports_custom', __( 'Advanced Supports', 'jet_cct' ), __( 'Comma-separated list of custom "supports" values to pass to register_post_type.', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'supports_custom', jet_cct_var_raw( 'supports_custom', $jet, '' ), 'text' ); ?>
    </div>
    <div class="jet_cct-field-option-group">
        <p class="jet_cct-field-option-group-label">
            <?php _e( 'Built-in Taxonomies', 'jet_cct' ); ?>
        </p>

        <div class="jet_cct-pick-values jet_cct-pick-checkbox">
            <ul>
                <?php
                foreach ( (array) $field_settings[ 'pick_object' ][ __( 'Taxonomies', 'jet_cct' ) ] as $taxonomy => $label ) {
                    $taxonomy = jet_cct_str_replace( 'taxonomy-', '', $taxonomy, 1 );
                    ?>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'built_in_taxonomies_' . $taxonomy, jet_cct_var_raw( 'built_in_taxonomies_' . $taxonomy, $jet, false ), 'boolean', array( 'boolean_yes_label' => $label . ' <small>(' . $taxonomy . ')</small>' ) ); ?>
                        </div>
                    </li>
                    <?php
                }
                ?>
            </ul>
        </div>
    </div>
    <?php
}
elseif ( 'taxonomy' == jet_cct_v_sanitized( 'type', $jet ) && strlen( jet_cct_v_sanitized( 'object', $jet ) ) < 1 ) {
    $fields = $tab_options[ 'advanced' ];
    $field_options = jet_cctForm::fields_setup( $fields );
    $field = $jet;

    include jet_cct_DIR . 'ui/admin/field-option.php';
    ?>
    <div class="jet_cct-field-option-group">
        <p class="jet_cct-field-option-group-label">
            <?php _e( 'Associated Post Types', 'jet_cct' ); ?>
        </p>

        <div class="jet_cct-pick-values jet_cct-pick-checkbox">
            <ul>
                <?php
                    foreach ( (array) $field_settings[ 'pick_object' ][ __( 'Post Types', 'jet_cct' ) ] as $post_type => $label ) {
                        $post_type = jet_cct_str_replace( 'post_type-', '', $post_type, 1 );
                        $label = str_replace( array( '(', ')' ), array( '<small>(', ')</small>' ), $label );
                ?>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'built_in_post_types_' . $post_type, jet_cct_var_raw( 'built_in_post_types_' . $post_type, $jet, false ), 'boolean', array( 'boolean_yes_label' => $label ) ); ?>
                        </div>
                    </li>
                <?php
                    }
                ?>

                <?php
                    if ( jet_cct_version_check( 'wp', '3.5' ) ) {
                ?>
                    <li>
                        <div class="jet_cct-field jet_cct-boolean">
                            <?php echo jet_cctForm::field( 'built_in_post_types_attachment', jet_cct_var_raw( 'built_in_post_types_attachment', $jet, false ), 'boolean', array( 'boolean_yes_label' => 'Media <small>(attachment)</small>' ) ); ?>
                        </div>
                    </li>
                <?php
                    }
                ?>
            </ul>
        </div>
    </div>
    <?php
}
elseif ( 'jet' == jet_cct_var( 'type', $jet ) ) {
?>
    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'detail_url', __( 'Detail Page URL', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'detail_url', jet_cct_var_raw( 'detail_url', $jet ), 'text' ); ?>
    </div>

    <?php
        $index_fields = array( 'id' => 'ID' );

        foreach ( $jet[ 'fields' ] as $field ) {
            if ( !in_array( $field[ 'type' ], $tableless_field_types ) )
                $index_fields[ $field[ 'name' ] ] = $field[ 'label' ];
        }
    ?>

    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'jet_index', __( 'Title Field', 'jet_cct' ), __( 'If you delete the "name" field, we need to specify the field to use as your primary title field. This field will serve as an index of your content. Most commonly this field represents the name of a person, place, thing, or a summary field.', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'jet_index', jet_cct_var_raw( 'jet_index', $jet, 'name' ), 'pick', array( 'data' => $index_fields ) ); ?>
    </div>

    <div class="jet_cct-field-option">
        <?php echo jet_cctForm::label( 'hierarchical', __( 'Hierarchical', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'hierarchical', (int) jet_cct_var_raw( 'hierarchical', $jet, 0 ), 'boolean', array( 'dependency' => true, 'boolean_yes_label' => '' ) ); ?>
    </div>

    <?php
        $hierarchical_fields = array();

        foreach ( $jet[ 'fields' ] as $field ) {
            if ( 'pick' == $field[ 'type' ] && 'jet' == jet_cct_var( 'pick_object', $field ) && $jet[ 'name' ] == jet_cct_var( 'pick_val', $field ) && 'single' == jet_cct_var( 'pick_format_type', $field[ 'options' ] ) )
                $hierarchical_fields[ $field[ 'name' ] ] = $field[ 'label' ];
        }

        if ( empty( $hierarchical_fields ) )
            $hierarchical_fields = array( '' => __( 'No Hierarchical Fields found', 'jet_cct' ) );
    ?>

    <div class="jet_cct-field-option jet_cct-depends-on jet_cct-depends-on-hierarchical">
        <?php echo jet_cctForm::label( 'jet_parent', __( 'Hierarchical Field', 'jet_cct' ), __( 'help', 'jet_cct' ) ); ?>
        <?php echo jet_cctForm::field( 'jet_parent', jet_cct_var_raw( 'jet_parent', $jet, 'name' ), 'pick', array( 'data' => $hierarchical_fields ) ); ?>
    </div>

    <?php
    if ( class_exists( 'jet_cct_Helpers' ) ) {
    ?>

    <div class="jet_cct-field-option">
        <?php
            $pre_save_helpers = array( '' => '-- Select --' );

            $helpers = $api->load_helpers( array( 'options' => array( 'helper_type' => 'pre_save' ) ) );

            foreach ( $helpers as $helper ) {
                $pre_save_helpers[ $helper[ 'name' ] ] = $helper[ 'name' ];
            }

            echo jet_cctForm::label( 'pre_save_helpers', __( 'Pre-Save Helper(s)', 'jet_cct' ), __( 'help', 'jet_cct' ) );
            echo jet_cctForm::field( 'pre_save_helpers', jet_cct_var_raw( 'pre_save_helpers', $jet ), 'pick', array( 'data' => $pre_save_helpers ) );
        ?>
    </div>
    <div class="jet_cct-field-option">
        <?php
            $post_save_helpers = array( '' => '-- Select --' );

            $helpers = $api->load_helpers( array( 'options' => array( 'helper_type' => 'post_save' ) ) );

            foreach ( $helpers as $helper ) {
                $post_save_helpers[ $helper[ 'name' ] ] = $helper[ 'name' ];
            }

            echo jet_cctForm::label( 'post_save_helpers', __( 'Post-Save Helper(s)', 'jet_cct' ), __( 'help', 'jet_cct' ) );
            echo jet_cctForm::field( 'post_save_helpers', jet_cct_var_raw( 'post_save_helpers', $jet ), 'pick', array( 'data' => $post_save_helpers ) );
        ?>
    </div>
    <div class="jet_cct-field-option">
        <?php
            $pre_delete_helpers = array( '' => '-- Select --' );

            $helpers = $api->load_helpers( array( 'options' => array( 'helper_type' => 'pre_delete' ) ) );

            foreach ( $helpers as $helper ) {
                $pre_delete_helpers[ $helper[ 'name' ] ] = $helper[ 'name' ];
            }

            echo jet_cctForm::label( 'pre_delete_helpers', __( 'Pre-Delete Helper(s)', 'jet_cct' ), __( 'help', 'jet_cct' ) );
            echo jet_cctForm::field( 'pre_delete_helpers', jet_cct_var_raw( 'pre_delete_helpers', $jet ), 'pick', array( 'data' => $pre_delete_helpers ) );
        ?>
    </div>
    <div class="jet_cct-field-option">
        <?php
            $post_delete_helpers = array( '' => '-- Select --' );

            $helpers = $api->load_helpers( array( 'options' => array( 'helper_type' => 'post_delete' ) ) );

            foreach ( $helpers as $helper ) {
                $post_delete_helpers[ $helper[ 'name' ] ] = $helper[ 'name' ];
            }

            echo jet_cctForm::label( 'post_delete_helpers', __( 'Post-Delete Helper(s)', 'jet_cct' ), __( 'help', 'jet_cct' ) );
            echo jet_cctForm::field( 'post_delete_helpers', jet_cct_var_raw( 'post_delete_helpers', $jet ), 'pick', array( 'data' => $post_delete_helpers ) );
        ?>
    </div>
    <?php
    }
}
?>
</div>
<?php
}

foreach ( $tabs as $tab => $tab_label ) {
    $tab = sanitize_title( $tab );

    if ( in_array( $tab, array( 'manage-fields', 'labels', 'advanced', 'extra-fields' ) ) || !isset( $tab_options[ $tab ] ) || empty( $tab_options[ $tab ] ) )
        continue;
?>
    <div id="jet_cct-<?php echo esc_attr( $tab ); ?>" class="jet_cct-nav-tab jet_cct-manage-field jet_cct-dependency jet_cct-submittable-fields">
        <?php
            $fields = $tab_options[ $tab ];
            $field_options = jet_cctForm::fields_setup( $fields );
            $field = $jet;

            include jet_cct_DIR . 'ui/admin/field-option.php';
        ?>
    </div>
<?php
}

if ( isset( $tabs[ 'extra-fields' ] ) ) {
?>
<div id="jet_cct-extra-fields" class="jet_cct-nav-tab">
    <p><?php _e( 'Taxonomies do not support extra fields natively, but jet_cct can add this feature for you easily. Table based storage will operate in a way where each field you create for your content type becomes a field in a table.', 'jet_cct' ); ?></p>

    <p><?php echo sprintf( __( 'Enabling extra fields for this taxonomy will add a custom table into your database as <em>%s</em>.', 'jet_cct' ), $wpdb->prefix . 'jet_cct_' . jet_cct_var( 'name', $jet ) ); ?></p>

    <p><a href="http://jet_cct.io/docs/comparisons/compare-storage-types/" target="_blank"><?php _e( 'Find out more', 'jet_cct' ); ?> &raquo;</a></p>

    <p class="submit">
        <a href="<?php echo esc_url( jet_cct_query_arg( array( 'enable_extra_fields' => 1 ) ) ); ?>" class="button-primary"><?php _e( 'Enable Extra Fields', 'jet_cct' ); ?></a>
    </p>
</div>
<?php
}
?>
</div>
<!-- /#post-body-content -->

<div id="postbox-container-1" class="postbox-container jet_cct_floatmenu">
    <div id="side-info-field" class="inner-sidebar">
        <div id="side-sortables">
            <div id="submitdiv" class="postbox jet_cct-no-toggle">
                <h3><span>Manage <small>(<a href="<?php echo esc_url( jet_cct_query_arg( array( 'action' . $obj->num => 'manage', 'id' . $obj->num => '' ) ) ); ?>">&laquo; <?php _e( 'Back to Manage', 'jet_cct' ); ?></a>)
                </small></span></h3>
                <div class="inside">
                    <div class="submitbox" id="submitpost">
                        <div id="major-publishing-actions">
                            <div id="delete-action">
                                <a href="<?php echo esc_url( jet_cct_query_arg( array( 'action' . $obj->num => 'delete', '_wpnonce' => wp_create_nonce( 'jet_cct-ui-action-delete' ) ) ) ); ?>" class="submitdelete deletion jet_cct-confirm" data-confirm="<?php _e( 'Are you sure you want to delete this jet? All fields and data will be removed.', 'jet_cct' ); ?>"> <?php _e( 'Delete', 'jet_cct' ); ?> jet </a>
                            </div>
                            <div id="publishing-action">
                                <img class="waiting" src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ); ?>" alt="" />
                                <button class="button-primary" type="submit">Save jet</button>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /#submitdiv -->
        </div>
    </div>
</div>
</div>
<!-- /#post-body -->
</div>
<!-- /poststuff -->
</form>
</div>
<script type="text/javascript">
    <?php
    $jet_cct_field_types = array();

    foreach ( $field_types as $field_type => $field_type_data ) {
        $jet_cct_field_types[] = "'" . esc_js( $field_type ) . "' : '" . esc_js( $field_type_data[ 'label' ] ) . "'";
    }

    $jet_cct_pick_objects = array();

    $pick_object_singular = array(
        __( 'jet_cct', 'jet_cct' ) => __( 'jet', 'jet_cct' ),
        __( 'Post Types', 'jet_cct' ) => __( 'Post Type', 'jet_cct' ),
        __( 'Taxonomies', 'jet_cct' ) => __( 'Taxonomy', 'jet_cct' )
    );

    foreach ( $field_settings[ 'pick_object' ] as $object => $object_label ) {
        if ( is_array( $object_label ) ) {
            if ( isset( $pick_object_singular[ $object ] ) )
                $object = ' <small>(' . esc_js( $pick_object_singular[ $object ] ) . ')</small>';
            else
                $object = '';

            foreach ( $object_label as $sub_object => $sub_object_label ) {
                $jet_cct_pick_objects[] = "'" . esc_js( $sub_object ) . "' : '" . esc_js( $sub_object_label ) . $object . "'";
            }
        }
        elseif ( '-- Select --' != $object_label )
            $jet_cct_pick_objects[] = "'" . esc_js( $object ) . "' : '" . esc_js( $object_label ) . "'";
    }
    ?>
    var jet_cct_field_types = {
    <?php echo implode( ",\n        ", $jet_cct_field_types ); ?>
    };
    var jet_cct_pick_objects = {
    <?php echo implode( ",\n        ", $jet_cct_pick_objects ); ?>
    };

    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'sluggable' );
        $( document ).jet_cct( 'sortable' );
        $( document ).jet_cct( 'collapsible', $( 'tbody.jet_cct-manage-list tr.flexible-row div.jet_cct-manage-field' ) );
        $( document ).jet_cct( 'toggled' );
        $( document ).jet_cct( 'tabbed' );
        $( document ).jet_cct( 'nav_tabbed' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'flexible', $( 'tbody.jet_cct-manage-list tr.flexible-row' ) );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'exit_confirm' );
    } );

    var jet_cct_admin_submit_callback = function ( id ) {
        id = parseInt( id );
        var thank_you = '<?php echo jet_cct_slash( jet_cct_query_arg( array( 'do' => 'save' ) ) ); ?>';

        document.location = thank_you.replace( 'X_ID_X', id );
    }

    var jet_cct_sister_field_going = {

    };

    var jet_cct_sister_field = function ( $el ) {
        var id = $el.closest( 'tr.jet_cct-manage-row' ).data( 'row' );

        if ( 'undefined' != typeof jet_cct_sister_field_going[ id + '_' + $el.prop( 'id' ) ] && true == jet_cct_sister_field_going[ id + '_' + $el.prop( 'id' ) ] )
            return;

        jet_cct_sister_field_going[ id + '_' + $el.prop( 'id' ) ] = true;

        var default_select = '<?php echo str_replace( array( "\n", "\r" ), ' ', jet_cctForm::field( 'field_data[--1][sister_id]', '', 'pick', array( 'data' => jet_cct_var_raw( 'sister_id', $field_settings ) ) ) ); ?>';
        default_select = default_select.replace( /\-\-1/g, id );

        var related_jet_name = jQuery( '#jet_cct-form-ui-field-data-' + id + '-pick-object' ).val();

        if ( 0 != related_jet_name.indexOf( 'jet-' ) && 0 != related_jet_name.indexOf( 'post_type-' ) && 0 != related_jet_name.indexOf( 'taxonomy-' ) && 0 != related_jet_name.indexOf( 'user' ) && 0 != related_jet_name.indexOf( 'media' ) && 0 != related_jet_name.indexOf( 'comment' ) ) {
            jet_cct_sister_field_going[ id + '_' + $el.prop( 'id' ) ] = false;

            return;
        }

        var selected_value = jQuery( '#jet_cct-form-ui-field-data-' + id + '-sister-id' ).val();

        var select_container = default_select.match( /<select[^<]*>/g );

        $el.find( '.jet_cct-sister-field' ).html( select_container + '<option value=""><?php esc_attr_e( 'Loading available fields..', 'jet_cct' ); ?></option></select>' );

        postdata = {
            action : 'jet_cct_admin',
            method : 'load_sister_fields',
            _wpnonce : '<?php echo esc_js( wp_create_nonce( 'jet_cct-load_sister_fields' ) ); ?>',
            jet : '<?php echo esc_js( jet_cct_v( 'name', $jet ) ); ?>',
            related_jet : related_jet_name
        };

        jQuery.ajax( {
            type : 'POST',
            dataType : 'html',
            url : ajaxurl + '?jet_cct_ajax=1',
            cache : false,
            data : postdata,
            success : function ( d ) {
                if ( -1 == d.indexOf( '<e>' ) && -1 == d.indexOf('</e>') && -1 != d && '[]' != d ) {
                    var json = d.match( /{.*}$/ );

                    if ( null !== json && 0 < json.length )
                        json = jQuery.parseJSON( json[ 0 ] );
                    else
                        json = {};

                    var select_container = default_select.match( /<select[^<]*>/g );

                    if ( 'object' != typeof json || ! jQuery.isEmptyObject( json ) ) {
                        if ( 'object' != typeof json ) {
                            if ( window.console ) console.log( d );
                            if ( window.console ) console.log( json );

                            select_container += '<option value=""><?php esc_attr_e( 'There was a server error with your AJAX request.', 'jet_cct' ); ?></option>';
                        }

                        select_container += '<option value=""><?php esc_attr_e( '-- Select Related Field --', 'jet_cct' ); ?></option>';

                        for ( var field_id in json ) {
                            var field_name = json[field_id];

                            select_container += '<option value="' + field_id + '">' + field_name + '</option>';
                        }

                        select_container += '</select>';

                        $el.find( '.jet_cct-sister-field' ).html( select_container );

                        jQuery( '#jet_cct-form-ui-field-data-' + id + '-sister-id' ).val( selected_value );
                    }
                    else {
                        // None found
                        $el.find( '.jet_cct-sister-field' ).html( default_select );
                    }
                }
                else {
                    // None found
                    $el.find( '.jet_cct-sister-field' ).html( default_select );
                }

                jet_cct_sister_field_going[ id + '_' + $el.prop( 'id' ) ] = false;
            },
            error : function () {
                // None found
                $el.find( '.jet_cct-sister-field' ).html( default_select );

                jet_cct_sister_field_going[ id + '_' + $el.prop( 'id' ) ] = false;
            }
        } );
    }
</script>
