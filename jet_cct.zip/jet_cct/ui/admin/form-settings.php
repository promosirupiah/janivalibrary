<?php
wp_enqueue_script( 'jet_cct' );
wp_enqueue_style( 'jet_cct-form' );

if ( empty( $fields ) || !is_array( $fields ) )
    $fields = $obj->jet->fields;

if ( !isset( $duplicate ) )
    $duplicate = false;
else
    $duplicate = (boolean) $duplicate;

// unset fields
foreach ( $fields as $k => $field ) {
    if ( in_array( $field[ 'name' ], array( 'created', 'modified' ) ) )
        unset( $fields[ $k ] );
    elseif ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field[ 'options' ], $fields, $jet, $jet->id() ) ) {
        if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
            $fields[ $k ][ 'type' ] = 'hidden';
        else
            unset( $fields[ $k ] );
    }
    elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
        $fields[ $k ][ 'type' ] = 'hidden';
}

$submittable_fields = $fields;

foreach ( $submittable_fields as $k => $field ) {
    if ( jet_cct_var( 'readonly', $field, false ) )
        unset( $submittable_fields[ $k ] );
}

if ( !isset( $thank_you_alt ) )
    $thank_you_alt = $thank_you;

$uri_hash = wp_create_nonce( 'jet_cct_uri_' . $_SERVER[ 'REQUEST_URI' ] );
$field_hash = wp_create_nonce( 'jet_cct_fields_' . implode( ',', array_keys( $submittable_fields ) ) );

$uid = @session_id();

if ( is_user_logged_in() )
    $uid = 'user_' . get_current_user_id();

$nonce = wp_create_nonce( 'jet_cct_form_' . $jet->jet . '_' . $uid . '_' . ( $duplicate ? 0 : $jet->id() ) . '_' . $uri_hash . '_' . $field_hash );

if ( isset( $_POST[ '_jet_cct_nonce' ] ) ) {
    $action = __( 'saved', 'jet_cct' );

    try {
        $params = jet_cct_unslash( (array) $_POST );
        $id = $jet->api->process_form( $params, $jet, $submittable_fields, $thank_you );

        $message = sprintf( __( '<strong>Success!</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );
        $error = sprintf( __( '<strong>Error:</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );

        if ( 0 < $id )
            echo $obj->message( $message );
        else
            echo $obj->error( $error );
    }
    catch ( Exception $e ) {
        echo $obj->error( $e->getMessage() );
    }
}
elseif ( isset( $_GET[ 'do' ] ) ) {
    $action = __( 'saved', 'jet_cct' );

    $message = sprintf( __( '<strong>Success!</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );
    $error = sprintf( __( '<strong>Error:</strong> %s not %s.', 'jet_cct' ), $obj->item, $action );

    if ( 0 < $jet->id() )
        echo $obj->message( $message );
    else
        echo $obj->error( $error );
}

if ( !isset( $label ) )
    $label = __( 'Save', 'jet_cct' );

$do = 'save';
?>

<form action="" method="post" class="jet_cct-submittable jet_cct-form jet_cct-form-jet-<?php echo esc_attr( $jet->jet ); ?>">
    <div class="jet_cct-submittable-fields">
        <?php echo jet_cctForm::field( 'action', 'jet_cct_admin', 'hidden' ); ?>
        <?php echo jet_cctForm::field( 'method', 'process_form', 'hidden' ); ?>
        <?php echo jet_cctForm::field( 'do', $do, 'hidden' ); ?>
        <?php echo jet_cctForm::field( '_jet_cct_nonce', $nonce, 'hidden' ); ?>
        <?php echo jet_cctForm::field( '_jet_cct_jet', $jet->jet, 'hidden' ); ?>
        <?php echo jet_cctForm::field( '_jet_cct_id', $jet->id(), 'hidden' ); ?>
        <?php echo jet_cctForm::field( '_jet_cct_uri', $uri_hash, 'hidden' ); ?>
        <?php echo jet_cctForm::field( '_jet_cct_form', implode( ',', array_keys( $submittable_fields ) ), 'hidden' ); ?>
        <?php echo jet_cctForm::field( '_jet_cct_location', $_SERVER[ 'REQUEST_URI' ], 'hidden' ); ?>

        <?php
            foreach ( $fields as $field ) {
                if ( 'hidden' != $field[ 'type' ] )
                    continue;

                echo jet_cctForm::field( 'jet_cct_field_' . $field[ 'name' ], $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) ), 'hidden' );
            }
        ?>
        <table class="form-table jet_cct-manage-field">
            <?php
                $depends_on = false;

                foreach ( $fields as $field ) {
                    if ( 'hidden' == $field[ 'type' ] )
                        continue;

                    $depends = jet_cctForm::dependencies( $field );

                    if ( ( !empty( $depends_on ) || !empty( $depends ) ) && $depends_on != $depends ) {
                        if ( !empty( $depends_on ) ) {
            ?>
                </tbody>
            <?php
                        }

                        if ( !empty( $depends ) ) {
            ?>
                <tbody class="jet_cct-field-option-container <?php echo esc_attr( $depends ); ?>">
            <?php
                        }
                    }
            ?>
                <tr valign="top" class="jet_cct-field-option jet_cct-field <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>">
                    <th>
                        <?php echo jet_cctForm::label( 'jet_cct_field_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field ); ?>
                    </th>
                    <td>
                        <?php echo jet_cctForm::field( 'jet_cct_field_' . $field[ 'name' ], $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) ), $field[ 'type' ], $field, $jet, $jet->id() ); ?>
                        <?php echo jet_cctForm::comment( 'jet_cct_field_' . $field[ 'name' ], $field[ 'description' ], $field ); ?>
                    </td>
                </tr>
            <?php
                    if ( false !== $depends_on || !empty( $depends ) )
                        $depends_on = $depends;
                }

                if ( !empty( $depends_on ) ) {
            ?>
                </tbody>
            <?php
                }
            ?>
        </table>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_attr( $obj->label[ 'edit' ] ); ?>">
            <img class="waiting" src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ); ?>" alt="" />
        </p>
    </div>
</form>

<script type="text/javascript">
    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'exit_confirm' );
    } );

    var jet_cct_admin_submit_callback = function ( id ) {
        document.location = '<?php echo jet_cct_slash( jet_cct_query_arg( array( 'do' => $do ) ) ); ?>';
    }
</script>