<?php
wp_enqueue_style( 'jet_cct-form' );

/**
 * @var array $fields
 * @var jet_cctUI $obj
 */
?>

<div class="jet_cct-submittable-fields">
<div id="poststuff" class="metabox-holder has-right-sidebar"> <!-- class "has-right-sidebar" preps for a sidebar... always present? -->
<div id="side-info-column" class="inner-sidebar">
	<div id="side-sortables" class="meta-box-sortables ui-sortable">
		<!-- BEGIN PUBLISH DIV -->
		<div id="submitdiv" class="postbox">
			<div class="handlediv" title="Click to toggle"><br /></div>
			<h3 class="hndle"><span><?php _e( 'Manage', 'jet_cct' ); ?></span></h3>

			<div class="inside">
				<div class="submitbox" id="submitpost">
					<?php
						if ( isset( $jet->jet_data[ 'fields' ][ 'created' ] ) || isset( $jet->jet_data[ 'fields' ][ 'modified' ] ) || 0 < strlen( jet_cct_v_sanitized( 'detail_url', $jet->jet_data[ 'options' ] ) ) ) {
					?>
						<div id="minor-publishing">
							<?php
								if ( 0 < strlen( jet_cct_v_sanitized( 'detail_url', $jet->jet_data[ 'options' ] ) ) ) {
							?>
								<div id="minor-publishing-actions">
									<div id="preview-action">
										<a class="button" href="<?php echo esc_url( $jet->field( 'detail_url' ) ); ?>" target="_blank"><?php echo sprintf( __( 'View %s', 'jet_cct' ), $obj->item ); ?></a>
									</div>
									<div class="clear"></div>
								</div>
							<?php
								}

								if ( isset( $jet->jet_data[ 'fields' ][ 'created' ] ) || isset( $jet->jet_data[ 'fields' ][ 'modified' ] ) ) {
							?>
								<div id="misc-publishing-actions">
									<?php
										$datef = __( 'M j, Y @ G:i' );

										if ( isset( $jet->jet_data[ 'fields' ][ 'created' ] ) ) {
											$date = date_i18n( $datef, strtotime( $jet->field( 'created' ) ) );
										?>
										<div class="misc-pub-section curtime">
											<span id="timestamp"><?php _e( 'Created on', 'jet_cct' ); ?>: <b><?php echo $date; ?></b></span>
										</div>
									<?php
										}

										if ( isset( $jet->jet_data[ 'fields' ][ 'modified' ] ) && $jet->display( 'created' ) != $jet->display( 'modified' ) ) {
											$date = date_i18n( $datef, strtotime( $jet->field( 'modified' ) ) );
										?>
										<div class="misc-pub-section curtime">
											<span id="timestamp"><?php _e( 'Last Modified', 'jet_cct' ); ?>: <b><?php echo $date; ?></b></span>
										</div>
									<?php
										}
									?>
								</div>
							<?php
								}
							?>
						</div>
						<!-- /#minor-publishing -->
					<?php
						}
					?>

					<div id="major-publishing-actions">
						<?php
							if ( jet_cct_is_admin( array( 'jet_cct', 'jet_cct_delete_' . $jet->jet ) ) && !in_array( 'delete', $obj->actions_disabled ) && !in_array( 'delete', $obj->actions_hidden ) ) {
						?>
							<div id="delete-action">
								<a class="submitdelete deletion" href="<?php echo esc_url( jet_cct_query_arg( array( 'action' => 'delete' ) ) ); ?>" onclick="return confirm('You are about to permanently delete this item\n Choose \'Cancel\' to stop, \'OK\' to delete.');"><?php _e( 'Delete', 'jet_cct' ); ?></a>
							</div>
							<!-- /#delete-action -->
						<?php } ?>

						<div class="clear"></div>
					</div>
					<!-- /#major-publishing-actions -->
				</div>
				<!-- /#submitpost -->
			</div>
			<!-- /.inside -->
		</div>
		<!-- /#submitdiv --><!-- END PUBLISH DIV --><!-- TODO: minor column fields -->
		<?php
			if ( !in_array( 'navigate', $obj->actions_disabled ) && !in_array( 'navigate', $obj->actions_hidden ) ) {
				if ( !isset( $singular_label ) )
					$singular_label = ucwords( str_replace( '_', ' ', $jet->jet_data[ 'name' ] ) );

				$singular_label = jet_cct_v( 'label', $jet->jet_data[ 'options' ], $singular_label, true );
				$singular_label = jet_cct_v( 'label_singular', $jet->jet_data[ 'options' ], $singular_label, true );

				$prev = $jet->prev_id();
				$next = $jet->next_id();

				if ( 0 < $prev || 0 < $next ) {
		?>
			<div id="navigatediv" class="postbox">
				<div class="handlediv" title="Click to toggle"><br /></div>
				<h3 class="hndle"><span><?php _e( 'Navigate', 'jet_cct' ); ?></span></h3>

				<div class="inside">
					<div class="jet_cct-admin" id="navigatebox">
						<div id="navigation-actions">
							<?php
							if ( 0 < $prev ) {
								?>
								<a class="previous-item" href="<?php echo esc_url( jet_cct_query_arg( array( 'id' => $prev ), null, 'do' ) ); ?>">
									<span>&laquo;</span>
									<?php echo sprintf( __( 'Previous %s', 'jet_cct' ), $singular_label ); ?>
								</a>
							<?php
							}

							if ( 0 < $next ) {
								?>
								<a class="next-item" href="<?php echo esc_url( jet_cct_query_arg( array( 'id' => $next ), null, 'do' ) ); ?>">
									<?php echo sprintf( __( 'Next %s', 'jet_cct' ), $singular_label ); ?>
									<span>&raquo;</span>
								</a>
							<?php
							}
							?>

							<div class="clear"></div>
						</div>
						<!-- /#navigation-actions -->
					</div>
					<!-- /#navigatebox -->
				</div>
				<!-- /.inside -->
			</div> <!-- /#navigatediv -->
		<?php
				}
			}
		?>
	</div>
	<!-- /#side-sortables -->
</div>
<!-- /#side-info-column -->

<div id="post-body">
	<div id="post-body-content">
		<?php
			$more = false;

			if ( $jet->jet_data[ 'field_index' ] != $jet->jet_data[ 'field_id' ] ) {
				foreach ( $fields as $k => $field ) {
					if ( $jet->jet_data[ 'field_index' ] != $field[ 'name' ] || 'text' != $field[ 'type' ] )
						continue;

					$more = true;
					$extra = '';

					$max_length = (int) jet_cct_v_sanitized( 'maxlength', $field[ 'options' ], jet_cct_v_sanitized( $field[ 'type' ] . '_max_length', $field[ 'options' ], 0 ), true );

					if ( 0 < $max_length )
						$extra .= ' maxlength="' . $max_length . '"';
		?>
			<div id="titlediv">
				<div id="titlewrap">
					<h3><?php echo esc_html( $jet->index() ); ?></h3>
				</div>
				<!-- /#titlewrap -->
			</div>
			<!-- /#titlediv -->
		<?php
					unset( $fields[ $k ] );
				}
			}

			if ( 0 < count( $fields ) ) {
		?>
			<div id="normal-sortables" class="meta-box-sortables ui-sortable">
				<div id="jet_cct-meta-box" class="postbox" style="">
					<div class="handlediv" title="Click to toggle"><br /></div>
					<h3 class="hndle">
						<span>
							<?php
								if ( $more )
									$title = __( 'More Fields', 'jet_cct' );
								else
									$title = __( 'Fields', 'jet_cct' );

								/** This filter is documented in classes/jet_cctMeta.php */
								echo apply_filters( 'jet_cct_meta_default_box_title', $title, $jet, $fields, $jet->api->jet_data[ 'type' ], $jet->jet );
							?>
						</span>
					</h3>

					<div class="inside">
						<table class="form-table jet_cct-metabox">
							<?php
								foreach ( $fields as $field ) {
									if ( isset( $field[ 'custom_display' ] ) && is_callable( $field[ 'custom_display' ] ) ) {
										$value = call_user_func_array( $field[ 'custom_display' ], array( $jet->row(), $obj, $jet->field( $field[ 'name' ] ), $field[ 'name' ], $field ) );
									}
									else {
										$value = $jet->display( $field[ 'name' ] );
									}
							?>
								<tr class="form-field jet_cct-field <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>">
									<th scope="row" valign="top">
										<strong><?php echo $field[ 'label' ]; ?></strong>
									</th>
									<td>
										<?php echo $value; ?>
									</td>
								</tr>
							<?php
								}
							?>
						</table>
					</div>
					<!-- /.inside -->
				</div>
				<!-- /#jet_cct-meta-box -->
			</div>
			<!-- /#normal-sortables -->

		<?php } ?>

		<!--<div id="advanced-sortables" class="meta-box-sortables ui-sortable">
		</div>
		 /#advanced-sortables -->

	</div>
	<!-- /#post-body-content -->

	<br class="clear" />
</div>
<!-- /#post-body -->

<br class="clear" />
</div>
<!-- /#poststuff -->
</div>
<!-- /#jet_cct-record -->
