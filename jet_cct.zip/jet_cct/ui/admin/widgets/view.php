<style type="text/css">
    ol.jet_cct_form_widget_form {
        list-style: none;
        padding-left: 0;
        margin-left: 0;
    }

    ol.jet_cct_form_widget_form label {
        display: block;
    }
</style>

<ol class="jet_cct_form_widget_form">
    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"> <?php _e( 'Title', 'jet_cct' ); ?></label>

        <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>" />
    </li>

    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'view' ) ); ?>"><?php _e( 'File to include', 'jet_cct' ); ?></label>

        <input class="widefat" type="text" name="<?php echo esc_attr( $this->get_field_name( 'view' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'view' ) ); ?>" value="<?php echo esc_attr( $view ); ?>" />
    </li>

    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'cache_mode' ) ); ?>"><?php _e( 'Cache Type', 'jet_cct' ); ?></label>

        <?php
            $cache_modes = array(
                'none' => __( 'Disable Caching', 'jet_cct' ),
                'cache' => __( 'Object Cache', 'jet_cct' ),
                'transient' => __( 'Transient', 'jet_cct' ),
                'site-transient' => __( 'Site Transient', 'jet_cct' )
            );
        ?>
        <select id="<?php echo esc_attr( $this->get_field_id( 'cache_mode' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'cache_mode' ) ); ?>">
            <?php foreach ( $cache_modes as $cache_mode_option => $cache_mode_label ): ?>
            <?php $selected = ( $cache_mode_option == $cache_mode ) ? 'selected' : ''; ?>
            <option value="<?php echo esc_attr( $cache_mode_option ); ?>"<?php selected( $cache_mode_option, $cache_mode ); ?>>
                <?php echo esc_html( $cache_mode_label ); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </li>

    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'expires' ) ); ?>"><?php _e( 'Cache Expiration (in seconds)', 'jet_cct' ); ?></label>

        <input class="widefat" type="text" name="<?php echo esc_attr( $this->get_field_name( 'expires' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'expires' ) ); ?>" value="<?php echo esc_attr( $expires ); ?>" />
    </li>
</ol>
