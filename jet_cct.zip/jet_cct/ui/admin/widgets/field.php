<style type="text/css">
    ol.jet_cct_field_widget_form {
        list-style: none;
        padding-left: 0;
        margin-left: 0;
    }

    ol.jet_cct_field_widget_form label {
        display: block;
    }
</style>

<ol class="jet_cct_field_widget_form">
    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"> <?php _e( 'Title', 'jet_cct' ); ?></label>

        <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>" />
    </li>

    <li>
        <?php
            $api = jet_cct_api();
            $all_jet_cct = $api->load_jet_cct( array( 'names' => true ) );
        ?>
        <label for="<?php echo esc_attr( $this->get_field_id( 'jet_type' ) ); ?>">
            <?php _e( 'jet', 'jet_cct' ); ?>
        </label>

        <?php if ( 0 < count( $all_jet_cct ) ): ?>
            <select id="<?php echo esc_attr( $this->get_field_id( 'jet_type' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'jet_type' ) ); ?>">
                <?php foreach ( $all_jet_cct as $jet_name => $jet_label ): ?>
                    <option value="<?php echo esc_attr( $jet_name ); ?>" <?php selected( $jet_name, $jet_type ); ?>>
                        <?php echo esc_html( $jet_label . ' (' . $jet_name . ')' ); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        <?php else: ?>
            <strong class="red"><?php _e( 'None Found', 'jet_cct' ); ?></strong>
        <?php endif; ?>
    </li>

    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'slug' ) ); ?>">
            <?php _e( 'Slug or ID', 'jet_cct' ); ?>
        </label>

        <input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'slug' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'slug' ) ); ?>" value="<?php echo esc_attr( $slug ); ?>" />
    </li>

    <li>
        <label for="<?php echo esc_attr( $this->get_field_id( 'field' ) ); ?>"><?php _e( 'Field', 'jet_cct' ); ?></label>

        <input class="widefat" type="text" name="<?php echo esc_attr( $this->get_field_name( 'field' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'field' ) ); ?>" value="<?php echo esc_attr( $field ); ?>" />
    </li>
</ol>
