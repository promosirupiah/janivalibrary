<div class="wrap jet_cct-admin">
    <div id="icon-jet_cct" class="icon32"><br /></div>
    <form action="" method="post" class="jet_cct-submittable">
        <div class="jet_cct-submittable-fields">
            <?php echo jet_cctForm::field( 'action', 'jet_cct_admin_components', 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'component', $component, 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'method', 'settings', 'hidden' ); ?>
            <?php echo jet_cctForm::field( '_wpnonce', wp_create_nonce( 'jet_cct-component-' . $component . '-settings' ), 'hidden' ); ?>

            <h2><?php _e( 'Settings', 'jet_cct' ); ?>: <?php echo $component_label; ?></h2>

            <?php
                if ( isset( $_GET[ 'do' ] ) )
                    jet_cct_message( __( 'Settings saved successfully.', 'jet_cct' ) );
            ?>

            <table class="form-table jet_cct-manage-field">
                <?php
                    $depends_on = false;

                    foreach ( $options as $field_name => $field_option ) {
                        $field_option = jet_cctForm::field_setup( $field_option, null, $field_option[ 'type' ] );

                        $depends = jet_cctForm::dependencies( $field_option );

                        if ( ( !empty( $depends_on ) || !empty( $depends ) ) && $depends_on != $depends ) {
                            if ( !empty( $depends_on ) ) {
                ?>
                    </tbody>
                <?php
                            }

                            if ( !empty( $depends ) ) {
                ?>
                    <tbody class="jet_cct-field-option-container <?php echo esc_attr( $depends ); ?>">
                <?php
                            }
                        }

                        if ( !is_array( $field_option[ 'group' ] ) ) {
                            $value = jet_cct_var_raw( $field_name, $settings, $field_option[ 'default' ] );
                ?>
                    <tr valign="top" class="jet_cct-field-option" id="jet_cct-setting-<?php echo esc_attr( $field_name ); ?>">
                        <th>
                            <?php echo jet_cctForm::label( 'jet_cct_setting_' . $field_name, $field_option[ 'label' ], $field_option[ 'help' ], $field_option ); ?>
                        </th>
                        <td>
                            <?php echo jet_cctForm::field( 'jet_cct_setting_' . $field_name, $value, $field_option[ 'type' ], $field_option ); ?>
                        </td>
                    </tr>
                <?php
                        }
                        else {
                ?>
                    <tr valign="top" class="jet_cct-field-option-group" id="jet_cct-setting-<?php echo esc_attr( $field_name ); ?>">
                        <th class="jet_cct-field-option-group-label">
                            <?php echo $field_option[ 'label' ]; ?>
                        </th>
                        <td class="jet_cct-pick-values jet_cct-pick-checkbox">
                            <ul>
                                <?php
                                    foreach ( $field_option[ 'group' ] as $field_group_name => $field_group_option ) {
                                        $field_group_option = jet_cctForm::field_setup( $field_group_option, null, $field_group_option[ 'type' ] );

                                        if ( 'boolean' != $field_group_option[ 'type' ] )
                                            continue;

                                        $field_group_option[ 'boolean_yes_label' ] = $field_group_option[ 'label' ];

                                        $depends_option = jet_cctForm::dependencies( $field_group_option );

                                        $value = jet_cct_var_raw( $field_group_name, $settings, $field_group_option[ 'default' ] );
                                ?>
                                    <li class="<?php echo esc_attr( $depends_option ); ?>">
                                        <?php echo jet_cctForm::field( 'jet_cct_setting_' . $field_group_name, $value, $field_group_option[ 'type' ], $field_group_option ); ?>
                                    </li>
                                <?php
                                    }
                                ?>
                            </ul>
                        </td>
                    </tr>
                <?php
                        }

                        if ( false !== $depends_on || !empty( $depends ) )
                            $depends_on = $depends;
                    }

                    if ( !empty( $depends_on ) ) {
                ?>
                    </tbody>
                <?php
                    }
                ?>
            </table>

            <p class="submit">
                <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Changes', 'jet_cct' ); ?>">
                <img class="waiting" src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ); ?>" alt="" />
            </p>
        </div>
    </form>
</div>

<script type="text/javascript">
    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'exit_confirm' );
    } );

    var jet_cct_admin_submit_callback = function ( id ) {
        document.location = '<?php echo jet_cct_slash( jet_cct_query_arg( array( 'do' => 'save' ) ) ); ?>';
    }
</script>