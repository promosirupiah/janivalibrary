<div class="wrap jet_cct-admin">
    <form action="" method="post">

        <div id="icon-jet_cct" class="icon32"><br /></div>

        <?php
            $default = 'tools';

            $tabs = array(
                //'settings' => __( 'Settings', 'jet_cct' ),
                'tools' => __( 'Tools', 'jet_cct' ),
                'reset' => __( 'Cleanup &amp; Reset', 'jet_cct' )
            );
        ?>

        <h2 class="nav-tab-wrapper">
            <?php
                foreach ( $tabs as $tab => $label ) {
                    $class = '';

                    if ( $tab == jet_cct_var( 'tab', 'get', $default ) ) {
                        $class = ' nav-tab-active';

                        $label = 'jet_cct ' . $label;
                    }

                    $url = jet_cct_query_arg( array( 'tab' => $tab ), array( 'page' ) );
            ?>
                <a href="<?php echo esc_url( $url ); ?>" class="nav-tab<?php echo esc_attr( $class ); ?>">
                    <?php echo $label; ?>
                </a>
            <?php
                }
            ?>
        </h2>
        <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />

        <?php
            wp_nonce_field( 'jet_cct-settings' );

            $tab = jet_cct_var( 'tab', 'get', $default );
            $tab = sanitize_title( $tab );

            echo jet_cct_view( jet_cct_DIR . 'ui/admin/settings-' . $tab . '.php' );
        ?>
    </form>
</div>
