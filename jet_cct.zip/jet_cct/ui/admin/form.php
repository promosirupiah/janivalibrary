<?php
wp_enqueue_script( 'jet_cct' );
wp_enqueue_style( 'jet_cct-form' );

if ( empty( $fields ) || !is_array( $fields ) )
    $fields = $obj->jet->fields;

if ( !isset( $duplicate ) )
    $duplicate = false;
else
    $duplicate = (boolean) $duplicate;

$groups = jet_cctInit::$meta->groups_get( $jet->jet_data[ 'type' ], $jet->jet_data[ 'name' ], $fields );

$group_fields = array();
$submittable_fields = array();

foreach ( $groups as $g => $group ) {
    // unset fields
    foreach ( $group[ 'fields' ] as $k => $field ) {
        if ( in_array( $field[ 'name' ], array( 'created', 'modified' ) ) ) {
            unset( $group[ 'fields' ][ $k ] );

            continue;
        }
        elseif ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field[ 'options' ], $group[ 'fields' ], $jet, $jet->id() ) ) {
            if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) ) {
                $group[ 'fields' ][ $k ][ 'type' ] = 'hidden';
            }
            elseif ( jet_cct_var( 'read_only', $field[ 'options' ], false ) ) {
                $group[ 'fields' ][ $k ][ 'readonly' ] = true;
            }
            else {
                unset( $group[ 'fields' ][ $k ] );

                continue;
            }
	    }
	    elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) ) {
            if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) ) {
                $group[ 'fields' ][ $k ][ 'type' ] = 'hidden';
            }
            elseif ( jet_cct_var( 'read_only', $field[ 'options' ], false ) ) {
                $group[ 'fields' ][ $k ][ 'readonly' ] = true;
            }
	    }

        if ( !jet_cct_var( 'readonly', $field, false ) ) {
            $submittable_fields[ $field[ 'name' ]] = $group[ 'fields' ][ $k ];
        }

        $group_fields[ $field[ 'name' ] ] = $group[ 'fields' ][ $k ];
    }
    $groups[ $g ] = $group;
}

if ( !isset( $thank_you_alt ) )
    $thank_you_alt = $thank_you;

$uri_hash = wp_create_nonce( 'jet_cct_uri_' . $_SERVER[ 'REQUEST_URI' ] );
$field_hash = wp_create_nonce( 'jet_cct_fields_' . implode( ',', array_keys( $submittable_fields ) ) );

$uid = @session_id();

if ( is_user_logged_in() )
    $uid = 'user_' . get_current_user_id();

$nonce = wp_create_nonce( 'jet_cct_form_' . $jet->jet . '_' . $uid . '_' . ( $duplicate ? 0 : $jet->id() ) . '_' . $uri_hash . '_' . $field_hash );

if ( isset( $_POST[ '_jet_cct_nonce' ] ) ) {
    $action = __( 'saved', 'jet_cct' );

    if ( 'create' == jet_cct_var_raw( 'do', 'post', 'save' ) )
        $action = __( 'created', 'jet_cct' );
    elseif ( 'duplicate' == jet_cct_var_raw( 'do', 'get', 'save' ) )
        $action = __( 'duplicated', 'jet_cct' );

    try {
        $params = jet_cct_unslash( (array) $_POST );
        $id = $jet->api->process_form( $params, $jet, $submittable_fields, $thank_you );

        $message = sprintf( __( '<strong>Success!</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );

        if ( 0 < strlen( jet_cct_var( 'detail_url', $jet->jet_data[ 'options' ] ) ) )
            $message .= ' <a target="_blank" href="' . $jet->field( 'detail_url' ) . '">' . sprintf( __( 'View %s', 'jet_cct' ), $obj->item ) . '</a>';

        $error = sprintf( __( '<strong>Error:</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );

        if ( 0 < $id )
            echo $obj->message( $message );
        else
            echo $obj->error( $error );
    }
    catch ( Exception $e ) {
        echo $obj->error( $e->getMessage() );
    }
}
elseif ( isset( $_GET[ 'do' ] ) ) {
    $action = __( 'saved', 'jet_cct' );

    if ( 'create' == jet_cct_var_raw( 'do', 'get', 'save' ) )
        $action = __( 'created', 'jet_cct' );
    elseif ( 'duplicate' == jet_cct_var_raw( 'do', 'get', 'save' ) )
        $action = __( 'duplicated', 'jet_cct' );

    $message = sprintf( __( '<strong>Success!</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );

    if ( 0 < strlen( jet_cct_var( 'detail_url', $jet->jet_data[ 'options' ] ) ) )
        $message .= ' <a target="_blank" href="' . $jet->field( 'detail_url' ) . '">' . sprintf( __( 'View %s', 'jet_cct' ), $obj->item ) . '</a>';

    $error = sprintf( __( '<strong>Error:</strong> %s not %s.', 'jet_cct' ), $obj->item, $action );

    if ( 0 < $jet->id() )
        echo $obj->message( $message );
    else
        echo $obj->error( $error );
}

if ( !isset( $label ) )
    $label = __( 'Save', 'jet_cct' );

$do = 'create';

if ( 0 < $jet->id() ) {
    if ( $duplicate )
        $do = 'duplicate';
    else
        $do = 'save';
}
?>

<form action="" method="post" class="jet_cct-submittable jet_cct-form jet_cct-form-jet-<?php echo esc_attr( $jet->jet ); ?> jet_cct-submittable-ajax">
    <div class="jet_cct-submittable-fields">
        <?php
            echo jet_cctForm::field( 'action', 'jet_cct_admin', 'hidden' );
            echo jet_cctForm::field( 'method', 'process_form', 'hidden' );
            echo jet_cctForm::field( 'do', $do, 'hidden' );
            echo jet_cctForm::field( '_jet_cct_nonce', $nonce, 'hidden' );
            echo jet_cctForm::field( '_jet_cct_jet', $jet->jet, 'hidden' );
            echo jet_cctForm::field( '_jet_cct_id', ( $duplicate ? 0 : $jet->id() ), 'hidden' );
            echo jet_cctForm::field( '_jet_cct_uri', $uri_hash, 'hidden' );
            echo jet_cctForm::field( '_jet_cct_form', implode( ',', array_keys( $submittable_fields ) ), 'hidden' );
            echo jet_cctForm::field( '_jet_cct_location', $_SERVER[ 'REQUEST_URI' ], 'hidden' );

            foreach ( $group_fields as $field ) {
                if ( 'hidden' != $field[ 'type' ] )
                    continue;

                echo jet_cctForm::field( 'jet_cct_field_' . $field[ 'name' ], $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) ), 'hidden' );
           }

			/**
			 * Action that runs before the meta boxes for an Advanced Content Type
			 *
			 * Occurs at the top of #poststuff
			 *
			 * @param jet_cct $jet Current jet_cct object.
			 * @param jet_cctUI $obj Current jet_cctUI object.
			 *
			 * @since 2.5
			 */
            do_action( 'jet_cct_meta_box_pre', $jet, $obj );
        ?>
        <div id="poststuff" class="metabox-holder has-right-sidebar"> <!-- class "has-right-sidebar" preps for a sidebar... always present? -->
            <div id="side-info-column" class="inner-sidebar">
				<?php
					/**
					 * Action that runs before the sidebar of the editor for an Advanced Content Type
					 *
					 * Occurs at the top of #side-info-column
					 *
					 * @param jet_cct $jet Current jet_cct object.
					 * @param jet_cctUI $obj Current jet_cctUI object.
					 *
					 * @since 2.4.1
					 */
					do_action( 'jet_cct_act_editor_before_sidebar', $jet, $obj );
				?>
                <div id="side-sortables" class="meta-box-sortables ui-sortable">
                    <!-- BEGIN PUBLISH DIV -->
                    <div id="submitdiv" class="postbox">
                        <div class="handlediv" title="Click to toggle"><br /></div>
                        <h3 class="hndle"><span><?php _e( 'Manage', 'jet_cct' ); ?></span></h3>

                        <div class="inside">
                            <div class="submitbox" id="submitpost">
                                <?php
                                    if ( 0 < $jet->id() && ( isset( $jet->jet_data[ 'fields' ][ 'created' ] ) || isset( $jet->jet_data[ 'fields' ][ 'modified' ] ) || 0 < strlen( jet_cct_var( 'detail_url', $jet->jet_data[ 'options' ] ) ) ) ) {
                                ?>
                                    <div id="minor-publishing">
                                        <?php
                                            if ( 0 < strlen( jet_cct_var( 'detail_url', $jet->jet_data[ 'options' ] ) ) ) {
                                        ?>
                                            <div id="minor-publishing-actions">
                                                <div id="preview-action">
                                                    <a class="button" href="<?php echo esc_url( $jet->field( 'detail_url' ) ); ?>" target="_blank"><?php echo sprintf( __( 'View %s', 'jet_cct' ), $obj->item ); ?></a>
                                                </div>
                                                <div class="clear"></div>
                                            </div>
                                        <?php
                                            }

                                            if ( isset( $jet->jet_data[ 'fields' ][ 'created' ] ) || isset( $jet->jet_data[ 'fields' ][ 'modified' ] ) ) {
                                        ?>
                                            <div id="misc-publishing-actions">
                                                <?php
                                                    $datef = __( 'M j, Y @ G:i' );

                                                    if ( isset( $jet->jet_data[ 'fields' ][ 'created' ] ) ) {
                                                        $date = date_i18n( $datef, strtotime( $jet->field( 'created' ) ) );
                                                ?>
                                                    <div class="misc-pub-section curtime">
                                                        <span id="timestamp"><?php _e( 'Created on', 'jet_cct' ); ?>: <b><?php echo $date; ?></b></span>
                                                    </div>
                                                <?php
                                                    }

                                                    if ( isset( $jet->jet_data[ 'fields' ][ 'modified' ] ) && $jet->display( 'created' ) != $jet->display( 'modified' ) ) {
                                                        $date = date_i18n( $datef, strtotime( $jet->field( 'modified' ) ) );
                                                ?>
                                                    <div class="misc-pub-section curtime">
                                                        <span id="timestamp"><?php _e( 'Last Modified', 'jet_cct' ); ?>: <b><?php echo $date; ?></b></span>
                                                    </div>
                                                <?php
                                                    }
                                                ?>

                                                <?php
                                                    /**
                                                     * Action that runs after the misc publish actions area for an Advanced Content Type
                                                     *
                                                     * Occurs at the end of #misc-publishing-actions
                                                     *
                                                     * @param jet_cct $jet Current jet_cct object.
                                                     * @param jet_cctUI $obj Current jet_cctUI object.
                                                     *
                                                     * @since 2.5
                                                     */
                                                    do_action( 'jet_cct_ui_form_misc_pub_actions', $jet, $obj );
                                                ?>
                                            </div>
                                        <?php
                                            }
                                        ?>
                                    </div>
                                    <!-- /#minor-publishing -->
                                <?php
                                    }
                                ?>

                                <div id="major-publishing-actions">
                                    <?php
                                        if ( jet_cct_is_admin( array( 'jet_cct', 'jet_cct_delete_' . $jet->jet ) ) && null !== $jet->id() && !$duplicate && !in_array( 'delete', (array) $obj->actions_disabled ) && !in_array( 'delete', (array) $obj->actions_hidden ) ) {
                                            $link = jet_cct_query_arg( array(
                                                'action' => 'delete',
                                                '_wpnonce' => wp_create_nonce( 'jet_cct-ui-action-delete' )
                                            ) );
                                    ?>
                                        <div id="delete-action">
                                            <a class="submitdelete deletion" href="<?php echo esc_url( $link ); ?>" onclick="return confirm('You are about to permanently delete this item\n Choose \'Cancel\' to stop, \'OK\' to delete.');"><?php _e( 'Delete', 'jet_cct' ); ?></a>
                                        </div>
                                        <!-- /#delete-action -->
                                    <?php } ?>

                                    <div id="publishing-action">
                                        <img class="waiting" src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ); ?>" alt="" />
                                        <input type="submit" name="publish" id="publish" class="button button-primary button-large" value="<?php echo esc_attr( $label ); ?>" accesskey="p" />
                                        <?php
											/**
											 * Action that runs after the publish button for an Advanced Content Type
											 *
											 * Occurs at the end of #publishing-action
											 *
											 * @param jet_cct $jet Current jet_cct object.
											 * @param jet_cctUI $obj Current jet_cctUI object.
											 *
											 * @since 2.5
											 */
                                            do_action( 'jet_cct_ui_form_submit_area', $jet, $obj );
                                        ?>
                                    </div>
                                    <!-- /#publishing-action -->

                                    <div class="clear"></div>
                                </div>

                                <?php
                                    /**
                                     * Action that runs after the publish area for an Advanced Content Type
                                     *
                                     * Occurs at the end of #submitpost
                                     *
                                     * @param jet_cct $jet Current jet_cct object.
                                     * @param jet_cctUI $obj Current jet_cctUI object.
                                     *
                                     * @since 2.5
                                     */
                                    do_action( 'jet_cct_ui_form_publish_area', $jet, $obj );
                                ?>
                                <!-- /#major-publishing-actions -->
                            </div>
                            <!-- /#submitpost -->
                        </div>
                        <!-- /.inside -->
                    </div>
                    <!-- /#submitdiv --><!-- END PUBLISH DIV --><!-- TODO: minor column fields -->
                    <?php
                        if ( jet_cct_var_raw( 'action' ) == 'edit' && !$duplicate && !in_array( 'navigate', (array) $obj->actions_disabled ) && !in_array( 'navigate', (array) $obj->actions_hidden ) ) {
                            if ( !isset( $singular_label ) )
                                $singular_label = ucwords( str_replace( '_', ' ', $jet->jet_data[ 'name' ] ) );

                            $singular_label = jet_cct_var_raw( 'label', $jet->jet_data[ 'options' ], $singular_label, null, true );
                            $singular_label = jet_cct_var_raw( 'label_singular', $jet->jet_data[ 'options' ], $singular_label, null, true );

                            $jet->params = $obj->get_params( null, 'manage' );

                            $prev_next = apply_filters( 'jet_cct_ui_prev_next_ids', array(), $jet, $obj );

                            if ( empty( $prev_next ) ) {
                                $prev_next = array(
                                    'prev' => $jet->prev_id(),
                                    'next' => $jet->next_id()
                                );
                            }

                            $prev = $prev_next[ 'prev' ];
                            $next = $prev_next[ 'next' ];

                            if ( 0 < $prev || 0 < $next ) {
                    ?>
                    <div id="navigatediv" class="postbox">
						<?php
							/**
							 * Action that runs before the post navagiation in the editor for an Advanced Content Type
							 *
							 * Occurs at the top of #navigatediv
							 *
							 * @param jet_cct $jet Current jet_cct object.
							 * @param jet_cctUI $obj Current jet_cctUI object.
							 *
							 * @since 2.4.1
							 */
							do_action( 'jet_cct_act_editor_before_navigation', $jet, $obj );
						?>
                        <div class="handlediv" title="Click to toggle"><br /></div>
                        <h3 class="hndle"><span><?php _e( 'Navigate', 'jet_cct' ); ?></span></h3>

                        <div class="inside">
                            <div class="jet_cct-admin" id="navigatebox">
                                <div id="navigation-actions">
                                    <?php
                                        if ( 0 < $prev ) {
                                    ?>
                                        <a class="previous-item" href="<?php echo esc_url( jet_cct_query_arg( array( 'id' => $prev ), null, 'do' ) ); ?>">
                                            <span>&laquo;</span>
                                            <?php echo sprintf( __( 'Previous %s', 'jet_cct' ), $singular_label ); ?>
                                        </a>
                                    <?php
                                        }

                                        if ( 0 < $next ) {
                                    ?>
                                        <a class="next-item" href="<?php echo esc_url( jet_cct_query_arg( array( 'id' => $next ), null, 'do' ) ); ?>">
                                            <?php echo sprintf( __( 'Next %s', 'jet_cct' ), $singular_label ); ?>
                                            <span>&raquo;</span>
                                        </a>
                                    <?php
                                        }
                                    ?>

                                    <div class="clear"></div>
                                </div>
                                <!-- /#navigation-actions -->
                            </div>
                            <!-- /#navigatebox -->
                        </div>
                        <!-- /.inside -->
						<?php
							/**
							 * Action that runs after the post navagiation in the editor for an Advanced Content Type
							 *
							 * Occurs at the bottom of #navigatediv
							 *
							 * @param jet_cct $jet Current jet_cct object.
							 * @param jet_cctUI $obj Current jet_cctUI object.
							 *
							 * @since 2.4.1
							 */
							do_action( 'jet_cct_act_editor_after_navigation', $jet, $obj );
						?>
                    </div> <!-- /#navigatediv -->
                    <?php
                            }
                        }
                    ?>
                </div>
                <!-- /#side-sortables -->
				<?php
					/**
					 * Action that runs after the sidebar of the editor for an Advanced Content Type
					 *
					 * Occurs at the bottom of #side-info-column
					 *
					 * @param jet_cct $jet Current jet_cct object.
					 * @param jet_cctUI $obj Current jet_cctUI object.
					 *
					 * @since 2.4.1
					 */
					do_action( 'jet_cct_act_editor_after_sidebar', $jet, $obj );
				?>
            </div>
            <!-- /#side-info-column -->

            <div id="post-body">
                <div id="post-body-content">
                    <?php
                        $more = false;

                        if ( $jet->jet_data[ 'field_index' ] != $jet->jet_data[ 'field_id' ] ) {
                            foreach ( $group_fields as $field ) {
                                if ( $jet->jet_data[ 'field_index' ] != $field[ 'name' ] || 'text' != $field[ 'type' ] )
                                    continue;

                                $more = true;
                                $extra = '';

                                $max_length = (int) jet_cct_var( 'maxlength', $field[ 'options' ], jet_cct_var( $field[ 'type' ] . '_max_length', $field[ 'options' ], 0 ), null, true );

                                if ( 0 < $max_length )
                                    $extra .= ' maxlength="' . esc_attr( $max_length ) . '"';

                                /**
                                 * Filter that lets you make the title field readonly
                                 *
                                 * @param jet_cct $jet Current jet_cct object.
                                 * @param jet_cctUI $obj Current jet_cctUI object.
                                 *
                                 * @since 2.5
                                 */
                                if ( jet_cct_v( 'readonly', $field[ 'options' ], jet_cct_v( 'readonly', $field, false ) ) || apply_filters( 'jet_cct_ui_form_title_readonly', false, $jet, $obj ) ) {
                            ?>
                                    <div id="titlediv">
                                        <div id="titlewrap">
                                            <h3><?php echo esc_html( $jet->index() ); ?></h3>
                                            <input type="hidden" name="jet_cct_field_<?php echo esc_attr( $jet->jet_data[ 'field_index' ] ); ?>" data-name-clean="jet_cct-field-<?php echo esc_attr( $jet->jet_data[ 'field_index' ] ); ?>" id="title" size="30" tabindex="1" value="<?php echo esc_attr( htmlspecialchars( $jet->index() ) ); ?>" class="jet_cct-form-ui-field-name-jet_cct-field-<?php echo esc_attr( $jet->jet_data[ 'field_index' ] ); ?>" autocomplete="off"<?php echo $extra; ?> />
                                        </div>
                                        <!-- /#titlewrap -->
                                    </div>
                                    <!-- /#titlediv -->
                            <?php
                                }
                                else {
                            ?>
                                <div id="titlediv">
									<?php
										/**
										 * Action that runs before the title field of the editor for an Advanced Content Type
										 *
										 * Occurs at the top of #titlediv
										 *
										 * @param jet_cct $jet Current jet_cct object.
										 * @param jet_cctUI $obj Current jet_cctUI object.
										 *
										 * @since 2.4.1
										 */
										do_action( 'jet_cct_act_editor_before_title', $jet, $obj );
									?>
                                    <div id="titlewrap">
                                        <label class="screen-reader-text" id="title-prompt-text" for="title"><?php echo apply_filters( 'jet_cct_enter_name_here', __( 'Enter name here', 'jet_cct' ), $jet, $fields ); ?></label>
                                        <input type="text" name="jet_cct_field_<?php echo esc_attr( $jet->jet_data[ 'field_index' ] ); ?>" data-name-clean="jet_cct-field-<?php echo esc_attr( $jet->jet_data[ 'field_index' ] ); ?>" id="title" size="30" tabindex="1" value="<?php echo esc_attr( htmlspecialchars( $jet->index() ) ); ?>" class="jet_cct-form-ui-field-name-jet_cct-field-<?php echo esc_attr( $jet->jet_data[ 'field_index' ] ); ?>" autocomplete="off"<?php echo $extra; ?> />
										<?php
											/**
											 * Action that runs after the title field of the editor for an Advanced Content Type
											 *
											 * Occurs at the bottom of #titlediv
											 *
											 * @param jet_cct $jet Current jet_cct object.
											 * @param jet_cctUI $obj Current jet_cctUI object.
											 *
											 * @since 2.4.1
											 */
											do_action( 'jet_cct_act_editor_after_title', $jet, $obj );
										?>
                                    </div>
                                    <!-- /#titlewrap -->

                                    <div class="inside">
                                        <div id="edit-slug-box">
                                        </div>
                                        <!-- /#edit-slug-box -->
                                    </div>
                                    <!-- /.inside -->
                                </div>
                                <!-- /#titlediv -->
                            <?php
                                }

                                unset( $group_fields[ $field[ 'name' ] ] );
                            }
                        }

                        if ( 0 < count( $groups ) ) {
                            if ( $more && 1 == count( $groups ) ) {
                                $first_group = current( $groups );

                                if ( 1 == count( $first_group[ 'fields' ] ) && isset( $first_group[ 'fields' ][ $jet->jet_data[ 'field_index' ] ] ) ) {
                                    $groups = array();
                                }
                            }

                            if ( 0 < count( $groups ) ) {
                    ?>
                    <div id="normal-sortables" class="meta-box-sortables ui-sortable">
						<?php
                            foreach ( $groups as $group ) {
                                if ( empty( $group[ 'fields' ] ) ) {
                                    continue;
                                }

								/**
								 * Action that runs before the main fields metabox in the editor for an Advanced Content Type
								 *
								 * Occurs at the top of #normal-sortables
								 *
								 * @param jet_cct $jet Current jet_cct object.
								 *
								 * @since 2.4.1
								 */
								do_action( 'jet_cct_act_editor_before_metabox', $jet );
						?>
                        <div id="jet_cct-meta-box-<?php echo esc_attr( sanitize_title( $group[ 'label' ] ) ); ?>" class="postbox">
                            <div class="handlediv" title="Click to toggle"><br /></div>
                            <h3 class="hndle">
                                <span>
                                    <?php
                                        if ( ! $more && 1 == count( $groups ) ) {
                                            $title = __( 'Fields', 'jet_cct' );
                                        }
                                        else {
                                            $title = $group[ 'label' ];
                                        }

										/** This filter is documented in classes/jet_cctMeta.php */
	                                    echo apply_filters( 'jet_cct_meta_default_box_title', $title, $jet, $fields, $jet->api->jet_data[ 'type' ], $jet->jet );
                                    ?>
                                </span>
                            </h3>

                            <div class="inside">
                                    <?php
                                        if ( false === apply_filters( 'jet_cct_meta_box_override', false, $jet, $group, $obj ) ) {
                                    ?>
                                <table class="form-table jet_cct-metabox">
                                    <?php
                                                foreach ( $group[ 'fields' ] as $field ) {
                                                    if ( 'hidden' == $field[ 'type' ] || $more === $field[ 'name' ] || !isset( $group_fields[ $field[ 'name' ] ] ) )
                                                continue;
                                    ?>
                                        <tr class="form-field jet_cct-field jet_cct-field-input <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>">
                                            <th scope="row" valign="top"><?php echo jet_cctForm::label( 'jet_cct_field_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field ); ?></th>
                                            <td>
                                                <?php echo jet_cctForm::field( 'jet_cct_field_' . $field[ 'name' ], $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) ), $field[ 'type' ], $field, $jet, $jet->id() ); ?>
                                                <?php echo jet_cctForm::comment( 'jet_cct_field_' . $field[ 'name' ], $field[ 'description' ], $field ); ?>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                </table>
                                    <?php
                                        }
                                    ?>
                            </div>
                            <!-- /.inside -->
                        </div>
                        <!-- /#jet_cct-meta-box -->
						<?php
                            }

							/**
							 * Action that runs after the main fields metabox in the editor for an Advanced Content Type
							 *
							 * Occurs at the bottom of #normal-sortables
							 *
							 * @param jet_cct $jet Current jet_cct object.
							 * @param jet_cctUI $obj Current jet_cctUI object.
							 *
							 * @since 2.4.1
							 */
							do_action( 'jet_cct_act_editor_after_metabox', $jet, $obj );
						?>
                    </div>
                    <!-- /#normal-sortables -->

                <?php
                        }
                    }
                ?>

                    <!--<div id="advanced-sortables" class="meta-box-sortables ui-sortable">
                    </div>
                     /#advanced-sortables -->

                </div>
                <!-- /#post-body-content -->

                <br class="clear" />
            </div>
            <!-- /#post-body -->

            <br class="clear" />
        </div>
        <!-- /#poststuff -->
    </div>
</form>
<!-- /#jet_cct-record -->

<script type="text/javascript">
    if ( 'undefined' == typeof ajaxurl ) {
        var ajaxurl = '<?php echo jet_cct_slash( admin_url( 'admin-ajax.php' ) ); ?>';
    }

    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'exit_confirm' );
    } );

    if ( 'undefined' == typeof jet_cct_form_thank_you ) {
        var jet_cct_form_thank_you = null;
    }

    var jet_cct_admin_submit_callback = function ( id ) {

        id = parseInt( id, 10 );
        var thank_you = '<?php echo esc_url_raw( $thank_you ); ?>';
        var thank_you_alt = '<?php echo esc_url_raw( $thank_you_alt ); ?>';

        if ( 'undefined' != typeof jet_cct_form_thank_you && null !== jet_cct_form_thank_you ) {
            thank_you = jet_cct_form_thank_you;
        }

        if ( isNaN( id ) ) {
            document.location = thank_you_alt.replace( 'X_ID_X', String( 0 ) );
        }
        else {
            document.location = thank_you.replace( 'X_ID_X', String( id ) );
        }
    }
</script>
