<p class="padded"><?php _e( 'We recommend that you back your database up, it can really save you in a bind or a really weird situation that you may not be expecting. Check out a few options we think are <em>great</em> below.', 'jet_cct' ); ?></p>

<div id="jet_cct-wizard-options">
    <div class="jet_cct-wizard-option">
        <a href="http://ithemes.com/member/go.php?r=31250&i=l44" target="_blank"> <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/logo_backupbuddy.png" alt="Backup Buddy" />

            <p><?php _e( 'Receive 25% off', 'jet_cct' ); ?></p>

            <p><?php _e( 'Coupon Code', 'jet_cct' ); ?>: <strong>jet_cct25</strong></p>
        </a>

        <p><em><?php _e( 'The all-in-one WordPress backup plugin to easily backup, restore, and migrate to any number of local or external locations.', 'jet_cct' ); ?></em></p>
    </div>
    <div class="jet_cct-wizard-option">
        <a href="http://vaultpress.com/jet_cctframework/" target="_blank"> <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/logo_vaultpress.png" alt="Vaultpress" />

            <p><?php _e( '1 free month', 'jet_cct' ); ?></p>

            <p><strong><?php _e( 'Click to sign up', 'jet_cct' ); ?></strong></p>
        </a>

        <p><em><?php _e( 'A service that provides realtime continuous backups, restores, and security scanning.', 'jet_cct' ); ?></em></p>
    </div>
</div>