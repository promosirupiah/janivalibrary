<?php
global $wpdb;
?>
<div class="wrap jet_cct-admin">
    <script>
        var jet_cct_URL = '<?php echo esc_js( jet_cct_URL ); ?>';
    </script>
    <div id="icon-jet_cct" class="icon32"><br /></div>

    <h2 class="italicized"><?php _e( 'Upgrade jet_cct', 'jet_cct' ); ?></h2>

    <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />

    <div id="jet_cct-wizard-box" class="jet_cct-wizard-steps-3" data-action="jet_cct_admin" data-method="upgrade" data-_wpnonce="<?php echo wp_create_nonce( 'jet_cct-upgrade' ); ?>" data-version="<?php echo $new_version; ?>">
        <div id="jet_cct-wizard-heading">
            <ul>
                <li class="jet_cct-wizard-menu-current" data-step="1">
                    <i></i> <span>1</span> <?php _e( 'Getting Started', 'jet_cct' ); ?>
                    <em></em>
                </li>
                <li data-step="2">
                    <i></i> <span>2</span> <?php _e( 'Prepare', 'jet_cct' ); ?>
                    <em></em>
                </li>
                <li data-step="3">
                    <i></i> <span>3</span> <?php _e( 'Migrate', 'jet_cct' ); ?>
                    <em></em>
                </li>
            </ul>
        </div>
        <div id="jet_cct-wizard-main">

            <!-- Getting Started Panel -->
            <div id="jet_cct-wizard-panel-1" class="jet_cct-wizard-panel">
                <div class="jet_cct-wizard-content jet_cct-wizard-grey">
                    <p>
                        <?php
                            $intro = __( 'Welcome to jet_cct 2.x! We sincerely hope you enjoy over two years worth of planning and work, available to you for <em>free</em>.', 'jet_cct' )
                                . ' ' . __( 'Due to a number of optimizations in jet_cct 2.x, we need to run a few updates to your database. This should not remove or change your existing jet data from 1.x, so if you wish to rollback to jet_cct 1.x - you can easily do that.', 'jet_cct' );

                            echo $intro;
                        ?>
                    </p>
                </div>

                <?php include_once jet_cct_DIR . 'ui/admin/upgrade/backup.php'; ?>
            </div>
            <!-- // Getting Started Panel -->

            <!-- Prepare Panel -->
            <div id="jet_cct-wizard-panel-2" class="jet_cct-wizard-panel">
                <div class="jet_cct-wizard-content">
                    <p><?php _e( 'We will prepare all of your jet_cct, Settings, and Content for migration. If any issues are found they will be displayed below for your review. Be sure to backup your database before continuing onto the next step for Migration.', 'jet_cct' ); ?></p>
                </div>
                <table cellpadding="0" cellspacing="0">
                    <col style="width: 70px">
                    <col style="width: 110px">
                    <col style="width: 580px">
                    <thead>
                        <tr>
                            <th colspan="3"><?php _e( 'Preparing Your Content for Migration', 'jet_cct' ); ?>..</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $jet_cct = $wpdb->get_results( "SELECT `name`, `label` FROM `{$wpdb->prefix}jet_types` ORDER BY `name`" );
                        $count = count( $jet_cct );
                        ?>
                        <tr class="jet_cct-wizard-table-<?php echo esc_attr( 0 < $count ? 'complete' : 'pending' ); ?>" data-upgrade="jet_cct">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count"><?php echo esc_attr( 0 < $count ? $count : '&mdash;' ); ?></td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'jet_cct', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="fields">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Fields', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="relationships">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Relationships', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="index">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Item Indexes', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="templates">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Templates', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="pages">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'jet Pages', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="helpers">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Helpers', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <?php
                        foreach ( $jet_cct as $jet ) {
                            ?>
                            <tr class="jet_cct-wizard-table-pending" data-upgrade="jet" data-jet="<?php echo esc_attr( $jet->name ); ?>">
                                <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                    <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                                </td>
                                <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                                <td class="jet_cct-wizard-name">
                                    <?php echo __( 'Content', 'jet_cct' ) . ': ' . $jet->name; ?>
                                    <span class="jet_cct-wizard-info"></span>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- // Prepare Panel -->

            <!-- Migrate Panel -->
            <div id="jet_cct-wizard-panel-3" class="jet_cct-wizard-panel">
                <div class="jet_cct-wizard-content">
                    <p><?php _e( 'During this process your jet_cct, Settings, and Content will be migrated into the optimized jet_cct 2.x architecture. We will not delete any of your old data, the tables will remain until you choose to clean them up after a successful upgrade.', 'jet_cct' ); ?></p>
                </div>
                <table cellpadding="0" cellspacing="0">
                    <col style="width: 70px">
                    <col style="width: 110px">
                    <col style="width: 580px">
                    <thead>
                        <tr>
                            <th colspan="3"><?php _e( 'Migrating Your Content', 'jet_cct' ); ?>..</th>
                        </tr>
                    </thead>
                    <tbody><!-- complete|pending|active <i></i> -->
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="1_x">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( '1.x Updates', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="jet_cct">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count"><?php echo ( 0 < $count ? $count : '&mdash;' ); ?></td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'jet_cct', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="fields">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Fields', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="relationships">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Relationships', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="settings">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Settings', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="templates">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Templates', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="pages">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'jet Pages', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="helpers">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Helpers', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                        <?php
                        foreach ( $jet_cct as $jet ) {
                            ?>
                            <tr class="jet_cct-wizard-table-pending" data-upgrade="jet" data-jet="<?php echo esc_attr( $jet->name ); ?>">
                                <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                    <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                                </td>
                                <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                                <td class="jet_cct-wizard-name">
                                    <?php echo __( 'Content', 'jet_cct' ) . ': ' . $jet->name; ?>
                                    <span class="jet_cct-wizard-info"></span>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <tr class="jet_cct-wizard-table-pending" data-upgrade="cleanup">
                            <td class="jet_cct-wizard-right jet_cct-wizard-status">
                                <i><img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/spinner.gif" alt="Loading..." /></i>
                            </td>
                            <td class="jet_cct-wizard-right jet_cct-wizard-count">&mdash;</td>
                            <td class="jet_cct-wizard-name">
                                <?php _e( 'Cleanup', 'jet_cct' ); ?>
                                <span class="jet_cct-wizard-info"></span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- // Mirate Panel -->

        </div>
        <div id="jet_cct-wizard-actions">
            <div id="jet_cct-wizard-toolbar">
                <a href="#start" id="jet_cct-wizard-start" class="button button-secondary"><?php _e( 'Start Over', 'jet_cct' ); ?></a> <a href="#next" id="jet_cct-wizard-next" class="button button-primary" data-next="<?php esc_attr_e( 'Next Step', 'jet_cct' ); ?>" data-finished="<?php esc_attr_e( 'Start using jet_cct', 'jet_cct' ); ?>"><?php _e( 'Next Step', 'jet_cct' ); ?></a>
            </div>
            <div id="jet_cct-wizard-finished">
                <?php _e( 'Migration Complete!', 'jet_cct' ); ?>
            </div>
        </div>
    </div>
</div>

<script>
    var jet_cct_admin_wizard_callback = function ( step ) {
        jQuery( '#jet_cct-wizard-start, #jet_cct-wizard-next' ).hide();

        if ( step == 2 ) {
            jQuery( '#jet_cct-wizard-box' ).jet_cctUpgrade( 'prepare' );

            return false;
        }
        else if ( step == 3 ) {
            jQuery( '#jet_cct-wizard-box' ).jet_cctUpgrade( 'migrate' );
        }
    }

    jQuery( function ( $ ) {
        $( '#jet_cct-wizard-box' ).jet_cct( 'wizard' );
    } );
</script>
