<div class="wrap jet_cct-admin">
    <div id="icon-jet_cct" class="icon32"><br /></div>
    <h2><?php _e( 'jet_cct Help', 'jet_cct' ); ?></h2>
    <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />

    <h3><?php _e( 'jet_cct Support' , 'jet_cct'); ?></h3>

    <p><?php _e( 'There are many resources available to help you learn to use jet_cct on our site, <a href="http://jet_cct.io/" target="_blank">jet_cct.io</a>:', 'jet_cct'); ?></p>
    <ul class="ul-disc">
        <li><?php _e('To learn more about using jet_cct, see the <a href="http://jet_cct.io/docs/" target="_blank">documentation</a>, or our <a href="http://jet_cct.io/tutorials/" target="_blank">tutorials section</a>', 'jet_cct'); ?>.

        <li><?php _e( 'To get help with a specific issue, you can ask in our <a href="http://jet_cct.io/forums/" target="_blank">support forums</a>, or in <a href="http://jet_cct.io/forums/chat/" target="_blank">our chat</a>', 'jet_cct'); ?>.

        <li><?php _e('To report <strong>bugs or request features</strong>, go to our <a href="https://github.com/jet_cct-framework/jet_cct/issues?sort=updated&direction=desc&state=open" target="_blank">GitHub</a>.', 'jet_cct' ); ?></li>

        <li><?php _e( "jet_cct is open source, so if you want to get into the code and submit your own fixes or features, go at it, we'd love to have you contribute on our project! With GitHub, it's really easy to contribute back, so why not give it a try?", 'jet_cct'); ?></li>
    </ul>

    <hr />

    <?php
        include_once( ABSPATH . WPINC . '/feed.php' );

        $feed = fetch_feed( 'http://jet_cct.io/forums/forum/jet_cct-2-x/feed/' );

        if ( !is_wp_error( $feed ) ) {
            $max_items = $feed->get_item_quantity( 6 );
            $rss_items = $feed->get_items( 0, $max_items );

            if ( 0 < $max_items ) {
    ?>
        <h3><?php _e( 'Latest Forum Posts at <a href="http://jet_cct.io/forums/forum/general-discussion/jet_cct-2-x/" target="_blank">jet_cct.io</a>', 'jet_cct'); ?></h3>

        <ul class="ul-disc">
            <?php
                foreach ( $rss_items as $item ) {
                    $authors = $item->get_authors();

                    $author_text = '';

                    foreach ( $authors as $author ) {
                        $author_text = '<br /> by ';

                        if ( !empty( $author->link ) )
                            $author_text .= '<a href="' . $author->link . '" target="_blank">';

                        $author_text .= $author->name;

                        if ( !empty( $author->link ) )
                            $author_text .= '</a>';
                    }
            ?>
                <li>
                    <a href="<?php echo esc_url( $item->get_permalink() ); ?>"><?php echo esc_html( $item->get_title() ); ?></a>
                    <?php echo $author_text; ?>
                    <br />
                    on <?php echo $item->get_date( 'm/d/Y' ); ?>
                </li>
            <?php
                }
            ?>
        </ul>

        <hr />
    <?php
            }
        }

        $feed = fetch_feed( 'https://github.com/jet_cct-framework/jet_cct/commits/' . jet_cct_GITHUB_BRANCH . '.atom' );

        if ( !is_wp_error( $feed ) ) {
            $max_items = $feed->get_item_quantity( 6 );
            $rss_items = $feed->get_items( 0, $max_items );

            if ( 0 < $max_items ) {
    ?>
        <h3><?php _e( 'Latest Activity on <a href="http://github.com/jet_cct-framework/jet_cct" target="_blank">GitHub</a>', 'jet_cct' ); ?></h3>

        <ul class="ul-disc">
            <?php
                foreach ( $rss_items as $item ) {
                    $authors = $item->get_authors();

                    $author_text = '';

                    foreach ( $authors as $author ) {
                        $author_text = '<br /> by ';

                        if ( !empty( $author->link ) )
                            $author_text .= '<a href="' . $author->link . '" target="_blank">';

                        $author_text .= $author->name;

                        if ( !empty( $author->link ) )
                            $author_text .= '</a>';
                    }
            ?>
                <li>
                    <a href="<?php echo esc_url( $item->get_permalink() ); ?>">Commit</a>: <?php echo esc_html( $item->get_title() ); ?>
                    <?php echo $author_text; ?>
                    <br />
                    on <?php echo $item->get_date( 'm/d/Y' ); ?>
                </li>
            <?php
                }
            ?>
        </ul>
    <?php
            }
        }
    ?>

</div>
