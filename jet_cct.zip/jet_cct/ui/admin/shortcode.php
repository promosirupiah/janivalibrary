<script type="text/javascript">
    var jet_cct_shortcode_first = true;

    jQuery( function ( $ ) {
        $( '#jet_cct_insert_shortcode' ).on( 'click', function ( e ) {
            var form = $( '#jet_cct_shortcode_form_element' ),
                use_case = $( '#jet_cct_use_case_selector' ).val(),
                jet_select = $( '#jet_select' ).val(),
                slug = $( '#jet_slug' ).val(),
                orderby = $( '#jet_orderby' ).val(),
                limit = $( '#jet_limit' ).val(),
                where = $( '#jet_where' ).val(),
                template = '',
                jet_cct_page = '',
                template_custom = $( '#jet_template_custom' ).val(),
                field = $( '#jet_field' ).val(),
                fields = $( '#jet_fields' ).val(),
                label = $( '#jet_label' ).val(),
                thank_you = $( '#jet_thank_you' ).val(),
                view = $( '#jet_view' ).val(),
                cache_mode = $( '#jet_cache_mode' ).val(),
                expires = $( '#jet_expires' ).val();
                template = $( '#jet_template' ).val();

            <?php if ( class_exists( 'jet_cct_Pages' ) ) { ?>
                jet_cct_page = $( '#jet_cct_page' ).val();
            <?php } ?>

            // Slash and burn
            jet_select = ( jet_select + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            slug = ( slug + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            orderby = ( orderby + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            limit = ( limit + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            where = ( where + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            template = ( template + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            jet_cct_page = ( jet_cct_page + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            field = ( field + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            fields = ( fields + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            label = ( label + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            thank_you = ( thank_you + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            view = ( view + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            cache_mode = ( cache_mode + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );
            expires = ( expires + '' ).replace( /\\"/g, '\\$&' ).replace( /\u0000/g, '\\0' );

            // Validate the form
            var errors = [];

            switch ( use_case ) {
                case 'single':
                    if ( !jet_select || !jet_select.length ) {
                        errors.push( "jet" );
                    }
                    if ( !slug || !slug.length ) {
                        errors.push( "Slug or ID" );
                    }
                    if ( ( !template || !template.length ) && ( !template_custom || !template_custom.length) ) {
                        errors.push( "Template" );
                    }
                    break;

                case 'list':
                    if ( !jet_select || !jet_select.length ) {
                        errors.push( "jet" );
                    }
                    if ( ( !template || !template.length ) && ( !template_custom || !template_custom.length) ) {
                        errors.push( "Template" );
                    }
                    break;

                case 'field':
                    if ( !jet_select || !jet_select.length ) {
                        errors.push( "jet" );
                    }
                    if ( !slug || !slug.length ) {
                        errors.push( "ID or Slug" );
                    }
                    if ( !field || !field.length ) {
                        errors.push( "Field" );
                    }
                    break;

                case 'field-current':
                    if ( !field || !field.length ) {
                        errors.push( "Field" );
                    }
                    break;

                case 'form':
                    if ( !jet_select || !jet_select.length ) {
                        errors.push( "jet" );
                    }
                    break;

                case 'view':
                    if ( !view || !view.length ) {
                        errors.push( "File to include" );
                    }
                    break;

                case 'page':
                    if ( !jet_cct_page || !jet_cct_page.length ) {
                        errors.push( "jet Page" );
                    }
                    break;
            }

            if ( errors.length ) {
                alert( "The following fields are required:\n" + errors.join( "\n" ) );

                e.preventDefault();

                return false;
            }

            var shortcode = '[jet_cct';

            if ( 'single' == use_case ) {
                if ( jet_select.length )
                    shortcode += ' name="' + jet_select + '"';

                if ( slug.length )
                    shortcode += ' slug="' + slug + '"';

                if ( template.length )
                    shortcode += ' template="' + template + '"';
            }
            else if ( 'list' == use_case ) {
                if ( jet_select.length )
                    shortcode += ' name="' + jet_select + '"';

                if ( orderby.length )
                    shortcode += ' orderby="' + orderby + '"';

                if ( limit.length )
                    shortcode += ' limit="' + limit + '"';

                if ( where.length )
                    shortcode += ' where="' + where + '"';

                if ( template.length )
                    shortcode += ' template="' + template + '"';

            }
            else if ( 'field' == use_case ) {
                if ( jet_select.length )
                    shortcode += ' name="' + jet_select + '"';

                if ( slug.length )
                    shortcode += ' slug="' + slug + '"';

                if ( field.length )
                    shortcode += ' field="' + field + '"';

            }
            else if ( 'field-current' == use_case ) {
                if ( field.length )
                    shortcode += ' field="' + field + '"';

            }
            else if ( 'form' == use_case ) {
                // Make shortcode into [jet_cct-form]
                shortcode += '-form';

                if ( jet_select.length )
                    shortcode += ' name="' + jet_select + '"';

                if ( slug.length )
                    shortcode += ' slug="' + slug + '"';

                if ( fields.length )
                    shortcode += ' fields="' + fields + '"';

                if ( label.length )
                    shortcode += ' label="' + label + '"';

                if ( thank_you.length )
                    shortcode += ' thank_you="' + thank_you + '"';

            }
            else if ( 'view' == use_case ) {
                if ( view.length )
                    shortcode += ' view="' + view + '"';

                if ( cache_mode.length && 'none' != cache_mode ) {
                    shortcode += ' cache_mode="' + cache_mode + '"';

                    if ( expires.length )
                        shortcode += ' expires="' + expires + '"';
                }
            }
            else if ( 'page' == use_case ) {
                if ( jet_cct_page.length )
                    shortcode += ' jet_cct_page="' + jet_cct_page + '"';
            }

            shortcode += ']';

            if ( ( 'single' == use_case || 'list' == use_case ) && template_custom && template_custom.length )
                shortcode += '<br />' + template_custom.replace( /\n/g, '<br />' ) + '<br />[/jet_cct]';

            window.send_to_editor( shortcode );

            e.preventDefault();
        } );

        $( '#jet_cache_mode' ).on( 'change', function () {
            var $this = $( this );

            if ( 'none' == $this.val() ) {
                $( this ).closest( '.jet_cct-section' ).addClass( 'hide' );
            }
            else {
                $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
            }
        } );

        var $useCaseSelector = $( '#jet_cct_use_case_selector' );

        $useCaseSelector.on( 'change', function () {
            var val = $( this ).val();

            $( '.jet_cct-section' ).addClass( 'hide' );

            switch ( val ) {
                case 'single':
                    $( '#jet_select, #jet_slug, #jet_template, #jet_template_custom, #jet_cct_insert_shortcode' ).each( function () {
                        $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                    } )
                    break;

                case 'list':
                    $( '#jet_select, #jet_limit, #jet_orderby, #jet_where, #jet_template, #jet_template_custom, #jet_cache_mode, #jet_expires, #jet_cct_insert_shortcode' ).each( function () {
                        $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                    } )
                    break;

                case 'field':
                    $( '#jet_select, #jet_slug, #jet_field, #jet_cct_insert_shortcode' ).each( function () {
                        $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                    } )
                    break;

                case 'field-current':
                    $( '#jet_field, #jet_cct_insert_shortcode' ).each( function () {
                        $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                    } )
                    break;

                case 'form':
                    $( '#jet_select, #jet_slug, #jet_fields, #jet_label, #jet_thank_you, #jet_cct_insert_shortcode' ).each( function () {
                        $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                    } )
                    break;

                case 'view':
                    $( '#jet_view, #jet_cache_mode, #jet_expires, #jet_cct_insert_shortcode' ).each( function () {
                        $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                    } )
                    break;

                <?php if ( class_exists( 'jet_cct_Pages' ) ) { ?>
                    case 'page':
                        $( '#jet_cct_page, #jet_cct_insert_shortcode' ).each( function () {
                            $( this ).closest( '.jet_cct-section' ).removeClass( 'hide' );
                        } )
                        break;
                <?php } ?>
            }

            // Fix for TB ajaxContent not picking up the height on the first open
            if ( jet_cct_shortcode_first ) {
                $( '#TB_ajaxContent' ).css( { width: 'auto', height: '91%' } );

                jet_cct_shortcode_first = false;
            }
        } );
    } );
</script>

<style type="text/css">
    .jet_cct-shortcode h3.popup-header {
        font-family: "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", sans-serif;
        font-weight: normal;
        color: #5a5a5a;
        font-size: 1.8em;
        background: url(<?php echo esc_url( jet_cct_URL ); ?>ui/images/icon32.png) top left no-repeat;
        padding: 8px 0 5px 36px;
        margin-top: 0;
    }

    .jet_cct-shortcode div.jet_cct-section, div.jet_cct-select, div.jet_cct-header {
        padding: 15px 15px 0 15px;
    }

    .jet_cct-shortcode div.jet_cct-section.hide {
        display: none;
    }

    .jet_cct-shortcode .jet_cct-section label {
        display: inline-block;
        width: 120px;
        font-weight: bold;
    }

    a#jet_cct_insert_shortcode {
        color: white !important;
    }

    .jet_cct-shortcode strong.red {
        color: red;
    }
</style>

<div id="jet_cct_shortcode_form" style="display: none;">
    <div class="wrap jet_cct-shortcode">
        <div>
            <div class="jet_cct-header">
                <h3 class="popup-header"><?php _e( 'jet_cct &raquo; Embed', 'jet_cct' ); ?></h3>
            </div>

            <form id="jet_cct_shortcode_form_element">
                <div class="jet_cct-select">
                    <label for="jet_cct_use_case_selector"><?php _e( 'What would you like to do?', 'jet_cct' ); ?></label>

                    <select id="jet_cct_use_case_selector">
                        <option value="single"><?php _e( 'Display a single jet item', 'jet_cct' ); ?></option>
                        <option value="list"><?php _e( 'List multiple jet items', 'jet_cct' ); ?></option>
                        <option value="field"><?php _e( 'Display a field from a single jet item', 'jet_cct' ); ?></option>
                        <option value="field-current" SELECTED><?php _e( 'Display a field from this item', 'jet_cct' ); ?></option>
                        <option value="form"><?php _e( 'Display a form for creating and editing jet items', 'jet_cct' ); ?></option>
                        <option value="view"><?php _e( 'Include a file from a theme, with caching options', 'jet_cct' ); ?></option>
                        <?php if ( class_exists( 'jet_cct_Pages' ) ) { ?>
                            <option value="page"><?php _e( 'Embed content from a jet_cct Page', 'jet_cct' ); ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="jet_cct-section hide">
                    <?php
                        $api = jet_cct_api();
                        $all_jet_cct = $api->load_jet_cct( array( 'names' => true ) );
                        $jet_count = count( $all_jet_cct );
                    ?>
                    <label for="jet_select"><?php _e( 'Choose a jet', 'jet_cct' ); ?></label>

                    <?php if ( $jet_count > 0 ) { ?>
                        <select id="jet_select" name="jet_select">
                            <?php foreach ( $all_jet_cct as $jet_name => $jet_label ) { ?>
                                <option value="<?php echo esc_attr( $jet_name ); ?>">
                                    <?php echo esc_html( $jet_label . ' (' . $jet_name . ')' ); ?>
                                </option>
                            <?php } ?>
                        </select>
                    <?php
                        }
                        else {
                    ?>
                        <strong class="red" id="jet_select"><?php _e( 'None Found', 'jet_cct' ); ?></strong>
                    <?php } ?>
                </div>

                <?php if ( class_exists( 'jet_cct_Templates' ) ) { ?>
                    <div class="jet_cct-section hide">
                        <?php
                        $templates = $api->load_templates();
                        $template_count = count( $templates );
                        ?>
                        <label for="jet_template"><?php _e( 'Template', 'jet_cct' ); ?></label>

                        <select id="jet_template" name="jet_template">
                            <option value="" SELECTED>- <?php _e( 'Custom Template', 'jet_cct' ); ?> -</option>

                            <?php foreach ( $templates as $tmpl ) { ?>
                                <option value="<?php echo esc_attr( $tmpl[ 'name' ] ); ?>">
                                    <?php echo esc_html( $tmpl[ 'name' ] ); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                <?php
                    }
                    else {
                ?>
                    <div class="jet_cct-section hide">
                        <label for="jet_template"><?php _e( 'Template', 'jet_cct' ); ?></label>

                        <input type="text" id="jet_template" name="jet_template" />
                    </div>
                <?php
                    }
                ?>

                <div class="jet_cct-section hide">
                    <label for="jet_template_custom"><?php _e( 'Custom Template', 'jet_cct' ); ?></label>

                    <textarea name="jet_template_custom" id="jet_template_custom" cols="10" rows="10" class="widefat"></textarea>
                </div>

                <?php if ( class_exists( 'jet_cct_Pages' ) ) { ?>
                    <div class="jet_cct-section hide">
                        <?php
                        $pages = $api->load_pages();
                        $page_count = count( $pages );
                        ?>
                        <label for="jet_cct_page"><?php _e( 'jet_cct Page', 'jet_cct' ); ?></label>

                        <select id="jet_cct_page" name="jet_cct_page">
                            <?php foreach ( $pages as $page ) { ?>
                                <option value="<?php echo esc_attr( $page[ 'name' ] ); ?>">
                                    <?php echo esc_html( $page[ 'name' ] ); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                <?php } ?>

                <div class="jet_cct-section hide">
                    <label for="jet_slug"><?php _e( 'ID or Slug', 'jet_cct' ); ?></label>

                    <input type="text" id="jet_slug" name="jet_slug" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_limit"><?php _e( 'Limit', 'jet_cct' ); ?></label>

                    <input type="text" id="jet_limit" name="jet_limit" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_orderby"><?php _e( 'Order By', 'jet_cct' ); ?></label>

                    <input type="text" id="jet_orderby" name="jet_orderby" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_where"><?php _e( 'Where', 'jet_cct' ); ?></label>

                    <input type="text" name="jet_where" id="jet_where" />
                </div>

                <div class="jet_cct-section">
                    <label for="jet_field"><?php _e( 'Field', 'jet_cct' ); ?></label>

                    <input type="text" name="jet_field" id="jet_field" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_fields"><?php _e( 'Fields (comma-separated)', 'jet_cct' ); ?></label>

                    <input type="text" id="jet_fields" name="jet_fields" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_label"><?php _e( 'Submit Label', 'jet_cct' ); ?></label>

                    <input type="text" id="jet_label" name="jet_label" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_thank_you"><?php _e( 'Thank You URL upon submission', 'jet_cct' ); ?></label>

                    <input type="text" id="jet_thank_you" name="jet_thank_you" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_view"><?php _e( 'File to include', 'jet_cct' ); ?></label>

                    <input type="text" name="jet_view" id="jet_view" />
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_cache_mode"><?php _e( 'Cache Type', 'jet_cct' ); ?></label>

                    <?php
                        $cache_modes = array(
                            'none' => __( 'Disable Caching', 'jet_cct' ),
                            'cache' => __( 'Object Cache', 'jet_cct' ),
                            'transient' => __( 'Transient', 'jet_cct' ),
                            'site-transient' => __( 'Site Transient', 'jet_cct' )
                        );

                        $default_cache_mode = apply_filters( 'jet_cct_shortcode_default_cache_mode', 'none' );
                    ?>
                    <select id="jet_cache_mode" name="jet_cache_mode">
                        <?php foreach ( $cache_modes as $cache_mode_option => $cache_mode_label ): ?>
                            <option value="<?php echo esc_attr( $cache_mode_option ); ?>"<?php selected( $default_cache_mode, $cache_mode_option ); ?>>
                                <?php echo esc_html( $cache_mode_label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="jet_cct-section hide">
                    <label for="jet_expires"><?php _e( 'Cache Expiration (in seconds)', 'jet_cct' ); ?></label>

                    <input type="text" name="jet_expires" id="jet_expires" value="<?php echo ( 60 * 5 ); ?>" />
                </div>

                <div class="jet_cct-section" style="text-align: right;">
                    <a class="button-primary" id="jet_cct_insert_shortcode" href="#insert-shortcode"><?php _e( 'Insert', 'jet_cct' ); ?></a>
                </div>
            </form>
        </div>
    </div>
</div>
