<?php
$depends_on = false;

foreach ( $field_options as $field_name => $field_option ) {
    if ( false !== strpos( $field_name, 'helper' ) && !class_exists( 'jet_cct_Helpers' ) )
        continue;
    elseif ( $field_option[ 'developer_mode' ] && !jet_cct_developer() )
        continue;

    $field_option = (array) $field_option;

    $depends = jet_cctForm::dependencies( $field_option, ( !isset( $jet_cct_tab_form ) ? 'field-data-' : '' ) );

    if ( ( !empty( $depends_on ) || !empty( $depends ) ) && $depends_on != $depends ) {
        if ( !empty( $depends_on ) ) {
            ?>
        </div>
        <?php
        }
        if ( !empty( $depends ) ) {
            ?>
    <div class="jet_cct-field-option-container <?php echo esc_attr( $depends ); ?>">
<?php
        }
    }

    if ( !is_array( $field_option[ 'group' ] ) ) {
        $row_name = $field_name;

        if ( !isset( $jet_cct_tab_form ) )
            $row_name = 'field_data[' . $jet_cct_i . '][' . $field_name . ']';

        $value = $field_option[ 'default' ];

        if ( isset( $field_option[ 'value' ] ) && 0 < strlen( $field_option[ 'value' ] ) )
            $value = $field_option[ 'value' ];
        else
            $value = jet_cct_var_raw( $field_name, $field, $value );

        if ( in_array( $field_option[ 'type' ], jet_cctForm::file_field_types() ) ) {
            if ( is_array( $value ) && !isset( $value[ 'id' ] ) ) {
                foreach ( $value as $k => $v ) {
                    if ( isset( $v[ 'id' ] ) )
                        $value[ $k ] = $v[ 'id' ];
                }
            }
        }
        ?>
        <div class="jet_cct-field-option">
            <?php echo jet_cctForm::row( $row_name, $value, $field_option[ 'type' ], $field_option ); ?>
        </div>
        <?php
    }
    else {
        ?>
        <div class="jet_cct-field-option-group">
            <p class="jet_cct-field-option-group-label">
                <?php echo $field_option[ 'label' ]; ?>
            </p>

            <div class="jet_cct-pick-values jet_cct-pick-checkbox">
                <ul>
                    <?php
                    foreach ( $field_option[ 'group' ] as $field_group_name => $field_group_option ) {
                        $field_group_option = (array) $field_group_option;

                        if ( 'boolean' != $field_group_option[ 'type' ] )
                            continue;

                        $field_group_option[ 'boolean_yes_label' ] = $field_group_option[ 'label' ];

                        $depends_option = jet_cctForm::dependencies( $field_group_option, ( !isset( $jet_cct_tab_form ) ? 'field-data-' : '' ) );

                        $row_name = $field_group_name;

                        if ( !isset( $jet_cct_tab_form ) )
                            $row_name = 'field_data[' . $jet_cct_i . '][' . $field_group_name . ']';

                        $value = $field_group_option[ 'default' ];

                        if ( isset( $field_group_option[ 'value' ] ) && 0 < strlen( $field_group_option[ 'value' ] ) )
                            $value = $field_group_option[ 'value' ];
                        else
                            $value = jet_cct_var_raw( $field_group_name, $field, $value );

                        ?>
                        <li class="<?php echo esc_attr( $depends_option ); ?>">
                            <?php echo jet_cctForm::field( $row_name, $value, $field_group_option[ 'type' ], $field_group_option ); ?>
                        </li>
                        <?php
                    }
                    ?>
                </ul>
            </div>
        </div>
        <?php
    }

    if ( false !== $depends_on || !empty( $depends ) )
        $depends_on = $depends;
}

if ( !empty( $depends_on ) ) {
    ?>
    </div>
<?php
}
