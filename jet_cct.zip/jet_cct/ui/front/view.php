<?php
wp_enqueue_style( 'jet_cct-form', false, array(), false, true );

/**
 * @var array $fields
 * @var jet_cct $jet
 */
?>
<div class="jet_cct-submittable-fields">
	<ul class="jet_cct-form-fields">
		<?php
			foreach ( $fields as $field ) {
				if ( isset( $field[ 'custom_display' ] ) && is_callable( $field[ 'custom_display' ] ) ) {
					$value = call_user_func_array( $field[ 'custom_display' ], array( $jet->row(), $jet, $jet->field( $field[ 'name' ] ), $field[ 'name' ], $field ) );
				}
				else {
					$value = $jet->display( $field[ 'name' ] );
				}
		?>
			<li class="jet_cct-field <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>">
				<div class="jet_cct-field-label">
					<strong><?php echo $field[ 'label' ]; ?></strong>
				</div>

				<div class="jet_cct-field-input">
					<?php echo $value; ?>
				</div>
			</li>
		<?php } ?>
	</ul>
</div>
