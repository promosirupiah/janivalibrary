<span class="jet_cct-pagination-simple <?php echo esc_attr( $params->class ); ?>">
    <?php

    if ( 1 < $params->page ) {
        if ( 1 === $params->first_last ) {
            ?>
            <a href="<?php echo esc_url( jet_cct_query_arg( array( $params->page_var => 1 ) ) ); ?>" class="jet_cct-pagination-number jet_cct-pagination-first <?php echo esc_attr( $params->link_class ); ?>"><?php echo $params->first_text; ?></a>
            <?php } ?>
        <a href="<?php echo esc_url( jet_cct_query_arg( array( $params->page_var => ( $params->page - 1 ) ) ) ); ?>" class="jet_cct-pagination-number jet_cct-pagination-prev <?php echo esc_attr( $params->link_class ); ?>"><?php echo $params->prev_text; ?></a>
        <?php
    }

    if ( $params->page < $params->total ) {
        ?>

        <a href="<?php echo esc_url( jet_cct_query_arg( array( $params->page_var => ( $params->page + 1 ) ) ) ); ?>" class="jet_cct-pagination-number jet_cct-pagination-next <?php echo esc_attr( $params->link_class ); ?>"><?php echo $params->next_text; ?></a>
        <?php if ( 1 === $params->first_last ) {
            ?>
            <a href="<?php echo esc_url( jet_cct_query_arg( array( $params->page_var => $params->total ) ) ); ?>" class="jet_cct-pagination-number jet_cct-pagination-last <?php echo esc_attr( $params->link_class ); ?>"><?php echo $params->last_text; ?></a>
            <?php } ?>
        <?php
    }
    ?>

</span>
