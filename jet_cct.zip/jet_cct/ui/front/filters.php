    <form method="get" class="jet_cct-form-filters jet_cct-form-filters-<?php echo esc_attr( $jet->jet ); ?>" action="<?php echo esc_attr( $action ); ?>">
        <input type="hidden" name="type" value="<?php echo esc_attr( $jet->jet ); ?>" />

        <?php
            foreach ( $fields as $name => $field ) {
                if ( 'pick' == $field[ 'type' ] && 'pick-custom' != $field[ 'pick_object' ] && !empty( $field[ 'pick_object' ] ) ) {
                    $field[ 'options' ][ 'pick_format_type' ] = 'single';
                    $field[ 'options' ][ 'pick_format_single' ] = 'dropdown';
                    $field[ 'options' ][ 'pick_select_text' ] = '-- ' . $field[ 'label' ] . ' --';

                    $filter = jet_cct_var_raw( 'filter_' . $name, 'get', '' );

                    echo jet_cctForm::field( 'filter_' . $name, $filter, 'pick', $field, $jet->jet, $jet->id() );
                }
            }
        ?>

        <input type="text" class="jet_cct-form-filters-search" name="<?php echo esc_attr( $jet->search_var ); ?>" value="<?php echo esc_attr( $search ); ?>" />

        <input type="submit" class="jet_cct-form-filters-submit" value="<?php echo esc_attr( $label ); ?>" />
    </form>