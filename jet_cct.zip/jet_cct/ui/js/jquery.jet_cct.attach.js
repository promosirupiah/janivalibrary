var jet_cct_file_context = false; // tracks whether or not we've got a thickbox displayed in our context
var jet_cct_file_thickbox_modder; // stores our interval for making necessary changes to thickbox content

// handle our thickbox mods
function jet_cct_attachments ( src, file_limit ) {
    var jet_cct_thickbox = jQuery( '#TB_iframeContent' ).contents();

    // add quick add text so we dont have to expand each line item
    var wp_media_show_links = jet_cct_thickbox.find( 'div.media-item a.describe-toggle-on' );

    // loop through each 'Show' link and check if we added an 'Add' action next to it
    for ( var x = 0, len = wp_media_show_links.length; x < len; x++ ) {
        var wp_media_show = jQuery( wp_media_show_links[x] );

        if ( wp_media_show.data( 'jet_cct-injected-quick-add') !== true ) {
            // Create 'Add' link
            var jet_cct_file_quick_add = jQuery( '<a href="#">Add</a>' ).addClass( 'jet_cct-quick-add' );

            jet_cct_file_quick_add.bind( 'click', function( e ) {
                var item = jQuery( this );
                var item_parent = item.parent();

                item.fadeOut( 'fast', function() {

                    // Not sure if the close link should be there for each link?
                    item.before( '<span class="jet_cct-attached jet_cct-quick-add">Added!</span>' );
                    //item.before( '<span class="jet_cct-attached jet_cct-quick-add">Added! <a href="#">close this box</a>.</span>' );

                    item.remove(); }
                );

                var wp_media_meta = item_parent;

                jet_cct_thickbox_send( wp_media_meta, e );

                item_parent.find( 'span.jet_cct-attached a' ).on( 'click', function ( e ) {
                    parent.eval( 'tb_remove()' );
                } );

                item_parent.find( 'span.jet_cct-attached' ).delay( 6000 ).fadeOut( 'fast' );

                e.preventDefault();
            } );

            wp_media_show.after( jet_cct_file_quick_add );

            wp_media_show.data( 'jet_cct-injected-quick-add', true );
        }
    }

    jet_cct_thickbox.find( 'td.savesend input' ).unbind( 'click' ).click( function ( e ) {
        var wp_media_meta = jQuery( this ).parent().parent().parent();

        jet_cct_thickbox_send( wp_media_meta, e );
    } );

    function jet_cct_thickbox_send ( wp_media_meta, e ) {
        // grab our meta as per the Media library
        var wp_media_title = wp_media_meta.find( 'tr.post_title td.field input' ).val();
        //var wp_media_caption = wp_media_meta.find( 'tr.post_excerpt td.field input' ).val();
        var wp_media_id = wp_media_meta.find( 'td.imgedit-response' ).attr( 'id' ).replace( 'imgedit-response-', '' );
        var wp_media_thumb = wp_media_meta.parent().find( 'img.thumbnail' ).attr( 'src' );
        var wp_media_link = wp_media_meta.find( 'tr.url td.field input.urlfield' ).val();

        // use the data we found to form a new jet_cct file entry and append it to the DOM
        var source = jQuery( '#' + src + '-handlebars' ).html();

        var binding = {
            id : wp_media_id,
            name : wp_media_title,
            icon : wp_media_thumb
        };

        var tmpl = Handlebars.compile( source );

        jet_cct_file_context.prepend( tmpl( binding ) );

        if ( !jet_cct_file_context.is( ':visible' ) )
            jet_cct_file_context.show().removeClass( 'hidden' );

        jet_cct_file_context.find( 'li#jet_cct-file-' + wp_media_id ).slideDown( 'fast' );

        var items = jet_cct_file_context.find( 'li.jet_cct-file' ),
            itemCount = items.size();

        if ( 0 < file_limit && itemCount > file_limit ) {
            items.each( function ( idx, elem ) {
                if ( idx + 1 > file_limit ) {
                    jQuery( elem ).remove();
                }
            } );
        }

        if ( 1 < file_limit || file_limit == 0 ) {
            jQuery( this ).after( ' <span class="jet_cct-attached">Added! Choose another or <a href="#">close this box</a>.</span>' );
            jQuery( this ).parent().find( 'span.jet_cct-attached a' ).on( 'click', function ( e ) {
                parent.eval( 'tb_remove()' );

                e.preventDefault();
            } );
            jQuery( this ).parent().find( 'span.jet_cct-attached' ).delay( 6000 ).fadeOut( 'fast' );
        }
        else {
            parent.eval( 'tb_remove()' );
        }

        e.preventDefault();
    }

    // update button
    if ( jet_cct_thickbox.find( '.media-item .savesend input[type=submit], #insertonlybutton' ).length ) {
        jet_cct_thickbox.find( '.media-item .savesend input[type=submit], #insertonlybutton' ).val( 'Select' );
    }

    // hide the URL tab
    if ( jet_cct_thickbox.find( '#tab-type_url' ).length )
        jet_cct_thickbox.find( '#tab-type_url' ).hide();

    // we need to ALWAYS get the fullsize since we're retrieving the guid
    // if the user inserts an image somewhere else and chooses another size, everything breaks, so we'll force it
    if ( jet_cct_thickbox.find( 'tr.post_title' ).length ) {
        jet_cct_thickbox.find( 'tr.image-size input[value="full"]' ).prop( 'checked', true );
        jet_cct_thickbox.find( 'tr.image-size,tr.post_content,tr.url,tr.align,tr.submit>td>a.del-link' ).hide();
    }

    // was the thickbox closed?
    if ( jet_cct_thickbox.length == 0 && jet_cct_file_context ) {
        clearInterval( jet_cct_file_thickbox_modder );
        jet_cct_file_context = false;
    }
}
