// change the menu position based on the scroll positon
window.onscroll = function () {
    if ( window.XMLHttpRequest ) {
        if ( document.documentElement.scrollTop > 33 || self.pageYOffset > 33 ) {
            jQuery( '.jet_cct_floatmenu' ).css( 'position', 'fixed' );
            jQuery( '.jet_cct_floatmenu' ).css( 'top', '52px' );
            jQuery( '.jet_cct_floatmenu' ).css( 'right', '315px' );
        }
        else if ( document.documentElement.scrollTop < 33 || self.pageYOffset < 33 ) {
            jQuery( '.jet_cct_floatmenu' ).css( 'position', 'relative' );
            jQuery( '.jet_cct_floatmenu' ).css( 'top', 'auto' );
            jQuery( '.jet_cct_floatmenu' ).css( 'right', 'auto' );
            //jQuery('.jet_cct_floatmenu').css('top','112px');
            //jQuery('.jet_cct_floatmenu').css('right','15px');
        }
    }
}