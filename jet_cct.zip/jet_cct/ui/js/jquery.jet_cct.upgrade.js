(function ( $ ) {
    var methods = {
        prepare : function () {
            var jet_cct_ajaxurl = $( '#jet_cct-wizard-box' ).data( 'url' );

            if ( 'undefined' != typeof jet_cct_ajaxurl )
                jet_cct_ajaxurl = jet_cct_ajaxurl.replace( /\?nojs\=1/, '?jet_cct_ajax=1' );

            if ( 'undefined' != typeof ajaxurl && ('undefined' == typeof jet_cct_ajaxurl || '' == jet_cct_ajaxurl || '?jet_cct_ajax=1' == jet_cct_ajaxurl || document.location.href == jet_cct_ajaxurl || document.location.href.replace( /\?nojs\=1/, '?jet_cct_ajax=1' ) == jet_cct_ajaxurl) )
                jet_cct_ajaxurl = ajaxurl + '?jet_cct_ajax=1';

            if ( $( '#jet_cct-wizard-panel-2 table tbody tr.jet_cct-wizard-table-pending' )[ 0 ] ) {
                var $row = $( '#jet_cct-wizard-panel-2 table tbody tr.jet_cct-wizard-table-pending' ).first();

                $row.removeClass( 'jet_cct-wizard-table-pending' ).addClass( 'jet_cct-wizard-table-active' );

                var postdata = {
                    'action' : $( '#jet_cct-wizard-box' ).data( 'action' ),
                    'method' : $( '#jet_cct-wizard-box' ).data( 'method' ),
                    '_wpnonce' : $( '#jet_cct-wizard-box' ).data( '_wpnonce' ),
                    'step' : 'prepare',
                    'type' : $row.data( 'upgrade' ),
                    'jet' : '',
                    'version' : $( '#jet_cct-wizard-box' ).data( 'version' )
                };

                if ( 'undefined' != typeof $row.data( 'jet' ) )
                    postdata[ 'jet' ] = $row.data( 'jet' );

                $.ajax( {
                    type : 'POST',
                    url : jet_cct_ajaxurl,
                    cache : false,
                    data : postdata,
                    success : function ( d ) {
                        if ( -1 == d.indexOf( '<e>' ) && -1 != d ) {
                            $row.find( 'td.jet_cct-wizard-count' ).text( d );
                            $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-complete' );

                            if ( 'undefined' == typeof $row.data( 'jet' ) )
                                $( '#jet_cct-wizard-panel-3 table tbody tr[data-upgrade="' + $row.data( 'upgrade' ) + '"] td.jet_cct-wizard-count' ).text( d );
                            else
                                $( '#jet_cct-wizard-panel-3 table tbody tr[data-jet="' + $row.data( 'jet' ) + '"] td.jet_cct-wizard-count' ).text( d );

                            // Run next
                            return methods[ 'prepare' ]();
                        }
                        else {
                            $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-warning' );
                            $row.find( 'td span.jet_cct-wizard-info' ).html( d.replace( '<e>', '' ).replace( '</e>', '' ) );
                            if ( window.console ) console.log( d.replace( '<e>', '' ).replace( '</e>', '' ) );

                            // Run next
                            return methods[ 'prepare' ]();
                        }
                    },
                    error : function () {
                        $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-error' );
                        $row.find( 'td span.jet_cct-wizard-info' ).text( 'Unable to process request, please try again.' );
                    },
                    dataType : 'html'
                } );
            }
            else {
                $( '#jet_cct-wizard-next' ).show();
            }
        },
        migrate : function ( postdata, $row ) {
            var jet_cct_ajaxurl = $( '#jet_cct-wizard-box' ).data( 'url' );

            if ( 'undefined' != typeof jet_cct_ajaxurl )
                jet_cct_ajaxurl = jet_cct_ajaxurl.replace( /\?nojs\=1/, '?jet_cct_ajax=1' );

            if ( 'undefined' != typeof ajaxurl && ('undefined' == typeof jet_cct_ajaxurl || '' == jet_cct_ajaxurl || '?jet_cct_ajax=1' == jet_cct_ajaxurl || document.location.href == jet_cct_ajaxurl || document.location.href.replace( /\?nojs\=1/, '?jet_cct_ajax=1' ) == jet_cct_ajaxurl) )
                jet_cct_ajaxurl = ajaxurl + '?jet_cct_ajax=1';

            if ( 'undefined' != typeof postdata || $( '#jet_cct-wizard-panel-3 table tbody tr.jet_cct-wizard-table-pending' )[ 0 ] ) {
                if ( 'undefined' == typeof $row )
                    var $row = $( '#jet_cct-wizard-panel-3 table tbody tr.jet_cct-wizard-table-pending' ).first();

                if ( 'undefined' == typeof postdata ) {
                    $row.removeClass( 'jet_cct-wizard-table-pending' ).addClass( 'jet_cct-wizard-table-active' );

                    var postdata = {
                        'action' : $( '#jet_cct-wizard-box' ).data( 'action' ),
                        'method' : $( '#jet_cct-wizard-box' ).data( 'method' ),
                        '_wpnonce' : $( '#jet_cct-wizard-box' ).data( '_wpnonce' ),
                        'step' : 'migrate',
                        'type' : $row.data( 'upgrade' ),
                        'jet' : '',
                        'version' : $( '#jet_cct-wizard-box' ).data( 'version' )
                    };

                    if ( 'undefined' != typeof $row.data( 'jet' ) )
                        postdata[ 'jet' ] = $row.data( 'jet' );
                }

                $.ajax( {
                    type : 'POST',
                    url : jet_cct_ajaxurl,
                    cache : false,
                    data : postdata,
                    success : function ( d ) {
                        if ( -1 == d.indexOf( '<e>' ) && '-1' != d ) {
                            if ( '-2' == d ) {
                                // Run next
                                return methods[ 'migrate' ]( postdata, $row );
                            }
                            else if ( '1' == d ) {
                                $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-complete' );

                                // Run next
                                return methods[ 'migrate' ]();
                            }
                            else if ( ( d.length - 2 ) == d.indexOf( '-2' ) ) {
                                $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-warning' );
                                $row.find( 'td span.jet_cct-wizard-info' ).html( d.replace( '<e>', '' ).replace( '</e>', '' ) );
                                if ( window.console ) console.log( d.replace( '<e>', '' ).replace( '</e>', '' ) );

                                // Run next
                                return methods[ 'migrate' ]( postdata, $row );
                            }
                            else if ( ( d.length - 1 ) == d.indexOf( '1' ) ) {
                                $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-warning' );
                                $row.find( 'td span.jet_cct-wizard-info' ).html( d.replace( '<e>', '' ).replace( '</e>', '' ) );
																if ( window.console ) console.log( d.replace( '<e>', '' ).replace( '</e>', '' ) );

                                // Run next
                                return methods[ 'migrate' ]();
                            }
                            else {
                                $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-error' );
                                $row.find( 'td span.jet_cct-wizard-info' ).html( d.replace( '<e>', '' ).replace( '</e>', '' ) );
																if ( window.console ) console.log( d.replace( '<e>', '' ).replace( '</e>', '' ) );
                            }
                        }
                        else if ( -1 < d.indexOf( 'Database Error;' ) ) {
                            $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-error' );
                            $row.find( 'td span.jet_cct-wizard-info' ).html( d.replace( '<e>', '' ).replace( '</e>', '' ) );
														if ( window.console ) console.log( d.replace( '<e>', '' ).replace( '</e>', '' ) );
                        }
                        else {
                            $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-warning' );
                            $row.find( 'td span.jet_cct-wizard-info' ).html( d.replace( '<e>', '' ).replace( '</e>', '' ) );
														if ( window.console ) console.log( d.replace( '<e>', '' ).replace( '</e>', '' ) );

                            // Run next
                            return methods[ 'migrate' ]();
                        }
                    },
                    error : function () {
                        $row.removeClass( 'jet_cct-wizard-table-active' ).addClass( 'jet_cct-wizard-table-error' );
                        $row.find( 'td span.jet_cct-wizard-info' ).text( 'Unable to process request, please try again.' );
                    },
                    dataType : 'html'
                } );
            }
            else {
                $( '#jet_cct-wizard-next' ).click().text( 'Start using jet_cct' ).addClass( 'finished' );
                $( '#jet_cct-wizard-next' ).off( 'click' );
                $( '#jet_cct-wizard-next' ).prop( 'href', 'admin.php?page=jet_cct' );
                $( '#jet_cct-wizard-next' ).show();
                $( '#jet_cct-wizard-finished' ).show();
            }
        }
    };

    $.fn.jet_cctUpgrade = function ( method ) {
        return methods[ method ]();
        // go through tr by tr, run if/else checks
    };
})( jQuery );