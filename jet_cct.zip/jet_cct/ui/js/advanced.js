jQuery(document).ready(function($) {
	/**
	 * Globals
	 */
	$smallWidth = 300;
	$bigWidth = 800;

	/**
	 * Update Button
	 */
	function updateButtonText ($newText){
		$('#jet_cct-parts-submit').val($newText);
	}

	/**
	 * Dialog Box Population
	 */
	function populateEditPages() {
		$newHTML = '<div id="jet_cct-parts-search"><label for="jet_cct-parts-search-box">Search:</label><input id="jet_cct-parts-search-box" name="jet_cct-parts-search-box" type="text" /><input id="jet_cct-parts-search-box-submit" name="jet_cct-parts-search-box-submit" class="button-secondary" value="Search Pages" /></div>';
		$newHTML+= '<div class="clear"></div>';
		$newHTML+= '<div class="tablenav top lightgraybackground">';
		$newHTML+= '<div id="jet_cct-parts-display-per-page" class="left">';
		$newHTML+= '<label for="jet_cct-parts-display-per-page-select">Display Per Page:</label>';
		$newHTML+= '<select id="jet_cct-parts-display-per-page-select" name="jet_cct-parts-display-per-page-select">';
		$newHTML+= '<option value="40">40</option>';
		$newHTML+= '<option value="20">20</option>';
		$newHTML+= '<option value="10">10</option>';
		$newHTML+= '</select>';
		$newHTML+= '</div>';
		$newHTML+= '<div class="jet_cct-parts-pagination">';
		$newHTML+= '<div class="tablenav-pages">';
		$newHTML+= '<span class="pagination-links">';
		$newHTML+= '<a class="first-page disabled" href="#" title="Go to the first page">&laquo;</a>';
		$newHTML+= '<a class="prev-page disabled" href="#" title="Go to the previous page">‹</a>';
		$newHTML+= '<span class="paging-input">';
		$newHTML+= '<input class="current-page" type="text" size="2" value="1" name="paged" title="Current page" />';
		$newHTML+= ' of ';
		$newHTML+= '<span class="total-pages">10 </span>';
		$newHTML+= '</span>';
		$newHTML+= '<a class="next-page" href="#" title="Go to the next page">›</a>';
		$newHTML+= '<a class="last-page" href="#" title="Go to the last page">»</a>';
		$newHTML+= '</span>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '<table style="width: 100%">';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '</table>';
		$newHTML+= '<div class="tablenav top lightgraybackground">';
		$newHTML+= '<div id="jet_cct-parts-display-per-page" class="left">';
		$newHTML+= '<label for="jet_cct-parts-display-per-page-select">Display Per Page</label>';
		$newHTML+= '<select id="jet_cct-parts-display-per-page-select" name="jet_cct-parts-display-per-page-select">';
		$newHTML+= '<option value="40">40</option>';
		$newHTML+= '<option value="20">20</option>';
		$newHTML+= '<option value="10">10</option>';
		$newHTML+= '</select>';
		$newHTML+= '</div>';
		$newHTML+= '<div class="jet_cct-parts-pagination">';
		$newHTML+= '<div class="tablenav-pages">';
		$newHTML+= '<span class="pagination-links">';
		$newHTML+= '<a class="first-page disabled" href="#" title="Go to the first page">&laquo;</a>';
		$newHTML+= '<a class="prev-page disabled" href="#" title="Go to the previous page">‹</a>';
		$newHTML+= '<span class="paging-input">';
		$newHTML+= '<input class="current-page" type="text" size="2" value="1" name="paged" title="Current page" />';
		$newHTML+= ' of ';
		$newHTML+= '<span class="total-pages">10 </span>';
		$newHTML+= '</span>';
		$newHTML+= '<a class="next-page" href="#" title="Go to the next page">›</a>';
		$newHTML+= '<a class="last-page" href="#" title="Go to the last page">»</a>';
		$newHTML+= '</span>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$('#jet_cct-parts-popup').html($newHTML);
		updateButtonText('Update jet_cct Page');
	}

	function populateAddPage() {
		$newHTML = '<p>Create a new jet_cct Page by entering the name in the text field.</p>';
		$newHTML+= '<label for="jet_cct-parts-dialog-page-new">Name:</label><input id="jet_cct-parts-dialog-page-new" name="jet_cct-parts-dialog-page-new" type="text" />';
		$newHTML+= '<input class="submitnew button-primary" type="" value="Add New jet_cct Page" />';
		$newHTML+= '<input type="hidden" value="newjet_cctpage" />';

		$('#jet_cct-parts-popup').html($newHTML);
		updateButtonText('Save New jet_cct Page');
	}

	function populateEditTemplates() {
		$newHTML = '<div id="jet_cct-parts-search"><label for="jet_cct-parts-search-box">Search:</label><input id="jet_cct-parts-search-box" name="jet_cct-parts-search-box" type="text" /><input id="jet_cct-parts-search-box-submit" name="jet_cct-parts-search-box-submit" class="button-secondary" value="Search Templates" /></div>';
		$newHTML+= '<div class="clear"></div>';
		$newHTML+= '<div class="tablenav top lightgraybackground">';
		$newHTML+= '<div id="jet_cct-parts-display-per-page" class="left">';
		$newHTML+= '<label for="jet_cct-parts-display-per-page-select">Display Per Page</label>';
		$newHTML+= '<select id="jet_cct-parts-display-per-page-select" name="jet_cct-parts-display-per-page-select">';
		$newHTML+= '<option value="40">40</option>';
		$newHTML+= '<option value="20">20</option>';
		$newHTML+= '<option value="10">10</option>';
		$newHTML+= '</select>';
		$newHTML+= '</div>';
		$newHTML+= '<div class="jet_cct-parts-pagination">';
		$newHTML+= '<div class="tablenav-pages">';
		$newHTML+= '<span class="pagination-links">';
		$newHTML+= '<a class="first-page disabled" href="#" title="Go to the first page">&laquo;</a>';
		$newHTML+= '<a class="prev-page disabled" href="#" title="Go to the previous page">‹</a>';
		$newHTML+= '<span class="paging-input">';
		$newHTML+= '<input class="current-page" type="text" size="2" value="1" name="paged" title="Current page" />';
		$newHTML+= ' of ';
		$newHTML+= '<span class="total-pages">10 </span>';
		$newHTML+= '</span>';
		$newHTML+= '<a class="next-page" href="#" title="Go to the next page">›</a>';
		$newHTML+= '<a class="last-page" href="#" title="Go to the last page">»</a>';
		$newHTML+= '</span>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '<table style="width: 100%">';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '</table>';
		$newHTML+= '<div class="tablenav top lightgraybackground">';
		$newHTML+= '<div id="jet_cct-parts-display-per-page" class="left">';
		$newHTML+= '<label for="jet_cct-parts-display-per-page-select">Display Per Page:</label>';
		$newHTML+= '<select id="jet_cct-parts-display-per-page-select" name="jet_cct-parts-display-per-page-select">';
		$newHTML+= '<option value="40">40</option>';
		$newHTML+= '<option value="20">20</option>';
		$newHTML+= '<option value="10">10</option>';
		$newHTML+= '</select>';
		$newHTML+= '</div>';
		$newHTML+= '<div class="jet_cct-parts-pagination">';
		$newHTML+= '<div class="tablenav-pages">';
		$newHTML+= '<span class="pagination-links">';
		$newHTML+= '<a class="first-page disabled" href="#" title="Go to the first page">&laquo;</a>';
		$newHTML+= '<a class="prev-page disabled" href="#" title="Go to the previous page">‹</a>';
		$newHTML+= '<span class="paging-input">';
		$newHTML+= '<input class="current-page" type="text" size="2" value="1" name="paged" title="Current page" />';
		$newHTML+= ' of ';
		$newHTML+= '<span class="total-pages">10 </span>';
		$newHTML+= '</span>';
		$newHTML+= '<a class="next-page" href="#" title="Go to the next page">›</a>';
		$newHTML+= '<a class="last-page" href="#" title="Go to the last page">»</a>';
		$newHTML+= '</span>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$('#jet_cct-parts-popup').html($newHTML);
		updateButtonText('Update jet_cct Template');
	}

	function populateAddTemplate() {
		$newHTML = '<p>Create a new jet_cct Template by entering the name in the text field.</p>';
		$newHTML+= '<label for="jet_cct-parts-dialog-template-new">Name:</label><input id="jet_cct-parts-dialog-template-new" name="jet_cct-parts-dialog-template-new" type="text" />';
		$newHTML+= '<input class="submitnew button-primary" type="" value="Add New jet_cct Template" />';
		$newHTML+= '<input type="hidden" value="newjet_ccttemplate" />';

		$('#jet_cct-parts-popup').html($newHTML);
		updateButtonText('Save New jet_cct Template');
	}

	function populateEditHelpers() {
		$newHTML = '<div id="jet_cct-parts-search"><label for="jet_cct-parts-search-box">Search:</label><input id="jet_cct-parts-search-box" name="jet_cct-parts-search-box" type="text" /><input id="jet_cct-parts-search-box-submit" name="jet_cct-parts-search-box-submit" class="button-secondary" value="Search Helpers" /></div>';
		$newHTML+= '<div id="jet_cct-parts-filter"><label for="jet_cct-parts-filter-box">jet_cct Helper Type:</label>';
		$newHTML+= '<select id="jet_cct-parts-filter-box" name="jet_cct-parts-filter-box">';
		$newHTML+= '<option value="all">-- All Types --</option>';
		$newHTML+= '<option value="display">Display</option>';
		$newHTML+= '<option value="input">Input</option>';
		$newHTML+= '<option value="presave">Pre-Save</option>';
		$newHTML+= '<option value="postsave">Post-Save</option>';
		$newHTML+= '</select>';
		$newHTML+= '<input id="jet_cct-parts-filter-submit" name="jet_cct-parts-filter-submit" class="button-secondary" value="Filter" />';
		$newHTML+= '</div>';
		$newHTML+= '<div class="clear"></div>';
		$newHTML+= '<div class="tablenav top lightgraybackground">';
		$newHTML+= '<div id="jet_cct-parts-display-per-page" class="left">';
		$newHTML+= '<label for="jet_cct-parts-display-per-page-select">Display Per Page:</label>';
		$newHTML+= '<select id="jet_cct-parts-display-per-page-select" name="jet_cct-parts-display-per-page-select">';
		$newHTML+= '<option value="40">40</option>';
		$newHTML+= '<option value="20">20</option>';
		$newHTML+= '<option value="10">10</option>';
		$newHTML+= '</select>';
		$newHTML+= '</div>';
		$newHTML+= '<div class="jet_cct-parts-pagination">';
		$newHTML+= '<div class="tablenav-pages">';
		$newHTML+= '<span class="pagination-links">';
		$newHTML+= '<a class="first-page disabled" href="#" title="Go to the first page">&laquo;</a>';
		$newHTML+= '<a class="prev-page disabled" href="#" title="Go to the previous page">‹</a>';
		$newHTML+= '<span class="paging-input">';
		$newHTML+= '<input class="current-page" type="text" size="2" value="1" name="paged" title="Current page" />';
		$newHTML+= ' of ';
		$newHTML+= '<span class="total-pages">10 </span>';
		$newHTML+= '</span>';
		$newHTML+= '<a class="next-page" href="#" title="Go to the next page">›</a>';
		$newHTML+= '<a class="last-page" href="#" title="Go to the last page">»</a>';
		$newHTML+= '</span>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '<table style="width: 100%">';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '<tr>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '<td>';
		$newHTML+= '<div class="bluehighlight">';
		$newHTML+= '<span class="blue"><a href="#">file/photo/single</a></span>';
		$newHTML+= '<span class="gray">Display</span><span class="actions"><a href="#" class="editjet_cctpart">Edit</a> | <a href="#" class="deletejet_cctpart">Delete</a></span>';
		$newHTML+= '</div>';
		$newHTML+= '</td>';
		$newHTML+= '</tr>';
		$newHTML+= '</table>';
		$newHTML+= '<div class="tablenav top lightgraybackground">';
		$newHTML+= '<div id="jet_cct-parts-display-per-page" class="left">';
		$newHTML+= '<label for="jet_cct-parts-display-per-page-select">Display Per Page</label>';
		$newHTML+= '<select id="jet_cct-parts-display-per-page-select" name="jet_cct-parts-display-per-page-select">';
		$newHTML+= '<option value="40">40</option>';
		$newHTML+= '<option value="20">20</option>';
		$newHTML+= '<option value="10">10</option>';
		$newHTML+= '</select>';
		$newHTML+= '</div>';
		$newHTML+= '<div class="jet_cct-parts-pagination">';
		$newHTML+= '<div class="tablenav-pages">';
		$newHTML+= '<span class="pagination-links">';
		$newHTML+= '<a class="first-page disabled" href="#" title="Go to the first page">&laquo;</a>';
		$newHTML+= '<a class="prev-page disabled" href="#" title="Go to the previous page">‹</a>';
		$newHTML+= '<span class="paging-input">';
		$newHTML+= '<input class="current-page" type="text" size="2" value="1" name="paged" title="Current page" />';
		$newHTML+= ' of ';
		$newHTML+= '<span class="total-pages">10 </span>';
		$newHTML+= '</span>';
		$newHTML+= '<a class="next-page" href="#" title="Go to the next page">›</a>';
		$newHTML+= '<a class="last-page" href="#" title="Go to the last page">»</a>';
		$newHTML+= '</span>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$newHTML+= '</div>';
		$('#jet_cct-parts-popup').html($newHTML);
		updateButtonText('Update jet_cct Helper');
	}

	function populateAddHelper() {
		$newHTML = '<p>Create a new jet_cct Helper by entering the name in the text field and selecting what kind of helper it is.</p>';
		$newHTML+= '<label for="jet_cct-parts-dialog-helper-new">Name:</label><input id="jet_cct-parts-dialog-helper-new" name="jet_cct-parts-dialog-helper-new" type="text" />';
		$newHTML+= '<label for="jet_cct-parts-dialog-helper-new-type">Type:</label>';
		$newHTML+= '<select id="jet_cct-parts-dialog-helper-new-type" name="jet_cct-parts-dialog-helper-new-type">';
		$newHTML+= '<option value="display">Display</option>';
		$newHTML+= '<option value="input">Input</option>';
		$newHTML+= '<option value="presave">Pre-Save</option>';
		$newHTML+= '<option value="postsave">Post-Save</option>';
		$newHTML+= '</select>';
		$newHTML+= '<input class="submitnew button-primary" type="" value="Add New jet_cct Helper" />';
		$newHTML+= '<input type="hidden" value="newjet_ccthelper" />';
		$('#jet_cct-parts-popup').html($newHTML);
		updateButtonText('Save New jet_cct Helper');
	}

	/**
	 * Event Handlers
	 */
	$('#jet_cct-parts-pages-edit').click(function(e){
		e.preventDefault();
		populateEditPages();
		$('#jet_cct-parts-popup').dialog({title: 'Select jet_cct Page to Edit', width: $bigWidth}).dialog('open');
	});

	$('#jet_cct-parts-pages-add').click(function(e){
		e.preventDefault();
		populateAddPage();
		$('#jet_cct-parts-popup').dialog({title: 'Create New jet_cct Page', width: $smallWidth}).dialog('open');
	});

	$('#jet_cct-parts-templates-edit').click(function(e){
		e.preventDefault();
		populateEditTemplates();
		$('#jet_cct-parts-popup').dialog({title: 'Select jet_cct Template to Edit', width: $bigWidth}).dialog('open');
	});

	$('#jet_cct-parts-templates-add').click(function(e){
		e.preventDefault();
		populateAddTemplate();
		$('#jet_cct-parts-popup').dialog({title: 'Create New jet_cct Template', width: $smallWidth}).dialog('open');
	});

	$('#jet_cct-parts-helpers-edit').click(function(e){
		e.preventDefault();
		populateEditHelpers();
		$('#jet_cct-parts-popup').dialog({title: 'Select jet_cct Helper to Edit', width: $bigWidth}).dialog('open');
	});

	$('#jet_cct-parts-helpers-add').click(function(e){
		e.preventDefault();
		populateAddHelper();
		$('#jet_cct-parts-popup').dialog({title: 'Create New jet_cct Helper', width: $smallWidth}).dialog('open');
	});

	/**
	 * Run Startup Commands
	 */
	$('#jet_cct-parts-popup').dialog({
		autoOpen: false,
		closeOnEscape: true,
		modal: true,
		dialogClass: 'dialogWithDropShadow',
		resizable: false,
		hide: 'fade',
		show: 'fade'
	})
});