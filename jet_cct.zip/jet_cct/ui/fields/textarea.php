<?php
    $type = 'textarea';
    $attributes = array();
    $attributes[ 'tabindex' ] = 2;
    $attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );

    if ( jet_cct_var( 'readonly', $options, false ) ) {
        $attributes[ 'readonly' ] = 'READONLY';

        $attributes[ 'class' ] .= ' jet_cct-form-ui-read-only';
    }
?>
    <textarea<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?>><?php echo esc_textarea( $value ); ?></textarea>
<?php
    jet_cctForm::regex( $form_field_type, $options );