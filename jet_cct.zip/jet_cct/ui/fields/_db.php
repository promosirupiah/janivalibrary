<?php
$attributes = array();
$attributes[ 'type' ] = 'text';
$attributes[ 'value' ] = jet_cctForm::clean( $value, false, true );
$attributes[ 'tabindex' ] = 2;
$attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );
?>
<input<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?> />
<script>
    jQuery( function ( $ ) {
        $( 'input#<?php echo esc_js( $attributes[ 'id' ] ); ?>' ).change( function () {
	        var newval = $( this ).val().toLowerCase().replace( /(\s)/g, '_' ).replace( /([^0-9a-z_\-])/g, '' ).replace( /(_){2,}/g, '_' ).replace( /_$/, '' );
            $( this ).val( newval );
        } );
    } );
</script>
