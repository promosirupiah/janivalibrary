<?php echo jet_cctForm::label( $name, $options ); ?>

<?php echo jet_cctForm::field( $name, $value, $type, $options, $jet, $id ); ?>

<?php echo jet_cctForm::comment( $name, null, $options ); ?>