<?php
wp_enqueue_script( 'jet_cct-codemirror' );
wp_enqueue_style( 'jet_cct-codemirror' );
wp_enqueue_script( 'jet_cct-codemirror-loadmode' );

$type = 'textarea';
$attributes = array();
$attributes[ 'tabindex' ] = 2;
$attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options, 'jet_cct-ui-field-codemirror' );
?>
<div class="code-toolbar"><!-- Placeholder --></div>
<textarea<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?>><?php echo esc_textarea( $value ); ?></textarea>
<div class="code-footer"><!-- Placeholder --></div>

<script>
    var $textarea_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?>, codemirror_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?>;

    jQuery( function ( $ ) {
        $textarea_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?> = jQuery( 'textarea#<?php echo esc_js( $attributes[ 'id' ] ); ?>' );

        CodeMirror.modeURL = "<?php echo esc_js( jet_cct_URL ); ?>ui/js/codemirror/mode/%N/%N.js";
        if ( 'undefined' == typeof codemirror_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?> ) {

            codemirror_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?> = CodeMirror.fromTextArea( document.getElementById( "<?php echo esc_js( $attributes[ 'id' ] ); ?>" ), {
                lineNumbers : true,
                matchBrackets : true,
                mode : "application/x-httpd-php",
                indentUnit : 4,
                indentWithTabs : false,
                lineWrapping : true,
                enterMode : "keep",
                tabMode : "shift"
            } );
            codemirror_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?>.on( 'blur', function() {
                var value = codemirror_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?>.getValue();
                $textarea_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?>.val( value );
            });

            CodeMirror.autoLoadMode( codemirror_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?>, 'php' );
        }
    } );
</script>
