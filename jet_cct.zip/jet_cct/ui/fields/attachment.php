<?php
global $post_ID;

wp_enqueue_script( 'jet_cct-handlebars' );
wp_enqueue_script( 'jquery-ui-core' );
wp_enqueue_script( 'jquery-ui-sortable' );
wp_enqueue_script( 'thickbox' );
wp_enqueue_script( 'jet_cct-attach' );

wp_enqueue_style( 'thickbox' );
wp_enqueue_style( 'jet_cct-attach' );

$field_file = jet_cctForm::field_loader( 'file' );

$attributes = array();
$attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );

$css_id = $attributes[ 'id' ];

$uri_hash = wp_create_nonce( 'jet_cct_uri_' . $_SERVER[ 'REQUEST_URI' ] );

$uid = @session_id();

if ( is_user_logged_in() )
    $uid = 'user_' . get_current_user_id();

$field_nonce = wp_create_nonce( 'jet_cct_upload_' . ( !is_object( $jet ) ? '0' : $jet->jet_id ) . '_' . $uid . '_' . $uri_hash . '_' . $options[ 'id' ] );

$limit_file_type = jet_cct_var( $form_field_type . '_type', $options, 'images' );

$title_editable = jet_cct_var( $form_field_type . '_edit_title', $options, 0 );
$linked = jet_cct_var( $form_field_type . '_linked', $options, 0 );

if ( 'images' == $limit_file_type )
    $limit_types = 'jpg,jpeg,png,gif';
elseif ( 'video' == $limit_file_type )
    $limit_types = 'mpg,mov,flv,mp4';
elseif ( 'audio' == $limit_file_type )
    $limit_types = 'mp3,m4a,wav,wma';
elseif ( 'text' == $limit_file_type )
    $limit_types = 'txt,rtx,csv,tsv';
elseif ( 'any' == $limit_file_type )
    $limit_types = '';
else
    $limit_types = jet_cct_var( $form_field_type . '_allowed_extensions', $options, '' );

$limit_types = str_replace( ' ', '', $limit_types );

$tab = jet_cct_var( $form_field_type . '_attachment_tab', $options, 'type', null, true );

if ( 'upload' == $tab )
    $tab = 'type';
elseif ( 'browse' == $tab )
    $tab = 'library';

$file_limit = 1;

if ( 'multi' == jet_cct_var( $form_field_type . '_format_type', $options, 'single' ) )
    $file_limit = (int) jet_cct_var( $form_field_type . '_limit', $options, 0 );

$data = array(
    'limit-types' => $limit_types,
    'limit-files' => $file_limit
);

$the_post_id = '';

if ( is_admin() && !empty( $post_ID ) )
    $the_post_id = '&amp;post_id=' . (int) $post_ID;

if ( empty( $value ) )
    $value = array();
else
    $value = (array) $value;
?>
<div<?php jet_cctForm::attributes( array( 'class' => $attributes[ 'class' ], 'id' => $attributes[ 'id' ] ), $name, $form_field_type, $options ); ?>>
    <ul class="jet_cct-files jet_cct-files-list"><?php // no extra space in ul or CSS:empty won't work
        foreach ( $value as $val ) {
            $attachment = get_post( $val, ARRAY_A );

            if ( empty( $attachment ) ) {
                continue;
            }

            $attachment[ 'filename' ] = basename( $attachment[ 'guid' ] );

            $thumb = wp_get_attachment_image_src( $attachment[ 'ID' ], 'thumbnail', true );
            $attachment[ 'thumbnail' ] = $thumb[ 0 ];

            $attachment[ 'link' ] = '';

            if ( $linked ) {
                $attachment[ 'link' ] = wp_get_attachment_url( $attachment[ 'ID' ] );
            }

            $attachment = apply_filters( 'jet_cct_media_attachment', $attachment );

            echo $field_file->markup( $attributes, $file_limit, $title_editable, $attachment[ 'ID' ], $attachment[ 'thumbnail' ], $attachment[ 'post_title' ] );
        }
        ?></ul>

    <a class="button jet_cct-file-add jet_cct-media-add" href="<?php echo esc_url( admin_url( 'media-upload.php?inlineId=jet_cct_media_attachment' . $the_post_id . '&tab=' . $tab . '&TB_iframe=1&width=640&height=1500&jet_cct_jet=' . $jet->jet . '&jet_cct_jet_id=' . $jet->jet . '&jet_cct_field=' . $options[ 'name' ] . '&jet_cct_field_id=' .$options[ 'id' ] . '&jet_cct_uri_hash=' .$uri_hash . '&jet_cct_field_nonce=' . $field_nonce ) ); ?>"><?php echo jet_cct_v( $form_field_type . '_add_button', $options, __( 'Add File', 'jet_cct' ) ); ?></a>
</div>

<script type="text/x-handlebars" id="<?php echo $css_id; ?>-handlebars">
    <?php echo $field_file->markup( $attributes, $file_limit, $title_editable ); ?>
</script>

<script type="text/javascript">
    jQuery( function ( $ ) {
        // init sortable
        $( '#<?php echo esc_js( $css_id ); ?> ul.jet_cct-files' )
            .sortable( {
                containment : 'parent',
                axis : 'y',
                scrollSensitivity : 40,
                tolerance : 'pointer',
                opacity : 0.6
            } );

        // hook delete links
        $( '#<?php echo esc_js( $css_id ); ?>' ).on( 'click', 'li.jet_cct-file-delete a', function ( e ) {
			e.preventDefault();

            var jet_cctfile = $( this ).parent().parent().parent();
            jet_cctfile.slideUp( function () {

                // check to see if this was the only entry
                if ( jet_cctfile.parent().children().length == 1 ) { // 1 because we haven't removed our target yet
                    jet_cctfile.parent().hide();
                }

                // remove the entry
                $( this ).remove();

            } );
        } );

        var maxFiles_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?> = <?php echo esc_js( $file_limit ); ?>;

        // hook the add link
        $( '#<?php echo esc_js( $css_id ); ?>' ).on( 'click', 'a.jet_cct-file-add', function ( e ) {
            e.preventDefault();
            var trigger = $( this );
            var href = trigger.attr( 'href' ), width = $( window ).width(), H = $( window ).height(), W = ( 720 < width ) ? 720 : width;
            if ( !href ) {
                return;
            }
            href = href.replace( /&width=[0-9]+/g, '' );
            href = href.replace( /&height=[0-9]+/g, '' );
            trigger.attr( 'href', href + '&width=' + ( W - 80 ) + '&height=' + ( H - 85 ) );

            jet_cct_file_context = trigger.parent().find( 'ul.jet_cct-files' );
            jet_cct_file_thickbox_modder = setInterval( function () {
                if ( jet_cct_file_context )
                    jet_cct_attachments( '<?php echo esc_js( $css_id ); ?>', maxFiles_<?php echo esc_js( jet_cct_js_name( $attributes[ 'id' ] ) ); ?> );
            }, 500 );

            tb_show( 'Attach a file', e.target.href, false );
            return false;
        } );
    } );
</script>
