<?php
wp_enqueue_script( 'jet_cct-cleditor' );
wp_enqueue_style( 'jet_cct-cleditor' );

$type = 'textarea';
$attributes = array();
$attributes[ 'tabindex' ] = 2;
$attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options, 'jet_cct-ui-field-cleditor' );
?>
<textarea<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?>><?php echo esc_textarea( $value ); ?></textarea>
<script>
    jQuery( function ( $ ) {
        var $textarea = $( 'textarea#<?php echo esc_js( $attributes[ 'id' ] ); ?>' );
        var editorWidth = $textarea.outerWidth();
        $textarea.cleditor( {
            width : editorWidth
        } );
    } );
</script>
