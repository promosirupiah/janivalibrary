<p<?php jet_cctForm::attributes( $attributes, $name, $type, $options ); ?>>
    <?php echo $message; ?>
</p>