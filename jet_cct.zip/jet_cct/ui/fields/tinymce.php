<?php
$settings = array();
$settings[ 'textarea_name' ] = $name;
$settings[ 'media_buttons' ] = false;
if (
    !( defined( 'jet_cct_DISABLE_FILE_UPLOAD' ) && true === jet_cct_DISABLE_FILE_UPLOAD )
    && !( defined( 'jet_cct_UPLOAD_REQUIRE_LOGIN' ) && is_bool( jet_cct_UPLOAD_REQUIRE_LOGIN ) && true === jet_cct_UPLOAD_REQUIRE_LOGIN && !is_user_logged_in() )
    && !( defined( 'jet_cct_UPLOAD_REQUIRE_LOGIN' ) && !is_bool( jet_cct_UPLOAD_REQUIRE_LOGIN )
          && ( !is_user_logged_in() || !current_user_can( jet_cct_UPLOAD_REQUIRE_LOGIN ) ) )
) {
    $settings[ 'media_buttons' ] = (boolean) jet_cct_var( 'wysiwyg_media_buttons', $options, true );
}

if ( isset( $options[ 'settings' ] ) )
    $settings = array_merge( $settings, $options[ 'settings' ] );

$attributes = array();
$attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options, 'jet_cct-ui-field-tinymce' );
$class_attributes = array( 'class' => $attributes[ 'class' ] );
?>
<div<?php jet_cctForm::attributes( $class_attributes, $name, $form_field_type, $options ); ?>>
    <?php wp_editor( $value, $attributes[ 'id' ], $settings ); ?>
</div>
