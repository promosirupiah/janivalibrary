<?php
    $attributes = array();
    $attributes[ 'type' ] = 'password';
    $attributes[ 'value' ] = $value;
    $attributes[ 'tabindex' ] = 2;
    $attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );

    if ( jet_cct_var( 'readonly', $options, false ) ) {
        $attributes[ 'readonly' ] = 'READONLY';

        $attributes[ 'class' ] .= ' jet_cct-form-ui-read-only';
    }
?>
    <input<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?> />
<?php
    jet_cctForm::regex( $form_field_type, $options );