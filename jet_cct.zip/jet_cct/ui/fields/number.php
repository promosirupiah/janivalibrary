<?php
$field_number = jet_cctForm::field_loader( 'number' );

$value = $field_number->format( $value, $name, $options, $jet, $id );

$attributes = array();
$attributes[ 'type' ] = 'text';
$attributes[ 'value' ] = $value;
$attributes[ 'tabindex' ] = 2;
$attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );

global $wp_locale;

if ( '9999.99' == jet_cct_var( 'number_format', $options ) ) {
    $thousands = ',';
    $dot = '.';
}
elseif ( '9999,99' == jet_cct_var( 'number_format', $options ) ) {
    $thousands = '.';
    $dot = ',';
}
elseif ( '9.999,99' == jet_cct_var( 'number_format', $options ) ) {
    $thousands = '.';
    $dot = ',';
}
else {
    $thousands = $wp_locale->number_format[ 'thousands_sep' ];
    $dot = $wp_locale->number_format[ 'decimal_point' ];
}
?>
<input<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?>/>
<script>
    jQuery( function ( $ ) {
        $( 'input#<?php echo esc_js( $attributes[ 'id' ] ); ?>' ).on( 'blur', function () {
            if ( !/^[0-9\<?php
            echo esc_js( implode( '\\', array_filter( array( $dot, $thousands ) ) ) );
            ?>\-]$/.test( $( this ).val() ) ) {
                var newval = $( this )
                    .val()
                    .replace( /[^0-9\<?php
                              echo esc_js( implode( '\\', array_filter( array( $dot, $thousands ) ) ) );
                              ?>\-]/g, '' );
                $( this ).val( newval );
            }
        } );
    } );
</script>
