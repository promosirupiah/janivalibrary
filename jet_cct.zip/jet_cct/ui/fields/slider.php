<?php
    wp_enqueue_script( 'jquery-ui-slider' );
    wp_enqueue_style( 'jquery-ui' );

    if ( is_array( $value ) )
        $value = implode( ',', $value );

    if ( strlen( $value ) < 1 )
        $value = 0;

    $values = explode( ',', $value );
    $values = array(
        jet_cct_var( 0, $values, jet_cct_var( $form_field_type . '_min', $options, 0, null, true ) ),
        jet_cct_var( 1, $values, jet_cct_var( $form_field_type . '_max', $options, 100, null, true ) )
    );

    $values[ 0 ] = max( $values[ 0 ], jet_cct_var( $form_field_type . '_min', $options, 0 ) );
    $values[ 1 ] = min( $values[ 1 ], jet_cct_var( $form_field_type . '_min', $options, 100 ) );

    if ( 0 == jet_cct_var( $form_field_type . '_range', $options, 0 ) )
        $output_value = $value = $values[ 0 ];
    else {
        $value = implode( ',', $values );
        $output_value = implode( ' - ', $values );
    }

    $attributes = array();
    $attributes[ 'type' ] = 'hidden';
    $attributes[ 'value' ] = $value;
    $attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );
?>
<input<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?> />

<div class="jet_cct-slider-field">
    <div id="<?php echo esc_js( $attributes[ 'id' ] ); ?>-range" class="jet_cct-slider-range"></div>
    <div id="<?php echo esc_js( $attributes[ 'id' ] ); ?>-amount-display" class="jet_cct-slider-field-display">
        <?php echo $output_value; ?>
    </div>
</div>

<script>
    jQuery( function ( $ ) {
        $( "#<?php echo esc_js( $attributes[ 'id' ] ); ?>-range" ).slider( {
            orientation : '<?php echo esc_js( jet_cct_v( $form_field_type . '_orientation', $options, 'horizontal' ) ); ?>',
            min : <?php echo esc_js( jet_cct_v( $form_field_type . '_min', $options, 0 ) ); ?>,
            max : <?php echo esc_js( jet_cct_v( $form_field_type . '_max', $options, 100 ) ); ?>,
            step : <?php echo esc_js( jet_cct_v( $form_field_type . '_step', $options, 1 ) ); ?>,

            <?php
                if ( 1 == jet_cct_var( $form_field_type . '_range', $options, 0 ) ) {
            ?>
                range : true,
                values : [
                    <?php echo esc_js( $values[ 0 ] ); ?>,
                    <?php echo esc_js( $values[ 1 ] ); ?>
                ],
                slide : function ( event, ui ) {
                    $( "#<?php echo esc_js( $attributes[ 'id' ] ); ?>" ).val( ui.values[ 0 ] + ',' + ui.values[ 1 ] );
                    $( "#<?php echo esc_js( $attributes[ 'id' ] ); ?>-amount-display" ).html( ui.values[ 0 ] + ' - ' + ui.values[ 1 ] );
                }
            <?php
                }
                else {
            ?>
                range : false,
                value : <?php echo esc_js( $value ); ?>,
                slide : function ( event, ui ) {
                    $( "#<?php echo esc_js( $attributes[ 'id' ] ); ?>" ).val( ui.value );
                    $( "#<?php echo esc_js( $attributes[ 'id' ] ); ?>-amount-display" ).html( ui.value );
                }
            <?php
                }
            ?>
        } );
    } );
</script>