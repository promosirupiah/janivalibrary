<?php
$options[ 'data' ] = (array) jet_cct_var_raw( 'data', $options, array(), null, true );

if ( 1 == jet_cct_var( 'grouped', $options, 0, null, true ) ) {
    ?>
<div class="jet_cct-pick-values jet_cct-pick-radio">
    <ul>
<?php
}

$counter = 1;
$primary_name = $name;
$primary_id = 'jet_cct-form-ui-' . jet_cctForm::clean( $name );
$selection_made = false;

foreach ( $options[ 'data' ] as $val => $label ) {
    if ( is_array( $label ) ) {
        if ( isset( $label[ 'label' ] ) )
            $label = $label[ 'label' ];
        else
            $label = $val;
    }

    $attributes = array();

    $attributes[ 'type' ] = 'radio';

    $attributes[ 'checked' ] = null;
    $attributes[ 'tabindex' ] = 2;

    if ( !$selection_made && ( $val == $value || ( is_array( $value ) && in_array( $val, $value ) ) ) ) {
        $attributes[ 'checked' ] = 'CHECKED';
        $selection_made = true;
    }

    $attributes[ 'value' ] = $val;

    $attributes = jet_cctForm::merge_attributes( $attributes, $name, $form_field_type, $options );

    $indent = '';

    $indent_count = substr_count( $label, '&nbsp;&nbsp;&nbsp;' );

    if ( 0 < $indent_count ) {
        $label = str_replace( '&nbsp;&nbsp;&nbsp;', '', $label );

        $indent = ' style="margin-left:' . ( 18 * $indent_count ) . 'px;"';
    }

    if ( jet_cct_var( 'readonly', $options, false ) ) {
        $attributes[ 'readonly' ] = 'READONLY';

        $attributes[ 'class' ] .= ' jet_cct-form-ui-read-only';
    }

    if ( 1 < count( $options[ 'data' ] ) )
        $attributes[ 'id' ] = $primary_id . $counter;

    if ( 1 == jet_cct_var( 'grouped', $options, 0, null, true ) ) {
        ?>
        <li>
<?php
    }
    ?>
    <div class="jet_cct-field jet_cct-boolean"<?php echo $indent; ?>>
        <input<?php jet_cctForm::attributes( $attributes, $name, $form_field_type, $options ); ?> />
        <?php
        if ( 0 < strlen( $label ) ) {
            $help = jet_cct_var_raw( 'help', $options );

            if ( 1 == jet_cct_var( 'grouped', $options, 0, null, true ) || empty( $help ) )
                $help = '';

            echo jet_cctForm::label( $attributes[ 'id' ], $label, $help );
        }
        ?>
    </div>
    <?php

    if ( 1 == jet_cct_var( 'grouped', $options, 0, null, true ) ) {
        ?>
        </li>
<?php
    }

    $counter++;
}

if ( 1 == jet_cct_var( 'grouped', $options, 0, null, true ) ) {
    ?>
    </ul>
</div>
<?php
}
