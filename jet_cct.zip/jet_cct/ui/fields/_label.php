<label<?php jet_cctForm::attributes( $attributes, $name, 'label' ); ?>>
    <?php
    echo $label;

    if ( 1 == jet_cct_var( 'required', $options, jet_cct_var( 'options', $options, $options ) ) )
        echo ' <abbr title="required" class="required">*</abbr>';

    if ( 0 == jet_cct_var( 'grouped', $options, 0, null, true ) && !empty( $help ) && 'help' != $help )
        jet_cct_help( $help );
    ?>
</label>
