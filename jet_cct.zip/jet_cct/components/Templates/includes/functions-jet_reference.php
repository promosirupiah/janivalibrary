<?php

add_action( 'wp_ajax_pq_loadjet', 'pq_loadjet' );

function pq_loadjet($jetname = false) {
	if ( !jet_cct_is_admin() ) {
		jet_cct_error( __( 'Unauthorized request', 'jet_cct' ) );
	}
	if(!empty($_POST['jet_reference']['jet'])){
		$jetname = $_POST['jet_reference']['jet'];
	}
	if(!empty($_POST['jet'])){
		$jetname = $_POST['jet'];
	}
	$fields = array( __( 'No reference jet selected', 'jet_cct' ) );

	if(!empty($jetname)){
		$fields = pq_recurse_jet_fields( $jetname );
	}
	if(!empty($_POST['jet_reference']['jet']) || !empty($_POST['jet'])){
		header("Content-Type:application/json");
		echo json_encode($fields);
		die;
	}
	return $fields;
}

function pq_recurse_jet_fields( $jet_name, $prefix = '', &$jet_cct_visited = array() ) {
	$fields = array();
	if ( empty( $jet_name ) ) {
		return $fields;
	}
	$jet = jet_cct( $jet_name );
	$recurse_queue = array();

	foreach( $jet->jet_data['object_fields'] as $name => $field ){
		// Add WordPress object fields
		$fields[] = $prefix . $name;
	}
	if ( post_type_supports( $jet_name, 'thumbnail' ) ) {
		$fields[] = "{$prefix}post_thumbnail";
		$fields[] = "{$prefix}post_thumbnail_url";
		$sizes = get_intermediate_image_sizes();
		foreach ( $sizes as $size ) {
			$fields[] = "{$prefix}post_thumbnail.{$size}";
			$fields[] = "{$prefix}post_thumbnail_url.{$size}";
		}
	}
	$jet_fields = $jet->fields();
	foreach ( $jet_fields as $name => $field ) {
		// Add base field name
		$fields[] = $prefix . $name;

		// Field type specific handling
		if ( 'file' === $field['type'] && 'attachment' === $field['options']['file_uploader'] ) {
			$fields[] = $prefix . $name . '._src';
			$fields[] = $prefix . $name . '._img';

			$sizes = get_intermediate_image_sizes();
			foreach ( $sizes as $size ) {
				$fields[] = "{$prefix}{$name}._src.{$size}";
				if ( 'multi' != $field['options']['file_format_type'] ) {
					$fields[] = "{$prefix}{$name}._src_relative.{$size}";
					$fields[] = "{$prefix}{$name}._src_schemeless.{$size}";
				}
				$fields[] = "{$prefix}{$name}._img.{$size}";
			}

		} elseif ( ! empty( $field['table_info'] ) && ! empty( $field['table_info']['jet'] ) ) {
			$linked_jet = $field['table_info']['jet']['name'];
			if (  !isset( $jet_cct_visited[ $linked_jet ] ) || !in_array( $name, $jet_cct_visited[ $linked_jet ] ) ) {
				$jet_cct_visited[ $linked_jet ][] = $name;
				$recurse_queue[ $linked_jet ] = "{$prefix}{$name}.";
			}

		}
	}
	foreach ( $recurse_queue as $recurse_name => $recurse_prefix ) {
		$fields = array_merge( $fields, pq_recurse_jet_fields( $recurse_name, $recurse_prefix, $jet_cct_visited ) );
	}
	return $fields;
}

