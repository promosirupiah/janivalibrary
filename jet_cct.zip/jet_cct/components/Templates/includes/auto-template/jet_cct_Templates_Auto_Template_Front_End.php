<?php
if ( class_exists( 'jet_cct_PFAT_Frontend' ) ) {
	return;
}

/**
 * Class jet_cct_Templates_Auto_Template_Front_End
 *
 * Replaces jet_cct_PFAT_Frontend
 */
class jet_cct_Templates_Auto_Template_Front_End {
	function __construct() {

		if( !is_admin() ){
			add_action( 'wp', array( $this, 'set_frontier_style_script' ) );
		}

		add_action( 'template_redirect', array( $this, 'hook_content' ) );


	}

	/**
	 * Add hooks for output
	 *
	 * @since 2.6.6
	 */
	public function hook_content(){
		$filter = 'the_content';

		// get the current post type
		$current_post_type = $this->current_post_type();

		//now use other methods in class to build array to search in/ use
		$possible_jet_cct = $this->auto_jet_cct();


		//check if $current_post_type is the key of the array of possible jet_cct
		if ( isset( $possible_jet_cct[ $current_post_type ] ) ) {

			$this_jet = $possible_jet_cct[ $current_post_type ];

			if ( is_singular( $current_post_type ) ) {
				$filter =  $this_jet[ 'single_filter' ];
			} elseif ( is_post_type_archive( $current_post_type ) ) {
				$filter =  $this_jet[ 'archive_filter' ];

			} elseif ( is_home() && $current_post_type === 'post'  ) {
				$filter =  $this_jet[ 'archive_filter' ];
			} elseif ( is_tax( $current_post_type )  ) {
				$filter =  $this_jet[ 'archive_filter' ];

			}

		}
		/**
		 * Allows plugin to append/replace the_excerpt
		 *
		 * Default is false, set to true to enable.
		 */
		if ( !defined( 'PFAT_USE_ON_EXCERPT' ) ) {
			define( 'PFAT_USE_ON_EXCERPT', false );
		}


		add_filter( $filter, array( $this, 'front' ), 10.5 );

		if (  PFAT_USE_ON_EXCERPT  ) {
			add_filter( 'the_excerpt', array ( $this, 'front' ) );
		}


	}

	/**
	 * Get all post type and taxonomy jet_cct
	 *
	 * @since 2.4.5
	 *
	 * @return array Of jet names.
	 */
	function the_jet_cct() {

		//use the cached results
		$key = '_jet_cct_pfat_the_jet_cct';
		$the_jet_cct = jet_cct_transient_get( $key  );

		//check if we already have the results cached & use it if we can.
		if ( false === $the_jet_cct ) {
			//get all post type jet_cct
			$the_jet_cct = jet_cct_api()->load_jet_cct( array(
					'type' => array(
						'taxonomy',
						'post_type'
					),
					'names' => true )
			);

			//cache the results
			jet_cct_transient_set( $key, $the_jet_cct );

		}

		return $the_jet_cct;

	}

	/**
	 * Get all jet_cct with auto template enable and its settings
	 *
	 * @return array With info about auto template settings per post type
	 *
	 * @since 2.4.5
	 */
	function auto_jet_cct() {
		/**
		 * Filter to override all settings for which templates are used.
		 *
		 * Note: If this filter does not return null, all back-end settings are ignored. To add to settings with a filter, use 'jet_cct_pfat_auto_jet_cct';
		 *
		 * @param array $auto_jet_cct Array of parameters to use instead of those from settings.
		 *
		 * @return array Settings arrays for each post type.
		 *
		 * @since 2.4.5
		 */
		$auto_jet_cct = apply_filters( 'jet_cct_pfat_auto_jet_cct_override', null );
		if ( !is_null( $auto_jet_cct ) ) {
			return $auto_jet_cct;
		}

		//try to get cached results of this method
		$key = '_jet_cct_pfat_auto_jet_cct';
		$auto_jet_cct = jet_cct_transient_get( $key );
	

		//check if we already have the results cached & use it if we can.
		if ( $auto_jet_cct === false  ) {
			//get possible jet_cct
			$the_jet_cct = $this->the_jet_cct();

			//start output array empty
			$auto_jet_cct = array();

			//get jet_cct api class
			$api = jet_cct_api();

			//loop through each to see if auto templates is enabled
			foreach ( $the_jet_cct as $the_jet => $the_jet_label ) {
				//get this jet_cct' data.
				$jet_data = $api->load_jet( array( 'name' => $the_jet ) );

				//if auto template is enabled add info about jet to array
				if ( 1 == jet_cct_v( 'pfat_enable', $jet_data[ 'options' ] ) ) {
					//check if pfat_single and pfat_archive are set
					$single = jet_cct_v( 'pfat_single', $jet_data[ 'options' ], false, true );
					$archive = jet_cct_v( 'pfat_archive', $jet_data[ 'options' ], false, true );
					$single_append = jet_cct_v( 'pfat_append_single', $jet_data[ 'options' ], true, true );
					$archive_append = jet_cct_v( 'pfat_append_archive', $jet_data[ 'options' ], true, true );
					$single_filter = jet_cct_v( 'pfat_filter_single', $jet_data[ 'options' ], 'the_content', true );
					$archive_filter = jet_cct_v( 'pfat_filter_archive', $jet_data[ 'options' ], 'the_content', true );
					$run_outside_loop = jet_cct_v( 'pfat_run_outside_loop', $jet_data[ 'options' ], false, true );
					$type = jet_cct_v( 'type', $jet_data, false, true );
					//check if it's a post type that has an archive
					if ( $type === 'post_type' && $the_jet !== 'post' || $the_jet !== 'page' ) {
						$has_archive = jet_cct_v( 'has_archive', $jet_data['options'], false, true );
					}
					else {
						$has_archive = true;
					}

					if( empty( $single_filter ) ){
						$single_filter = 'the_content';
					}

					if( empty( $archive_filter  ) ){
						$archive_filter = 'the_content';
					}

					//build output array
					$auto_jet_cct[ $the_jet ] = array(
						'name' => $the_jet,
						'label'	=> $the_jet_label,
						'single' => $single,
						'archive' => $archive,
						'single_append' => $single_append,
						'archive_append' => $archive_append,
						'has_archive'	=> $has_archive,
						'single_filter' => $single_filter,
						'archive_filter' => $archive_filter,
						'run_outside_loop' => $run_outside_loop,
						'type' => $type,
					);
				}

			} //endforeach

			//cache the results
			jet_cct_transient_set( $key, $auto_jet_cct );
		}

		/**
		 * Add to or change settings.
		 *
		 * Use this filter to change or add to the settings set in the back-end for this plugin. Has no effect if 'jet_cct_pfat_auto_jet_cct_override' filter is being used.
		 *
		 * @param array $auto_jet_cct Array of parameters to use instead of those from settings.
		 *
		 * @return array Settings arrays for each post type.
		 *
		 * @since 2.4.5
		 */
		$auto_jet_cct = apply_filters( 'jet_cct_pfat_auto_jet_cct', $auto_jet_cct );

		return $auto_jet_cct;

	}

	/**
	 * Fetches the current post type.
	 *
	 * @return string current post type.
	 *
	 * @since 2.4.5
	 */
	function current_post_type() {
		//start by getting current post or stdClass object
		global $wp_query;
		$obj = $wp_query->get_queried_object();

		//see if we are on a post type and if so, set $current_post_type to post type
		if ( isset( $obj->post_type ) ) {
			$current_post_type = $obj->post_type;

		}
		elseif ( isset( $obj->taxonomy ) ) {
			$current_post_type = $obj->taxonomy;
		}
		elseif ( isset ( $obj->name ) ) {
			$current_post_type = $obj->name;
		}
		elseif ( is_home() ) {
			$current_post_type = 'post';
		}
		else {
			$current_post_type = false;
		}

		return $current_post_type;
	}

	/**
	 * Outputs templates after the content as needed.
	 *
	 * @param string $content Post content
	 *
	 * @uses 'the_content' filter
	 *
	 * @return string Post content with the template appended if appropriate.
	 *
	 * @since 2.4.5
	 */
	function front( $content ) {

		// get the current post type
		$current_post_type = $this->current_post_type();

		//now use other methods in class to build array to search in/ use
		$possible_jet_cct = $this->auto_jet_cct();


		//check if $current_post_type is the key of the array of possible jet_cct
		if ( isset( $possible_jet_cct[ $current_post_type ] ) ) {
			//get array for the current post type
			$this_jet = $possible_jet_cct[ $current_post_type ];

			if ( !in_the_loop() && !jet_cct_v( 'run_outside_loop', $this_jet, false ) ) {
				// If outside of the loop, exit quickly
				return $content;
			}

			//build jet_cct object for current item
			global $post;
			$jet_cct = jet_cct( $current_post_type, $post->ID );

			if ( $this_jet[ 'single' ] && is_singular( $current_post_type ) ) {
				//load the template
				$content = $this->load_template( $this_jet[ 'single' ], $content , $jet_cct, $this_jet[ 'single_append' ] );
			}
			//if pfat_archive was set try to use that template
			//check if we are on an archive of the post type
			elseif ( $this_jet[ 'archive' ] && is_post_type_archive( $current_post_type ) ) {
				//load the template
				$content = $this->load_template( $this_jet[ 'archive' ], $content , $jet_cct, $this_jet[ 'archive_append' ] );

			}
			//if pfat_archive was set and we're in the blog index, try to append template
			elseif ( is_home() && $this_jet[ 'archive' ] && $current_post_type === 'post'  ) {
				//append the template
				$content = $this->load_template( $this_jet[ 'archive' ], $content , $jet_cct, $this_jet[ 'archive_append' ] );

			}
			//if is taxonomy archive of the selected taxonomy
			elseif ( is_tax( $current_post_type )  ) {
				//if pfat_single was set try to use that template
				if ( $this_jet[ 'archive' ] ) {
					//append the template
					$content = $this->load_template( $this_jet[ 'archive' ], $content , $jet_cct, $this_jet[ 'archive_append' ] );
				}

			}

		}

		return $content;

	}

	/**
	 * Attach jet_cct Template to $content
	 *
	 * @param string        $template_name  The name of a jet_cct Template to load.
	 * @param string        $content        Post content
	 * @param jet_cct          $jet_cct           Current jet_cct object.
	 * @param bool|string   $append         Optional. Whether to append, prepend or replace content. Defaults to true, which appends, if false, content is replaced, if 'prepend' content is prepended.
	 *
	 * @return string $content with jet_cct Template appended if template exists
	 *
	 * @since 2.4.5
	 */
	function load_template( $template_name, $content, $jet_cct, $append = true  ) {

		//prevent infinite loops caused by this method acting on post_content
		remove_filter( 'the_content', array( $this, 'front' ) );

		/**
		 * Change which template -- by name -- to be used.
		 *
		 * @since 2.5.6
		 *
		 * @param string        $template_name  The name of a jet_cct Template to load.
		 * @param jet_cct          $jet_cct           Current jet_cct object.
		 * @param bool|string   $append         Whether Template will be appended (true), prepended ("prepend") or replaced (false).
		 */
		$template_name = apply_filters( 'jet_cct_auto_template_template_name', $template_name, $jet_cct, $append );

		$template = $jet_cct->template( $template_name );
		add_filter( 'the_content', array( $this, 'front' ) );

		//check if we have a valid template
		if ( !is_null( $template ) ) {
			//if so append it to content or replace content.

			if ( $append === 'replace' ) {
				$content = $template;
			}
			elseif ( $append === 'prepend' ) {
				$content = $template . $content;
			}
			elseif ( $append || $append === 'append' ) {
				$content = $content . $template;
			}
			else {
				$content = $template;
			}
		}

		return $content;
	}


	/**
	 * Sets Styles and Scripts from the Frontier template addons.
	 *
	 * @since 2.4.5
	 */
	function set_frontier_style_script(){

		if( ! class_exists( 'jet_cct_Frontier' ) ) {
			return;
		}

		// cet the current post type
		$current_post_type = $this->current_post_type();

		//now use other methods in class to build array to search in/ use
		$possible_jet_cct = $this->auto_jet_cct();

		if ( isset( $possible_jet_cct[ $current_post_type ] ) ) {

			$this_jet = $possible_jet_cct[ $current_post_type ];

			if ( $this_jet[ 'single' ] && is_singular( $current_post_type ) ) {
				//set template
				$template = $this_jet[ 'single' ];

			}
			//if pfat_archive was set try to use that template
			//check if we are on an archive of the post type
			elseif ( $this_jet[ 'archive' ] && is_post_type_archive( $current_post_type ) ) {
				//set template
				$template = $this_jet[ 'archive' ];

			}
			//if pfat_archive was set and we're in the blog index, try to append template
			elseif ( is_home() && $this_jet[ 'archive' ] && $current_post_type === 'post'  ) {
				//set template
				$template = $this_jet[ 'archive' ];

			}
			//if is taxonomy archive of the selected taxonomy
			elseif ( is_tax( $current_post_type )  ) {
				//if pfat_single was set try to use that template
				if ( $this_jet[ 'archive' ] ) {
					//set template
					$template = $this_jet[ 'archive' ];
				}

			}

			if( isset( $template ) ){
				global $frontier_styles, $frontier_scripts;

				$template_post = jet_cct()->api->load_template( array('name' => $template ) );

				if( !empty( $template_post['id'] ) ){
					// got a template - check for styles & scripts
					$meta = get_post_meta($template_post['id'], 'view_template', true);

					$frontier = new jet_cct_Frontier;
					if(!empty($meta['css'])){
						$frontier_styles .= $meta['css'];
					}

					if(!empty($meta['js'])){
						$frontier_scripts .= $meta['js'];
					}
				}
			}

		}
	}
}
