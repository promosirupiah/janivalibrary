<?php
if ( class_exists( 'jet_cct_PFAT' ) ) {
	return;
}

/**
 * Class jet_cct_Templates_Auto_Template_Settings
 *
 * This class replaced jet_cct_PFAT class
 *
 * @since 2.5.5
 */
class jet_cct_Templates_Auto_Template_Settings {

	/**
	 * Front end class object
	 *
	 * @since 2.5.5
	 *
	 * @var jet_cct_Templates_Auto_Template_Front_End
	 */
	private $front_end_class;

	/**
	 * Holds instance of this class
	 *
	 * @var jet_cct_Templates_Auto_Template_Settings
	 */
	private  $instance;

	/**
	 * Constructor for the jet_cct_PFAT class
	 *
	 * Sets up all the appropriate hooks and actions
	 * within the plugin.
	 *
	 * @since 2.5.5
	 */
	public function __construct() {


		//Add option tab for post types
		add_filter( 'jet_cct_admin_setup_edit_tabs_post_type', array( $this, 'tab' ), 11, 3 );

		//add the same tab for taxonomies
		add_filter( 'jet_cct_admin_setup_edit_tabs_taxonomy', array( $this, 'tab' ), 11, 3 );

		//Add options to the new tab
		add_filter( 'jet_cct_admin_setup_edit_options', array( $this, 'options' ), 12, 2 );


		//Include and init front-end class
		add_action( 'init', array( $this, 'front_end' ), 25 );

		//Delete transients when jet_cct settings are updated.
		add_action( 'update_option', array( $this, 'reset' ), 21, 3 );

		//admin notice for archives without archives
		add_action( 'admin_notices', array( $this, 'archive_warning' ) );

	}

	/**
	 * Initializes the class
	 *
	 * @since 2.5.5
	 */
	public function init() {
		if ( ! is_null( $this->instance ) ) {
			$this->instance = new self;
		}

		return $this->instance;

	}



	/**
	 * The Frontier Auto Display option tab.
	 *
	 * @param array $tabs
	 * @param array $jet
	 * @param array $addtl_args
	 *
	 * @return array
	 *
	 * @since 2.5.5
	 */
	function tab( $tabs, $jet, $addtl_args ) {

		$tabs[ 'jet_cct-pfat' ] = __( 'Auto Template Options', 'jet_cct' );

		return $tabs;

	}

	/**
	 * Adds options for this plugin under the Frontier Auto Template tab.
	 *
	 * @param array $options
	 * @param array $jet
	 *
	 * @return array
	 *
	 * @since 2.5.5
	 *
	 */
	function options( $options, $jet ) {
		//check if it's a post type jet and add fields for that.
		if ( $jet['type'] === 'post_type' )  {
			$options[ 'jet_cct-pfat' ] = array(
				'pfat_enable'         => array(
					'label'             => __( 'Enable Automatic jet_cct Templates for this jet?', 'jet_cct' ),
					'help'              => __( 'When enabled you can specify the names of jet_cct Templates to be used to display items in this jet in the front-end.', 'jet_cct' ),
					'type'              => 'boolean',
					'default'           => false,
					'dependency'        => true,
					'boolean_yes_label' => ''
				),
				'pfat_run_outside_loop' => array(
					'label'             => __( 'Execute Auto Template outside of the WordPress loop? (advanced)', 'jet_cct' ),
					'help'              => __( 'When enabled, the template will be executed whenever the specified filter is called.', 'jet_cct' ),
					'type'              => 'boolean',
					'default'           => false,
					'depends-on'        => array( 'pfat_enable' => true ),
					'boolean_yes_label' => ''
				),
				'pfat_single'         => array(
					'label'      => __( 'Single item view template', 'jet_cct' ),
					'help'       => __( 'Name of jet_cct template to use for single item view.', 'jet_cct' ),
					'type'       => 'text',
					'default'    => false,
					'depends-on' => array( 'pfat_enable' => true )
				),
				'pfat_append_single'  => array(
					'label'      => __( 'Single Template Location', 'jet_cct' ),
					'help'       => __( 'Whether the template will go before, after or in place of the post content.', 'jet_cct' ),
					'depends-on' => array( 'pfat_enable' => true ),
				),
				'pfat_filter_single'  => array(
					'label'      => __( 'Single Template Filter', 'jet_cct' ),
					'help'       => __( 'Which filter to use for single views.', 'jet_cct' ),
					'default'    => 'the_content',
					'type'       => 'text',
					'depends-on' => array( 'pfat_enable' => true ),
				),
				'pfat_archive'        => array(
					'label'      => __( 'Archive view template', 'jet_cct' ),
					'help'       => __( 'Name of jet_cct template to use for use in this jet_cct archive pages.', 'jet_cct' ),
					'type'       => 'text',
					'default'    => false,
					'depends-on' => array( 'pfat_enable' => true )
				),
				'pfat_append_archive' => array(
					'label'      => __( 'Archive Template Location', 'jet_cct' ),
					'help'       => __( 'Whether the template will go before, after or in place of the post content.', 'jet_cct' ),
					'depends-on' => array( 'pfat_enable' => true ),
				),
				'pfat_filter_archive' => array(
					'label'      => __( 'Archive Template Filter', 'jet_cct' ),
					'help'       => __( 'Which filter to use for archives.', 'jet_cct' ),
					'default'    => 'the_content',
					'type'       => 'text',
					'depends-on' => array( 'pfat_enable' => true ),
				),
			);
		}

		//check if it's a taxonomy jet, if so add fields for that
		if ( $jet['type'] === 'taxonomy' ) {
			$options[ 'jet_cct-pfat' ] = array (
				'pfat_enable'  => array (
					'label'             => __( 'Enable Automatic jet_cct Templates for this jet?', 'jet_cct' ),
					'help'              => __( 'When enabled you can specify the names of a jet_cct Template to be used to display items in this jet in the front-end.', 'jet_cct' ),
					'type'              => 'boolean',
					'default'           => false,
					'dependency'        => true,
					'boolean_yes_label' => ''
				),
				'pfat_run_outside_loop' => array(
					'label'             => __( 'Execute Auto Template outside of the WordPress loop? (advanced)', 'jet_cct' ),
					'help'              => __( 'When enabled, the template will be executed whenever the specified filter is called.', 'jet_cct' ),
					'type'              => 'boolean',
					'default'           => false,
					'depends-on'        => array( 'pfat_enable' => true ),
					'boolean_yes_label' => ''
				),
				'pfat_archive'  => array (
					'label'      => __( 'Taxonomy Template', 'jet_cct' ),
					'help'       => __( 'Name of jet_cct template to use for this taxonomy.', 'jet_cct' ),
					'type'       => 'text',
					'default'    => false,
					'depends-on' => array ( 'pfat_enable' => true )
				),
				'pfat_append_archive'  => array (
					'label'      => __( 'Template Location', 'jet_cct' ),
					'help'       => __( 'Whether the template will go before, after or in place of the post content.', 'jet_cct' ),
					'depends-on' => array ( 'pfat_enable' => true ),
				),
			);
		}

		if ( isset( $options[ 'jet_cct-pfat' ] ) ) {

			//field options pick values
			$pick = array (
				'type'               => 'pick',
				'pick_format_type'   => 'single',
				'pick_format_single' => 'dropdown',
				'default'            => 'true',
			);

			//get template titles
			$titles = $this->get_template_titles();

			if ( !empty( $titles ) ) {
				foreach ( $pick as $k => $v ) {
					$options[ 'jet_cct-pfat' ][ 'pfat_single' ][ $k ] = $v;

					$options[ 'jet_cct-pfat' ][ 'pfat_archive' ][ $k ] = $v;

				}

				$options[ 'jet_cct-pfat' ][ 'pfat_archive' ][ 'data' ] = array( null => __('No Archive view template', 'jet_cct') ) + ( array_combine( $this->get_template_titles(), $this->get_template_titles() ) );
				$options[ 'jet_cct-pfat' ][ 'pfat_single' ][ 'data' ] = array_combine( $this->get_template_titles(), $this->get_template_titles() );
			}

			//Add data to $pick for template location
			unset( $pick['data']);
			$location_data =  array (
				'append'  => __( 'After', 'jet_cct' ),
				'prepend' => __( 'Before', 'jet_cct' ),
				'replace' => __( 'Replace', 'jet_cct' ),
			);
			$pick['data'] = $location_data;

			//add location options to fields without type set.
			foreach ( $options[ 'jet_cct-pfat' ] as $k => $option ) {
				if ( !isset( $option[ 'type' ] ) ) {
					$options[ 'jet_cct-pfat' ][ $k ] = array_merge( $option, $pick );
				}

			}

			//remove single from taxonomy
			if( 'taxonomy' === $jet['type'] ){
				unset( $options[ 'jet_cct-pfat' ][ 'pfat_single' ] );
			}

		}

		return $options;

	}

	/**
	 * Include/ init the front end class on the front end only
	 *
	 * @param bool	$load_in_admin Optional. Whether to load in admin. Default is false.
	 *
	 * @return jet_cct_PFAT_Frontend
	 *
	 * @since 2.5.5
	 */
	function front_end( $load_in_admin = false ) {

		if ( !is_admin() || $load_in_admin ) {
			include_once( dirname( __FILE__ ) . '/jet_cct_Templates_Auto_Template_Front_End.php' );

			// Only instantiate if we haven't already
			if ( is_null( $this->front_end_class ) ) {
				$this->front_end_class = new jet_cct_Templates_Auto_Template_Front_End();
			}

			return $this->front_end_class;
		}

	}

	/**
	 * Reset the transients for front-end class when jet_cct are saved.
	 *
	 * @uses update_option hook
	 *
	 * @param string $option
	 * @param mixed $old_value
	 * @param mixed $value
	 *
	 * @since 2.5.5
	 */
	function reset( $option, $old_value, $value ) {

		if ( $option === '_transient_jet_cct_flush_rewrites' ) {
			$this->reseter();
		}

	}


	/**
	 * Delete transients that stores the settings.
	 *
	 * @since 2.5.5
	 */
	function reseter() {

		$keys = array( 'jet_cct_pfat_the_jet_cct', 'jet_cct_pfat_auto_jet_cct', 'jet_cct_pfat_archive_test' );
		foreach( $keys as $key ) {
			jet_cct_transient_clear( $key );
		}

	}

	/**
	 * Test if archive is set for post types that don't have archives.
	 *
	 * @return bool|mixed|null|void
	 *
	 * @since 2.4.5
	 */
	function archive_test() {

		//try to get cached results of this method
		$key = 'jet_cct_pfat_archive_test';
		$archive_test = jet_cct_transient_get( $key );

		if ( $archive_test === false ) {
			$front = $this->front_end( true );
			$auto_jet_cct = $front->auto_jet_cct();

			foreach ( $auto_jet_cct as $name => $jet ) {
				if ( ! $jet[ 'has_archive' ] && $jet[ 'archive' ] && $jet[ 'type' ] !== 'taxonomy' && ! in_array( $name, array( 'post', 'page', 'attachment' ) ) ) {
					$archive_test[ $jet[ 'label' ] ] = 'fail';
				}

			}

			jet_cct_transient_set( $key, $archive_test );

		}

		return $archive_test;

	}

	/**
	 * Throw admin warnings for post types that have archive templates set, but don't support archives
	 *
	 * @since 2.4.5
	 */
	function archive_warning() {

		//create $page variable to check if we are on jet_cct admin page
		$page = jet_cct_v( 'page','get', false, true );

		//check if we are on jet_cct Admin page
		if ( $page === 'jet_cct' ) {
			$archive_test = $this->archive_test();
			if ( is_array( $archive_test ) ) {
				foreach ( $archive_test as $label => $test ) {
					if ( $test === 'fail' ) {
						echo sprintf( '<div id="message" class="error"><p>%s</p></div>',
							sprintf(
								__( 'The jet_cct post type %1$s has an archive template set to be displayed using jet_cct auto template, but the jet does not have an archive. You can enable post type archives in the "Advanced Options" tab.', 'pfat' ),
								$label )
						);
					}

				}

			}

		}

	}

	/**
	 * Get titles of all jet_cct Templates
	 *
	 * @return string[] Array of template names
	 *
	 * @since 2.4.5
	 */
	public function get_template_titles() {

		static $template_titles;

		if ( empty( $template_titles ) ) {
            $all_templates = (array) jet_cct_api()->load_templates( array() );

			$template_titles = array();

            foreach ( $all_templates as $template ) {
                $template_titles[] = $template['name'];
            }
		}

		return $template_titles;

	}


}
