<div class="jet-queries-tools"><?php

	if ( empty( $atts ) ) {
		$atts = array(
			'jet' => ''
		);
	}

	$api = jet_cct_api();
	$_jet_cct = $api->load_jet_cct();
	echo '<select name="jet_reference[jet]" id="jet-reference" class="jet-switch" data-template="#jetref-tmpl" data-target="#jet-reference-wrapper" data-action="pq_loadjet" data-event="change" />';
	echo '<option value="">' . __( 'Select jet to use as reference', 'jet_cct' ) . '</option>';
	foreach ( $_jet_cct as $jet ) {
		echo '<option value="' . esc_attr( $jet[ 'name' ] ) . '" ' . ( $atts[ 'jet' ] == $jet[ 'name' ] ? 'selected="selected"' : '' ) . '>' . esc_html( $jet[ 'label' ] ) . '</option>';
	}
	echo '</select>';
	?></div>
<div id="jet-reference-wrapper" class="jet-reference-wrapper">
	<?php

	if ( !empty( $atts[ 'jet' ] ) ) {
		$fields = pq_loadjet( $atts[ 'jet' ] );
		if ( !empty( $fields ) ) {
			foreach ( $fields as $field ) {
				echo '<div class="jet-field-row">';
				echo '<div class="jet-field-label jet-field-name" data-tag="' . esc_attr( $field ) . '">' . esc_html( $field ) . '</div>';
				echo '</div>';
			}
		}
	}
	else {

	}

	?>
</div>
<script id="jetref-tmpl" type="text/html">
	{{#each this}}
	<div class="jet-field-row">
		<div class="jet-field-label jet-field-name" data-tag="{{this}}">{{this}}</div>
	</div>
	{{/each}}
</script>