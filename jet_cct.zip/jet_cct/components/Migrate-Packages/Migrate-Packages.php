<?php
/**
 * Name: Migrate: Packages
 *
 * Menu Name: Migrate Packages
 *
 * Description: Import/Export your jet_cct, Fields, and other settings from any jet_cct site; Includes an API to Import/Export Packages via PHP
 *
 * Version: 2.0
 *
 * Category: Migration
 *
 * Plugin: jet_cct-migrate-packages/jet_cct-migrate-packages.php
 *
 * @package jet_cct\Components
 * @subpackage Migrate-Packages
 */

if ( class_exists( 'jet_cct_Migrate_Packages' ) )
    return;

class jet_cct_Migrate_Packages extends jet_cctComponent {

    /**
     * Do things like register/enqueue scripts and stylesheets
     *
     * @since 2.0
     */
    public function __construct () {

    }

    /**
     * Enqueue styles
     *
     * @since 2.0
     */
    public function admin_assets () {
        wp_enqueue_style( 'jet_cct-wizard' );
    }

    /**
     * Build admin area
     *
     * @param $options
     *
     * @since 2.0
     */
    public function admin ( $options, $component ) {
        $method = 'import_export'; // ajax_import

        jet_cct_view( jet_cct_DIR . 'components/Migrate-Packages/ui/wizard.php', compact( array_keys( get_defined_vars() ) ) );
    }

    /**
     * Handle the Import/Export AJAX
     *
     * @param $params
     */
    public function ajax_import_export ( $params ) {
        if ( 'import' == $params->import_export ) {
            $data = trim( $params->import_package );

            $content = '<div class="jet_cct-wizard-content">';

            if ( !empty( $data ) ) {
                $imported = $this->import( $data );

                if ( !empty( $imported ) ) {
                    $content .= '<p>Import Complete! The following items were imported:</p>';

                    foreach ( $imported as $type => $import ) {
                        $content .= '<h4>' . ucwords( $type ) . '</h4>';

                        $content .= '<ul class="normal">';

                        foreach ( $import as $k => $what ) {
                            $content .= '<li>' . esc_html( $what ) . '</li>';
                        }

                        $content .= '</ul>';
                    }
                }
            }
            else
                $content .= '<p>Import Error: Invalid Package</p>';

            $content .= '</div>';

            echo $content;
        }
        elseif ( 'export' == $params->import_export ) {
            $params = get_object_vars( $params );
            foreach ( $params as $k => $v ) {
                if ( is_array( $v ) )
                    $params[ $k ] = array_keys( array_filter( $v ) );
            }

            $package = $this->export( $params );

            echo '<div class="jet_cct-field-option">';

            echo jet_cctForm::field( 'export_package', $package, 'paragraph', array( 'attributes' => array( 'style' => 'width: 94%; max-width: 94%; height: 300px;' ) ) );

            echo '</div>';
        }

    }

    /**
     * Import a Package
     *
     * @param string|array $data a JSON array package string, or an array of Package Data
     * @param bool $replace Whether to replace existing jet_cct entirely or just update them
     *
     * @return array|bool
     *
     * @static
     * @since 2.0.5
     */
    public static function import ( $data, $replace = false ) {
        if ( !defined( 'jet_cct_FIELD_STRICT' ) )
            define( 'jet_cct_FIELD_STRICT', false );

        if ( !is_array( $data ) ) {
            $json_data = @json_decode( $data, true );

            if ( !is_array( $json_data ) )
                $json_data = @json_decode( jet_cct_unslash( $data ), true );

            $data = $json_data;
        }

        if ( !is_array( $data ) || empty( $data ) )
            return false;

        $api = jet_cct_api();

        if ( !isset( $data[ 'meta' ] ) || !isset( $data[ 'meta' ][ 'version' ] ) || empty( $data[ 'meta' ][ 'version' ] ) )
            return false;

        // jet_cct 1.x < 1.10
        if ( false === strpos( $data[ 'meta' ][ 'version' ], '.' ) && (int) $data[ 'meta' ][ 'version' ] < 1000 )
            $data[ 'meta' ][ 'version' ] = implode( '.', str_split( $data[ 'meta' ][ 'version' ] ) );
        // jet_cct 1.10 <= 2.0
        elseif ( false === strpos( $data[ 'meta' ][ 'version' ], '.' ) )
            $data[ 'meta' ][ 'version' ] = jet_cct_version_to_point( $data[ 'meta' ][ 'version' ] );

        $found = array();

        if ( isset( $data[ 'jet_cct' ] ) && is_array( $data[ 'jet_cct' ] ) ) {
            foreach ( $data[ 'jet_cct' ] as $jet_data ) {
                if ( isset( $jet_data[ 'id' ] ) )
                    unset( $jet_data[ 'id' ] );

                $jet = $api->load_jet( array( 'name' => $jet_data[ 'name' ] ), false );

                $existing_fields = array();

                if ( !empty( $jet ) ) {
                    // Delete jet if it exists
                    if ( $replace ) {
                        $api->delete_jet( array( 'id' => $jet[ 'id' ] ) );

                        $jet = array( 'fields' => array() );
                    }
                    else
                        $existing_fields = $jet[ 'fields' ];
                }
                else
                    $jet = array( 'fields' => array() );

                // Backwards compatibility
                if ( version_compare( $data[ 'meta' ][ 'version' ], '2.0', '<' ) ) {
                    $core_fields = array(
                        array(
                            'name' => 'created',
                            'label' => 'Date Created',
                            'type' => 'datetime',
                            'options' => array(
                                'datetime_format' => 'ymd_slash',
                                'datetime_time_type' => '12',
                                'datetime_time_format' => 'h_mm_ss_A'
                            ),
                            'weight' => 1
                        ),
                        array(
                            'name' => 'modified',
                            'label' => 'Date Modified',
                            'type' => 'datetime',
                            'options' => array(
                                'datetime_format' => 'ymd_slash',
                                'datetime_time_type' => '12',
                                'datetime_time_format' => 'h_mm_ss_A'
                            ),
                            'weight' => 2
                        ),
                        array(
                            'name' => 'author',
                            'label' => 'Author',
                            'type' => 'pick',
                            'pick_object' => 'user',
                            'options' => array(
                                'pick_format_type' => 'single',
                                'pick_format_single' => 'autocomplete',
                                'default_value' => '{@user.ID}'
                            ),
                            'weight' => 3
                        )
                    );

                    $found_fields = array();

                    if ( !empty( $jet_data[ 'fields' ] ) ) {
                        foreach ( $jet_data[ 'fields' ] as $k => $field ) {
                            $field_type = $field[ 'coltype' ];

                            if ( 'txt' == $field_type )
                                $field_type = 'text';
                            elseif ( 'desc' == $field_type )
                                $field_type = 'wysiwyg';
                            elseif ( 'code' == $field_type )
                                $field_type = 'paragraph';
                            elseif ( 'bool' == $field_type )
                                $field_type = 'boolean';
                            elseif ( 'num' == $field_type )
                                $field_type = 'number';
                            elseif ( 'date' == $field_type )
                                $field_type = 'datetime';

                            $multiple = min( max( (int) $field[ 'multiple' ], 0 ), 1 );

                            $new_field = array(
                                'name' => trim( $field[ 'name' ] ),
                                'label' => trim( $field[ 'label' ] ),
                                'description' => trim( $field[ 'comment' ] ),
                                'type' => $field_type,
                                'weight' => (int) $field[ 'weight' ],
                                'options' => array(
                                    'required' => min( max( (int) $field[ 'required' ], 0 ), 1 ),
                                    'unique' => min( max( (int) $field[ 'unique' ], 0 ), 1 ),
                                    'input_helper' => $field[ 'input_helper' ]
                                )
                            );

                            if ( in_array( $new_field[ 'name' ], $found_fields ) ) {
                                unset( $jet_data[ 'fields' ][ $k ] );

                                continue;
                            }

                            $found_fields[] = $new_field[ 'name' ];

                            if ( 'pick' == $field_type ) {
                                $new_field[ 'pick_object' ] = 'jet';
                                $new_field[ 'pick_val' ] = $field[ 'pickval' ];

                                if ( 'wp_user' == $field[ 'pickval' ] )
                                    $new_field[ 'pick_object' ] = 'user';
                                elseif ( 'wp_post' == $field[ 'pickval' ] )
                                    $new_field[ 'pick_object' ] = 'post_type-post';
                                elseif ( 'wp_page' == $field[ 'pickval' ] )
                                    $new_field[ 'pick_object' ] = 'post_type-page';
                                elseif ( 'wp_taxonomy' == $field[ 'pickval' ] )
                                    $new_field[ 'pick_object' ] = 'taxonomy-category';

                                // This won't work if the field doesn't exist
                                // $new_field[ 'sister_id' ] = $field[ 'sister_field_id' ];

                                $new_field[ 'options' ][ 'pick_filter' ] = $field[ 'pick_filter' ];
                                $new_field[ 'options' ][ 'pick_orderby' ] = $field[ 'pick_orderby' ];
                                $new_field[ 'options' ][ 'pick_display' ] = '';
                                $new_field[ 'options' ][ 'pick_size' ] = 'medium';

                                if ( 1 == $multiple ) {
                                    $new_field[ 'options' ][ 'pick_format_type' ] = 'multi';
                                    $new_field[ 'options' ][ 'pick_format_multi' ] = 'checkbox';
                                    $new_field[ 'options' ][ 'pick_limit' ] = 0;
                                }
                                else {
                                    $new_field[ 'options' ][ 'pick_format_type' ] = 'single';
                                    $new_field[ 'options' ][ 'pick_format_single' ] = 'dropdown';
                                    $new_field[ 'options' ][ 'pick_limit' ] = 1;
                                }
                            }
                            elseif ( 'file' == $field_type ) {
                                $new_field[ 'options' ][ 'file_format_type' ] = 'multi';
                                $new_field[ 'options' ][ 'file_type' ] = 'any';
                            }
                            elseif ( 'number' == $field_type )
                                $new_field[ 'options' ][ 'number_decimals' ] = 2;
                            elseif ( 'desc' == $field[ 'coltype' ] )
                                $new_field[ 'options' ][ 'wysiwyg_editor' ] = 'tinymce';
                            elseif ( 'text' == $field_type )
                                $new_field[ 'options' ][ 'text_max_length' ] = 128;

                            if ( isset( $jet[ 'fields' ][ $new_field[ 'name' ] ] ) )
                                $new_field = array_merge( $jet[ 'fields' ][ $new_field[ 'name' ] ], $new_field );

                            $jet_data[ 'fields' ][ $k ] = $new_field;
                        }
                    }

                    if ( jet_cct_var( 'id', $jet, 0 ) < 1 )
                        $jet_data[ 'fields' ] = array_merge( $core_fields, $jet_data[ 'fields' ] );

                    if ( empty( $jet_data[ 'label' ] ) )
                        $jet_data[ 'label' ] = ucwords( str_replace( '_', ' ', $jet_data[ 'name' ] ) );

                    if ( isset( $jet_data[ 'is_toplevel' ] ) ) {
                        $jet_data[ 'show_in_menu' ] = ( 1 == $jet_data[ 'is_toplevel' ] ? 1 : 0 );

                        unset( $jet_data[ 'is_toplevel' ] );
                    }

                    if ( isset( $jet_data[ 'detail_page' ] ) ) {
                        $jet_data[ 'detail_url' ] = $jet_data[ 'detail_page' ];

                        unset( $jet_data[ 'detail_page' ] );
                    }

                    if ( isset( $jet_data[ 'before_helpers' ] ) ) {
                        $jet_data[ 'pre_save_helpers' ] = $jet_data[ 'before_helpers' ];

                        unset( $jet_data[ 'before_helpers' ] );
                    }

                    if ( isset( $jet_data[ 'after_helpers' ] ) ) {
                        $jet_data[ 'post_save_helpers' ] = $jet_data[ 'after_helpers' ];

                        unset( $jet_data[ 'after_helpers' ] );
                    }

                    if ( isset( $jet_data[ 'pre_drop_helpers' ] ) ) {
                        $jet_data[ 'pre_delete_helpers' ] = $jet_data[ 'pre_drop_helpers' ];

                        unset( $jet_data[ 'pre_drop_helpers' ] );
                    }

                    if ( isset( $jet_data[ 'post_drop_helpers' ] ) ) {
                        $jet_data[ 'post_delete_helpers' ] = $jet_data[ 'post_drop_helpers' ];

                        unset( $jet_data[ 'post_drop_helpers' ] );
                    }

                    $jet_data[ 'name' ] = jet_cct_clean_name( $jet_data[ 'name' ] );

                    $jet_data = array(
                        'name' => $jet_data[ 'name' ],
                        'label' => $jet_data[ 'label' ],
                        'type' => 'jet',
                        'storage' => 'table',
                        'fields' => $jet_data[ 'fields' ],
                        'options' => array(
                            'pre_save_helpers' => jet_cct_var_raw( 'pre_save_helpers', $jet_data ),
                            'post_save_helpers' => jet_cct_var_raw( 'post_save_helpers', $jet_data ),
                            'pre_delete_helpers' => jet_cct_var_raw( 'pre_delete_helpers', $jet_data ),
                            'post_delete_helpers' => jet_cct_var_raw( 'post_delete_helpers', $jet_data ),
                            'show_in_menu' => ( 1 == jet_cct_var_raw( 'show_in_menu', $jet_data, 0 ) ? 1 : 0 ),
                            'detail_url' => jet_cct_var_raw( 'detail_url', $jet_data ),
                            'jet_index' => 'name'
                        ),
                    );
                }

                $jet = array_merge( $jet, $jet_data );

                foreach ( $jet[ 'fields' ] as $k => $field ) {
                    if ( isset( $field[ 'id' ] ) && !isset( $existing_fields[ $field[ 'name' ] ] ) )
                        unset( $jet[ 'fields' ][ $k ][ 'id' ] );

                    if ( isset( $field[ 'jet_id' ] ) )
                        unset( $jet[ 'fields' ][ $k ][ 'jet_id' ] );

                    if ( isset( $existing_fields[ $field['name'] ] ) ) {
                        if ( $existing_field = jet_cct_api()->load_field( array( 'name' => $field['name'], 'jet' => $jet[ 'name' ] ) ) )
                            $jet['fields'][$k]['id'] = $existing_field['id'];
                    }

                    if ( isset( $field[ 'jet' ] ) )
                        unset( $jet[ 'fields' ][ $k ][ 'jet' ] );
                }

                $api->save_jet( $jet );

                if ( !isset( $found[ 'jet_cct' ] ) )
                    $found[ 'jet_cct' ] = array();

                $found[ 'jet_cct' ][ $jet[ 'name' ] ] = $jet[ 'label' ];
            }
        }

        if ( isset( $data[ 'templates' ] ) && is_array( $data[ 'templates' ] ) ) {
            foreach ( $data[ 'templates' ] as $template_data ) {
                if ( isset( $template_data[ 'id' ] ) )
                    unset( $template_data[ 'id' ] );

                $template = $api->load_template( array( 'name' => $template_data[ 'name' ] ) );

                if ( !empty( $template ) ) {
                    // Delete Template if it exists
                    if ( $replace ) {
                        $api->delete_template( array( 'id' => $template[ 'id' ] ) );

                        $template = array();
                    }
                }
                else
                    $template = array();

                $template = array_merge( $template, $template_data );

                $api->save_template( $template );

                if ( !isset( $found[ 'templates' ] ) )
                    $found[ 'templates' ] = array();

                $found[ 'templates' ][ $template[ 'name' ] ] = $template[ 'name' ];
            }
        }

        // Backwards compatibility
        if ( isset( $data[ 'jet_pages' ] ) ) {
            $data[ 'pages' ] = $data[ 'jet_pages' ];

            unset( $data[ 'jet_pages' ] );
        }

        if ( isset( $data[ 'pages' ] ) && is_array( $data[ 'pages' ] ) ) {
            foreach ( $data[ 'pages' ] as $page_data ) {
                if ( isset( $page_data[ 'id' ] ) )
                    unset( $page_data[ 'id' ] );

                $page = $api->load_page( array( 'name' => jet_cct_var_raw( 'name', $page_data, jet_cct_var_raw( 'uri', $page_data ), null, true ) ) );

                if ( !empty( $page ) ) {
                    // Delete Page if it exists
                    if ( $replace ) {
                        $api->delete_page( array( 'id' => $page[ 'id' ] ) );

                        $page = array();
                    }
                }
                else
                    $page = array();

                // Backwards compatibility
                if ( isset( $page_data[ 'uri' ] ) ) {
                    $page_data[ 'name' ] = $page_data[ 'uri' ];

                    unset( $page_data[ 'uri' ] );
                }

                if ( isset( $page_data[ 'phpcode' ] ) ) {
                    $page_data[ 'code' ] = $page_data[ 'phpcode' ];

                    unset( $page_data[ 'phpcode' ] );
                }

                $page = array_merge( $page, $page_data );

                $page[ 'name' ] = trim( $page[ 'name' ], '/' );

                $api->save_page( $page );

                if ( !isset( $found[ 'pages' ] ) )
                    $found[ 'pages' ] = array();

                $found[ 'pages' ][ $page[ 'name' ] ] = $page[ 'name' ];
            }
        }

        if ( isset( $data[ 'helpers' ] ) && is_array( $data[ 'helpers' ] ) ) {
            foreach ( $data[ 'helpers' ] as $helper_data ) {
                if ( isset( $helper_data[ 'id' ] ) )
                    unset( $helper_data[ 'id' ] );

                $helper = $api->load_helper( array( 'name' => $helper_data[ 'name' ] ) );

                if ( !empty( $helper ) ) {
                    // Delete Helper if it exists
                    if ( $replace ) {
                        $api->delete_helper( array( 'id' => $helper[ 'id' ] ) );

                        $helper = array();
                    }
                }
                else
                    $helper = array();

                // Backwards compatibility
                if ( isset( $helper_data[ 'phpcode' ] ) ) {
                    $helper_data[ 'code' ] = $helper_data[ 'phpcode' ];

                    unset( $helper_data[ 'phpcode' ] );
                }

                if ( isset( $helper_data[ 'type' ] ) ) {
                    if ( 'before' == $helper_data[ 'type' ] )
                        $helper_data[ 'type' ] = 'pre_save';
                    elseif ( 'after' == $helper_data[ 'type' ] )
                        $helper_data[ 'type' ] = 'post_save';
                }

                $helper = array_merge( $helper, $helper_data );

                if ( isset( $helper[ 'type' ] ) ) {
                    $helper[ 'helper_type' ] = $helper[ 'type' ];

                    unset( $helper[ 'helper_type' ] );
                }

                $api->save_helper( $helper );

                if ( !isset( $found[ 'helpers' ] ) )
                    $found[ 'helpers' ] = array();

                $found[ 'helpers' ][ $helper[ 'name' ] ] = $helper[ 'name' ];
            }
        }

        $found = apply_filters( 'jet_cct_packages_import', $found, $data, $replace );

        if ( !empty( $found ) )
            return $found;

        return false;
    }

    /**
     * Export a Package
     *
     * $params['jet_cct'] string|array|bool jet IDs to export, or set to true to export all
     * $params['templates'] string|array|bool Template IDs to export, or set to true to export all
     * $params['pages'] string|array|bool Page IDs to export, or set to true to export all
     * $params['helpers'] string|array|bool Helper IDs to export, or set to true to export all
     *
     * @param array $params Array of things to export
     *
     * @return array|bool
     *
     * @static
     * @since 2.0.5
     */
    public static function export ( $params ) {
        $export = array(
            'meta' => array(
                'version' => jet_cct_VERSION,
                'build' => time()
            )
        );

        if ( is_object( $params ) )
            $params = get_object_vars( $params );

        $api = jet_cct_api();

        $jet_ids = jet_cct_var_raw( 'jet_cct', $params );
        $template_ids = jet_cct_var_raw( 'templates', $params );
        $page_ids = jet_cct_var_raw( 'pages', $params );
        $helper_ids = jet_cct_var_raw( 'helpers', $params );

        if ( !empty( $jet_ids ) ) {
            $api_params = array( 'export' => true );

            if ( true !== $jet_ids )
                $api_params[ 'ids' ] = (array) $jet_ids;

            $export[ 'jet_cct' ] = $api->load_jet_cct( $api_params );

            $options_ignore = array(
                'jet_id',
                'old_name',
                'object_type',
                'object_name',
                'object_hierarchical',
                'table',
                'meta_table',
                'jet_table',
                'field_id',
                'field_index',
                'field_slug',
                'field_type',
                'field_parent',
                'field_parent_select',
                'meta_field_id',
                'meta_field_index',
                'meta_field_value',
                'jet_field_id',
                'jet_field_index',
                'object_fields',
                'join',
                'where',
                'where_default',
                'orderby',
                'jet',
                'recurse',
                'table_info',
                'attributes',
                'group',
                'grouped',
                'developer_mode',
                'dependency',
                'depends-on',
                'excludes-on'
            );

            $field_types = jet_cctForm::field_types();

            $field_type_options = array();

            foreach ( $field_types as $type => $field_type_data ) {
                $field_type_options[ $type ] = jet_cctForm::ui_options( $type );
            }

            foreach ( $export[ 'jet_cct' ] as &$jet ) {
                if ( isset( $jet[ 'options' ] ) ) {
                    $jet = array_merge( $jet, $jet[ 'options' ] );

                    unset( $jet[ 'options' ] );
                }

                foreach ( $jet as $option => $option_value ) {
                    if ( in_array( $option, $options_ignore ) || null === $option_value )
                        unset( $jet[ $option ] );
                }

                if ( !empty( $jet[ 'fields' ] ) ) {
                    foreach ( $jet[ 'fields' ] as &$field ) {
                        if ( isset( $field[ 'options' ] ) ) {
                            $field = array_merge( $field, $field[ 'options' ] );

                            unset( $field[ 'options' ] );
                        }

                        foreach ( $field as $option => $option_value ) {
                            if ( in_array( $option, $options_ignore ) || null === $option_value )
                                unset( $field[ $option ] );
                        }

                        foreach ( $field_type_options as $type => $options ) {
                            if ( $type == jet_cct_var( 'type', $field ) )
                                continue;

                            foreach ( $options as $option_data ) {
                                if ( isset( $option_data[ 'group' ] ) && is_array( $option_data[ 'group' ] ) && !empty( $option_data[ 'group' ] ) ) {
                                    if ( isset( $field[ $option_data[ 'name' ] ] ) )
                                        unset( $field[ $option_data[ 'name' ] ] );

                                    foreach ( $option_data[ 'group' ] as $group_option_data ) {
                                        if ( isset( $field[ $group_option_data[ 'name' ] ] ) )
                                            unset( $field[ $group_option_data[ 'name' ] ] );
                                    }
                                }
                                elseif ( isset( $field[ $option_data[ 'name' ] ] ) )
                                    unset( $field[ $option_data[ 'name' ] ] );
                            }
                        }
                    }
                }
            }
        }

        if ( !empty( $template_ids ) ) {
            $api_params = array();

            if ( true !== $template_ids )
                $api_params[ 'ids' ] = (array) $template_ids;

            $export[ 'templates' ] = $api->load_templates( $api_params );
        }

        if ( !empty( $page_ids ) ) {
            $api_params = array();

            if ( true !== $page_ids )
                $api_params[ 'ids' ] = (array) $page_ids;

            $export[ 'pages' ] = $api->load_pages( $api_params );
        }

        if ( !empty( $helper_ids ) ) {
            $api_params = array();

            if ( true !== $helper_ids )
                $api_params[ 'ids' ] = (array) $helper_ids;

            $export[ 'helpers' ] = $api->load_helpers( $api_params );
        }

        $export = apply_filters( 'jet_cct_packages_export', $export, $params );

        if ( 1 == count( $export ) )
            return false;

        $export = version_compare( PHP_VERSION, '5.4.0', '>=' ) ? json_encode( $export, JSON_UNESCAPED_UNICODE ) : json_encode( $export );

        return $export;
    }
}