<div class="wrap jet_cct-admin">
    <script>
        var jet_cct_URL = '<?php echo esc_js( jet_cct_URL ); ?>';
    </script>
    <div id="icon-jet_cct" class="icon32"><br /></div>

    <form action="" method="post" class="jet_cct-submittable">
        <div class="jet_cct-submittable-fields">
            <?php echo jet_cctForm::field( 'action', 'jet_cct_admin_components', 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'component', $component, 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'method', $method, 'hidden' ); ?>
            <?php echo jet_cctForm::field( '_wpnonce', wp_create_nonce( 'jet_cct-component-' . $component . '-' . $method ), 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'import_export', 'export', 'hidden' ); ?>

            <h2 class="italicized"><?php _e( 'Migrate: Packages', 'jet_cct' ); ?></h2>

            <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />

            <div id="jet_cct-wizard-box" class="jet_cct-wizard-steps-2" data-step-process="1">
                <div id="jet_cct-wizard-heading">
                    <ul>
                        <li class="jet_cct-wizard-menu-current" data-step="1">
                            <i></i> <span>1</span> <?php _e( 'Choose', 'jet_cct' ); ?>
                            <em></em>
                        </li>
                        <li data-step="2">
                            <i></i> <span>2</span> <?php _e( 'Import / Export', 'jet_cct' ); ?>
                            <em></em>
                        </li>
                    </ul>
                </div>

                <div id="jet_cct-wizard-main">
                    <?php
                        $api = jet_cct_api();

                        $jet_cct = $api->load_jet_cct( array( 'fields' => false ) );
                        $jet_templates = $api->load_templates();
                        $jet_pages = $api->load_pages();
                        $jet_helpers = $api->load_helpers();

                        $export = true;

                        if ( empty( $jet_cct ) && empty( $jet_templates ) && empty( $jet_pages ) && empty( $jet_helpers ) )
                            $export = false;
                    ?>

                    <div id="jet_cct-wizard-panel-1" class="jet_cct-wizard-panel">
                        <div class="jet_cct-wizard-content">
                            <p><?php _e( 'Packages allow you to import/export your jet_cct, Fields, and other settings between any jet_cct sites.', 'jet_cct' ); ?></p>
                        </div>

                        <div id="jet_cct-wizard-options">
                            <div class="jet_cct-wizard-option">
                                <a href="#jet_cct-wizard-import" data-opt="import">
                                    <h2><?php _e( 'Import', 'jet_cct' ); ?></h2>

                                    <p><?php _e( 'Import a package of jet_cct, Fields, and other settings from another site.', 'jet_cct' ); ?></p>
                                </a>

                                <p><br /></p>
                            </div>

                            <?php
                                if ( $export ) {
                            ?>
                            <div class="jet_cct-wizard-option">
                                <a href="#jet_cct-wizard-export" data-opt="export">
                                    <h2><?php _e( 'Export', 'jet_cct' ); ?></h2>

                                    <p><?php _e( 'Choose which jet_cct, Fields, and other settings to export into a package.', 'jet_cct' ); ?></p>
                                </a>

                                <p><br /></p>
                            </div>
                            <?php
                                }
                            ?>
                        </div>
                    </div>

                    <div id="jet_cct-wizard-panel-2" class="jet_cct-wizard-panel">
                        <div class="jet_cct-wizard-option-content" id="jet_cct-wizard-import">
                            <div class="jet_cct-wizard-content">
                                <p><?php _e( 'Packages allow you to import/export your jet_cct, Fields, and other settings between any jet_cct sites.', 'jet_cct' ); ?></p>
                            </div>

                            <div class="stuffbox">
                                <h3><label for="link_name"><?php _e( 'Paste the Package Code', 'jet_cct' ); ?></label></h3>

                                <div class="inside jet_cct-manage-field jet_cct-dependency">
                                    <div class="jet_cct-field-option">
                                        <?php
                                            echo jet_cctForm::field( 'import_package', jet_cct_var_raw( 'import_package', 'post' ), 'paragraph', array( 'attributes' => array( 'style' => 'width: 94%; max-width: 94%; height: 300px;' ) ) );
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="jet_cct-wizard-option-content" id="jet_cct-wizard-export">
                            <div class="jet_cct-wizard-content">
                                <p><?php _e( 'Packages allow you to import/export your jet_cct, Fields, and other settings between any jet_cct sites.', 'jet_cct' ); ?></p>
                            </div>

                            <?php
                                if ( !empty( $jet_cct ) ) {
                                    $data = $jet_cct;
                                    $data_name = 'jet_cct';
                            ?>
                                <div class="stuffbox jet_cct-package-import-group">
                                    <h3><label for="link_name"><?php _e( 'Choose which jet_cct to export', 'jet_cct' ); ?></label></h3>

                                    <div class="inside jet_cct-manage-field jet_cct-dependency">
                                        <div class="jet_cct-field-option-group">
                                            <p>
                                                <a href="#toggle" class="button jet_cct-wizard-toggle-all" data-toggle="<?php echo esc_attr( $data_name ); ?>"><?php _e( 'Toggle all on / off', 'jet_cct' ); ?></a>
                                            </p>

                                            <div class="jet_cct-pick-values jet_cct-pick-checkbox jet_cct-zebra">
                                                <ul>
                                                    <?php
                                                        $zebra = false;

                                                        foreach ( $data as $item ) {
                                                            $checked = true;

                                                            $class = ( $zebra ? 'even' : 'odd' );

                                                            $zebra = ( !$zebra );
                                                    ?>
                                                        <li class="jet_cct-zebra-<?php echo esc_attr( $class ); ?>">
                                                            <?php echo jet_cctForm::field( $data_name . '[' . $item[ 'id' ] . ']', $checked, 'boolean', array( 'boolean_yes_label' => $item[ 'name' ] . ( !empty( $item[ 'label' ] ) ? ' (' . $item[ 'label' ] . ')' : '' ) ) ); ?>
                                                        </li>
                                                    <?php
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                }

                                if ( !empty( $jet_templates ) ) {
                                    $data = $jet_templates;
                                    $data_name = 'templates';
                            ?>
                                <div class="stuffbox jet_cct-package-import-group">
                                    <h3><label for="link_name"><?php _e( 'Choose which jet Templates to export', 'jet_cct' ); ?></label></h3>

                                    <div class="inside jet_cct-manage-field jet_cct-dependency">
                                        <div class="jet_cct-field-option-group">
                                            <p>
                                                <a href="#toggle" class="button jet_cct-wizard-toggle-all" data-toggle="<?php echo esc_attr( $data_name ); ?>"><?php _e( 'Toggle all on / off', 'jet_cct' ); ?></a>
                                            </p>

                                            <div class="jet_cct-pick-values jet_cct-pick-checkbox jet_cct-zebra">
                                                <ul>
                                                    <?php
                                                        $zebra = false;

                                                        foreach ( $data as $item ) {
                                                            $checked = true;

                                                            $class = ( $zebra ? 'even' : 'odd' );

                                                            $zebra = ( !$zebra );
                                                    ?>
                                                        <li class="jet_cct-zebra-<?php echo esc_attr( $class ); ?>">
                                                            <?php echo jet_cctForm::field( $data_name . '[' . $item[ 'id' ] . ']', $checked, 'boolean', array( 'boolean_yes_label' => $item[ 'name' ] . ( !empty( $item[ 'label' ] ) ? ' (' . $item[ 'label' ] . ')' : '' ) ) ); ?>
                                                        </li>
                                                    <?php
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                }

                                if ( !empty( $jet_pages ) ) {
                                    $data = $jet_pages;
                                    $data_name = 'pages';
                            ?>
                                <div class="stuffbox jet_cct-package-import-group">
                                    <h3><label for="link_name"><?php _e( 'Choose which jet Pages to export', 'jet_cct' ); ?></label></h3>

                                    <div class="inside jet_cct-manage-field jet_cct-dependency">
                                        <div class="jet_cct-field-option-group">
                                            <p>
                                                <a href="#toggle" class="button jet_cct-wizard-toggle-all" data-toggle="<?php echo esc_attr( $data_name ); ?>"><?php _e( 'Toggle all on / off', 'jet_cct' ); ?></a>
                                            </p>

                                            <div class="jet_cct-pick-values jet_cct-pick-checkbox jet_cct-zebra">
                                                <ul>
                                                    <?php
                                                        $zebra = false;

                                                        foreach ( $data as $item ) {
                                                            $checked = true;

                                                            $class = ( $zebra ? 'even' : 'odd' );

                                                            $zebra = ( !$zebra );
                                                    ?>
                                                        <li class="jet_cct-zebra-<?php echo esc_attr( $class ); ?>">
                                                            <?php echo jet_cctForm::field( $data_name . '[' . $item[ 'id' ] . ']', $checked, 'boolean', array( 'boolean_yes_label' => $item[ 'name' ] . ( !empty( $item[ 'label' ] ) ? ' (' . $item[ 'label' ] . ')' : '' ) ) ); ?>
                                                        </li>
                                                    <?php
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                }

                                if ( !empty( $jet_helpers ) ) {
                                    $data = $jet_helpers;
                                    $data_name = 'helpers';
                            ?>
                                <div class="stuffbox jet_cct-package-import-group">
                                    <h3><label for="link_name"><?php _e( 'Choose which jet Helpers to export', 'jet_cct' ); ?></label></h3>

                                    <div class="inside jet_cct-manage-field jet_cct-dependency">
                                        <div class="jet_cct-field-option-group">
                                            <p>
                                                <a href="#toggle" class="button jet_cct-wizard-toggle-all" data-toggle="<?php echo esc_attr( $data_name ); ?>"><?php _e( 'Toggle all on / off', 'jet_cct' ); ?></a>
                                            </p>

                                            <div class="jet_cct-pick-values jet_cct-pick-checkbox jet_cct-zebra">
                                                <ul>
                                                    <?php
                                                        $zebra = false;

                                                        foreach ( $data as $item ) {
                                                            $checked = true;

                                                            $class = ( $zebra ? 'even' : 'odd' );

                                                            $zebra = ( !$zebra );
                                                    ?>
                                                        <li class="jet_cct-zebra-<?php echo esc_attr( $class ); ?>">
                                                            <?php echo jet_cctForm::field( $data_name . '[' . $item[ 'id' ] . ']', $checked, 'boolean', array( 'boolean_yes_label' => $item[ 'name' ] . ( !empty( $item[ 'label' ] ) ? ' (' . $item[ 'label' ] . ')' : '' ) ) ); ?>
                                                        </li>
                                                    <?php
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                }

                                do_action( 'jet_cct_packages_export_options', $jet_cct, $jet_templates, $jet_pages, $jet_helpers );
                            ?>
                        </div>

                        <span id="import-export"></span>

                        <div class="stuffbox hidden" id="import-export-results">
                            <h3><label for="link_name"><?php _e( 'Results', 'jet_cct' ); ?></label></h3>

                            <div class="inside jet_cct-manage-field jet_cct-dependency">
                            </div>
                        </div>
                    </div>

                    <div id="jet_cct-wizard-actions">
                        <div id="jet_cct-wizard-toolbar">
                            <a href="#start" id="jet_cct-wizard-start" class="button button-secondary"><?php _e( 'Start Over', 'jet_cct' ); ?></a> <a href="#next" id="jet_cct-wizard-next" class="button button-primary" data-again="<?php esc_attr_e( 'Process Again', 'jet_cct' ); ?>" data-next="<?php esc_attr_e( 'Continue', 'jet_cct' ); ?>" data-finished="<?php esc_attr_e( 'Finished', 'jet_cct' ); ?>" data-processing="<?php esc_attr_e( 'Processing', 'jet_cct' ); ?>.."><?php _e( 'Continue', 'jet_cct' ); ?></a>
                        </div>
                        <div id="jet_cct-wizard-finished">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript">
    var jet_cct_admin_wizard_callback = function ( step, completed ) {
        console.log( step );
        console.log( completed );

        if ( 2 == step || !step) {
            jQuery( '#jet_cct-wizard-panel-2 div#import-export-results' ).slideUp( 'fast', function () {
                jQuery( '#jet_cct-wizard-panel-2 div#import-export-results div.inside' ).html( '' );
            } );
        }

        return true;
    }

    var jet_cct_admin_submit_callback = function ( id ) {
        jQuery( '#jet_cct-wizard-panel-2 div#import-export-results div.inside' ).html( id );
        jQuery( '#jet_cct-wizard-panel-2 div#import-export-results' ).slideDown( 'fast' );

        jQuery( '#jet_cct-wizard-next' ).css( 'cursor', 'pointer' );
        jQuery( '#jet_cct-wizard-next' ).prop( 'disabled', false );
        jQuery( '#jet_cct-wizard-next' ).text( jQuery( '#jet_cct-wizard-next' ).data( 'again' ) );

        window.location.hash = 'import-export';

        if ( 'export' == jQuery( '#jet_cct-form-ui-import-export' ).val() ) {
            // @todo We need copy/paste functionality here
            //jQuery( '#jet_cct-wizard-panel-2 div#import-export-results div.inside textarea' ).select();
        }

        return false;
    };

    var jet_cct_admin_option_select_callback = function ( $opt ) {
        jQuery( '#jet_cct-form-ui-import-export' ).val( $opt.data( 'opt' ) );
    };

    var jet_cct_admin_wizard_startover_callback = function () {
        jQuery( '#jet_cct-wizard-panel-2 div#import-export-results' ).hide();
        jQuery( '#jet_cct-wizard-panel-2 div#import-export-results div.inside' ).html( '' );
    };

    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'wizard' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'advanced' );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'sluggable' );

        var toggle_all = {};

        $( '.jet_cct-wizard-toggle-all' ).on( 'click', function ( e ) {
            e.preventDefault();

            if ( 'undefined' == typeof toggle_all[ $( this ).data( 'toggle' ) ] )
                toggle_all[ $( this ).data( 'toggle' ) ] = true;

            $( this ).closest( '.jet_cct-field-option-group' ).find( '.jet_cct-field.jet_cct-boolean input[type="checkbox"]' ).prop( 'checked', ( !toggle_all[ $( this ).data( 'toggle' ) ] ) );

            toggle_all[ $( this ).data( 'toggle' ) ] = ( !toggle_all[ $( this ).data( 'toggle' ) ] );
        } );
    } );
</script>