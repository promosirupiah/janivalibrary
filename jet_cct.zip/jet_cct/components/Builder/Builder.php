<?php
/**
 * Name: Builder Integration
 *
 * Description: Integration with the <a href="http://ithemes.com/">Builder</a> theme / child themes from <a href="http://ithemes.com/">iThemes</a>; Adds new modules to the Layout engine
 *
 * Version: 1.0
 *
 * Category: Integration
 *
 * Plugin: jet_cct-builder/jet_cct-builder.php
 *
 * @package jet_cct\Components
 * @subpackage Builder
 */

if ( !function_exists( 'jet_cct_builder_modules_init' ) ) {
    function jet_cct_builder_modules_init () {
        require_once( jet_cct_DIR . 'components/Builder/modules/field/jet_cctBuilderModuleField.php' );
        require_once( jet_cct_DIR . 'components/Builder/modules/form/jet_cctBuilderModuleForm.php' );
        require_once( jet_cct_DIR . 'components/Builder/modules/list/jet_cctBuilderModuleList.php' );
        require_once( jet_cct_DIR . 'components/Builder/modules/single/jet_cctBuilderModuleSingle.php' );
        require_once( jet_cct_DIR . 'components/Builder/modules/view/jet_cctBuilderModuleView.php' );
    }
    add_action( 'builder_modules_loaded', 'jet_cct_builder_modules_init' );
}