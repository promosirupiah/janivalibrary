<?php
/**
 * @package jet_cct\Components
 * @subpackage Builder
 */
if ( !class_exists( 'LayoutModule' ) )
    return;

if ( !class_exists( 'jet_cctBuilderModuleForm' ) ) {
    class jet_cctBuilderModuleForm extends LayoutModule {

        var $_name = '';
        var $_var = 'jet_cct-builder-form';
        var $_description = '';
        var $_editor_width = 500;
        var $_can_remove_wrappers = true;

        /**
         * Register the Module
         */
        public function __construct () {
            $this->_name = __( 'jet_cct - Form', 'jet_cct' );
            $this->_description = __( 'Display a form for creating and editing jet items', 'jet_cct' );
            $this->module_path = dirname( __FILE__ );

            $this->LayoutModule();
        }

        /**
         * Set default variables
         *
         * @param $defaults
         *
         * @return mixed
         */
        function _get_defaults ( $defaults ) {
            $new_defaults = array(
                'jet_type' => '',
                'slug' => '',
                'fields' => '',
                'label' => __( 'Submit', 'jet_cct' ),
                'thank_you' => '',
                'sidebar' => 'none'
            );

            return ITUtility::merge_defaults( $new_defaults, $defaults );
        }

        /**
         * Output something before the table form
         *
         * @param object $form Form class
         * @param bool $results
         */
        function _before_table_edit ( $form, $results = true ) {
?>
    <p><?php echo $this->_description; ?></p>
<?php
        }

        /**
         * Output something at the start of the table form
         *
         * @param object $form Form class
         * @param bool $results
         */
        function _start_table_edit ( $form, $results = true ) {
            $api = jet_cct_api();
            $all_jet_cct = $api->load_jet_cct( array( 'names' => true ) );

            $jet_types = array();

            foreach ( $all_jet_cct as $jet_name => $jet_label ) {
                $jet_types[ $jet_name ] = $jet_label . ' (' . $jet_name . ')';
            }
?>
    <tr>
        <td valign="top">
            <label for="jet_type"><?php _e( 'jet', 'jet_cct' ); ?></label>
        </td>
        <td>
            <?php
                if ( 0 < count( $all_jet_cct ) )
                    $form->add_drop_down( 'jet_type', $jet_types );
                else
                    echo '<strong class="red">' . __( 'None Found', 'jet_cct' ) . '</strong>';
            ?>
        </td>
    </tr>
    <tr>
        <td valign="top">
            <label for="slug"><?php _e( 'Slug or ID', 'jet_cct' ); ?></label>
        </td>
        <td>
            <?php $form->add_text_box( 'slug' ); ?>
        </td>
    </tr>
    <tr>
        <td valign="top">
            <label for="fields"><?php _e( 'Fields (comma-separated)', 'jet_cct' ); ?></label>
        </td>
        <td>
            <?php $form->add_text_box( 'fields' ); ?>
        </td>
    </tr>
    <tr>
        <td valign="top">
            <label for="label"><?php _e( 'Submit Label', 'jet_cct' ); ?></label>
        </td>
        <td>
            <?php $form->add_text_box( 'label' ); ?>
        </td>
    </tr>
    <tr>
        <td valign="top">
            <label for="thank_you"><?php _e( 'Thank You URL upon submission', 'jet_cct' ); ?></label>
        </td>
        <td>
            <?php $form->add_text_box( 'thank_you' ); ?>
        </td>
    </tr>
<?php
        }

        /**
         * Module Output
         */
        function _render ( $fields ) {
            $args = array(
                'name' => trim( jet_cct_var_raw( 'jet_type', $fields[ 'data' ], '' ) ),
                'slug' => trim( jet_cct_var_raw( 'slug', $fields[ 'data' ], '' ) ),
                'fields' => trim( jet_cct_var_raw( 'fields', $fields[ 'data' ], '' ) ),
                'label' => trim( jet_cct_var_raw( 'label', $fields[ 'data' ], __( 'Submit', 'jet_cct' ), null, true ) ),
                'thank_you' => trim( jet_cct_var_raw( 'thank_you', $fields[ 'data' ], '' ) ),
                'form' => 1
            );

            if ( 0 < strlen( $args[ 'name' ] ) )
                echo jet_cct_shortcode( $args, ( isset( $content ) ? $content : null ) );
        }

    }
}

new jet_cctBuilderModuleForm();