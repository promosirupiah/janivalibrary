<div class="wrap jet_cct-admin">
    <script>
        var jet_cct_URL = '<?php echo esc_js( jet_cct_URL ); ?>';
    </script>
    <div id="icon-jet_cct" class="icon32"><br /></div>

    <form action="" method="post" class="jet_cct-submittable">
        <div class="jet_cct-submittable-fields">
            <?php echo jet_cctForm::field( 'action', 'jet_cct_admin_components', 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'component', $component, 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'method', $method, 'hidden' ); ?>
            <?php echo jet_cctForm::field( '_wpnonce', wp_create_nonce( 'jet_cct-component-' . $component . '-' . $method ), 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'cleanup', 0, 'hidden', array( 'attributes' => array( 'id' => 'jet_cct_cleanup' ) ) ); ?>

            <h2 class="italicized"><?php _e( 'Migrate: Import from Custom Post Type UI', 'jet_cct' ); ?></h2>

            <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />

            <div id="jet_cct-wizard-box" class="jet_cct-wizard-steps-2 jet_cct-wizard-hide-first">
                <div id="jet_cct-wizard-heading">
                    <ul>
                        <li class="jet_cct-wizard-menu-current" data-step="1">
                            <i></i> <span>1</span> <?php _e( 'Setup', 'jet_cct' ); ?>
                            <em></em>
                        </li>
                        <li data-step="2">
                            <i></i> <span>2</span> <?php _e( 'Migrate', 'jet_cct' ); ?>
                            <em></em>
                        </li>
                    </ul>
                </div>
                <div id="jet_cct-wizard-main">
                    <div id="jet_cct-wizard-panel-1" class="jet_cct-wizard-panel">
                        <div class="jet_cct-wizard-content">
                            <p><?php _e( 'Custom Post Type UI provides an interface to create Custom Post Types and Custom Taxonomies. You can import these and their settings directly into jet_cct 2.0', 'jet_cct' ); ?></p>
                        </div>
                        <div id="jet_cct-wizard-options">
                            <div class="jet_cct-wizard-option">
                                <a href="#jet_cct-wizard-import" data-opt="0">
                                    <h2><?php _e( 'Import Only', 'jet_cct' ); ?></h2>

                                    <p><?php _e( 'This will import your Custom Post Types and Taxonomies.', 'jet_cct' ); ?></p>
                                </a>

                                <p><br /></p>
                            </div>
                            <div class="jet_cct-wizard-option">
                                <a href="#jet_cct-wizard-import-clean" data-opt="1">
                                    <h2><?php _e( 'Import and Clean Up', 'jet_cct' ); ?></h2>

                                    <p><?php _e( 'This will import your Custom Post Types and Taxonomies, and then remove them from Custom Post Type UI.', 'jet_cct' ); ?></p>
                                </a>

                                <p><br /></p>
                            </div>
                        </div>
                    </div>
                    <div id="jet_cct-wizard-panel-2" class="jet_cct-wizard-panel">
                        <div class="jet_cct-wizard-content">
                            <p><?php _e( 'Choose below which Custom Post Types and Taxonomies you want to import into jet_cct 2.0', 'jet_cct' ); ?></p>
                        </div>

                        <div class="stuffbox">
                            <h3><label for="link_name"><?php _e( 'Choose Post Types to Import', 'jet_cct' ); ?></label></h3>

                            <div class="inside jet_cct-manage-field jet_cct-dependency">
                                <?php
                                if ( !empty( $post_types ) ) {
                                    ?>
                                    <div class="jet_cct-field-option-group">
                                        <p class="jet_cct-field-option-group-label">
                                            <?php _e( 'Available Post Types', 'jet_cct' ); ?>
                                        </p>

                                        <div class="jet_cct-pick-values jet_cct-pick-checkbox">
                                            <ul>
                                                <?php
                                                foreach ( $post_types as $post_type ) {
                                                    $post_type_name = jet_cct_var_raw( 'name', $post_type );
                                                    $post_type_label = jet_cct_var_raw( 'label', $post_type, ucwords( str_replace( '_', ' ', $post_type_name ) ) );
                                                    ?>
                                                    <li>
                                                        <div class="jet_cct-field jet_cct-boolean">
                                                            <?php echo jet_cctForm::field( 'post_type[' . $post_type_name . ']', jet_cct_var_raw( 'post_type[' . $post_type_name . ']', 'post', true ), 'boolean', array( 'boolean_yes_label' => $post_type_label . ' (' . $post_type_name . ')' ) ); ?>
                                                        </div>
                                                    </li>
                                                    <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php
                                }
                                else {
                                    ?>
                                    <p class="padded"><?php _e( 'No Post Types were found.', 'jet_cct' ); ?></p>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>

                        <div class="stuffbox">
                            <h3><label for="link_name"><?php _e( 'Choose Taxonomies to Import', 'jet_cct' ); ?></label></h3>

                            <div class="inside jet_cct-manage-field jet_cct-dependency">
                                <?php
                                if ( !empty( $taxonomies ) ) {
                                    ?>
                                    <div class="jet_cct-field-option-group">
                                        <p class="jet_cct-field-option-group-label">
                                            <?php _e( 'Available Taxonomies', 'jet_cct' ); ?>
                                        </p>

                                        <div class="jet_cct-pick-values jet_cct-pick-checkbox">
                                            <ul>
                                                <?php
                                                foreach ( $taxonomies as $taxonomy ) {
                                                    $taxonomy_name = jet_cct_var_raw( 'name', $taxonomy );
                                                    $taxonomy_label = jet_cct_var_raw( 'label', $taxonomy, ucwords( str_replace( '_', ' ', $taxonomy_name ) ) );
                                                    ?>
                                                    <li>
                                                        <?php echo jet_cctForm::field( 'taxonomy[' . $taxonomy_name . ']', jet_cct_var_raw( 'taxonomy[' . $taxonomy_name . ']', 'post', true ), 'boolean', array( 'boolean_yes_label' => $taxonomy_label . ' (' . $taxonomy_name . ')' ) ); ?>
                                                    </li>
                                                    <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php
                                }
                                else {
                                    ?>
                                    <p class="padded"><?php _e( 'No Taxonomies were found.', 'jet_cct' ); ?></p>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <div id="jet_cct-wizard-actions">
                        <div id="jet_cct-wizard-toolbar">
                            <a href="#start" id="jet_cct-wizard-start" class="button button-secondary"><?php _e( 'Start Over', 'jet_cct' ); ?></a> <a href="#next" id="jet_cct-wizard-next" class="button button-primary" data-next="<?php esc_attr_e( 'Next Step', 'jet_cct' ); ?>" data-finished="<?php esc_attr_e( 'Finished', 'jet_cct' ); ?>" data-processing="<?php esc_attr_e( 'Processing', 'jet_cct' ); ?>.."><?php _e( 'Next Step', 'jet_cct' ); ?></a>
                        </div>
                        <div id="jet_cct-wizard-finished">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    var jet_cct_admin_submit_callback = function ( id ) {
        id = parseInt( id );
        document.location = 'admin.php?page=jet_cct&do=create';
    }

    var jet_cct_admin_option_select_callback = function ( $opt ) {
        jQuery( '#jet_cct_cleanup' ).val( $opt.data( 'opt' ) );
    }

    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'wizard' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'advanced' );
        $( document ).jet_cct( 'confirm' );
    } );
</script>
