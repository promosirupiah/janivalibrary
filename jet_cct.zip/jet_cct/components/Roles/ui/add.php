<div class="wrap jet_cct-admin">
    <script>
        var jet_cct_URL = '<?php echo esc_js( jet_cct_URL ); ?>';
    </script>
    <div id="icon-jet_cct" class="icon32"><br /></div>

    <form action="" method="post" class="jet_cct-submittable">
        <div class="jet_cct-submittable-fields">
            <?php echo jet_cctForm::field( 'action', 'jet_cct_admin_components', 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'component', $component, 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'method', $method, 'hidden' ); ?>
            <?php echo jet_cctForm::field( '_wpnonce', wp_create_nonce( 'jet_cct-component-' . $component . '-' . $method ), 'hidden' ); ?>

            <h2 class="italicized"><?php _e( 'Roles &amp; Capabilities: Add New Role', 'jet_cct' ); ?></h2>

            <img src="<?php echo esc_url( jet_cct_URL ); ?>ui/images/jet_cct-logo-notext-rgb-transparent.png" class="jet_cct-leaf-watermark-right" />

            <div id="jet_cct-wizard-box" class="jet_cct-wizard-steps-2">
                <div id="jet_cct-wizard-heading">
                    <ul>
                        <li class="jet_cct-wizard-menu-current" data-step="1">
                            <i></i> <span>1</span> <?php _e( 'Naming', 'jet_cct' ); ?>
                            <em></em>
                        </li>
                        <li data-step="2">
                            <i></i> <span>2</span> <?php _e( 'Capabilities', 'jet_cct' ); ?>
                            <em></em>
                        </li>
                    </ul>
                </div>
                <div id="jet_cct-wizard-main">
                    <div id="jet_cct-wizard-panel-1" class="jet_cct-wizard-panel">
                        <div class="jet_cct-wizard-content">
                            <p><?php _e( 'Roles allow you to specify which capabilities a user should be able to do within WordPress.', 'jet_cct' ); ?></p>
                        </div>

                        <div class="stuffbox">
                            <h3><label for="link_name"><?php _e( 'Name your new Role', 'jet_cct' ); ?></label></h3>

                            <div class="inside jet_cct-manage-field">
                                <div class="jet_cct-field-option">
                                    <?php
                                    echo jet_cctForm::label( 'role_label', __( 'Label', 'jet_cct' ), __( 'Users will see this as the name of their role', 'jet_cct' ) );
                                    echo jet_cctForm::field( 'role_label', jet_cct_var_raw( 'role_label', 'post' ), 'text', array( 'class' => 'jet_cct-validate jet_cct-validate-required' ) );
                                    ?>
                                </div>

                                <div class="jet_cct-field-option">
                                    <?php
                                    echo jet_cctForm::label( 'role_name', __( 'Name', 'jet_cct' ), __( 'You will use this name to programatically reference this role throughout WordPress', 'jet_cct' ) );
                                    echo jet_cctForm::field( 'role_name', jet_cct_var_raw( 'role_name', 'post' ), 'db', array( 'attributes' => array( 'data-sluggable' => 'role_label' ), 'class' => 'jet_cct-validate jet_cct-validate-required jet_cct-slugged-lower' ) );
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="jet_cct-wizard-panel-2" class="jet_cct-wizard-panel">
                        <div class="jet_cct-wizard-content">
                            <p><?php _e( 'Choose below which Capabilities you would like this new user role to have.', 'jet_cct' ); ?></p>
                        </div>

                        <div class="stuffbox">
                            <h3><label for="link_name"><?php _e( 'Assign the Capabilities for', 'jet_cct' ); ?> <strong class="jet_cct-slugged" data-sluggable="role_label"></strong></label></h3>

                            <div class="inside jet_cct-manage-field jet_cct-dependency">
                                <div class="jet_cct-field-option-group">
                                    <p><a href="#toggle" class="button" id="toggle-all"><?php _e( 'Toggle All Capabilities on / off', 'jet_cct' ); ?></a></p>

                                    <div class="jet_cct-pick-values jet_cct-pick-checkbox jet_cct-zebra">
                                        <ul>
                                            <?php
                                            $zebra = false;

                                            foreach ( $capabilities as $capability ) {
                                                $checked = false;

                                                if ( in_array( $capability, $defaults ) )
                                                    $checked = true;

                                                $class = ( $zebra ? 'even' : 'odd' );

                                                $zebra = ( !$zebra );
                                                ?>
                                                <li class="jet_cct-zebra-<?php echo esc_attr( $class ); ?>" data-capability="<?php echo esc_attr( $capability ); ?>">
                                                    <?php echo jet_cctForm::field( 'capabilities[' . $capability . ']', jet_cct_var_raw( 'capabilities[' . $capability . ']', 'post', $checked ), 'boolean', array( 'boolean_yes_label' => $capability ) ); ?>
                                                </li>
                                                <?php
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                </div>

                                <div class="jet_cct-field-option-group">
                                    <p class="jet_cct-field-option-group-label">
                                        <?php
                                        echo jet_cctForm::label( 'custom_capabilities[0]', __( 'Custom Capabilities', 'jet_cct' ), __( 'These capabilities will automatically be created and assigned to this role', 'jet_cct' ) );
                                        ?>
                                    </p>

                                    <div class="jet_cct-pick-values jet_cct-pick-checkbox">
                                        <ul id="custom-capabilities">
                                            <li class="jet_cct-repeater hidden">
                                                <?php echo jet_cctForm::field( 'custom_capabilities[--1]', '', 'text' ); ?>
                                            </li>
                                            <li>
                                                <?php echo jet_cctForm::field( 'custom_capabilities[0]', '', 'text' ); ?>
                                            </li>
                                        </ul>

                                        <p>
                                            <a href="#add-capability" id="add-capability" class="button">Add Another Custom Capability</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="jet_cct-wizard-actions">
                        <div id="jet_cct-wizard-toolbar">
                            <a href="#start" id="jet_cct-wizard-start" class="button button-secondary"><?php _e( 'Start Over', 'jet_cct' ); ?></a> <a href="#next" id="jet_cct-wizard-next" class="button button-primary" data-next="<?php esc_attr_e( 'Next Step', 'jet_cct' ); ?>" data-finished="<?php esc_attr_e( 'Finished', 'jet_cct' ); ?>" data-processing="<?php esc_attr_e( 'Processing', 'jet_cct' ); ?>.."><?php _e( 'Next Step', 'jet_cct' ); ?></a>
                        </div>
                        <div id="jet_cct-wizard-finished">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    var jet_cct_admin_submit_callback = function ( id ) {
        id = parseInt( id );
        document.location = 'admin.php?page=jet_cct-component-<?php echo esc_js( $component ); ?>&do=create';
    }

    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'wizard' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'advanced' );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'sluggable' );

        var toggle_all = true;

        $( '#toggle-all' ).on( 'click', function ( e ) {
            e.preventDefault();

            $( '.jet_cct-field.jet_cct-boolean input[type="checkbox"]' ).prop( 'checked', toggle_all );

            toggle_all = ( !toggle_all );
        } );

        $( '#add-capability' ).on( 'click', function ( e ) {
            e.preventDefault();

            var new_id = $( 'ul#custom-capabilities li' ).length;
            var html = $( 'ul#custom-capabilities li.jet_cct-repeater' ).html().replace( '--1', new_id );

            $( 'ul#custom-capabilities' ).append( '<li id="capability-' + new_id + '">' + html + '</li>' );
            $( 'li#capability-' + new_id + ' input' ).focus();
        } );
    } );
</script>
