<div class="wrap jet_cct-admin">
    <script>
        var jet_cct_URL = '<?php echo esc_js( jet_cct_URL ); ?>';
    </script>
    <div id="icon-jet_cct" class="icon32"><br /></div>

    <form action="" method="post" class="jet_cct-submittable jet_cct-form">
        <div class="jet_cct-submittable-fields">
            <?php echo jet_cctForm::field( 'action', 'jet_cct_admin_components', 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'component', $component, 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'method', $method, 'hidden' ); ?>
            <?php echo jet_cctForm::field( 'id', $id, 'hidden' ); ?>
            <?php echo jet_cctForm::field( '_wpnonce', wp_create_nonce( 'jet_cct-component-' . $component . '-' . $method ), 'hidden' ); ?>

            <h2 class="italicized"><?php _e( 'Roles &amp; Capabilities: Edit Role', 'jet_cct' ); ?></h2>

            <?php
            if ( isset( $_GET[ 'do' ] ) ) {
                $action = __( 'saved', 'jet_cct' );

                if ( 'create' == jet_cct_var( 'do', 'get', 'save' ) )
                    $action = __( 'created', 'jet_cct' );

                $message = sprintf( __( '<strong>Success!</strong> %s %s successfully.', 'jet_cct' ), $obj->item, $action );

                echo $obj->message( $message );
            }
            ?>

            <p><?php _e( 'Choose below which Capabilities you would like this existing user role to have.', 'jet_cct' ); ?></p>

            <div id="poststuff" class="metabox-holder has-right-sidebar"> <!-- class "has-right-sidebar" preps for a sidebar... always present? -->

                <div id="side-info-column" class="inner-sidebar">
                    <div id="side-sortables" class="meta-box-sortables ui-sortable">
                        <!-- BEGIN PUBLISH DIV -->
                        <div id="submitdiv" class="postbox">
                            <div class="handlediv" title="Click to toggle"><br /></div>
                            <h3 class="hndle"><span><?php _e( 'Manage', 'jet_cct' ); ?></span></h3>

                            <div class="inside">
                                <div class="submitbox" id="submitpost">
                                    <div id="minor-publishing">
                                        <div id="major-publishing-actions">
                                            <div id="publishing-action">
                                                <img class="waiting" src="<?php echo esc_url( admin_url( 'images/wpspin_light.gif' ) ); ?>" alt="" />
                                                <input type="submit" name="publish" id="publish" class="button-primary" value="<?php _e( 'Save', 'jet_cct' ); ?>" accesskey="p" />
                                            </div>
                                            <!-- /#publishing-action -->

                                            <div class="clear"></div>
                                        </div>
                                        <!-- /#major-publishing-actions -->
                                    </div>
                                    <!-- /#minor-publishing -->
                                </div>
                                <!-- /#submitpost -->
                            </div>
                            <!-- /.inside -->
                        </div>
                        <!-- /#submitdiv --><!-- END PUBLISH DIV --><!-- TODO: minor column fields -->
                    </div>
                    <!-- /#side-sortables -->
                </div>
                <!-- /#side-info-column -->

                <div id="post-body">
                    <div id="post-body-content">
                        <div id="normal-sortables" class="meta-box-sortables ui-sortable">
                            <div id="jet_cct-meta-box" class="postbox" style="">
                                <div class="handlediv" title="Click to toggle"><br /></div>
                                <h3 class="hndle">
                                    <span>
                                        <?php _e( 'Assign the Capabilities for', 'jet_cct' ); ?>
                                        <strong><?php echo $role_label; ?></strong>
                                    </span>
                                </h3>

                                <div class="inside jet_cct-manage-field jet_cct-dependency">
                                    <div class="jet_cct-field-option-group">
                                        <p>
                                            <a href="#toggle" class="button" id="toggle-all"><?php _e( 'Toggle All Capabilities on / off', 'jet_cct' ); ?></a>
                                        </p>

                                        <div class="jet_cct-pick-values jet_cct-pick-checkbox jet_cct-zebra">
                                            <ul>
                                                <?php
                                                $zebra = false;

                                                foreach ( $capabilities as $capability ) {
                                                    $checked = false;

                                                    if ( true === (boolean) jet_cct_var( $capability, $role_capabilities, false ) )
                                                        $checked = true;

                                                    $class = ( $zebra ? 'even' : 'odd' );

                                                    $zebra = ( !$zebra );
                                                    ?>
                                                    <li class="jet_cct-zebra-<?php echo esc_attr( $class ); ?>" data-capability="<?php echo esc_attr( $capability ); ?>">
                                                        <?php echo jet_cctForm::field( 'capabilities[' . $capability . ']', jet_cct_var_raw( 'capabilities[' . $capability . ']', 'post', $checked ), 'boolean', array( 'boolean_yes_label' => $capability ) ); ?>
                                                    </li>
                                                    <?php
                                                }
                                                ?>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="jet_cct-field-option-group">
                                        <p class="jet_cct-field-option-group-label">
                                            <?php
                                            echo jet_cctForm::label( 'custom_capabilities[0]', __( 'Custom Capabilities', 'jet_cct' ), __( 'These capabilities will automatically be created and assigned to this role', 'jet_cct' ) );
                                            ?>
                                        </p>

                                        <div class="jet_cct-pick-values jet_cct-pick-checkbox">
                                            <ul id="custom-capabilities">
                                                <li class="jet_cct-repeater hidden">
                                                    <?php echo jet_cctForm::field( 'custom_capabilities[--1]', '', 'text' ); ?>
                                                </li>
                                                <li>
                                                    <?php echo jet_cctForm::field( 'custom_capabilities[0]', '', 'text' ); ?>
                                                </li>
                                            </ul>

                                            <p><a href="#add-capability" id="add-capability" class="button">Add Another Custom Capability</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.inside -->
                            </div>
                            <!-- /#jet_cct-meta-box -->
                        </div>
                        <!-- /#normal-sortables -->

                        <!--<div id="advanced-sortables" class="meta-box-sortables ui-sortable">
                      </div>
                       /#advanced-sortables -->

                    </div>
                    <!-- /#post-body-content -->

                    <br class="clear" />
                </div>
                <!-- /#post-body -->

                <br class="clear" />
            </div>
            <!-- /#poststuff -->
        </div>
    </form>
    <!-- /#jet_cct-record -->
</div>

<script type="text/javascript">
    var jet_cct_admin_submit_callback = function ( id ) {
        id = parseInt( id );
        document.location = 'admin.php?page=jet_cct-component-<?php echo esc_js( $component ); ?>&action=edit&id=<?php echo esc_js( $id ); ?>&do=save';
    }

    jQuery( function ( $ ) {
        $( document ).jet_cct( 'validate' );
        $( document ).jet_cct( 'submit' );
        $( document ).jet_cct( 'wizard' );
        $( document ).jet_cct( 'dependency' );
        $( document ).jet_cct( 'advanced' );
        $( document ).jet_cct( 'confirm' );
        $( document ).jet_cct( 'sluggable' );

        var toggle_all = true;

        $( '#toggle-all' ).on( 'click', function ( e ) {
            e.preventDefault();

            $( '.jet_cct-field.jet_cct-boolean input[type="checkbox"]' ).prop( 'checked', toggle_all );

            toggle_all = ( !toggle_all );
        } );

        $( '#add-capability' ).on( 'click', function ( e ) {
            e.preventDefault();

            var new_id = $( 'ul#custom-capabilities li' ).length;
            var html = $( 'ul#custom-capabilities li.jet_cct-repeater' ).html().replace( /\-\-1/g, new_id );

            $( 'ul#custom-capabilities' ).append( '<li id="capability-' + new_id + '">' + html + '</li>' );
            $( 'li#capability-' + new_id + ' input' ).focus();
        } );
    } );
</script>
