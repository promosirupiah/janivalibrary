<?php
/**
 * Name: Advanced Content Types
 *
 * Description: A content type that exists outside of the WordPress post and postmeta table and uses custom tables instead. You most likely don't need these and we strongly recommend that you use Custom Post Types or Custom Taxonomies instead. FOR ADVANCED USERS ONLY.
 *
 * Version: 2.3
 *
 * Category: Advanced
 *
 * Tableless Mode: No
 *
 * @package jet_cct\Components
 * @subpackage Advanced Content Types
 */

if ( class_exists( 'jet_cct_Advanced_Content_Types' ) )
    return;

class jet_cct_Advanced_Content_Types extends jet_cctComponent {

    /**
     * Do things like register/enqueue scripts and stylesheets
     *
     * @since 2.3
     */
    public function __construct () {
        if ( !jet_cct_tableless() )
            add_filter( 'jet_cct_admin_setup_add_create_jet_type', array( $this, 'add_jet_type' ) );
    }

    /**
     * Enable Advanced Content Type option in setup-add.php
     *
     * @param array $data jet Type options
     *
     * @return array
     */
    public function add_jet_type ( $data ) {
        $data[ 'jet' ] = __( 'Advanced Content Type (separate from WP, blank slate, in its own table)', 'jet_cct' );

        return $data;
    }

}