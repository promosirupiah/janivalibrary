<?php
/**
 * @package jet_cct\Widgets
 */
class jet_cctWidgetList extends WP_Widget {

	/**
	 * Register the widget
	 *
	 * @since 2.5.4
	 *
	 * Note: params are totally ignored. Included for the sake of strict standards.
	 *
	 *
	 * @param string $id_base         Optional Base ID for the widget, lowercase and unique. If left empty,
	 *                                a portion of the widget's class name will be used Has to be unique.
	 * @param string $name            Name for the widget displayed on the configuration page.
	 * @param array  $widget_options  Optional. Widget options. See {@see wp_register_sidebar_widget()} for
	 *                                information on accepted arguments. Default empty array.
	 * @param array  $control_options Optional. Widget control options. See {@see wp_register_widget_control()}
	 *                                for information on accepted arguments. Default empty array.
	 */
	public function __construct( $id_base = 'jet_cct_widget_list', $name = 'jet_cct - List Items', $widget_options = array(), $control_options = array() ) {
	    parent::__construct(
            'jet_cct_widget_list',
            'jet_cct - List Items',
            array( 'classname' => 'jet_cct_widget_list', 'description' => 'Display multiple jet items' ),
            array( 'width' => 200 )
        );

    }

    /**
     * Output of widget
     */
    public function widget ( $args, $instance ) {
        extract( $args );

        // Get widget fields
        $title = apply_filters( 'widget_title', jet_cct_v( 'title', $instance ) );

        $args = array(
            'name' => trim( jet_cct_var_raw( 'jet_type', $instance, '' ) ),
            'template' => trim( jet_cct_var_raw( 'template', $instance, '' ) ),
            'limit' => (int) jet_cct_var_raw( 'limit', $instance, 15, null, true ),
            'orderby' => trim( jet_cct_var_raw( 'orderby', $instance, '' ) ),
            'where' => trim( jet_cct_var_raw( 'where', $instance, '' ) ),
            'expires' => (int) trim( jet_cct_var_raw( 'expires', $instance, ( 60 * 5 ) ) ),
            'cache_mode' => trim( jet_cct_var_raw( 'cache_mode', $instance, 'none', null, true ) )
        );

        $before_content = trim( jet_cct_var_raw( 'before_content', $instance, '' ) );
        $content = trim( jet_cct_var_raw( 'template_custom', $instance, '' ) );
        $after_content = trim( jet_cct_var_raw( 'after_content', $instance, '' ) );

        if ( 0 < strlen( $args[ 'name' ] ) && ( 0 < strlen( $args[ 'template' ] ) || 0 < strlen( $content ) ) ) {
            require jet_cct_DIR . 'ui/front/widgets.php';
        }
    }

    /**
     * Updates the new instance of widget arguments
     *
     * @returns array $instance Updated instance
     */
    public function update ( $new_instance, $old_instance ) {
        $instance = $old_instance;

        $instance[ 'title' ] = jet_cct_var_raw( 'title', $new_instance, '' );
        $instance[ 'jet_type' ] = jet_cct_var_raw( 'jet_type', $new_instance, '' );
        $instance[ 'template' ] = jet_cct_var_raw( 'template', $new_instance, '' );
        $instance[ 'template_custom' ] = jet_cct_var_raw( 'template_custom', $new_instance, '' );
        $instance[ 'limit' ] = (int) jet_cct_var_raw( 'limit', $new_instance, 15, null, true );
        $instance[ 'orderby' ] = jet_cct_var_raw( 'orderby', $new_instance, '' );
        $instance[ 'where' ] = jet_cct_var_raw( 'where', $new_instance, '' );
        $instance[ 'expires' ] = (int) jet_cct_var_raw( 'expires', $new_instance, ( 60 * 5 ) );
        $instance[ 'cache_mode' ] = jet_cct_var_raw( 'cache_mode', $new_instance, 'none' );
        $instance[ 'before_content' ] = jet_cct_var_raw( 'before_content', $new_instance, '' );
        $instance[ 'after_content' ] = jet_cct_var_raw( 'after_content', $new_instance, '' );

        return $instance;
    }

    /**
     * Widget Form
     */
    public function form ( $instance ) {
        $title = jet_cct_var_raw( 'title', $instance, '' );
        $jet_type = jet_cct_var_raw( 'jet_type', $instance, '' );
        $template = jet_cct_var_raw( 'template', $instance, '' );
        $template_custom = jet_cct_var_raw( 'template_custom', $instance, '' );
        $limit = (int) jet_cct_var_raw( 'limit', $instance, 15, null, true );
        $orderby = jet_cct_var_raw( 'orderby', $instance, '' );
        $where = jet_cct_var_raw( 'where', $instance, '' );
        $expires = (int) jet_cct_var_raw( 'expires', $instance, ( 60 * 5 ) );
        $cache_mode = jet_cct_var_raw( 'cache_mode', $instance, 'none' );
        $before_content = jet_cct_var_raw( 'before_content', $instance, '' );
        $after_content = jet_cct_var_raw( 'after_content', $instance, '' );

        require jet_cct_DIR . 'ui/admin/widgets/list.php';
    }
}
