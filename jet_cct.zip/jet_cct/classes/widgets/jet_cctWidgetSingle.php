<?php
/**
 * @package jet_cct\Widgets
 */
class jet_cctWidgetSingle extends WP_Widget {

	/**
	 * Register the widget
	 *
	 * @since 2.5.4
	 *
	 * Note: params are totally ignored. Included for the sake of strict standards.
	 *
	 *
	 * @param string $id_base         Optional Base ID for the widget, lowercase and unique. If left empty,
	 *                                a portion of the widget's class name will be used Has to be unique.
	 * @param string $name            Name for the widget displayed on the configuration page.
	 * @param array  $widget_options  Optional. Widget options. See {@see wp_register_sidebar_widget()} for
	 *                                information on accepted arguments. Default empty array.
	 * @param array  $control_options Optional. Widget control options. See {@see wp_register_widget_control()}
	 *                                for information on accepted arguments. Default empty array.
	 */
	public function __construct( $id_base = 'jet_cct_widget_single', $name = 'jet_cct - Single Item', $widget_options = array(), $control_options = array() ) {
	    parent::__construct(
            'jet_cct_widget_single',
            'jet_cct - Single Item',
            array( 'classname' => 'jet_cct_widget_single', 'description' => 'Display a Single jet Item' ),
            array( 'width' => 200 )
        );
    }

    /**
     * Output of widget
     */
    public function widget ( $args, $instance ) {
        extract( $args );

        // Get widget field values
        $title = apply_filters( 'widget_title', jet_cct_v( 'title', $instance ) );

        $args = array(
            'name' => trim( jet_cct_var_raw( 'jet_type', $instance, '' ) ),
            'slug' => trim( jet_cct_var_raw( 'slug', $instance, '' ) ),
            'use_current' => trim( jet_cct_var_raw( 'use_current', $instance, '' ) ),
            'template' => trim( jet_cct_var_raw( 'template', $instance, '' ) )
        );

        $content = trim( jet_cct_var_raw( 'template_custom', $instance, '' ) );

        if ( ( ( 0 < strlen( $args[ 'name' ] ) && 0 < strlen( $args[ 'slug' ] ) ) || 0 < strlen( $args[ 'use_current' ] ) ) && ( 0 < strlen( $args[ 'template' ] ) || 0 < strlen( $content ) ) ) {
            require jet_cct_DIR . 'ui/front/widgets.php';
        }
    }

    /**
     * Updates the new instance of widget arguments
     *
     * @returns array $instance Updated instance
     */
    public function update ( $new_instance, $old_instance ) {
        $instance = $old_instance;

        $instance[ 'title' ] = jet_cct_var_raw( 'title', $new_instance, '' );
        $instance[ 'jet_type' ] = jet_cct_var_raw( 'jet_type', $new_instance, '' );
        $instance[ 'slug' ] = jet_cct_var_raw( 'slug', $new_instance, '' );
        $instance[ 'use_current' ] = jet_cct_var_raw( 'use_current', $new_instance, '' );
        $instance[ 'template' ] = jet_cct_var_raw( 'template', $new_instance, '' );
        $instance[ 'template_custom' ] = jet_cct_var_raw( 'template_custom', $new_instance, '' );

        return $instance;
    }

    /**
     * Widget Form
     */
    public function form ( $instance ) {
        $title = jet_cct_var_raw( 'title', $instance, '' );
        $slug = jet_cct_var_raw( 'slug', $instance, '' );
        $use_current = jet_cct_var_raw( 'use_current', $instance, '' );
        $jet_type = jet_cct_var_raw( 'jet_type', $instance, '' );
        $template = jet_cct_var_raw( 'template', $instance, '' );
        $template_custom = jet_cct_var_raw( 'template_custom', $instance, '' );

        require jet_cct_DIR . 'ui/admin/widgets/single.php';
    }
}
