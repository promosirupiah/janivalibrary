<?php
/**
 * @package jet_cct\Widgets
 */
class jet_cctWidgetView extends WP_Widget {

	/**
	 * Register the widget
	 *
	 * @since 2.5.4
	 *
	 * Note: params are totally ignored. Included for the sake of strict standards.
	 *
	 *
	 * @param string $id_base         Optional Base ID for the widget, lowercase and unique. If left empty,
	 *                                a portion of the widget's class name will be used Has to be unique.
	 * @param string $name            Name for the widget displayed on the configuration page.
	 * @param array  $widget_options  Optional. Widget options. See {@see wp_register_sidebar_widget()} for
	 *                                information on accepted arguments. Default empty array.
	 * @param array  $control_options Optional. Widget control options. See {@see wp_register_widget_control()}
	 *                                for information on accepted arguments. Default empty array.
	 */
	public function __construct( $id_base = 'jet_cct_widget_view', $name = 'jet_cct - View', $widget_options = array(), $control_options = array() ) {
	    parent::__construct(
            'jet_cct_widget_view',
            'jet_cct - View',
            array( 'classname' => 'jet_cct_widget_view', 'description' => "Include a file from a theme, with caching options" ),
            array( 'width' => 200 )
        );

    }

    /**
     * Output of widget
     */
    public function widget ( $args, $instance ) {
        extract( $args );

        // Get widget fields
        $title = apply_filters( 'widget_title', jet_cct_v( 'title', $instance ) );

        $args = array(
            'view' => trim( jet_cct_var_raw( 'view', $instance, '' ) ),
            'expires' => (int) jet_cct_var_raw( 'expires', $instance, ( 60 * 5 ) ),
            'cache_mode' => trim( jet_cct_var_raw( 'cache_mode', $instance, 'none', null, true ) )
        );

        if ( 0 < strlen( $args[ 'view' ] ) )
            require jet_cct_DIR . 'ui/front/widgets.php';
    }

    /**
     * Updates the new instance of widget arguments
     *
     * @returns array $instance Updated instance
     */
    public function update ( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance[ 'title' ] = jet_cct_var_raw( 'title', $new_instance, '' );
        $instance[ 'view' ] = jet_cct_var_raw( 'view', $new_instance, '' );
        $instance[ 'expires' ] = (int) jet_cct_var_raw( 'expires', $new_instance, ( 60 * 5 ) );
        $instance[ 'cache_mode' ] = jet_cct_var_raw( 'cache_mode', $new_instance, 'none', null, true );

        return $instance;
    }

    /**
     * Widget Form
     */
    public function form ( $instance ) {
        $title = jet_cct_var_raw( 'title', $instance, '' );
        $view = jet_cct_var_raw( 'view', $instance, '' );
        $expires = (int) jet_cct_var_raw( 'expires', $instance, ( 60 * 5 ) );
        $cache_mode = jet_cct_var_raw( 'cache_mode', $instance, 'none', null, true );

        require jet_cct_DIR . 'ui/admin/widgets/view.php';
    }
}
