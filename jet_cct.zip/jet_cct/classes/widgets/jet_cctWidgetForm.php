<?php
/**
 * @package jet_cct\Widgets
 */
class jet_cctWidgetForm extends WP_Widget {

	/**
	 * Register the widget
	 *
	 * @since 2.5.4
	 *
	 * Note: params are totally ignored. Included for the sake of strict standards.
	 *
	 *
	 * @param string $id_base         Optional Base ID for the widget, lowercase and unique. If left empty,
	 *                                a portion of the widget's class name will be used Has to be unique.
	 * @param string $name            Name for the widget displayed on the configuration page.
	 * @param array  $widget_options  Optional. Widget options. See {@see wp_register_sidebar_widget()} for
	 *                                information on accepted arguments. Default empty array.
	 * @param array  $control_options Optional. Widget control options. See {@see wp_register_widget_control()}
	 *                                for information on accepted arguments. Default empty array.
	 */
	public function __construct( $id_base = 'jet_cct_widget_form', $name = 'jet_cct - Form', $widget_options = array(), $control_options = array() ) {
	    parent::__construct(
            'jet_cct_widget_form',
            'jet_cct - Form',
            array( 'classname' => 'jet_cct_widget_form', 'description' => 'Display a form for creating and editing jet items' ),
            array( 'width' => 200 )
        );

    }

    public function widget ( $args, $instance ) {
        extract( $args );

        // Get widget fields
        $title = apply_filters( 'widget_title', jet_cct_v( 'title', $instance ) );

        $args = array(
            'name' => trim( jet_cct_var_raw( 'jet_type', $instance, '' ) ),
            'slug' => trim( jet_cct_var_raw( 'slug', $instance, '' ) ),
            'fields' => trim( jet_cct_var_raw( 'fields', $instance, '' ) ),
            'label' => trim( jet_cct_var_raw( 'label', $instance, __( 'Submit', 'jet_cct' ), null, true ) ),
            'thank_you' => trim( jet_cct_var_raw( 'thank_you', $instance, '' ) ),
            'form' => 1
        );

        if ( 0 < strlen( $args[ 'name' ] ) ) {
            require jet_cct_DIR . 'ui/front/widgets.php';
        }
    }

    public function update ( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance[ 'title' ] = jet_cct_var_raw( 'title', $new_instance, '' );
        $instance[ 'jet_type' ] = jet_cct_var_raw( 'jet_type', $new_instance, '' );
        $instance[ 'slug' ] = jet_cct_var_raw( 'slug', $new_instance, '' );
        $instance[ 'fields' ] = jet_cct_var_raw( 'fields', $new_instance, '' );
        $instance[ 'label' ] = jet_cct_var_raw( 'label', $new_instance, __( 'Submit', 'jet_cct' ), null, true );
        $instance[ 'thank_you' ] = jet_cct_var_raw( 'thank_you', $new_instance, '' );

        return $instance;
    }

    public function form ( $instance ) {
        $title = jet_cct_var_raw( 'title', $instance, '' );
        $jet_type = jet_cct_var_raw( 'jet_type', $instance, '' );
        $slug = jet_cct_var_raw( 'slug', $instance, '' );
        $fields = jet_cct_var_raw( 'fields', $instance, '' );
        $label = jet_cct_var_raw( 'label', $instance, __( 'Submit', 'jet_cct' ), null, true );
        $thank_you = jet_cct_var_raw( 'thank_you', $instance, '' );

        require jet_cct_DIR . 'ui/admin/widgets/form.php';
    }
}
