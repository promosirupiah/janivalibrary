<?php
/**
 * @package jet_cct\Widgets
 */
class jet_cctWidgetField extends WP_Widget {

	/**
	 * Register the widget
	 *
	 * @since 2.5.4
	 *
	 * Note: params are totally ignored. Included for the sake of strict standards.
	 *
	 *
	 * @param string $id_base         Optional Base ID for the widget, lowercase and unique. If left empty,
	 *                                a portion of the widget's class name will be used Has to be unique.
	 * @param string $name            Name for the widget displayed on the configuration page.
	 * @param array  $widget_options  Optional. Widget options. See {@see wp_register_sidebar_widget()} for
	 *                                information on accepted arguments. Default empty array.
	 * @param array  $control_options Optional. Widget control options. See {@see wp_register_widget_control()}
	 *                                for information on accepted arguments. Default empty array.
	 */
	public function __construct( $id_base = 'jet_cct_widget_field', $name = 'jet_cct - Field Value', $widget_options = array(), $control_options = array() ) {
	    parent::__construct(
            'jet_cct_widget_field',
            'jet_cct - Field Value',
            array( 'classname' => 'jet_cct_widget_field', 'description' => "Display a single jet item's field value" ),
            array( 'width' => 200 )
        );
		
    }

    /**
     * Output of widget
     */
    public function widget ( $args, $instance ) {
        extract( $args );

        // Get widget fields
        $title = apply_filters( 'widget_title', jet_cct_v( 'title', $instance ) );

        $args = array(
            'name' => trim( jet_cct_var_raw( 'jet_type', $instance, '' ) ),
            'slug' => trim( jet_cct_var_raw( 'slug', $instance, '' ) ),
            'field' => trim( jet_cct_var_raw( 'field', $instance, '' ) )
        );

        if ( 0 < strlen( $args[ 'name' ] ) && 0 < strlen( $args[ 'slug' ] ) && 0 < strlen( $args[ 'field' ] ) ) {
            require jet_cct_DIR . 'ui/front/widgets.php';
        }
    }

    /**
     * Updates the new instance of widget arguments
     *
     * @returns array $instance Updated instance
     */
    public function update ( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance[ 'title' ] = jet_cct_var_raw( 'title', $new_instance, '' );
        $instance[ 'jet_type' ] = jet_cct_var_raw( 'jet_type', $new_instance, '' );
        $instance[ 'slug' ] = jet_cct_var_raw( 'slug', $new_instance, '' );
        $instance[ 'field' ] = jet_cct_var_raw( 'field', $new_instance, '' );

        return $instance;
    }

    /**
     * Widget Form
     */
    public function form ( $instance ) {
        $title = jet_cct_var_raw( 'title', $instance, '' );
        $jet_type = jet_cct_var_raw( 'jet_type', $instance, '' );
        $slug = jet_cct_var_raw( 'slug', $instance, '' );
        $field = jet_cct_var_raw( 'field', $instance, '' );

        require jet_cct_DIR . 'ui/admin/widgets/field.php';
    }
}
