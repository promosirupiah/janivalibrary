<?php
/**
 * Class jet_cctRESTHandlers
 *
 * Handlers for reading and writing jet_cct fields via REST API
 *
 * @package jet_cct
 * @since   2.5.6
 */
class jet_cctRESTHandlers {

	/**
	 * Holds a jet_cct object to avoid extra DB queries
	 *
	 * @since 2.5.6
	 *
	 * @var jet_cct
	 */
	private static $jet;

	/**
	 * Get jet object
	 *
	 * @since 2.5.6
	 *
	 * @param $jet_name
	 * @param $id
	 *
	 * @return bool|jet_cct
	 */
	protected static function get_jet( $jet_name, $id ) {

		if ( ! self::$jet || self::$jet->jet != $jet_name ) {
			self::$jet = jet_cct( $jet_name, $id, true );
		}

		if ( self::$jet && self::$jet->id != $id ) {
			self::$jet->fetch( $id );
		}

		return self::$jet;

	}

	/**
	 * Handler for getting custom field data.
	 *
	 * @since 2.5.6
	 *
	 * @param array           $object      The object from the response
	 * @param string          $field_name  Name of field
	 * @param WP_REST_Request $request     Current request
	 * @param string          $object_type Type of object
	 *
	 * @return mixed
	 */
	public static function get_handler( $object, $field_name, $request, $object_type ) {

		$jet_name = jet_cct_v( 'type', $object );

		/**
		 * If $jet_name in the line above is empty then the route invoked
		 * may be for a taxonomy, so lets try and check for that
		 *
		 */
		if ( empty( $jet_name ) ) {
			$jet_name = jet_cct_v( 'taxonomy', $object );
		}

		/**
		 * $jet_name is still empty, so check lets check $object_type
		 *
		 */

		if ( empty( $jet_name ) ) {
			if ( 'attachment' == $object_type ) {
				$jet_name = 'media';
			} else {
				$jet_name = $object_type;
			}
		}

		/**
		 * Filter the jet name
		 *
		 * @since 2.6.7
		 *
		 * @param array           $jet_name    jet name
		 * @param jet_cct            $object      Rest object
		 * @param string          $field_name  Name of the field
		 * @param WP_REST_Request $request     Current request
		 * @param string          $object_type Rest Object type
		 */
		$jet_name = apply_filters( 'jet_cct_rest_api_jet_name', $jet_name, $object, $field_name, $request, $object_type  );

		$id  = jet_cct_v( 'id', $object );

		if ( empty( $id ) ) {
			$id = jet_cct_v( 'ID', $object );
		}

		$jet = self::get_jet( $jet_name, $id );

		$value = false;

		if ( $jet && jet_cctRESTFields::field_allowed_to_extend( $field_name, $jet, 'read' ) ) {
			$params = null;

			$field_data = $jet->fields( $field_name );

			if ( 'pick' == jet_cct_v( 'type', $field_data ) ) {
				$output_type = jet_cct_v( 'rest_pick_response', $field_data['options'], 'array' );

				if ( 'array' == $output_type ) {
					$related_jet_items = $jet->field( $field_name, array( 'output' => 'jet' ) );

					if ( $related_jet_items ) {
						$fields = false;
						$items  = array();
						$depth  = jet_cct_v( 'rest_pick_depth', $field_data['options'], 2 );

						if ( ! is_array( $related_jet_items ) ) {
							$related_jet_items = array( $related_jet_items );
						}

						/**
						 * @var $related_jet jet_cct
						 */
						foreach ( $related_jet_items as $related_jet ) {
							if ( ! is_object( $related_jet ) || ! is_a( $related_jet, 'jet_cct' ) ) {
								$items = $related_jet_items;

								break;
							}

							if ( false === $fields ) {
								$fields = $related_jet->fields();
								$fields = array_keys( $fields );

								if ( isset( $related_jet->jet_data['object_fields'] ) && ! empty( $related_jet->jet_data['object_fields'] ) ) {
									$fields = array_merge( $fields, array_keys( $related_jet->jet_data['object_fields'] ) );
								}

								/**
								 * What fields to show in a related field REST response.
								 *
								 * @since 0.0.1
								 *
								 * @param array                  $fields     The fields to show
								 * @param string                 $field_name The name of the field
								 * @param object|jet_cct            $jet        The jet_cct object for jet relationship is from.
								 * @param object|jet_cct            $jet        The jet_cct object for jet relationship is to.
								 * @param int                    $id         Current item ID
								 * @param object|WP_REST_Request Current     request object.
								 */
								$fields = apply_filters( 'jet_cct_rest_api_fields_for_relationship_response', $fields, $field_name, $jet, $related_jet, $id, $request );
							}

							/**
							 * What depth to use for a related field REST response.
							 *
							 * @since 0.0.1
							 *
							 * @param array                  $depth      The depth.
							 * @param string                 $field_name The name of the field
							 * @param object|jet_cct            $jet        The jet_cct object for jet relationship is from.
							 * @param object|jet_cct            $jet        The jet_cct object for jet relationship is to.
							 * @param int                    $id         Current item ID
							 * @param object|WP_REST_Request Current     request object.
							 */
							$depth = apply_filters( 'jet_cct_rest_api_depth_for_relationship_response', $depth, $field_name, $jet, $related_jet, $id, $request );

							$params = array(
								'fields' => $fields,
								'depth'  => $depth,
							);

							$items[] = $related_jet->export( $params );
						}

						$value = $items;
					}
				}

				$params = array(
					'output' => $output_type,
				);
			}

			// If no value set yet, get normal field value
			if ( ! $value && ! is_array( $value ) ) {
				$value = $jet->field( $field_name, $params );
			}
		}

		return $value;

	}

	/**
	 * Handler for updating custom field data.
	 *
	 * @since 2.5.6
	 *
	 * @param mixed           $value      Value to write
	 * @param object          $object     The object from the response
	 * @param string          $field_name Name of field
	 * @param WP_REST_Request $request     Current request
	 * @param string          $object_type Type of object
	 *
	 * @return bool|int
	 */
	public static function write_handler( $value, $object, $field_name, $request, $object_type ) {

		$jet_name = jet_cct_v( 'type', $object );

		/**
		 * If $jet_name in the line above is empty then the route invoked
		 * may be for a taxonomy, so lets try and check for that
		 *
		 */
		if ( empty( $jet_name ) ) {
			$jet_name = jet_cct_v( 'taxonomy', $object );
		}

		/**
		 * $jet_name is still empty, so check lets check $object_type
		 *
		 */

		if ( empty( $jet_name ) ) {
			if ( 'attachment' == $object_type ) {
				$jet_name = 'media';
			} else {
				$jet_name = $object_type;
			}
		}

		/**
		 * Filter the jet name
		 *
		 * @since 2.6.7
		 *
		 * @param array           $jet_name    jet name
		 * @param jet_cct            $object      Rest object
		 * @param string          $field_name  Name of the field
		 * @param WP_REST_Request $request     Current request
		 * @param string          $object_type Rest Object type
		 */
		$jet_name = apply_filters( 'jet_cct_rest_api_jet_name', $jet_name, $object, $field_name, $request, $object_type );

		$id = jet_cct_v( 'id', $object );

		if ( empty( $id ) ) {
			$id = jet_cct_v( 'ID', $object );
		}
		$jet = self::get_jet( $jet_name, $id );

		if ( $jet && jet_cctRESTFields::field_allowed_to_extend( $field_name, $jet, 'write' ) ) {
			$jet->save( $field_name, $value, $id );

			return $jet->field( $field_name );
		}

		return false;

	}

	/**
	 * Add REST API support to a post type
	 *
	 * @since 2.5.6
	 *
	 * @param string     $post_type_name Name of post type
	 * @param bool|false $rest_base      Optional. Base url segment. If not set, post type name is used
	 * @param string     $controller     Optional, controller class for route. If not set "WP_REST_Posts_Controller" is
	 *                                   used.
	 */
	public static function post_type_rest_support( $post_type_name, $rest_base = false, $controller = 'WP_REST_Posts_Controller' ) {

		global $wp_post_types;

		// Only add support for post types that exist
		if ( isset( $wp_post_types[ $post_type_name ] ) ) {
			// Only add support if REST base not already set
			if ( empty( $wp_post_types[ $post_type_name ]->rest_base ) ) {
				if ( ! $rest_base ) {
					$rest_base = $post_type_name;
				}

				$wp_post_types[ $post_type_name ]->show_in_rest          = true;
				$wp_post_types[ $post_type_name ]->rest_base             = $rest_base;
				$wp_post_types[ $post_type_name ]->rest_controller_class = $controller;
			}
		}

	}

	/**
	 * Add REST API support to an already registered taxonomy.
	 *
	 * @since 2.5.6
	 *
	 * @param string     $taxonomy_name Taxonomy name.
	 * @param bool|false $rest_base     Optional. Base url segment. If not set, taxonomy name is used.
	 * @param string     $controller    Optional, controller class for route. If not set "WP_REST_Terms_Controller" is
	 *                                  used.
	 */
	public static function taxonomy_rest_support( $taxonomy_name, $rest_base = false, $controller = 'WP_REST_Terms_Controller' ) {

		/** As of WordPress 4.7: https://make.wordpress.org/core/2016/10/29/wp_taxonomy-in-4-7/ */
		/** @var WP_Taxonomy[] $wp_taxonomies */
		global $wp_taxonomies;

		// Only add support for taxonomies that exist
		if ( isset( $wp_taxonomies[ $taxonomy_name ] ) ) {
			// Only add support if REST base not already set
			if ( empty( $wp_taxonomies[ $taxonomy_name ]->rest_base ) ) {
				if ( ! $rest_base ) {
					$rest_base = $taxonomy_name;
				}

				$wp_taxonomies[ $taxonomy_name ]->show_in_rest          = true;
				$wp_taxonomies[ $taxonomy_name ]->rest_base             = $rest_base;
				$wp_taxonomies[ $taxonomy_name ]->rest_controller_class = $controller;
			}

		}
	}

	/**
	 * Check if a jet supports extending core REST response.
	 *
	 * @since 2.5.6
	 *
	 * @param array|jet_cct $jet jet object or the jet_data array
	 *
	 * @return bool
	 */
	public static function jet_extends_core_route( $jet ) {

		$enabled = false;

		if ( is_object( $jet ) ) {
			$jet = $jet->jet_data;
		}

		if ( is_array( $jet ) ) {
			$enabled = (boolean) jet_cct_v( 'rest_enable', $jet['options'], false );
		}

		return $enabled;

	}

}
