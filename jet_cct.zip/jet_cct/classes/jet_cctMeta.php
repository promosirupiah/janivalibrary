<?php
/**
 * @package jet_cct
 */
class jet_cctMeta {

    /**
     * @var jet_cctMeta
     */
    static $instance = null;

    /**
     * @var jet_cctAPI
     */
    private $api;

    /**
     * @var jet_cct
     */
    private static $current_jet;

    /**
     * @var array
     */
    private static $current_jet_data;

    /**
     * @var jet_cct
     */
    private static $current_field_jet;

    /**
     * @var int
     */
    public static $object_identifier = -1;

    /**
     * @var array
     */
    public static $advanced_content_types = array();

    /**
     * @var array
     */
    public static $post_types = array();

    /**
     * @var array
     */
    public static $taxonomies = array();

    /**
     * @var array
     */
    public static $media = array();

    /**
     * @var array
     */
    public static $user = array();

    /**
     * @var array
     */
    public static $comment = array();

    /**
     * @var array
     */
    public static $settings = array();

    /**
     * @var array
     */
    public static $queue = array();

    /**
     * @var array
     */
    public static $groups = array();

    /**
     * @var array
     */
    public static $old_post_status = array();

    /**
     * Singleton handling for a basic jet_cct_meta() request
     *
     * @return \jet_cctMeta
     *
     * @since 2.3.5
     */
    public static function init () {
        if ( !is_object( self::$instance ) )
            self::$instance = new jet_cctMeta();

        return self::$instance;
    }

    /**
     * @return \jet_cctMeta
     *
     * @since 2.0
     */
    function __construct () {

    }

    /**
     * @return \jet_cctMeta
     */
    public function core () {
        self::$advanced_content_types = jet_cct_api()->load_jet_cct( array( 'type' => 'jet' ) );
        self::$post_types = jet_cct_api()->load_jet_cct( array( 'type' => 'post_type' ) );
        self::$taxonomies = jet_cct_api()->load_jet_cct( array( 'type' => 'taxonomy' ) );
        self::$media = jet_cct_api()->load_jet_cct( array( 'type' => 'media' ) );
        self::$user = jet_cct_api()->load_jet_cct( array( 'type' => 'user' ) );
        self::$comment = jet_cct_api()->load_jet_cct( array( 'type' => 'comment' ) );
        self::$settings = jet_cct_api()->load_jet_cct( array( 'type' => 'settings' ) );

        // Handle Post Type Editor (needed for jet_cct core)

        // Loop through and add meta boxes for individual types (can't use this, Tabify doesn't pick it up)
        /*
        foreach ( self::$post_types as $post_type ) {
            $post_type_name = $post_type[ 'name' ];

            if ( !empty( $post_type[ 'object' ] ) )
                $post_type_name = $post_type[ 'object' ];

            add_action( 'add_meta_boxes_' . $post_type_name, array( $this, 'meta_post_add' ) );
        }
        */

        add_action( 'add_meta_boxes', array( $this, 'meta_post_add' ) );
        add_action( 'transition_post_status', array( $this, 'save_post_detect_new' ), 10, 3 );
        add_action( 'save_post', array( $this, 'save_post' ), 10, 3 );

        if ( apply_filters( 'jet_cct_meta_handler', true, 'post' ) ) {
            // Handle *_post_meta
			if ( apply_filters( 'jet_cct_meta_handler_get', true, 'post' ) ) {
            	add_filter( 'get_post_metadata', array( $this, 'get_post_meta' ), 10, 4 );
			}

            if ( !jet_cct_tableless() ) {
                add_filter( 'add_post_metadata', array( $this, 'add_post_meta' ), 10, 5 );
                add_filter( 'update_post_metadata', array( $this, 'update_post_meta' ), 10, 5 );
                add_filter( 'delete_post_metadata', array( $this, 'delete_post_meta' ), 10, 5 );
            }
        }

        add_action( 'delete_post', array( $this, 'delete_post' ), 10, 1 );

        if ( !empty( self::$taxonomies ) ) {
			$has_fields = false;

            // Handle Taxonomy Editor
            foreach ( self::$taxonomies as $taxonomy ) {
				if ( empty( $taxonomy[ 'fields' ] ) ) {
					continue;
				}

				$has_fields = true;

                $taxonomy_name = $taxonomy[ 'name' ];

                if ( !empty( $taxonomy[ 'object' ] ) )
                    $taxonomy_name = $taxonomy[ 'object' ];

                add_action( $taxonomy_name . '_edit_form_fields', array( $this, 'meta_taxonomy' ), 10, 2 );
                add_action( $taxonomy_name . '_add_form_fields', array( $this, 'meta_taxonomy' ), 10, 1 );
            }

			if ( $has_fields ) {
				// Handle Term Editor
				add_action( 'edited_term', array( $this, 'save_taxonomy' ), 10, 3 );
				add_action( 'create_term', array( $this, 'save_taxonomy' ), 10, 3 );

				if ( apply_filters( 'jet_cct_meta_handler', true, 'term' ) ) {
					// Handle *_term_meta
					if ( apply_filters( 'jet_cct_meta_handler_get', true, 'term' ) ) {
						add_filter( 'get_term_metadata', array( $this, 'get_term_meta' ), 10, 4 );
					}

					if ( !jet_cct_tableless() ) {
						add_filter( 'add_term_metadata', array( $this, 'add_term_meta' ), 10, 5 );
						add_filter( 'update_term_metadata', array( $this, 'update_term_meta' ), 10, 5 );
						add_filter( 'delete_term_metadata', array( $this, 'delete_term_meta' ), 10, 5 );
					}
				}
			}
        }

        /**
         * Fires after a previously shared taxonomy term is split into two separate terms.
         *
         * @since 4.2.0
         *
         * @param int    $term_id          ID of the formerly shared term.
         * @param int    $new_term_id      ID of the new term created for the $term_taxonomy_id.
         * @param int    $term_taxonomy_id ID for the term_taxonomy row affected by the split.
         * @param string $taxonomy         Taxonomy for the split term.
         */
        add_action( 'split_shared_term', array( $this, 'split_shared_term' ), 10, 4 );

        // Handle Delete
        add_action( 'delete_term_taxonomy', array( $this, 'delete_taxonomy' ), 10, 1 );

        if ( !empty( self::$media ) ) {
            if ( jet_cct_version_check( 'wp', '3.5' ) ) {
                add_action( 'add_meta_boxes', array( $this, 'meta_post_add' ) );
                add_action( 'wp_ajax_save-attachment-compat', array( $this, 'save_media_ajax' ), 0 );
            }

            add_filter( 'attachment_fields_to_edit', array( $this, 'meta_media' ), 10, 2 );

            add_filter( 'attachment_fields_to_save', array( $this, 'save_media' ), 10, 2 );
            add_filter( 'wp_update_attachment_metadata', array( $this, 'save_media' ), 10, 2 );

            if ( apply_filters( 'jet_cct_meta_handler', true, 'post' ) ) {
                // Handle *_post_meta
                if ( !has_filter( 'get_post_metadata', array( $this, 'get_post_meta' ) ) ) {
					if ( apply_filters( 'jet_cct_meta_handler_get', true, 'post' ) ) {
                    	add_filter( 'get_post_metadata', array( $this, 'get_post_meta' ), 10, 4 );
					}

                    if ( !jet_cct_tableless() ) {
                        add_filter( 'add_post_metadata', array( $this, 'add_post_meta' ), 10, 5 );
                        add_filter( 'update_post_metadata', array( $this, 'update_post_meta' ), 10, 5 );
                        add_filter( 'delete_post_metadata', array( $this, 'delete_post_meta' ), 10, 5 );
                    }
                }
            }
        }

        // Handle Delete
        add_action( 'delete_attachment', array( $this, 'delete_media' ), 10, 1 );

        if ( !empty( self::$user ) ) {
            // Handle User Editor
            add_action( 'show_user_profile', array( $this, 'meta_user' ) );
            add_action( 'edit_user_profile', array( $this, 'meta_user' ) );
            add_action( 'user_register', array( $this, 'save_user' ) );
            add_action( 'profile_update', array( $this, 'save_user' ), 10, 2 );

            if ( apply_filters( 'jet_cct_meta_handler', true, 'user' ) ) {
                // Handle *_user_meta
				if ( apply_filters( 'jet_cct_meta_handler_get', true, 'user' ) ) {
                	add_filter( 'get_user_metadata', array( $this, 'get_user_meta' ), 10, 4 );
				}

                if ( !jet_cct_tableless() ) {
                    add_filter( 'add_user_metadata', array( $this, 'add_user_meta' ), 10, 5 );
                    add_filter( 'update_user_metadata', array( $this, 'update_user_meta' ), 10, 5 );
                    add_filter( 'delete_user_metadata', array( $this, 'delete_user_meta' ), 10, 5 );
                }
            }
        }

        // Handle Delete
        add_action( 'delete_user', array( $this, 'delete_user' ), 10, 1 );

        if ( !empty( self::$comment ) ) {
            // Handle Comment Form / Editor
            add_action( 'comment_form_logged_in_after', array( $this, 'meta_comment_new_logged_in' ), 10, 2 );
            add_filter( 'comment_form_default_fields', array( $this, 'meta_comment_new' ) );
            add_action( 'add_meta_boxes_comment', array( $this, 'meta_comment_add' ) );
            add_filter( 'pre_comment_approved', array( $this, 'validate_comment' ), 10, 2 );
            add_action( 'comment_post', array( $this, 'save_comment' ) );
            add_action( 'edit_comment', array( $this, 'save_comment' ) );

            if ( apply_filters( 'jet_cct_meta_handler', true, 'comment' ) ) {
                // Handle *_comment_meta
                add_filter( 'get_comment_metadata', array( $this, 'get_comment_meta' ), 10, 4 );

                if ( !jet_cct_tableless() ) {
                    add_filter( 'add_comment_metadata', array( $this, 'add_comment_meta' ), 10, 5 );
                    add_filter( 'update_comment_metadata', array( $this, 'update_comment_meta' ), 10, 5 );
                    add_filter( 'delete_comment_metadata', array( $this, 'delete_comment_meta' ), 10, 5 );
                }
            }
        }

        // Handle Delete
        add_action( 'delete_comment', array( $this, 'delete_comment' ), 10, 1 );

        // @todo Patch core to provide $option back in filters, patch core to add filter pre_add_option to add_option
        /*if ( !empty( self::$settings ) ) {
            foreach ( self::$settings as $setting_jet ) {
                foreach ( $setting_jet[ 'fields' ] as $option ) {
                    add_filter( 'pre_option_' . $setting_jet[ 'name' ] . '_' . $option[ 'name' ], array( $this, 'get_option' ), 10, 1 );
                    add_action( 'add_option_' . $setting_jet[ 'name' ] . '_' . $option[ 'name' ], array( $this, 'add_option' ), 10, 2 );
                    add_filter( 'pre_update_option_' . $setting_jet[ 'name' ] . '_' . $option[ 'name' ], array( $this, 'update_option' ), 10, 2 );
                }
            }
        }*/

        if ( is_admin() )
            $this->integrations();

        add_action( 'init', array( $this, 'enqueue' ), 9 );

        if ( function_exists( 'pll_current_language' ) )
            add_action( 'init', array( $this, 'cache_jet_cct' ), 101 );

        do_action( 'jet_cct_meta_init' );

        return $this;
    }

    public static function enqueue () {
        foreach ( self::$queue as $type => $objects ) {
            foreach ( $objects as $jet_name => $jet ) {
                jet_cct_transient_set( 'jet_cct_jet_' . $jet_name, $jet );
            }

            self::$$type = array_merge( self::$$type, $objects );
        }
    }

    /**
     * Go back through and cache the jet_cct now that Polylang has loaded
     */
    public function cache_jet_cct () {
        self::$advanced_content_types = jet_cct_api()->load_jet_cct( array( 'type' => 'jet', 'refresh' => true ) );
        self::$post_types = jet_cct_api()->load_jet_cct( array( 'type' => 'post_type', 'refresh' => true ) );
        self::$taxonomies = jet_cct_api()->load_jet_cct( array( 'type' => 'taxonomy', 'refresh' => true ) );
        self::$media = jet_cct_api()->load_jet_cct( array( 'type' => 'media', 'refresh' => true ) );
        self::$user = jet_cct_api()->load_jet_cct( array( 'type' => 'user', 'refresh' => true ) );
        self::$comment = jet_cct_api()->load_jet_cct( array( 'type' => 'comment', 'refresh' => true ) );
        self::$settings = jet_cct_api()->load_jet_cct( array( 'type' => 'settings', 'refresh' => true ) );
    }

    public function register ( $type, $jet ) {
        $jet_type = $type;

        if ( 'post_type' == $type )
            $type = 'post_types';
        elseif ( 'taxonomy' == $type )
            $type = 'taxonomies';
        elseif ( 'jet' == $type )
            $type = 'advanced_content_types';

        if ( !isset( self::$queue[ $type ] ) )
            self::$queue[ $type ] = array();

        if ( is_array( $jet ) && !empty( $jet ) && !isset( $jet[ 'name' ] ) ) {
            $data = array();

            foreach ( $jet as $p ) {
                $data[] = $this->register( $type, $p );
            }

            return $data;
        }

        $jet[ 'type' ] = $jet_type;
        $jet = jet_cct_api()->save_jet( $jet, false, false );

        if ( !empty( $jet ) ) {
            self::$object_identifier--;

            self::$queue[ $type ][ $jet[ 'name' ] ] = $jet;

            return $jet;
        }

        return false;
    }

    public function register_field ( $jet, $field ) {
        if ( is_array( $jet ) && !empty( $jet ) && !isset( $jet[ 'name' ] ) ) {
            $data = array();

            foreach ( $jet as $p ) {
                $data[] = $this->register_field( $p, $field );
            }

            return $data;
        }

        if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $jet )
            self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $jet ), false );

        $jet = self::$current_jet_data;

        if ( !empty( $jet ) ) {
            $type = $jet[ 'type' ];

            if ( 'post_type' == $jet[ 'type' ] )
                $type = 'post_types';
            elseif ( 'taxonomy' == $jet[ 'type' ] )
                $type = 'taxonomies';
            elseif ( 'jet' == $jet[ 'type' ] )
                $type = 'advanced_content_types';

            if ( !isset( self::$queue[ $jet[ 'type' ] ] ) )
                self::$queue[ $type ] = array();

            $field = jet_cct_api()->save_field( $field, false, false, $jet[ 'id' ] );

            if ( !empty( $field ) ) {
                $jet[ 'fields' ][ $field[ 'name' ] ] = $field;

                self::$queue[ $type ][ $jet[ 'name' ] ] = $jet;

                return $field;
            }
        }

        return false;
    }

    public function integrations () {
        // Codepress Admin Columns 2.x
		add_filter( 'cac/storage_model/meta_keys', array( $this, 'cpac_meta_keys' ), 10, 2 );
        add_filter( 'cac/post_types', array( $this, 'cpac_post_types' ), 10, 1 );
        add_filter( 'cac/column/meta/value', array( $this, 'cpac_meta_value' ), 10, 3 );
    }


    public function cpac_meta_keys ( $meta_fields, $storage_model ) {
        $object_type = 'post_type';
        $object = $storage_model->key;

        if ( in_array( $storage_model->key, array( 'wp-links', 'link' ) ) ) {
            $object_type = $object = 'link';
        }
        elseif ( in_array( $storage_model->key, array( 'wp-media', 'media' ) ) ) {
            $object_type = $object = 'media';
        }
        elseif ( in_array( $storage_model->key, array( 'wp-users', 'user' ) ) ) {
            $object_type = $object = 'user';
        }
        elseif ( in_array( $storage_model->key, array( 'wp-comments', 'comment' ) ) ) {
            $object_type = $object = 'comment';
        }
        elseif ( 'taxonomy' === $storage_model->type ) {
            $object_type = 'taxonomy';
            $object = $storage_model->taxonomy;
        }

        if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $object )
            self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $object ), false );

        $jet = self::$current_jet_data;

        // Add jet_cct fields
        if ( !empty( $jet ) && $object_type == $jet[ 'type' ] ) {
            foreach ( $jet[ 'fields' ] as $field => $field_data ) {
                if ( !is_array( $meta_fields ) )
                    $meta_fields = array();

                if ( !in_array( $field, $meta_fields ) )
                    $meta_fields[] = $field;
            }
        }

        // Remove internal jet_cct fields
        if ( is_array( $meta_fields ) ) {
            foreach ( $meta_fields as $k => $meta_field ) {
                if ( 0 === strpos( $meta_field, '_jet_cct_' ) )
                    unset( $meta_fields[ $k ] );
            }
        }

        return $meta_fields;
    }

    public function cpac_post_types ( $post_types ) {
        // Remove internal jet_cct post types
        foreach ( $post_types as $post_type => $post_type_name ) {
            if ( 0 === strpos( $post_type, '_jet_cct_' ) || 0 === strpos( $post_type_name, '_jet_cct_' ) )
                unset( $post_types[ $post_type ] );
        }

        return $post_types;
    }

    public function cpac_meta_value ( $meta, $id, $obj ) {
        $tableless_field_types = jet_cctForm::tableless_field_types();

        $object_type = 'post_type';
        $object = $obj->storage_model->key;

        if ( in_array( $obj->storage_model->type, array( 'wp-links', 'link' ) ) ) {
            $object_type = $object = 'link';
        }
        elseif ( in_array( $obj->storage_model->type, array( 'wp-media', 'media' ) ) ) {
            $object_type = $object = 'media';
        }
        elseif ( in_array( $obj->storage_model->type, array( 'wp-users', 'user' ) ) ) {
            $object_type = $object = 'user';
        }
        elseif ( in_array( $obj->storage_model->type, array( 'wp-comments', 'comment' ) ) ) {
            $object_type = $object = 'comment';
        }
        elseif ( 'taxonomy' === $obj->storage_model->type ) {
            $object_type = 'taxonomy';
            $object = $obj->storage_model->taxonomy;
        }

        $field = substr( $obj->get_option( 'field' ), 0, 10 ) == "cpachidden" ? str_replace( 'cpachidden', '', $obj->get_option( 'field' ) ) : $obj->get_option( 'field' );
        $field_type = $obj->get_option( 'field_type' );

        if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $object )
            self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $object ), false );

        $jet = self::$current_jet_data;

        // Add jet_cct fields
        if ( !empty( $jet ) && isset( $jet[ 'fields' ][ $field ] ) ) {
            if ( in_array( $jet[ 'type' ], array( 'post_type', 'media', 'taxonomy', 'user', 'comment', 'media' ) ) && ( !empty( $field_type ) || in_array( $jet[ 'fields' ][ $field ][ 'type' ], $tableless_field_types ) ) ) {
                $metadata_type = $jet['type'];

                if ( in_array( $metadata_type, array( 'post_type', 'media' ) ) ) {
                    $metadata_type = 'post';
                } elseif ( 'taxonomy' == $metadata_type ) {
                    $metadata_type = 'term';
                }

                if ( 'term' == $metadata_type && ! function_exists( 'get_term_meta' ) ) {
                    $jetterms = jet_cct( $jet['name'], $id );

                    $meta = $jetterms->field( $field );
                } else {
                    $meta = get_metadata( $metadata_type, $id, $field, true );
                }
            }
            elseif ( 'taxonomy' == $jet['type'] ) {
                $jetterms = jet_cct( $jet['name'], $id );

                $meta = $jetterms->field( $field );
            }

            $meta = jet_cctForm::field_method( $jet[ 'fields' ][ $field ][ 'type' ], 'ui', $id, $meta, $field, array_merge( $jet[ 'fields' ][ $field ], $jet[ 'fields' ][ $field ][ 'options' ] ), $jet[ 'fields' ], $jet );
        }

        return $meta;
    }

    public function cpac_meta_values ( $meta, $field_type, $field, $type, $id ) {
        $tableless_field_types = jet_cctForm::tableless_field_types();

        $object = $type;

        if ( 'wp-media' == $type )
            $object = 'media';
        elseif ( 'wp-users' == $type )
            $object = 'user';
        elseif ( 'wp-comments' == $type )
            $object = 'comment';

        if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $object )
            self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $object ), false );

        $jet = self::$current_jet_data;

        // Add jet_cct fields
        if ( !empty( $jet ) && isset( $jet[ 'fields' ][ $field ] ) ) {
            if ( in_array( $jet[ 'type' ], array( 'post_type', 'user', 'taxonomy', 'comment', 'media' ) ) && ( !empty( $field_type ) || in_array( $jet[ 'fields' ][ $field ][ 'type' ], $tableless_field_types ) ) ) {
                $metadata_type = $jet['type'];

                if ( in_array( $metadata_type, array( 'post_type', 'media' ) ) ) {
                    $metadata_type = 'post';
                } elseif ( 'taxonomy' == $metadata_type ) {
                    $metadata_type = 'term';
                }

                $meta = get_metadata( $metadata_type, $id, $field, true );
            }

            $meta = jet_cctForm::field_method( $jet[ 'fields' ][ $field ][ 'type' ], 'ui', $id, $meta, $field, array_merge( $jet[ 'fields' ][ $field ], $jet[ 'fields' ][ $field ][ 'options' ] ), $jet[ 'fields' ], $jet );
        }

        return $meta;
    }

    /**
     * Add a meta group of fields to add/edit forms
     *
     * @param string|array $jet The jet or type of element to attach the group to.
     * @param string $label Title of the edit screen section, visible to user.
     * @param string|array $fields Either a comma separated list of text fields or an associative array containing field infomration.
     * @param string $context (optional) The part of the page where the edit screen section should be shown ('normal', 'advanced', or 'side').
     * @param string $priority (optional) The priority within the context where the boxes should show ('high', 'core', 'default' or 'low').
     *
     * @since 2.0
     *
     * @return mixed|void
     */
    public function group_add ( $jet, $label, $fields, $context = 'normal', $priority = 'default' ) {
        if ( is_array( $jet ) && !empty( $jet ) && !isset( $jet[ 'name' ] ) ) {
            foreach ( $jet as $p ) {
                $this->group_add( $jet, $label, $fields, $context, $priority );
            }

            return true;
        }

        if ( !is_array( $jet ) ) {
            if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $jet )
                self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $jet ), false );

            if ( !empty( self::$current_jet_data ) )
                $jet = self::$current_jet_data;
            else {
                $type = 'post_type';

                if ( in_array( $jet, array( 'media', 'user', 'comment' ) ) )
                    $type = $jet;

                $jet = array(
                    'name' => $jet,
                    'type' => $type
                );
            }
        }

        if ( is_array( $jet ) && !isset( $jet[ 'id' ] ) ) {
            $defaults = array(
                'name' => '',
                'type' => 'post_type'
            );

            $jet = array_merge( $defaults, $jet );
        }

        if ( 'post' == $jet[ 'type' ] )
            $jet[ 'type' ] = 'post_type';

        if ( empty( $jet[ 'name' ] ) && isset( $jet[ 'object' ] ) && !empty( $jet[ 'object' ] ) )
            $jet[ 'name' ] = $jet[ 'object' ];
        elseif ( !isset( $jet[ 'object' ] ) || empty( $jet[ 'object' ] ) )
            $jet[ 'object' ] = $jet[ 'name' ];

        if ( empty( $jet[ 'object' ] ) )
            return jet_cct_error( __( 'Object required to add a jet_cct meta group', 'jet_cct' ) );

        $object_name = $jet[ 'object' ];

        if ( 'jet' == $jet[ 'type' ] )
            $object_name = $jet[ 'name' ];

        if ( !isset( self::$groups[ $jet[ 'type' ] ] ) )
            self::$groups[ $jet[ 'type' ] ] = array();

        if ( !isset( self::$groups[ $jet[ 'type' ] ][ $object_name ] ) )
            self::$groups[ $jet[ 'type' ] ][ $object_name ] = array();

        $_fields = array();

        if ( !is_array( $fields ) )
            $fields = explode( ',', $fields );

        foreach ( $fields as $k => $field ) {
            $name = $k;

            $defaults = array(
                'name' => $name,
                'label' => $name,
                'type' => 'text'
            );

            if ( !is_array( $field ) ) {
                $name = trim( $field );

                $field = array(
                    'name' => $name,
                    'label' => $name
                );
            }

            $field = array_merge( $defaults, $field );

            $field[ 'name' ] = trim( $field[ 'name' ] );

            if ( isset( $jet[ 'fields' ] ) && isset( $jet[ 'fields' ][ $field[ 'name' ] ] ) )
                $field = array_merge( $field, $jet[ 'fields' ][ $field[ 'name' ] ] );

            $_fields[ $k ] = $field;
        }

        // Setup field options
        $fields = jet_cctForm::fields_setup( $_fields );

        $group = array(
            'jet' => $jet,
            'label' => $label,
            'fields' => $fields,
            'context' => $context,
            'priority' => $priority
        );

        // Filter group data, pass vars separately for reference down the line (in case array changed by other filter)
        $group = apply_filters( 'jet_cct_meta_group_add_' . $jet[ 'type' ] . '_' . $object_name, $group, $jet, $label, $fields );
        $group = apply_filters( 'jet_cct_meta_group_add_' . $jet[ 'type' ], $group, $jet, $label, $fields );
        $group = apply_filters( 'jet_cct_meta_group_add', $group, $jet, $label, $fields );

        self::$groups[ $jet[ 'type' ] ][ $object_name ][] = $group;

        // Hook it up!
        if ( 'post_type' == $jet[ 'type' ] ) {
            if ( !has_action( 'add_meta_boxes', array( $this, 'meta_post_add' ) ) )
                add_action( 'add_meta_boxes', array( $this, 'meta_post_add' ) );

            /*if ( !has_action( 'save_post', array( $this, 'save_post' ), 10, 3 ) )
                add_action( 'save_post', array( $this, 'save_post' ), 10, 3 );*/
        }
        elseif ( 'taxonomy' == $jet[ 'type' ] ) {
            if ( !has_action( $jet[ 'object' ] . '_edit_form_fields', array( $this, 'meta_taxonomy' ), 10, 2 ) ) {
                add_action( $jet[ 'object' ] . '_edit_form_fields', array( $this, 'meta_taxonomy' ), 10, 2 );
                add_action( $jet[ 'object' ] . '_add_form_fields', array( $this, 'meta_taxonomy' ), 10, 1 );
            }

            if ( !has_action( 'edited_term', array( $this, 'save_taxonomy' ), 10, 3 ) ) {
                add_action( 'edited_term', array( $this, 'save_taxonomy' ), 10, 3 );
                add_action( 'create_term', array( $this, 'save_taxonomy' ), 10, 3 );
            }
        }
        elseif ( 'media' == $jet[ 'type' ] ) {
            if ( !has_filter( 'wp_update_attachment_metadata', array( $this, 'save_media' ), 10, 2 ) ) {
                if ( jet_cct_version_check( 'wp', '3.5' ) ) {
                    add_action( 'add_meta_boxes', array( $this, 'meta_post_add' ) );
                    add_action( 'wp_ajax_save-attachment-compat', array( $this, 'save_media_ajax' ), 0 );
                }

                add_filter( 'attachment_fields_to_edit', array( $this, 'meta_media' ), 10, 2 );

                add_filter( 'attachment_fields_to_save', array( $this, 'save_media' ), 10, 2 );
                add_filter( 'wp_update_attachment_metadata', array( $this, 'save_media' ), 10, 2 );
            }
        }
        elseif ( 'user' == $jet[ 'type' ] ) {
            if ( !has_action( 'show_user_profile', array( $this, 'meta_user' ) ) ) {
                add_action( 'show_user_profile', array( $this, 'meta_user' ) );
                add_action( 'edit_user_profile', array( $this, 'meta_user' ) );
                add_action( 'user_register', array( $this, 'save_user' ) );
                add_action( 'profile_update', array( $this, 'save_user' ), 10, 2 );
            }
        }
        elseif ( 'comment' == $jet[ 'type' ] ) {
            if ( !has_action( 'comment_form_logged_in_after', array( $this, 'meta_comment_new_logged_in' ), 10, 2 ) ) {
                add_action( 'comment_form_logged_in_after', array( $this, 'meta_comment_new_logged_in' ), 10, 2 );
                add_filter( 'comment_form_default_fields', array( $this, 'meta_comment_new' ) );
                add_action( 'add_meta_boxes_comment', array( $this, 'meta_comment_add' ) );
                add_action( 'wp_insert_comment', array( $this, 'save_comment' ) );
                add_action( 'edit_comment', array( $this, 'save_comment' ) );
            }
        }
    }

    public function object_get ( $type, $name ) {
        $object = self::$post_types;

        if ( 'term' == $type ) {
        	$type = 'taxonomy';
        }

        if ( 'taxonomy' == $type )
            $object = self::$taxonomies;
        elseif ( 'media' == $type )
            $object = self::$media;
        elseif ( 'user' == $type )
            $object = self::$user;
        elseif ( 'comment' == $type )
            $object = self::$comment;

        if ( 'jet' != $type && !empty( $object ) && is_array( $object ) && isset( $object[ $name ] ) )
            $jet = $object[ $name ];
        else {
            if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $name )
                self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $name ), false );

            $jet = self::$current_jet_data;
        }

        if ( empty( $jet ) )
            return array();

        $defaults = array(
            'name' => 'post',
            'object' => 'post',
            'type' => 'post_type'
        );

        $jet = array_merge( $defaults, (array) $jet );

        if ( empty( $jet[ 'name' ] ) )
            $jet[ 'name' ] = $jet[ 'object' ];
        elseif ( empty( $jet[ 'object' ] ) )
            $jet[ 'object' ] = $jet[ 'name' ];

        if ( $jet[ 'type' ] != $type )
            return array();

        return $jet;
    }

    /**
     * @param $type
     * @param $name
     * @param $default_fields
     *
     * @return array
     */
    public function groups_get ( $type, $name, $default_fields = null ) {
        if ( 'post_type' == $type && 'attachment' == $name ) {
            $type = 'media';
            $name = 'media';
        } elseif ( 'term' == $type ) {
            $type = 'taxonomy';
        }

        do_action( 'jet_cct_meta_groups', $type, $name );

        $jet = array();
        $fields = array();

        $object = self::$post_types;

        if ( 'taxonomy' == $type )
            $object = self::$taxonomies;
        elseif ( 'media' == $type )
            $object = self::$media;
        elseif ( 'user' == $type )
            $object = self::$user;
        elseif ( 'comment' == $type )
            $object = self::$comment;
        elseif ( 'jet' == $type )
            $object = self::$advanced_content_types;

        if ( !empty( $object ) && is_array( $object ) && isset( $object[ $name ] ) )
            $fields = $object[ $name ][ 'fields' ];
        else {
            if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet_data ) || self::$current_jet_data[ 'name' ] != $name )
                self::$current_jet_data = jet_cct_api()->load_jet( array( 'name' => $name ), false );

            $jet = self::$current_jet_data;

            if ( !empty( $jet ) )
                $fields = $jet[ 'fields' ];
        }

        if ( null !== $default_fields ) {
            $fields = $default_fields;
        }

        $defaults = array(
            'name' => 'post',
            'object' => 'post',
            'type' => 'post_type'
        );

        $jet = array_merge( $defaults, (array) $jet );

        if ( empty( $jet[ 'name' ] ) )
            $jet[ 'name' ] = $jet[ 'object' ];
        elseif ( empty( $jet[ 'object' ] ) )
            $jet[ 'object' ] = $jet[ 'name' ];

        if ( $jet[ 'type' ] != $type )
            return array();

        $groups = array(
            array(
                'jet' => $jet,
				/**
				 * Filter the title of the jet_cct Metabox In The Post Editor
				 *
				 * @param string $title The title to use, default is 'More Fields'
				 * @param obj|jet $jet Current jet_cct Object
				 * @param array $fields Array of fields that will go in the metabox
				 * @param string $type The type of jet
				 * @params string $name Name of the jet
				 *
				 * @returns string The title for the metabox.
				 *
				 * @since unknown
				 */
				'label' => apply_filters( 'jet_cct_meta_default_box_title', __( 'More Fields', 'jet_cct' ), $jet, $fields, $type, $name ),
                'fields' => $fields,
                'context' => 'normal',
                'priority' => 'default'
            )
        );

        if ( isset( self::$groups[ $type ] ) && isset( self::$groups[ $type ][ $name ] ) )
            $groups = self::$groups[ $type ][ $name ];

        /**
         * Filter the array of field groups
         *
         * @param array  $groups Array of groups
         * @param string  $type The type of jet
         * @param string  $name Name of the jet
         *
         * @since 2.6.6
         */
        return apply_filters( 'jet_cct_meta_groups_get', $groups, $type, $name );
    }

    /**
     * @param $post_type
     * @param null $post
     */
    public function meta_post_add ( $post_type, $post = null ) {
        if ( 'comment' == $post_type )
            return;

        if ( is_object( $post ) )
            $post_type = $post->post_type;

        $groups = $this->groups_get( 'post_type', $post_type );
        $jet_cct_field_found = false;

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

            $field_found = false;
            $group_hidden = true;

            foreach ( $group[ 'fields' ] as $field ) {
                if ( false !== jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ] ) ) {
                    $field_found = true;
                }
                if ( ! isset( $field['options']['hidden'] ) || 1 != (int) $field['options']['hidden'] ) {
                    $group_hidden = false;
                }
            }

            if ( $group_hidden )
                continue;

            if ( empty( $group[ 'label' ] ) )
                $group[ 'label' ] = get_post_type_object( $post_type )->labels->label;

            if ( $field_found ) {
                $jet_cct_field_found = true;
                add_meta_box(
                    'jet_cct-meta-' . sanitize_title( $group[ 'label' ] ),
                    $group[ 'label' ],
                    array( $this, 'meta_post' ),
                    $post_type,
                    $group[ 'context' ],
                    $group[ 'priority' ],
                    array( 'group' => $group )
                );

            }
        }

		if ( $jet_cct_field_found ) {
			// Only add the classes to forms that actually have jet_cct fields
			add_action( 'post_edit_form_tag', array( $this, 'add_class_submittable' ) );
		}
    }

    /**
     *
     * Called by 'post_edit_form_tag' action to include the classes in the <form> tag
     *
     */
    public function add_class_submittable () {
        echo ' class="jet_cct-submittable jet_cct-form"';
    }

    /**
     * @param $post
     * @param $metabox
     */
    public function meta_post ( $post, $metabox ) {
        wp_enqueue_style( 'jet_cct-form' );
        wp_enqueue_script( 'jet_cct' );

		$jet_type = 'post';

		if ( 'attachment' == $post->post_type ) {
			$jet_type = 'media';
		}

        do_action( 'jet_cct_meta_' . __FUNCTION__, $post );

        $hidden_fields = array();

        $id = null;

        if ( is_object( $post ) && false === strpos( $_SERVER[ 'REQUEST_URI' ], '/post-new.php' ) )
            $id = $post->ID;

	if ( empty( self::$current_jet_data ) || !is_object( self::$current_jet ) || self::$current_jet->jet != $metabox[ 'args' ][ 'group' ][ 'jet' ][ 'name' ] ) {
		self::$current_jet = jet_cct( $metabox[ 'args' ][ 'group' ][ 'jet' ][ 'name' ], $id, true );
	} elseif ( self::$current_jet->id() != $id ) {
		self::$current_jet->fetch( $id );
	}

        $jet = self::$current_jet;

	$fields = $metabox['args']['group']['fields'];

	/**
	 * Filter the fields used for the jet_cct metabox group
	 *
	 * @since 2.6.6
	 *
	 * @param array   $fields  Fields from the current jet metabox group
	 * @param int     $id      Post ID
	 * @param WP_Post $post    Post object
	 * @param array	  $metabox Metabox args from the current jet metabox group
	 * @param jet_cct    $jet     jet object
	 */
 	$fields = apply_filters( 'jet_cct_meta_post_fields', $fields, $id,  $post, $metabox, $jet  );

 	if ( empty( $fields ) ) {
 		_e( 'There are no fields to display', 'jet_cct' );

 		return;
 	}
?>
    <table class="form-table jet_cct-metabox jet_cct-admin jet_cct-dependency">
	<?php
	echo jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_' . $jet_type ), 'hidden' );

        foreach ( $fields as $field ) {
            if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field[ 'options' ], $fields, $jet, $id ) ) {
                if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                    $field[ 'type' ] = 'hidden';
                else
                    continue;
            }
            elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                $field[ 'type' ] = 'hidden';

            $value = '';

            if ( !empty( $jet ) ) {
                jet_cct_no_conflict_on( 'post' );

                $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );

                jet_cct_no_conflict_off( 'post' );
            }
            elseif ( !empty( $id ) )
                $value = get_post_meta( $id, $field[ 'name' ], true );

            if ( 'hidden' == $field[ 'type' ] ) {
                $hidden_fields[] = array(
                    'field' => $field,
                    'value' => $value
                );
            }
            else {
                $depends = jet_cctForm::dependencies( $field, 'jet_cct-meta-' );

            do_action( 'jet_cct_meta_' . __FUNCTION__ . '_' . $field[ 'name' ], $post, $field, $jet );
        ?>
            <tr class="form-field jet_cct-field jet_cct-field-input <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?> <?php echo esc_attr( $depends ); ?>">
                <th scope="row" valign="top"><?php echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field ); ?></th>
                <td>
                    <?php
                        // Remove any extra ? help icons
                        if ( isset( $field[ 'help' ] ) )
                            unset( $field[ 'help' ] );
                    ?>
			<div class="jet_cct-submittable-fields">
                    <?php echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id ); ?>
                    <?php echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field ); ?>
			</div>
                </td>
            </tr>
        <?php
                do_action( 'jet_cct_meta_' . __FUNCTION__ . '_' . $field[ 'name' ] . '_post', $post, $field, $jet );
            }
        }
        ?>
    </table>

    <?php
        do_action( 'jet_cct_meta_' . __FUNCTION__ . '_post', $post );

        foreach ( $hidden_fields as $hidden_field ) {
            $field_data = $hidden_field[ 'field' ];

            echo jet_cctForm::field( 'jet_cct_meta_' . $field_data[ 'name' ], $hidden_field[ 'value' ], 'hidden', $field_data );
        }
    ?>

    <script type="text/javascript">
        jQuery( function ( $ ) {
            $( document ).jet_cct( 'validate' );
            $( document ).jet_cct( 'submit_meta' );
            $( document ).jet_cct( 'dependency', true );
        } );
    </script>
<?php
    }

    /**
	 * Handle integration with the transition_post_status hook
	 *
     * @see wp_transition_post_status
	 *
     * @param string  $new_status
     * @param string  $old_status
     * @param WP_Post $post
     */
    public function save_post_detect_new ( $new_status, $old_status, $post ) {

    	if ( $post ) {
		    self::$old_post_status[ $post->post_type ] = $old_status;
	    }

    }

    /**
     * Handle integration with the save_post hook
     *
     * @see wp_insert_post
	 *
     * @param int       $post_id
     * @param WP_Post   $post
     * @param bool|null $update
     */
	public function save_post( $post_id, $post, $update = null ) {

		if ( empty( $post ) ) {
			return;
		}

		$is_new_item = false;

		if ( is_bool( $update ) ) {
			$is_new_item = ! $update;
		} // false is new item
		elseif ( isset( self::$old_post_status[ $post->post_type ] ) && in_array( self::$old_post_status[ $post->post_type ], array( 'new', 'auto-draft' ), true ) ) {
			$is_new_item = true;
		}

		$nonced = wp_verify_nonce( jet_cct_v( 'jet_cct_meta', 'post' ), 'jet_cct_meta_post' );

		if ( ! $is_new_item && false === $nonced ) {
			return;
		}

		// Unset to avoid manual new post issues
		if ( isset( self::$old_post_status[ $post->post_type ] ) ) {
			unset( self::$old_post_status[ $post->post_type ] );
		}

		$blacklisted_types = array(
			'revision',
			'_jet_cct_jet',
			'_jet_cct_field'
		);

		$blacklisted_types = apply_filters( 'jet_cct_meta_save_post_blacklist_types', $blacklisted_types, $post_id, $post );

		// @todo Figure out how to hook into autosave for saving meta

		// Block Autosave and Revisions
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || in_array( $post->post_type, $blacklisted_types ) ) {
			return;
		}

		// Block Quick Edits / Bulk Edits
		if ( 'edit.php' === jet_cct_v( 'pagenow', 'global' ) && ( 'inline-save' === jet_cct_v( 'action', 'post' ) || null !== jet_cct_v( 'bulk_edit', 'get' ) || is_array( jet_cct_v( 'post', 'get' ) ) ) ) {
			return;
		}

		// Block Trash
		if ( in_array( jet_cct_v( 'action', 'get' ), array( 'untrash', 'trash' ), true ) ) {
			return;
		}

		// Block Auto-drafting and Trash (not via Admin action)
		$blacklisted_status = array(
			'auto-draft',
			'trash',
		);

		$blacklisted_status = apply_filters( 'jet_cct_meta_save_post_blacklist_status', $blacklisted_status, $post_id, $post );

		if ( in_array( $post->post_status, $blacklisted_status ) ) {
			return;
		}

		$groups = $this->groups_get( 'post_type', $post->post_type );

		$id = $post_id;

		if ( ! is_object( self::$current_jet ) || self::$current_jet->jet !== $post->post_type ) {
			self::$current_jet = jet_cct( $post->post_type, $id, true );
		} elseif ( is_object( self::$current_jet ) && (int) self::$current_jet->id() !== (int) $id ) {
			self::$current_jet->fetch( $id );
		}

		$jet  = self::$current_jet;
		$data = array();

		if ( false !== $nonced && ! empty( $groups ) ) {
			foreach ( $groups as $group ) {
				if ( empty( $group['fields'] ) ) {
					continue;
				}

				foreach ( $group['fields'] as $field ) {
					if ( false === jet_cctForm::permission( $field['type'], $field['name'], $field, $group['fields'], $jet, $id ) ) {
						if ( ! jet_cct_v( 'hidden', $field['options'], false ) ) {
							continue;
						}
					}

					$data[ $field['name'] ] = '';

					if ( isset( $_POST[ 'jet_cct_meta_' . $field['name'] ] ) ) {
						$data[ $field['name'] ] = $_POST[ 'jet_cct_meta_' . $field['name'] ];
					}
				}
			}

			if ( $is_new_item ) {
				do_action( 'jet_cct_meta_create_pre_post', $data, $jet, $id, $groups, $post, $post->post_type );
				do_action( "jet_cct_meta_create_pre_post_{$post->post_type}", $data, $jet, $id, $groups, $post );
			}

			do_action( 'jet_cct_meta_save_pre_post', $data, $jet, $id, $groups, $post, $post->post_type, $is_new_item );
			do_action( "jet_cct_meta_save_pre_post_{$post->post_type}", $data, $jet, $id, $groups, $post, $is_new_item );
		}

		if ( $is_new_item || false !== $nonced ) {
			jet_cct_no_conflict_on( 'post' );

			if ( ! empty( $jet ) ) {
				// Fix for jet_cct doing it's own sanitizing
				$data = jet_cct_unslash( (array) $data );

				$jet->save( $data, null, null, array( 'is_new_item' => $is_new_item ) );
			} elseif ( ! empty( $id ) ) {
				foreach ( $data as $field => $value ) {
					update_post_meta( $id, $field, $value );
				}
			}

			jet_cct_no_conflict_off( 'post' );
		}

		if ( false !== $nonced && ! empty( $groups ) ) {
			if ( $is_new_item ) {
				do_action( 'jet_cct_meta_create_post', $data, $jet, $id, $groups, $post, $post->post_type );
				do_action( "jet_cct_meta_create_post_{$post->post_type}", $data, $jet, $id, $groups, $post );
			}

			do_action( 'jet_cct_meta_save_post', $data, $jet, $id, $groups, $post, $post->post_type, $is_new_item );
			do_action( "jet_cct_meta_save_post_{$post->post_type}", $data, $jet, $id, $groups, $post, $is_new_item );
		}

	}

    /**
     * @param $form_fields
     * @param $post
     *
     * @return array
     */
    public function meta_media ( $form_fields, $post ) {
        $groups = $this->groups_get( 'media', 'media' );

        if ( empty( $groups ) || 'attachment' == jet_cct_var( 'typenow', 'global' ) )
            return $form_fields;

        wp_enqueue_style( 'jet_cct-form' );

        $id = null;

        if ( is_object( $post ) )
            $id = $post->ID;

        $jet = null;

		$meta_nonce = jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_media' ), 'hidden' );

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {
                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( !jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        continue;
                }

                $value = '';

                if ( !empty( $jet ) )
                    $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );
                elseif ( !empty( $id ) ) {
                    jet_cct_no_conflict_on( 'post' );

                    $value = get_post_meta( $id, $field[ 'name' ], true );

                    jet_cct_no_conflict_off( 'post' );
                }

                $form_fields[ 'jet_cct_meta_' . $field[ 'name' ] ] = array(
                    'label' => $field[ 'label' ],
                    'input' => 'html',
                    'html' => jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id ) . $meta_nonce,
                    'helps' => jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field )
                );
            }
        }

        $form_fields = apply_filters( 'jet_cct_meta_' . __FUNCTION__, $form_fields );

        return $form_fields;
    }

    /**
     * @param $post
     * @param $attachment
     *
     * @return mixed
     */
    public function save_media ( $post, $attachment ) {
        $groups = $this->groups_get( 'media', 'media' );

        if ( empty( $groups ) )
            return $post;

        $post_id = $attachment;

        if ( empty( $_POST ) || !wp_verify_nonce( jet_cct_v( 'jet_cct_meta', 'post' ), 'jet_cct_meta_media' ) ) {
            return $post;
		}

        if ( is_array( $post ) && !empty( $post ) && isset( $post[ 'ID' ] ) && 'attachment' == $post[ 'post_type' ] )
            $post_id = $post[ 'ID' ];

        if ( is_array( $post_id ) || empty( $post_id ) )
            return $post;

        $data = array();

        $id = $post_id;
        $jet = null;

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {

                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( !jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        continue;
                }

                $data[ $field[ 'name' ] ] = '';

                if ( isset( $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ] ) )
                    $data[ $field[ 'name' ] ] = $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ];
            }
        }

        do_action( 'jet_cct_meta_save_pre_media', $data, $jet, $id, $groups, $post, $attachment );

        if ( !empty( $jet ) ) {
            // Fix for jet_cct doing it's own sanitization
            $data = jet_cct_unslash( (array) $data );

            $jet->save( $data, null, null, array( 'jet_cctmeta' => true ) );
        }
        elseif ( !empty( $id ) ) {
            jet_cct_no_conflict_on( 'post' );

            foreach ( $data as $field => $value ) {
                update_post_meta( $id, $field, $value );
            }

            jet_cct_no_conflict_off( 'post' );
        }

        do_action( 'jet_cct_meta_save_media', $data, $jet, $id, $groups, $post, $attachment );

        return $post;
    }

    public function save_media_ajax () {
        if ( !isset( $_POST[ 'id' ] ) || empty( $_POST[ 'id' ] ) || absint( $_POST[ 'id' ] ) < 1 )
            return;

        $id = absint( $_POST[ 'id' ] );

        if ( !isset( $_POST[ 'nonce' ] ) || empty( $_POST[ 'nonce' ] ) )
            return;

        check_ajax_referer( 'update-post_' . $id, 'nonce' );

        if ( !current_user_can( 'edit_post', $id ) )
            return;

        $post = get_post( $id, ARRAY_A );

    	if ( 'attachment' != $post[ 'post_type' ] )
            return;

        // fix ALL THE THINGS

        if ( !isset( $_REQUEST[ 'attachments' ] ) )
            $_REQUEST[ 'attachments' ] = array();

        if ( !isset( $_REQUEST[ 'attachments' ][ $id ] ) )
            $_REQUEST[ 'attachments' ][ $id ] = array();

        if ( empty( $_REQUEST[ 'attachments' ][ $id ] ) )
            $_REQUEST[ 'attachments' ][ $id ][ '_fix_wp' ] = 1;
    }

    /**
     * @param $tag
     * @param null $taxonomy
     */
    public function meta_taxonomy ( $tag, $taxonomy = null ) {
        wp_enqueue_style( 'jet_cct-form' );

        do_action( 'jet_cct_meta_' . __FUNCTION__, $tag, $taxonomy );

        $taxonomy_name = $taxonomy;

        if ( !is_object( $tag ) )
            $taxonomy_name = $tag;

        $groups = $this->groups_get( 'taxonomy', $taxonomy_name );

        $id = null;

        if ( is_object( $tag ) )
            $id = $tag->term_id;

        $jet = null;

		echo jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_taxonomy' ), 'hidden' );

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {
                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        $field[ 'type' ] = 'hidden';
                    else
                        continue;
                }
                elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                    $field[ 'type' ] = 'hidden';

                $value = '';

                if ( !empty( $jet ) )
                    $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );

                if ( !is_object( $tag ) ) {
            ?>
                <div class="form-field jet_cct-field" style="<?php echo esc_attr( 'hidden' == $field[ 'type' ] ? 'display:none;' : '' ); ?>">
                    <?php
                        echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field );
                        echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id );
                        echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field );
                    ?>
                </div>
            <?php
                }
                else {
            ?>
                <tr class="form-field jet_cct-field <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>" style="<?php echo esc_attr( 'hidden' == $field[ 'type' ] ? 'display:none;' : '' ); ?>">
                    <th scope="row" valign="top"><?php echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field ); ?></th>
                    <td>
                        <?php
                            echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id );
                            echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field );
                        ?>
                    </td>
                </tr>
            <?php
                }
            }
        }

        do_action( 'jet_cct_meta_' . __FUNCTION__ . '_post', $tag, $taxonomy );
    }

    /**
     * @param $term_id
     * @param $term_taxonomy_id
     * @param $taxonomy
     */
    public function save_taxonomy ( $term_id, $term_taxonomy_id, $taxonomy ) {
        $is_new_item = false;

        if ( 'create_term' == current_filter() )
            $is_new_item = true;

        if ( empty( $_POST ) || !wp_verify_nonce( jet_cct_v( 'jet_cct_meta', 'post' ), 'jet_cct_meta_taxonomy' ) ) {
            return $term_id;
		}

		// Block Quick Edits / Bulk Edits
		if ( 'inline-save-tax' == jet_cct_var( 'action', 'post' ) || null != jet_cct_var( 'delete_tags', 'post' ) ) {
            return $term_id;
		}

        $groups = $this->groups_get( 'taxonomy', $taxonomy );

        if ( empty( $groups ) )
            return $term_id;

		$term = null;

        $id = $term_id;
        $jet = null;

		$has_fields = false;

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $term ) {
				$term = get_term( $term_id, $taxonomy );

				$data = array(
					'name' => $term->name
				);
			}

			$has_fields = true;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {

                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( !jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        continue;
                }

                $data[ $field[ 'name' ] ] = '';

                if ( isset( $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ] ) )
                    $data[ $field[ 'name' ] ] = $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ];
            }
        }

		if ( !$has_fields ) {
			return $term_id;
		}

        if ( $is_new_item ) {
            do_action( 'jet_cct_meta_create_pre_taxonomy', $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy );
            do_action( "jet_cct_meta_create_pre_taxonomy_{$taxonomy}", $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy );
        }

        do_action( 'jet_cct_meta_save_pre_taxonomy', $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy, $is_new_item );
        do_action( "jet_cct_meta_save_pre_taxonomy_{$taxonomy}", $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy, $is_new_item );

        jet_cct_no_conflict_on( 'taxonomy' );

        if ( !empty( $jet ) ) {
            // Fix for jet_cct doing it's own sanitization
            $data = jet_cct_unslash( (array) $data );

            $jet->save( $data, null, null, array( 'is_new_item' => $is_new_item, 'jet_cctmeta' => true ) );
        }

        jet_cct_no_conflict_off( 'taxonomy' );

        if ( $is_new_item ) {
            do_action( 'jet_cct_meta_create_taxonomy', $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy );
            do_action( "jet_cct_meta_create_taxonomy_{$taxonomy}", $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy );
        }

        do_action( 'jet_cct_meta_save_taxonomy', $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy, $is_new_item );
        do_action( "jet_cct_meta_save_taxonomy_{$taxonomy}", $data, $jet, $id, $groups, $term_id, $term_taxonomy_id, $taxonomy, $is_new_item );

		return $term_id;
    }

    /**
     * @param $user_id
     */
    public function meta_user ( $user_id ) {
        wp_enqueue_style( 'jet_cct-form' );

        do_action( 'jet_cct_meta_' . __FUNCTION__, $user_id );

        $groups = $this->groups_get( 'user', 'user' );

        if ( is_object( $user_id ) )
            $user_id = $user_id->ID;

        $id = $user_id;
        $jet = null;

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            $hidden_fields = array();
?>
    <h3><?php echo $group[ 'label' ]; ?></h3>

	<?php echo jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_user' ), 'hidden' ); ?>

    <table class="form-table jet_cct-meta">
        <tbody>
            <?php
                foreach ( $group[ 'fields' ] as $field ) {

                    if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                        if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                            $field[ 'type' ] = 'hidden';
                        else
                            continue;
                    }
                    elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        $field[ 'type' ] = 'hidden';

                    $value = '';

                    if ( !empty( $jet ) )
                        $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );
                    elseif ( !empty( $id ) ) {
                        jet_cct_no_conflict_on( 'user' );

                        $value = get_user_meta( $id, $field[ 'name' ], true );

                        jet_cct_no_conflict_off( 'user' );
                    }

                    if ( 'hidden' == $field[ 'type' ] ) {
                        $hidden_fields[] = array(
                            'field' => $field,
                            'value' => $value
                        );
                    }
                    else {
            ?>
                <tr class="form-field jet_cct-field <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>">
                    <th scope="row" valign="top"><?php echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field ); ?></th>
                    <td>
                        <?php echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id ); ?>
                        <?php echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field ); ?>
                    </td>
                </tr>
            <?php
                    }
                }
            ?>
        </tbody>
    </table>
<?php
            foreach ( $hidden_fields as $hidden_field ) {
                $field_data = $hidden_field[ 'field' ];

                echo jet_cctForm::field( 'jet_cct_meta_' . $field_data[ 'name' ], $hidden_field[ 'value' ], 'hidden', $field_data );
            }
        }

        do_action( 'jet_cct_meta_' . __FUNCTION__ . '_post', $user_id );
    }

	/**
	 * Handle integration with the user_register and profile_update hooks.
	 *
	 * @see wp_insert_user
	 *
	 * @param int         $user_id       User ID.
	 * @param object|null $old_user_data Object containing user's data prior to update.
	 */
	public function save_user( $user_id, $old_user_data = null ) {

		$is_new_item = false;

		if ( 'user_register' == current_filter() ) {
			$is_new_item = true;
		}

		$nonced = wp_verify_nonce( jet_cct_v( 'jet_cct_meta', 'post' ), 'jet_cct_meta_user' );

		if ( ! $is_new_item && false === $nonced ) {
			return;
		}

		if ( is_object( $user_id ) ) {
			$user_id = $user_id->ID;
		}

		$groups = $this->groups_get( 'user', 'user' );

		$id = $user_id;

		if ( ! is_object( self::$current_jet ) || self::$current_jet->jet !== 'user' ) {
			self::$current_jet = jet_cct( 'user', $id, true );
		} elseif ( is_object( self::$current_jet ) && (int) self::$current_jet->id() !== (int) $id ) {
			self::$current_jet->fetch( $id );
		}

		$jet  = self::$current_jet;
		$data = array();

		if ( false !== $nonced && ! empty( $groups ) ) {
			foreach ( $groups as $group ) {
				if ( empty( $group['fields'] ) ) {
					continue;
				}

				foreach ( $group['fields'] as $field ) {
					if ( false === jet_cctForm::permission( $field['type'], $field['name'], $field, $group['fields'], $jet, $id ) ) {
						if ( ! jet_cct_v( 'hidden', $field['options'], false ) ) {
							continue;
						}
					}

					$data[ $field['name'] ] = '';

					if ( isset( $_POST[ 'jet_cct_meta_' . $field['name'] ] ) ) {
						$data[ $field['name'] ] = $_POST[ 'jet_cct_meta_' . $field['name'] ];
					}
				}
			}

			if ( $is_new_item ) {
				do_action( 'jet_cct_meta_create_pre_user', $data, $jet, $id, $groups );
			}

			do_action( 'jet_cct_meta_save_pre_user', $data, $jet, $id, $groups, $is_new_item );
		}

		if ( $is_new_item || false !== $nonced ) {
			jet_cct_no_conflict_on( 'user' );

			if ( ! empty( $jet ) ) {
				// Fix for jet_cct doing it's own sanitizing
				$data = jet_cct_unslash( (array) $data );

				$jet->save( $data, null, null, array( 'is_new_item' => $is_new_item, 'jet_cctmeta' => true ) );
			} elseif ( ! empty( $id ) ) {
				foreach ( $data as $field => $value ) {
					update_user_meta( $id, $field, $value );
				}
			}

			jet_cct_no_conflict_off( 'user' );
		}

		if ( false !== $nonced && ! empty( $groups ) ) {
			if ( $is_new_item ) {
				do_action( 'jet_cct_meta_create_user', $data, $jet, $id, $groups );
			}

			do_action( 'jet_cct_meta_save_user', $data, $jet, $id, $groups, $is_new_item );
		}

	}

    /**
     * @param $commenter
     * @param $user_identity
     */
    public function meta_comment_new_logged_in ( $commenter, $user_identity ) {
        wp_enqueue_style( 'jet_cct-form' );

        do_action( 'jet_cct_meta_' . __FUNCTION__, $commenter, $user_identity );

        $groups = $this->groups_get( 'comment', 'comment' );

        $id = null;
        $jet = null;

		echo jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_comment' ), 'hidden' );

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {
                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        $field[ 'type' ] = 'hidden';
                    else
                        continue;
                }
                elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                    $field[ 'type' ] = 'hidden';

                $value = '';

                if ( !empty( $jet ) )
                    $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );
                elseif ( !empty( $id ) ) {
                    jet_cct_no_conflict_on( 'comment' );

                    $value = get_comment_meta( $id, $field[ 'name' ], true );

                    jet_cct_no_conflict_off( 'comment' );
                }
                ?>
            <p class="comment-form-author comment-form-jet_cct-meta-<?php echo esc_attr( $field[ 'name' ] ); ?>  jet_cct-field" style="<?php echo esc_attr( 'hidden' == $field[ 'type' ] ? 'display:none;' : '' ); ?>">
                <?php
                    echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field );
                    echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id );
                    echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field );
                ?>
            </p>
            <?php
            }
        }

        do_action( 'jet_cct_meta_' . __FUNCTION__ . '_post', $commenter, $user_identity );
    }

    /**
     * @param $form_fields
     *
     * @return array
     */
    public function meta_comment_new ( $form_fields ) {
        wp_enqueue_style( 'jet_cct-form' );

        $groups = $this->groups_get( 'comment', 'comment' );

        $id = null;
        $jet = null;

		$form_fields[ 'jet_cct_meta' ] = jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_comment' ), 'hidden' );

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {

                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        $field[ 'type' ] = 'hidden';
                    else
                        continue;
                }
                elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                    $field[ 'type' ] = 'hidden';

                $value = '';

                if ( !empty( $jet ) )
                    $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );
                elseif ( !empty( $id ) ) {
                    jet_cct_no_conflict_on( 'comment' );

                    $value = get_comment_meta( $id, $field[ 'name' ], true );

                    jet_cct_no_conflict_off( 'comment' );
                }

                ob_start();
                ?>
            <p class="comment-form-author comment-form-jet_cct-meta-<?php echo esc_attr( $field[ 'name' ] ); ?> jet_cct-field" style="<?php echo esc_attr( 'hidden' == $field[ 'type' ] ? 'display:none;' : '' ); ?>">
                <?php
                    echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field );
                    echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id );
                    echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field );
                ?>
            </p>
            <?php
                $form_fields[ 'jet_cct_meta_' . $field[ 'name' ] ] = ob_get_clean();
            }
        }

        $form_fields = apply_filters( 'jet_cct_meta_' . __FUNCTION__, $form_fields );

        return $form_fields;
    }

    /**
     * @param $comment_type
     * @param null $comment
     */
    public function meta_comment_add ( $comment_type, $comment = null ) {
        if ( is_object( $comment ) && isset( $comment_type->comment_type ) )
            $comment_type = $comment->comment_type;

        if ( is_object( $comment_type ) && isset( $comment_type->comment_type ) ) {
            $comment = $comment_type;
            $comment_type = $comment_type->comment_type;
        }

        if ( is_object( $comment_type ) )
            return;
        elseif ( empty( $comment_type ) )
            $comment_type = 'comment';

        $groups = $this->groups_get( 'comment', $comment_type );

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

            $field_found = false;

            foreach ( $group[ 'fields' ] as $field ) {
                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], null, null ) ) {
                    if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) ) {
                        $field_found = true;
                        break;
                    }
                    else {
                        continue;
                    }
                }
                else {
                    $field_found = true;
                    break;
                }
            }

            if ( $field_found ) {
                add_meta_box(
                    'jet_cct-meta-' . sanitize_title( $group[ 'label' ] ),
                    $group[ 'label' ],
                    array( $this, 'meta_comment' ),
                    $comment_type,
                    $group[ 'context' ],
                    $group[ 'priority' ],
                    array( 'group' => $group )
                );
            }
        }
    }

    /**
     * @param $comment
     * @param $metabox
     */
    public function meta_comment ( $comment, $metabox ) {
        wp_enqueue_style( 'jet_cct-form' );

        do_action( 'jet_cct_meta_' . __FUNCTION__, $comment, $metabox );

        $hidden_fields = array();

		echo jet_cctForm::field( 'jet_cct_meta', wp_create_nonce( 'jet_cct_meta_comment' ), 'hidden' );
?>
    <table class="form-table editcomment jet_cct-metabox">
        <?php
            $id = null;

            if ( is_object( $comment ) )
                $id = $comment->comment_ID;

            if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $metabox[ 'args' ][ 'group' ][ 'jet' ][ 'name' ] )
                self::$current_jet = jet_cct( $metabox[ 'args' ][ 'group' ][ 'jet' ][ 'name' ], $id, true );
			elseif ( self::$current_jet->id() != $id )
				self::$current_jet->fetch( $id );

            $jet = self::$current_jet;

            foreach ( $metabox[ 'args' ][ 'group' ][ 'fields' ] as $field ) {
                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $metabox[ 'args' ][ 'group' ][ 'fields' ], $jet, $id ) ) {
                    if ( jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        $field[ 'type' ] = 'hidden';
                    else
                        continue;
                }
                elseif ( !jet_cct_has_permissions( $field[ 'options' ] ) && jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                    $field[ 'type' ] = 'hidden';

                $value = '';

                if ( !empty( $jet ) )
                    $value = $jet->field( array( 'name' => $field[ 'name' ], 'in_form' => true ) );

                if ( 'hidden' == $field[ 'type' ] ) {
                    $hidden_fields[] = array(
                        'field' => $field,
                        'value' => $value
                    );
                }
                else {
        ?>
            <tr class="form-field jet_cct-field <?php echo esc_attr( 'jet_cct-form-ui-row-type-' . $field[ 'type' ] . ' jet_cct-form-ui-row-name-' . jet_cctForm::clean( $field[ 'name' ], true ) ); ?>">
                <th scope="row" valign="top"><?php echo jet_cctForm::label( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'label' ], $field[ 'help' ], $field ); ?></th>
                <td>
                    <?php echo jet_cctForm::field( 'jet_cct_meta_' . $field[ 'name' ], $value, $field[ 'type' ], $field, $jet, $id ); ?>
                    <?php echo jet_cctForm::comment( 'jet_cct_meta_' . $field[ 'name' ], $field[ 'description' ], $field ); ?>
                </td>
            </tr>
        <?php
                }
            }
        ?>
    </table>
<?php
        foreach ( $hidden_fields as $hidden_field ) {
            $field_data = $hidden_field[ 'field' ];

            echo jet_cctForm::field( 'jet_cct_meta_' . $field_data[ 'name' ], $hidden_field[ 'value' ], 'hidden', $field_data );
        }

        do_action( 'jet_cct_meta_' . __FUNCTION__ . '_post', $comment, $metabox );
    }

    /**
     * @param $approved
     * @param $commentdata
     */
    public function validate_comment ( $approved, $commentdata ) {
        $groups = $this->groups_get( 'comment', 'comment' );

        if ( empty( $groups ) )
            return $approved;

        $data = array();

        $jet = null;
        $id = null;

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {

                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( !jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        continue;
                }

                $data[ $field[ 'name' ] ] = '';

                if ( isset( $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ] ) )
                    $data[ $field[ 'name' ] ] = $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ];

                $validate = jet_cct_api()->handle_field_validation( $data[ $field[ 'name' ] ], $field[ 'name' ], jet_cct_api()->get_wp_object_fields( 'comment' ), $jet->fields(), $jet, array() );

                if ( false === $validate )
                    $validate = sprintf( __( 'There was an issue validating the field %s', 'jet_cct' ), $field[ 'label' ] );

                if ( !is_bool( $validate ) && !empty( $validate ) )
                    return jet_cct_error( $validate, $this );
            }
        }

        return $approved;
    }

    /**
     * @param $comment_id
     */
    public function save_comment ( $comment_id ) {
        $groups = $this->groups_get( 'comment', 'comment' );

        if ( empty( $groups ) ) {
            return $comment_id;
		}
		elseif ( empty( $_POST ) ) {
			return $comment_id;
		}
		elseif ( !wp_verify_nonce( jet_cct_v( 'jet_cct_meta', 'post' ), 'jet_cct_meta_comment' ) ) {
			return $comment_id;
		}

        $data = array();

        $id = $comment_id;
        $jet = null;

        foreach ( $groups as $group ) {
            if ( empty( $group[ 'fields' ] ) )
                continue;

			if ( null === $jet || ( is_object( $jet ) && $jet->id() != $id ) ) {
				if ( !is_object( self::$current_jet ) || self::$current_jet->jet != $group[ 'jet' ][ 'name' ] )
					self::$current_jet = jet_cct( $group[ 'jet' ][ 'name' ], $id, true );
				elseif ( self::$current_jet->id() != $id )
					self::$current_jet->fetch( $id );

				$jet = self::$current_jet;
			}

            foreach ( $group[ 'fields' ] as $field ) {
                if ( false === jet_cctForm::permission( $field[ 'type' ], $field[ 'name' ], $field, $group[ 'fields' ], $jet, $id ) ) {
                    if ( !jet_cct_var( 'hidden', $field[ 'options' ], false ) )
                        continue;
                }

                $data[ $field[ 'name' ] ] = '';

                if ( isset( $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ] ) )
                    $data[ $field[ 'name' ] ] = $_POST[ 'jet_cct_meta_' . $field[ 'name' ] ];
            }
        }

        do_action( 'jet_cct_meta_save_pre_comment', $data, $jet, $id, $groups );

        if ( !empty( $jet ) ) {
            // Fix for jet_cct doing it's own sanitization
            $data = jet_cct_unslash( (array) $data );

            $jet->save( $data, null, null, array( 'jet_cctmeta' => true ) );
        }
        elseif ( !empty( $id ) ) {
            jet_cct_no_conflict_on( 'comment' );

            foreach ( $data as $field => $value ) {
                update_comment_meta( $id, $field, $value );
            }

            jet_cct_no_conflict_off( 'comment' );
        }

        do_action( 'jet_cct_meta_save_comment', $data, $jet, $id, $groups );

        return $comment_id;
    }

    /**
     * All *_*_meta filter handler aliases
     *
     * @return mixed
     */
    public function get_post_meta () {
        $args = func_get_args();

        array_unshift( $args, 'post_type' );

        $_null = apply_filters( 'jet_cct_meta_get_post_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'get_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function get_user_meta () {
        $args = func_get_args();

        array_unshift( $args, 'user' );

        $_null = apply_filters( 'jet_cct_meta_get_user_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'get_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function get_comment_meta () {
        $args = func_get_args();

        array_unshift( $args, 'comment' );

        $_null = apply_filters( 'jet_cct_meta_get_comment_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'get_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function get_term_meta () {
        $args = func_get_args();

        array_unshift( $args, 'term' );

        $_null = apply_filters( 'jet_cct_meta_get_term_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'get_meta' ), $args );
    }

    /**
     * All *_*_meta filter handler aliases
     *
     * @return mixed
     */
    public function get_option () {
        $args = func_get_args();

        array_unshift( $args, 'settings' );

        $_null = apply_filters( 'jet_cct_meta_get_option', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'get_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function add_post_meta () {
        $args = func_get_args();

        array_unshift( $args, 'post_type' );

        $_null = apply_filters( 'jet_cct_meta_add_post_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'add_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function add_user_meta () {
        $args = func_get_args();

        array_unshift( $args, 'user' );

        $_null = apply_filters( 'jet_cct_meta_add_user_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'add_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function add_comment_meta () {
        $args = func_get_args();

        array_unshift( $args, 'comment' );

        $_null = apply_filters( 'jet_cct_meta_add_comment_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'add_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function add_term_meta () {
        $args = func_get_args();

        array_unshift( $args, 'term' );

        $_null = apply_filters( 'jet_cct_meta_add_term_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'add_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function add_option () {
        $args = func_get_args();

        array_unshift( $args, 'settings' );

        $_null = apply_filters( 'jet_cct_meta_add_option', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'add_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function update_post_meta () {
        $args = func_get_args();

        array_unshift( $args, 'post_type' );

        $_null = apply_filters( 'jet_cct_meta_update_post_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'update_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function update_user_meta () {
        $args = func_get_args();

        array_unshift( $args, 'user' );

        $_null = apply_filters( 'jet_cct_meta_update_user_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'update_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function update_comment_meta () {
        $args = func_get_args();

        array_unshift( $args, 'comment' );

        $_null = apply_filters( 'jet_cct_meta_update_comment_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'update_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function update_term_meta () {
        $args = func_get_args();

        array_unshift( $args, 'term' );

        $_null = apply_filters( 'jet_cct_meta_update_term_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'update_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function update_option () {
        $args = func_get_args();

        array_unshift( $args, 'settings' );

        $_null = apply_filters( 'jet_cct_meta_update_option', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'update_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function delete_post_meta () {
        $args = func_get_args();

        array_unshift( $args, 'post_type' );

        $_null = apply_filters( 'jet_cct_meta_delete_post_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'delete_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function delete_user_meta () {
        $args = func_get_args();

        array_unshift( $args, 'user' );

        $_null = apply_filters( 'jet_cct_meta_delete_user_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'delete_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function delete_comment_meta () {
        $args = func_get_args();

        array_unshift( $args, 'comment' );

        $_null = apply_filters( 'jet_cct_meta_delete_comment_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'delete_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function delete_term_meta () {
        $args = func_get_args();

        array_unshift( $args, 'term' );

        $_null = apply_filters( 'jet_cct_meta_delete_term_meta', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'delete_meta' ), $args );
    }

    /**
     * @return mixed
     */
    public function delete_option () {
        $args = func_get_args();

        array_unshift( $args, 'settings' );

        $_null = apply_filters( 'jet_cct_meta_delete_option', null, $args );

        if ( null !== $_null )
            return $_null;

        return call_user_func_array( array( $this, 'delete_meta' ), $args );
    }

    /*
     * The real meta functions
     */
    /**
     * @param $object_type
     * @param $object_id
     * @param string $aux
     *
     * @return bool|mixed
     */
    public function get_object ( $object_type, $object_id, $aux = '' ) {

    	global $wpdb;

    	if ( 'term' == $object_type ) {
    		$object_type = 'taxonomy';
    	}

        if ( 'post_type' == $object_type )
            $objects = self::$post_types;
        elseif ( 'taxonomy' == $object_type )
            $objects = self::$taxonomies;
        elseif ( 'media' == $object_type )
            $objects = self::$media;
        elseif ( 'user' == $object_type )
            $objects = self::$user;
        elseif ( 'comment' == $object_type )
            $objects = self::$comment;
        elseif ( 'settings' == $object_type )
            $objects = self::$settings;
        else
            return false;

        if ( empty( $objects ) || !is_array( $objects ) )
            return false;

        $object_name = null;

        if ( 'media' == $object_type )
            return @current( $objects );
        elseif ( 'user' == $object_type )
            return @current( $objects );
        elseif ( 'comment' == $object_type )
            return @current( $objects );
        elseif ( 'post_type' == $object_type ) {
            $object = get_post( $object_id );

            if ( !is_object( $object ) || !isset( $object->post_type ) )
                return false;

            $object_name = $object->post_type;
        }
        elseif ( 'taxonomy' == $object_type ) {
            if ( jet_cct_version_check( 'wp', '4.4' ) ) {
            	$object = get_term( $object_id );

            	if ( !is_object( $object ) || !isset( $object->taxonomy ) )
                	return false;

            	$object_name = $object->taxonomy;
            } elseif ( empty( $aux ) ) {
            	$object_name = $wpdb->get_var( $wpdb->prepare( "SELECT `taxonomy` FROM `{$wpdb->term_taxonomy}` WHERE `term_id` = %d", $object_id ) );
            } else {
            	$object_name = $aux;
            }
        }
        elseif ( 'settings' == $object_type )
            $object = $object_id;
        else
            return false;

        $reserved_post_types = array(
			'revision'
        );

        $reserved_post_types = apply_filters( 'jet_cct_meta_reserved_post_types', $reserved_post_types, $object_type, $object_id, $object_name, $objects );

        if ( empty( $object_name ) || ( 'post_type' == $object_type && ( 0 === strpos( $object_name, '_jet_cct_' ) ) || in_array( $object_name, $reserved_post_types ) ) ) {
            return false;
		}
		elseif ( 'attachment' == $object_name ) {
			return @current( self::$media );
		}

        $recheck = array();

        // Return first created by jet_cct, save extended for later
        foreach ( $objects as $jet ) {
            if ( $object_name == $jet[ 'object' ] )
                $recheck[] = $jet;

            if ( '' == $jet[ 'object' ] && $object_name == $jet[ 'name' ] )
                return $jet;
        }

        // If no objects created by jet_cct, return first extended
        foreach ( $recheck as $jet ) {
            return $jet;
        }

        return false;
    }

    /**
     * @param $object_type
     * @param null $_null
     * @param int $object_id
     * @param string $meta_key
     * @param bool $single
     *
     * @return array|bool|int|mixed|null|string|void
     */
    public function get_meta ( $object_type, $_null = null, $object_id = 0, $meta_key = '', $single = false ) {
		// Enforce boolean as it can be a string sometimes
		$single = filter_var( $single, FILTER_VALIDATE_BOOLEAN );

        $meta_type = $object_type;

        if ( in_array( $meta_type, array( 'post_type', 'media' ) ) )
            $meta_type = 'post';
        elseif ( 'taxonomy' == $meta_type )
            $meta_type = 'term';

        if ( empty( $meta_key ) ) {
			if ( !defined( 'jet_cct_ALLOW_FULL_META' ) || !jet_cct_ALLOW_FULL_META ) {
				return $_null; // don't cover get_post_meta( $id )
			}

			$single = false;
		}

        $object = $this->get_object( $object_type, $object_id );

        if ( empty( $object_id ) || empty( $object ) )
            return $_null;

        $no_conflict = jet_cct_no_conflict_check( $meta_type );

        if ( !$no_conflict )
            jet_cct_no_conflict_on( $meta_type );

        $meta_cache = array();

        if ( !$single && isset( $GLOBALS[ 'wp_object_cache' ] ) && is_object( $GLOBALS[ 'wp_object_cache' ] ) ) {
            $meta_cache = wp_cache_get( $object_id, 'jet_cct_' . $meta_type . '_meta' );

            if ( empty( $meta_cache ) ) {
                $meta_cache = wp_cache_get( $object_id, $meta_type . '_meta' );

                if ( empty( $meta_cache ) ) {
                    $meta_cache = update_meta_cache( $meta_type, array( $object_id ) );
                    $meta_cache = $meta_cache[ $object_id ];
                }
            }
        }

        if ( empty( $meta_cache ) || !is_array( $meta_cache ) )
            $meta_cache = array();

        if ( !is_object( self::$current_field_jet ) || self::$current_field_jet->jet != $object[ 'name' ] )
            self::$current_field_jet = jet_cct( $object[ 'name' ], $object_id );
		elseif ( self::$current_field_jet->id() != $object_id )
			self::$current_field_jet->fetch( $object_id );

        $jet = self::$current_field_jet;

        $meta_keys = array( $meta_key );

        if ( empty( $meta_key ) )
            $meta_keys = array_keys( $meta_cache );

        $key_found = false;

        foreach ( $meta_keys as $meta_k ) {
            if ( !empty( $jet ) ) {
                if ( isset( $jet->fields[ $meta_k ] ) ) {
                    $key_found = true;

                    $meta_cache[ $meta_k ] = $jet->field( array( 'name' => $meta_k, 'single' => $single, 'get_meta' => true ) );

                    if ( ( !is_array( $meta_cache[ $meta_k ] ) || !isset( $meta_cache[ $meta_k ][ 0 ] ) ) ) {
                        if ( empty( $meta_cache[ $meta_k ] ) && !is_array( $meta_cache[ $meta_k ] ) && $single )
                            $meta_cache[ $meta_k ] = array();
                        else
                            $meta_cache[ $meta_k ] = array( $meta_cache[ $meta_k ] );
                    }

                    if ( in_array( $jet->fields[ $meta_k ][ 'type' ], jet_cctForm::tableless_field_types() ) && isset( $meta_cache[ '_jet_cct_' . $meta_k ] ) )
                        unset( $meta_cache[ '_jet_cct_' . $meta_k ] );
                }
                elseif ( false !== strpos( $meta_k, '.' ) ) {
                    $key_found = true;

                    $first = current( explode( '.', $meta_k ) );

                    if ( isset( $jet->fields[ $first ] ) ) {
                        $meta_cache[ $meta_k ] = $jet->field( array( 'name' => $meta_k, 'single' => $single, 'get_meta' => true ) );

                        if ( ( !is_array( $meta_cache[ $meta_k ] ) || !isset( $meta_cache[ $meta_k ][ 0 ] ) ) && $single ) {
                            if ( empty( $meta_cache[ $meta_k ] ) && !is_array( $meta_cache[ $meta_k ] ) && $single )
                                $meta_cache[ $meta_k ] = array();
                            else
                                $meta_cache[ $meta_k ] = array( $meta_cache[ $meta_k ] );
                        }

                        if ( in_array( $jet->fields[ $first ][ 'type' ], jet_cctForm::tableless_field_types() ) && isset( $meta_cache[ '_jet_cct_' . $first ] ) )
                            unset( $meta_cache[ '_jet_cct_' . $first ] );
                    }
                }
            }
        }

        if ( !$no_conflict )
            jet_cct_no_conflict_off( $meta_type );

        unset( $jet ); // memory clear

        if ( !$key_found )
            return $_null;

        if ( !$single && isset( $GLOBALS[ 'wp_object_cache' ] ) && is_object( $GLOBALS[ 'wp_object_cache' ] ) )
            wp_cache_set( $object_id, $meta_cache, 'jet_cct_' . $meta_type . '_meta' );

        if ( empty( $meta_key ) )
            return $meta_cache;
        elseif ( isset( $meta_cache[ $meta_key ] ) )
            $value = $meta_cache[ $meta_key ];
        else
            $value = '';

        if ( !is_numeric( $value ) && empty( $value ) ) {
            if ( $single )
                $value = '';
            else
                $value = array();
        }
        // get_metadata requires $meta[ 0 ] to be set for first value to be retrieved
        elseif ( !is_array( $value ) )
            $value = array( $value );

        return $value;
    }

    /**
     * @param $object_type
     * @param null $_null
     * @param int $object_id
     * @param string $meta_key
     * @param string $meta_value
     * @param bool $unique
     *
     * @return bool|int|null
     */
    public function add_meta ( $object_type, $_null = null, $object_id = 0, $meta_key = '', $meta_value = '', $unique = false ) {
        if ( jet_cct_tableless() )
            return $_null;

        $object = $this->get_object( $object_type, $object_id );

        if ( empty( $object_id ) || empty( $object ) || !isset( $object[ 'fields' ][ $meta_key ] ) )
            return $_null;

        if ( in_array( $object[ 'fields' ][ $meta_key ][ 'type' ], jet_cctForm::tableless_field_types() ) ) {
            if ( !is_object( self::$current_field_jet ) || self::$current_field_jet->jet != $object[ 'name' ] )
                self::$current_field_jet = jet_cct( $object[ 'name' ], $object_id );
			elseif ( self::$current_field_jet->id() != $object_id )
				self::$current_field_jet->fetch( $object_id );

            $jet = self::$current_field_jet;

            $jet->add_to( $meta_key, $meta_value );
        }
        else {
            if ( !is_object( self::$current_field_jet ) || self::$current_field_jet->jet != $object[ 'name' ] )
                self::$current_field_jet = jet_cct( $object[ 'name' ] );

            $jet = self::$current_field_jet;

            $jet->save( $meta_key, $meta_value, $object_id, array( 'jet_cctmeta_direct' => true, 'error_mode' => 'false' ) );
        }

        return $object_id;
    }

    /**
     * @param $object_type
     * @param null $_null
     * @param int $object_id
     * @param string $meta_key
     * @param string $meta_value
     * @param string $prev_value
     *
     * @return bool|int|null
     */
    public function update_meta ( $object_type, $_null = null, $object_id = 0, $meta_key = '', $meta_value = '', $prev_value = '' ) {
        if ( jet_cct_tableless() )
            return $_null;

        $object = $this->get_object( $object_type, $object_id );

        if ( empty( $object_id ) || empty( $object ) || !isset( $object[ 'fields' ][ $meta_key ] ) )
            return $_null;

        if ( !is_object( self::$current_field_jet ) || self::$current_field_jet->jet != $object[ 'name' ] )
            self::$current_field_jet = jet_cct( $object[ 'name' ] );

        $jet = self::$current_field_jet;

        if ( ( isset( $jet->fields[ $meta_key ] ) || false !== strpos( $meta_key, '.' ) ) && $jet->row !== null) {

            $key = $meta_key;
            if(false !== strpos( $meta_key, '.' )){
                $key = current( explode( '.', $meta_key ) );
            }

            $jet->row[ $meta_key ] = $meta_value;

            if ( isset( $jet->fields[ $key ] ) ) {
                if ( in_array( $jet->fields[ $key ][ 'type' ], jet_cctForm::tableless_field_types() ) && isset( $meta_cache[ '_jet_cct_' . $key ] ) )
                    unset( $meta_cache[ '_jet_cct_' . $key ] );
            }

        }

        $jet->save( $meta_key, $meta_value, $object_id, array( 'jet_cctmeta_direct' => true, 'error_mode' => 'false' ) );

        return $object_id;
    }

    /**
     * @param $object_type
     * @param null $_null
     * @param int $object_id
     * @param string $meta_key
     * @param string $meta_value
     * @param bool $delete_all
     *
     * @return null
     */
    public function delete_meta ( $object_type, $_null = null, $object_id = 0, $meta_key = '', $meta_value = '', $delete_all = false ) {
        if ( jet_cct_tableless() )
            return $_null;

        $object = $this->get_object( $object_type, $object_id );

        if ( empty( $object_id ) || empty( $object ) || !isset( $object[ 'fields' ][ $meta_key ] ) )
            return $_null;

        // @todo handle $delete_all (delete the field values from all jet items)
        if ( !empty( $meta_value ) && in_array( $object[ 'fields' ][ $meta_key ][ 'type' ], jet_cctForm::tableless_field_types() ) ) {
            if ( !is_object( self::$current_field_jet ) || self::$current_field_jet->jet != $object[ 'name' ] )
                self::$current_field_jet = jet_cct( $object[ 'name' ], $object_id );
			elseif ( self::$current_field_jet->id() != $object_id )
				self::$current_field_jet->fetch( $object_id );

            $jet = self::$current_field_jet;

            $jet->remove_from( $meta_key, $meta_value );
        }
        else {
            if ( !is_object( self::$current_field_jet ) || self::$current_field_jet->jet != $object[ 'name' ] )
                self::$current_field_jet = jet_cct( $object[ 'name' ] );

            $jet = self::$current_field_jet;

            $jet->save( array( $meta_key => null ), null, $object_id, array( 'jet_cctmeta_direct' => true, 'error_mode' => 'false' ) );
        }

        return $_null;
    }

    public function delete_post ( $id ) {
        $post = get_post( $id );

        if ( empty( $post ) )
            return;

        $id = $post->ID;
        $post_type = $post->post_type;

        return $this->delete_object( 'post_type', $id, $post_type );
    }

    public function delete_taxonomy ( $id ) {
        /**
         * @var $wpdb WPDB
         */
        global $wpdb;

        $terms = $wpdb->get_results( "SELECT `term_id`, `taxonomy` FROM `{$wpdb->term_taxonomy}` WHERE `term_taxonomy_id` = {$id}" );

        if ( empty( $terms ) )
            return;

        foreach ( $terms as $term ) {
            $id = $term->term_id;
            $taxonomy = $term->taxonomy;

            $this->delete_object( 'taxonomy', $id, $taxonomy );
        }
    }

    /**
     * Hook the split_shared_term action and point it to this method
     *
     * Fires after a previously shared taxonomy term is split into two separate terms.
     *
     * @param int    $term_id          ID of the formerly shared term.
     * @param int    $new_term_id      ID of the new term created for the $term_taxonomy_id.
     * @param int    $term_taxonomy_id ID for the term_taxonomy row affected by the split.
     * @param string $taxonomy         Taxonomy for the split term.
     */
    public static function split_shared_term( $term_id, $new_term_id, $term_taxonomy_id, $taxonomy ) {

        require_once( jet_cct_DIR . 'classes/jet_cctTermSplitting.php' );

        $term_splitting = new jet_cct_Term_Splitting( $term_id, $new_term_id, $taxonomy );
        $term_splitting->split_shared_term();

    }

    public function delete_user ( $id ) {
        return $this->delete_object( 'user', $id );
    }

    public function delete_comment ( $id ) {
        return $this->delete_object( 'comment', $id );
    }

    public function delete_media ( $id ) {
        return $this->delete_object( 'media', $id );
    }

    public function delete_object ( $type, $id, $name = null ) {
        if ( empty( $name ) )
            $name = $type;

        $object = $this->object_get( $type, $name );

        if ( !empty( $object ) ) {
            $params = array(
                'jet' => jet_cct_var( 'name', $object ),
                'jet_id' => jet_cct_var( 'id', $object ),
                'id' => $id
            );

            return jet_cct_api()->delete_jet_item( $params, false );
        }
        else
            return jet_cct_api()->delete_object_from_relationships( $id, $type, $name );
    }
}
