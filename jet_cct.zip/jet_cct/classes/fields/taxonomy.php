<?php
require_once( jet_cct_DIR . 'classes/fields/pick.php' );

/**
 * @package jet_cct\Fields
 */
class jet_cctField_Taxonomy extends jet_cctField_Pick {

    /**
     * Setup related objects list
     *
     * @since 2.0
     */
    public function __construct () {
	    parent::__construct();
		// this field type just maps to the relationship field
    }

}
