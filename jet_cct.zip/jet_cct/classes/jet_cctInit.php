<?php
/**
 * @package jet_cct
 */
class jet_cctInit {

	/**
	 * @var jet_cctInit
	 */
	static $instance = null;

	/**
	 * @var array
	 */
	static $no_conflict = array();

	/**
	 * @var array
	 */
	static $content_types_registered = array();

	/**
	 * @var jet_cctComponents
	 */
	static $components;

	/**
	 * @var jet_cctMeta
	 */
	static $meta;

	/**
	 * @var jet_cctAdmin
	 */
	static $admin;

	/**
	 * @var mixed|void
	 */
	static $version;

	/**
	 * @var mixed|void
	 */
	static $version_last;

	/**
	 * @var mixed|void
	 */
	static $db_version;

	/**
	 * Upgrades to trigger (last installed version => upgrade version)
	 *
	 * @var array
	 */
	static $upgrades = array(
		'1.0.0' => '2.0.0'
		//'2.0.0' => '2.1.0'
	);

	/**
	 * Whether an Upgrade for 1.x has happened
	 *
	 * @var bool
	 */
	static $upgraded;

	/**
	 * Whether an Upgrade is needed
	 *
	 * @var bool
	 */
	static $upgrade_needed = false;

	/**
	 * Singleton handling for a basic jet_cct_init() request
	 *
	 * @return \jet_cctInit
	 *
	 * @since 2.3.5
	 */
	public static function init() {

		if ( ! is_object( self::$instance ) ) {
			self::$instance = new jet_cctInit();
		}

		return self::$instance;
	}

	/**
	 * Setup and Initiate jet_cct
	 *
	 * @return \jet_cctInit
	 *
	 * @license http://www.gnu.org/licenses/gpl-2.0.html
	 * @since   1.8.9
	 */
	function __construct() {

		self::$version      = get_option( 'jet_cct_framework_version' );
		self::$version_last = get_option( 'jet_cct_framework_version_last' );
		self::$db_version   = get_option( 'jet_cct_framework_db_version' );
		self::$upgraded     = (int) get_option( 'jet_cct_framework_upgraded_1_x' );

		if ( empty( self::$version_last ) && 0 < strlen( get_option( 'jet_cct_version' ) ) ) {
			$old_version = get_option( 'jet_cct_version' );

			if ( ! empty( $old_version ) ) {
				if ( false === strpos( $old_version, '.' ) ) {
					$old_version = jet_cct_version_to_point( $old_version );
				}

				update_option( 'jet_cct_framework_version_last', $old_version );

				self::$version_last = $old_version;
			}
		}

		self::$upgrade_needed = $this->needs_upgrade();

		add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ) );
		add_action( 'plugins_loaded', array( $this, 'activate_install' ), 9 );

		add_action( 'wp_loaded', array( $this, 'flush_rewrite_rules' ) );

		$this->run();

	}

	/**
	 * Load the plugin textdomain and set default constants
	 */
	public function plugins_loaded() {

		if ( ! defined( 'jet_cct_LIGHT' ) ) {
			define( 'jet_cct_LIGHT', false );
		}

		if ( ! defined( 'jet_cct_TABLELESS' ) ) {
			define( 'jet_cct_TABLELESS', false );
		}

		load_plugin_textdomain( 'jet_cct' );

	}

	/**
	 * Load jet_cct Components
	 */
	public function load_components() {

		if ( empty( self::$version ) ) {
			return;
		}

		if ( ! defined( 'jet_cct_LIGHT' ) || ! jet_cct_LIGHT ) {
			self::$components = jet_cct_components();
		}

	}

	/**
	 * Load jet_cct Meta
	 */
	public function load_meta() {

		self::$meta = jet_cct_meta()->core();
	}

	/**
	 * Set up the jet_cct core
	 */
	public function core() {

		if ( empty( self::$version ) ) {
			return;
		}

		// Session start
		jet_cct_session_start();

		add_shortcode( 'jet_cct', 'jet_cct_shortcode' );
		add_shortcode( 'jet_cct-form', 'jet_cct_shortcode_form' );

		$security_settings = array(
			'jet_cct_disable_file_browser'     => 0,
			'jet_cct_files_require_login'      => 1,
			'jet_cct_files_require_login_cap'  => '',
			'jet_cct_disable_file_upload'      => 0,
			'jet_cct_upload_require_login'     => 1,
			'jet_cct_upload_require_login_cap' => ''
		);

		foreach ( $security_settings as $security_setting => $setting ) {
			$setting = get_option( $security_setting );
			if ( ! empty( $setting ) ) {
				$security_settings[ $security_setting ] = $setting;
			}
		}

		foreach ( $security_settings as $security_setting => $setting ) {
			if ( 0 == $setting ) {
				$setting = false;
			} elseif ( 1 == $setting ) {
				$setting = true;
			}

			if ( in_array( $security_setting, array( 'jet_cct_files_require_login', 'jet_cct_upload_require_login' ) ) ) {
				if ( 0 < strlen( $security_settings[ $security_setting . '_cap' ] ) ) {
					$setting = $security_settings[ $security_setting . '_cap' ];
				}
			} elseif ( in_array( $security_setting, array(
				'jet_cct_files_require_login_cap',
				'jet_cct_upload_require_login_cap'
			) ) ) {
				continue;
			}

			if ( ! defined( strtoupper( $security_setting ) ) ) {
				define( strtoupper( $security_setting ), $setting );
			}
		}

		$this->register_jet_cct();

		$avatar = jet_cctForm::field_loader( 'avatar' );

		if ( method_exists( $avatar, 'get_avatar' ) ) {
			add_filter( 'get_avatar', array( $avatar, 'get_avatar' ), 10, 4 );
		}
	}

	/**
	 * Register Scripts and Styles
	 */
	public function register_assets() {

		if ( ! wp_style_is( 'jquery-ui', 'registered' ) ) {
			wp_register_style( 'jquery-ui', jet_cct_URL . 'ui/css/smoothness/jquery-ui.custom.css', array(), '1.8.16' );
		}

		wp_register_script( 'jet_cct-json', jet_cct_URL . 'ui/js/jquery.json.js', array( 'jquery' ), '2.3' );

		if ( ! wp_style_is( 'jquery-qtip2', 'registered' ) ) {
			wp_register_style( 'jquery-qtip2', jet_cct_URL . 'ui/css/jquery.qtip.min.css', array(), '2.2' );
		}

		if ( ! wp_script_is( 'jquery-qtip2', 'registered' ) ) {
			wp_register_script( 'jquery-qtip2', jet_cct_URL . 'ui/js/jquery.qtip.min.js', array( 'jquery' ), '2.2' );
		}

		wp_register_script( 'jet_cct', jet_cct_URL . 'ui/js/jquery.jet_cct.js', array(
			'jquery',
			'jet_cct-json',
			'jquery-qtip2'
		), jet_cct_VERSION );

		wp_register_style( 'jet_cct-form', jet_cct_URL . 'ui/css/jet_cct-form.css', array(), jet_cct_VERSION );

		wp_register_style( 'jet_cct-cleditor', jet_cct_URL . 'ui/css/jquery.cleditor.css', array(), '1.3.0' );
		wp_register_script( 'jet_cct-cleditor', jet_cct_URL . 'ui/js/jquery.cleditor.min.js', array( 'jquery' ), '1.3.0' );

		wp_register_style( 'jet_cct-codemirror', jet_cct_URL . 'ui/css/codemirror.css', array(), '4.8' );
		wp_register_script( 'jet_cct-codemirror', jet_cct_URL . 'ui/js/codemirror.js', array(), '4.8', true );
		wp_register_script( 'jet_cct-codemirror-loadmode', jet_cct_URL . 'ui/js/codemirror/addon/mode/loadmode.js', array( 'jet_cct-codemirror' ), '4.8', true );
		wp_register_script( 'jet_cct-codemirror-overlay', jet_cct_URL . 'ui/js/codemirror/addon/mode/overlay.js', array( 'jet_cct-codemirror' ), '4.8', true );
		wp_register_script( 'jet_cct-codemirror-hints', jet_cct_URL . 'ui/js/codemirror/addon/mode/show-hint.js', array( 'jet_cct-codemirror' ), '4.8', true );
		wp_register_script( 'jet_cct-codemirror-mode-xml', jet_cct_URL . 'ui/js/codemirror/mode/xml/xml.js', array( 'jet_cct-codemirror' ), '4.8', true );
		wp_register_script( 'jet_cct-codemirror-mode-html', jet_cct_URL . 'ui/js/codemirror/mode/htmlmixed/htmlmixed.js', array( 'jet_cct-codemirror' ), '4.8', true );
		wp_register_script( 'jet_cct-codemirror-mode-css', jet_cct_URL . 'ui/js/codemirror/mode/css/css.js', array( 'jet_cct-codemirror' ), '4.8', true );

		if ( ! wp_style_is( 'jquery-ui-timepicker', 'registered' ) ) {
			wp_register_style( 'jquery-ui-timepicker', jet_cct_URL . 'ui/css/jquery.ui.timepicker.css', array(), '1.1.1' );
		}

		if ( ! wp_script_is( 'jquery-ui-timepicker', 'registered' ) ) {
			wp_register_script( 'jquery-ui-timepicker', jet_cct_URL . 'ui/js/jquery.ui.timepicker.min.js', array(
				'jquery',
				'jquery-ui-core',
				'jquery-ui-datepicker',
				'jquery-ui-slider'
			), '1.1.1' );
		}

		wp_register_style( 'jet_cct-attach', jet_cct_URL . 'ui/css/jquery.jet_cct.attach.css', array(), jet_cct_VERSION );
		wp_register_script( 'jet_cct-attach', jet_cct_URL . 'ui/js/jquery.jet_cct.attach.js', array(), jet_cct_VERSION );

		wp_register_style( 'jet_cct-select2', jet_cct_URL . 'ui/js/select2/select2.css', array(), '3.3.1' );
		wp_register_script( 'jet_cct-select2', jet_cct_URL . 'ui/js/select2/select2.min.js', array( 'jquery' ), '3.3.1' );

		$register_handlebars = apply_filters( 'jet_cct_script_register_handlebars', true );

		if ( is_admin() ) {
			$screen = get_current_screen();

			// Deregister the outdated jet_cct handlebars script on TEC event screen
			if ( $screen && 'tribe_events' === $screen->post_type ) {
				$register_handlebars = false;
			}
		}

		if ( $register_handlebars ) {
			wp_register_script( 'jet_cct-handlebars', jet_cct_URL . 'ui/js/handlebars.js', array(), '1.0.0.beta.6' );
		}

	}

	/**
	 * Register internal Post Types
	 */
	public function register_jet_cct() {

		$args = array(
			'label'           => 'jet_cct',
			'labels'          => array( 'singular_name' => 'jet' ),
			'public'          => false,
			'can_export'      => false,
			'query_var'       => false,
			'rewrite'         => false,
			'capability_type' => 'jet_cct_jet',
			'has_archive'     => false,
			'hierarchical'    => false,
			'supports'        => array( 'title', 'author' ),
			'menu_icon'       => 'dashicons-jet_cct'
		);

		$args = self::object_label_fix( $args, 'post_type' );

		register_post_type( '_jet_cct_jet', apply_filters( 'jet_cct_internal_register_post_type_jet', $args ) );

		$args = array(
			'label'           => 'jet Fields',
			'labels'          => array( 'singular_name' => 'jet Field' ),
			'public'          => false,
			'can_export'      => false,
			'query_var'       => false,
			'rewrite'         => false,
			'capability_type' => 'jet_cct_jet',
			'has_archive'     => false,
			'hierarchical'    => true,
			'supports'        => array( 'title', 'editor', 'author' ),
			'menu_icon'       => 'dashicons-jet_cct'
		);

		$args = self::object_label_fix( $args, 'post_type' );

		register_post_type( '_jet_cct_field', apply_filters( 'jet_cct_internal_register_post_type_field', $args ) );
	}

	/**
	 * Include Admin
	 */
	public function admin_init() {

		self::$admin = jet_cct_admin();
	}

	/**
	 * Register Post Types and Taxonomies
	 */
	public function setup_content_types( $force = false ) {

		if ( empty( self::$version ) ) {
			return;
		}

		$post_types = jet_cctMeta::$post_types;
		$taxonomies = jet_cctMeta::$taxonomies;

		$existing_post_types = get_post_types();
		$existing_taxonomies = get_taxonomies();

		$jet_cct_cpt_ct = jet_cct_transient_get( 'jet_cct_wp_cpt_ct' );

		$cpt_positions = array();

		if ( empty( $jet_cct_cpt_ct ) && ( ! empty( $post_types ) || ! empty( $taxonomies ) ) ) {
			$force = true;
		} elseif ( ! empty( $jet_cct_cpt_ct ) && empty( $jet_cct_cpt_ct['post_types'] ) && ! empty( $post_types ) ) {
			$force = true;
		} elseif ( ! empty( $jet_cct_cpt_ct ) && empty( $jet_cct_cpt_ct['taxonomies'] ) && ! empty( $taxonomies ) ) {
			$force = true;
		}

		if ( false === $jet_cct_cpt_ct || $force ) {
			/**
			 * @var WP_Query
			 */
			global $wp_query;

			$reserved_query_vars = array(
				'post_type',
				'taxonomy',
				'output'
			);

			if ( is_object( $wp_query ) ) {
				$reserved_query_vars = array_merge( $reserved_query_vars, array_keys( $wp_query->fill_query_vars( array() ) ) );
			}

			$jet_cct_cpt_ct = array(
				'post_types' => array(),
				'taxonomies' => array()
			);

			$jet_cct_post_types      = $jet_cct_taxonomies = array();
			$supported_post_types = $supported_taxonomies = array();

			$post_format_post_types = array();

			foreach ( $post_types as $post_type ) {
				// Post Type exists already
				if ( isset( $jet_cct_cpt_ct['post_types'][ $post_type['name'] ] ) ) {
					continue;
				} elseif ( ! empty( $post_type['object'] ) && isset( $existing_post_types[ $post_type['object'] ] ) ) {
					continue;
				} elseif ( ! $force && isset( $existing_post_types[ $post_type['name'] ] ) ) {
					continue;
				}

				$post_type['options']['name'] = $post_type['name'];
				$post_type                    = array_merge( $post_type, (array) $post_type['options'] );

				$post_type_name = jet_cct_var( 'name', $post_type );

				// Labels
				$cpt_label    = esc_html( jet_cct_var_raw( 'label', $post_type, ucwords( str_replace( '_', ' ', jet_cct_var_raw( 'name', $post_type ) ) ), null, true ) );
				$cpt_singular = esc_html( jet_cct_var_raw( 'label_singular', $post_type, ucwords( str_replace( '_', ' ', jet_cct_var_raw( 'label', $post_type, $post_type_name, null, true ) ) ), null, true ) );

				$cpt_labels                       = array();
				$cpt_labels['name']               = $cpt_label;
				$cpt_labels['singular_name']      = $cpt_singular;
				$cpt_labels['menu_name']          = jet_cct_var_raw( 'menu_name', $post_type, '', null, true );
				$cpt_labels['add_new']            = jet_cct_var_raw( 'label_add_new', $post_type, '', null, true );
				$cpt_labels['add_new_item']       = jet_cct_var_raw( 'label_add_new_item', $post_type, '', null, true );
				$cpt_labels['new_item']           = jet_cct_var_raw( 'label_new_item', $post_type, '', null, true );
				$cpt_labels['edit']               = jet_cct_var_raw( 'label_edit', $post_type, '', null, true );
				$cpt_labels['edit_item']          = jet_cct_var_raw( 'label_edit_item', $post_type, '', null, true );
				$cpt_labels['view']               = jet_cct_var_raw( 'label_view', $post_type, '', null, true );
				$cpt_labels['view_item']          = jet_cct_var_raw( 'label_view_item', $post_type, '', null, true );
				$cpt_labels['all_items']          = jet_cct_var_raw( 'label_all_items', $post_type, '', null, true );
				$cpt_labels['search_items']       = jet_cct_var_raw( 'label_search_items', $post_type, '', null, true );
				$cpt_labels['not_found']          = jet_cct_var_raw( 'label_not_found', $post_type, '', null, true );
				$cpt_labels['not_found_in_trash'] = jet_cct_var_raw( 'label_not_found_in_trash', $post_type, '', null, true );
				$cpt_labels['parent']             = jet_cct_var_raw( 'label_parent', $post_type, '', null, true );
				$cpt_labels['parent_item_colon']  = jet_cct_var_raw( 'label_parent_item_colon', $post_type, '', null, true );

				// Supported
				$cpt_supported = array(
					'title'           => (boolean) jet_cct_var( 'supports_title', $post_type, false ),
					'editor'          => (boolean) jet_cct_var( 'supports_editor', $post_type, false ),
					'author'          => (boolean) jet_cct_var( 'supports_author', $post_type, false ),
					'thumbnail'       => (boolean) jet_cct_var( 'supports_thumbnail', $post_type, false ),
					'excerpt'         => (boolean) jet_cct_var( 'supports_excerpt', $post_type, false ),
					'trackbacks'      => (boolean) jet_cct_var( 'supports_trackbacks', $post_type, false ),
					'custom-fields'   => (boolean) jet_cct_var( 'supports_custom_fields', $post_type, false ),
					'comments'        => (boolean) jet_cct_var( 'supports_comments', $post_type, false ),
					'revisions'       => (boolean) jet_cct_var( 'supports_revisions', $post_type, false ),
					'page-attributes' => (boolean) jet_cct_var( 'supports_page_attributes', $post_type, false ),
					'post-formats'    => (boolean) jet_cct_var( 'supports_post_formats', $post_type, false )
				);

				// Custom Supported
				$cpt_supported_custom = jet_cct_var( 'supports_custom', $post_type, '' );

				if ( ! empty( $cpt_supported_custom ) ) {
					$cpt_supported_custom = explode( ',', $cpt_supported_custom );
					$cpt_supported_custom = array_filter( array_unique( $cpt_supported_custom ) );

					foreach ( $cpt_supported_custom as $cpt_support ) {
						$cpt_supported[ $cpt_support ] = true;
					}
				}

				// Genesis Support
				if ( function_exists( 'genesis' ) ) {
					$cpt_supported['genesis-seo']             = (boolean) jet_cct_var( 'supports_genesis_seo', $post_type, false );
					$cpt_supported['genesis-layouts']         = (boolean) jet_cct_var( 'supports_genesis_layouts', $post_type, false );
					$cpt_supported['genesis-simple-sidebars'] = (boolean) jet_cct_var( 'supports_genesis_simple_sidebars', $post_type, false );
				}

				// YARPP Support
				if ( defined( 'YARPP_VERSION' ) ) {
					$cpt_supported['yarpp_support'] = (boolean) jet_cct_var( 'supports_yarpp_support', $post_type, false );
				}

				// Jetpack Support
				if ( class_exists( 'Jetpack' ) ) {
					$cpt_supported['supports_jetpack_publicize'] = (boolean) jet_cct_var( 'supports_jetpack_publicize', $post_type, false );
					$cpt_supported['supports_jetpack_markdown']  = (boolean) jet_cct_var( 'supports_jetpack_markdown', $post_type, false );
				}

				// WP needs something, if this was empty and none were enabled, it would show title+editor pre 3.5 :(
				$cpt_supports = array();

				if ( ! jet_cct_version_check( 'wp', '3.5' ) ) {
					$cpt_supports = array( '_bug_fix_pre_35' );
				}

				foreach ( $cpt_supported as $cpt_support => $supported ) {
					if ( true === $supported ) {
						$cpt_supports[] = $cpt_support;

						if ( 'post-formats' === $cpt_support ) {
							$post_format_post_types[] = $post_type_name;
						}
					}
				}

				if ( empty( $cpt_supports ) && jet_cct_version_check( 'wp', '3.5' ) ) {
					$cpt_supports = false;
				}

				// Rewrite
				$cpt_rewrite       = (boolean) jet_cct_var( 'rewrite', $post_type, true );
				$cpt_rewrite_array = array(
					'slug'       => jet_cct_var( 'rewrite_custom_slug', $post_type, str_replace( '_', '-', $post_type_name ), null, true ),
					'with_front' => (boolean) jet_cct_var( 'rewrite_with_front', $post_type, true ),
					'feeds'      => (boolean) jet_cct_var( 'rewrite_feeds', $post_type, (boolean) jet_cct_var( 'has_archive', $post_type, false ) ),
					'pages'      => (boolean) jet_cct_var( 'rewrite_pages', $post_type, true )
				);

				if ( false !== $cpt_rewrite ) {
					$cpt_rewrite = $cpt_rewrite_array;
				}

				$capability_type = jet_cct_var( 'capability_type', $post_type, 'post' );

				if ( 'custom' == $capability_type ) {
					$capability_type = jet_cct_var( 'capability_type_custom', $post_type, 'post' );
				}

				$show_in_menu = (boolean) jet_cct_var( 'show_in_menu', $post_type, true );

				if ( $show_in_menu && 0 < strlen( jet_cct_var_raw( 'menu_location_custom', $post_type ) ) ) {
					$show_in_menu = jet_cct_var_raw( 'menu_location_custom', $post_type );
				}

				$menu_icon = jet_cct_var( 'menu_icon', $post_type, null, null, true );

				if ( ! empty( $menu_icon ) ) {
					$menu_icon = jet_cct_evaluate_tags( $menu_icon );
				}

				// Register Post Type
				$jet_cct_post_types[ $post_type_name ] = array(
					'label'               => $cpt_label,
					'labels'              => $cpt_labels,
					'description'         => esc_html( jet_cct_var_raw( 'description', $post_type ) ),
					'public'              => (boolean) jet_cct_var( 'public', $post_type, true ),
					'publicly_queryable'  => (boolean) jet_cct_var( 'publicly_queryable', $post_type, (boolean) jet_cct_var( 'public', $post_type, true ) ),
					'exclude_from_search' => (boolean) jet_cct_var( 'exclude_from_search', $post_type, ( (boolean) jet_cct_var( 'public', $post_type, true ) ? false : true ) ),
					'show_ui'             => (boolean) jet_cct_var( 'show_ui', $post_type, (boolean) jet_cct_var( 'public', $post_type, true ) ),
					'show_in_menu'        => $show_in_menu,
					'show_in_nav_menus'   => (boolean) jet_cct_var( 'show_in_nav_menus', $post_type, (boolean) jet_cct_var( 'public', $post_type, true ) ),
					'show_in_admin_bar'   => (boolean) jet_cct_var( 'show_in_admin_bar', $post_type, (boolean) jet_cct_var( 'show_in_menu', $post_type, true ) ),
					'menu_position'       => (int) jet_cct_var( 'menu_position', $post_type, 0, null, true ),
					'menu_icon'           => $menu_icon,
					'capability_type'     => $capability_type,
					//'capabilities' => $cpt_capabilities,
					'map_meta_cap'        => (boolean) jet_cct_var( 'capability_type_extra', $post_type, true ),
					'hierarchical'        => (boolean) jet_cct_var( 'hierarchical', $post_type, false ),
					'supports'            => $cpt_supports,
					//'register_meta_box_cb' => array($this, 'manage_meta_box'),
					//'permalink_epmask' => EP_PERMALINK,
					'has_archive'         => jet_cct_v( 'has_archive_slug', $post_type, (boolean) jet_cct_v( 'has_archive', $post_type, false ), true ),
					'rewrite'             => $cpt_rewrite,
					'query_var'           => ( false !== (boolean) jet_cct_var( 'query_var', $post_type, true ) ? jet_cct_var( 'query_var_string', $post_type, $post_type_name, null, true ) : false ),
					'can_export'          => (boolean) jet_cct_var( 'can_export', $post_type, true )
				);

				// YARPP doesn't use 'supports' array option (yet)
				if ( ! empty( $cpt_supports['yarpp_support'] ) ) {
					$jet_cct_post_types[ $post_type_name ]['yarpp_support'] = true;
				}

				// Prevent reserved query_var issues
				if ( in_array( $jet_cct_post_types[ $post_type_name ]['query_var'], $reserved_query_vars ) ) {
					$jet_cct_post_types[ $post_type_name ]['query_var'] = 'post_type_' . $jet_cct_post_types[ $post_type_name ]['query_var'];
				}

				if ( 25 == $jet_cct_post_types[ $post_type_name ]['menu_position'] ) {
					$jet_cct_post_types[ $post_type_name ]['menu_position'] ++;
				}

				if ( $jet_cct_post_types[ $post_type_name ]['menu_position'] < 1 || in_array( $jet_cct_post_types[ $post_type_name ]['menu_position'], $cpt_positions ) ) {
					unset( $jet_cct_post_types[ $post_type_name ]['menu_position'] );
				} else {
					$cpt_positions[] = $jet_cct_post_types[ $post_type_name ]['menu_position'];

					// This would be nice if WP supported floats in menu_position
					// $jet_cct_post_types[ $post_type_name ][ 'menu_position' ] = $jet_cct_post_types[ $post_type_name ][ 'menu_position' ] . '.1';
				}

				// Taxonomies
				$cpt_taxonomies = array();
				$_taxonomies    = get_taxonomies();
				$_taxonomies    = array_merge_recursive( $_taxonomies, $jet_cct_taxonomies );
				$ignore         = array( 'nav_menu', 'link_category', 'post_format' );

				foreach ( $_taxonomies as $taxonomy => $label ) {
					if ( in_array( $taxonomy, $ignore ) ) {
						continue;
					}

					if ( false !== (boolean) jet_cct_var( 'built_in_taxonomies_' . $taxonomy, $post_type, false ) ) {
						$cpt_taxonomies[] = $taxonomy;

						if ( isset( $supported_post_types[ $taxonomy ] ) && ! in_array( $post_type_name, $supported_post_types[ $taxonomy ] ) ) {
							$supported_post_types[ $taxonomy ][] = $post_type_name;
						}
					}
				}

				if ( isset( $supported_taxonomies[ $post_type_name ] ) ) {
					$supported_taxonomies[ $post_type_name ] = array_merge( (array) $supported_taxonomies[ $post_type_name ], $cpt_taxonomies );
				} else {
					$supported_taxonomies[ $post_type_name ] = $cpt_taxonomies;
				}
			}

			foreach ( $taxonomies as $taxonomy ) {
				// Taxonomy Type exists already
				if ( isset( $jet_cct_cpt_ct['taxonomies'][ $taxonomy['name'] ] ) ) {
					continue;
				} elseif ( ! empty( $taxonomy['object'] ) && isset( $existing_taxonomies[ $taxonomy['object'] ] ) ) {
					continue;
				} elseif ( ! $force && isset( $existing_taxonomies[ $taxonomy['name'] ] ) ) {
					continue;
				}

				$taxonomy['options']['name'] = $taxonomy['name'];
				$taxonomy                    = array_merge( $taxonomy, (array) $taxonomy['options'] );

				$taxonomy_name = jet_cct_var( 'name', $taxonomy );

				// Labels
				$ct_label    = esc_html( jet_cct_var_raw( 'label', $taxonomy, ucwords( str_replace( '_', ' ', jet_cct_var_raw( 'name', $taxonomy ) ) ), null, true ) );
				$ct_singular = esc_html( jet_cct_var_raw( 'label_singular', $taxonomy, ucwords( str_replace( '_', ' ', jet_cct_var_raw( 'label', $taxonomy, jet_cct_var_raw( 'name', $taxonomy ), null, true ) ) ), null, true ) );

				$ct_labels                               = array();
				$ct_labels['name']                       = $ct_label;
				$ct_labels['singular_name']              = $ct_singular;
				$ct_labels['menu_name']                  = jet_cct_var_raw( 'menu_name', $taxonomy, '', null, true );
				$ct_labels['search_items']               = jet_cct_var_raw( 'label_search_items', $taxonomy, '', null, true );
				$ct_labels['popular_items']              = jet_cct_var_raw( 'label_popular_items', $taxonomy, '', null, true );
				$ct_labels['all_items']                  = jet_cct_var_raw( 'label_all_items', $taxonomy, '', null, true );
				$ct_labels['parent_item']                = jet_cct_var_raw( 'label_parent_item', $taxonomy, '', null, true );
				$ct_labels['parent_item_colon']          = jet_cct_var_raw( 'label_parent_item_colon', $taxonomy, '', null, true );
				$ct_labels['edit_item']                  = jet_cct_var_raw( 'label_edit_item', $taxonomy, '', null, true );
				$ct_labels['update_item']                = jet_cct_var_raw( 'label_update_item', $taxonomy, '', null, true );
				$ct_labels['add_new_item']               = jet_cct_var_raw( 'label_add_new_item', $taxonomy, '', null, true );
				$ct_labels['new_item_name']              = jet_cct_var_raw( 'label_new_item_name', $taxonomy, '', null, true );
				$ct_labels['separate_items_with_commas'] = jet_cct_var_raw( 'label_separate_items_with_commas', $taxonomy, '', null, true );
				$ct_labels['add_or_remove_items']        = jet_cct_var_raw( 'label_add_or_remove_items', $taxonomy, '', null, true );
				$ct_labels['choose_from_most_used']      = jet_cct_var_raw( 'label_choose_from_the_most_used', $taxonomy, '', null, true );

				// Rewrite
				$ct_rewrite       = (boolean) jet_cct_var( 'rewrite', $taxonomy, true );
				$ct_rewrite_array = array(
					'slug'         => jet_cct_var( 'rewrite_custom_slug', $taxonomy, str_replace( '_', '-', $taxonomy_name ), null, true ),
					'with_front'   => (boolean) jet_cct_var( 'rewrite_with_front', $taxonomy, true ),
					'hierarchical' => (boolean) jet_cct_var( 'rewrite_hierarchical', $taxonomy, (boolean) jet_cct_var( 'hierarchical', $taxonomy, false ) )
				);

				if ( false !== $ct_rewrite ) {
					$ct_rewrite = $ct_rewrite_array;
				}

				/**
				 * Default tax capabilities
				 * @see https://codex.wordpress.org/Function_Reference/register_taxonomy
				 */
				$capability_type = jet_cct_var( 'capability_type', $taxonomy, 'default' );
				$tax_capabilities = array();

				if ( 'custom' == $capability_type ) {
					$capability_type = jet_cct_var( 'capability_type_custom', $taxonomy, 'default' );
					if ( ! empty( $capability_type ) && 'default' != $capability_type ) {
						$capability_type .=  '_term';
						$capability_type_plural =  $capability_type . 's';
						$tax_capabilities = array(
							// Singular
							'edit_term'   => 'edit_' . $capability_type,
							'delete_term' => 'delete_' . $capability_type,
							'assign_term' => 'assign_' . $capability_type,
							// Plural
							'manage_terms' => 'manage_' . $capability_type_plural,
							'edit_terms'   => 'edit_' . $capability_type_plural,
							'delete_terms' => 'delete_' . $capability_type_plural,
							'assign_terms' => 'assign_' . $capability_type_plural,
						);
					}
				}

				// Register Taxonomy
				$jet_cct_taxonomies[ $taxonomy_name ] = array(
					'label'                 => $ct_label,
					'labels'                => $ct_labels,
					'public'                => (boolean) jet_cct_var( 'public', $taxonomy, true ),
					'show_in_nav_menus'     => (boolean) jet_cct_var( 'show_in_nav_menus', $taxonomy, (boolean) jet_cct_var( 'public', $taxonomy, true ) ),
					'show_ui'               => (boolean) jet_cct_var( 'show_ui', $taxonomy, (boolean) jet_cct_var( 'public', $taxonomy, true ) ),
					'show_in_menu'          => (boolean) jet_cct_var( 'show_in_menu', $taxonomy, (boolean) jet_cct_var( 'public', $taxonomy, true ) ),
					'show_tagcloud'         => (boolean) jet_cct_var( 'show_tagcloud', $taxonomy, (boolean) jet_cct_var( 'show_ui', $taxonomy, (boolean) jet_cct_var( 'public', $taxonomy, true ) ) ),
					'hierarchical'          => (boolean) jet_cct_var( 'hierarchical', $taxonomy, false ),
					//'capability_type'       => $capability_type,
					'capabilities'          => $tax_capabilities,
					//'map_meta_cap'          => (boolean) jet_cct_var( 'capability_type_extra', $taxonomy, true ),
					'update_count_callback' => jet_cct_var( 'update_count_callback', $taxonomy, null, null, true ),
					'query_var'             => ( false !== (boolean) jet_cct_var( 'query_var', $taxonomy, true ) ? jet_cct_var( 'query_var_string', $taxonomy, $taxonomy_name, null, true ) : false ),
					'rewrite'               => $ct_rewrite,
					'show_admin_column'     => (boolean) jet_cct_var( 'show_admin_column', $taxonomy, false ),
					'sort'                  => (boolean) jet_cct_var( 'sort', $taxonomy, false )
				);

				if ( is_array( $ct_rewrite ) && ! $jet_cct_taxonomies[ $taxonomy_name ]['query_var'] ) {
					$jet_cct_taxonomies[ $taxonomy_name ]['query_var'] = jet_cct_var( 'query_var_string', $taxonomy, $taxonomy_name, null, true );
				};

				// Prevent reserved query_var issues
				if ( in_array( $jet_cct_taxonomies[ $taxonomy_name ]['query_var'], $reserved_query_vars ) ) {
					$jet_cct_taxonomies[ $taxonomy_name ]['query_var'] = 'taxonomy_' . $jet_cct_taxonomies[ $taxonomy_name ]['query_var'];
				}

				// Integration for Single Value Taxonomy UI
				if ( function_exists( 'tax_single_value_meta_box' ) ) {
					$jet_cct_taxonomies[ $taxonomy_name ]['single_value'] = (boolean) jet_cct_var( 'single_value', $taxonomy, false );
					$jet_cct_taxonomies[ $taxonomy_name ]['required']     = (boolean) jet_cct_var( 'single_value_required', $taxonomy, false );
				}

				// Post Types
				$ct_post_types = array();
				$_post_types   = get_post_types();
				$_post_types   = array_merge_recursive( $_post_types, $jet_cct_post_types );
				$ignore        = array( 'revision' );

				foreach ( $_post_types as $post_type => $options ) {
					if ( in_array( $post_type, $ignore ) ) {
						continue;
					}

					if ( false !== (boolean) jet_cct_var( 'built_in_post_types_' . $post_type, $taxonomy, false ) ) {
						$ct_post_types[] = $post_type;

						if ( isset( $supported_taxonomies[ $post_type ] ) && ! in_array( $taxonomy_name, $supported_taxonomies[ $post_type ] ) ) {
							$supported_taxonomies[ $post_type ][] = $taxonomy_name;
						}
					}
				}

				if ( isset( $supported_post_types[ $taxonomy_name ] ) ) {
					$supported_post_types[ $taxonomy_name ] = array_merge( $supported_post_types[ $taxonomy_name ], $ct_post_types );
				} else {
					$supported_post_types[ $taxonomy_name ] = $ct_post_types;
				}
			}

			$jet_cct_post_types = apply_filters( 'jet_cct_wp_post_types', $jet_cct_post_types );
			$jet_cct_taxonomies = apply_filters( 'jet_cct_wp_taxonomies', $jet_cct_taxonomies );

			$supported_post_types = apply_filters( 'jet_cct_wp_supported_post_types', $supported_post_types );
			$supported_taxonomies = apply_filters( 'jet_cct_wp_supported_taxonomies', $supported_taxonomies );

			foreach ( $jet_cct_taxonomies as $taxonomy => $options ) {
				$ct_post_types = null;

				if ( isset( $supported_post_types[ $taxonomy ] ) && ! empty( $supported_post_types[ $taxonomy ] ) ) {
					$ct_post_types = $supported_post_types[ $taxonomy ];
				}

				$jet_cct_cpt_ct['taxonomies'][ $taxonomy ] = array(
					'post_types' => $ct_post_types,
					'options'    => $options
				);
			}

			foreach ( $jet_cct_post_types as $post_type => $options ) {
				if ( isset( $supported_taxonomies[ $post_type ] ) && ! empty( $supported_taxonomies[ $post_type ] ) ) {
					$options['taxonomies'] = $supported_taxonomies[ $post_type ];
				}

				$jet_cct_cpt_ct['post_types'][ $post_type ] = $options;
			}

			$jet_cct_cpt_ct['post_format_post_types'] = $post_format_post_types;

			jet_cct_transient_set( 'jet_cct_wp_cpt_ct', $jet_cct_cpt_ct );
		}

		foreach ( $jet_cct_cpt_ct['taxonomies'] as $taxonomy => $options ) {
			if ( isset( self::$content_types_registered['taxonomies'] ) && in_array( $taxonomy, self::$content_types_registered['taxonomies'] ) ) {
				continue;
			}

			$ct_post_types = $options['post_types'];
			$options       = $options['options'];

			$options = apply_filters( 'jet_cct_register_taxonomy_' . $taxonomy, $options, $taxonomy );
			$options = apply_filters( 'jet_cct_register_taxonomy', $options, $taxonomy );

			$options = self::object_label_fix( $options, 'taxonomy' );

			// Max length for taxonomies are 32 characters
			$taxonomy = substr( $taxonomy, 0, 32 );

			// i18n compatibility for plugins that override it
			if ( is_array( $options['rewrite'] ) && isset( $options['rewrite']['slug'] ) && ! empty( $options['rewrite']['slug'] ) ) {
				$options['rewrite']['slug'] = _x( $options['rewrite']['slug'], 'URL taxonomy slug', 'jet_cct' );
			}

			if ( 1 == jet_cct_var( 'jet_cct_debug_register', 'get', 0 ) && jet_cct_is_admin( array( 'jet_cct' ) ) ) {
				jet_cct_debug( array( $taxonomy, $ct_post_types, $options ) );
			}

			register_taxonomy( $taxonomy, $ct_post_types, $options );

			if ( ! isset( self::$content_types_registered['taxonomies'] ) ) {
				self::$content_types_registered['taxonomies'] = array();
			}

			self::$content_types_registered['taxonomies'][] = $taxonomy;
		}

		foreach ( $jet_cct_cpt_ct['post_types'] as $post_type => $options ) {
			if ( isset( self::$content_types_registered['post_types'] ) && in_array( $post_type, self::$content_types_registered['post_types'] ) ) {
				continue;
			}

			$options = apply_filters( 'jet_cct_register_post_type_' . $post_type, $options, $post_type );
			$options = apply_filters( 'jet_cct_register_post_type', $options, $post_type );

			$options = self::object_label_fix( $options, 'post_type' );

			// Max length for post types are 20 characters
			$post_type = substr( $post_type, 0, 20 );

			// i18n compatibility for plugins that override it
			if ( is_array( $options['rewrite'] ) && isset( $options['rewrite']['slug'] ) && ! empty( $options['rewrite']['slug'] ) ) {
				$options['rewrite']['slug'] = _x( $options['rewrite']['slug'], 'URL slug', 'jet_cct' );
			}

			if ( 1 == jet_cct_var( 'jet_cct_debug_register', 'get', 0 ) && jet_cct_is_admin( array( 'jet_cct' ) ) ) {
				jet_cct_debug( array( $post_type, $options ) );
			}

			register_post_type( $post_type, $options );

			// Register post format taxonomy for this post type
			if ( isset( $jet_cct_cpt_ct['post_format_post_types'] ) && in_array( $post_type, $jet_cct_cpt_ct['post_format_post_types'], true ) ) {
				register_taxonomy_for_object_type( 'post_format', $post_type );
			}

			if ( ! isset( self::$content_types_registered['post_types'] ) ) {
				self::$content_types_registered['post_types'] = array();
			}

			self::$content_types_registered['post_types'][] = $post_type;
		}

	}

	/**
	 * Check if we need to flush WordPress rewrite rules
	 * This gets run during 'init' action late in the game to give other plugins time to register their rewrite rules
	 */
	public function flush_rewrite_rules() {

		$flush = (int) jet_cct_transient_get( 'jet_cct_flush_rewrites' );

		if ( 1 === $flush ) {
			/**
			 * @var $wp_rewrite WP_Rewrite
			 */
			global $wp_rewrite;
			$wp_rewrite->flush_rules();
			$wp_rewrite->init();

			jet_cct_transient_set( 'jet_cct_flush_rewrites', 0 );
		}
	}

	/**
	 * Update Post Type messages
	 *
	 * @param array $messages
	 *
	 * @return array
	 * @since 2.0.2
	 */
	public function setup_updated_messages( $messages ) {

		global $post, $post_ID;

		$post_types          = jet_cctMeta::$post_types;
		$existing_post_types = get_post_types();

		$jet_cct_cpt_ct = jet_cct_transient_get( 'jet_cct_wp_cpt_ct' );

		if ( empty( $jet_cct_cpt_ct ) || empty( $post_types ) ) {
			return $messages;
		}

		/**
		 * Use get_preview_post_link function added in 4.4, which eventually applies preview_post_link filter
		 * Before 4.4, this filter is defined in wp-admin/includes/meta-boxes.php, $post parameter added in 4.0
		 * there wasn't post parameter back in 3.8
		 * Let's add $post in the filter as it won't hurt anyway.
		 * @since 2.6.8.1
		*/
		$preview_post_link = function_exists( 'get_preview_post_link' )
									? get_preview_post_link( $post )
									: apply_filters( 'preview_post_link', add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ), $post );

		foreach ( $post_types as $post_type ) {
			if ( ! isset( $jet_cct_cpt_ct['post_types'][ $post_type['name'] ] ) ) {
				continue;
			}

			$labels = self::object_label_fix( $jet_cct_cpt_ct['post_types'][ $post_type['name'] ], 'post_type' );
			$labels = $labels['labels'];

			$messages[ $post_type['name'] ] = array(
				1  => sprintf( __( '%s updated. <a href="%s">%s</a>', 'jet_cct' ), $labels['singular_name'], esc_url( get_permalink( $post_ID ) ), $labels['view_item'] ),
				2  => __( 'Custom field updated.', 'jet_cct' ),
				3  => __( 'Custom field deleted.', 'jet_cct' ),
				4  => sprintf( __( '%s updated.', 'jet_cct' ), $labels['singular_name'] ),
				/* translators: %s: date and time of the revision */
				5  => isset( $_GET['revision'] ) ? sprintf( __( '%s restored to revision from %s', 'jet_cct' ), $labels['singular_name'], wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
				6  => sprintf( __( '%s published. <a href="%s">%s</a>', 'jet_cct' ), $labels['singular_name'], esc_url( get_permalink( $post_ID ) ), $labels['view_item'] ),
				7  => sprintf( __( '%s saved.', 'jet_cct' ), $labels['singular_name'] ),
				8  => sprintf( __( '%s submitted. <a target="_blank" href="%s">Preview %s</a>', 'jet_cct' ), $labels['singular_name'], esc_url( $preview_post_link ), $labels['singular_name'] ),
				9  => sprintf( __( '%s scheduled for: <strong>%s</strong>. <a target="_blank" href="%s">Preview %s</a>', 'jet_cct' ), $labels['singular_name'], // translators: Publish box date format, see http://php.net/date
					date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ), $labels['singular_name'] ),
				10 => sprintf( __( '%s draft updated. <a target="_blank" href="%s">Preview %s</a>', 'jet_cct' ), $labels['singular_name'], esc_url( $preview_post_link ), $labels['singular_name'] )
			);

			if ( false === (boolean) $jet_cct_cpt_ct['post_types'][ $post_type['name'] ]['public'] ) {
				$messages[ $post_type['name'] ][1]  = sprintf( __( '%s updated.', 'jet_cct' ), $labels['singular_name'] );
				$messages[ $post_type['name'] ][6]  = sprintf( __( '%s published.', 'jet_cct' ), $labels['singular_name'] );
				$messages[ $post_type['name'] ][8]  = sprintf( __( '%s submitted.', 'jet_cct' ), $labels['singular_name'] );
				$messages[ $post_type['name'] ][9]  = sprintf( __( '%s scheduled for: <strong>%1$s</strong>.', 'jet_cct' ), $labels['singular_name'], // translators: Publish box date format, see http://php.net/date
					date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ) );
				$messages[ $post_type['name'] ][10] = sprintf( __( '%s draft updated.', 'jet_cct' ), $labels['singular_name'] );
			}
		}

		return $messages;
	}

	/**
	 * @param        $args
	 * @param string $type
	 *
	 * @return array
	 */
	public static function object_label_fix( $args, $type = 'post_type' ) {

		if ( empty( $args ) || ! is_array( $args ) ) {
			$args = array();
		}

		if ( ! isset( $args['labels'] ) || ! is_array( $args['labels'] ) ) {
			$args['labels'] = array();
		}

		$label          = jet_cct_var_raw( 'name', $args['labels'], jet_cct_var_raw( 'label', $args, __( 'Items', 'jet_cct' ), null, true ), null, true );
		$singular_label = jet_cct_var_raw( 'singular_name', $args['labels'], jet_cct_var_raw( 'label_singular', $args, __( 'Item', 'jet_cct' ), null, true ), null, true );

		$labels = $args['labels'];

		$labels['name']          = $label;
		$labels['singular_name'] = $singular_label;

		if ( 'post_type' == $type ) {
			$labels['menu_name']             = jet_cct_var_raw( 'menu_name', $labels, $label, null, true );
			$labels['add_new']               = jet_cct_var_raw( 'add_new', $labels, __( 'Add New', 'jet_cct' ), null, true );
			$labels['add_new_item']          = jet_cct_var_raw( 'add_new_item', $labels, sprintf( __( 'Add New %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['new_item']              = jet_cct_var_raw( 'new_item', $labels, sprintf( __( 'New %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['edit']                  = jet_cct_var_raw( 'edit', $labels, __( 'Edit', 'jet_cct' ), null, true );
			$labels['edit_item']             = jet_cct_var_raw( 'edit_item', $labels, sprintf( __( 'Edit %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['view']                  = jet_cct_var_raw( 'view', $labels, sprintf( __( 'View %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['view_item']             = jet_cct_var_raw( 'view_item', $labels, sprintf( __( 'View %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['all_items']             = jet_cct_var_raw( 'all_items', $labels, sprintf( __( 'All %s', 'jet_cct' ), $label ), null, true );
			$labels['search_items']          = jet_cct_var_raw( 'search_items', $labels, sprintf( __( 'Search %s', 'jet_cct' ), $label ), null, true );
			$labels['not_found']             = jet_cct_var_raw( 'not_found', $labels, sprintf( __( 'No %s Found', 'jet_cct' ), $label ), null, true );
			$labels['not_found_in_trash']    = jet_cct_var_raw( 'not_found_in_trash', $labels, sprintf( __( 'No %s Found in Trash', 'jet_cct' ), $label ), null, true );
			$labels['parent']                = jet_cct_var_raw( 'parent', $labels, sprintf( __( 'Parent %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['parent_item_colon']     = jet_cct_var_raw( 'parent_item_colon', $labels, sprintf( __( 'Parent %s:', 'jet_cct' ), $singular_label ), null, true );
			$labels['feature_image']         = jet_cct_var_raw( 'feature_image', $labels, __( 'Featured Image', 'jet_cct' ), null, true );
			$labels['set_featured_image']    = jet_cct_var_raw( 'set_featured_image', $labels, __( 'Set featured image', 'jet_cct' ), null, true );
			$labels['remove_featured_image'] = jet_cct_var_raw( 'remove_featured_image', $labels, __( 'Remove featured image', 'jet_cct' ), null, true );
			$labels['use_featured_image']    = jet_cct_var_raw( 'use_featured_image', $labels, __( 'Use as featured image', 'jet_cct' ), null, true );
			$labels['archives']              = jet_cct_var_raw( 'archives', $labels, sprintf( __( '%s Archives', 'jet_cct' ), $singular_label ), null, true );
			$labels['insert_into_item']      = jet_cct_var_raw( 'insert_into_item', $labels, sprintf( __( 'Insert into %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['uploaded_to_this_item'] = jet_cct_var_raw( 'uploaded_to_this_item', $labels, sprintf( __( 'Uploaded to this %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['filter_items_list']     = jet_cct_var_raw( 'filter_items_list', $labels, sprintf( __( 'Filter %s lists', 'jet_cct' ), $label ), null, true );
			$labels['items_list_navigation'] = jet_cct_var_raw( 'items_list_navigation', $labels, sprintf( __( '%s navigation', 'jet_cct' ), $label ), null, true );
			$labels['items_list']            = jet_cct_var_raw( 'items_list', $labels, sprintf( __( '%s list', 'jet_cct' ), $label ), null, true );
		} elseif ( 'taxonomy' == $type ) {
			$labels['menu_name']                  = jet_cct_var_raw( 'menu_name', $labels, $label, null, true );
			$labels['search_items']               = jet_cct_var_raw( 'search_items', $labels, sprintf( __( 'Search %s', 'jet_cct' ), $label ), null, true );
			$labels['popular_items']              = jet_cct_var_raw( 'popular_items', $labels, sprintf( __( 'Popular %s', 'jet_cct' ), $label ), null, true );
			$labels['all_items']                  = jet_cct_var_raw( 'all_items', $labels, sprintf( __( 'All %s', 'jet_cct' ), $label ), null, true );
			$labels['parent_item']                = jet_cct_var_raw( 'parent_item', $labels, sprintf( __( 'Parent %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['parent_item_colon']          = jet_cct_var_raw( 'parent_item_colon', $labels, sprintf( __( 'Parent %s :', 'jet_cct' ), $singular_label ), null, true );
			$labels['edit_item']                  = jet_cct_var_raw( 'edit_item', $labels, sprintf( __( 'Edit %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['update_item']                = jet_cct_var_raw( 'update_item', $labels, sprintf( __( 'Update %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['add_new_item']               = jet_cct_var_raw( 'add_new_item', $labels, sprintf( __( 'Add New %s', 'jet_cct' ), $singular_label ), null, true );
			$labels['new_item_name']              = jet_cct_var_raw( 'new_item_name', $labels, sprintf( __( 'New %s Name', 'jet_cct' ), $singular_label ), null, true );
			$labels['separate_items_with_commas'] = jet_cct_var_raw( 'separate_items_with_commas', $labels, sprintf( __( 'Separate %s with commas', 'jet_cct' ), $label ), null, true );
			$labels['add_or_remove_items']        = jet_cct_var_raw( 'add_or_remove_items', $labels, sprintf( __( 'Add or remove %s', 'jet_cct' ), $label ), null, true );
			$labels['choose_from_most_used']      = jet_cct_var_raw( 'choose_from_most_used', $labels, sprintf( __( 'Choose from the most used %s', 'jet_cct' ), $label ), null, true );
			$labels['no_terms']                   = jet_cct_var_raw( 'no_terms', $labels, sprintf( __( 'No %s', 'jet_cct' ), $label ), null, true );
			$labels['items_list_navigation']      = jet_cct_var_raw( 'items_list_navigation', $labels, sprintf( __( '%s navigation', 'jet_cct' ), $label ), null, true );
			$labels['items_list']                 = jet_cct_var_raw( 'items_list', $labels, sprintf( __( '%s list', 'jet_cct' ), $label ), null, true );
		}

		$args['labels'] = $labels;

		return $args;
	}

	/**
	 * Activate and Install
	 */
	public function activate_install() {

		register_activation_hook( jet_cct_DIR . 'init.php', array( $this, 'activate' ) );
		register_deactivation_hook( jet_cct_DIR . 'init.php', array( $this, 'deactivate' ) );

		add_action( 'wpmu_new_blog', array( $this, 'new_blog' ), 10, 6 );

		if ( empty( self::$version ) || version_compare( self::$version, jet_cct_VERSION, '<' ) || version_compare( self::$version, jet_cct_DB_VERSION, '<=' ) || self::$upgrade_needed ) {
			$this->setup();
		} elseif ( self::$version !== jet_cct_VERSION ) {
			delete_option( 'jet_cct_framework_version' );
			add_option( 'jet_cct_framework_version', jet_cct_VERSION, '', 'yes' );

			self::$version = jet_cct_VERSION;

			jet_cct_api()->cache_flush_jet_cct();
		}

	}

	/**
	 *
	 */
	public function activate() {

		global $wpdb;

		if ( function_exists( 'is_multisite' ) && is_multisite() && isset( $_GET['networkwide'] ) && 1 == $_GET['networkwide'] ) {
			$_blog_ids = $wpdb->get_col( "SELECT `blog_id` FROM `{$wpdb->blogs}`" );

			foreach ( $_blog_ids as $_blog_id ) {
				$this->setup( $_blog_id );
			}
		} else {
			$this->setup();
		}
	}

	/**
	 *
	 */
	public function deactivate() {

		jet_cct_api()->cache_flush_jet_cct();

	}

	/**
	 *
	 */
	public function needs_upgrade( $current = null, $last = null ) {

		if ( null === $current ) {
			$current = self::$version;
		}

		if ( null === $last ) {
			$last = self::$version_last;
		}

		$upgrade_needed = false;

		if ( ! empty( $current ) ) {
			foreach ( self::$upgrades as $old_version => $new_version ) {
				/*if ( '2.1.0' == $new_version && ( is_developer() ) )
					continue;*/

				if ( version_compare( $last, $old_version, '>=' ) && version_compare( $last, $new_version, '<' ) && version_compare( $current, $new_version, '>=' ) && 1 != self::$upgraded ) {
					$upgrade_needed = true;

					break;
				}
			}
		}

		return $upgrade_needed;
	}

	/**
	 * @param $_blog_id
	 * @param $user_id
	 * @param $domain
	 * @param $path
	 * @param $site_id
	 * @param $meta
	 */
	public function new_blog( $_blog_id, $user_id, $domain, $path, $site_id, $meta ) {

		if ( function_exists( 'is_multisite' ) && is_multisite() && is_plugin_active_for_network( basename( jet_cct_DIR ) . '/init.php' ) ) {
			$this->setup( $_blog_id );
		}
	}

	/**
	 * @param null $_blog_id
	 */
	public function setup( $_blog_id = null ) {

		global $wpdb;

		// Switch DB table prefixes
		if ( null !== $_blog_id && $_blog_id != $wpdb->blogid ) {
			switch_to_blog( jet_cct_absint( $_blog_id ) );
		} else {
			$_blog_id = null;
		}

		// Setup DB tables
		$jet_cct_version      = get_option( 'jet_cct_framework_version' );
		$jet_cct_version_last = get_option( 'jet_cct_framework_version_last' );

		// Install jet_cct
		if ( empty( $jet_cct_version ) ) {
			jet_cct_upgrade()->install( $_blog_id );

			$old_version = get_option( 'jet_cct_version' );

			if ( ! empty( $old_version ) ) {
				if ( false === strpos( $old_version, '.' ) ) {
					$old_version = jet_cct_version_to_point( $old_version );
				}

				delete_option( 'jet_cct_framework_version_last' );
				add_option( 'jet_cct_framework_version_last', $jet_cct_version, '', 'yes' );

				self::$version_last = $old_version;
			}
		} // Upgrade Wizard needed
		elseif ( $this->needs_upgrade( $jet_cct_version, $jet_cct_version_last ) ) {
			// Do not do anything
			return;
		} // Update jet_cct and run any required DB updates
		elseif ( version_compare( $jet_cct_version, jet_cct_VERSION, '<=' ) ) {
			if ( false !== apply_filters( 'jet_cct_update_run', null, jet_cct_VERSION, $jet_cct_version, $_blog_id ) && ! isset( $_GET['jet_cct_bypass_update'] ) ) {
				do_action( 'jet_cct_update', jet_cct_VERSION, $jet_cct_version, $_blog_id );

				// Update 2.0 alpha / beta sites
				if ( version_compare( '2.0.0-a-1', $jet_cct_version, '<=' ) && version_compare( $jet_cct_version, '2.0.0-b-15', '<=' ) ) {
					include( jet_cct_DIR . 'sql/update-2.0-beta.php' );
				}

				if ( version_compare( $jet_cct_version, jet_cct_DB_VERSION, '<=' ) ) {
					include( jet_cct_DIR . 'sql/update.php' );
				}

				do_action( 'jet_cct_update_post', jet_cct_VERSION, $jet_cct_version, $_blog_id );
			}

			delete_option( 'jet_cct_framework_version_last' );
			add_option( 'jet_cct_framework_version_last', $jet_cct_version, '', 'yes' );

			self::$version_last = $jet_cct_version;
		}

		delete_option( 'jet_cct_framework_version' );
		add_option( 'jet_cct_framework_version', jet_cct_VERSION, '', 'yes' );

		delete_option( 'jet_cct_framework_db_version' );
		add_option( 'jet_cct_framework_db_version', jet_cct_DB_VERSION, '', 'yes' );

		self::$version = jet_cct_VERSION;
		self::$db_version = jet_cct_DB_VERSION;

		jet_cct_api()->cache_flush_jet_cct();

		// Restore DB table prefix (if switched)
		if ( null !== $_blog_id ) {
			restore_current_blog();
		}

	}

	/**
	 * @param null $_blog_id
	 */
	public function reset( $_blog_id = null ) {

		global $wpdb;

		// Switch DB table prefixes
		if ( null !== $_blog_id && $_blog_id != $wpdb->blogid ) {
			switch_to_blog( jet_cct_absint( $_blog_id ) );
		} else {
			$_blog_id = null;
		}

		$api = jet_cct_api();

		$jet_cct = $api->load_jet_cct( array( 'names_ids' => true, 'table_info' => false ) );

		foreach ( $jet_cct as $jet_id => $jet_label ) {
			$api->delete_jet( array( 'id' => $jet_id ) );
		}

		$templates = $api->load_templates();

		foreach ( $templates as $template ) {
			$api->delete_template( array( 'id' => $template['id'] ) );
		}

		$pages = $api->load_pages();

		foreach ( $pages as $page ) {
			$api->delete_page( array( 'id' => $page['id'] ) );
		}

		$helpers = $api->load_helpers();

		foreach ( $helpers as $helper ) {
			$api->delete_helper( array( 'id' => $helper['id'] ) );
		}

		$tables = $wpdb->get_results( "SHOW TABLES LIKE '{$wpdb->prefix}jet_cct%'", ARRAY_N );

		if ( ! empty( $tables ) ) {
			foreach ( $tables as $table ) {
				$table = $table[0];

				jet_cct_query( "DROP TABLE `{$table}`", false );
			}
		}

		// Remove any orphans
		$wpdb->query( "
                DELETE `p`, `pm`
                FROM `{$wpdb->posts}` AS `p`
                LEFT JOIN `{$wpdb->postmeta}` AS `pm`
                    ON `pm`.`post_id` = `p`.`ID`
                WHERE
                    `p`.`post_type` LIKE '_jet_cct_%'
            " );

		delete_option( 'jet_cct_framework_version' );
		delete_option( 'jet_cct_framework_db_version' );
		delete_option( 'jet_cct_framework_upgrade_2_0' );
		delete_option( 'jet_cct_framework_upgraded_1_x' );

		// @todo Make sure all entries are being cleaned and do something about the jet_cct_framework_upgrade_{version} dynamic entries created by jet_cctUpgrade
		delete_option( 'jet_cct_framework_upgrade_2_0_0' );
		delete_option( 'jet_cct_framework_upgrade_2_0_sister_ids' );
		delete_option( 'jet_cct_framework_version_last' );

		delete_option( 'jet_cct_component_settings' );

		$api->cache_flush_jet_cct();

		jet_cct_transient_clear( 'jet_cct_flush_rewrites' );

		self::$version = '';

		// Restore DB table prefix (if switched)
		if ( null !== $_blog_id ) {
			restore_current_blog();
		}
	}

	public function run() {

		static $ran;

		if ( ! empty( $ran ) ) {
			return;
		}

		$ran = true;

		if ( ! did_action( 'plugins_loaded' ) ) {
			add_action( 'plugins_loaded', array( $this, 'load_components' ), 11 );
		} else {
			$this->load_components();
		}

		if ( ! did_action( 'setup_theme' ) ) {
			add_action( 'setup_theme', array( $this, 'load_meta' ), 14 );
		} else {
			$this->load_meta();
		}

		if ( ! did_action( 'init' ) ) {
			add_action( 'init', array( $this, 'core' ), 11 );
			add_action( 'init', array( $this, 'add_rest_support' ), 12 );
			add_action( 'init', array( $this, 'setup_content_types' ), 11 );

			if ( is_admin() ) {
				add_action( 'init', array( $this, 'admin_init' ), 12 );
			}
		} else {
			$this->core();
			$this->add_rest_support();
			$this->setup_content_types();

			if ( is_admin() ) {
				$this->admin_init();
			}
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 15 );
		add_action( 'admin_enqueue_scripts', array( $this, 'register_assets' ), 15 );
		add_action( 'login_enqueue_scripts', array( $this, 'register_assets' ), 15 );

		add_filter( 'post_updated_messages', array( $this, 'setup_updated_messages' ), 10, 1 );
		add_action( 'delete_attachment', array( $this, 'delete_attachment' ) );

		// Register widgets
		add_action( 'widgets_init', array( $this, 'register_widgets' ) );

		// Show admin bar links
		add_action( 'admin_bar_menu', array( $this, 'admin_bar_links' ), 81 );

	}

	/**
	 * Delete Attachments from relationships
	 *
	 * @param int $_ID
	 */
	public function delete_attachment( $_ID ) {

		global $wpdb;

		$_ID = (int) $_ID;

		do_action( 'jet_cct_delete_attachment', $_ID );

		$file_types = "'" . implode( "', '", jet_cctForm::file_field_types() ) . "'";

		if ( ! jet_cct_tableless() ) {
			$sql = "
                DELETE `rel`
                FROM `@wp_jet_cctrel` AS `rel`
                LEFT JOIN `{$wpdb->posts}` AS `p`
                    ON
                        `p`.`post_type` = '_jet_cct_field'
                        AND ( `p`.`ID` = `rel`.`field_id` OR `p`.`ID` = `rel`.`related_field_id` )
                LEFT JOIN `{$wpdb->postmeta}` AS `pm`
                    ON
                        `pm`.`post_id` = `p`.`ID`
                        AND `pm`.`meta_key` = 'type'
                        AND `pm`.`meta_value` IN ( {$file_types} )
                WHERE
                    `p`.`ID` IS NOT NULL
                    AND `pm`.`meta_id` IS NOT NULL
                    AND `rel`.`item_id` = {$_ID}";

			jet_cct_query( $sql, false );
		}

		// Post Meta
		if ( ! empty( jet_cctMeta::$post_types ) ) {
			$sql = "
                DELETE `rel`
                FROM `@wp_postmeta` AS `rel`
                LEFT JOIN `{$wpdb->posts}` AS `p`
                    ON
                        `p`.`post_type` = '_jet_cct_field'
                LEFT JOIN `{$wpdb->postmeta}` AS `pm`
                    ON
                        `pm`.`post_id` = `p`.`ID`
                        AND `pm`.`meta_key` = 'type'
                        AND `pm`.`meta_value` IN ( {$file_types} )
                WHERE
                    `p`.`ID` IS NOT NULL
                    AND `pm`.`meta_id` IS NOT NULL
                    AND `rel`.`meta_key` = `p`.`post_name`
                    AND `rel`.`meta_value` = '{$_ID}'";

			jet_cct_query( $sql, false );
		}

		// User Meta
		if ( ! empty( jet_cctMeta::$user ) ) {
			$sql = "
                DELETE `rel`
                FROM `@wp_usermeta` AS `rel`
                LEFT JOIN `{$wpdb->posts}` AS `p`
                    ON
                        `p`.`post_type` = '_jet_cct_field'
                LEFT JOIN `{$wpdb->postmeta}` AS `pm`
                    ON
                        `pm`.`post_id` = `p`.`ID`
                        AND `pm`.`meta_key` = 'type'
                        AND `pm`.`meta_value` IN ( {$file_types} )
                WHERE
                    `p`.`ID` IS NOT NULL
                    AND `pm`.`meta_id` IS NOT NULL
                    AND `rel`.`meta_key` = `p`.`post_name`
                    AND `rel`.`meta_value` = '{$_ID}'";

			jet_cct_query( $sql, false );
		}

		// Comment Meta
		if ( ! empty( jet_cctMeta::$comment ) ) {
			$sql = "
                DELETE `rel`
                FROM `@wp_commentmeta` AS `rel`
                LEFT JOIN `{$wpdb->posts}` AS `p`
                    ON
                        `p`.`post_type` = '_jet_cct_field'
                LEFT JOIN `{$wpdb->postmeta}` AS `pm`
                    ON
                        `pm`.`post_id` = `p`.`ID`
                        AND `pm`.`meta_key` = 'type'
                        AND `pm`.`meta_value` IN ( {$file_types} )
                WHERE
                    `p`.`ID` IS NOT NULL
                    AND `pm`.`meta_id` IS NOT NULL
                    AND `rel`.`meta_key` = `p`.`post_name`
                    AND `rel`.`meta_value` = '{$_ID}'";

			jet_cct_query( $sql, false );
		}
	}

	/**
	 * Register widgets for jet_cct
	 */
	public function register_widgets() {

		$widgets = array(
			'jet_cctWidgetSingle',
			'jet_cctWidgetList',
			'jet_cctWidgetField',
			'jet_cctWidgetForm',
			'jet_cctWidgetView'
		);

		foreach ( $widgets as $widget ) {
			if ( ! file_exists( jet_cct_DIR . 'classes/widgets/' . $widget . '.php' ) ) {
				continue;
			}

			require_once jet_cct_DIR . 'classes/widgets/' . $widget . '.php';

			register_widget( $widget );
		}
	}

	/**
	 * Add Admin Bar links
	 */
	public function admin_bar_links() {

		global $wp_admin_bar, $jet_cct;

		if ( ! is_user_logged_in() || ! is_admin_bar_showing() ) {
			return;
		}

		$all_jet_cct = jet_cct_api()->load_jet_cct( array( 'type' => 'jet', 'fields' => false, 'table_info' => false ) );

		// Add New item links for all jet_cct
		foreach ( $all_jet_cct as $jet ) {
			if ( 0 == $jet['options']['show_in_menu'] ) {
				continue;
			}

			if ( ! jet_cct_is_admin( array( 'jet_cct', 'jet_cct_content', 'jet_cct_add_' . $jet['name'] ) ) ) {
				continue;
			}

			$singular_label = jet_cct_var_raw( 'label_singular', $jet['options'], jet_cct_var_raw( 'label', $jet, ucwords( str_replace( '_', ' ', $jet['name'] ) ), null, true ), null, true );

			$wp_admin_bar->add_node( array(
				'id'     => 'new-jet-' . $jet['name'],
				'title'  => $singular_label,
				'parent' => 'new-content',
				'href'   => admin_url( 'admin.php?page=jet_cct-manage-' . $jet['name'] . '&action=add' )
			) );
		}

		// Add edit link if we're on a jet_cct page
		if ( is_object( $jet_cct ) && ! is_wp_error( $jet_cct ) && ! empty( $jet_cct->id ) && isset( $jet_cct->jet_data ) && ! empty( $jet_cct->jet_data ) && 'jet' == $jet_cct->jet_data['type'] ) {
			$jet = $jet_cct->jet_data;

			if ( jet_cct_is_admin( array( 'jet_cct', 'jet_cct_content', 'jet_cct_edit_' . $jet['name'] ) ) ) {
				$singular_label = jet_cct_var_raw( 'label_singular', $jet['options'], jet_cct_var_raw( 'label', $jet, ucwords( str_replace( '_', ' ', $jet['name'] ) ), null, true ), null, true );

				$wp_admin_bar->add_node( array(
					'title' => sprintf( __( 'Edit %s', 'jet_cct' ), $singular_label ),
					'id'    => 'edit-jet',
					'href'  => admin_url( 'admin.php?page=jet_cct-manage-' . $jet['name'] . '&action=edit&id=' . $jet_cct->id() )
				) );
			}
		}

	}

	/**
	 * Add REST API support to post type and taxonomy objects.
	 *
	 * @uses  "init"
	 *
	 * @since 2.5.6
	 */
	public function add_rest_support() {

		if ( empty( self::$version ) ) {
			return;
		}

		static $rest_support_added;

		if ( ! function_exists( 'register_rest_field' ) ) {
			return;
		}

		include_once( jet_cct_DIR . 'classes/jet_cctRESTFields.php' );
		include_once( jet_cct_DIR . 'classes/jet_cctRESTHandlers.php' );

		$rest_bases = jet_cct_transient_get( 'jet_cct_rest_bases' );

		if ( empty( $rest_bases ) ) {
	        $jet_cct = jet_cct_api()->load_jet_cct( array( 'type' => array( 'post_type', 'taxonomy', 'user', 'media', 'comment' ), 'fields' => false, 'table_info' => false ) );

			$rest_bases = array();

			if ( ! empty( $jet_cct ) && is_array( $jet_cct ) ) {
				foreach ( $jet_cct as $jet ) {
					$type = $jet['type'];

					if ( in_array( $type, array( 'post_type', 'taxonomy', 'user', 'media', 'comment' ) ) ) {
						if ( $jet && jet_cctRESTHandlers::jet_extends_core_route( $jet ) ) {
							$rest_bases[ $jet['name'] ] = array(
								'type' => $type,
								'base' => sanitize_title( jet_cct_v( 'rest_base', $jet['options'], $jet['name'] ) ),
							);
						}
					}
				}
			}

			if ( empty( $rest_bases ) ) {
				$rest_bases = 'none';
			}

			jet_cct_transient_set( 'jet_cct_rest_bases', $rest_bases );
		}

		if ( empty( $rest_support_added ) && ! empty( $rest_bases ) && 'none' !== $rest_bases ) {
			foreach ( $rest_bases as $jet_name => $jet_info ) {
				$jet_type  = $jet_info['type'];
				$rest_base = $jet_info['base'];

				if ( 'post_type' == $jet_type ) {
					jet_cctRESTHandlers::post_type_rest_support( $jet_name, $rest_base );
				} elseif ( 'taxonomy' == $jet_type ) {
					jet_cctRESTHandlers::taxonomy_rest_support( $jet_name, $rest_base );
				}

				new jet_cctRESTFields( $jet_name );
			}

			$rest_support_added = true;
		}

	}
}
