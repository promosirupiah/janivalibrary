<?php
/**
 * Class jet_cctRESTFields
 *
 * Creates an object that adds read/write handlers for jet_cct fields in default responses.
 *
 * @package jet_cct
 * @since   2.5.6
 */
class jet_cctRESTFields {

	/**
	 * jet_cct object
	 *
	 * @since 2.5.6
	 *
	 * @access protected
	 *
	 * @var jet_cct
	 */
	protected $jet;

	/**
	 * Constructor for class
	 *
	 * @since 2.5.6
	 *
	 * @param string|object|jet_cct $jet jet_cct object
	 */
	public function __construct( $jet ) {

		if ( ! function_exists( 'register_rest_field' ) ) {
			return;
		}

		$this->set_jet( $jet );

		if ( $this->jet ) {
			$this->add_fields();
		}

	}

	/**
	 * Set the jet_cct object
	 *
	 * @since  2.5.6
	 *
	 * @access protected
	 *
	 * @param string|jet_cct $jet jet_cct object or name of jet_cct object
	 */
	private function set_jet( $jet ) {

		if ( is_string( $jet ) ) {
			$this->set_jet( jet_cct( $jet, null, true ) );

		} else {
			$type = $jet->jet_data['type'];

			if ( in_array( $type, array( 'post_type', 'user', 'taxonomy', 'media', 'comment' ) ) ) {
				$this->jet = $jet;
			} else {
				$this->jet = false;
			}
		}

	}

	/**
	 * Add fields, based on options to REST read/write requests
	 *
	 * @since  2.5.6
	 *
	 * @access protected
	 */
	protected function add_fields() {

		$fields = $this->jet->fields();

		foreach ( $fields as $field_name => $field ) {
			$read  = self::field_allowed_to_extend( $field_name, $this->jet, 'read' );
			$write = self::field_allowed_to_extend( $field_name, $this->jet, 'write' );

			$this->register( $field_name, $read, $write );
		}

	}

	/**
	 * Register fields and their callbacks for read/write via REST
	 *
	 * @since  2.5.6
	 *
	 * @access protected
	 *
	 * @param string            $field_name Name of fields.
	 * @param bool|string|array $read       Allowing reading?
	 * @param bool|string|array $write      Allow writing?
	 */
	protected function register( $field_name, $read, $write ) {

		$args = array();

		switch ( $read ) {
			case true === $read :
				$args['get_callback'] = array( 'jet_cctRESTHandlers', 'get_handler' );
				break;
			case is_callable( $read ) :
				$args['get_callback'] = $read;
				$read                 = true;
				break;
		}

		switch ( $write ) {
			case true === $write :
				$args['update_callback'] = array( 'jet_cctRESTHandlers', 'write_handler' );
				break;
			case is_callable( $write ) :
				$args['update_callback'] = $write;
				$write                   = true;
				break;
		}

		$object_type = $this->jet->jet;

		if ( 'media' == $object_type ) {
			$object_type = 'attachment';
		}

		if ( $read || $write ) {
			if ( function_exists( 'register_rest_field' ) ) {
				register_rest_field( $object_type, $field_name, $args );
			} elseif ( function_exists( 'register_api_field' ) ) {
				register_api_field( $object_type, $field_name, $args );
			}
		}

	}

	/**
	 * Check if a field supports read or write via the REST API.
	 *
	 * @since 2.5.6
	 *
	 * @param string      $field_name The field name.
	 * @param object|jet_cct $jet        jet_cct object.
	 * @param string      $mode       Are we checking read or write?
	 *
	 * @return bool If supports, true, else false.
	 */
	public static function field_allowed_to_extend( $field_name, $jet, $mode = 'read' ) {

		$allowed = false;

		if ( is_object( $jet ) ) {
			$fields = $jet->fields();

			if ( array_key_exists( $field_name, $fields ) ) {
				$jet_options = $jet->jet_data['options'];

				if ( 'read' === $mode && jet_cct_v( 'read_all', $jet_options, false ) ) {
					$allowed = true;
				} elseif ( 'write' === $mode && jet_cct_v( 'write_all', $jet_options, false ) ) {
					$allowed = true;
				} elseif ( isset( $fields[ $field_name ] ) ) {
					if ( 'read' === $mode && 1 == (int) $jet->fields( $field_name, 'rest_read' ) ) {
						$allowed = true;
					} elseif ( 'write' === $mode && 1 == (int) $jet->fields( $field_name, 'rest_write' ) ) {
						$allowed = true;
					}
				}
			}
		}

		return $allowed;

	}

}