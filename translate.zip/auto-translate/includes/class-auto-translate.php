<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://pampa.dev
 * @since      1.0.0
 *
 * @package    Auto_Translate
 * @subpackage Auto_Translate/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Auto_Translate
 * @subpackage Auto_Translate/includes
 * @author     Pampa Dev <intouch@pampa.dev>
 */
class Auto_Translate {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Auto_Translate_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'AUTO_TRANSLATE_VERSION' ) ) {
			$this->version = AUTO_TRANSLATE_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'auto-translate';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Auto_Translate_Loader. Orchestrates the hooks of the plugin.
	 * - Auto_Translate_i18n. Defines internationalization functionality.
	 * - Auto_Translate_Admin. Defines all hooks for the admin area.
	 * - Auto_Translate_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-auto-translate-loader.php';

		/**
		 * Configuration accessor to avoid direct global coupling in runtime classes.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-auto-translate-config.php';

		/**
		 * Local lifecycle tracker for preview/live mode transitions.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-auto-translate-lifecycle.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-auto-translate-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-auto-translate-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-auto-translate-public.php';

		$this->loader = new Auto_Translate_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Auto_Translate_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Auto_Translate_i18n();

		$this->loader->add_action( 'init', $plugin_i18n, 'register_locale_fallbacks' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$lifecycle    = new Auto_Translate_Lifecycle();
		$plugin_admin = new Auto_Translate_Admin( $this->get_plugin_name(), $this->get_version(), $lifecycle );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'create_admin_menu' );
		$this->loader->add_action( 'admin_init', $plugin_admin, 'plugin_settings' );
		$this->loader->add_action( 'widgets_init', $plugin_admin, 'load_widgets' );
		// Keep migrations in admin flow to avoid version checks on every frontend request.
		$this->loader->add_action( 'admin_init', $plugin_admin, 'check_version', 1 );
		$this->loader->add_action( 'admin_post_wpat_set_go_live', $plugin_admin, 'handle_go_live_action' );
		$this->loader->add_action( 'admin_post_wpat_preview_site', $plugin_admin, 'handle_preview_site_action' );
		$this->loader->add_action( 'admin_post_wpat_record_launch_action', $plugin_admin, 'handle_record_launch_action' );
		$this->loader->add_action( 'admin_post_wpat_set_launch_checklist_state', $plugin_admin, 'handle_launch_checklist_state_action' );
		$this->loader->add_action( 'wp_ajax_wpat_set_launch_checklist_state', $plugin_admin, 'handle_launch_checklist_state_ajax' );
		$this->loader->add_action( 'wp_ajax_wpat_dismiss_plugin_links_notice', $plugin_admin, 'handle_plugin_links_notice_dismissal_ajax' );
		$this->loader->add_action( 'update_option_wpat_go_live', $lifecycle, 'handle_go_live_option_update', 10, 3 );
		$this->loader->add_filter( 'plugin_action_links_' . plugin_basename( dirname( __DIR__ ) . '/auto-translate.php' ), $plugin_admin, 'add_plugin_action_links' );
		$this->loader->add_filter( 'plugin_row_meta', $plugin_admin, 'add_plugin_row_meta', 10, 2 );
		$this->loader->add_filter( 'wpat_appsero_deactivation_reasons', $plugin_admin, 'filter_appsero_deactivation_reasons', 10, 2 );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Auto_Translate_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		$this->loader->add_filter( 'script_loader_tag', $plugin_public, 'add_defer_to_public_script_tags', 10, 3 );
		$this->loader->add_action( 'init', $plugin_public, 'register_selector_block' );
		$this->loader->add_action( 'wp_head', $plugin_public, 'add_version_meta', 1 );
		$this->loader->add_action( 'wp_head', $plugin_public, 'hook_javascript_translator' );
		$this->loader->add_action( 'wp_footer', $plugin_public, 'hook_content_translator' );
		$this->loader->add_action( 'admin_bar_menu', $plugin_public, 'add_preview_admin_bar_node', 90 );
		$this->loader->add_filter('wp_nav_menu_items', $plugin_public,'hook_menu_item', 10, 2);
		$this->loader->add_filter( 'render_block', $plugin_public, 'hook_navigation_block', 10, 2 );
		$this->loader->add_action( 'save_post_et_header_layout', $plugin_public, 'clear_divi_shortcode_layout_cache' );
		$this->loader->add_action( 'save_post_et_body_layout', $plugin_public, 'clear_divi_shortcode_layout_cache' );
		$this->loader->add_action( 'save_post_et_footer_layout', $plugin_public, 'clear_divi_shortcode_layout_cache' );
		$this->loader->add_action( 'wp_ajax_wpat_record_frontend_signal', $plugin_public, 'handle_frontend_signal_ajax' );
		$this->loader->add_action( 'wp_ajax_nopriv_wpat_record_frontend_signal', $plugin_public, 'handle_frontend_signal_ajax' );
		$this->loader->add_shortcode( 'auto_translate_button', $plugin_public, 'auto_translate_button_function' );
		$this->loader->add_shortcode( 'auto_translate_link', $plugin_public, 'auto_translate_link_function' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Auto_Translate_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
