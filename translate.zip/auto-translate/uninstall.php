<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @link       https://pampa.dev
 * @since      1.0.0
 *
 * @package    Auto_Translate
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'AUTO_TRANSLATE_DELETE_ON_UNINSTALL' ) ) {
	define( 'AUTO_TRANSLATE_DELETE_ON_UNINSTALL', false );
}

$wpat_should_delete = AUTO_TRANSLATE_DELETE_ON_UNINSTALL || 'on' === get_option( 'wpat_delete_data_on_uninstall', '' );

if ( ! $wpat_should_delete ) {
	return;
}

$wpat_option_keys = array(
	'wpat_auto_translate_version',
	'wpat_base_language',
	'wpat_widget_type',
	'wpat_button_icon',
	'wpat_show_icon',
	'wpat_supported_languages',
	'wpat_language_order',
	'wpat_language_name_display',
	'wpat_color_1',
	'wpat_color_2',
	'wpat_widget_size',
	'wpat_border_radius',
	'wpat_border_thickness',
	'wpat_border_color',
	'wpat_font_color',
	'wpat_font_family',
	'wpat_dropdown_border_thickness',
	'wpat_dropdown_border_color',
	'wpat_dropdown_background_color',
	'wpat_dropdown_hover_color',
	'wpat_dropdown_font_hover_color',
	'wpat_dropdown_font_selected_color',
	'wpat_dropdown_font_color',
	'wpat_dropdown_shadow',
	'wpat_dropdown_font_family',
	'wpat_min_style',
	'wpat_min_base_style',
	'wpat_min_preset',
	'wpat_min_layout',
	'wpat_min_icon',
	'wpat_min_txt_display',
	'wpat_min_chevron',
	'wpat_min_txt_underline',
	'wpat_min_text_divider',
	'wpat_min_border_thickness',
	'wpat_min_border_color',
	'wpat_min_border_transparent',
	'wpat_min_background_color',
	'wpat_min_background_transparent',
	'wpat_min_font_color',
	'wpat_min_font_family',
	'wpat_min_hover_color',
	'wpat_min_hover_transparent',
	'wpat_min_font_hover_color',
	'wpat_language_flags',
	'wpat_default_location',
	'wpat_go_live',
	'wpat_floating_position',
	'wpat_floating_offset_x',
	'wpat_floating_offset_y',
	'wpat_auto_detect',
	'wpat_show_in_menu',
	'wpat_menu_position',
	'wpat_wrapper_selector',
	'wpat_custom_css',
	'wpat_min_custom_css',
	'wpat_excluded_selectors',
	'wpat_delete_data_on_uninstall',
	'wpat_classic_widget_migrated_notice',
	'wpat_launch_checklist_completed',
	'wpat_launch_checklist_reviewed',
	'wpat_lifecycle_last_saved_tab',
	'wpat_lifecycle',
	'wpat_size', // legacy option key from old versions.
);

foreach ( $wpat_option_keys as $wpat_option_key ) {
	delete_option( $wpat_option_key );
}

delete_metadata( 'user', 0, 'wpat_launch_checklist_state', '', true );
