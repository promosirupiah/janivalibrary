<?php

//ini_set ('display_errors', 1);
//error_reporting (E_ALL);

define ('AI_OPTION_NAME',                'ad_inserter');
define ('AI_INSTALL_NAME',               'ai-install');
define ('AI_OPTION_GLOBAL',              'global');
define ('AI_OPTION_EXTRACT',             'extract');

if (!defined ('AD_INSERTER_PLUGIN_DIR'))
  define ('AD_INSERTER_PLUGIN_DIR', plugin_dir_path (__FILE__));

if (file_exists (AD_INSERTER_PLUGIN_DIR.'functions.php')) {
  include_once AD_INSERTER_PLUGIN_DIR.'functions.php';
}

if (!defined( 'AD_INSERTER_NAME'))
  define ('AD_INSERTER_NAME', 'Ad Inserter');

if (!defined( 'AD_INSERTER_VERSION'))
  define ('AD_INSERTER_VERSION', '2.2.7');

if (!defined ('AD_INSERTER_PLUGIN_BASENAME'))
  define ('AD_INSERTER_PLUGIN_BASENAME', plugin_basename (__FILE__));

if (!defined ('AD_INSERTER_PLUGIN_DIRNAME'))
  define ('AD_INSERTER_PLUGIN_DIRNAME', dirname (AD_INSERTER_PLUGIN_BASENAME));

if (!defined ('AD_INSERTER_PLUGIN_URL'))
  define ('AD_INSERTER_PLUGIN_URL', plugin_dir_url ( __FILE__));

if (!defined ('AD_INSERTER_PLUGIN_IMAGES_URL'))
  define ('AD_INSERTER_PLUGIN_IMAGES_URL', AD_INSERTER_PLUGIN_URL. 'images/');

define ('AD_EMPTY_DATA', '');
define ('AD_ZERO', '0');
define ('AD_ONE',  '1');
define ('AD_TWO',  '2');
define ('AD_GENERAL_TAG', '');
define ('AD_NAME', 'Block');

// Old options
define ('AD_OPTIONS',     'AdInserterOptions');   // general plugin options
define ('AD_ADx_OPTIONS', 'AdInserter#Options');

// Options
define ('WP_FORM_FIELD_POSTFIX',                 '_block_');
define ('AI_HEADER_OPTION_NAME',                 'h');
define ('AI_FOOTER_OPTION_NAME',                 'f');
define ('AI_ADB_MESSAGE_OPTION_NAME',            'a');

define ('AI_OPTION_CODE',                        'code');
define ('AI_OPTION_ENABLE_MANUAL',               'enable_manual');
define ('AI_OPTION_ENABLE_AMP',                  'enable_amp');
define ('AI_OPTION_ENABLE_WIDGET',               'enable_widget');
define ('AI_OPTION_PROCESS_PHP',                 'process_php');
define ('AI_OPTION_TRACKING',                    'tracking');
define ('AI_OPTION_ENABLE_AJAX',                 'enable_ajax');
define ('AI_OPTION_ENABLE_FEED',                 'enable_feed');
define ('AI_OPTION_ENABLE_404',                  'enable_404');
define ('AI_OPTION_BLOCK_NAME',                  'name');
define ('AI_OPTION_AUTOMATIC_INSERTION',         'display_type');
define ('AI_OPTION_PARAGRAPH_NUMBER',            'paragraph_number');
define ('AI_OPTION_MIN_PARAGRAPHS',              'min_paragraphs');
define ('AI_OPTION_MIN_WORDS_ABOVE',             'min_words_above');
define ('AI_OPTION_COUNT_INSIDE_BLOCKQUOTE',     'count_inside_blockquote');
define ('AI_OPTION_MIN_WORDS',                   'min_words');
define ('AI_OPTION_MAX_WORDS',                   'max_words');
define ('AI_OPTION_MIN_PARAGRAPH_WORDS',         'min_paragraph_words');
define ('AI_OPTION_MAX_PARAGRAPH_WORDS',         'max_paragraph_words');
define ('AI_OPTION_PARAGRAPH_TAGS',              'paragraph_tags');
define ('AI_OPTION_AVOID_PARAGRAPHS_ABOVE',      'avoid_paragraphs_above');
define ('AI_OPTION_AVOID_PARAGRAPHS_BELOW',      'avoid_paragraphs_below');
define ('AI_OPTION_AVOID_TEXT_ABOVE',            'avoid_text_above');
define ('AI_OPTION_AVOID_TEXT_BELOW',            'avoid_text_below');
define ('AI_OPTION_AVOID_ACTION',                'avoid_action');
define ('AI_OPTION_AVOID_TRY_LIMIT',             'avoid_try_limit');
define ('AI_OPTION_AVOID_DIRECTION',             'avoid_direction');
define ('AI_OPTION_EXCERPT_NUMBER',              'excerpt_number'); // needs to be renamed
define ('AI_OPTION_FILTER_TYPE',                 'filter_type');
define ('AI_OPTION_INVERTED_FILTER',             'inverted_filter');
define ('AI_OPTION_DIRECTION_TYPE',              'direction_type');
define ('AI_OPTION_ALIGNMENT_TYPE',              'alignment_type');
define ('AI_OPTION_GENERAL_TAG',                 'general_tag');
define ('AI_OPTION_SCHEDULING',                  'scheduling');
define ('AI_OPTION_AFTER_DAYS',                  'after_days');
define ('AI_OPTION_START_DATE',                  'start_date');
define ('AI_OPTION_END_DATE',                    'end_date');
define ('AI_OPTION_FALLBACK',                    'fallback');
define ('AI_OPTION_MAXIMUM_INSERTIONS',          'maximum_insertions');
define ('AI_OPTION_ID_LIST',                     'id_list');
define ('AI_OPTION_ID_LIST_TYPE',                'id_list_type');
define ('AI_OPTION_URL_LIST',                    'url_list');
define ('AI_OPTION_URL_LIST_TYPE',               'url_list_type');
define ('AI_OPTION_URL_PARAMETER_LIST',          'url_parameter_list');
define ('AI_OPTION_URL_PARAMETER_LIST_TYPE',     'url_parameter_list_type');
define ('AI_OPTION_DOMAIN_LIST',                 'domain_list');
define ('AI_OPTION_DOMAIN_LIST_TYPE',            'domain_list_type');
define ('AI_OPTION_IP_ADDRESS_LIST',             'ip_address_list');
define ('AI_OPTION_IP_ADDRESS_LIST_TYPE',        'ip_address_list_type');
define ('AI_OPTION_COUNTRY_LIST',                'country_list');
define ('AI_OPTION_COUNTRY_LIST_TYPE',           'country_list_type');
define ('AI_OPTION_CATEGORY_LIST',               'category_list');
define ('AI_OPTION_CATEGORY_LIST_TYPE',          'category_list_type');
define ('AI_OPTION_TAG_LIST',                    'tag_list');
define ('AI_OPTION_TAG_LIST_TYPE',               'tag_list_type');
define ('AI_OPTION_TAXONOMY_LIST',               'taxonomy_list');
define ('AI_OPTION_TAXONOMY_LIST_TYPE',          'taxonomy_list_type');
define ('AI_OPTION_DISPLAY_ON_HOMEPAGE',         'display_on_homepage');
define ('AI_OPTION_DISPLAY_ON_PAGES',            'display_on_pages');
define ('AI_OPTION_DISPLAY_ON_POSTS',            'display_on_posts');
define ('AI_OPTION_DISPLAY_ON_CATEGORY_PAGES',   'display_on_category_pages');
define ('AI_OPTION_DISPLAY_ON_SEARCH_PAGES',     'display_on_search_pages');
define ('AI_OPTION_DISPLAY_ON_ARCHIVE_PAGES',    'display_on_archive_pages');
define ('AI_OPTION_ENABLED_ON_WHICH_PAGES',      'enabled_on_which_pages');
define ('AI_OPTION_ENABLED_ON_WHICH_POSTS',      'enabled_on_which_posts');
define ('AI_OPTION_ENABLE_PHP_CALL',             'enable_php_call');
define ('AI_OPTION_PARAGRAPH_TEXT',              'paragraph_text');
define ('AI_OPTION_PARAGRAPH_TEXT_TYPE',         'paragraph_text_type');
define ('AI_OPTION_CUSTOM_CSS',                  'custom_css');
define ('AI_OPTION_DISPLAY_FOR_USERS',           'display_for_users');
define ('AI_OPTION_DISPLAY_FOR_DEVICES',         'display_for_devices');
define ('AI_OPTION_DETECT_SERVER_SIDE',          'detect_server_side');
define ('AI_OPTION_DETECT_CLIENT_SIDE',          'detect_client_side');
define ('AI_OPTION_DETECT_VIEWPORT',             'detect_viewport');
define ('AI_OPTION_ADB_BLOCK_ACTION',            'adb-block-action');
define ('AI_OPTION_ADB_BLOCK_REPLACEMENT',       'adb-block-replacement');

define ('AI_OPTION_DISABLED',                    'disabled');

define ('AI_OPTION_IMPORT',                      'import');
define ('AI_OPTION_IMPORT_NAME',                 'import_name');
define ('AI_OPTION_PLUGIN_STATUS',               'plugin_status');

define ('AI_OPTION_ADB_ACTION',                  'adb-action');
define ('AI_OPTION_ADB_SELECTORS',               'adb-selectors');
define ('AI_OPTION_ADB_DELAY_ACTION',            'adb-delay-action');
define ('AI_OPTION_ADB_NO_ACTION_PERIOD',        'adb-no-action-period');
define ('AI_OPTION_ADB_REDIRECTION_PAGE',        'adb-redirection-page');
define ('AI_OPTION_ADB_CUSTOM_REDIRECTION_URL',  'adb-custom-redirection-url');
define ('AI_OPTION_ADB_MESSAGE_CSS',             'adb-message-css');
define ('AI_OPTION_ADB_OVERLAY_CSS',             'adb-overlay-css');
define ('AI_OPTION_ADB_UNDISMISSIBLE_MESSAGE',   'adb-undismissible-message');


//misc
define('AD_EMPTY_VALUE','');

//define constant variable form
define('AI_FORM_SAVE','ai_save');
define('AI_FORM_CLEAR','ai_clear');
define('AI_FORM_CLEAR_EXCEPTIONS','ai-clear-exceptions');
define('AI_FORM_CLEAR_STATISTICS','ai-clear-statistics');

define('AD_AUTHOR_SITE', '<!-- Powered by Ad Inserter Plugin By Spacetime -->');
define('AD_ROTATE_SEPARATOR', '|rotate|');
define('AD_COUNT_SEPARATOR',  '|count|');
define('AD_AMP_SEPARATOR',    '|amp|');
define('AD_HTTP_SEPARATOR',   '|http|');

//form select options
define('AD_SELECT_SELECTED','selected');

//Automatic insertion options - Deprecated
define('AD_SELECT_NONE','None');
define('AD_SELECT_BEFORE_POST','Before Post');
define('AD_SELECT_AFTER_POST','After Post');
define('AD_SELECT_BEFORE_PARAGRAPH','Before Paragraph');
define('AD_SELECT_AFTER_PARAGRAPH','After Paragraph');
define('AD_SELECT_BEFORE_CONTENT','Before Content');
define('AD_SELECT_AFTER_CONTENT','After Content');
define('AD_SELECT_BEFORE_EXCERPT','Before Excerpt');
define('AD_SELECT_AFTER_EXCERPT','After Excerpt');
define('AD_SELECT_BETWEEN_POSTS','Between Posts');
define('AD_SELECT_WIDGET','Widget');              // Deprecated
define('AD_SELECT_BEFORE_TITLE','Before Title');  // Deprecated
define('AD_SELECT_MANUAL','Manual');              // Deprecated

define('AI_AUTOMATIC_INSERTION_DISABLED',             0);
define('AI_AUTOMATIC_INSERTION_BEFORE_POST',          1);
define('AI_AUTOMATIC_INSERTION_AFTER_POST',           2);
define('AI_AUTOMATIC_INSERTION_BEFORE_CONTENT',       3);
define('AI_AUTOMATIC_INSERTION_AFTER_CONTENT',        4);
define('AI_AUTOMATIC_INSERTION_BEFORE_PARAGRAPH',     5);
define('AI_AUTOMATIC_INSERTION_AFTER_PARAGRAPH',      6);
define('AI_AUTOMATIC_INSERTION_BEFORE_EXCERPT',       7);
define('AI_AUTOMATIC_INSERTION_AFTER_EXCERPT',        8);
define('AI_AUTOMATIC_INSERTION_BETWEEN_POSTS',        9);
define('AI_AUTOMATIC_INSERTION_BEFORE_COMMENTS',     10);
define('AI_AUTOMATIC_INSERTION_BETWEEN_COMMENTS',    11);
define('AI_AUTOMATIC_INSERTION_AFTER_COMMENTS',      12);
define('AI_AUTOMATIC_INSERTION_FOOTER',              13);
define('AI_AUTOMATIC_INSERTION_ABOVE_HEADER',        14);
define('AI_AUTOMATIC_INSERTION_CUSTOM_HOOK',        100);

define('AI_TEXT_DISABLED',             'Disabled');
define('AI_TEXT_BEFORE_POST',          'Before Post');
define('AI_TEXT_AFTER_POST',           'After Post');
define('AI_TEXT_BEFORE_CONTENT',       'Before Content');
define('AI_TEXT_AFTER_CONTENT',        'After Content');
define('AI_TEXT_BEFORE_PARAGRAPH',     'Before Paragraph');
define('AI_TEXT_AFTER_PARAGRAPH',      'After Paragraph');
define('AI_TEXT_BEFORE_EXCERPT',       'Before Excerpt');
define('AI_TEXT_AFTER_EXCERPT',        'After Excerpt');
define('AI_TEXT_BETWEEN_POSTS',        'Between Posts');
define('AI_TEXT_BEFORE_COMMENTS',      'Before Comments');
define('AI_TEXT_BETWEEN_COMMENTS',     'Between Comments');
define('AI_TEXT_AFTER_COMMENTS',       'After Comments');
define('AI_TEXT_ABOVE_HEADER',         'Above Header');
define('AI_TEXT_FOOTER',               'Footer');

//Display options
define('AD_DISPLAY_ALL_USERS','all users');
define('AD_DISPLAY_LOGGED_IN_USERS','logged in users');
define('AD_DISPLAY_NOT_LOGGED_IN_USERS','not logged in users');
define('AD_DISPLAY_ADMINISTRATORS','administrators');

define('AD_DISPLAY_ALL_DEVICES','all');
define('AD_DISPLAY_DESKTOP_DEVICES','desktop');
define('AD_DISPLAY_MOBILE_DEVICES','mobile');
define('AD_DISPLAY_TABLET_DEVICES','tablet');
define('AD_DISPLAY_PHONE_DEVICES','phone');
define('AD_DISPLAY_DESKTOP_TABLET_DEVICES','desktop and tablet');
define('AD_DISPLAY_DESKTOP_PHONE_DEVICES','desktop and phone');

//Direction options
define('AD_DIRECTION_FROM_TOP','From Top');
define('AD_DIRECTION_FROM_BOTTOM','From Bottom');

//Post-Page options
// Deprecated
define('AD_ENABLED_ON_ALL',                     'On all');
define('AD_ENABLED_ON_ALL_EXCEPT_ON_SELECTED',  'On all except selected');
define('AD_ENABLED_ONLY_ON_SELECTED',           'Only on selected');

define('AI_NO_INDIVIDUAL_EXCEPTIONS',           0);
define('AI_INDIVIDUALLY_DISABLED',              1);
define('AI_INDIVIDUALLY_ENABLED',               2);

define('AI_TEXT_NO_INDIVIDUAL_EXCEPTIONS',      '');
define('AI_TEXT_INDIVIDUALLY_DISABLED',         'Individually disabled');
define('AI_TEXT_INDIVIDUALLY_ENABLED',          'Individually enabled');

//Alignment options - Deprecated
define('AD_ALIGNMENT_NO_WRAPPING','No Wrapping');
define('AD_ALIGNMENT_CUSTOM_CSS','Custom CSS');
define('AD_ALIGNMENT_NONE','None');
define('AD_ALIGNMENT_LEFT','Align Left');
define('AD_ALIGNMENT_RIGHT','Align Right');
define('AD_ALIGNMENT_CENTER','Center');
define('AD_ALIGNMENT_FLOAT_LEFT','Float Left');
define('AD_ALIGNMENT_FLOAT_RIGHT','Float Right');

define('AI_ALIGNMENT_DEFAULT',        0);
define('AI_ALIGNMENT_LEFT',           1);
define('AI_ALIGNMENT_RIGHT',          2);
define('AI_ALIGNMENT_CENTER',         3);
define('AI_ALIGNMENT_FLOAT_LEFT',     4);
define('AI_ALIGNMENT_FLOAT_RIGHT',    5);
define('AI_ALIGNMENT_NO_WRAPPING',    6);
define('AI_ALIGNMENT_CUSTOM_CSS',     7);
define('AI_ALIGNMENT_STICKY_LEFT',    8);
define('AI_ALIGNMENT_STICKY_RIGHT',   9);
define('AI_ALIGNMENT_STICKY_TOP',    10);
define('AI_ALIGNMENT_STICKY_BOTTOM', 11);

define('AI_TEXT_DEFAULT',             'Default');
define('AI_TEXT_LEFT',                'Align Left');
define('AI_TEXT_RIGHT',               'Align Right');
define('AI_TEXT_CENTER',              'Center');
define('AI_TEXT_FLOAT_LEFT',          'Float Left');
define('AI_TEXT_FLOAT_RIGHT',         'Float Right');
define('AI_TEXT_NO_WRAPPING',         'No Wrapping');
define('AI_TEXT_CUSTOM_CSS',          'Custom CSS');
define('AI_TEXT_STICKY_LEFT',         'Sticky Left');
define('AI_TEXT_STICKY_RIGHT',        'Sticky Right');
define('AI_TEXT_STICKY_TOP',          'Sticky Top');
define('AI_TEXT_STICKY_BOTTOM',       'Sticky Bottom');

define('AI_ALIGNMENT_CSS_DEFAULT',        'margin: 8px 0; clear: both;');
define('AI_ALIGNMENT_CSS_LEFT',           'margin: 8px 0; text-align: left; clear: both;||margin: 8px 0; text-align: left; clear: both; display: flex; justify-content: flex-start;');
define('AI_ALIGNMENT_CSS_RIGHT',          'margin: 8px 0; text-align: right; clear: both;||margin: 8px 0; text-align: right; clear: both; display: flex; justify-content: flex-end;');
define('AI_ALIGNMENT_CSS_CENTER',         'margin: 8px auto; text-align: center; clear: both;||margin: 8px 0; text-align: center; clear: both; display: flex; justify-content: center;');
define('AI_ALIGNMENT_CSS_FLOAT_LEFT',     'margin: 8px 8px 8px 0; float: left;');
define('AI_ALIGNMENT_CSS_FLOAT_RIGHT',    'margin: 8px 0 8px 8px; float: right;');
define('AI_ALIGNMENT_CSS_STICKY_LEFT',    'position: fixed; left: 0px; top: 100px; z-index: 9999;');
define('AI_ALIGNMENT_CSS_STICKY_RIGHT',   'position: fixed; right: 0px; top: 100px; z-index: 9999;');
define('AI_ALIGNMENT_CSS_STICKY_TOP',     'position: fixed; top: 0; left: 0; width: 100%; text-align: center; z-index: 9999;||position: fixed; top: 0; left: 0; width: 100%; text-align: center; display: flex; justify-content: center; z-index: 9999;');
define('AI_ALIGNMENT_CSS_STICKY_BOTTOM',  'position: fixed; bottom: 0; left: 0; width: 100%; text-align: center; z-index: 9999;||position: fixed; bottom: 0; left: 0; width: 100%; text-align: center; display: flex; justify-content: center; z-index: 9999;');

//List Type
define('AD_BLACK_LIST','Black List');
define('AD_WHITE_LIST','White List');

//Filter Type - Deprecated
define ('AI_OPTION_FILTER_AUTO',                    'Auto');
define ('AI_OPTION_FILTER_PHP_FUNCTION_CALLS',      'PHP function calls');
define ('AI_OPTION_FILTER_CONTENT_PROCESSING',      'Content processing');
define ('AI_OPTION_FILTER_EXCERPT_PROCESSING',      'Excerpt processing');
define ('AI_OPTION_FILTER_BEFORE_POST_PROCESSING',  'Before post processing');
define ('AI_OPTION_FILTER_AFTER_POST_PROCESSING',   'After post processing');
define ('AI_OPTION_FILTER_WIDGET_DRAWING',          'Widget drawing');
define ('AI_OPTION_FILTER_SUBPAGES',                'Subpages');
define ('AI_OPTION_FILTER_POSTS',                   'Posts');
define ('AI_OPTION_FILTER_COMMENTS',                'Comments');


//Filter Type
define ('AI_FILTER_AUTO',                    0);
define ('AI_FILTER_PHP_FUNCTION_CALLS',      1);
define ('AI_FILTER_CONTENT_PROCESSING',      2);
define ('AI_FILTER_EXCERPT_PROCESSING',      3);
define ('AI_FILTER_BEFORE_POST_PROCESSING',  4);
define ('AI_FILTER_AFTER_POST_PROCESSING',   5);
define ('AI_FILTER_WIDGET_DRAWING',          6);
define ('AI_FILTER_SUBPAGES',                7);
define ('AI_FILTER_POSTS',                   8);
define ('AI_FILTER_PARAGRAPHS',              9);
define ('AI_FILTER_COMMENTS',               10);


define ('AI_TEXT_AUTO',                    'Auto');
define ('AI_TEXT_PHP_FUNCTION_CALLS',      'PHP function calls');
define ('AI_TEXT_CONTENT_PROCESSING',      'Content processing');
define ('AI_TEXT_EXCERPT_PROCESSING',      'Excerpt processing');
define ('AI_TEXT_BEFORE_POST_PROCESSING',  'Before post processing');
define ('AI_TEXT_AFTER_POST_PROCESSING',   'After post processing');
define ('AI_TEXT_WIDGET_DRAWING',          'Widget drawing');
define ('AI_TEXT_SUBPAGES',                'Subpages');
define ('AI_TEXT_POSTS',                   'Posts');
define ('AI_TEXT_PARAGRAPHS',              'Paragraphs');
define ('AI_TEXT_COMMENTS',                'Comments');



//Counter names
define ('AI_BLOCK_COUNTER_NAME',                    'AI_BLOCK_COUNTER_');
define ('AI_PHP_FUNCTION_CALL_COUNTER_NAME',        'AI_PHP_FUNCTION_CALL_COUNTER_');
define ('AI_CONTENT_COUNTER_NAME',                  'AI_CONTENT_COUNTER');
define ('AI_EXCERPT_COUNTER_NAME',                  'AI_EXCERPT_COUNTER');
define ('AI_LOOP_BEFORE_COUNTER_NAME',              'AI_LOOP_START_COUNTER');
define ('AI_LOOP_AFTER_COUNTER_NAME',               'AI_LOOP_END_COUNTER');
define ('AI_WIDGET_COUNTER_NAME',                   'AI_WIDGET_COUNTER_');
define ('AI_POST_COUNTER_NAME',                     'AI_THE_POST_COUNTER');
define ('AI_COMMENT_COUNTER_NAME',                  'AI_COMMENT_COUNTER');
define ('AI_ADB_FALLBACK_DEPTH_NAME',               'AI_ADB_FALLBACK_DEPTH');

//Text List Type
define('AD_CONTAIN','contain');
define('AD_DO_NOT_CONTAIN','do not contain');

//Avoid text action
define('AD_DO_NOT_INSERT','do not insert');
define('AD_TRY_TO_SHIFT_POSITION','try to shift position');

define('AD_ABOVE','above');
define('AD_BELOW','below');
define('AD_ABOVE_AND_THEN_BELOW','above and then below');
define('AD_BELOW_AND_THEN_ABOVE','below and then above');

// Scheduling
define('AI_SCHEDULING_OFF',             0);
define('AI_SCHEDULING_DELAY',           1);
define('AI_SCHEDULING_BETWEEN_DATES',   2);

define('AI_TEXT_OFF',                   'Insert immediately');
define('AI_TEXT_DELAY_INSERTION',       'Delay insertion');
define('AI_TEXT_INSERT_BETWEEN_DATES',  'Insert between dates');

// Dynamic blocks
define('AI_DYNAMIC_BLOCKS_SERVER_SIDE',       0);
define('AI_DYNAMIC_BLOCKS_CLIENT_SIDE',       1);
define('AI_DYNAMIC_BLOCKS_SERVER_SIDE_W3TC',  2);

define('AI_TEXT_SERVER_SIDE',           'Server-side');
define('AI_TEXT_CLIENT_SIDE',           'Client-side');
define('AI_TEXT_SERVER_SIDE_W3TC',      'Server-side using W3 Total Cache');

// Paragraph counting functions
define('AI_STANDARD_PARAGRAPH_COUNTING_FUNCTIONS',       0);
define('AI_MULTIBYTE_PARAGRAPH_COUNTING_FUNCTIONS',      1);

define('AI_TEXT_STANDARD',           'Standard');
define('AI_TEXT_MULTIBYTE',          'Multibyte');

// Tracking
define('AI_TRACKING_DISABLED',       0);
define('AI_TRACKING_ENABLED',        1);

define('AI_TRACKING_INTERNAL',       0);

// Ad Blocking
define ('AI_ADB_ACTION_NONE',             0);
define ('AI_ADB_ACTION_MESSAGE',          1);
define ('AI_ADB_ACTION_REDIRECTION',      2);

define ('AI_TEXT_NONE',               'None');
define ('AI_TEXT_POPUP_MESSAGE',      'Popup Message');
define ('AI_TEXT_REDIRECTION',        'Redirection');

define ('AI_ADB_BLOCK_ACTION_DO_NOTHING', 0);
define ('AI_ADB_BLOCK_ACTION_REPLACE',    1);
define ('AI_ADB_BLOCK_ACTION_SHOW',       2);
define ('AI_ADB_BLOCK_ACTION_HIDE',       3);

define ('AI_TEXT_DO_NOTHING',             'Do nothnig');
define ('AI_TEXT_REPLACE',                'Replace');
define ('AI_TEXT_SHOW',                   'Show');
define ('AI_TEXT_HIDE',                   'Hide');

// Click detection
define ('AI_CLICK_DETECTION_STANDARD', 0);
define ('AI_CLICK_DETECTION_ADVANCED', 1);

define ('AI_TEXT_INTERNAL',           'Internal');
define ('AI_TEXT_ADVANCED',           'Advanced');
define ('AI_TEXT_ENABLED',            'Enabled');

// Sticky widget mode
define ('AI_STICKY_WIDGET_MODE_CSS', 0);
define ('AI_STICKY_WIDGET_MODE_JS',  1);

define ('AI_TEXT_CSS', 'CSS');
define ('AI_TEXT_JS',  'JavaScript ');

//Settings
define ('AI_ENABLED',                '1');
define ('AI_DISABLED',               '0');

define ('AI_COOKIE_TIME', 3600);

define ('AI_TRANSIENT_RATING',                  'ai-rating');
define ('AI_TRANSIENT_RATING_EXPIRATION',       48 * 3600);

define ('AI_TRANSIENT_ADB_CLASS_1',             'ai-adb-class-1');
define ('AI_TRANSIENT_ADB_CLASS_2',             'ai-adb-class-2');
define ('AI_TRANSIENT_ADB_CLASS_3',             'ai-adb-class-3');
define ('AI_TRANSIENT_ADB_CLASS_4',             'ai-adb-class-4');
define ('AI_TRANSIENT_ADB_CLASS_5',             'ai-adb-class-5');
define ('AI_TRANSIENT_ADB_CLASS_6',             'ai-adb-class-6');
define ('AI_TRANSIENT_ADB_CLASS_EXPIRATION',    48 * 3600);

define ('AI_TRANSIENT_ADB_FILES_VERSION',       'ai-adb-version');

define ('AI_SYNTAX_HIGHLIGHTER_THEME',          'ad_inserter');
define ('DEFAULT_SYNTAX_HIGHLIGHTER_THEME',     AI_SYNTAX_HIGHLIGHTER_THEME);
define ('DEFAULT_BLOCK_CLASS_NAME',             'code-block');
define ('DEFAULT_MINIMUM_USER_ROLE',            'administrator');
define ('DEFAULT_STICKY_WIDGET_MODE',           AI_STICKY_WIDGET_MODE_CSS);
define ('DEFAULT_STICKY_WIDGET_MARGIN',         15);
define ('DEFAULT_PLUGIN_PRIORITY',              99999);
define ('DEFAULT_DYNAMIC_BLOCKS',               AI_DYNAMIC_BLOCKS_SERVER_SIDE);
define ('DEFAULT_PARAGRAPH_COUNTING_FUNCTIONS', AI_STANDARD_PARAGRAPH_COUNTING_FUNCTIONS);
define ('DEFAULT_NO_PARAGRAPH_COUNTING_INSIDE', 'blockquote, figure, li');
define ('DEFAULT_PARAGRAPH_TAGS',               'p');
define ('DEFAULT_ADMIN_TOOLBAR_DEBUGGING',      AI_ENABLED);
define ('DEFAULT_REMOTE_DEBUGGING',             AI_DISABLED);
define ('DEFAULT_JAVASCRIPT_DEBUGGING',         AI_DISABLED);
define ('DEFAULT_MULTISITE_SETTINGS_PAGE',      AI_ENABLED);
define ('DEFAULT_MULTISITE_WIDGETS',            AI_ENABLED);
define ('DEFAULT_MULTISITE_PHP_PROCESSING',     AI_ENABLED);
define ('DEFAULT_MULTISITE_EXCEPTIONS',         AI_ENABLED);
define ('DEFAULT_MULTISITE_MAIN_FOR_ALL_BLOGS', AI_DISABLED);
define ('DEFAULT_TRACKING',                     AI_TRACKING_DISABLED);
define ('DEFAULT_TRACKING_MODE',                AI_TRACKING_INTERNAL);
define ('DEFAULT_TRACKING_LOGGED_IN',           AI_TRACKING_ENABLED);
define ('DEFAULT_TRACK_PAGEVIEWS',              AI_TRACKING_DISABLED);
define ('DEFAULT_CLICK_DETECTION',              AI_CLICK_DETECTION_STANDARD);
define ('DEFAULT_ADB_BLOCK_ACTION',             AI_ADB_BLOCK_ACTION_DO_NOTHING);
define ('DEFAULT_CUSTOM_HOOK_PRIORITY',         10);

define ('AI_ADBLOCKING_DETECTION',              true);
define ('AI_AMP_HEADER_STYLES',                 true);
//define ('AI_CODE_GENERATOR',                    true);
//define ('AI_BUFFERING',                         true);
define ('AI_ADB_1_NAME',                        'dqwpediwqswqma');
define ('AI_ADB_2_DEFAULT_NAME',                'lfoswyekaaslsd');
define ('AI_ADB_CONTENT_CSS_BEGIN',             'ai-adb-content-begin');
define ('AI_ADB_CONTENT_CSS_END',               'ai-adb-content-end');
define ('AI_ADB_CONTENT_DELETE_BEGIN',          'ai-adb-delete-begin');
define ('AI_ADB_CONTENT_DELETE_END',            'ai-adb-delete-end');
define ('AI_ADB_CONTENT_REPLACE_BEGIN',         'ai-adb-replace-begin');
define ('AI_ADB_CONTENT_REPLACE_END',           'ai-adb-replace-end');
define ('AI_BASIC_ADB_OVERLAY_CSS',             "position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 99998; user-select: none;");
define ('AI_DEFAULT_ADB_OVERLAY_CSS',           "background: #000; opacity: 0.85;");
define ('AI_BASIC_ADB_MESSAGE_CSS',             "position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 99999; background: #000; color: #fff; user-select: none;");
define ('AI_DEFAULT_ADB_MESSAGE_CSS',           "width: 300px; padding: 10px; border: 5px solid #f00; border-radius: 5px;");
define ('AI_DEFAULT_ADB_MESSAGE',               "<p><strong>Blocked because of Ad Blocker</strong></p>\n<p>It seems that you are using some ad blocking software which is preventing the page from fully loading. Please whitelist this website or disable ad blocking software.</p>");
define ('AI_DEFAULT_ADB_ACTION',                AI_ADB_ACTION_NONE);
define ('AI_DEFAULT_ADB_NO_ACTION_PERIOD',      30);
define ('AI_DEFAULT_ADB_REDIRECTION_PAGE',      0);
define ('AI_DEFAULT_ADB_UNDISMISSIBLE_MESSAGE', AI_DISABLED);
define ('AI_ADB_VERSION_MASK',                  0x7F);
define ('AI_ADB_FLAG_BLOCKED',                  0x80);

define ('DEFAULT_VIEWPORT_NAME_1', "Desktop");
define ('DEFAULT_VIEWPORT_NAME_2', "Tablet");
define ('DEFAULT_VIEWPORT_NAME_3', "Phone");

define ('DEFAULT_VIEWPORT_WIDTH_1', 980);
define ('DEFAULT_VIEWPORT_WIDTH_2', 768);
define ('DEFAULT_VIEWPORT_WIDTH_3', 0);

define ('DEFAULT_COUNTRY_GROUP_NAME', "Group");

define ('CONTENT_HOOK_BLOCKS',          'content_hook');
define ('EXCERPT_HOOK_BLOCKS',          'excerpt_hook');
define ('LOOP_START_HOOK_BLOCKS',       'loop_start_hook');
define ('LOOP_END_HOOK_BLOCKS',         'loop_end_hook');
define ('POST_HOOK_BLOCKS',             'the_post_hook');
define ('BEFORE_COMMENTS_HOOK_BLOCKS',  'before_comments_hook');
define ('BETWEEN_COMMENTS_HOOK_BLOCKS', 'between_comments_hook');
define ('AFTER_COMMENTS_HOOK_BLOCKS',   'after_comments_hook');
define ('FOOTER_HOOK_BLOCKS',           'wp_footer_hook');
define ('ABOVE_HEADER_HOOK_BLOCKS',     'above_header_hook');
define ('CUSTOM_HOOK_BLOCKS',           '_hook');
define ('AI_EXTRACT_USED_BLOCKS',       'used_blocks');

define ('AI_CHECK_NONE',                  - 1);
define ('AI_CHECK_INSERTED',              0);

define ('AI_CHECK_PAGE_TYPE_FRONT_PAGE',  1);
define ('AI_CHECK_PAGE_TYPE_STATIC_PAGE', 2);
define ('AI_CHECK_PAGE_TYPE_POST',        3);
define ('AI_CHECK_PAGE_TYPE_CATEGORY',    4);
define ('AI_CHECK_PAGE_TYPE_SEARCH',      5);
define ('AI_CHECK_PAGE_TYPE_ARCHIVE',     6);
define ('AI_CHECK_PAGE_TYPE_FEED',        7);
define ('AI_CHECK_PAGE_TYPE_404',         8);

define ('AI_CHECK_DESKTOP_DEVICES',       9);
define ('AI_CHECK_MOBILE_DEVICES',        10);
define ('AI_CHECK_TABLET_DEVICES',        11);
define ('AI_CHECK_PHONE_DEVICES',         12);
define ('AI_CHECK_DESKTOP_TABLET_DEVICES',13);
define ('AI_CHECK_DESKTOP_PHONE_DEVICES', 14);

define ('AI_CHECK_CATEGORY',              15);
define ('AI_CHECK_TAG',                   16);
define ('AI_CHECK_URL',                   17);
define ('AI_CHECK_REFERER',               18);
define ('AI_CHECK_SCHEDULING',            19);
define ('AI_CHECK_CODE',                  20);
define ('AI_CHECK_LOGGED_IN_USER',        21);
define ('AI_CHECK_NOT_LOGGED_IN_USER',    22);
define ('AI_CHECK_ADMINISTRATOR',         23);

define ('AI_CHECK_INDIVIDUALLY_DISABLED', 24);
define ('AI_CHECK_INDIVIDUALLY_ENABLED',  25);
define ('AI_CHECK_DISABLED_MANUALLY',     26);
define ('AI_CHECK_MAX_INSERTIONS',        27);
define ('AI_CHECK_FILTER',                28);
define ('AI_CHECK_PARAGRAPH_COUNTING',    29);
define ('AI_CHECK_ENABLED',               30);
define ('AI_CHECK_PARAGRAPHS_MIN_NUMBER', 31);
//define ('AI_CHECK_NUMBER_OF_WORDS',       32);
define ('AI_CHECK_DEBUG_NO_INSERTION',    33);
define ('AI_CHECK_PARAGRAPH_TAGS',        34);
define ('AI_CHECK_PARAGRAPHS_WITH_TAGS',  35);
define ('AI_CHECK_PARAGRAPHS_AFTER_BLOCKQUOTE_FIGURE',    36);
define ('AI_CHECK_PARAGRAPHS_AFTER_MIN_MAX_WORDS', 37);
define ('AI_CHECK_PARAGRAPHS_AFTER_TEXT', 38);
define ('AI_CHECK_PARAGRAPHS_AFTER_CLEARANCE',     39);
define ('AI_CHECK_ID',                    40);
define ('AI_CHECK_URL_PARAMETER',         41);
define ('AI_CHECK_DO_NOT_INSERT',         42);
define ('AI_CHECK_AD_ABOVE',              43);
define ('AI_CHECK_AD_BELOW',              44);
define ('AI_CHECK_SHORTCODE_ATTRIBUTES',  45);
define ('AI_CHECK_COUNTRY',               46);
define ('AI_CHECK_IP_ADDRESS',            47);
define ('AI_CHECK_PARAGRAPH_NUMBER',      48);
define ('AI_CHECK_MIN_NUMBER_OF_WORDS',   49);
define ('AI_CHECK_MAX_NUMBER_OF_WORDS',   50);
define ('AI_CHECK_TAXONOMY',              51);

define ('AI_PT_NONE',                   - 1);
define ('AI_PT_ANY',                      0);
define ('AI_PT_STATIC',                   1);
define ('AI_PT_POST',                     2);
define ('AI_PT_HOMEPAGE',                 3);
define ('AI_PT_CATEGORY',                 4);
define ('AI_PT_ARCHIVE',                  5);
define ('AI_PT_SEARCH',                   6);
define ('AI_PT_404',                      7);
define ('AI_PT_FEED',                     8);
define ('AI_PT_ADMIN',                    9);
define ('AI_PT_AJAX',                    10);

define ('AI_USER_NOT_LOGGED_IN',          0);
define ('AI_USER_LOGGED_IN',              1);
define ('AI_USER_ADMINISTRATOR',          2);

define ('AI_WP_DEBUGGING',                0); // AI_WP_DEBUGGING_
define ('AI_WP_PAGE_TYPE',                1);
define ('AI_WP_USER_SET',                 2);
define ('AI_WP_USER',                     3);
define ('AI_WP_DEBUG_BLOCK',              4);
define ('AI_WP_URL',                      5);
define ('AI_SERVER_SIDE_DETECTION',       6);
define ('AI_CLIENT_SIDE_DETECTION',       7);
define ('AI_CONTEXT',                     8);
define ('AI_TRACKING',                    9);
define ('AI_STICKY_WIDGETS',             10);
define ('AI_NUMBER_OF_COMMENTS',         11);
define ('AI_COMMENTS_SAVED_CALLBACK',    12);
define ('AI_COMMENTS_SAVED_END_CALLBACK',13);
define ('AI_ADB_DETECTION',              14);
define ('AI_JS_DEBUGGING',               15);
define ('AI_WP_AMP_PAGE',                16);
define ('AI_INSTALL_TIME_DIFFERENCE',    17);
define ('AI_DAYS_SINCE_INSTAL',          18);
define ('AI_TAGS',                       19);
define ('AI_VIEWPORTS',                  20);
define ('AI_WORD_COUNT',                 21);
define ('AI_ADB_SHORTCODE_ACTION',       22);

define ('AI_CONTEXT_NONE',                0);
define ('AI_CONTEXT_CONTENT',             1);
define ('AI_CONTEXT_EXCERPT',             2);
define ('AI_CONTEXT_BEFORE_POST',         3);
define ('AI_CONTEXT_AFTER_POST',          4);
define ('AI_CONTEXT_WIDGET',              5);
define ('AI_CONTEXT_PHP_FUNCTION',        6);
define ('AI_CONTEXT_SHORTCODE',           7);
define ('AI_CONTEXT_HTTP_HEADER',         8);
define ('AI_CONTEXT_HEADER',              9);
define ('AI_CONTEXT_FOOTER',             10);
define ('AI_CONTEXT_BETWEEN_POSTS',      11);
define ('AI_CONTEXT_BEFORE_COMMENTS',    12);
define ('AI_CONTEXT_BETWEEN_COMMENTS',   13);
define ('AI_CONTEXT_AFTER_COMMENTS',     14);

define ('AI_URL_DEBUG',                      'ai-debug');               // AI_URL_DEBUG_
define ('AI_URL_DEBUG_PROCESSING',           'ai-debug-processing');    // AI_URL_DEBUG_PROCESSING_
define ('AI_URL_DEBUG_PHP',                  'ai-debug-php');           // AI_URL_DEBUG_PHP
define ('AI_URL_DEBUG_BLOCKS',               'ai-debug-blocks');
define ('AI_URL_DEBUG_USER',                 'ai-debug-user');
define ('AI_URL_DEBUG_TAGS',                 'ai-debug-tags');
define ('AI_URL_DEBUG_POSITIONS',            'ai-debug-positions');
define ('AI_URL_DEBUG_NO_INSERTION',         'ai-debug-no-insertion');
define ('AI_URL_DEBUG_COUNTRY',              'ai-debug-country');
define ('AI_URL_DEBUG_AD_BLOCKING' ,         'ai-debug-adb');
define ('AI_URL_DEBUG_AD_BLOCKING_STATUS',   'ai-debug-adb-status');

define ('AI_DEBUG_PROCESSING',            0x01); // AI_DEBUG_PROCESSING_
define ('AI_DEBUG_BLOCKS',                0x02);
define ('AI_DEBUG_TAGS',                  0x04);
define ('AI_DEBUG_POSITIONS',             0x08);
define ('AI_DEBUG_NO_INSERTION',          0x10);
define ('AI_DEBUG_AD_BLOCKING',           0x20);
define ('AI_DEBUG_AD_BLOCKING_STATUS',    0x40);

if (!defined ('AD_INSERTER_BLOCKS'))
  define ('AD_INSERTER_BLOCKS', 16);

if (!defined ('AD_INSERTER_VIEWPORTS'))
  define ('AD_INSERTER_VIEWPORTS', 3);

if (!defined ('AD_INSERTER_HOOKS'))
  define ('AD_INSERTER_HOOKS', 2);

define ('AI_DEBUG_WIDGET_STYLE',         'margin: 0; padding: 0 5px; font-size: 10px; white-space: pre; overflow-x: auto; overflow-y: hidden;');

define ('AI_DEBUG_TAGS_CLASS',           'ai-debug-tags');
define ('AI_DEBUG_POSITIONS_CLASS',      'ai-debug-positions');
define ('AI_DEBUG_PAGE_TYPE_CLASS',      'ai-debug-page-type');
define ('AI_DEBUG_ADB_CLASS',            'ai-debug-adb');

define ('AI_CODE_UNKNOWN',               0);
define ('AI_CODE_BANNER',                1);
define ('AI_CODE_ADSENSE',               2);

define ('AI_ADSENSE_STANDARD',           0);
define ('AI_ADSENSE_LINK',               1);
define ('AI_ADSENSE_IN_ARTICLE',         2);
define ('AI_ADSENSE_IN_FEED',            3);
define ('AI_ADSENSE_MATCHED_CONTENT',    4);

define ('AI_TEXT_LINK',                 'Link');
define ('AI_TEXT_IN_ARTICLE',           'In-article');
define ('AI_TEXT_IN_FEED',              'In-feed');
define ('AI_TEXT_MATCHED_CONTENT',      'Matched content');

