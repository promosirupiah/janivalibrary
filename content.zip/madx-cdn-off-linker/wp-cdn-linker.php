<?php
/*
Plugin Name: CDN madxer lite
Plugin URI: https://github.com/promosirupiah/
Description: Nggawe CDN versi dewe
Version: 1.3.1
Author:Rachmad Hidayat
Author URI: https://mark.madx.de/
License: GPL
*/

if ( @include_once('base.php') ) {
	add_action('template_redirect', 'do_madx_off_ob_start');
	add_action('template_redirect', 'do_madx1_off_ob_start');
	add_action('template_redirect', 'do_madx2_off_ob_start');
}

/********** WordPress Administrative ********/

function madx_off_activate() {
	add_option('madx_off_cdn_url', get_option('siteurl'));
	add_option('madx_off_include_dirs', 'wp-content,wp-includes');
	add_option('madx_off_exclude', '.php');
	add_option('madx_off_rootrelative', '');
	
	add_option('madx1_off_cdn_url', get_option('siteurl'));
	add_option('madx1_off_include_dirs', 'wp-content,wp-includes');
	add_option('madx1_off_exclude', '.php');
	add_option('madx1_off_rootrelative', '');
	
	add_option('madx2_off_cdn_url', get_option('siteurl'));
	add_option('madx2_off_include_dirs', 'wp-content,wp-includes');
	add_option('madx2_off_exclude', '.php');
	add_option('madx2_off_rootrelative', '');
}
register_activation_hook( __FILE__, 'madx_off_activate');

// This function deletes all settings if the plugin gets deactivated.
function madx_off_deactivate() {
	delete_option('madx_off_cdn_url');
	delete_option('madx_off_include_dirs');
	delete_option('madx_off_exclude');
	delete_option('madx_off_rootrelative');
	
	delete_option('madx1_off_cdn_url');
	delete_option('madx1_off_include_dirs');
	delete_option('madx1_off_exclude');
	delete_option('madx1_off_rootrelative');

	delete_option('madx2_off_cdn_url');
	delete_option('madx2_off_include_dirs');
	delete_option('madx2_off_exclude');
	delete_option('madx2_off_rootrelative');	
}
register_deactivation_hook( __FILE__, 'madx_off_deactivate');

/********** WordPress Interface ********/
add_action('admin_menu', 'madx_off_menu');

function madx_off_menu() {
	add_options_page('CDN madxer lite', 'CDN madxer lite', 8, __FILE__, 'madx_off_options');
}

function madx_off_options() {
	if ( isset($_POST['action']) && ( $_POST['action'] == 'update_madx_off' )){
		update_option('madx_off_cdn_url', $_POST['madx_off_cdn_url']);
		update_option('madx_off_include_dirs', $_POST['madx_off_include_dirs'] == '' ? 'wp-content,wp-includes' : $_POST['madx_off_include_dirs']);
		update_option('madx_off_exclude', $_POST['madx_off_exclude']);
		update_option('madx_off_rootrelative', !!$_POST['madx_off_rootrelative']);
		
		update_option('madx1_off_cdn_url', $_POST['madx1_off_cdn_url']);
		update_option('madx1_off_include_dirs', $_POST['madx1_off_include_dirs'] == '' ? 'wp-content,wp-includes' : $_POST['madx1_off_include_dirs']);
		update_option('madx1_off_exclude', $_POST['madx1_off_exclude']);
		update_option('madx1_off_rootrelative', !!$_POST['madx1_off_rootrelative']);

		update_option('madx2_off_cdn_url', $_POST['madx2_off_cdn_url']);
		update_option('madx2_off_include_dirs', $_POST['madx2_off_include_dirs'] == '' ? 'wp-content,wp-includes' : $_POST['madx2_off_include_dirs']);
		update_option('madx2_off_exclude', $_POST['madx2_off_exclude']);
		update_option('madx2_off_rootrelative', !!$_POST['madx2_off_rootrelative']);		
	}
	$example_cdn_uri = str_replace('http://', 'http://cdn.', str_replace('www.', '', get_option('siteurl')));

	?><div class="wrap">


		<p><form method="post" action="">
		<table class="form-table"><tbody>
			<tr valign="top">
				<th scope="row"><label for="madx_off_cdn_url">CDN URL</label></th>
				<td>
					<input type="text" name="madx_off_cdn_url" value="<?php echo(get_option('madx_off_cdn_url')); ?>" size="64" class="regular-text code" />
					<span class="description">The new URL to be used in place of <?php echo(get_option('siteurl')); ?> for rewriting. No trailing <code>/</code> please. E.g. <code><?php echo($example_cdn_uri); ?></code>.
					</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx_off_rootrelative">rewrite root-relative refs</label></th>
				<td>
					<input type="checkbox"  name="madx_off_rootrelative" <?php echo(!!get_option('madx_off_rootrelative') ? 'checked="1" ' : '') ?>value="true" class="regular-text code" />
					<span class="description">Check this if you want to have madxs like <code><em>/</em>wp-content/xyz.png</code> rewritten - i.e. without your blog's domain as prefix.</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx_off_include_dirs">include dirs</label></th>
				<td>
					<input  type="text" name="madx_off_include_dirs" value="<?php echo(get_option('madx_off_include_dirs')); ?>" size="64" class="regular-text code" />
					<span class="description">Directories to include in static file matching. Use a comma as the delimiter. Default is <code>wp-content, wp-includes</code>, which will be enforced if this field is left empty.</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx_off_exclude">exclude if substring</label></th>
				<td>
					<input  type="text" name="madx_off_exclude" value="<?php echo(get_option('madx_off_exclude')); ?>" size="64" class="regular-text code" />
					<span class="description">Excludes something from being rewritten if one of the above strings is found in the match. Use a comma as the delimiter. E.g. <code>.php, .flv, .do</code>, always include <code>.php</code> (default).</span>
				</td>
			</tr>
		</tbody></table>


	</div>
	
	
<!-- satu -->
<div class="wrap">



		<table class="form-table"><tbody>
			<tr valign="top">
				<th scope="row"><label for="madx1_off_cdn_url">CDN URL</label></th>
				<td>
					<input type="text" name="madx1_off_cdn_url" value="<?php echo(get_option('madx1_off_cdn_url')); ?>" size="64" class="regular-text code" />
					<span class="description">The new URL to be used in place of <?php echo(get_option('siteurl')); ?> for rewriting. No trailing <code>/</code> please. E.g. <code><?php echo($example_cdn_uri); ?></code>.
					</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx1_off_rootrelative">rewrite root-relative refs</label></th>
				<td>
					<input type="checkbox"  name="madx1_off_rootrelative" <?php echo(!!get_option('madx1_off_rootrelative') ? 'checked="1" ' : '') ?>value="true" class="regular-text code" />
					<span class="description">Check this if you want to have madx1s like <code><em>/</em>wp-content/xyz.png</code> rewritten - i.e. without your blog's domain as prefix.</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx1_off_include_dirs">include dirs</label></th>
				<td>
					<input  type="text" name="madx1_off_include_dirs" value="<?php echo(get_option('madx1_off_include_dirs')); ?>" size="64" class="regular-text code" />
					<span class="description">Directories to include in static file matching. Use a comma as the delimiter. Default is <code>wp-content, wp-includes</code>, which will be enforced if this field is left empty.</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx1_off_exclude">exclude if substring</label></th>
				<td>
					<input  type="text" name="madx1_off_exclude" value="<?php echo(get_option('madx1_off_exclude')); ?>" size="64" class="regular-text code" />
					<span class="description">Excludes something from being rewritten if one of the above strings is found in the match. Use a comma as the delimiter. E.g. <code>.php, .flv, .do</code>, always include <code>.php</code> (default).</span>
				</td>
			</tr>
		</tbody></table>


	</div>

<!-- dua -->

<div class="wrap">



		<table class="form-table"><tbody>
			<tr valign="top">
				<th scope="row"><label for="madx2_off_cdn_url">CDN URL</label></th>
				<td>
					<input type="text" name="madx2_off_cdn_url" value="<?php echo(get_option('madx2_off_cdn_url')); ?>" size="64" class="regular-text code" />
					<span class="description">The new URL to be used in place of <?php echo(get_option('siteurl')); ?> for rewriting. No trailing <code>/</code> please. E.g. <code><?php echo($example_cdn_uri); ?></code>.
					</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx2_off_rootrelative">rewrite root-relative refs</label></th>
				<td>
					<input type="checkbox"  name="madx2_off_rootrelative" <?php echo(!!get_option('madx2_off_rootrelative') ? 'checked="1" ' : '') ?>value="true" class="regular-text code" />
					<span class="description">Check this if you want to have madx2s like <code><em>/</em>wp-content/xyz.png</code> rewritten - i.e. without your blog's domain as prefix.</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx2_off_include_dirs">include dirs</label></th>
				<td>
					<input  type="text" name="madx2_off_include_dirs" value="<?php echo(get_option('madx2_off_include_dirs')); ?>" size="64" class="regular-text code" />
					<span class="description">Directories to include in static file matching. Use a comma as the delimiter. Default is <code>wp-content, wp-includes</code>, which will be enforced if this field is left empty.</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="madx2_off_exclude">exclude if substring</label></th>
				<td>
					<input  type="text" name="madx2_off_exclude" value="<?php echo(get_option('madx2_off_exclude')); ?>" size="64" class="regular-text code" />
					<span class="description">Excludes something from being rewritten if one of the above strings is found in the match. Use a comma as the delimiter. E.g. <code>.php, .flv, .do</code>, always include <code>.php</code> (default).</span>
				</td>
			</tr>
		</tbody></table>
		<input type="hidden" name="action" value="update_madx_off" />
		<p class="submit"><input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" /></p>
		</form></p>

	</div>	
	<?php
}
