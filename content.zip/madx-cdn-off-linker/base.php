<?php
/**
 * Reperesents the CDN madxer's rewrite logic.
 *
 * 'rewrite' gets the raw HTML as input and returns the final result.
 * It finds all madxs and runs them through 'rewrite_singe', which prepends the CDN domain.
 *
 * 'CDNmadxsRewriter' contains no WP related function calls and can thus be used in testing or in other software.
 *
 * This is the lite version!
 */
class CDNmadxsRewriter
{
	/** String: the blog's URL ( get_option('siteurl') ) */
	var $blog_url		= null;
	var $cdn_url		= null;
	var $include_dirs	= null;
	var $excludes		= array();
	var $rootrelative	= false;


	function __construct($blog_url, $cdn_url, $include_dirs, array $excludes, $root_relative) {
		$this->blog_url		= $blog_url;
		$this->cdn_url		= $cdn_url;
		$this->include_dirs	= $include_dirs;
		$this->excludes		= $excludes;
		$this->rootrelative	= $root_relative;
	}


	protected function exclude_single(&$match) {
		foreach ($this->excludes as $badword) {
			if (stristr($match, $badword) != false) {
				return true;
			}
		}
		return false;
	}


	protected function rewrite_single(&$match) {
		if ($this->exclude_single($match[0])) {
			return $match[0];
		} else {
			if (!$this->rootrelative || strstr($match[0], $this->blog_url)) {
				return str_replace($this->blog_url, $this->cdn_url, $match[0]);
			} else { // obviously $this->rootrelative is true and we got a root-relative madx - else that case won't happen
				return $this->cdn_url . $match[0];
			}
		}
	}


	protected function include_dirs_to_pattern() {
		$input = explode(',', $this->include_dirs);
		if ($this->include_dirs == '' || count($input) < 1) {
			return 'wp\-content|wp\-includes';
		} else {
			return implode('|', array_map('quotemeta', array_map('trim', $input)));
		}
	}


	public function rewrite(&$content) {
		$dirs = $this->include_dirs_to_pattern();
		$regex = '#(?<=[(\"\'])';
		$regex .= $this->rootrelative
			? ('(?:'.quotemeta($this->blog_url).')?')
			: quotemeta($this->blog_url);
		$regex .= '/(?:((?:'.$dirs.')[^\"\')]+)|([^/\"\']+\.[^/\"\')]+))(?=[\"\')])#';
		return preg_replace_callback($regex, array(&$this, 'rewrite_single'), $content);
	}

}


class CDNmadxsRewriterWordpress extends CDNmadxsRewriter
{
	function __construct() {
		$excl_tmp = get_option('madx_off_exclude');
		$excludes = array_map('trim', explode(',', $excl_tmp));

		parent::__construct(
			get_option('siteurl'),
			get_option('madx_off_cdn_url'),
			get_option('madx_off_include_dirs'),
			$excludes,
			!!get_option('madx_off_rootrelative')
		);
	}


	public function register_as_output_buffer() {
		if ($this->blog_url != get_option('madx_off_cdn_url')) {
			ob_start(array(&$this, 'rewrite'));
		}
	}

}

//satu

class CDNmadx1sRewriterWordpress extends CDNmadxsRewriter
{
	function __construct() {
		$excl_tmp = get_option('madx1_off_exclude');
		$excludes = array_map('trim', explode(',', $excl_tmp));

		parent::__construct(
			get_option('siteurl'),
			get_option('madx1_off_cdn_url'),
			get_option('madx1_off_include_dirs'),
			$excludes,
			!!get_option('madx1_off_rootrelative')
		);
	}


	public function register1_as_output_buffer() {
		if ($this->blog_url != get_option('madx1_off_cdn_url')) {
			ob_start(array(&$this, 'rewrite'));
		}
	}

}

//dua

class CDNmadx2sRewriterWordpress extends CDNmadxsRewriter
{
	function __construct() {
		$excl_tmp = get_option('madx2_off_exclude');
		$excludes = array_map('trim', explode(',', $excl_tmp));

		parent::__construct(
			get_option('siteurl'),
			get_option('madx2_off_cdn_url'),
			get_option('madx2_off_include_dirs'),
			$excludes,
			!!get_option('madx2_off_rootrelative')
		);
	}


	public function register2_as_output_buffer() {
		if ($this->blog_url != get_option('madx2_off_cdn_url')) {
			ob_start(array(&$this, 'rewrite'));
		}
	}

}

function do_madx_off_ob_start() {
	$rewriter = new CDNmadxsRewriterWordpress();
	$rewriter->register_as_output_buffer();
}

function do_madx1_off_ob_start() {
	$rewriter = new CDNmadx1sRewriterWordpress();
	$rewriter->register1_as_output_buffer();
}

function do_madx2_off_ob_start() {
	$rewriter = new CDNmadx2sRewriterWordpress();
	$rewriter->register2_as_output_buffer();
}
