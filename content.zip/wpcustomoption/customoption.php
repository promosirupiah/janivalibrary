<?php
/*
Plugin Name: MADX Custom Dataku
Plugin URI: https://github.com/
Description: Additional Dataku
Version: 1.3.1
Author: Rachmad
Author URI: https://datakuartwork.eu.org/
License: GPL
*/


/********** WordPress Administrative ********/

function dataku_off_activate() {
	add_option('whatsappsatu','');
	add_option('whatsappdua', '');
	add_option('telponsatu', '');
	add_option('tambahan', '');
}
register_activation_hook( __FILE__, 'dataku_off_activate');

// This function deletes all settings if the plugin gets deactivated.
function dataku_off_deactivate() {
	delete_option('whatsappsatu');
	delete_option('whatsappdua');
	delete_option('telponsatu');
	delete_option('tambahan');
}
register_deactivation_hook( __FILE__, 'dataku_off_deactivate');

/********** WordPress Interface ********/
add_action('admin_menu', 'dataku_off_menu');

function dataku_off_menu() {
	add_options_page('datakuer', 'datakuer', 8, __FILE__, 'dataku_off_options');
}

function dataku_off_options() {
	if ( isset($_POST['action']) && ( $_POST['action'] == 'update_dataku_off' )){
		update_option('whatsappsatu', $_POST['whatsappsatu']);
		update_option('whatsappdua', $_POST['whatsappdua']);
		update_option('telponsatu', $_POST['telponsatu']);
		update_option('tambahan',$_POST['tambahan']);
	}


	?><div class="wrap">
		<h2>Data Custom Tambahan<strong style="color: red">lite</strong></h2>

		<p><form method="post" action="">
		<table class="form-table"><tbod>
			<tr valign="top">
				<th scope="row"><label for="whatsappsatu">whatsappsatu</label></th>
				<td>
					<input type="text" name="whatsappsatu" value="<?php echo(get_option('whatsappsatu')); ?>" size="64" class="regular-text code" />
					<span class="description">Whatsapp Satu	</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="whatsappdua">whatsappdua</label></th>
				<td>
					<input type="text" name="whatsappdua" value="<?php echo(get_option('whatsappdua')); ?>" size="64" class="regular-text code" />
					<span class="description">Whatsapp Dua	</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="telponsatu">telponsatu</label></th>
				<td>
					<input type="text" name="telponsatu" value="<?php echo(get_option('telponsatu')); ?>" size="64" class="regular-text code" />
					<span class="description">telponsatu	</span>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="telponsatu">tambahan</label></th>
				<td>
					<input type="text" name="tambahan" value="<?php echo(get_option('tambahan')); ?>" size="64" class="regular-text code" />
					<span class="description">tambahan	</span>
				</td>
			</tr>
		</tbody></table>
		<input type="hidden" name="action" value="update_dataku_off" />
		<p class="submit"><input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" /></p>
		</form></p>

	</div><?php
}
