<div class="notice is-dismissible">
    <p><?php echo esc_html( $this->getMessage() ); ?></p>
</div>
