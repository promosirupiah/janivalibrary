			<h3><?php _e('Placeholders', 'easy-watermark'); ?></h3>
				<p class="description"><?php _e('You can use this placeholders in your text watermark, it will be replaced with proper value just befor applying watermark.', 'easy-watermark'); ?></p>
			<table class="widefat"><tbody>
				<tr><td>%admin_email%</td><td><?php _e('site admin email', 'easy-watermark'); ?></td></tr>
				<tr><td>%blog_name%</td><td><?php _e('blog title', 'easy-watermark'); ?></td></tr>
				<tr><td>%blog_url%</td><td><?php _e('blog url', 'easy-watermark'); ?></td></tr>
				<tr><td>%date%</td><td><?php _e('current date (see general settings for date format)', 'easy-watermark'); ?></td></tr>
				<tr><td>%time%</td><td><?php _e('current time', 'easy-watermark'); ?></td></tr>
			</tbody></table>
