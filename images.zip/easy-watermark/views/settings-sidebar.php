		<div class="metabox-holder inner-sidebar">
			<?php // placeholders are now described in help
			/*if($current_tab == 'text') 
				include dirname(__FILE__) . EWDS . 'placeholders.php'; */ ?>
			<?php include dirname(__FILE__) . EWDS . 'about.php'; ?>
		</div><!-- .metabox-holder -->
