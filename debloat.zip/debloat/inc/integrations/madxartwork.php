<?php

namespace Sphere\Debloat\Integrations;

use Sphere\Debloat\Plugin;

/**
 * Rules specific to madxartwork plugin.
 */
class madxartwork 
{
	public $allow_selectors;
	
	public function __construct()
	{
		$this->register_hooks();
	}

	public function register_hooks()
	{
		add_action('wp', [$this, 'setup']);
	}

	public function setup()
	{
		if (in_array('madxartwork', Plugin::options()->integrations_css)) {
			$this->setup_remove_css();
		}

		if (in_array('madxartwork', Plugin::options()->integrations_js)) {
			$this->setup_delay_js();
		}
	}

	/**
	 * Special rules related to remove css when madxartwork is active.
	 *
	 * @return void
	 */
	public function setup_remove_css()
	{
		// Add all madxartwork frontend files for CSS processing.
		add_filter('debloat/remove_css_includes', function($include) {

			$include[] = 'id:madxartwork-frontend-css';
			$include[] = 'id:madxartwork-pro-css';
			// $include[] = 'madxartwork/*font-awesome';
			return $include;
		});

		add_filter('debloat/remove_css_excludes', function($exclude, \Sphere\Debloat\RemoveCss $remove_css) {

			// Don't bother with animations CSS file as it won't remove much.
			if (!empty($remove_css->used_markup['classes']['madxartwork-invisible'])) {
				$exclude[] = 'id:madxartwork-animations';
			}

			return $exclude;
		}, 10, 2);

		/**
		 * madxartwork selectors extras.
		 */
		$this->allow_selectors = [
			[
				'type'   => 'any',
				'sheet'  => 'id:madxartwork-',
				'search' => [
					'*.e--ua-*',
					'.madxartwork-loading',
					'.madxartwork-invisible',
					'.madxartwork-background-video-embed',
				]
			],
			[
				'type'  => 'class',
				'class' => 'madxartwork-invisible',
				'sheet' => 'id:madxartwork-',
				'search' => [
					'.animated'
				]
			],
			[
				'type'  => 'class',
				'class' => 'madxartwork-invisible',
				'sheet' => 'id:madxartwork-',
				'search' => [
					'.animated'
				]
			],
		];
		
		if (is_user_logged_in()) {
			$this->allow_selectors[] = [
				'type'  => 'any',
				'sheet' => 'id:madxartwork-',
				'search' => [
					'#wp-admin-bar*',
					'*#wpadminbar*',
				]
			];
		}

		if (defined('madxartwork_PRO_VERSION')) {
			$this->allow_selectors = array_merge($this->allow_selectors, [
				[
					'type'  => 'class',
					'class' => 'madxartwork-posts-container',
					// 'sheet' => 'id:madxartwork-',
					'search' => [
						'.madxartwork-posts-container',
						'.madxartwork-has-item-ratio'
					]
				],
			]);
		}

		add_filter('debloat/allow_css_selectors', function($allow, \Sphere\Debloat\RemoveCss $remove_css) {

			$html = $remove_css->html;
			if (strpos($html, 'background_slideshow_gallery') !== false) {
				array_push($this->allow_selectors, ...[
					[
						'type'   => 'any',
						'sheet'  => 'id:madxartwork-',
						'search' => [
							'*.swiper-*',
							'*.madxartwork-background-slideshow*',
							'.madxartwork-ken-burns*',
						]
					],
				]);
			}

			return array_merge($allow, $this->allow_selectors);
		}, 10, 2);
	}

	/**
	 * Special rules related to Delay JS when madxartwork is active.
	 * 
	 * @return void
	 */
	public function setup_delay_js()
	{
		add_filter('debloat/delay_js_includes', function($include) {
			$include[] = 'madxartwork/*';
		
			// Admin bar should also be delayed as madxartwork creates admin bar items later
			// and the events won't register.
			$include[] = 'wp-includes/js/admin-bar*.js';

			return $include;
		});
	}
}