<?php
namespace PublishPress\Permissions\Compat;

class ACF {

}
