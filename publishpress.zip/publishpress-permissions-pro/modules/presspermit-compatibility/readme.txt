== PP Compatibility Pack for WordPress ==
	An extension to the PublishPress Permissions Pro plugin, an advanced content permissions engine and management interface. 
	
	Integration with bbPress, BuddyPress, Co-Authors Plus, WPML, Public Post Preview, Custom Post Type UI, various other plugins. For multisite, provides network-wide permission groups.
	
	WPML: filter exceptions admin UI by language. Mirror post/term permissions to translations.

	Author: Kevin Behrens
	
	Copyright 2020 PublishPress
	
	See license.txt and copyright notices within the code for further details.

	To receive a copy of the current version, one-click updates and expert support, purchase a license key at https://publishpress.com/pricing/
	
== Requirements ==
	Minimum bbPress version: 2.0.2
	bbPress tested up to: 2.5.9
	
== Change Log ==

	When an update is available, bug fixes and other changes made since your currently installed version can be retrieved by clicking the "View version details" link
	in your wp-admin Plugins listing.

	