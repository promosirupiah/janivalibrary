To activate a custom teaser template:
  * create a STYLESHEETPATH/press-permit folder
  * copy the template file into that folder and modify as desired
