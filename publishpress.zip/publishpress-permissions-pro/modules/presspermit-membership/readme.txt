== PP Membership for WordPress ==
	An extension to the PublishPress Permissions Pro plugin, an advanced content permissions engine and management interface. 
	
	Enables permit group membership to be date-limited (either delayed or scheduled for expiration).
	
	Author: Kevin Behrens
	
	Copyright 2020 PublishPress

	See license.txt and copyright notices within the code for further details.

	To receive a copy of the current version, one-click updates and expert support, purchase a license key at https://publishpress.com/pricing/
	
== Change Log ==

	When an update is available, bug fixes and other changes made since your currently installed version can be retrieved by clicking the "View version details" link
	in your wp-admin Plugins listing.