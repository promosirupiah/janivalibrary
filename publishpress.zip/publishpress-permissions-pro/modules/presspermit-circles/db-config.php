<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

global $wpdb;

$wpdb->pp_circles = $wpdb->prefix . 'pp_circles';
