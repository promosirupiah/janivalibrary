<?php
require_once(PRESSPERMIT_PRO_ABSPATH . '/includes-pro/library/Factory.php');
\PublishPress\Permissions\Factory::get_container();
