<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
_deprecated_file( esc_html( basename( __FILE__ ) ), '6.0', '', 'The styler now uses the Embed/Preview/Update header. It uses the same save button as other pages with Form tabs.' );
