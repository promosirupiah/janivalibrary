<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<a href="#" class="button-secondary frm-button-secondary frm-button-sm frm-export-application-button">
	<?php esc_html_e( 'Export', 'formidable-pro' ); ?>
</a>
