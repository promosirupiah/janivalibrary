<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<form action="" method="post">
	<?php $edd_update->pro_cred_form(); ?>
</form>
