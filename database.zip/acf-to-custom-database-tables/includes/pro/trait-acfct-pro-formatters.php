<?php


trait Acfct_pro_formatters
{
	protected function get_flexible_content_formatted_value($acfKeyMap, $key, $value)
	{
		return [];
	}

	protected function get_repeater_formatted_value($acfKeyMap, $key, $value)
	{
		return [];
	}

	protected function get_flexible_content_acf_values($acfFields, $key, $field, $value)
	{
		return [];
	}

}
