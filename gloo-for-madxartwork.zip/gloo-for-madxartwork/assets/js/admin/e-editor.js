jQuery(window).on('load', function () {
    if (madxartwork) {

        // add dark or light theme class to the body tag
        addThemeClass();

        // helper functions
        const addSelectOption = function (id, value, label) {
            jQuery('select[data-setting="' + id + '"]').append(new Option(label, value));
        }

        const updateSelectOption = function (value, label) {
            jQuery('select option[value="' + value + '"]').text(label).closest('select').select2();
            // console.log('updated ' + value);
        }

        const removeSelectOption = function (value) {
            jQuery('select option[value="' + value + '"]').remove();
            // console.log('removed ' + value);
        }

        const correctNamesAfterSort = function (titleName, collection) {
            if (collection.length) {
                jQuery.each(collection.models, function (index, value) {
                    var label = value.attributes[titleName] ? value.attributes[titleName] : 'Item #' + (index + 1)
                    updateSelectOption(value.attributes._id, label);
                });
            }
        }

        const addMissingSelectOptions = function (titleName, selectName, collection) {
            if (collection.length) {
                jQuery.each(collection.models, function (index, value) {
                    if (jQuery('select[data-setting="' + selectName + '"] option[value="' + value.attributes._id + '"]').length < 1) {
                        var label = value.attributes[titleName] ? value.attributes[titleName] : 'Item #' + (index + 1)
                        jQuery('select[data-setting="' + selectName + '"]').append(new Option(label, value.attributes._id));
                    }
                });
            }
        }


        const getEditorControlView = function (id) {
            const editor = madxartwork.getPanelView().getCurrentPageView();
            
            if(typeof editor.getControlModel(id) != 'undefined' && typeof editor.getControlModel(id).cid != 'undefined')
                return editor.children.findByModelCid(editor.getControlModel(id).cid);
        };


        var disableAuto = jQuery('.madxartwork-control-gloo_interactor_disable_auto_update input').is(':checked');

        const linkRepeaterToSelect = function (repeaterName, selectName, titleName) {
            var repeaterControlView = getEditorControlView(repeaterName);
            if(typeof repeaterControlView !='undefined'){
                console.log(repeaterControlView);
                repeaterControlView.collection
                    .on('change', function repeaterChanged(model, repeaterName) {
                        if (disableAuto) {
                            return;
                        }
    
                        if (repeaterName === 'gloo_interactor_events' && typeof (model.changed.gloo_interactor_event_next_status) !== 'undefined' && model.changed.gloo_interactor_event_next_status === 'yes') {
                            //events
                            if (model.collection.length) {
                                jQuery.each(model.collection.models, function (index, value) {
                                    var parentElement = 'input[value="' + model.attributes._id + '"]';
                                    if (jQuery(parentElement).closest('.madxartwork-repeater-fields').find('select[data-setting="' + 'gloo_interactor_event_next' + '"] option[value="' + value.attributes._id + '"]').length < 1) {
                                        var label = value.attributes[titleName] ? value.attributes[titleName] : 'Item #' + (index + 1)
                                        jQuery(parentElement).closest('.madxartwork-repeater-fields').find('select[data-setting="' + 'gloo_interactor_event_next' + '"]').append(new Option(label, value.attributes._id));
                                    }
                                });
                            }
    
                        }
    
                        var optionLabel = model.attributes[titleName],
                            optionValue = model.attributes._id;
    
                        if (!optionLabel) {
                            optionLabel = 'Item #' + model.collection.length;
                        }
    
                        updateSelectOption(optionValue, optionLabel);
                    })
                    .on('update', (collection, update) => {
                        if (disableAuto) {
                            return;
                        }
                        // prevent adding if its just sorting
                        if (update.add && (collection.length == update.at + 1)) {
                            var optionLabel = 'Item #' + (update.at + 1),
                                optionValue = collection.models[update.at].attributes._id;
    
                            if (collection.models[update.at].attributes[titleName]) {
                                optionLabel = collection.models[update.at].attributes[titleName];
                            }
    
                            // console.log(update);
                            if (optionValue) {
    
                                if (repeaterName === 'gloo_interactor_events') {
                                    var select = jQuery('.madxartwork-control:not(.madxartwork-hidden-control) select[data-setting="' + 'gloo_interactor_event_next' + '"]');
                                    if (select.find('option[value="' + optionValue + '"]').length < 1) {
                                    }
                                    jQuery('.madxartwork-control:not(.madxartwork-hidden-control) select[data-setting="' + 'gloo_interactor_event_next' + '"]').append(new Option(optionLabel, optionValue));
                                }
    
                                addSelectOption(selectName, optionValue, optionLabel);
                            }
                            return false;
                            // return console.log('true add:', collection, update);
                        }
    
                        addMissingSelectOptions(titleName, selectName, collection);
                        correctNamesAfterSort(titleName, collection);
                        // return console.log('add on sort:', collection, update);
                    })
                    .on('remove', (model, collection) => {
                        if (disableAuto) {
                            return;
                        }
    
                        var idToRemove = model.attributes._id;
                        // prevent removing if its just sorting
                        if (collection.models.findIndex(x => x.attributes._id === idToRemove) > 0) {
                            // console.log("not removed");
                            return false;
                        }
                        // not sorting, safe to remove
                        removeSelectOption(idToRemove);
                        // console.log('removed:', model);
    
                    });
            }
            
            return false;
        };


        // update connections button
        jQuery('body').on('change', '.madxartwork-control-gloo_interactor_disable_auto_update input', function (e) {
            disableAuto = jQuery(this).is(':checked');
        });

        jQuery(document).one('click', '#madxartwork-panel-page-settings .madxartwork-tab-control-advanced', function () {
            linkAllRepeaters();

            jQuery('.madxartwork-control-gloo_interactor_triggers .madxartwork-repeater-row-item-title').on('click', function () {
                var isClosing = jQuery(this).parent().next().hasClass('editable');
                if (isClosing) {
                    return;
                }
                var selectEl = jQuery(this).parent().next().find('select[data-setting="gloo_interactor_trigger_connect"]');

                // is opening
                var repeaterControlView = getEditorControlView('gloo_interactor_events');
                if (repeaterControlView.collection.length) {
                    jQuery.each(repeaterControlView.collection.models, function (index, value) {

                        // console.log("selectEl");
                        // console.log(selectEl);

                        if (jQuery(selectEl).find('option[value="' + value.attributes._id + '"]').length < 1) {
                            var label = value.attributes['gloo_interactor_event_title'] ? value.attributes['gloo_interactor_event_title'] : 'Item #' + (index + 1)
                            jQuery(selectEl).append(new Option(label, value.attributes._id));
                        }
                    });
                }

                // console.log(isClosing);
            });
        });


        jQuery("#madxartwork-panel-header-menu-button").after('<div class="gloo_go_to_interactor"></div>');
        jQuery('body').on('click', '.gloo_go_to_interactor', function (e) {
            //jQuery(".madxartwork-tab-control-advanced").trigger('click');
            jQuery("#madxartwork-panel-footer-settings").trigger('click');
            jQuery("#madxartwork-panel-page-settings .madxartwork-tab-control-advanced").trigger('click');
            e.preventDefault();
            return false;
        });




        function linkAllRepeaters() {
            // repeater, select, title
            linkRepeaterToSelect('gloo_interactor_triggers', 'gloo_interactor_condition_triggers', 'gloo_interactor_trigger_title');
            // linkRepeaterToSelect('gloo_interactor_events', 'gloo_interactor_trigger_connect', 'gloo_interactor_event_title');
            linkRepeaterToSelect('gloo_interactor_variables', 'gloo_dl_connector_interactor_variables', 'gloo_interactor_variable_name');
            linkRepeaterToSelect('gloo_dl_connector_', 'gloo_dl_connector_triggers', 'gloo_dl_connector_title');
        }

        function gloo_interactor_active() {
            if (jQuery(".madxartwork-tab-control-advanced").length >= 1) {
                if (jQuery("#madxartwork-panel-page-settings .madxartwork-tab-control-advanced").hasClass("madxartwork-active")) {
                    jQuery(".gloo_go_to_interactor").addClass("gloo-active");
                } else {
                    jQuery(".gloo_go_to_interactor").removeClass("gloo-active");
                }
            } else if (jQuery(".gloo_go_to_interactor").length >= 1) {
                jQuery(".gloo_go_to_interactor").removeClass("gloo-active");
            }
        }

        jQuery('html').on('click', function () {
            gloo_interactor_active();
        });

        jQuery(document).on('DOMNodeInserted', 'body', function (e) {
            gloo_interactor_active();
        });

        // add dark or light theme class to the body tag
        function addThemeClass() {
            var uiTheme = madxartwork.settings.editorPreferences.model.get('ui_theme'),
                userPrefersDark = matchMedia('(prefers-color-scheme: dark)').matches,
                uiThemeClass = 'dark' === uiTheme || 'auto' === uiTheme && userPrefersDark ? 'dark' : 'light';

            if (uiTheme) {
                jQuery('body').addClass('gloo-editor-theme-' + uiThemeClass);
            }

            jQuery('body').on('change', '.madxartwork-control-ui_theme :input', function (e) {
                uiTheme = madxartwork.settings.editorPreferences.model.get('ui_theme');
                if ('dark' === uiTheme || 'auto' === uiTheme && userPrefersDark) {
                    //dark
                    jQuery('body').addClass('gloo-editor-theme-dark').removeClass('gloo-editor-theme-light')
                } else {
                    // light
                    jQuery('body').addClass('gloo-editor-theme-light').removeClass('gloo-editor-theme-dark')
                }
            });
        }
    }
});