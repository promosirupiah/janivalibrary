jQuery( function( $ ) {
    //Make the DIV element draggagle:
    $( ".gloo-draggable-item" ).draggable({
        classes: {
            "ui-draggable": "move"
        }
    });
});
