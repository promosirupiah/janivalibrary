<?php
namespace ByteBunch\FluidDynamics;

class madxartworkWidget extends \madxartwork\Widget_Base {

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'gloo_for_madxartwork' ),
			]
		);

		$this->add_control(
			'google_autocomplete',
			[
				'label' => __( 'Google Autocomplete', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'placeholder' => __( 'Google Autocomplete', 'gloo_for_madxartwork' ),
			]
		);

		$this->end_controls_section();

	}

}