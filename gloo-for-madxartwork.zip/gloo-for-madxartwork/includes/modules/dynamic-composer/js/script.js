//String.prototype.cleanup = function() {
 //   return this.toLowerCase().replace(/[^a-zA-Z0-9]+/g, "");
 //}


 //jQuery( document ).ready(function($) {

   // $(document).on('DOMNodeInserted', 'body', function (e) {
        /*$('.otw_variable_name').find("input[type='text']").each(function(){
            $(this).on("keypress", function(){
                newValue = "["+$(this).val().cleanup()+"]";
                $(this).val(newValue);
                //$(this).parents(".madxartwork-repeater-fields").find(".madxartwork-repeater-row-item-title").text(newValue);
            });
        });*/

        /*$('.otw_variable_name').find("input[type='text']").on("keypress", function(){
            newValue = "["+$(this).val().cleanup()+"]";
            $(this).val(newValue);
            $(this).parents(".madxartwork-repeater-fields").find(".madxartwork-repeater-row-item-title").text(newValue);
        });*/

        /*$('.otw_variable_name').find("input[type='text']").each(function(){
            newValue = "["+$(this).val().cleanup()+"]";
            $(this).val(newValue);
            //$(this).parents(".madxartwork-repeater-fields").find(".madxartwork-repeater-row-item-title").text(newValue);
        });*/
    //});


    
    //console.log($('.otw_variable_name'));
    /**/

    /*$('.otw_variable_name').find("input[type='text']").on('keypress', function(){
        alert("sdf");
    });*/
//});
 