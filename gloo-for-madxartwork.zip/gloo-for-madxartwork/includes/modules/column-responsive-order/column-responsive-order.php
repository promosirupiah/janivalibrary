<?php
/**
 * Gloo Column Responsive Order module
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( ! class_exists( 'Gloo_Module_Column_Responsive_Order' ) ) {

	/**
	 * Define Gloo_Module_Column_Responsive_Order class
	 */
	class Gloo_Module_Column_Responsive_Order extends Gloo_Module_Base {

		public $instance = null;

		/**
		 * Module ID
		 *
		 * @return string
		 */
		public function module_id() {
			return 'gloo_column_responsive_order';
		}

		/**
		 * Module name
		 *
		 * @return string
		 */
		public function module_name() {
			return __( 'Column Responsive Order', 'gloo_for_madxartwork' );
		}

		/**
		 * Module init
		 *
		 * @return void
		 */
		public function module_init() {
			add_action( 'gloo/init', array( $this, 'create_instance' ) );
		}

		/**
		 * Create module instance
		 *
		 * @return [type] [description]
		 */
		public function create_instance(  ) {
			require  gloo()->modules_path( 'column-responsive-order/inc/module.php' );
			$this->instance = \Gloo\Modules\Column_Responsive_Order\Module::instance();
		}

	}

}
