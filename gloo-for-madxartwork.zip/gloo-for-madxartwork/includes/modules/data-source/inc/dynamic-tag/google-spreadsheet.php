<?php
namespace Gloo\Modules\Data_Source;

Class Tag_Maker extends \madxartwork\Core\DynamicTags\Tag {

	/**
	 * Get Name
	 *
	 * Returns the Name of the tag
	 *
	 * @since 2.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_name() {
		return 'gloo-tag-maker';
	}

	/**
	 * Get Title
	 *
	 * Returns the title of the Tag
	 *
	 * @since 2.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'Google Spreadsheet Tag', 'gloo_for_madxartwork' );
	}

	/**
	 * Get Group
	 *
	 * Returns the Group of the tag
	 *
	 * @since 2.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_group() {
		return 'gloo-dynamic-tags';
	}

	/**
	 * Get Categories
	 *
	 * Returns an array of tag categories
	 *
	 * @since 2.0.0
	 * @access public
	 *
	 * @return array
	 */
	public function get_categories() {
		return [ 
			\madxartwork\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\madxartwork\Modules\DynamicTags\Module::URL_CATEGORY,
			\madxartwork\Modules\DynamicTags\Module::POST_META_CATEGORY
		];
	}

	/**
	 * Register Controls
	 *
	 * Registers the Dynamic tag controls
	 *
	 * @return void
	 * @since 2.0.0
	 * @access protected
	 *
	 */
	protected function _register_controls() {

		$tags = array();

		$args = array(
			'post_type' => 'gloo_dtm',
			'posts_per_page' => -1,
		);
		
		$posts = get_posts($args);

		if(!empty($posts)) {
			foreach($posts as $dtm) {
				$tags[$dtm->ID] = $dtm->post_title;
			}
		}
		$tags['custom_cpt_id'] = 'Custom ID';

		$this->add_control(
			'select_tag',
			array(
				'label'   => __( 'Select Tag', 'gloo_for_madxartwork' ),
				'type'    => \madxartwork\Controls_Manager::SELECT,
				'options' => $tags,
			)
		);

		$this->add_control(
			'acf_rel_key',
			array(
				'label'   => __( 'ACF Relation Field Key (Optional)', 'gloo_for_madxartwork' ),
				'label_block' => true,
				'type'    => \madxartwork\Controls_Manager::TEXT,
				'condition' => [
					'select_tag' => 'custom_cpt_id',
				]
			)
		);

		$this->add_control(
			'horizontal_cell',
			array(
				'label'     => __( 'Horizontal Cell', 'gloo_for_madxartwork' ),
				'type'      => \madxartwork\Controls_Manager::TEXT,
			)
		);

		$this->add_control(
			'vertical_cell',
			array(
				'label'     => __( 'Vertical Cell', 'gloo_for_madxartwork' ),
				'type'      => \madxartwork\Controls_Manager::TEXT,
			)
		);
	}

	public function render() {
		
		$select_tag = $this->get_settings( 'select_tag' );
		$horizontal_cell = $this->get_settings( 'horizontal_cell' );
		$vertical_cell = $this->get_settings( 'vertical_cell' );
		$acf_rel_key = $this->get_settings( 'acf_rel_key' );
  
		if( !empty( $select_tag ) ) {

			if( $select_tag == 'custom_cpt_id' ) {

				if( !empty( $acf_rel_key ) ) {
					
					$post_data = [];

					$acf_id_prefix = '';
				
					if ( is_tax() || is_category()) {
						$acf_id_prefix = get_queried_object()->taxonomy . '_';
					}
					if ( is_author() ) {
						$acf_id_prefix = 'user_';
					}

					$relationship_values = get_field( $acf_rel_key, $acf_id_prefix . get_queried_object_id() );

					if(!empty($relationship_values)) {

						$relationship_ids = [];
						if ( $relationship_values && is_array( $relationship_values ) ) {
							// ACF returned object
							if ( isset( $relationship_values[0] ) && is_object( $relationship_values[0] ) && isset( $relationship_values[0]->ID ) ) {
		
								foreach ( $relationship_values as $relationship_value ) {
									$relationship_ids[] = $relationship_value->ID;
								}
							} else {
								// ACF returned IDs
								$relationship_ids = $relationship_values;
							}
						}
					}

					if( isset( $relationship_ids[0] ) && !empty( $relationship_ids[0] ) ) {
						$select_tag = $relationship_ids[0];
					}
				}
			}	

			$spreadsheet_data =  json_decode(get_post_meta( $select_tag, 'spreadsheet_data', true ));

			if(!empty($spreadsheet_data) && !empty($horizontal_cell) && !empty($vertical_cell) && is_numeric($horizontal_cell)) {
				$horizontal_index = $horizontal_cell - 1;
				$vertical_index = $this->get_alphabet_position($vertical_cell);
				
				if(isset($spreadsheet_data[$horizontal_index][$vertical_index])) {
					echo $spreadsheet_data[$horizontal_index][$vertical_index];
				}
			}
		}
	}

	public function get_alphabet_position($letter) {
		// Declare an empty array 
		$array = array(); 
	
		for( $i = 65; $i < 91; $i++) {
			$array[] = chr($i); 
		} 

		if(!empty($letter)) {
 			return array_search($letter, $array); // $key = 2;
		}
	}
}