<?php
namespace Gloo\Modules\BB_Group_Dynamic_Tags;

class BuddyBos_Group_Settings extends \madxartwork\Core\DynamicTags\Tag {

	/**
	 * Get Name
	 *
	 * Returns the Name of the tag
	 *
	 * @return string
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'buddyboss-group-settings';
	}

	/**
	 * Get Title
	 *
	 * Returns the title of the Tag
	 *
	 * @return string
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'BuddyBoss Group Settings', 'gloo_for_madxartwork' );
	}

	/**
	 * Get Group
	 *
	 * Returns the Group of the tag
	 *
	 * @return string
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_group() {
		return 'gloo-dynamic-tags';
	}

	/**
	 * Get Categories
	 *
	 * Returns an array of tag categories
	 *
	 * @return array
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [
			\madxartwork\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\madxartwork\Modules\DynamicTags\Module::URL_CATEGORY,
			\madxartwork\Modules\DynamicTags\Module::POST_META_CATEGORY
		 ];
	}

	/**
	 * Register Controls
	 *
	 * Registers the Dynamic tag controls
	 *
	 * @return void
	 * @since 2.0.0
	 * @access protected
	 *
	 */
	protected function _register_controls() {

		$this->add_control(
			'group_query',
			array(
				'label'   => __( 'Group', 'gloo_for_madxartwork' ),
				'type'    => \madxartwork\Controls_Manager::SELECT,
				'default' => 'current_group',
				'options' => [
					'current_group' => 'Current Group',
					'queried_group' => 'Queried Group'
				],
			)
		);

		$item_options = array(
			'group_privacy' => 'Group Privacy',
			'invite_status' => 'Invite Status',
			'feed_status' => 'Feed Status',
			'album_status' => 'Album Status',
			'media_status' => 'Media Status',
			'message_status' => 'Message Status'
		);

		$this->add_control(
			'item_output',
			array(
				'label'   => __( 'Items Output', 'gloo_for_madxartwork' ),
				'type'    => \madxartwork\Controls_Manager::SELECT,
				'default' => '',
				'options' => $item_options,
			)
		);

		$output_option = [
			'type_ul'      => 'Ul Structure',
			'type_ol'      => 'Ol Structure',
			'type_limeter' => 'Delimeter',
			'type_lenght'  => 'Array Length',
			'type_array'   => 'Specific Array'
		];

		$this->add_control(
			'field_output',
			array(
				'label'   => __( 'Output Format', 'gloo_for_madxartwork' ),
				'type'    => \madxartwork\Controls_Manager::SELECT,
				'default' => '',
				'options' => $output_option,
			)
		);

		$this->add_control(
			'delimiter',
			array(
				'label'     => __( 'Delimiter', 'gloo_for_madxartwork' ),
				'type'      => \madxartwork\Controls_Manager::TEXT,
				'condition' => [
					'field_output' => 'type_limeter'
				],
			)
		);

		$this->add_control(
			'array_index',
			array(
				'label'     => __( 'Array Index', 'gloo_for_madxartwork' ),
				'type'      => \madxartwork\Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100,
				'condition' => [
					'field_output' => 'type_array'
				],
			)
		);
	}

	public function render() {
		$group_query = $this->get_settings( 'group_query' );
		$queried_group_id = $this->get_settings( 'queried_group_id' );
		$field_output = $this->get_settings( 'field_output' );
		$delimiter = $this->get_settings( 'delimiter' );
		$array_index = $this->get_settings( 'array_index' );
		$item_output = $this->get_settings( 'item_output' );

		$group_id = bp_get_current_group_id();

 		if( $group_query == 'queried_group' ) {
			global $groups_template;
			$group_id =& $groups_template->group->id;
		}

		if( !empty($group_id) ) {
	
			if( $item_output == 'group_privacy' ) {
				
				$group = groups_get_group( $group_id );
				$data[] = $group->status;
				
			} else if( $item_output == 'invite_status' ) {
				$data[] = bp_group_get_invite_status( $group_id );
			} else if( $item_output == 'feed_status' ) { 
				$data[] = bp_group_get_activity_feed_status( $group_id );
			} else if ( $item_output == 'album_status' ) {
				$data[] = bp_group_get_album_status( $group_id );
			} else if( $item_output == 'media_status' ) {
				$data[] = bp_group_get_media_status( $group_id );
			} else if( $item_output == 'message_status' ) {
				$data[] = bp_group_get_message_status( $group_id );
			}
		}

		$output = '';

		if(!empty($data) && is_array($data)) {

			if ( $field_output == 'type_ul' ) {

				$output .= '<ul class="tax-ul">';

				foreach ( $data as $value ) {
					$output .= '<li>' . $value . '</li>';
				}

				$output .= '</ul>';

			} else if ( $field_output == 'type_ol' ) {

				$output .= '<ol class="tax-ol">';

				foreach ( $data as $value ) {
					$output .= '<li>' . $value . '</li>';
				}

				$output .= '</ol>';


			} else if ( $field_output == 'type_lenght' ) {

				$output = count( $data );

			} else if ( $field_output == 'type_limeter' && ! empty( $delimiter ) ) {

				$output = implode( $delimiter, $data );

			} else if ( $field_output == 'type_array' && is_numeric($array_index) ) {

				if ( isset( $data[ $array_index ] ) && ! empty( $data[ $array_index ] ) ) {
					$output = $data[ $array_index ];
				}

			}

			echo $output;

		}
	 
	}
}