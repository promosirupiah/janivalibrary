<?php

namespace Gloo\Modules\BB_Dynamic_Tags;

class BuddyBoss_Username extends \madxartwork\Core\DynamicTags\Tag {

	/**
	 * Get Name
	 *
	 * Returns the Name of the tag
	 *
	 * @return string
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'gloo-buddyboss-username';
	}

	/**
	 * Get Title
	 *
	 * Returns the title of the Tag
	 *
	 * @return string
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Dynamic Username', 'gloo_for_madxartwork' );
	}

	/**
	 * Get Group
	 *
	 * Returns the Group of the tag
	 *
	 * @return string
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_group() {
		return 'gloo-dynamic-tags';
	}

	/**
	 * Get Categories
	 *
	 * Returns an array of tag categories
	 *
	 * @return array
	 * @since 2.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [
			\madxartwork\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\madxartwork\Modules\DynamicTags\Module::URL_CATEGORY
		];
	}

	/**
	 * Register Controls
	 *
	 * Registers the Dynamic tag controls
	 *
	 * @return void
	 * @since 2.0.0
	 * @access protected
	 *
	 */
	protected function _register_controls() {

		$this->add_control(
			'user_context',
			array(
				'label'   => __( 'Context', 'gloo_for_madxartwork' ),
				'type'    => \madxartwork\Controls_Manager::SELECT,
				'default' => 'current_user',
				'options' => array(
					'current_user' => __( 'Current User', 'gloo_for_madxartwork' ),
					'queried_user' => __( 'Queried User', 'gloo_for_madxartwork' ),
				),
			)
		);

	}

	public function render() {

		$context = $this->get_settings( 'user_context' );

		if ( ! $context ) {
			$context = 'current_user';
		}

		$value = false;


		if ( 'current_user' === $context ) {
			$user_object = wp_get_current_user();
		} else {
			$user_object = jet_engine()->listings->data->get_current_user_object();
		}

		$value = bp_core_get_username( $user_object->ID );
		echo $value;

	}

}