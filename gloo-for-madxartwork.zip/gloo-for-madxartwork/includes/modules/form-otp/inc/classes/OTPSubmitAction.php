<?php 
namespace Gloo\Modules\FormOTP;

// exit if file is called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OTPSubmitAction extends \madxartworkPro\Modules\Forms\Classes\Action_Base{

	public $name;
	public $namePrefix;

	public function __construct($name = 'gloo_otp_submit_action', $namePrefix = ''){
		$this->name = $name;
		$this->namePrefix = $namePrefix;
	}

  public function get_sub_prefix($glue_string = '_'){
		$output = '';
		if(!empty($this->namePrefix) && $this->namePrefix && is_numeric($this->namePrefix) && $this->namePrefix >= 2)
			$output = $glue_string.$this->namePrefix;
		return $output;
	}

  public function get_prefix($glue_string = '_'){
		return $this->name.$this->get_sub_prefix('_parent_').$glue_string;
	}

  /**
	 * Get Name
	 *
	 * Return the action name
	 *
	 * @access public
	 * @return string
	 */
	public function get_name() {
		return $this->get_prefix();
	}

	/**
	 * Get Label
	 *
	 * Returns the action label
	 *
	 * @access public
	 * @return string
	 */
	public function get_label() {
		if($this->namePrefix)
			return __( 'OTP form action  - '.$this->namePrefix, 'gloo_for_madxartwork' );
		else
			return __( 'OTP form action ', 'gloo_for_madxartwork' );
	}

	/**
	 * Run
	 *
	 * Runs the action after submit
	 *
	 * @access public
	 * @param \madxartworkPro\Modules\Forms\Classes\Form_Record $record
	 * @param \madxartworkPro\Modules\Forms\Classes\Ajax_Handler $ajax_handler
	 */
	public function run( $record, $ajax_handler ) {

		$settings = $record->get( 'form_settings' );

		// Get sumitetd Form data
		$raw_fields = $record->get( 'fields' );

		// Normalize the Form Data
		$fields = [];
		foreach ( $raw_fields as $id => $field ) {
			$fields[ $id ] = $field['value'];
		}

    // if(isset($_POST['form_fields']) && isset($_POST['form_fields']['gloo_otp']) && is_array($_POST['form_fields']['gloo_otp'])){
    //   wp_send_json_error( [
    //     'message' => _('Please provide correct OTP.'),
    //     'data' => $ajax_handler->data,
    //   ] );die();
    // }
    

	}

	/**
	 * Register Settings Section
	 *
	 * Registers the Action controls
	 *
	 * @access public
	 * @param \madxartwork\Widget_Base $widget
	 */
	public function register_settings_section( $widget ) {

		
		$widget->start_controls_section(
			$this->get_prefix(),
			[
				'label' => __( $this->get_label(), 'gloo_for_madxartwork' ),
				'condition' => [
					'submit_actions' => $this->get_name(),
				],
			]
		);
		
    $widget->add_control(
			$this->get_prefix().'otp_type',
			[
				'label'   => __( 'OTP method', 'gloo_for_madxartwork' ),
				'type'    => \madxartwork\Controls_Manager::SELECT,
				'options' => array(
          'email' => __('Email', 'gloo_for_madxartwork'),
          'sms' => __('SMS', 'gloo_for_madxartwork')
        ),
				'default' => 'email',
			]
		);

    $widget->add_control(
			$this->get_prefix().'otp_length',
			[
				'label' => __( 'Code length', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::NUMBER,
        'min' => 2,
				'max' => 10,
				'step' => 1,
				'default' => 4,
			]
		);

    $widget->add_control(
			$this->get_prefix().'otp_to',
			[
				'label' => __( 'Phone/Email field ID', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
			]
		);

    $widget->add_control(
			$this->get_prefix().'message',
			[
				'label' => __( 'Content', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXTAREA,
				'default' => __('Your one time password is [gloo-form-otp].', 'gloo_for_madxartwork'),
				'show_label' => true,
			]
		);

    $widget->add_control(
			$this->get_prefix().'otp_button_label',
			[
				'label' => __( 'Button Label', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
        'default' => __('Send OTP', 'gloo_for_madxartwork'),
			]
		);

    

    /******************************************************* Email ************************************************/
		$widget->add_control(
			$this->get_prefix().'email_settings',
			[
				'label' => __( 'Email Settings', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'email'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'email_from_name',
			[
				'label' => __( 'From Name', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'default' => get_bloginfo( 'name' ),
				'placeholder' => get_bloginfo( 'name' ),
				'show_label' => true,
        'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'email'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'email_from',
			[
				'label' => __( 'From Email', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'default' => get_bloginfo('admin_email'),
				'placeholder' => get_bloginfo('admin_email'),
				'show_label' => true,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'email'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'email_subject',
			[
				'label' => __( 'Subject', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'default' => __('Your One Time Passcode', 'gloo_for_madxartwork'),
				'placeholder' => __('Thank you for registering', 'gloo_for_madxartwork'),
				'show_label' => true,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'email'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'email_content_type',
			[
				'label' => __( 'Send As', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::SELECT,
				'default' => 'html',
				'render_type' => 'none',
				'options' => [
					'html' => __( 'HTML', 'gloo_for_madxartwork' ),
					'plain' => __( 'Plain', 'gloo_for_madxartwork' )
				],
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'email'
						]
					]
				]
			]
		);

    $widget->add_control(
			$this->get_prefix().'otp_frontend_heading',
			[
				'label' => __( 'OTP field label', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXTAREA,
        'default' => '<p>'.__('Enter the 4 digits code sent to your email.', 'gloo_for_madxartwork').'</p>',
        'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'email'
						]
					]
				]
			]
		);
		


    //******************************************************* SMS ************************************************
 
		$widget->add_control(
			$this->get_prefix().'sms_settings',
			[
				'label' => __( 'SMS Settings', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::HEADING,
				'separator' => 'before',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'sms'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'phone_credentials_source',
			[
				'label' => __( 'API Source', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::SELECT,
				'label_block' => false,
				'options' =>[
					'twilio' => 'Twilio',
				],
				'default' => 'twilio',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'sms'
						]
					]
				]
			]
		);
		
		$widget->add_control(
			$this->get_prefix().'sms_account_sid',
			[
				'label' => __( 'Account SID', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'label_block' => false,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'sms'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'sms_auth_token',
			[
				'label' => __( 'Auth Token', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'label_block' => false,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'sms'
						]
					]
				]
			]
		);
		$widget->add_control(
			$this->get_prefix().'sms_from_number',
			[
				'label' => __( 'From Number', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXT,
				'placeholder' => '+919876543210',
				'show_label' => true,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'sms'
						]
					]
				]
			]
		);
    $widget->add_control(
			$this->get_prefix().'otp_frontend_heading_sms',
			[
				'label' => __( 'OTP field label', 'gloo_for_madxartwork' ),
				'type' => \madxartwork\Controls_Manager::TEXTAREA,
        'default' => '<p>'.__('Enter the 4 digits code sent to your phone.', 'gloo_for_madxartwork').'</p>',
        'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => $this->get_prefix().'otp_type',
							'operator' => '==',
							'value' => 'sms'
						]
					]
				]
			]
		);
		
		// $widget->add_control(
    //   $this->get_prefix().'enable_otp',
    //   [
    //     'type' => \madxartwork\Controls_Manager::SWITCHER,
    //     'label' => __( 'Enable OTP', 'gloo' ),
    //   ]
    // );

		

		
		
		
		$widget->end_controls_section();

	}

	/**
	 * On Export
	 *
	 * Clears form settings on export
	 * @access Public
	 * @param array $element
	 */
	public function on_export( $element ) {
		/*unset(
			$element['zohocampaign_accesstoken'],
			$element['zohocampaign_list'],
			$element['zohocampaign_email_field'],
			$element['zohocampaign_first_name_field'],
			$element['zohocampaign_last_name_field']
		);*/
  }
 

}