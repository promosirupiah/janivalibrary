(function($) {

    jQuery( window ).on( 'madxartwork/frontend/init', () => {
        const addHandler = ( $element ) => {
            
            var fields = $element.find('input[type="gloo_datepicker_field"]');

            if( typeof fields != 'undefined' ) {
                fields.each(function( key, val) {
                    var settings = $(this).data('config');
                    var field_id = $(this).attr('id');
                    
                    if( typeof field_id != 'undefined' && field_id != null ) {
                        settings.field = document.getElementById(field_id);
                        var picker = new Lightpick(settings);
                    }
                });
            }
        };

        madxartworkFrontend.hooks.addAction( 'frontend/element_ready/form.default', addHandler );
    });
})(jQuery);
