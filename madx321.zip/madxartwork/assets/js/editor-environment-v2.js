/*! madxartwork - v3.21.0 - 22-05-2024 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!************************************************************!*\
  !*** ../core/editor/loader/v2/js/editor-environment-v2.js ***!
  \************************************************************/


var _window$madxartworkV;
if (!((_window$madxartworkV = window.madxartworkV2) !== null && _window$madxartworkV !== void 0 && _window$madxartworkV.env)) {
  throw new Error('The "@madxartwork/env" package was not loaded.');
}
window.madxartworkV2.env.initEnv(window.madxartworkEditorV2Env);
/******/ })()
;
//# sourceMappingURL=editor-environment-v2.js.map