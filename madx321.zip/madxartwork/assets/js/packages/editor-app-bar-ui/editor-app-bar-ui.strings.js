__( 'More', 'madxartwork' );
__( 'madxartwork Logo', 'madxartwork' );
__( 'Integrations', 'madxartwork' );