__( 'Desktop', 'madxartwork' );
__( 'Switch Device', 'madxartwork' );
// translators: %s: Breakpoint label, %d: Breakpoint size.
__( '%s (%dpx and up)', 'madxartwork' );
// translators: %s: Breakpoint label, %d: Breakpoint size.
__( '%s (up to %dpx)', 'madxartwork' );