__( 'Pages', 'madxartwork' );
__( 'Page', 'madxartwork' );
__( 'Pages', 'madxartwork' );
__( 'Recent', 'madxartwork' );
__( 'There are no other pages or templates on this site yet.', 'madxartwork' );
__( 'Add new page', 'madxartwork' );
__( 'Pages', 'madxartwork' );
__( 'Add New', 'madxartwork' );
__( 'We couldn’t display your pages.', 'madxartwork' );
__( 'It’s probably a temporary issue.', 'madxartwork' );
__( 'If the problem persists,', 'madxartwork' );
__( 'Homepage', 'madxartwork' );
__( 'copy', 'madxartwork' );
__( 'New Page', 'madxartwork' );
__( 'Name is required', 'madxartwork' );
// translators: %s: Post type (e.g. Page, Post, etc.)
__( 'View %s', 'madxartwork' );
__( 'Set as homepage', 'madxartwork' );
__( 'Rename', 'madxartwork' );
__( 'Duplicate', 'madxartwork' );
__( 'Delete', 'madxartwork' );
/* translators: %s: Post title. */
__( 'Delete "%s"?', 'madxartwork' );
__( 'The page and its content will be deleted forever and we won’t be able to recover them.', 'madxartwork' );
__( 'Cancel', 'madxartwork' );
__( 'Delete', 'madxartwork' );