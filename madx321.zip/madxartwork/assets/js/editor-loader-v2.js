/*! madxartwork - v3.21.0 - 22-05-2024 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!*******************************************************!*\
  !*** ../core/editor/loader/v2/js/editor-loader-v2.js ***!
  \*******************************************************/


var _window$madxartworkV;
window.__madxartworkEditorV1LoadingPromise = new Promise(function (resolve) {
  window.addEventListener('madxartwork/init', function () {
    resolve();
  }, {
    once: true
  });
});
window.madxartwork.start();
if (!((_window$madxartworkV = window.madxartworkV2) !== null && _window$madxartworkV !== void 0 && _window$madxartworkV.editor)) {
  throw new Error('The "@madxartwork/editor" package was not loaded.');
}
window.madxartworkV2.editor.init(document.getElementById('madxartwork-editor-wrapper-v2'));
/******/ })()
;
//# sourceMappingURL=editor-loader-v2.js.map