<?php
namespace madxartwork\Core\Editor\Loader\V2\Templates;

use madxartwork\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$notice = Plugin::$instance->editor->notice_bar->get_notice();
?>

<div id="madxartwork-loading">
	<div class="madxartwork-loader-wrapper">
		<div class="madxartwork-loader" aria-hidden="true">
			<div class="madxartwork-loader-boxes">
				<div class="madxartwork-loader-box"></div>
				<div class="madxartwork-loader-box"></div>
				<div class="madxartwork-loader-box"></div>
				<div class="madxartwork-loader-box"></div>
			</div>
		</div>
		<div class="madxartwork-loading-title"><?php echo esc_html__( 'Loading', 'madxartwork' ); ?></div>
	</div>
</div>

<h1 class="madxartwork-screen-only"><?php echo sprintf( esc_html__( 'Edit "%s" with madxartwork', 'madxartwork' ), esc_html( get_the_title() ) ); ?></h1>

<div id="madxartwork-editor-wrapper-v2"></div>

<div id="madxartwork-editor-wrapper">
	<aside id="madxartwork-panel" class="madxartwork-panel" aria-labelledby="madxartwork-panel-header-title"></aside>
	<main id="madxartwork-preview" aria-label="<?php echo esc_attr__( 'Preview', 'madxartwork' ); ?>">
		<div id="madxartwork-preview-responsive-wrapper" class="madxartwork-device-desktop madxartwork-device-rotate-portrait">
			<div id="madxartwork-preview-loading">
				<i class="eicon-loading eicon-animation-spin" aria-hidden="true"></i>
			</div>
			<?php if ( $notice ) {
				$notice->render();
			} // IFrame will be created here by the Javascript later. ?>
		</div>
	</main>
	<aside id="madxartwork-navigator" aria-labelledby="madxartwork-navigator__header__title"></aside>
</div>
