if ( ! window.madxartworkV2?.env ) {
	throw new Error( 'The "@madxartwork/env" package was not loaded.' );
}

window.madxartworkV2.env.initEnv( window.madxartworkEditorV2Env );
