window.__madxartworkEditorV1LoadingPromise = new Promise( ( resolve ) => {
	window.addEventListener( 'madxartwork/init', () => {
		resolve();
	}, { once: true } );
} );

window.madxartwork.start();

if ( ! window.madxartworkV2?.editor ) {
	throw new Error( 'The "@madxartwork/editor" package was not loaded.' );
}

window.madxartworkV2
	.editor
	.init(
		document.getElementById( 'madxartwork-editor-wrapper-v2' ),
	);
