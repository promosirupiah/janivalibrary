<?php
namespace madxartwork\Core\Editor;

use madxartwork\Core\Utils\Promotions\Filtered_Promotions_Manager;
use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Promotion {

	/**
	 * @return array
	 */
	public function get_elements_promotion() {
		return Filtered_Promotions_Manager::get_filtered_promotion_data(
			$this->get_promotion_data(),
			'madxartwork/editor/promotion/get_elements_promotion',
			'action_button',
			'url'
		);
	}

	/**
	 * @return array
	 */
	private function get_action_button_content(): array {
		$has_pro = Utils::has_pro();
		return $has_pro ? [
			'text' => __( 'Connect & Activate', 'madxartwork' ),
			'url' => admin_url( 'admin.php?page=madxartwork-license' ),
		] : [
			'text' => __( 'Upgrade Now', 'madxartwork' ),
			'url' => 'https://go.madxartwork.com/go-pro-%s',
		];
	}

	/**
	 * @return string
	 */
	private function get_promotion_url(): string {
		return Utils::has_pro()
			? admin_url( 'admin.php?page=madxartwork-license' )
			: 'https://go.madxartwork.com/go-pro-%s';
	}

	/**
	 * @return array
	 */
	private function get_promotion_data(): array {
		return [
			/* translators: %s: Widget title. */
			'title' => __( '%s Widget', 'madxartwork' ),
			/* translators: %s: Widget title. */
			'content' => __(
				'Use %s widget and dozens more pro features to extend your toolbox and build sites faster and better.',
				'madxartwork'
			),
			'action_button' => $this->get_action_button_content(),
		];
	}
}
