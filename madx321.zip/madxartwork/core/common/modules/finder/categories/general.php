<?php
namespace madxartwork\Core\Common\Modules\Finder\Categories;

use madxartwork\Core\Common\Modules\Finder\Base_Category;
use madxartwork\Core\RoleManager\Role_Manager;
use madxartwork\Plugin;
use madxartwork\TemplateLibrary\Source_Local;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * General Category
 *
 * Provides general items related to madxartwork Admin.
 */
class General extends Base_Category {

	/**
	 * Get title.
	 *
	 * @since 2.3.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'General', 'madxartwork' );
	}

	public function get_id() {
		return 'general';
	}

	/**
	 * Get category items.
	 *
	 * @since 2.3.0
	 * @access public
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	public function get_category_items( array $options = [] ) {
		return [
			'saved-templates' => [
				'title' => esc_html__( 'Saved Templates', 'madxartwork' ),
				'icon' => 'library-save',
				'url' => Source_Local::get_admin_url(),
				'keywords' => [ 'template', 'section', 'page', 'library' ],
			],
			'system-info' => [
				'title' => esc_html__( 'System Info', 'madxartwork' ),
				'icon' => 'info-circle-o',
				'url' => admin_url( 'admin.php?page=madxartwork-system-info' ),
				'keywords' => [ 'system', 'info', 'environment', 'madxartwork' ],
			],
			'role-manager' => [
				'title' => esc_html__( 'Role Manager', 'madxartwork' ),
				'icon' => 'person',
				'url' => Role_Manager::get_url(),
				'keywords' => [ 'role', 'manager', 'user', 'madxartwork' ],
			],
			'knowledge-base' => [
				'title' => esc_html__( 'Knowledge Base', 'madxartwork' ),
				'url' => admin_url( 'admin.php?page=go_knowledge_base_site' ),
				'keywords' => [ 'help', 'knowledge', 'docs', 'madxartwork' ],
			],
			'theme-builder' => [
				'title' => esc_html__( 'Theme Builder', 'madxartwork' ),
				'icon' => 'library-save',
				'url' => Plugin::$instance->app->get_settings( 'menu_url' ),
				'keywords' => [ 'template', 'header', 'footer', 'single', 'archive', 'search', '404', 'library' ],
			],
			'kit-library' => [
				'title' => esc_html__( 'Kit Library', 'madxartwork' ),
				'icon' => 'kit-parts',
				'url' => Plugin::$instance->app->get_base_url() . '#/kit-library',
				'keywords' => [ 'kit library', 'kit', 'library', 'site parts', 'parts', 'assets', 'templates' ],
			],
		];
	}
}
