<?php

namespace madxartwork\Core\Admin\Menu;

use madxartwork\Plugin;
use madxartwork\TemplateLibrary\Source_Local;
use madxartwork\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Main extends Base {

	protected function get_init_args() {
		return [
			'page_title' => esc_html__( 'madxartwork', 'madxartwork' ),
			'menu_title' => esc_html__( 'madxartwork', 'madxartwork' ),
			'capability' => 'manage_options',
			'menu_slug' => 'madxartwork',
			'function' => [ Plugin::$instance->settings, 'display_settings_page' ],
			'position' => 58.5,
		];
	}

	protected function get_init_options() {
		return [
			'separator' => true,
		];
	}

	protected function register_default_submenus() {
		$this->add_submenu( [
			'page_title' => esc_html_x( 'Templates', 'Template Library', 'madxartwork' ),
			'menu_title' => esc_html_x( 'Templates', 'Template Library', 'madxartwork' ),
			'menu_slug' => Source_Local::ADMIN_MENU_SLUG,
			'index' => 0,
		] );

		$this->add_submenu( [
			'menu_title' => esc_html__( 'Help', 'madxartwork' ),
			'menu_slug' => 'go_knowledge_base_site',
			'function' => [ Plugin::$instance->settings, 'handle_external_redirects' ],
			'index' => 150,
		] );
	}

	protected function register() {
		parent::register();

		$this->rearrange_madxartwork_submenu();
	}

	private function rearrange_madxartwork_submenu() {
		global $submenu;

		$madxartwork_menu_slug = $this->get_args( 'menu_slug' );

		$madxartwork_submenu_old_index = null;

		$tools_submenu_index = null;

		foreach ( $submenu[ $madxartwork_menu_slug ] as $index => $submenu_item ) {
			if ( $madxartwork_menu_slug === $submenu_item[2] ) {
				$madxartwork_submenu_old_index = $index;
			} elseif ( Tools::PAGE_ID === $submenu_item[2] ) {
				$tools_submenu_index = $index;

				break;
			}
		}

		$madxartwork_submenu = array_splice( $submenu[ $madxartwork_menu_slug ], $madxartwork_submenu_old_index, 1 );

		$madxartwork_submenu[0][0] = esc_html__( 'Settings', 'madxartwork' );

		array_splice( $submenu[ $madxartwork_menu_slug ], $tools_submenu_index, 0, $madxartwork_submenu );
	}
}
