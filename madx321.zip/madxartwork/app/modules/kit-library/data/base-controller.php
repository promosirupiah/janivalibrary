<?php
namespace madxartwork\App\Modules\KitLibrary\Data;

use madxartwork\Plugin;
use madxartwork\Data\V2\Base\Controller;
use madxartwork\Core\Utils\Collection;
use madxartwork\Modules\Library\User_Favorites;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Base_Controller extends Controller {
	/**
	 * @var Repository
	 */
	private $repository;

	/**
	 * @return Repository
	 */
	public function get_repository() {
		if ( ! $this->repository ) {
			/** @var \madxartwork\Core\Common\Modules\Connect\Module $connect */
			$connect = Plugin::$instance->common->get_component( 'connect' );

			$subscription_plans = ( new Collection( $connect->get_subscription_plans() ) )
				->map( function ( $value ) {
					return $value['label'];
				} );

			$this->repository = new Repository(
				$connect->get_app( 'kit-library' ),
				new User_Favorites( get_current_user_id() ),
				$subscription_plans
			);
		}

		return $this->repository;
	}
}
