<?php
namespace Marvymadxartwork\animation;

if( !defined( 'ABSPATH' ) ) exit;
use madxartwork\Controls_Manager;

class MarvyCellsAnimation {

  public function __construct(){
    add_action('madxartwork/frontend/section/before_render', array($this, 'before_render'), 1);
    add_action('madxartwork/element/section/section_layout/after_section_end',array($this,'register_controls'), 1 );
  }

  public function register_controls($element)
  {
    $element->start_controls_section('marvy_cells_animation_section',
      [
        'label' => __('<div style="float: right"><img src="'.plugin_dir_url(__DIR__).'assets/images/logo.png" height="15px" width="15px" style="float:left;" alt=""></div> Cells Animation', 'marvy-lang'),
        'tab' => Controls_Manager::TAB_LAYOUT
      ]
    );

    $element->add_control('marvy_enable_cells_animation',
      [
        'label' => esc_html__('Enable Cells Animation', 'marvy-lang'),
        'type' => Controls_Manager::SWITCHER,
      ]
    );

    $element->add_control(
      'marvy_cells_animation_color',
      [
        'label' => esc_html__('Color1', 'marvy-lang'),
        'type' => Controls_Manager::COLOR,
        'default' => '#008c8c',
        'condition' => [
          'marvy_enable_cells_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_cells_animation_color_two',
      [
        'label' => esc_html__('Color2', 'marvy-lang'),
        'type' => Controls_Manager::COLOR,
        'default' => '#f2e734',
        'condition' => [
          'marvy_enable_cells_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_cells_animation_size',
      [
        'label' => esc_html__('Size', 'marvy-lang'),
        'type' => Controls_Manager::NUMBER,
        'default' => 1.5,
        'min' => 0.2,
        'max' => 5,
        'step' => 0.5,
        'condition' => [
          'marvy_enable_cells_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_cells_animation_speed',
      [
        'label' => esc_html__('Speed', 'marvy-lang'),
        'type' => Controls_Manager::NUMBER,
        'default' => 1,
        'min' => 0,
        'max' => 5,
        'step' => 0.5,
        'condition' => [
          'marvy_enable_cells_animation' => 'yes',
        ]
      ]
    );

    $element->end_controls_section();

  }

  public function before_render($element) {
    $settings = $element->get_settings();

    if ($settings['marvy_enable_cells_animation'] === 'yes') {
      $element->add_render_attribute(
        '_wrapper',
        [
          'data-marvy_enable_cells_animation' => 'true',
          'data-marvy_cells_animation_color' => $settings['marvy_cells_animation_color'],
          'data-marvy_cells_animation_color_two' => $settings['marvy_cells_animation_color_two'],
          'data-marvy_cells_animation_size' => $settings['marvy_cells_animation_size'],
          'data-marvy_cells_animation_speed' => $settings['marvy_cells_animation_speed'],
        ]
      );
    } else {
      $element->add_render_attribute('_wrapper', 'data-marvy_enable_cells_animation', 'false');
    }
  }
}
