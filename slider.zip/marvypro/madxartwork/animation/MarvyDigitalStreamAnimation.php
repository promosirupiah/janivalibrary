<?php
namespace Marvymadxartwork\animation;

if( !defined( 'ABSPATH' ) ) exit;
use madxartwork\Controls_Manager;

class MarvyDigitalStreamAnimation {

    public function __construct(){
        add_action('madxartwork/frontend/section/before_render', array($this, 'before_render'), 1);
        add_action('madxartwork/element/section/section_layout/after_section_end',array($this,'register_controls'), 1 );
    }

    public function register_controls( $element )
    {
        $element->start_controls_section('marvy_digitalStream_animation_section',
            [
                'label' => __('<div style="float: right"><img src="'.plugin_dir_url(__DIR__).'assets/images/logo.png" height="15px" width="15px" style="float:left;"></div> Digital Stream Animation', 'marvy-lang'),
                'tab' => Controls_Manager::TAB_LAYOUT
            ]
        );

        $element->add_control('marvy_enable_digitalStream_animation',
            [
                'label' => esc_html__( 'Enable Digital Stream', 'marvy-lang'),
                'type'  => Controls_Manager::SWITCHER
            ]
        );

        $element->add_control(
            'marvy_digitalStream_animation_background_color',
            [
                'label' => esc_html__('Background Color', 'marvy-lang'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'condition' => [
                    'marvy_enable_digitalStream_animation' => 'yes'
                ]
            ]
        );

        $element->add_control(
            'marvy_digitalStream_animation_color_type',
            [
                'label' => esc_html__('Stream Color Type', 'marvy-lang'),
                'type' => Controls_Manager::SELECT,
                'default' => 'random',
                'options' => [
                    'random' => esc_html__('Random', 'marvy-lang'),
                    'custom' => esc_html__('Custom', 'marvy-lang')
                ],
                'condition' => [
                    'marvy_enable_digitalStream_animation' => 'yes'
                ]
            ]
        );

        $element->add_control(
            'marvy_digitalStream_animation_color',
            [
                'label' => esc_html__('Stream Color', 'marvy-lang'),
                'type' => Controls_Manager::COLOR,
                'default' => '#30ABBD',
                'condition' => [
                    'marvy_enable_digitalStream_animation' => 'yes',
                    'marvy_digitalStream_animation_color_type' => 'custom'
                ]
            ]
        );

        $element->add_control(
            'marvy_digitalStream_animation_alpha',
            [
                'label' => esc_html__('Alpha', 'marvy-lang'),
                'type' => Controls_Manager::NUMBER,
                'default' => 0.03,
                'min' => 0.01,
                'max' => 1,
                'step' => 0.03,
                'condition' => [
                    'marvy_enable_digitalStream_animation' => 'yes'
                ]
            ]
        );

        $element->add_control(
            'marvy_digitalStream_animation_noise_dist',
            [
                'label' => esc_html__('Noise Distance', 'marvy-lang'),
                'type' => Controls_Manager::NUMBER,
                'default' => 100,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'condition' => [
                    'marvy_enable_digitalStream_animation' => 'yes'
                ]
            ]
        );

        $element->end_controls_section();
    }

    public function before_render($element) {
        $settings = $element->get_settings();
        if ($settings['marvy_enable_digitalStream_animation'] === 'yes') {
            $element->add_render_attribute(
                '_wrapper',
                [
                    'data-marvy_enable_digitalStream_animation' => 'true',
                    'data-marvy_digitalStream_animation_background_color' => $settings['marvy_digitalStream_animation_background_color'],
                    'data-marvy_digitalStream_animation_color_type' => $settings['marvy_digitalStream_animation_color_type'],
                    'data-marvy_digitalStream_animation_color' => $settings['marvy_digitalStream_animation_color'],
                    'data-marvy_digitalStream_animation_alpha' => $settings['marvy_digitalStream_animation_alpha'],
                    'data-marvy_digitalStream_animation_noise_dist' => $settings['marvy_digitalStream_animation_noise_dist']
                ]
            );
        } else {
            $element->add_render_attribute('_wrapper', 'data-marvy_enable_digitalStream_animation', 'false');
        }
    }
}
