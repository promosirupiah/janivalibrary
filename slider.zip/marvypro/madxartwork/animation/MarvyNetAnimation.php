<?php
namespace Marvymadxartwork\animation;

if( !defined( 'ABSPATH' ) ) exit;
use madxartwork\Controls_Manager;

class MarvyNetAnimation {

  public function __construct(){
    add_action('madxartwork/frontend/section/before_render', array($this, 'before_render'), 1);
    add_action('madxartwork/element/section/section_layout/after_section_end',array($this,'register_controls'), 1 );
  }

  public function register_controls($element)
  {
    $element->start_controls_section('marvy_net_animation_section',
      [
        'label' => __('<div style="float: right"><img src="'.plugin_dir_url(__DIR__).'assets/images/logo.png" height="15px" width="15px" style="float:left;" alt=""></div> Net Animation', 'marvy-lang'),
        'tab' => Controls_Manager::TAB_LAYOUT
      ]
    );

    $element->add_control('marvy_enable_net_animation',
      [
        'label' => esc_html__('Enable Net Animation', 'marvy-lang'),
        'type' => Controls_Manager::SWITCHER,
      ]
    );

    $element->add_control(
      'marvy_net_animation_background_color',
      [
        'label' => esc_html__('Background Color', 'marvy-lang'),
        'type' => Controls_Manager::COLOR,
        'default' => '#23153c',
        'condition' => [
          'marvy_enable_net_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_net_animation_color',
      [
        'label' => esc_html__('Color', 'marvy-lang'),
        'type' => Controls_Manager::COLOR,
        'default' => '#ff3f81',
        'condition' => [
          'marvy_enable_net_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_net_animation_points',
      [
        'label' => esc_html__('Points', 'marvy-lang'),
        'type' => Controls_Manager::NUMBER,
        'default' => 10,
        'min' => 1,
        'max' => 20,
        'step' => 1,
        'condition' => [
          'marvy_enable_net_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_net_animation_max_distance',
      [
        'label' => esc_html__('Max Distance', 'marvy-lang'),
        'type' => Controls_Manager::NUMBER,
        'default' => 20,
        'min' => 10,
        'max' => 40,
        'step' => 5,
        'condition' => [
          'marvy_enable_net_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_net_animation_spacing',
      [
        'label' => esc_html__('Spacing', 'marvy-lang'),
        'type' => Controls_Manager::NUMBER,
        'default' => 15,
        'min' => 10,
        'max' => 20,
        'step' => 1,
        'condition' => [
          'marvy_enable_net_animation' => 'yes',
        ]
      ]
    );

    $element->add_control(
      'marvy_net_animation_show_dots',
      [
        'label' => esc_html__('Show Dots', 'marvy-lang'),
        'type' => Controls_Manager::SWITCHER,
        'default' => true,
        'label_on' => __( 'Show', 'marvy-lang' ),
        'label_off' => __( 'Hide', 'marvy-lang' ),
        'condition' => [
          'marvy_enable_net_animation' => 'yes',
        ]
      ]
    );

    $element->end_controls_section();

  }

  public function before_render($element) {
    $settings = $element->get_settings();

    if ($settings['marvy_enable_net_animation'] === 'yes') {
      $element->add_render_attribute(
        '_wrapper',
        [
          'data-marvy_enable_net_animation' => 'true',
          'data-marvy_net_animation_background_color' => $settings['marvy_net_animation_background_color'],
          'data-marvy_net_animation_color' => $settings['marvy_net_animation_color'],
          'data-marvy_net_animation_points' => $settings['marvy_net_animation_points'],
          'data-marvy_net_animation_max_distance' => $settings['marvy_net_animation_max_distance'],
          'data-marvy_net_animation_spacing' => $settings['marvy_net_animation_spacing'],
          'data-marvy_net_animation_show_dots' => $settings['marvy_net_animation_show_dots']
        ]
      );
    } else {
      $element->add_render_attribute('_wrapper', 'data-marvy_enable_net_animation', 'false');
    }
  }
}
