jQuery( document ).ready( function() {
	jQuery( '.slick-slider-wrapper .slick-slider' ).slick();
} );
