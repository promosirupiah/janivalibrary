<?php


/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, hooks & filters
 *
 */

namespace Easy_Slideshow\FrontEnd;

use Easy_Slideshow\Includes\Template_Loader;

class FrontEnd {

	/**
	 * The ID of this plugin.
	 *
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;


	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/frontend.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 */
	public function register_scripts() {

		wp_register_script( 'cycle2', '//malsup.github.io/jquery.cycle2.js', array( 'jquery' ), '1.0.0', true );
		wp_register_script( 'cycle2swipe', '//malsup.github.io/min/jquery.cycle2.swipe.min.js', array(
			'jquery',
			'cycle2'
		), '1.0.0', true );

	}


	public function add_shortcode() {
		remove_shortcode( 'gallery' );
		add_shortcode( 'gallery', array( $this, 'do_shortcode' ) );
	}

	/**
	 * @param $atts
	 *
	 * @return string
	 */
	public function do_shortcode( $atts ) {

		if ( isset( $atts['fullworks_slideshow'] ) && ( 'slideshow' == $atts['fullworks_slideshow'] ) ) {
			wp_enqueue_script( 'cycle2' );
			wp_enqueue_script( 'cycle2swipe' );

			return $this->build_slideshow( $atts );
		} else {
			return gallery_shortcode( $atts );
		}
	}

	private function build_slideshow( $atts ) {
		$post = get_post();
		static $instance = 0;
		$instance ++;

		$atts = shortcode_atts( array(
			'order'                => 'ASC',
			'orderby'              => 'post__in',
			'id'                   => $post ? $post->ID : 0,
			'size'                 => 'thumbnail',
			'ids'                  => '',
			'fullworks_slideshow'  => '',
			'easy_slideshow_align' => 'left'
		), $atts, 'gallery' );

		if ( ! empty( $atts['ids'] ) ) {
			$_attachments = get_posts( array(
				'include'        => $atts['ids'],
				'post_status'    => 'inherit',
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'order'          => $atts['order'],
				'orderby'        => $atts['orderby']
			) );
			$attachments  = array();
			foreach ( $_attachments as $key => $val ) {
				$attachments[ $val->ID ] = $_attachments[ $key ];
			}
			$template_loader = new Template_Loader;
			$template_loader->set_template_data( array(
				'attachments' => $attachments,
				'atts'        => $atts,
				'instance'    => $instance
			) );
			ob_start();


			if ( 'background' === $atts['easy_slideshow_align'] ) {
				$template_loader->get_template_part( 'background' );
			} else {
				$template_loader->get_template_part( 'slideshow' );
			}


			$html = ob_get_clean();

			return $html;
		}


		return '';

	}

}
