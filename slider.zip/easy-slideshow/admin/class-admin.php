<?php


/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 */

namespace Easy_Slideshow\Admin;


class Admin {

	/**
	 * The ID of this plugin.
	 *
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	public function connect_message(
		$message,
		$user_first_name,
		$plugin_title,
		$user_login,
		$site_link,
		$freemius_link
	) {
		return sprintf(
			__( 'Hi %1$s' ) . ',<br>' .
			__( 'Never miss an important update -- opt-in to our security and feature updates notifications related to %2$s, and non-sensitive diagnostic tracking to help me improve %2$s sent via %5$s', 'easy-slideshow' ),
			$user_first_name,
			'<b>' . $plugin_title . '</b>',
			'<b>' . $user_login . '</b>',
			$site_link,
			$freemius_link
		);
	}

	public function print_media_templates() {
		?>
        <script type="text/html" id="tmpl-easy-slideshow-settings">
            <label class="setting">
                <span><?php _e( 'Slideshow or Gallery', 'easy-slideshow' ); ?></span>
                <select data-setting="fullworks_slideshow">
                    <option value="normal"><?php _e( 'Normal Gallery', 'easy-slideshow' ); ?></option>
                    <option value="slideshow"><?php _e( 'Slideshow', 'easy-slideshow' ); ?></option>
                </select>
            </label>
            <label class="setting">
                <span><?php _e( 'Slideshow Alignment', 'easy-slideshow' ); ?></span>
                <select data-setting="easy_slideshow_align">
                    <option value="left"><?php _e( 'Left', 'easy-slideshow' ); ?></option>
                    <option value="center"><?php _e( 'Centre', 'easy-slideshow' ); ?></option>
                    <option value="right"><?php _e( 'Right', 'easy-slideshow' ); ?></option>
                    <option value="none"><?php _e( 'None', 'easy-slideshow' ); ?></option>
                    <option value="background"><?php _e( 'Background', 'easy-slideshow' ); ?></option>
                </select>
            </label>
        </script>

        <script>

            jQuery(document).ready(function () {
                _.extend(wp.media.gallery.defaults, {
                    fullworks_slideshow: 'normal',
                    easy_slideshow_align: 'left'
                });
                wp.media.view.Settings.Gallery = wp.media.view.Settings.Gallery.extend({
                    template: function (view) {
                        return wp.media.template('gallery-settings')(view)
                            + wp.media.template('easy-slideshow-settings')(view);
                    }
                });

            });

        </script>
		<?php
	}


}
