<?php
/**
 * Class to load freemius configuration
 */

namespace Easy_Slideshow\Includes;


class Freemius_Config {

	public function init() {

		global $easy_slideshow_fs;

		if ( ! isset( $easy_slideshow_fs ) ) {
			// Include Freemius SDK.
			require_once dirname( __FILE__ ) . '/vendor/freemius/wordpress-sdk/start.php';

			$easy_slideshow_fs = fs_dynamic_init( array(
				'id'             => '1704',
				'slug'           => 'easy-slideshow',
				'type'           => 'plugin',
				'public_key'     => 'pk_3daabb9d0a30bcb35a941d63dec58',
				'is_premium'     => false,
				'has_addons'     => false,
				'has_paid_plans' => false,
				'menu'           => array(
					'first-path' => 'plugins.php',
					'contact'    => false,
				),
			) );
		}

		return $easy_slideshow_fs;

	}


}