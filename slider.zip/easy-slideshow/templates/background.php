<?php
/**
 * @var mixed $data Custom data for the template.
 */

?>

<div id="slideshow-background"
     class="easy-slideshow
      easy-slideshow-<?php echo $data->atts['id']; ?>
      align<?php echo $data->atts['easy_slideshow_align']; ?>
      fullworks-slider-size-<?php echo sanitize_html_class( $data->atts['size'] ); ?>">
	<div id="cycle-<?php echo $data->instance; ?>" class="cycle-slideshow
        attachment-<?php echo sanitize_html_class( $data->atts['size'] ); ?>
        align<?php echo $data->atts['easy_slideshow_align']; ?>"
         data-cycle-fx="fadeout"
	     data-cycle-timeout="5000"
	     data-cycle-slides="> div"
	>
		<?php
		// loop images
		foreach ( $data->attachments as $id => $attachment ) {
		    $image = wp_get_attachment_image_src($id, 'full', false);
			?>
			<div style="background-image:url(
				<?php
				echo $image[0];
				?>
                    );">
			</div>
			<?php
		}
		?>
	</div>
</div>