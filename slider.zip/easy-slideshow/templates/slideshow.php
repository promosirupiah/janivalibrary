<?php
/**
 * @var mixed $data Custom data for the template.
 */

?>

<div id="slideshow-<?php echo $data->instance; ?>"
     class="easy-slideshow
      easy-slideshow-<?php echo $data->atts['id']; ?>
      align<?php echo $data->atts['easy_slideshow_align']; ?>
      fullworks-slider-size-<?php echo sanitize_html_class( $data->atts['size'] ); ?>">
    <div id="cycle-<?php echo $data->instance; ?>" class="cycle-slideshow
        attachment-<?php echo sanitize_html_class( $data->atts['size'] ); ?>
        align<?php echo $data->atts['easy_slideshow_align']; ?>"
         data-cycle-swipe=true
         data-cycle-swipe-fx=scrollHorz
         data-cycle-timeout="5000"
         data-cycle-slides="> div"
    >
		<?php
		// loop images
		foreach ( $data->attachments as $id => $attachment ) {
			?>
            <div>
				<?php
				echo wp_get_attachment_image( $id, $data->atts['size'], false, array(
					'class' => 'align' . $data->atts['easy_slideshow_align']
				) );
				?>
            </div>
			<?php
		}
		?>
    </div>
</div>

