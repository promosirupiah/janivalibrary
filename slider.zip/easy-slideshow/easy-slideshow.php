<?php

/**
 *
 *
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 *
 * Plugin Name:       Easy Slideshow
 * Plugin URI:        http://fullworks.net/wordpress-plugins/easy-slideshow/
 * Description:       Convert the WordPress image gallery into a slideshow or full width photo background or thumbnail gallery
 * Version:           1.2.1
 * Author:            Fullworks
 * Author URI:        http://fullworks.net/
 * License:           GPL-3.0+
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain:       easy-slideshow
 * Domain Path:       /languages
 *
 * @package easy-slideshow
 */

namespace Easy_Slideshow;

use \Easy_Slideshow\Includes\Core;
use \Easy_Slideshow\Includes\Freemius_Config;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
if ( ! function_exists( 'Easy_Slideshow\run_Easy_Slideshow' ) ) {
	define( 'EASY_SLIDESHOW_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
	define( 'EASY_SLIDESHOW_PLUGIN_VERSION', '1.2.1' );

// Include the autoloader so we can dynamically include the classes.
	require_once EASY_SLIDESHOW_PLUGIN_DIR . 'includes/autoloader.php';

	/**
	 * Begins execution of the plugin.
	 */
	function run_Easy_Slideshow() {
		/**
		 *  Load freemius SDK
		 */
		$freemius = new Freemius_Config();
		$freemius = $freemius->init();
		// Signal that SDK was initiated.

		/**
		 * The code that runs during plugin uninstall.
		 * This action is documented in includes/class-uninstall.php
		 * * use freemius hook
		 *
		 * @var \Freemius $freemius freemius SDK.
		 */
		/**
		 * The core plugin class that is used to define internationalization,
		 * admin-specific hooks, and public-facing site hooks.
		 */
		$plugin = new Core( $freemius );
		$plugin->run();
	}

	run_Easy_Slideshow();
} else {
	die( __( 'Cannot execute as the plugin already exists, if you have a another version installed deactivate that and try again', 'easy-slideshow' ) );
}
