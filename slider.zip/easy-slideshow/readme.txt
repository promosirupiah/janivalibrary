=== WordPress Slideshow Gallery Plugin - Easy Slideshow ===
Contributors: Fullworks
Tags: slideshow, image rotator, simple slideshow, gallery slideshow
Requires at least: 3.6
Tested up to: 4.9.9
Stable tag: 1.2.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Convert the WordPress image gallery into a slideshow or full width photo background or thumbnail gallery.

== Description ==

Please note - this plugin will not work within the new block editor released in WP 5.0 ( Gutenberg ) - if you want to use this you will need to disable the block editor ( e.g. use the Classic Editor Plugin ). There are no plans to have a version that works within the block editor.

An easy to use, responsive, swipeable, light weight wordpress slideshow gallery / thumbnail photo image rotator or background photo slideshow capability.


Simply use the WordPress Gallery and select slideshow on the Gallery form.

You can select the alignments and even use it as a fullscreen background slider for individual pages and posts.

See a [demo here](https://demo.fullworks.net/easy-slideshow)

See a [background demo here]( https://demo.fullworks.net/easy-slideshow/background )

You can create a WordPress Slideshow from a gallery.

If you want a WordPress image slideshow widget, you can easily do this by adding the gallery using the standard WordPress text widget ( see [demo WordPress image widgets](https://demo.fullworks.net/easy-slideshow/2018/07/08/sidebar/)

The simplicity of this plugin is it uses the standard WordPress Gallery to generate a WordPress gallery slideshow shortcode, which is just and extension of teh standard WordPress Gallery Shortcode, so if you prefer to work with shortcodes, you certainly can.

This image slideshow WordPress plugin is one of the best plugins as it is light weight ( using the fantastic jQuery Cycle 2 library ) and easy to use as it is integrated into the standard way WordPress works, unlike many other WordPress slideshow plugins.

== Screenshots ==
1. Responsive slideshow
1. Easy Settings

== Installation ==

1. Install and activate the plugin through the 'Plugins' menu in WordPress

== Privacy and GDPR ==

This plugin does not process any personal data


== Frequently Asked Questions ==

= How to make a WordPress gallery sideshow? =

Install the plugin, create a WordPress gallery as you would, select the option 'Slideshow', that is it

= Are there any dashboard settings =

No, the slideshow takes all its settings from the Media add Gallery pop up.

= Is it mobile friendly =

Yes it is responsive and swipeable, try the [demo](https://demo.fullworks.net/easy-slideshow) on your mobile

= Can I create a WordPress image slideshow widget =

You simply use the Text Widget to add galleries, just set it to 'slideshow'
You can adjust the widget from the customizer too.

= How to make a WordPress background slideshow? =

Add a gallery to your page or post and select 'slideshow' and alignment as 'background' and it will work as a full width background slideshow. You will need, clearly to make sure that your theme has transpaent areas to be able to see the background, you may need to customize your theme CSS to be able to see any background.
e.g. `.site-content-contain {
      	background-color: transparent
      }`  would work for 2017 theme




== Changelog ==
= 1.2.1 =
* Security Fix

= 1.2 =
* Added background capability

= 1.1 =
* CSS adjustment for centering

= 1.0 =
* First release


