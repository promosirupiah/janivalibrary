<?php

namespace FSProVendor;

if (!\defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly
?>
<script type="text/javascript">
    <?php 
include \dirname(__FILE__, 5) . '/assets/js/gutenberg.js';
?>
</script>
<?php 
