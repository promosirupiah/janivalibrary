<?php

namespace FSProVendor\WPDesk\PluginBuilder\Storage\Exception;

class ClassNotExists extends \RuntimeException
{
}
