<?php

namespace FSProVendor\WPDesk\Forms\Field;

class RadioField extends \FSProVendor\WPDesk\Forms\Field\BasicField
{
    public function get_template_name()
    {
        return 'input-radio';
    }
}
