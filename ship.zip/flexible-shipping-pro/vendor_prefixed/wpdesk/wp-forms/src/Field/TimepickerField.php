<?php

namespace FSProVendor\WPDesk\Forms\Field;

class TimepickerField extends \FSProVendor\WPDesk\Forms\Field\BasicField
{
    /**
     * @inheritDoc
     */
    public function get_template_name()
    {
        return 'timepicker';
    }
}
