<?php

namespace FSProVendor\WPDesk\Logger\WC\Exception;

class WCLoggerAlreadyCaptured extends \RuntimeException
{
}
