[![pipeline status](https://gitlab.com/wpdesk/flexible-shipping/badges/master/pipeline.svg)](https://gitlab.com/wpdesk/flexible-shipping/commits/master)
 
