<?php

namespace WPDesk\FSPro\TableRate\Rule\Condition\ProductDimension;

/**
 * Not Implemented Exception.
 */
class NotImplementedException extends \RuntimeException {

}
