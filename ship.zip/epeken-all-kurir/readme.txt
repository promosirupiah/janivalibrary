== Epeken All Kurir Plugin for Woocommerce Full Version ==
Contributors: support@epeken.com
Tags: JNE, TIKI, POS, J&T, WAHANA, SICEPAT, SAP, RPX, ecommerce, e-commerce, commerce, wordpress ecommerce, plugin jne gratis,affiliate, online shop, toko online, cart, checkout, reports, download, downloadable, digital, inventory, stock, pengiriman, reports, shipping, tax, JNE, Tiki, POS, RPX, NINJA, kurir, jne kurir, woocommerce jne, epeken
Donate link: http://www.epeken.com/shop/epeken-all-kurir-license/
Requires at least:4.0 
Tested up to: 6.4
Stable tag: 1.4.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

Epeken All Kurir Plugin is a wordpress plugin for woocommerce to enable shipping method featuring many shipping companies for Indonesia e-commerce.  

== Description ==

Epeken All Kurir Plugin is a wordpress plugin for woocommerce to enable shipping methods featuring many shipping companies in Indonesia for Indonesia e-commerce. This is very popular plugin that many woocommerce online shops in Indonesia have installed. However, you need to have license to use this plugin. But, it's worth it. [Buy our valid anual or monthly license to continue using this plugin](http://www.epeken.com/shop/epeken-all-kurir-license/). 

== Marketplace Support ==

This Plugin also supports marketplace plugins like [Woocommerce Product Vendors](https://woocommerce.com/products/product-vendors/), [wc-vendors](https://id.wordpress.org/plugins/wc-vendors/) , [MultiVendorX](https://wordpress.org/plugins/dc-woocommerce-multi-vendor/), [Yith Woocommerce Multi Vendor](https://yithemes.com/themes/plugins/yith-woocommerce-multi-vendor/), [woocommerce-dropshippers](https://codecanyon.net/item/woocommerce-dropshippers/7615263), [Woocommerce Multivendor Marketplace](https://wordpress.org/plugins/wc-multivendor-marketplace/) and [dokan](https://wordpress.org/plugins/dokan-lite/) if you want to build marketplace ecommerce based on wordpress and woocommerce.

[Try Our Demo](http://epeken.com/demo)

This plugin is developed by epeken. copyright (c) 2015 by [epeken](http://www.epeken.com)

= Supporting Expeditions =

JNE, TIKI, POS, NSS, J&T, RPX, SICEPAT, WAHANA, SAP Express, JMX, LION PARCEL, NINJA EXPRESS, JNE TRUCKING, DAKOTA CARGO

= Ekspedisi Anteraja =

Epeken in collaboration with Anterja has released Anteraja plugin for WooCommerce. [Check this out](https://wordpress.org/plugins/anteraja).

= Strength & flexibility =

This plugin is built using WordPress best practises both on the front and the back end. This results in an efficient, robust and intuitive plugin. Currently this plugin supports latest woocommerce v.7 and latest wordpress 6.0

= Customizable =

Your business is unique, you may modify this plugin to meet your business requirement. You may refer to woocommerce plugin customization page and wordpress plugin development page to do it. Any concerns and questions, you may submit them and contact us : support@epeken.com.

== Installation ==

= Minimum Requirement =

* Wordpress 4.0
* Woocommerce version 3.0
* PHP version 5.2.4 or greater
* MySQL version 5.0 or greater

= Automatic installation =

Like you usually do from Plugin screen backend administrator (wp-admin), search for epeken all kurir and easily install this plugin

= Manual installation =

The manual installation method involves downloading our eCommerce plugin and uploading it to your webserver via your favourite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Updating =

Automatic updates should work like a charm; as always though, ensure you backup your site just in case.

= Configuration =

Once plugin is installed please activate it from activate link in the wordpress plugin page. After that, you need to go to dashboard main menu Woocommerce > Settings > Shipping > Epeken Courier. Click [here](https://blog.epeken.com) to get complete documentation of this product. License should be activated from MAIN MENU Settings > Epeken License Management.

== Screenshots ==

== Change Log ==

= 1.0 =
* Base Upload
= 1.0.9 = 
* Full Version
= 1.1.0 =
* Full Version with Dropship Ready. Data Asal Kota bisa diset per product. Sangat cocok untuk pengguna yang menjalankan bisnis dropship.
= 1.1.1 =
* Supporting woocommerce v.2.4
= 1.1.3 =
* Provided shipping tariff for PT POS Indonesia more valid.
= 1.1.4 =
* Fixing volume metrics functionality bug. get api ongkos tarif PT POS v2.
= 1.1.5.2 =
* Bug Fix Insurance, Angka unik
= 1.1.5.3 =
* Add - Kode Bayar BII, Niaga
* Add - Setting max angka unik
* Add - Pilihan Free Shipping for some provinces
* Add - Pop Up Loading Kecamatan
= 1.1.5.4 =
* Add - Mode Kode Pembayaran
= 1.1.5.5 =
* Add - custom tarif with is_volumetrik flag
= 1.1.5.6 =
* Add - Combine minimum total free shipping parameter, and city for free shipping
= 1.1.5.7 =
* Add - Di versi 1.1.5.7 kurir wahana sudah disupport oleh epeken all kurir
= 1.1.5.8 =
* Add - Fitur Mark Up Ongkos kirim JNE, TIKI dan POS
* Add - Fitur percentage untuk biaya tambahan
= 1.1.5.9 =
* Add - Konfirmasi Pembayaran
= 1.1.6.0 =
* Add - Pilihan satuan berat kg/g
= 1.1.6.1 =
* Modify - Bug Fix Invalid Shipping Method untuk returning customer jika mengganti alamat pengiriman pada saat checkout sehingga gagal checkout. Bug ini fix di versi ini.
= 1.1.6.2 =
* Add - Packing Kayu (Khusus JNE). Asuransi/Packing Kayu/Free ongkir product based.
= 1.1.6.3 =
* Modify - Improved Konfirmasi Pembayaran, like all fields in konfirmasi pembayaran are mandatory. Add success/failed message in konfirmasi pembayaran
= 1.1.6.4 =
* Add - Supporting plugin woocommerce multi currency. Shipping cost and other fees will be converted to selected current currency.
= 1.1.6.5 = 
* Add - Supporting new courier www.jet.co.id
= 1.1.6.6 =
* Add - Diskon Ongkir
* Tweak - bug fixing free shipping mechanism
= 1.1.6.7 =
* Add - SICEPAT
= 1.1.6.8 =
* Modify - Tarif Wahana Lebih Akurat sebab di versi ini data tarif sudah sampai level kecamatan. versi sebelumnya belum sampai level kecamatan.
= 1.1.6.9 = 
* Modify - Subsidi Tarif, cek resi di halaman sendiri dan support baru untuk kurir JNE.
= 1.1.7.3 =
* Modify - compatibility with woocommerce 3
= 1.1.7.4 =
* Add - SAP Express and Cash On Delivery (COD).
* Add - Supporting coupon with free shipping. Bisa pakai kupon kalau mau free shipping.
= 1.1.7.5 =
* Add - NOW PLUGIN EPEKEN SUPPORTS [wc-vendor](https://id.wordpress.org/plugins/wc-vendors/). to build marketplace with wc vendor plugin.
= 1.1.7.6 = 
* Add - Bisa hitung ongkir multi vendor dalam 1 cart, dengan plugin wc-vendors.
= 1.1.7.6.1 =
* Fix - Bug Fix multiple vendor dalam 1 cart.
= 1.1.7.6.2 =
* Fix - Bug Fix encoded shipping address before it is sent as parameters
= 1.1.7.6.3 =
* Fix - Performance Tuning
= 1.1.7.6.4 =
* Bug Fix - PT POS courier is not coming up. we already fixed this.
= 1.1.7.6.5 =
* Bug Fix - Wahana and SAP courier are not coming up. we already fixed this.
= 1.1.7.6.6 =
* Bug Fix autocomplete shipping province when ship to different address
= 1.1.7.7 =
* Add - Merge Opsi Internasional dalam 1 source plugin
= 1.1.7.8 =
* Bug Fix - Billing Kecamatan is required error message when shipping to other countries outside Indonesia.
= 1.1.7.9 =
* Bug Fix - Clear Transients automatically before load shipping data. To prevent failed on loading shipping cost.
= 1.1.7.9.1 =
* Add - Add NSS Express Courier
= 1.1.8.0 =
* Konfirmasi Pembayaran dengan fungsi upload bukti transfer
= 1.1.8.1 =
* Bug fix: choose kecamatan many times before it populates shipping cost in checkout page
* NOW PLUGIN EPEKEN SUPPORTS [DOKAN](https://wordpress.org/plugins/dokan-lite/) to build marketplace with Dokan plugin. 
= 1.1.8.2 =
* NOW PLUGIN EPEKEN SUPPORT [WC-MARKETPLACE](https://wordpress.org/plugins/dc-woocommerce-multi-vendor/) to build marketplace with WC Marketplace plugin
= 1.1.8.2.1 =
* BUG FIX - For multivendor with dokan-pro and wc-marketplace.
= 1.1.8.2.2 =
* BUG FIX - fix function epeken_is_vendor and epeken_is_vendor_id if checked user doesn't have role vendor.
= 1.1.8.3 =
* NOW PLUGIN EPEKEN SUPPORT [YITH MULTIVENDOR](https://yithemes.com/themes/plugins/yith-woocommerce-multi-vendor/) to build marketplace with YITH Woo Multi Vendor
= 1.1.8.3.1 =
* NOW PLUGIN EPEKEN SUPPORT [WOO-DROPSHIPPER](https://codecanyon.net/item/woocommerce-dropshippers/7615263) to build online store with dropshipping concept
* Wahana now available in multi vendor/marketplace concept
* Make shipping label more nice.
= 1.1.8.4 =
* Marketplace Bug Fix
= 1.1.8.4.1/2
* Bug Fix backward compatibity with PHP 5.4
= 1.1.8.4.3 =
* Bug Fix WC Marketplace vendor_id in shipping order item
= 1.1.8.4.4 =
* Bug Fix on checkout field labelling. Kota Kabupaten and Kecamatan should be mandatory instead of optional
= 1.1.8.4.5 =
* Add Enable/Disable button konfirmasi pembayaran pada layar my-account > orders. defaultnya adalah no atau disable. Jika tidak menggunakan fitur konfirmasi pembayaran dari epeken silakan untuk mendisable button konfirmasi pembayaran pada layar my-account > orders. Jika menggunakan fitur konfirmasi pembayaran dari epeken, sangat disarankan untuk melakukan enable button tersebut.
= 1.1.8.5 =
* Bug Fix Konfirmasi Pembayaran, Revamp checkout fields
= 1.1.8.5.1 =
* add validation on kecamatan checkout field.
= 1.1.8.5.2 =
* bug fix kecamatan validation
= 1.1.8.5.3 =
* fix width bug on field kota kabupaten and kecamatan
= 1.1.8.5.4 =
* fix bug on insurance, when place order, it was not applied if customer choose to include insurance as additional fee. now it is fixed.
= 1.1.8.5.5 =
* fix for new role 'vendor' in wc-vendor 2.0.9
= 1.1.8.5.6 =
* bug fix : edit address from my-account woocommerce front ent.
* add konfirmasi pembayaran url so that customer can link to a URL when button konfirmasi pembayaran clicked. page: my-account/order
= 1.1.8.5.7 =
* add fitur asuransi untuk RPX dan bisa pilih aktivasi kurir RPX berdasarkan jenis paketnya (MDP/NDP/RGP)
= 1.1.8.5.8 =
* functionality tarif flat, bug fix pada activate license dan beberapa bug fix yang lain.
* fitur baru subsidi ongkir dengan kupon. Anda dapat menerapkan diskon ongkir sejumlah rupiah jika customer memasukkan kode kupon tertentu. kode kupon ini bisa dimasukkan ke dalam setting plugin epeken supaya customer dapat diskon/subsidi ongkir
= 1.1.8.5.9 =
* bug fix
= 1.1.8.5.9.1 =
* Cek resi mendukung kurir JNE, J&T, POS, WAHANA, TIKI
* backward compatibility with woocommerce 2.X
* Mark Up Tarif dan Diskon Tarif untuk J&T
= 1.1.8.5.9.2 =
* Mendukung Kurir JMX (www.jmx.co.id)
* Fix bug subsidi ongkir yang terpotong 2 kali.
= 1.1.8.5.9.3 =
* Mendukung translasi front-end plugin epeken untuk bahasa Indonesia dan Bahasa Inggris.
= 1.1.8.5.9.4 =
* Mendukung Toko Online yang menggunakan default mata uangnya US Dollar.
= 1.1.8.5.9.5 =
* Code fix and improvements
= 1.1.8.5.9.6 =
* Bug fix to get weight,length,width,height from variation product if product in the cart is variation product.
= 1.1.8.5.9.7 =
* By Default billing city and billing shipping is blank, to adapt with latest woocommerce version.
= 1.1.8.5.9.8 =
* Update kota kecamatan. Di versi sebelumnya ada beberapa kecamatan yang belum masuk, versi kali ini kecamatan sudah lebih update.
= 1.1.8.5.9.9 =
* Important performance update. memperbaiki performance plugin epeken all kurir di website Anda.
= 1.1.8.5.9.10 =
* Bug Fix: Exclude RPX VLP
= 1.1.8.5.9.11 =
* fitur baru free ongkir per produk untuk kota-kota tertentu.
= 1.1.8.5.9.12 =
* Tarif PT POS Improved sampai dengan level kecamatan.
= 1.1.8.5.9.14 =
* Bug Fix Kecamatan Encoded before API call PT POS
= 1.1.8.5.10 = 
* Now, Plugin Epeken supports [woocommerce multivendor marketplace](https://wordpress.org/plugins/wc-multivendor-marketplace/) by WC Lovers. 
= 1.1.8.5.10.1 = 
* bug fix, RPX muncul 0 walaupun tidak diaktifkan.
= 1.1.8.5.10.2 = 
* add maybank manual transfer payment method and display bank account number in customer view order front end page.
= 1.1.8.5.10.3 = 
* alamat pengiriman otomatis terload saat checkout untuk user-user yang sudah logged in di halaman checkout
= 1.1.8.5.10.4 = 
* auto populate alamat pelanggan saat checkout dibuat configurable dari wp-admin pada setting Auto populate alamat checkbox.
= 1.1.8.5.10.5 = 
* bug fix issue RPX RGS
= 1.1.8.5.11 =
* Lion Parcel is just onboard Epeken All Kurir
* Bug Fix Volumetrik Calculation
= 1.1.8.5.11.1 =
* Bug Fix Multivendor dokan: Shipping Tidak muncul di level order vendor dashboard. Sudah diperbaiki.
= 1.1.8.5.11.2 =
* Bug Fix Multivendor WCFM: Shipping Tidak muncul di level order vendor dashboard. Sudah diperbaiki.
* Flat Tarif Per Vendor
= 1.1.8.5.11.3 =
* front end modify pilihan kurir pada vendor di wcfm + dokan
= 1.1.8.5.11.4 = 
* many bug fixes and add ePacket LX Prime for international shipping.
= 1.1.8.5.11.5 = 
* bug fix, fixing checkout fields layout if default country location is not Indonesia.
= 1.1.8.5.12 =
* bug fix and improvements.
= 1.1.8.5.13 = 
* Pilihan Data Server Singapura dan Indonesia
= 1.1.8.5.13.1 = 
* Adding KARGOPOS RITEL TRAIN & KARGOPOS RITEL UDARA
= 1.1.8.5.14 =
* Important Bug Fix to increase performance in loading shipping cost at checkout page.
= 1.1.8.5.14.1 =
* Temporary fix for PT POS Intl shipping info problem.
= 1.1.8.5.14.2 = 
* Fix unwanted RPX service.
= 1.1.8.5.14.3 = 
* Added new css.
= 1.1.8.5.15 =
* Together with Epeken Ojek Online support marketplace
= 1.1.8.5.16 = 
* Bug Fix for running with yith multi vendor newest version.
= 1.1.8.5.17 =
* Adding Ninja Express as new logistics into Epeken All Kurir.
= 1.1.8.5.18 = 
* Enable JNE Trucking for multi vendor
= 1.1.8.5.20 =
* Bug fix tariff not correct for city and kecamatan with slash character
= 1.1.8.5.25 =
* Bug fix performance issue. Duplicate ajax call. This will speed up shipping cost loading in checkout page
= 1.1.8.5.26 = 
* Sudah support kurir Dakota Kargo (dakotacargo.co.id)
= 1.1.8.5.27 =
* Bug fix cache in checkout field issue regarding with change international and local shipping destination
= 1.1.8.5.28 =
* Bug Fix shipping is not included the vendor dashboard when running multivendor using wcfm marketplace (wc lovers)
= 1.1.8.5.28.1 =
* Settings enable berat untuk perhitungan ongkir dipisah dengan enable dimensi untuk perhitungan ongkir
= 1.1.8.6 = 
* New format in checkout fields. Reorder field: Province, City and District.
= 1.1.8.6.1 =
* Bug fix update billing and shipping contact from account page.
= 1.1.8.6.2 =
* Some setting layout changes in wp-admin.
= 1.1.8.6.3 = 
* add action epeken_is_free_shiping_filter untuk memberikan peluang untuk customize combining free shipping criteria.
= 1.1.8.6.4 = 
* add action to decide whether subsidi is applied or not.
= 1.1.8.6.5 =
* fixing volumetrik calculation
= 1.1.8.6.6 =
* bug fixed from 1.1.8.6.5
= 1.1.8.6.7 =
* preserve jquery migrate for wp 5.5, to users that are using wp 5.5 should upgrade to epeken plugin version 1.1.8.6.7
= 1.1.8.6.8 = 
* bug fix when admin disable a shipping service, it should impact to vendor shipping service choice too.
= 1.1.8.6.9 = 
* bug fix in konfirmasi pembayaran using ajax asynchronous
= 1.1.8.6.10 =
* bug fix sub order of dokan order doesn't contain shipping
= 1.1.8.6.12 = 
* bug fix cek resi JNE
= 1.1.8.6.14 = 
* bug fix layout on v.1.1.8.6.13
= 1.1.8.6.15 = 
* bug fix checkout fields behaviour.
= 1.1.8.6.16 = 
* big fix refreshing international shipping when change billing/shipping address in checkout page.
= 1.1.8.6.17 = 
* important update to keep compatibility with Wordpress 5.6
= 1.1.8.6.18 = 
* RPX is ready to use for multi origin/marketplace.
= 1.1.8.6.19 = 
* Bug Fix for Dokan PRO/Business Users for marketplace online store.
= 1.1.8.6.20 = 
* Bug Fix, force to use jquery migrate 1.4.1 in checkout page. So far, Epeken shipping plugin works with up to jquery version 1.4.1
= 1.1.8.6.21 = 
* Bug Fix, use jquery migrate version 3 in the admin backend page.
* Bug Fix, solve critical issue in site health about session_start and session_write_close.
* add ETA for JNE and TIKI, other couriers ETA will be available in next version. 
= 1.1.8.6.22 =
* bug fix, license management problem in 1.1.8.6.21.
= 1.1.8.6.23 =
* bug fix, halaman konfirmasi pembayaran pada versi 1.1.8.6.22
= 1.1.8.6.24 = 
* bug fix, billing kecamatan and kelurahan fixed on dokan sub order in marketplace concept.
= 1.1.8.6.25 = 
* bug fix, JNE and TIKI disable/enable services.
= 1.2.2 = 
* bug fix and code improvements. 
= 1.2.3 = 
* bug fix on session management.
= 1.2.4 = 
* added atlas express.
= 1.2.7 = 
* Bug Fixing PT POS volumetrix
= 1.2.8 = 
* Added Sicepat SIUNT, GOKIL, SDS
= 1.2.9 = 
* Added JNE International
= 1.3.1 = 
* Bug fix cek resi JNE
= 1.3.2 = 
* Performance improvement, added international courier POS EKSPOR
= 1.3.3 = 
* Bug fixes, support dimension in mm
= 1.3.4 =
* Bug Fixes, Konfirmasi Pembayaran
= 1.3.4.2 =
* Bug Fixes, Anticipate select2() error using try catch.
= 1.3.4.3 =
* Added cities configuration for COD shipping method.
= 1.3.5 = 
* Compatible with plugin "WooCommerce Multi Inventory & Warehouses". Contact us if you want to implement multi inventory and warehouse.
= 1.3.5.1 =
* Bug fix after v.1.3.5 broken. Please upgrade to 1.3.5.1.
= 1.3.5.2 = 
* Bug fix floating checkout fields label
= 1.3.6 = 
* Add new rate service POS REGULER, SAMEDAY and NEXTDAY
= 1.3.7 = 
* Bug fix additional markup validation.
= 1.3.8 = 
* Multi origin for marketplace is compatible with WooCommerce Product Vendors Plugin.
= 1.3.9 = 
* Bug fix for multi site and multi inventory
* Function to specify countries on international shipping
= 1.4.0 =
* Compatible with MultiVendorX. Disable compatibility with WC Marketplace as it is rebranded to MultiVendorX.
= 1.4.1 =
* Subsidi ongkir can be specified for some cities only
= 1.4.1.2 =
* Bug Fixes
= 1.4.3 = 
* Fitur COD Dengan Kurir: Penambahan biaya (fee) COD dengan kurir dengan persentase ongkir + harga barang
= 1.4.4 =
* Auto Classic Checkout

