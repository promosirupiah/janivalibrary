jQuery(document).ready(function($) {
	var wcsApp = {
		operators: [],
		triggersInit: false,

		init: function() {
			var table = $( 'table.wcs-conditions-table' );

			if ( table.length == 0 ) {
				return;
			}

			this.operators = table.data( 'operators' );

			var self = this;
			$( 'table.wcs-conditions-table' ).each( function() {
				self.insertExisting($(this));
			} );

			if ( ! this.triggersInit ) {
				this.triggerFieldUpdates();
				this.triggerRemoveConditions();
				this.triggerAddCondition();
				this.triggerToggleValueInputs();

				this.triggersInit = true;
			}
		},

		/**
		 * Show correct fields when changing condition type
		 */
		triggerFieldUpdates: function() {
			var self = this;

			$(document).on('change', 'select.wcs_condition_type_select', function() {
				var row = $(this).closest('tr');

				self.toggleOperators(row);
				self.toggleValueInputs(row);
			});
		},

		/**
		 * Insert existing conditions into the table
		 */
		insertExisting: function(table) {
			if ( table.length > 0 ) {
				for (var i = 0; i < table.data('conditions').length; i++) {
					this.addCondition(table, table.data('conditions')[i]);
				}
			}

			$( document.body ).trigger( 'wc-enhanced-select-init' );

			this.toggleAllValueInputs();
			this.initAutocomplete();
		},

		/**
		 * Init autocomplete fields
		 */
		initAutocomplete: function() {
			$('select.wcs_product_value_ajax_input:not(.inited)').each(function() {
				$(this).addClass('inited');

				$(this).select2({
				  ajax: {
				    url: ajaxurl,
				    dataType: 'json',
						data: function (params) {
							var query = {
								q: params.term,
								action: 'wcs_product_search'
							}

							return query;
						}
				  }
				});
			});
		},

		/**
		 * Toggle all value inputs
		 */
		toggleAllValueInputs: function() {
			var self = this;

			$('table.wcs-conditions-table tbody tr').each(function() {
				self.toggleOperators($(this));
				self.toggleValueInputs($(this));
			});
		},

		/**
		 * Toggle value inputs for a single row
		 */
		toggleValueInputs: function(row) {
			this.removeClassStartingWith(row, 'wcs-operator-');
			this.removeClassStartingWith(row, 'wcs-type-');

			var type = $('select.wcs_condition_type_select', row).val();
			var operator = $('select.wcs_operator_select', row).val();

			row.addClass('wcs-operator-' + operator);
			row.addClass('wcs-type-' + type);
		},

		/**
		 * Toggle operators
		 */
		toggleOperators: function(row) {
			var operators = $('select.wcs_condition_type_select option:selected', row).data( 'operators' );

			// Save current value
			var currentValue = $( 'select.wcs_operator_select', row ).val();

			// First remove all operators
			$( 'select.wcs_operator_select option', row ).remove();

			var self = this;
			$.each( operators, function( index, value ) {
				self.renderOperator( row, value );
			} );

			if ( typeof currentValue != 'undefined' ) {
				if ( $( 'select.wcs_operator_select option[value="' + currentValue + '"]', row ).length > 0 ) {
					$( 'select.wcs_operator_select', row ).val( currentValue ).trigger( 'change' );
				}
			}
		},

		/**
		 * Render operator
		 */
		renderOperator: function(row, operator) {
			var operatorTitle = this.operators[operator];

			$( 'select.wcs_operator_select', row ).append( '<option value="' + operator + '">' + operatorTitle + '</option>' );
		},

		/**
		 * Add new condition
		 */
		addCondition: function(table, data) {
			// Get index
			var index = table.data('index');
			if (typeof index == 'undefined') { index = 0; }
			data['index'] = index;

			// Get instance ID
			var instance_id = table.data( 'instance-id' );

			// Add one to conditions table index
			table.data('index', index + 1);

			// Get template
			var row_template = wp.template( 'wcs_row_template_' + instance_id );

			// Add products
			var products_data = table.data('selected-products');
			data.selected_products = [];
			if (typeof data.product_ids !== 'undefined' && data.product_ids !== null && data.product_ids.length > 0) {
				jQuery.each(data.product_ids, function(index, product_id) {
					if (typeof products_data[product_id] !== 'undefined') {
						data.selected_products.push({
							'id': product_id,
							'title': products_data[product_id]
						});
					}
				});
			}

			// Render template and add to the table
			$('tbody', table).append( row_template(data) );

			$( document.body ).trigger( 'wc-enhanced-select-init' );

			this.toggleAllValueInputs();
			this.initAutocomplete();
		},

		/**
		 * Remove selected conditions when clicking the button
		 */
		triggerRemoveConditions: function() {
			$(document).on('click', 'button#wcs-remove-conditions', function() {
				var table = $(this).closest('table.wcs-conditions-table');

				$('.condition_row input.remove_condition:checked', table).closest('tr.condition_row').remove();
			});
		},

		/**
		 * Add new condition when clicking the Add button
		 */
		triggerAddCondition: function() {
			var self = this;

			$(document).on('click', 'button#wcs-add-condition', function() {
				var table = $(this).closest('table.wcs-conditions-table');
				self.addCondition(table, {});
			});
		},

		/**
		 * Update value inputs when changing operator type
		 */
		triggerToggleValueInputs: function() {
			var self = this;

			$(document).on('change', 'select.wcs_operator_select', function() {
				var row = $(this).closest('tr');
				self.toggleValueInputs(row);
			});
		},

		removeClassStartingWith: function(el, filter) {
			el.removeClass(function (index, className) {
				return (className.match(new RegExp("\\S*" + filter + "\\S*", 'g')) || []).join(' ');
			});
		}
	};

	$( document.body ).on( 'wc_backbone_modal_loaded', function() {
		wcsApp.init();
	});
	wcsApp.init();
});
