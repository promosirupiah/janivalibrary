<?php

/*
Plugin Name: Conditional Shipping for WooCommerce
Description: Disable shipping methods based on shipping classes, weight, categories and much more.
Version:     1.1.1
Author:      Lauri Karisola / WooElements.com
Author URI:  https://wooelements.com
Text Domain: woo-conditional-shipping
Domain Path: /languages
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Stable Tag:  1.1.1
WC requires at least: 3.0.0
WC tested up to: 3.4.5
*/

/**
 * Prevent direct access to the script.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin version
 */
if ( ! defined( 'WOO_CONDITIONAL_SHIPPING_VERSION' ) ) {
	define( 'WOO_CONDITIONAL_SHIPPING_VERSION', '1.1.1' );
}

/**
 * Load updater
 */
require_once 'includes/class-conditional-shipping-updater.php';

/**
 * Load filters
 */
require_once 'includes/class-conditional-shipping-filters.php';

/**
 * Load plugin textdomain
 *
 * @return void
 */
add_action( 'plugins_loaded', 'woo_conditional_shipping_load_textdomain' );
function woo_conditional_shipping_load_textdomain() {
  load_plugin_textdomain( 'woo-conditional-shipping', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}

class Woo_Conditional_Shipping {
	private $allowed_classes;
	private $wc_shipping;

	function __construct() {
	}

	public function setup() {
		// WooCommerce not activated, abort
		if ( ! defined( 'WC_VERSION' ) ) {
			return;
		}

		// Prevent running same actions twice if Pro version is enabled
		if ( class_exists( 'Woo_Conditional_Shipping_Pro' ) ) {
			return;
		}

		$this->wc_shipping = WC_Shipping::instance();
		$this->allowed_classes = $this->wc_shipping->get_shipping_method_class_names();

		// Process options for all shipping methods
		foreach ( array_keys( $this->allowed_classes ) as $class_id ) {
			add_filter( 'woocommerce_shipping_' . $class_id . '_instance_settings_values', array( $this, 'process_options' ), 10, 2 );
		}

		// Add fields for conditions
		add_filter( 'woocommerce_shipping_zone_shipping_methods', array( $this, 'add_fields_modal' ), 10, 4 );
		add_filter( 'woocommerce_settings_shipping', array( $this, 'add_fields' ), 20, 0 );

		// Exclude shipping methods
		add_filter( 'woocommerce_package_rates', array( $this, 'exclude_shipping_methods' ), 10, 2 );

		// Add admin JS
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

		// Add AJAX page for searching products
		add_action( 'wp_ajax_wcs_product_search', array( $this, 'product_ajax_search' ) );

		// Go Pro settings link
		add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), array( $this, 'add_settings_link' ) );

		// Show save button for shipping methods created with WooCommerce Services
		add_action( 'wc_connect_service_admin_options', array( $this, 'enable_save_button' ), 10, 0 );
	}

	/**
	 * Add settings link to the plugins page.
	 */
	public function add_settings_link( $links ) {
		$link = '<span style="font-weight:bold;"><a href="https://wooelements.com/products/conditional-shipping" style="color:#46b450;" target="_blank">' . __( 'Go Pro' ) . '</a></span>';

		return array_merge( array( $link ), $links );
	}

	/**
	 * Add admin JS
	 */
	public function admin_enqueue_scripts() {
		wp_enqueue_script( 'jquery-ui-autocomplete' );
		wp_enqueue_script( 'woo_conditional_shipping_js', plugin_dir_url( __FILE__ ) . '/admin/js/woo-conditional-shipping.js', array( 'jquery', 'wp-util' ), WOO_CONDITIONAL_SHIPPING_VERSION );
		wp_enqueue_style( 'woo_conditional_shipping_css', plugin_dir_url( __FILE__ ) . '/admin/css/woo-conditional-shipping.css', array(), WOO_CONDITIONAL_SHIPPING_VERSION );
	}

	/**
 	* Enable save button for shipping methods done with WooCommerce Services
 	 */
	public function enable_save_button() {
		global $hide_save_button;
		$hide_save_button = false;
	}

	/**
	 * Process conditions when saving a shipping method
	 */
	public function process_options( $instance_settings, $method ) {
		$conditions = array();
		$post_data = $method->get_post_data();

		$settings_prefix = $method->plugin_id . $method->id;

		if ( isset( $post_data[ $settings_prefix . '_wcs_condition_ids' ] ) ) {
			foreach ( $post_data[ $settings_prefix . '_wcs_condition_ids' ] as $key ) {
				$conditions[] = array(
					'type' => $this->get_field_value( $method, $key, 'wcs_type' ),
					'operator' => $this->get_field_value( $method, $key, 'wcs_operator' ),
					'value' => $this->get_field_value( $method, $key, 'wcs_value' ),
					'shipping_class_ids' => $this->get_field_value( $method, $key, 'wcs_value_shipping_class_ids' ),
					'category_ids' => $this->get_field_value( $method, $key, 'wcs_value_category_ids' ),
					'product_ids' => $this->get_field_value( $method, $key, 'wcs_value_product_ids' ),
				);
			}
		}

		$all_conditions = get_option( 'wcs_conditions', array() );
		$all_conditions[$method->instance_id] = $conditions;

		update_option( 'wcs_conditions', $all_conditions );

		return $instance_settings;
	}

	/**
	 * Get field value from post data
	 */
	private function get_field_value( $method, $key, $index ) {
		$post_data = $method->get_post_data();
		$settings_prefix = $method->plugin_id . $method->id;
		$settings_key = "{$settings_prefix}_{$index}_{$key}";

		return isset( $post_data[$settings_key] ) ? $post_data[$settings_key] : NULL;
	}

	/**
	 * Get a grouped list of filters
	 */
	public function filter_groups() {
		return array(
			array(
				'title' => __( 'Measurements', 'woo-conditional-shipping' ),
				'filters' => array(
					'weight' => array(
						'title' => sprintf( __( 'Weight (%s)', 'woo-conditional-shipping' ), get_option( 'woocommerce_weight_unit' ) ),
						'operators' => array( 'gt', 'gte', 'lt', 'lte' ),
					),
					'height_total' => array(
						'title' => sprintf( __( 'Total Height (%s)', 'woo-conditional-shipping' ), get_option( 'woocommerce_dimension_unit' ) ),
						'operators' => array( 'gt', 'gte', 'lt', 'lte' ),
					),
					'length_total' => array(
						'title' => sprintf( __( 'Total Length (%s)', 'woo-conditional-shipping' ), get_option( 'woocommerce_dimension_unit' ) ),
						'operators' => array( 'gt', 'gte', 'lt', 'lte' ),
					),
					'width_total' => array(
						'title' => sprintf( __( 'Total Width (%s)', 'woo-conditional-shipping' ), get_option( 'woocommerce_dimension_unit' ) ),
						'operators' => array( 'gt', 'gte', 'lt', 'lte' ),
					),
					'volume' => array(
						'title' => sprintf( __( 'Total Volume (%s&sup3;)', 'woo-conditional-shipping' ), get_option( 'woocommerce_dimension_unit' ) ),
						'operators' => array( 'gt', 'gte', 'lt', 'lte' ),
					),
				)
			),
			array(
				'title' => __( 'Cart', 'woo-conditional-shipping' ),
				'filters' => array(
					'subtotal' => array(
						'title' => __( 'Subtotal', 'woo-conditional-shipping' ),
						'operators' => array( 'gt', 'gte', 'lt', 'lte' ),
					),
					'products' => array(
						'title' => __( 'Products', 'woo-conditional-shipping' ),
						'operators' => array( 'in', 'notin', 'exclusive', 'allin' ),
					),
				)
			),
		);
	}

	/**
	 * Get a list of operators
	 */
	public function operators() {
		return array(
			'gt' => __( 'greater than', 'woo-conditional-shipping' ),
			'gte' => __( 'greater than or equal', 'woo-conditional-shipping' ),
			'lt' => __( 'less than', 'woo-conditional-shipping' ),
			'lte' => __( 'less than or equal', 'woo-conditional-shipping' ),
			'in' => __( 'includes', 'woo-conditional-shipping' ),
			'exclusive' => __( 'includes (exclusive)', 'woo-conditional-shipping' ),
			'notin' => __( 'excludes', 'woo-conditional-shipping' ),
			'allin' => __( 'all present', 'woo-conditional-shipping' ),
			'is' => __( 'is', 'woo-conditional-shipping' ),
			'isnot' => __( 'is not', 'woo-conditional-shipping' ),
			'exists' => __( 'is not empty', 'woo-conditional-shipping' ),
			'notexists' => __( 'is empty', 'woo-conditional-shipping' ),
			'contains' => __( 'contains', 'woo-conditional-shipping' ),
			'loggedin' => __( 'logged in', 'woo-conditional-shipping' ),
			'loggedout' => __( 'logged out', 'woo-conditional-shipping' ),
		);
	}

	/**
	 * Add fields to a shipping method settings in a modal
	 */
	public function add_fields_modal( $methods, $raw_methods, $allowed_classes, $wc_shipping_zone ) {
		foreach ( $methods as $instance_id => $method ) {
			if ( $method->has_settings ) {
				// Do not add settings to the modal if there are no other settings. Plugins
				// like USPS only show settings in a separate window.
				if ( ! empty ( $method->settings_html ) ) {
					$methods[$instance_id]->settings_html .= $this->generate_settings_html( $method );
				}
			}
		}

		return $methods;
	}

	/**
	 * Add fields to a shipping method settings in a separate page
	 */
	public function add_fields() {
		if ( isset( $_REQUEST['instance_id'] ) && ! empty( $_REQUEST['instance_id'] ) ) {
			$instance_id = absint( $_REQUEST['instance_id'] );
			$zone = WC_Shipping_Zones::get_zone_by( 'instance_id', $instance_id );
			$shipping_method = WC_Shipping_Zones::get_shipping_method( $instance_id );

			if ( ! $shipping_method || ! $zone || ! $shipping_method->has_settings() ) {
				return;
			}

			echo $this->generate_settings_html( $shipping_method );
		}
	}

	/**
	 * Generate settings HTML for conditions
	 */
	public function generate_settings_html( $method ) {
		$output = '';
		$output .= $this->generate_title_html( __( 'Conditions', 'woo-conditional-shipping' ) );
		$output .= $this->generate_table_html( $method );

		return $output;
	}

	/**
	 * Generate settings title
	 */
	private function generate_title_html( $title ) {
		ob_start();
		?>
			<h3 class="wc-settings-sub-title"><?php echo wp_kses_post( $title ); ?></h3>
		<?php

		return ob_get_clean();
	}

	/**
	 * Generate table HTML
	 */
	private function generate_table_html( $method ) {
		$all_conditions = get_option( 'wcs_conditions', array() );
		$conditions = array();

		if ( isset( $all_conditions[$method->instance_id] ) ) {
			$conditions = $all_conditions[$method->instance_id];
		}

		// Products in condition fields
		// Needed for showing titles in select2 fields
		$products = $this->load_products_for_method( $method, $conditions );

		return '<table class="form-table wcs-conditions-table" data-instance-id="' . $method->instance_id .'" data-operators="' . htmlspecialchars( json_encode( $this->operators() ), ENT_QUOTES, 'UTF-8' ) . '" data-selected-products="' . htmlspecialchars( json_encode( $products ), ENT_QUOTES, 'UTF-8' ) . '" data-conditions="' . htmlspecialchars( json_encode( $conditions ), ENT_QUOTES, 'UTF-8' ) . '"><tbody>' . $this->generate_rows_html( $method ) . '</tbody>' . $this->generate_tfoot_html() . '</table>';
	}

	/**
	 * Generate table rows HTML
	 */
	private function generate_rows_html( $method ) {
		ob_start();
		?>
		<?php $this->_conditions_row_template( $method ); ?>
		<?php

		return ob_get_clean();
	}

	/**
	 * Template for conditions row
	 */
	private function _conditions_row_template( $method ) {
	?>
	<script type="text/html" id="tmpl-wcs_row_template_<?php echo $method->instance_id; ?>">
		<tr valign="top" class="condition_row">
			<th class="condition_remove">
				<input type="checkbox" class="remove_condition">
			</th>
			<th scope="row" class="titledesc">
				<fieldset>
					<input type="hidden" name="<?php echo $this->get_field_key( $method, 'wcs_condition_ids'); ?>[]" value="{{ data.index }}" />
					<select name="<?php echo $this->get_field_key($method, 'wcs_type'); ?>_{{data.index}}" class="wcs_condition_type_select">
						<?php foreach ( $this->filter_groups() as $filter_group ) { ?>
							<optgroup label="<?php echo $filter_group['title']; ?>">
								<?php foreach ( $filter_group['filters'] as $key => $filter ) { ?>
									<option
										value="<?php echo $key; ?>"
										data-operators="<?php echo htmlspecialchars( json_encode( $filter['operators'] ), ENT_QUOTES, 'UTF-8'); ?>"
										<# if ( data.type == '<?php echo $key; ?>' ) { #>selected<# } #>
									>
										<?php echo $filter['title']; ?>
									</option>
								<?php } ?>
							</optgroup>
						<?php } ?>
					</select>
				</fieldset>
			</th>
			<td class="forminp">
				<select class="wcs_operator_select" name="<?php echo $this->get_field_key($method, 'wcs_operator'); ?>_{{data.index}}">
					<?php foreach ( $this->operators() as $key => $operator ) { ?>
						<option
							value="<?php echo $key; ?>"
							class="wcs-operator wcs-operator-<?php echo $key; ?>"
							<# if ( data.operator == '<?php echo $key; ?>' ) { #>selected<# } #>
						>
							<?php echo $operator; ?>
						</option>
					<?php } ?>
				</select>
			</td>
			<td class="forminp">
				<fieldset class="wcs_condition_value_inputs">
					<input class="input-text value_input regular-input wcs_text_value_input" type="text" name="<?php echo $this->get_field_key($method, 'wcs_value'); ?>_{{data.index}}" value="{{data.value}}" />

					<div class="value_input wcs_product_value_input">
						<select class="wcs_product_value_ajax_input" name="<?php echo $this->get_field_key( $method, 'wcs_value_product_ids' ); ?>_{{data.index}}[]" class="select" multiple>
							<# if ( data.selected_products && data.selected_products.length > 0 ) { #>
								<# _.each(data.selected_products, function(product) { #>
									<option value="{{ product['id'] }}" selected>{{ product['title'] }}</option>
								<# }) #>
							<# } #>
						</select>
					</div>
				</fieldset>
			</td>
		</tr>
	</script>
	<?php
	}

	/**
 	* Get field key for a shipping method
 	*/
	private function get_field_key( $method, $key ) {
		return $method->plugin_id . $method->id . '_' . $key;
	}

	/**
	 * Generate table foot HTML
	 */
	public function generate_tfoot_html() {
		ob_start();
		?>
		<tfoot>
			<tr valign="top">
				<td colspan="2" class="forminp">
					<button type="button" class="button" id="wcs-add-condition"><?php _e( 'Add Condition', 'woo-conditional-shipping' ); ?></button>
					<button type="button" class="button" id="wcs-remove-conditions"><?php _e( 'Remove Selected', 'woo-conditional-shipping' ); ?></button>
				</td>
			</tr>
		</tfoot>
		<?php

		return ob_get_clean();
	}

	/**
	 * Load all products in the conditions for a method
	 */
	private function load_products_for_method( $method, $conditions ) {
		$product_ids = array();

		foreach ( $conditions as $condition ) {
			if ( is_array( $condition['product_ids'] ) ) {
				$product_ids = array_merge( $product_ids, $condition['product_ids'] );
			}
		}

		$products = array();
		foreach ( $product_ids as $product_id ) {
			$product = get_post( $product_id );
			if ( $product ) {
				$products[$product_id] = $product->post_title;
			}
		}

		return $products;
	}

	/**
	 * AJAX search for products
	 */
	public function product_ajax_search() {
		if ( ! is_admin() ) {
			wp_die( __( 'Access denied', 'woo-conditional-shipping' ) );
		}

		if ( empty( $_GET['q'] ) ) {
			echo json_encode(array());
			wp_die();
		}

		$args = array(
			'post_type' => array( 'product', 'product_variation' ),
			'posts_per_page' => 10,
			'offset' => 0,
			's' => $_GET['q'],
			'orderby' => 'title',
			'order' => 'ASC'
		);
		$query = new WP_Query( $args );

		$results = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();

				$id = get_the_ID();
				$title = get_the_title();

				$results[] = array(
					'id' => $id,
					'text' => html_entity_decode( $title )
				);
			}
		}

		$output = array(
			'results' => $results
		);

		echo json_encode($output);

		wp_die();
	}

	/**
	 * Filter shipping classes in the checkout
	 */
	public function exclude_shipping_methods( $rates, $package ) {
		$all_conditions = get_option( 'wcs_conditions', array() );

		foreach( $rates as $key => $rate ) {
			if ( ! is_object( $rate ) || ! isset( $rate->method_id ) ) {
				continue;
			}

			// Get instance ID
			$instance_id = FALSE;
			if ( method_exists( $rate, 'get_instance_id' ) && strlen( strval( $rate->get_instance_id() ) ) > 0 ) {
				$instance_id = $rate->get_instance_id();
			} else {
				if ( $rate->method_id == 'oik_weight_zone_shipping' ) {
					$ids = explode( '_', $rate->id );
					$instance_id = end( $ids );
				} else {
					$ids = explode( ':', $rate->id );
					if ( count($ids) >= 2 ) {
						$instance_id = $ids[1];
					}
				}
			}

			$instance_id = strval( $instance_id );
			if ( $instance_id === FALSE || ! ctype_digit( $instance_id ) ) {
				continue;
			}

			$conditions = isset( $all_conditions[$instance_id] ) ? $all_conditions[$instance_id] : array();

			if ( ! empty( $conditions ) ) {
				foreach ( $conditions as $index => $condition ) {
					if ( isset( $condition['type'] ) && ! empty( $condition['type'] ) ) {
						if ( call_user_func( array( 'Woo_Conditional_Shipping_Filters', "filter_{$condition['type']}" ), $condition, $package ) ) {
							unset( $rates[$key] );
						}
					}
				}
			}
		}

		return $rates;
	}
}

function init_woo_conditional_shipping() {
	$woo_conditional_shipping = new Woo_Conditional_Shipping();
	$woo_conditional_shipping->setup();
}

add_action( 'init', 'init_woo_conditional_shipping', 110 );
