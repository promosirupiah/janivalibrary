<?php if ($show_gmap) { ?>
  <div class="woocommerce-checkout-review-order">
    <label><a href="#map" id="mapButton"><?php echo $message; ?></a></label>
  </div>
  <?php } ?>
