# betrs-shipping-cities
Add a new section to your Table Rate settings page to limit options to specific cities
