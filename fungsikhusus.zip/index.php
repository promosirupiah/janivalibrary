<?php
/**
 * Plugin Name: Fungsi Khusus
 * Description: Mengatur Web ini
 * Version: 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Proteksi dari akses langsung
}


/**
 * =========================================================
 * 1. LOAD MODUL AJAX & AUTOCOMPLETE PODS
 * =========================================================
 */

require_once __DIR__ . '/ajax/podskota.php';


/**
 * =========================================================
 * 2. REGISTER HOOK AKTIVASI & DEAKTIVASI PLUGIN
 * =========================================================
 */

register_activation_hook(
    __FILE__,
    'fungsikhusus_add_htaccess_rules'
);

register_deactivation_hook(
    __FILE__,
    'fungsikhusus_remove_htaccess_rules'
);


/**
 * =========================================================
 * 3. MENAMBAHKAN RULE KE .HTACCESS
 * =========================================================
 *
 * Blok FungsiKhususAjax akan ditempatkan:
 *
 * # BEGIN FungsiKhususAjax
 * ...
 * # END FungsiKhususAjax
 *
 * tepat SEBELUM:
 *
 * # BEGIN WordPress
 *
 * Jika # BEGIN WordPress tidak ditemukan,
 * blok akan ditempatkan di paling atas.
 */

function fungsikhusus_add_htaccess_rules() {

    require_once ABSPATH . 'wp-admin/includes/file.php';

    /*
     * Lokasi .htaccess WordPress
     */
    $htaccess_path = get_home_path() . '.htaccess';


    /*
     * Pastikan file .htaccess ada.
     */
    if ( ! file_exists( $htaccess_path ) ) {

        /*
         * Buat file kosong jika belum ada.
         */
        file_put_contents(
            $htaccess_path,
            ''
        );
    }


    /*
     * Baca isi .htaccess.
     */
    $htaccess = file_get_contents( $htaccess_path );

    if ( $htaccess === false ) {
        return;
    }


    /**
     * =====================================================
     * BLOK RULE YANG AKAN DITAMBAHKAN
     * =====================================================
     */

    $marker_start = '# BEGIN FungsiKhususAjax';
    $marker_end   = '# END FungsiKhususAjax';

    $rules = implode(
        "\n",
        array(
            $marker_start,

            '<IfModule mod_rewrite.c>',

            'RewriteEngine On',

            'RewriteRule ^ongkirajax.php/?$ /wp-content/plugins/fungsikhusus/ajax/ongkirajax.php [L,QSA]',

            'RewriteRule ^resiajax.php/?$ /wp-content/plugins/fungsikhusus/ajax/resiajax.php [L,QSA]',

            '</IfModule>',

            $marker_end,
        )
    );


    /**
     * =====================================================
     * HAPUS BLOK LAMA
     * =====================================================
     *
     * Ini penting supaya ketika plugin diaktifkan kembali
     * tidak terjadi duplikasi rule.
     */

    $pattern = '/^[ \t]*# BEGIN FungsiKhususAjax.*?# END FungsiKhususAjax[ \t]*\r?\n?/ms';

    $htaccess = preg_replace(
        $pattern,
        '',
        $htaccess
    );


    /*
     * Jika regex di atas tidak menemukan blok karena
     * posisinya berada setelah karakter lain, gunakan
     * pencarian blok yang lebih fleksibel.
     */

    $pattern_fallback =
        '/# BEGIN FungsiKhususAjax.*?# END FungsiKhususAjax\s*/s';

    $htaccess = preg_replace(
        $pattern_fallback,
        '',
        $htaccess
    );


    /**
     * =====================================================
     * CARI # BEGIN WordPress
     * =====================================================
     */

    $wordpress_marker = '# BEGIN WordPress';

    $pos = strpos(
        $htaccess,
        $wordpress_marker
    );


    /**
     * =====================================================
     * SISIPKAN SEBELUM # BEGIN WordPress
     * =====================================================
     */

    if ( $pos !== false ) {

        /*
         * Bagian sebelum # BEGIN WordPress
         */
        $before = substr(
            $htaccess,
            0,
            $pos
        );


        /*
         * Bagian mulai # BEGIN WordPress
         */
        $after = substr(
            $htaccess,
            $pos
        );


        /*
         * Gabungkan kembali.
         */
        $htaccess =
            rtrim( $before ) .
            "\n\n" .
            $rules .
            "\n\n" .
            ltrim( $after );

    } else {

        /**
         * =================================================
         * # BEGIN WordPress TIDAK DITEMUKAN
         * =================================================
         *
         * Maka blok diletakkan paling atas.
         */

        $htaccess =
            $rules .
            "\n\n" .
            ltrim( $htaccess );
    }


    /**
     * =====================================================
     * SIMPAN .HTACCESS
     * =====================================================
     */

    file_put_contents(
        $htaccess_path,
        $htaccess,
        LOCK_EX
    );
}


/**
 * =========================================================
 * 4. MENGHAPUS RULE DARI .HTACCESS
 * =========================================================
 *
 * Fungsi ini dipanggil ketika plugin dinonaktifkan.
 */

function fungsikhusus_remove_htaccess_rules() {

    require_once ABSPATH . 'wp-admin/includes/file.php';


    /*
     * Lokasi .htaccess
     */
    $htaccess_path = get_home_path() . '.htaccess';


    /*
     * Pastikan file ada.
     */
    if ( ! file_exists( $htaccess_path ) ) {
        return;
    }


    /*
     * Baca .htaccess.
     */
    $htaccess = file_get_contents(
        $htaccess_path
    );

    if ( $htaccess === false ) {
        return;
    }


    /**
     * =====================================================
     * HAPUS BLOK FungsiKhususAjax
     * =====================================================
     */

    $pattern =
        '/\s*# BEGIN FungsiKhususAjax.*?# END FungsiKhususAjax\s*/s';


    $htaccess = preg_replace(
        $pattern,
        "\n\n",
        $htaccess
    );


    /*
     * Rapikan beberapa baris kosong berlebihan.
     */
    $htaccess = preg_replace(
        "/\n{3,}/",
        "\n\n",
        $htaccess
    );


    /*
     * Simpan kembali.
     */
    file_put_contents(
        $htaccess_path,
        ltrim( $htaccess ),
        LOCK_EX
    );
}