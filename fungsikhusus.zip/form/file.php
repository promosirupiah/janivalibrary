<?php
//ubah url menjadi file path
function wp_upload_url_to_path($url) {
    $upload = wp_get_upload_dir();
    if (strpos($url, $upload['baseurl']) !== 0) {
        return false;
    }
    $file = str_replace($upload['baseurl'], $upload['basedir'], $url);
    return wp_normalize_path($file);
}
//ubah jadi webp file.jpg -> file.jpg.webp
function create_webp($file, $quality = 85) {
    if (!file_exists($file)) {
        return false;
    }
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    if ($ext === 'webp') {
        return rename($file,$file.'.webp');
    } 
    $webp = $file . '.webp';
    switch ($ext) {
        case 'jpg':
        case 'jpeg':
            $image = imagecreatefromjpeg($file);
            break;
        case 'png':
            $image = imagecreatefrompng($file);
            imagepalettetotruecolor($image);
            imagealphablending($image, true);
            imagesavealpha($image, true);
            break;
        case 'gif':
            $image = imagecreatefromgif($file);
            break;		
        default:
            return false;
    }
    if (!imagewebp($image, $webp, $quality)) {
        imagedestroy($image);
        return false;
    }
    imagedestroy($image);
    return $webp;
}

//move file
function move_file($source, $destination) {
    if (!file_exists($source)) {
        return false;
    }
    $dir = dirname($destination);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return rename($source, $destination);
}