<?php
add_action( 'jet-form-builder/custom-action/approve', function( $request, $handler ) {

$allowapprove = false;
 if (!empty(array_intersect(wp_get_current_user()->roles, array('moderator'))) && get_user_meta(get_current_user_id(),'angkatan',true) == get_user_meta($request['userid'],'angkatan',true) ) {$allowapprove = true;}; //moderator dan angkatan sama
 if (!empty(array_intersect(wp_get_current_user()->roles, array('administrator')))) { $allowapprove = true; }; //admin utama
if($allowapprove)	{
      $user = new WP_User($request['userid']);
	if(!array_intersect($user->roles,array('unverified'))){throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'User sudah verified' );}

//nomor anggota check
$podsuser = pods('user',$request['userid']);
$userangkatan = absint(get_user_meta($request['userid'],'angkatan',true));
//echo '$userangkatan = '.$userangkatan.'<br>'; //check
$usernomoranggota = get_user_meta($request['userid'],'nomor_anggota',true);
//echo '$usernomoranggota = '. $usernomoranggota .'<br>'; //check
if(!$usernomoranggota){
//echo '$usernomoranggota tidak ada <br>'; //check
	$nomoranggotaminimal = $userangkatan * 1000 ;
	$nomoranggotamaximal = $nomoranggotaminimal + 999; 
//	echo 'p.angkatan = "'.$userangkatan.'" and p.nomor_anggota > '.$nomoranggotaminimal -1 .' and p.nomor_anggota < '.$nomoranggotamaximal +1 . '<br>'; //check
$getallnomoranggotaangkatan = get_wpdb_data( array(
    'select' => 'p.nomor_anggota',
    'from'   => 'pods_user p',
    'where'  => 'p.angkatan = "'.$userangkatan.'" and p.nomor_anggota > '.$nomoranggotaminimal -1 .' and p.nomor_anggota < '.$nomoranggotamaximal +1 ,
) );
if($getallnomoranggotaangkatan){ //sudah ada member di angkatan
//echo 'sudah ada member di angkatan <br>'; //check
$getallnomoranggotaangkatan = array_column($getallnomoranggotaangkatan,'nomor_anggota');
//print_r($getallnomoranggotaangkatan);
for($cek = $nomoranggotaminimal;$cek < $nomoranggotamaximal + 1;$cek ++){
if(!in_array($cek,$getallnomoranggotaangkatan)){ 
//echo $cek.' tersedia dari for $cek = $nomoranggotaminimal;$cek < $nomoranggotamaximal + 1;$cek ++ <br>'; //check
$nomoranggotabaru = $cek; 
break;};
}

} else { 
//echo 'belum ada member di angkatan <br>'; //check //nomor anggota baru di angkatan
$cek = $nomoranggotaminimal ; 
//echo $cek.' tersedia<br>'; //check
$nomoranggotabaru = $cek; 
}
//echo '$nomoranggotabaru = '.$nomoranggotabaru; //check
$data['nomor_anggota'] = $nomoranggotabaru;
$data['id'] = absint($request['userid']);
//if(wp_upsert('pods_user', $data, 'id')){echo 'wp_upsert berhasil, print_r : '; print_r($data);} 
$podsusersave = $podsuser->save($data);
if($podsusersave){
//echo 'save menggunakan $podsusersave = $podsuser->save($data);<br>'; //check
//print_r($podsusersave);//check
}
} //end jika belum ada nomor anggota
else {
//echo 'nomor anggota sudah ada ' .$usernomoranggota; //check
} //end check nomor anggota

//ganti role
	   $user->set_role('customer');
	   update_user_meta( $request['userid'], 'user_activation_status', 1 ); 
    }  else{throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'Anda Tidak Berhak approve user' );} 

}, 10, 2 );