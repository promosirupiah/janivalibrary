<?php
add_action( 'jet-form-builder/custom-action/capture', function ( $request, $handler ) {

$targetUrl = 'https://ikaspega.my03.com/madxajax/capture/';
$data = $request;
// $data = array_merge($_GET, $_POST);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $targetUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data)); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
$response = curl_exec($ch);
if(curl_errno($ch)){
 throw ( new Action_Exception( 'failed' ) )->dynamic_error();
} 
curl_close($ch);

 }, 10, 2 );