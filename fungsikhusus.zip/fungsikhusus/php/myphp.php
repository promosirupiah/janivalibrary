<?php function myphp_shortcode($atts, $content = null) {
    if ($content === null) {
        return '';
    }

    ob_start();
    try {
        eval('?>' . $content);
    } catch (Throwable $e) {
        ob_end_clean();
        return 'PHP Error: ' . $e->getMessage();
    }
    return ob_get_clean();
}

add_shortcode('myphp', 'myphp_shortcode');
/* [myphp]<?php echo 'xxx'; ?>[/myphp */