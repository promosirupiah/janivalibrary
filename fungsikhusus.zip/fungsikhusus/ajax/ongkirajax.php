<?php
/**
 * ONGKIR AJAX WITH ADVANCED CACHE
 * Support: SHORTINIT, Autocomplete Kota, Autocomplete Kecamatan, Detail Ongkir
 tambahkan pada .htaccess:
 RewriteRule ^ongkirajax.php/?$ /wp-content/plugins/fungsikhusus/ajax/ongkirajax.php [L,QSA]
 */

function handleAdvancedCacheFunc($dosemething, $name, $folder = 'ongkir-cache', $ttl = 3600) {
    // 1. Cache Key berdasarkan REQUEST (karena ini AJAX endpoint)
    $cache_params = $_REQUEST;
    
    // Buang parameter anti-cache jQuery (biasanya '_')
    if (isset($cache_params['_'])) {
        unset($cache_params['_']);
    }
    
    // Urutkan array agar urutan parameter tidak mempengaruhi hash
    ksort($cache_params);
    
    $filename_only = md5(serialize($cache_params)) . '.txt';
    
    // 2. Tentukan Base Cache Directory secara mandiri (tanpa bergantung WP_CONTENT_DIR)
    // Karena SHORTINIT membuat WP_CONTENT_DIR belum tentu ter-load di awal
    $wp_content_dir = dirname(__DIR__, 3);
    if (basename($wp_content_dir) !== 'wp-content') {
        // Fallback jika struktur folder berbeda
        $wp_content_dir = dirname(__DIR__, 4) . '/wp-content';
    }
    
    $base_cache_dir = $wp_content_dir . '/cache';
    
    // Sanitasi nama folder (pengganti sanitize_title karena SHORTINIT)
    $target_folder  = preg_replace('/[^a-zA-Z0-9_\-]/', '', $folder);
    $target_name    = preg_replace('/[^a-zA-Z0-9_\-]/', '', $name);
    
    $dirPath  = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
    $filename = $dirPath . '/' . $filename_only;
    
    // 3. Cek Cache & TTL
    if (file_exists($filename) && filesize($filename) > 0) {
        if ($ttl === -1 || (time() - filemtime($filename) < $ttl)) {
            header('Content-Type: application/json; charset=utf-8');
            header('X-Cache: HIT');
            readfile($filename);
            exit; // Langsung keluar, hemat resource!
        }
    }
    
    // 4. Buat folder jika belum ada
    if (!is_dir($dirPath)) {
        @mkdir($dirPath, 0755, true);
        // Proteksi keamanan direktori
        @file_put_contents($base_cache_dir . '/index.php', '<?php // Silence is golden');
        @file_put_contents($base_cache_dir . '/' . $target_folder . '/index.php', '<?php // Silence is golden');
        @file_put_contents($dirPath . '/index.php', '<?php // Silence is golden');
    }
    
    // 5. Mulai Output Buffering
    ob_start();
    if (is_callable($dosemething)) {
        $dosemething();
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: Callback tidak valid.']);
    }
    $output = ob_get_clean();
    
    // 6. Simpan ke Cache
    if (!empty($output) && is_writable($dirPath)) {
        @file_put_contents($filename, $output);
    }
    
    // 7. Tampilkan Output
    header('Content-Type: application/json; charset=utf-8');
    header('X-Cache: MISS');
    echo $output;
    exit;
}

// PANGGIL FUNGSI CACHE
// Parameter: Callback, Name, Folder, TTL (3600 = 1 Jam. Ubah ke -1 untuk permanen)
handleAdvancedCacheFunc(function() {
    // ==========================================
    // MULAI LOGIKA AJAX (DI DALAM BUFFER)
    // ==========================================
    
    // 1. Load WordPress Core (SHORTINIT)
    if (!defined('SHORTINIT')) {
        define('SHORTINIT', true);
    }
    
    $wp_load_path = dirname(__DIR__, 4) . '/wp-load.php';
    if (!file_exists($wp_load_path)) {
        $wp_load_path = dirname(__DIR__, 3) . '/wp-load.php';
    }
    
    if (file_exists($wp_load_path)) {
        require_once $wp_load_path;
    } else {
        echo json_encode(['success' => false, 'message' => 'wp-load.php tidak ditemukan.']);
        return; // PENTING: Gunakan return, bukan exit!
    }
    
    global $wpdb, $table_prefix;
    
    if (!isset($wpdb)) {
        echo json_encode(['success' => false, 'message' => 'Database tidak tersedia.']);
        return;
    }
    
    $action = isset($_REQUEST['action']) ? preg_replace('/[^a-zA-Z0-9_\-]/', '', $_REQUEST['action']) : '';
    $table  = $table_prefix.'pods_ongkir';
    
    // Helper untuk response
    $send_json = function($data) {
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    };

    /**
     * ACTION 1: Search Kota Tujuan (Autocomplete)
     */
    if ($action === 'search_kota_tujuan') {
        $keyword = isset($_REQUEST['keyword']) ? trim($_REQUEST['keyword']) : '';
        $asal    = isset($_REQUEST['asal']) ? trim($_REQUEST['asal']) : 'SEMARANG';
        
        if (strlen($keyword) < 2) {
            $results = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT kabupaten_kota 
                 FROM {$table} 
                 WHERE origin = %s 
                 ORDER BY kabupaten_kota ASC 
                 LIMIT 15",
                $asal
            ));
            $send_json(['success' => true, 'data' => $results ?: []]);
            return;
        }
        
        $results = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT kabupaten_kota 
             FROM {$table} 
             WHERE origin = %s AND kabupaten_kota LIKE %s 
             ORDER BY kabupaten_kota ASC 
             LIMIT 15",
            $asal,
            '%' . $wpdb->esc_like($keyword) . '%'
        ));
        
        $send_json(['success' => true, 'data' => $results ?: []]);
        return;
    }

    /**
     * ACTION 2: Search Kecamatan (Autocomplete)
     */
    if ($action === 'search_kecamatan') {
        $asal    = isset($_REQUEST['asal']) ? trim($_REQUEST['asal']) : 'SEMARANG';
        $kota    = isset($_REQUEST['kota']) ? trim($_REQUEST['kota']) : '';
        $keyword = isset($_REQUEST['keyword']) ? trim($_REQUEST['keyword']) : '';
        
        if (empty($kota)) {
            $send_json(['success' => true, 'data' => []]);
            return;
        }
        
        // Resolve nama kota yang tepat di database (exact / fuzzy)
        $exact_kota = $wpdb->get_var($wpdb->prepare(
            "SELECT DISTINCT kabupaten_kota FROM {$table} WHERE origin = %s AND kabupaten_kota = %s LIMIT 1",
            $asal, $kota
        ));
        $query_kota = $exact_kota ?: $kota;
        
        if (!$exact_kota) {
            $like_kota = $wpdb->get_var($wpdb->prepare(
                "SELECT DISTINCT kabupaten_kota FROM {$table} WHERE origin = %s AND kabupaten_kota LIKE %s LIMIT 1",
                $asal, '%' . $wpdb->esc_like($kota) . '%'
            ));
            if ($like_kota) $query_kota = $like_kota;
        }
        
        if (empty($keyword)) {
            $results = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT kecamatan 
                 FROM {$table} 
                 WHERE origin = %s AND kabupaten_kota = %s AND kecamatan <> '' 
                 ORDER BY kecamatan ASC 
                 LIMIT 20",
                $asal, $query_kota
            ));
        } else {
            $results = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT kecamatan 
                 FROM {$table} 
                 WHERE origin = %s AND kabupaten_kota = %s AND kecamatan LIKE %s 
                 ORDER BY kecamatan ASC 
                 LIMIT 20",
                $asal, $query_kota, '%' . $wpdb->esc_like($keyword) . '%'
            ));
        }
        
        $send_json(['success' => true, 'data' => $results ?: []]);
        return;
    }

    /**
     * ACTION 3: Ambil Data Ongkir
     */
    if ($action === 'get_data_ongkir') {
        $asal      = isset($_REQUEST['asal']) ? trim($_REQUEST['asal']) : 'SEMARANG';
        $kota      = isset($_REQUEST['kota']) ? trim($_REQUEST['kota']) : (isset($_REQUEST['tujuan']) ? trim($_REQUEST['tujuan']) : '');
        $kecamatan = isset($_REQUEST['kecamatan']) ? trim($_REQUEST['kecamatan']) : '';
        
        if (empty($kota)) {
            $send_json(['success' => false, 'message' => 'Kota tujuan wajib diisi.']);
            return;
        }
        
        // Resolve nama kota
        $exact_kota = $wpdb->get_var($wpdb->prepare(
            "SELECT DISTINCT kabupaten_kota FROM {$table} WHERE origin = %s AND kabupaten_kota = %s LIMIT 1",
            $asal, $kota
        ));
        $query_kota = $exact_kota ?: $kota;
        
        if (!$exact_kota) {
            $like_kota = $wpdb->get_var($wpdb->prepare(
                "SELECT DISTINCT kabupaten_kota FROM {$table} WHERE origin = %s AND kabupaten_kota LIKE %s LIMIT 1",
                $asal, '%' . $wpdb->esc_like($kota) . '%'
            ));
            if ($like_kota) $query_kota = $like_kota;
        }
        
        // Jika ada kecamatan, ambil detail per kecamatan
        if (!empty($kecamatan)) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT origin, kabupaten_kota, kecamatan, nama_sisco, tariff_darat, minimum_kg, lead_time 
                 FROM {$table} 
                 WHERE origin = %s AND kabupaten_kota = %s AND kecamatan = %s 
                 ORDER BY nama_sisco ASC",
                $asal, $query_kota, $kecamatan
            ), ARRAY_A);
            
            if (empty($rows)) {
                $rows = $wpdb->get_results($wpdb->prepare(
                    "SELECT origin, kabupaten_kota, kecamatan, nama_sisco, tariff_darat, minimum_kg, lead_time 
                     FROM {$table} 
                     WHERE origin = %s AND kabupaten_kota = %s AND kecamatan LIKE %s 
                     ORDER BY nama_sisco ASC LIMIT 10",
                    $asal, $query_kota, '%' . $wpdb->esc_like($kecamatan) . '%'
                ), ARRAY_A);
            }
            
            if (empty($rows)) {
                $send_json(['success' => false, 'message' => 'Kecamatan tidak ditemukan.']);
                return;
            }
            
            $send_json([
                'success' => true,
                'data' => [
                    'mode' => 'kecamatan',
                    'rows' => $rows
                ]
            ]);
            return;
        }
        
        // Jika tidak ada kecamatan, ambil ringkasan kota
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                kabupaten_kota,
                COUNT(DISTINCT NULLIF(kecamatan, '')) as jumlah_kecamatan,
                MIN(tariff_darat) as min_tarif, 
                MAX(tariff_darat) as max_tarif, 
                MIN(minimum_kg) as min_kg, 
                MAX(minimum_kg) as max_kg, 
                GROUP_CONCAT(DISTINCT NULLIF(lead_time, '') SEPARATOR ', ') as lead_time
             FROM {$table} 
             WHERE origin = %s AND kabupaten_kota = %s 
             GROUP BY kabupaten_kota 
             LIMIT 1",
            $asal, $query_kota
        ), ARRAY_A);
        
        if (!$row) {
            $send_json(['success' => false, 'message' => 'Rute tidak ditemukan.']);
            return;
        }
        
        $send_json([
            'success' => true,
            'data' => [
                'mode' => 'kota',
                'row'  => $row
            ]
        ]);
        return;
    }

    $send_json(['success' => false, 'message' => 'Invalid action.']);
    
}, 'geo', 'ongkir-ajax', 3600); // Cache 1 Jam.