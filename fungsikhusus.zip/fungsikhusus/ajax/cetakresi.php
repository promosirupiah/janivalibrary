<?php
/**
 * CETAK RESI - SIAP PRINT (ukuran 1/3 kertas A4)
 * Pemakaian: cetakresi.php?idresi=1
 * Letakkan di root WordPress (sejajar wp-load.php).
 *
 * Revisi:
 * - Logo perusahaan: https://tnalogistics-id.com/wp-content/uploads/logotna1993.webp
 * - Telepon pengirim  = senderphone
 * - Telepon penerima  = destinationphone
 * - Hilangkan Package Type / Tipe Paket
 * - Hilangkan PACKING, DISCOUNT, OTHER, INSURANCE
 * - Hilangkan Collected by / Diambil Oleh
 * - Hilangkan L x W x H = 1 x 1 x 1
 */

//define('WP_USE_THEMES', false);
define('WP_INSTALLING', true);
define('WP_USE_THEMES', false);
//define('SHORTINIT', true); // load WordPress minimal (hanya wpdb)
define('LOGO_URL', 'https://tnalogistics-id.com/wp-content/uploads/logotna1993.webp');
//require_once __DIR__ . '/wp-load.php';
$wp_load = dirname( __DIR__, 4 ) . '/wp-load.php';
require_once $wp_load;


global $wpdb;

/* ---------- Helper ---------- */
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function fmt_tgl($dt){
    if(!$dt || strncmp($dt,'0000',4)===0) return '-';
    $t = strtotime($dt); return $t ? date('d-m-Y',$t) : '-';
}
function fmt_jam($dt){
    if(!$dt || strncmp($dt,'0000',4)===0) return '-';
    $t = strtotime($dt); return $t ? date('H:i',$t) : '-';
}
function fmt_rupiah($n){ return number_format((float)$n,0,',','.'); }

/* ---------- Barcode Code 39 (SVG murni, tanpa library) ---------- */
function code39_svg($text, $height = 30){
    $map = array(
        '0'=>'000110100','1'=>'100100001','2'=>'001100001','3'=>'101100000',
        '4'=>'000110001','5'=>'100110000','6'=>'001110000','7'=>'000100101',
        '8'=>'100100100','9'=>'001100100','A'=>'100001001','B'=>'001001001',
        'C'=>'101001000','D'=>'000011001','E'=>'100011000','F'=>'001011000',
        'G'=>'000001101','H'=>'100001100','I'=>'001001100','J'=>'000011100',
        'K'=>'100000011','L'=>'001000011','M'=>'101000010','N'=>'000010011',
        'O'=>'100010010','P'=>'001010010','Q'=>'000000111','R'=>'100000110',
        'S'=>'001000110','T'=>'000010110','U'=>'110000001','V'=>'011000001',
        'W'=>'111000000','X'=>'010010001','Y'=>'110010000','Z'=>'011010000',
        '-'=>'010000101','.'=>'110000100',' '=>'011000100','*'=>'010010100',
    );
    $text  = strtoupper(trim((string)$text));
    $chars = '*'.$text.'*';
    $x = 0; $rects = '';
    for($i=0;$i<strlen($chars);$i++){
        $c = $chars[$i];
        if(!isset($map[$c])) continue;
        $p = $map[$c];
        for($j=0;$j<9;$j++){
            $w = ($p[$j]==='1') ? 3 : 1;
            if($j%2===0){ $rects .= '<rect x="'.$x.'" y="0" width="'.$w.'" height="'.$height.'"/>'; }
            $x += $w;
        }
        $x += 1;
    }
    $vw = $x + 4;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-2 0 '.$vw.' '.$height.'" preserveAspectRatio="none" shape-rendering="crispEdges"><g fill="#000">'.$rects.'</g></svg>';
}

/* ---------- Ambil data resi + customer ---------- */
$idresi = isset($_GET['idresi']) ? (int)$_GET['idresi'] : 0;
if($idresi <= 0){ http_response_code(400); exit('Parameter idresi tidak valid.'); }

$resi = $wpdb->get_row($wpdb->prepare("
    SELECT r.*, c.company AS cust_company, c.contact AS cust_contact,
           c.phone AS cust_phone, c.address AS cust_address
    FROM {$wpdb->prefix}pods_resi r
    LEFT JOIN {$wpdb->prefix}pods_customer c ON c.name = r.customer
    WHERE r.id = %d
", $idresi));

if(!$resi){ http_response_code(404); exit('Resi tidak ditemukan.'); }

$no_resi   = $resi->name;
$asal      = $resi->origin_hub;
$tujuan    = $resi->destination_hub;
$berat     = $resi->weight;
$pengirim  = !empty($resi->cust_company) ? $resi->cust_company : $resi->customer;
$alm_peng  = !empty($resi->cust_address) ? $resi->cust_address : $resi->asal;
$telp_peng = !empty($resi->senderphone)      ? $resi->senderphone      : (!empty($resi->cust_phone) ? $resi->cust_phone : '0');
$penerima  = !empty($resi->penerima)         ? $resi->penerima : (!empty($resi->outbondname) ? $resi->outbondname : '-');
$alm_ter   = $resi->tujuan;
$telp_ter  = !empty($resi->destinationphone) ? $resi->destinationphone : '0';
$layanan   = strtoupper($resi->layanan);
$konten    = $resi->content;
$tariff    = fmt_rupiah($resi->fee);
$tgl       = fmt_tgl($resi->tanggal);
$jam       = fmt_jam($resi->tanggal);

if ( is_user_logged_in() ) {
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Resi <?php echo e($no_resi); ?></title>
<style>
@page{ size:A4; margin:0; }
html,body{ margin:0; padding:0; background:#fff; }
body{ font-family:Arial,Helvetica,sans-serif; }
.toolbar{ position:fixed; top:10px; right:10px; z-index:99; }
.toolbar button{ padding:8px 18px; font-size:14px; cursor:pointer; }
@media print{ .toolbar{ display:none; } }

/* ===== LABEL 1/3 KERTAS A4 (210mm x 99mm) ===== */
.label{
  width:210mm; height:99mm; margin:0 auto; padding:2mm 2.5mm;
  display:flex; flex-direction:column; overflow:hidden;
  background:#fff; color:#000; font-size:7pt; line-height:1.25;
}
.label *{ box-sizing:border-box; }
.lbl{ display:block; font-size:5.5pt; text-transform:uppercase; letter-spacing:.2px; }
.val{ display:block; font-size:8pt; font-weight:700; }

/* --- header --- */
.head{ display:flex; height:21mm; border:1px solid #000; }
.logo{ width:26%; border-right:1px solid #000; display:flex; align-items:center; justify-content:center; padding:1.5mm 2mm; }
.logo img{ max-width:100%; max-height:17mm; }
.bc{ width:46%; border-right:1px solid #000; padding:1.5mm 2mm 1mm; text-align:center; }
.bc .bars{ height:12mm; }
.bc .bars svg{ width:100%; height:100%; }
.bcnum{ font-size:11pt; font-weight:700; letter-spacing:2px; margin-top:1mm; }
.od{ width:28%; display:grid; grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; }
.od .cell{ padding:1mm 1.5mm; }
.od .cell:nth-child(even){ border-left:1px solid #000; }
.od .cell:nth-child(n+3){ border-top:1px solid #000; }

/* --- body 3 kolom --- */
.body{ flex:1; display:flex; border:1px solid #000; border-top:0; min-height:0; }
.col{ display:flex; flex-direction:column; min-height:0; }
.col.left{ width:27%; }
.col.mid{ width:45%; border-left:1px solid #000; }
.col.right{ width:28%; border-left:1px solid #000; }
.cell{ padding:1mm 1.5mm; border-bottom:1px solid #000; }
.cell:last-child{ border-bottom:0; }
.grow{ flex:1; }
.row2{ display:flex; padding:0 !important; }
.row2 .c{ flex:1; padding:1mm 1.5mm; }
.row2 .c + .c{ border-left:1px solid #000; }

/* --- kolom tarif --- */
.trow{ display:flex; border-bottom:1px solid #000; }
.trow .k{ flex:1; padding:1.2mm 1.5mm; }
.trow .v{ width:40%; padding:1.2mm 1.5mm; border-left:1px solid #000; text-align:right; font-weight:700; }
</style>
</head>
<body>

<div class="toolbar"><button onclick="window.print()">&#128424; Cetak</button></div>

<div class="label">

  <!-- ================= HEADER ================= -->
  <div class="head">
    <div class="logo"><img src="<?php echo LOGO_URL; ?>" alt="Logo Perusahaan"></div>
    <div class="bc">
      <div class="bars"><?php echo code39_svg($no_resi); ?></div>
      <div class="bcnum"><?php echo e($no_resi); ?></div>
    </div>
    <div class="od">
      <div class="cell"><span class="lbl">Origin / Asal</span><span class="val"><?php echo e($asal); ?></span></div>
      <div class="cell"><span class="lbl">Destination / Tujuan</span><span class="val"><?php echo e($tujuan); ?></span></div>
      <div class="cell"><span class="lbl">Pieces / Jumlah Satuan</span><span class="val">1</span></div>
      <div class="cell"><span class="lbl">Weight / Berat (kg)</span><span class="val"><?php echo e($berat); ?></span></div>
    </div>
  </div>

  <!-- ================= BODY ================= -->
  <div class="body">

    <!-- KIRI : PENGIRIM -->
    <div class="col left">
      <div class="cell"><span class="lbl">Consignor / Pengirim</span><span class="val"><?php echo e($pengirim); ?></span></div>
      <div class="cell grow"><span class="lbl">Address / Alamat</span><span class="val"><?php echo e($alm_peng); ?></span></div>
      <div class="cell"><span class="lbl">Phone / Telepon</span><span class="val"><?php echo e($telp_peng); ?></span></div>
      <div class="cell"><span class="lbl">Consignor's Authorization / Tanda Tangan Pengirim</span><span class="val" style="font-weight:400">ISI TIDAK DIPERIKSA / DIPERIKSA</span></div>
      <div class="cell grow"><span class="lbl">Description of Contents / Keterangan Isi</span><span class="val"><?php echo e($konten); ?></span></div>
      <div class="cell grow"><span class="lbl">Special Instruction / Keterangan Khusus</span><span class="val">&nbsp;</span></div>
    </div>

    <!-- TENGAH : PENERIMA -->
    <div class="col mid">
      <div class="cell"><span class="lbl">Consignee / Penerima</span><span class="val"><?php echo e($penerima); ?></span></div>
      <div class="cell grow"><span class="lbl">Address / Alamat</span><span class="val"><?php echo e($alm_ter); ?></span></div>
      <div class="cell"><span class="lbl">Attention of (Name/Dept) / Ditujuan Untuk</span><span class="val">&nbsp;</span></div>
      <div class="cell"><span class="lbl">Phone / Telepon</span><span class="val"><?php echo e($telp_ter); ?></span></div>
      <div class="cell row2">
        <div class="c"><span class="lbl">Service Type / Jenis Service</span><span class="val"><?php echo e($layanan); ?></span></div>
        <div class="c" style="display:flex;align-items:center;justify-content:center"><span class="val">CASH</span></div>
      </div>
      <div class="cell row2">
        <div class="c"><span class="lbl">Date / Tanggal</span><span class="val"><?php echo e($tgl); ?></span></div>
        <div class="c"><span class="lbl">Time / Jam</span><span class="val"><?php echo e($jam); ?></span></div>
      </div>
      <div class="cell grow">
        <span class="lbl">Received by Consignee / Diterima Oleh Penerima</span>
        <span class="lbl" style="margin-top:2mm">Name / Nama</span>
        <span class="lbl" style="margin-top:2mm">Signature / Tanda Tangan</span>
        <span class="lbl">Company's Stamp / Cap Perusahaan</span>
      </div>
    </div>

    <!-- KANAN : TARIF -->
    <div class="col right">
      <div class="trow"><div class="k lbl">Keterangan Tarif</div><div class="v lbl" style="text-align:right">Charges / Harga</div></div>
      <div class="trow"><div class="k">TARIFF</div><div class="v"><?php echo e($tariff); ?></div></div>
      <div class="trow"><div class="k"><b>TOTAL / JUMLAH</b></div><div class="v"><?php echo e($tariff); ?></div></div>
      <div class="cell grow">
        <span class="lbl">Time / Jam</span>
        <span class="lbl" style="margin-top:3mm">Date / Tanggal</span>
      </div>
    </div>

  </div>
</div>

<script>
/* Aktifkan baris di bawah ini jika ingin langsung print saat halaman dibuka:
window.onload = function(){ window.print(); };
*/
</script>
</body>
</html>
<?php }