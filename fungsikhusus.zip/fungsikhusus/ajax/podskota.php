<?php
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    
    // Pastikan parameter 'page' ada di URL
    if ( ! isset( $_GET['page'] ) ) {
        return;
    }

    $page   = $_GET['page'];
    $action = isset( $_GET['action'] ) ? $_GET['action'] : '';

    // Tentukan kondisi halaman yang diizinkan
    $is_add_new = ( $page === 'pods-add-new-resi' );
    $is_edit    = ( $page === 'pods-manage-resi' && $action === 'edit' );

    // Jika bukan di halaman Add New maupun Edit, hentikan eksekusi
    if ( ! $is_add_new && ! $is_edit ) {
        return;
    }

    // Load jQuery UI Autocomplete bawaan WordPress
    wp_enqueue_script( 'jquery-ui-autocomplete' );

    // Load script custom Anda
    wp_enqueue_script(
        'resi-city-autocomplete',
        plugin_dir_url( __FILE__ ) . 'resi-city-autocomplete.js',
        array( 'jquery-ui-autocomplete' ),
        '1.0',
        true
    );

    // Terjemahkan variabel PHP ke JavaScript (untuk URL AJAX)
    wp_localize_script( 'resi-city-autocomplete', 'resiAutocomplete', array(
        'ajaxUrl' => plugin_dir_url( __FILE__ ) . 'resi-search-cities.php',
    ) );
    
} );