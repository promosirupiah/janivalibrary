﻿<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cek Ongkir</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
            margin: 0;
            padding: 30px 15px;
        }

        .ongkir-box {
            max-width: 560px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 14px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, .08);
        }

        .ongkir-box h1 {
            margin: 0 0 18px;
            font-size: 22px;
            color: #111827;
        }

        .field {
            position: relative;
            margin-bottom: 14px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #374151;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 11px 13px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 14px;
            box-sizing: border-box;
        }

        input:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, .12);
        }

        input:disabled {
            background: #f9fafb;
            color: #9ca3af;
        }

        .autocomplete-list {
            position: absolute;
            top: calc(100% + 6px);
            left: 0;
            right: 0;
            background: #ffffff;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, .10);
            max-height: 240px;
            overflow: auto;
            z-index: 99;
            display: none;
        }

        .autocomplete-list.show {
            display: block;
        }

        .autocomplete-item {
            padding: 10px 13px;
            cursor: pointer;
            font-size: 14px;
            border-bottom: 1px solid #f3f4f6;
        }

        .autocomplete-item:last-child {
            border-bottom: none;
        }

        .autocomplete-item:hover {
            background: #f3f4f6;
        }

        .result {
            margin-top: 16px;
        }

        .notice {
            padding: 12px 14px;
            border-radius: 10px;
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            color: #1e3a8a;
            line-height: 1.5;
            font-size: 14px;
        }

        .notice.error {
            background: #fef2f2;
            border-color: #fecaca;
            color: #b91c1c;
        }

        .muted {
            margin-top: 8px;
            color: #6b7280;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 13px;
        }

        th,
        td {
            border: 1px solid #e5e7eb;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #f9fafb;
            color: #374151;
        }

        .title-small {
            font-size: 15px;
            margin: 0 0 10px;
            color: #111827;
        }

        .auto-note {
            font-size: 12px;
            color: #6b7280;
            margin: 6px 0 0;
        }
    </style>
</head>
<body>

<div class="ongkir-box">
    <h1>Cek Ongkir</h1>

    <div class="field">
        <label for="asal">Kota Asal</label>
        <input
            type="text"
            id="asal"
            value="SEMARANG"
            autocomplete="off"
			disabled
        >
    </div>

    <div class="field">
        <label for="kota_tujuan">Kota Tujuan</label>
        <input
            type="text"
            id="kota_tujuan"
            autocomplete="off"
            placeholder="Ketik kota/kabupaten tujuan..."
        >
        <div id="kota_list" class="autocomplete-list"></div>
    </div>

    <div class="field">
        <label for="kecamatan">Kecamatan</label>
        <input
            type="text"
            id="kecamatan"
            autocomplete="off"
            placeholder="Pilih kota tujuan dulu"
            disabled
        >
        <div id="kecamatan_list" class="autocomplete-list"></div>
    </div>

    <p class="auto-note">
        Hasil akan muncul otomatis setelah kota tujuan / kecamatan dipilih atau diisi.
    </p>

    <div id="ongkir_result" class="result"></div>
</div>

<script>
(() => {

    const ajaxUrl = 'ongkirajax.php';

    const asalInput      = document.getElementById('asal');
    const kotaInput      = document.getElementById('kota_tujuan');
    const kecamatanInput = document.getElementById('kecamatan');

    const kotaList      = document.getElementById('kota_list');
    const kecamatanList = document.getElementById('kecamatan_list');

    const result = document.getElementById('ongkir_result');

    let selectedKota      = '';
    let selectedKecamatan = '';
    let requestCounter    = 0;
    let lastCheckedKey    = '';

    const debounce = (fn, delay = 300) => {
        let timer;
        return (...args) => {
            clearTimeout(timer);
            timer = setTimeout(() => fn(...args), delay);
        };
    };

    const hideList = (list) => list.classList.remove('show');
    const showList = (list) => list.classList.add('show');

    function clearList(list) {
        list.innerHTML = '';
        hideList(list);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = String(text ?? '');
        return div.innerHTML;
    }

    function rupiah(angka) {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(Number(angka || 0));
    }

    function renderList(list, items, onSelect) {
        clearList(list);

        if (!Array.isArray(items) || !items.length) {
            return;
        }

        items.forEach((text) => {
            const div = document.createElement('div');
            div.className = 'autocomplete-item';
            div.textContent = text;

            div.addEventListener('mousedown', () => {
                onSelect(text);
            });

            list.appendChild(div);
        });

        showList(list);
    }

    async function api(params) {
        const url = ajaxUrl + '?' + new URLSearchParams(params).toString();

        const response = await fetch(url, {
            headers: {
                'Accept': 'application/json'
            }
        });

        const text = await response.text();

        let json;

        try {
            json = JSON.parse(text);
        } catch (e) {
            throw new Error('Server mengembalikan respons tidak valid.');
        }

        if (!json.success) {
            throw new Error(json.message || 'Gagal memuat data.');
        }

        return json.data;
    }

    function buildCheckParams() {
        const kota      = kotaInput.value.trim();
        const kecamatan = kecamatanInput.value.trim();
        const asal      = asalInput.value.trim();

        return {
            action: 'get_data_ongkir',
            asal: asal,

            // Untuk ongkirajax versi baru
            kota: kota,

            // Kompatibilitas dengan ongkirajax versi lama
            tujuan: kota,

            // Untuk ongkirajax versi kecamatan
            kecamatan: kecamatan
        };
    }

    async function cekOtomatis(force = false) {
        const params = buildCheckParams();
        const key = JSON.stringify(params);

        if (!params.kota) {
            lastCheckedKey = '';
            result.innerHTML = '';
            return;
        }

        if (!force && key === lastCheckedKey) {
            return;
        }

        lastCheckedKey = key;

        result.innerHTML = `
            <div class="notice">
                ⏳ Mencari data ongkir...
            </div>
        `;

        try {
            const data = await api(params);
            renderHasil(data);
        } catch (e) {
            lastCheckedKey = '';
            result.innerHTML = `
                <div class="notice error">
                    ${escapeHtml(e.message)}
                </div>
            `;
        }
    }

    async function cariKota(keyword) {
        const requestId = ++requestCounter;

        try {
            const data = await api({
                action: 'search_kota_tujuan',
                asal: asalInput.value.trim(),
                keyword: keyword
            });

            if (requestId !== requestCounter) {
                return;
            }

            renderList(kotaList, data, (item) => {
                selectedKota = item;
                selectedKecamatan = '';

                kotaInput.value = item;
                kecamatanInput.value = '';
                kecamatanInput.disabled = false;
                kecamatanInput.placeholder = 'Ketik kecamatan...';

                clearList(kotaList);

                cekOtomatis(true);

                kecamatanInput.focus();
            });

        } catch (e) {
            console.error(e);
        }
    }

    async function cariKecamatan(keyword) {
        const kotaTujuan = selectedKota || kotaInput.value.trim();

        if (!kotaTujuan) {
            return;
        }

        const requestId = ++requestCounter;

        try {
            const data = await api({
                action: 'search_kecamatan',
                asal: asalInput.value.trim(),
                kota: kotaTujuan,
                keyword: keyword
            });

            if (requestId !== requestCounter) {
                return;
            }

            renderList(kecamatanList, data, (item) => {
                selectedKecamatan = item;
                kecamatanInput.value = item;

                clearList(kecamatanList);

                cekOtomatis(true);
            });

        } catch (e) {
            console.error(e);
        }
    }

    const debouncedCariKota = debounce(() => {
        cariKota(kotaInput.value.trim());
    }, 300);

    const debouncedCariKecamatan = debounce(() => {
        cariKecamatan(kecamatanInput.value.trim());
    }, 300);

    /**
     * Jika kota asal berubah, cek ulang otomatis
     */
    asalInput.addEventListener('input', debounce(() => {
        if (kotaInput.value.trim()) {
            cekOtomatis(true);
        }
    }, 400));

    asalInput.addEventListener('change', () => {
        if (kotaInput.value.trim()) {
            cekOtomatis(true);
        }
    });

    /**
     * Input kota tujuan
     */
    kotaInput.addEventListener('input', () => {
        selectedKota = '';
        selectedKecamatan = '';

        kecamatanInput.value = '';
        kecamatanInput.disabled = kotaInput.value.trim() === '';
        kecamatanInput.placeholder = kotaInput.value.trim() === ''
            ? 'Pilih kota tujuan dulu'
            : 'Ketik kecamatan...';

        clearList(kecamatanList);

        debouncedCariKota();
    });

    kotaInput.addEventListener('focus', () => {
        if (kotaInput.value.trim().length >= 1) {
            debouncedCariKota();
        }
    });

    kotaInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            hideList(kotaList);
            selectedKota = kotaInput.value.trim();
            cekOtomatis(true);
        }
    });

    kotaInput.addEventListener('blur', () => {
        setTimeout(() => {
            if (!kotaList.classList.contains('show') && kotaInput.value.trim()) {
                selectedKota = kotaInput.value.trim();
                cekOtomatis(false);
            }
        }, 200);
    });

    /**
     * Input kecamatan
     */
    kecamatanInput.addEventListener('input', () => {
        selectedKecamatan = '';
        debouncedCariKecamatan();
    });

    kecamatanInput.addEventListener('focus', () => {
        debouncedCariKecamatan();
    });

    kecamatanInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            hideList(kecamatanList);
            selectedKecamatan = kecamatanInput.value.trim();
            cekOtomatis(true);
        }
    });

    kecamatanInput.addEventListener('blur', () => {
        setTimeout(() => {
            if (!kecamatanList.classList.contains('show') && kotaInput.value.trim()) {
                selectedKecamatan = kecamatanInput.value.trim();
                cekOtomatis(false);
            }
        }, 200);
    });

    /**
     * Tutup dropdown saat klik di luar
     */
    document.addEventListener('click', (e) => {
        const kotaField = kotaInput.closest('.field');
        const kecamatanField = kecamatanInput.closest('.field');

        if (kotaField && !kotaField.contains(e.target)) {
            hideList(kotaList);
        }

        if (kecamatanField && !kecamatanField.contains(e.target)) {
            hideList(kecamatanList);
        }
    });

    function renderHasil(data) {
        if (!data) {
            result.innerHTML = '';
            return;
        }

        /**
         * Format ongkirajax versi baru:
         * {
         *   mode: 'kecamatan',
         *   rows: [...]
         * }
         */
        if (data.mode === 'kecamatan') {
            renderKecamatan(data.rows || []);
            return;
        }

        /**
         * Format ongkirajax versi baru:
         * {
         *   mode: 'kota',
         *   row: {...}
         * }
         */
        if (data.mode === 'kota') {
            renderKota(data.row || {});
            return;
        }

        /**
         * Format ongkirajax versi lama:
         * {
         *   min_tarif: ...,
         *   max_tarif: ...,
         *   min_kg: ...,
         *   max_kg: ...,
         *   lead_time: ...
         * }
         */
        if (
            typeof data.min_tarif !== 'undefined' ||
            typeof data.min_kg !== 'undefined'
        ) {
            renderOldFormat(data);
            return;
        }

        /**
         * Fallback
         */
        if (data.rows) {
            renderKecamatan(data.rows);
            return;
        }

        if (data.row) {
            renderKota(data.row);
            return;
        }

        result.innerHTML = `
            <div class="notice">
                Data tidak ditemukan.
            </div>
        `;
    }

    function renderOldFormat(d) {
        result.innerHTML = `
            <div class="notice">
                <b class="title-small">Hasil Ongkir</b><br>

                Tarif: <b>${rupiah(d.min_tarif)}</b> - <b>${rupiah(d.max_tarif)}</b><br>
                Minimum berat: <b>${escapeHtml(d.min_kg || 0)}</b> - <b>${escapeHtml(d.max_kg || 0)}</b> kg<br>
                Estimasi: <b>${escapeHtml(d.lead_time || '-')}</b>

                <div class="muted">
                    Pilih kecamatan untuk hasil yang lebih spesifik.
                </div>
            </div>
        `;
    }

    function renderKota(d) {
        result.innerHTML = `
            <div class="notice">
                <b class="title-small">${escapeHtml(d.kabupaten_kota || '-')}</b><br>

                Jumlah kecamatan tersedia: <b>${Number(d.jumlah_kecamatan || 0)}</b><br>
                Tarif: <b>${rupiah(d.min_tarif)}</b> - <b>${rupiah(d.max_tarif)}</b><br>
                Minimum berat: <b>${escapeHtml(d.min_kg || 0)}</b> - <b>${escapeHtml(d.max_kg || 0)}</b> kg<br>
                Estimasi: <b>${escapeHtml(d.lead_time || '-')}</b>

                <div class="muted">
                    Pilih kecamatan untuk hasil yang lebih spesifik.
                </div>
            </div>
        `;
    }

    function renderKecamatan(rows) {
        if (!rows.length) {
            result.innerHTML = `
                <div class="notice error">
                    Kecamatan tidak ditemukan.
                </div>
            `;
            return;
        }

        const first = rows[0] || {};

        let html = `
            <div class="notice">
                Hasil ongkir untuk kecamatan
                <b>${escapeHtml(first.kecamatan || '-')}</b>,
                ${escapeHtml(first.kabupaten_kota || '-')}.
            </div>
        `;

        html += `
            <table>
                <thead>
                    <tr>
                        <th>Rute</th>
                        <th>Tarif Darat</th>
                        <th>Minimum Kg</th>
                        <th>Lead Time</th>
                    </tr>
                </thead>
                <tbody>
        `;

        rows.forEach((row) => {
            html += `
                <tr>
                    <td>${escapeHtml(row.nama_sisco || row.kecamatan || '-')}</td>
                    <td>${rupiah(row.tariff_darat)}</td>
                    <td>${escapeHtml(row.minimum_kg || 0)} kg</td>
                    <td>${escapeHtml(row.lead_time || '-')}</td>
                </tr>
            `;
        });

        html += `</tbody></table>`;

        result.innerHTML = html;
    }

})();
</script>

</body>
</html>