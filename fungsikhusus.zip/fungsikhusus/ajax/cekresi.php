﻿<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Resi Pengiriman</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            padding: 40px;
            width: 100%;
            max-width: 600px;
        }
        h1 { text-align: center; color: #1a1a2e; margin-bottom: 8px; font-size: 24px; }
        .subtitle { text-align: center; color: #888; margin-bottom: 30px; font-size: 14px; }
        .search-box { display: flex; gap: 10px; margin-bottom: 30px; }
        .search-box input {
            flex: 1;
            padding: 14px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.3s;
            outline: none;
        }
        .search-box input:focus { border-color: #4361ee; }
        .search-box button {
            padding: 14px 28px;
            background: #4361ee;
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s, transform 0.2s;
        }
        .search-box button:hover { background: #3a56d4; transform: translateY(-1px); }
        .search-box button:disabled { background: #a0a0a0; cursor: not-allowed; transform: none; }
        .loading { text-align: center; padding: 20px; display: none; }
        .loading .spinner {
            width: 40px; height: 40px;
            border: 4px solid #e0e0e0;
            border-top-color: #4361ee;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 10px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .result-area { display: none; }
        .error-msg {
            background: #fee;
            color: #c0392b;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            display: none;
        }

        .paket-info {
            background: #f8f9ff;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid #e8ecff;
        }
        .paket-info .row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }
        .paket-info .row:last-child { margin-bottom: 0; }
        .paket-info .label { color: #666; }
        .paket-info .value { font-weight: 600; color: #1a1a2e; }
        .route {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px dashed #d0d5ff;
        }
        .route .city {
            background: #4361ee;
            color: #fff;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }
        .route .arrow { color: #4361ee; font-size: 18px; }

        /* Timeline */
        .timeline { position: relative; padding-left: 30px; }
        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: #e0e0e0;
            border-radius: 3px;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 22px;
            padding-left: 10px;
        }
        .timeline-item:last-child { margin-bottom: 0; }
        .timeline-item .dot {
            position: absolute;
            left: -25px;
            top: 4px;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #e0e0e0;
            border: 3px solid #fff;
            box-shadow: 0 0 0 2px #e0e0e0;
        }
        .timeline-item.active .dot {
            background: #4361ee;
            box-shadow: 0 0 0 2px #4361ee;
        }
        .timeline-item.completed .dot {
            background: #27ae60;
            box-shadow: 0 0 0 2px #27ae60;
        }
        .timeline-item .tl-title {
            font-weight: 600;
            font-size: 14px;
            color: #1a1a2e;
        }
        .timeline-item .tl-time {
            font-size: 12px;
            color: #666;
            margin-top: 3px;
        }

        /* Mobile responsive */
        html, body { width:100%; overflow-x:hidden; }
        @media (max-width:600px){
          body{padding:10px;align-items:flex-start;}
          .container{width:100%;max-width:100%;padding:22px 16px;border-radius:12px;margin:10px 0;}
          h1{font-size:21px;margin-bottom:6px;}
          .subtitle{font-size:13px;line-height:1.5;margin-bottom:20px;}
          .search-box{flex-direction:column;gap:9px;margin-bottom:20px;}
          .search-box input,.search-box button{width:100%;min-height:48px;font-size:16px;}
          .search-box input{padding:12px 15px;}
          .search-box button{padding:12px 20px;}
          .paket-info{padding:15px;margin-bottom:20px;}
          .paket-info .row{gap:10px;align-items:flex-start;font-size:13px;line-height:1.4;}
          .paket-info .value{min-width:0;max-width:65%;text-align:right;overflow-wrap:anywhere;}
          .route{flex-wrap:wrap;gap:7px;margin-top:12px;padding-top:12px;}
          .route .city{max-width:calc(50% - 18px);padding:5px 10px;font-size:12px;overflow-wrap:anywhere;text-align:center;}
          .route .arrow{font-size:16px;}
          .timeline{padding-left:27px;}
          .timeline::before{left:8px;width:2px;}
          .timeline-item{margin-bottom:20px;padding-left:8px;}
          .timeline-item .dot{left:-24px;width:13px;height:13px;}
          .timeline-item .tl-title{font-size:13px;line-height:1.45;}
          .timeline-item .tl-time{font-size:11px;line-height:1.4;}
          .error-msg{padding:12px;font-size:13px;line-height:1.5;}
          .loading{padding:16px 10px;font-size:13px;}
        }
        @media (max-width:360px){
          body{padding:6px;}
          .container{padding:18px 12px;}
          .paket-info{padding:13px;}
          .route .city{font-size:11px;padding:5px 8px;}
          .timeline-item .tl-title{font-size:12px;}
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📦 Cek Resi</h1>
        <p class="subtitle">Masukkan kode resi untuk melacak paket Anda</p>

        <div class="search-box">
            <input type="text" id="kodeResi" placeholder="Contoh: 1234" autocomplete="off">
            <button id="btnCek">Cek</button>
        </div>

        <div class="loading" id="loading">
            <div class="spinner"></div>
            <p>Mencari resi...</p>
        </div>

        <div class="error-msg" id="errorMsg"></div>

        <div class="result-area" id="resultArea">
            <div class="paket-info" id="paketInfo"></div>
            <div class="timeline" id="timeline"></div>
        </div>
    </div>

    <script>
    $(function() {

        // Submit via Enter atau klik tombol
        $('#kodeResi').on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                $('#btnCek').trigger('click');
            }
        });

        $('#btnCek').on('click', function() {
            var kode = $.trim($('#kodeResi').val());

            if (!kode) {
                showError('Silakan masukkan kode resi.');
                return;
            }

            // Reset tampilan
            $('#resultArea').hide();
            $('#errorMsg').hide();
            $('#loading').show();
            $('#btnCek').prop('disabled', true);

            $.ajax({
                url: '/resiajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'cek_resi',
                    kode_resi: kode
                },
                success: function(res) {
                    $('#loading').hide();
                    $('#btnCek').prop('disabled', false);

                    if (res.success) {
                        renderResult(res.data);
                    } else {
                        showError(res.message || 'Resi tidak ditemukan.');
                    }
                },
                error: function() {
                    $('#loading').hide();
                    $('#btnCek').prop('disabled', false);
                    showError('Terjadi kesalahan server. Silakan coba lagi.');
                }
            });
        });

        function showError(msg) {
            $('#resultArea').hide();
            $('#errorMsg').text(msg).show();
        }

        function renderResult(data) {
            // ── Info Paket ───────────────────────────────
            var infoHtml = ''
                + '<div class="row"><span class="label">Kode Resi</span><span class="value">' + escHtml(data.name) + '</span></div>'
                + '<div class="row"><span class="label">Penerima</span><span class="value">' + escHtml(data.penerima || '-') + '</span></div>'
                + '<div class="route">'
                +   '<span class="city">' + escHtml(data.origin_hub) + '</span>'
                +   '<span class="arrow">➜</span>'
                +   '<span class="city">' + escHtml(data.destination_hub) + '</span>'
                + '</div>';
            $('#paketInfo').html(infoHtml);

            // ── Definisikan semua step ───────────────────
            var steps = [
                { key: 'pick_time',                     label: 'Paket Diambil' },
                { key: 'to_origin_hub_time',            label: 'Menuju Hub Asal (' + data.origin_hub + ')' },
                { key: 'on_origin_hub_time',            label: 'Tiba di Hub Asal (' + data.origin_hub + ')' },
                { key: 'going_to_destination_hub_time', label: 'Menuju Hub Tujuan (' + data.destination_hub + ')' },
                { key: 'on_destination_hub_time',       label: 'Tiba di Hub Tujuan (' + data.destination_hub + ')' },
                { key: 'deliver_destination_time',      label: 'Paket Dalam Pengiriman ke Tujuan' },
                { key: 'delivered_time',                label: 'Paket Diterima' }
            ];

            // ── FILTER: hanya step yang waktunya valid ───
            var validSteps = [];
            for (var i = 0; i < steps.length; i++) {
                if (isValidTime(data[steps[i].key])) {
                    validSteps.push({
                        label: steps[i].label,
                        time:  data[steps[i].key]
                    });
                }
            }

            // ── Render timeline ──────────────────────────
            // Paket sudah sampai? → semua hijau (completed)
            // Belum sampai?      → step terakhir biru (active), lainnya hijau
            var isDelivered = isValidTime(data.delivered_time);
            var tlHtml = '';

            for (var j = 0; j < validSteps.length; j++) {
                var cls;
                if (isDelivered) {
                    cls = 'completed';
                } else {
                    cls = (j === validSteps.length - 1) ? 'active' : 'completed';
                }

                tlHtml += '<div class="timeline-item ' + cls + '">'
                        +   '<div class="dot"></div>'
                        +   '<div class="tl-title">' + validSteps[j].label + '</div>'
                        +   '<div class="tl-time">' + formatTime(validSteps[j].time) + '</div>'
                        + '</div>';
            }

            $('#timeline').html(tlHtml);
            $('#resultArea').show();
        }

        function isValidTime(t) {
            return t && t !== '0000-00-00 00:00:00' && t !== '';
        }

        function formatTime(t) {
            // "2026-07-28 07:48:00" → "28 Jul 2026, 07:48"
            var d = new Date(t.replace(' ', 'T'));
            if (isNaN(d)) return t;
            var months = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
            var dd   = String(d.getDate()).padStart(2, '0');
            var mm   = months[d.getMonth()];
            var yyyy = d.getFullYear();
            var hh   = String(d.getHours()).padStart(2, '0');
            var mi   = String(d.getMinutes()).padStart(2, '0');
            return dd + ' ' + mm + ' ' + yyyy + ', ' + hh + ':' + mi;
        }

        function escHtml(s) {
            return $('<span>').text(s).html();
        }
    });
    </script>
</body>
</html>