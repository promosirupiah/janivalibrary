jQuery( function ( $ ) {

    if ( typeof resiAutocomplete === 'undefined' ) {
        return;
    }

    var fields = '#pods-form-ui-pods-field-origin-hub, #pods-form-ui-pods-field-destination-hub';

    $( fields ).autocomplete( {
        source: function ( request, response ) {
            $.getJSON( resiAutocomplete.ajaxUrl, {
                term: request.term
            }, response );
        },
        minLength: 2,
        delay: 250,
        select: function ( event, ui ) {
            $( this ).data( 'city-id', ui.item.id );
        }
    } );
} );