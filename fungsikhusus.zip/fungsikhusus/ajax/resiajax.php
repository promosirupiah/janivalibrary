<?php
/**
 * AJAX Resi
 *
 * URL publik:
 * /resiajax.php
 *
 * .htaccess:
 * RewriteRule ^resiajax.php/?$ /wp-content/plugins/fungsikhusus/ajax/resiajax.php [L,QSA]
 *
 * Menggunakan SHORTINIT agar endpoint tetap ringan.
 */

define( 'SHORTINIT', true );

$wp_load = dirname( __DIR__, 4 ) . '/wp-load.php';

if ( ! file_exists( $wp_load ) ) {
    header( 'Content-Type: application/json; charset=utf-8' );
    http_response_code( 500 );
    echo wp_json_encode( array(
        'success' => false,
        'message' => 'wp-load.php tidak ditemukan.',
    ) );
    exit;
}

require_once $wp_load;

header( 'Content-Type: application/json; charset=utf-8' );
header( 'X-Content-Type-Options: nosniff' );

global $wpdb;

/*
 * ============================================================
 * ACTION: SEARCH CUSTOMER
 * ============================================================
 *
 * Dipakai oleh Select2 pada:
 * - pods-add-new-resi
 * - pods-manage-resi?action=add
 * - pods-manage-resi?action=edit
 *
 * Data dibaca dari:
 * {$wpdb->prefix}pods_customer
 *
 * Dengan prefix tn_:
 * tn_pods_customer
 */
if (
    isset( $_REQUEST['action'] ) &&
    sanitize_key( wp_unslash( $_REQUEST['action'] ) ) === 'search_customer'
) {

    /*
     * Endpoint ini dipanggil dari halaman wp-admin oleh Select2.
     * Tidak menggunakan nonce/authentication agar endpoint tetap ringan.
     */

    /*
     * Ambil keyword.
     */
    $term = isset( $_REQUEST['term'] )
        ? sanitize_text_field( wp_unslash( $_REQUEST['term'] ) )
        : '';

    $term = trim( $term );

    /*
     * Jangan query jika terlalu pendek.
     */
    if ( strlen( $term ) < 1 ) {
        echo wp_json_encode( array(
            'success' => true,
            'data'    => array(),
        ) );

        exit;
    }

    /*
     * Nama tabel otomatis mengikuti prefix WordPress.
     *
     * Jika $table_prefix = 'tn_':
     * tn_pods_customer
     */
    $table = $wpdb->prefix . 'pods_customer';

    /*
     * Search:
     * - name
     * - company
     * - contact
     * - phone
     * - address
     * - tipe
     *
     * Hanya kolom yang memang ada pada CSV yang Anda berikan.
     */
    $like = '%' . $wpdb->esc_like( $term ) . '%';

    $sql = $wpdb->prepare(
        "SELECT
            id,
            name,
            tipe,
            company,
            contact,
            address,
            phone,
            remark
         FROM {$table}
         WHERE
            name LIKE %s
            OR company LIKE %s
            OR contact LIKE %s
            OR phone LIKE %s
            OR address LIKE %s
            OR tipe LIKE %s
         ORDER BY
            CASE
                WHEN name = %s THEN 0
                WHEN name LIKE %s THEN 1
                WHEN company LIKE %s THEN 2
                ELSE 3
            END,
            name ASC
         LIMIT 20",
        $like,
        $like,
        $like,
        $like,
        $like,
        $like,
        $term,
        $like,
        $like
    );

    $rows = $wpdb->get_results( $sql, ARRAY_A );

    /*
     * Jika tabel tidak ada / query gagal.
     */
    if ( $wpdb->last_error ) {
        http_response_code( 500 );

        echo wp_json_encode( array(
            'success' => false,
            'message' => 'Gagal membaca tabel customer.',
        ) );

        exit;
    }

    $results = array();

    foreach ( $rows as $row ) {
        $results[] = array(
            'id'      => (int) $row['id'],
            'name'    => (string) $row['name'],
            'tipe'    => (string) $row['tipe'],
            'company' => (string) $row['company'],
            'contact' => (string) $row['contact'],
            'address' => (string) $row['address'],
            'phone'   => (string) $row['phone'],
            'remark'  => (string) $row['remark'],
        );
    }

    echo wp_json_encode(
        array(
            'success' => true,
            'data'    => $results,
        ),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

    exit;
}


/*
 * ============================================================
 * ACTION: CALCULATE RESI FEE
 * ============================================================
 */
if (
    isset($_REQUEST['action']) &&
    sanitize_key(wp_unslash($_REQUEST['action'])) === 'calculate_fee'
) {
    $asal = isset($_REQUEST['asal'])
        ? sanitize_text_field(wp_unslash($_REQUEST['asal']))
        : 'SEMARANG';

    $kota = isset($_REQUEST['kota'])
        ? sanitize_text_field(wp_unslash($_REQUEST['kota']))
        : '';

    $customer = isset($_REQUEST['customer'])
        ? sanitize_text_field(wp_unslash($_REQUEST['customer']))
        : '';

    $weight_raw = isset($_REQUEST['weight'])
        ? str_replace(',', '.', sanitize_text_field(wp_unslash($_REQUEST['weight'])))
        : '0';

    $weight = (float) $weight_raw;

    if ($weight < 0) {
        $weight = 0;
    }

    if ($kota === '' || $weight <= 0) {
        echo wp_json_encode(array(
            'success' => true,
            'data' => array(
                'fee' => '',
                'message' => 'Isi Hub Tujuan dan Berat (KG).',
            ),
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $ongkir_table = $wpdb->prefix . 'pods_ongkir';

    /*
     * Satu kota dapat memiliki beberapa kecamatan dengan tarif berbeda.
     * Karena field Resi saat ini hanya menyimpan Hub Tujuan/kota,
     * gunakan tarif terendah untuk kota tersebut, konsisten dengan
     * ringkasan ongkir yang sudah digunakan oleh autocomplete.
     */
    $rate = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT
                tariff_darat,
                minimum_kg,
                lead_time,
                kabupaten_kota
             FROM {$ongkir_table}
             WHERE origin = %s
               AND kabupaten_kota = %s
             ORDER BY tariff_darat ASC, minimum_kg ASC
             LIMIT 1",
            $asal,
            $kota
        ),
        ARRAY_A
    );

    /*
     * Fallback fuzzy bila nilai Hub Tujuan berbeda sedikit dari database.
     */
    if (!$rate) {
        $rate = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT
                    tariff_darat,
                    minimum_kg,
                    lead_time,
                    kabupaten_kota
                 FROM {$ongkir_table}
                 WHERE origin = %s
                   AND kabupaten_kota LIKE %s
                 ORDER BY tariff_darat ASC, minimum_kg ASC
                 LIMIT 1",
                $asal,
                '%' . $wpdb->esc_like($kota) . '%'
            ),
            ARRAY_A
        );
    }

    if (!$rate) {
        echo wp_json_encode(array(
            'success' => false,
            'message' => 'Tarif untuk Hub Tujuan "' . $kota . '" tidak ditemukan.',
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $tariff = (float) $rate['tariff_darat'];
    $minimum_kg = (float) $rate['minimum_kg'];

    /*
     * Berat di bawah minimum tetap ditagihkan minimum_kg.
     */
    $billable_weight = max($weight, $minimum_kg);

    /*
     * Tentukan tipe customer.
     * Field customer pada Pods menyimpan nama customer, sehingga tipe
     * dibaca dari tabel Pods Customer.
     */
    $customer_type = '';
    if ($customer !== '') {
        $customer_table = $wpdb->prefix . 'pods_customer';

        $customer_type = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT tipe
                 FROM {$customer_table}
                 WHERE name = %s
                 LIMIT 1",
                $customer
            )
        );

        if ($customer_type === null) {
            /*
             * Fallback pencarian agar tetap bekerja jika nama yang
             * tersimpan memiliki perbedaan kapitalisasi/format.
             */
            $customer_type = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT tipe
                     FROM {$customer_table}
                     WHERE name LIKE %s
                     ORDER BY id ASC
                     LIMIT 1",
                    '%' . $wpdb->esc_like($customer) . '%'
                )
            );
        }
    }

    $normalized_type = strtolower(trim((string) $customer_type));
    $normalized_type = preg_replace('/[^a-z0-9]+/', '', $normalized_type);

    $is_corporate = in_array(
        $normalized_type,
        array('corporate', 'corporat', 'corp'),
        true
    );

    $corporate_discount_per_kg = 1000;
    $corporate_tariff = max(0, $tariff - $corporate_discount_per_kg);

    $discount_per_kg = $is_corporate ? $corporate_discount_per_kg : 0;
    $effective_tariff = max(0, $tariff - $discount_per_kg);

    // Total ongkir normal dan total ongkir Corporate setelah berat diketahui.
    $normal_total = $tariff * $billable_weight;
    $corporate_total = $corporate_tariff * $billable_weight;

    // Fee yang disimpan mengikuti tipe customer yang dipilih.
    $fee = $effective_tariff * $billable_weight;

    echo wp_json_encode(array(
        'success' => true,
        'data' => array(
            'fee' => (int) round($fee),
            'tariff' => (int) round($tariff),
            'corporate_tariff' => (int) round($corporate_tariff),
            'normal_total' => (int) round($normal_total),
            'corporate_total' => (int) round($corporate_total),
            'effective_tariff' => (int) round($effective_tariff),
            'discount_per_kg' => $discount_per_kg,
            'corporate_discount_per_kg' => $corporate_discount_per_kg,
            'weight' => $weight,
            'minimum_kg' => $minimum_kg,
            'billable_weight' => $billable_weight,
            'customer_type' => (string) $customer_type,
            'is_corporate' => $is_corporate,
            'lead_time' => (string) ($rate['lead_time'] ?? ''),
            'kabupaten_kota' => (string) ($rate['kabupaten_kota'] ?? $kota),
        ),
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/*
 * ============================================================
 * ACTION: CEK RESI
 * ============================================================
 */
if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
    http_response_code( 405 );

    echo wp_json_encode( array(
        'success' => false,
        'message' => 'Method tidak diizinkan.',
    ) );

    exit;
}

$action = isset( $_POST['action'] )
    ? sanitize_text_field( wp_unslash( $_POST['action'] ) )
    : '';

$kode_resi = isset( $_POST['kode_resi'] )
    ? sanitize_text_field( wp_unslash( $_POST['kode_resi'] ) )
    : '';

if ( $action !== 'cek_resi' ) {
    http_response_code( 400 );

    echo wp_json_encode( array(
        'success' => false,
        'message' => 'Action tidak valid.',
    ) );

    exit;
}

if ( empty( $kode_resi ) ) {
    http_response_code( 400 );

    echo wp_json_encode( array(
        'success' => false,
        'message' => 'Kode resi wajib diisi.',
    ) );

    exit;
}


/*
 * ============================================================
 * QUERY RESI
 * ============================================================
 */
$table = $wpdb->prefix . 'pods_resi';

$row = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT
            name,
            penerima,
            origin_hub,
            destination_hub,
            pick_time,
            to_origin_hub_time,
            on_origin_hub_time,
            going_to_destination_hub_time,
            on_destination_hub_time,
            deliver_destination_time,
            delivered_time
         FROM {$table}
         WHERE name = %s
         LIMIT 1",
        $kode_resi
    ),
    ARRAY_A
);

if ( ! $row ) {
    echo wp_json_encode( array(
        'success' => false,
        'message' => 'Resi "' . $kode_resi . '" tidak ditemukan.',
    ), JSON_UNESCAPED_UNICODE );

    exit;
}

echo wp_json_encode(
    array(
        'success' => true,
        'data'    => $row,
    ),
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);

exit;
