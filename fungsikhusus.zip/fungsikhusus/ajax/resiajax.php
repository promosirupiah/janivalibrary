<?php
/**
 * AJAX Handler untuk Cek Resi
 * File: resiajax.php (root folder WordPress)
 * Menggunakan SHORTINIT untuk performa cepat (skip plugins & themes)
  tambahkan pada .htaccess:
 RewriteRule ^resiajax.php/?$ /wp-content/plugins/fungsikhusus/ajax/resiajax.php [L,QSA]
 */

// Hanya load WordPress minimal (DB, $wpdb, constants)
define( 'SHORTINIT', true );

$wp_load = dirname( __DIR__, 4 ) . '/wp-load.php';
if ( ! file_exists( $wp_load ) ) {
    status_header( 500 );
    exit( json_encode( array( 'error' => 'wp-load.php tidak ditemukan' ) ) );
}
require_once $wp_load;

// -- Security Headers ----------------------------------
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// -- Hanya izinkan POST --------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    wp_send_json_error(['message' => 'Method tidak diizinkan.'], 405);
}

// -- Validasi input ------------------------------------
$action    = isset($_POST['action']) ? sanitize_text_field($_POST['action']) : '';
$kode_resi = isset($_POST['kode_resi']) ? sanitize_text_field($_POST['kode_resi']) : '';

if ($action !== 'cek_resi') {
    wp_send_json_error(['message' => 'Action tidak valid.'], 400);
}

if (empty($kode_resi)) {
    wp_send_json_error(['message' => 'Kode resi wajib diisi.'], 400);
}

// -- Query ke tabel tn_pods_resi -----------------------
global $wpdb;

$table = $wpdb->prefix . 'pods_resi';   // tn_pods_resi ? prefix "tn_"

$row = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT name,
                origin_hub,
                destination_hub,
                pick_time,
                to_origin_hub_time,
                on_origin_hub_time,
                going_to_destination_hub_time,
                on_destination_hub_time,
                deliver_destination_time,
                delivered_time
         FROM {$table}
         WHERE name = %s
         LIMIT 1",
        $kode_resi
    ),
    ARRAY_A
);

if (!$row) {
    wp_send_json_error(['message' => 'Resi "' . esc_html($kode_resi) . '" tidak ditemukan.']);
}

// -- Response sukses -----------------------------------
wp_send_json_success($row);