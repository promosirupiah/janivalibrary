Fungsi Khusus + Resi Uploader 2.2.4

Perubahan versi ini:
- Field Inbound dan Outbond pada form Pods Resi ditata menjadi 2 kolom.
- Tampilan desktop:
  Inbound Name    | Outbond Name
  Inbound Alamat  | Outbond Alamat
  Inbound PIC     | Outbond PIC
  Inbound Telpon  | Outbond Telpon
- Pada layar kecil, otomatis kembali menjadi 1 kolom.
- Mempertahankan fungsi autocomplete customer, kalkulator ongkir, uploader foto, dan fungsi lain dari versi sebelumnya.


Print Resi:
Pada halaman Pods Resi edit, tombol Print Resi otomatis mengarah ke /cetakresi.php?idresi={ID}.

Customer Autofill:
Saat customer dipilih pada Pods Resi, field alamat pengirim/asal dan telepon pengirim/asal diisi otomatis dari tabel tn_pods_customer.


Cek Resi:
Endpoint publik /resiajax.php menggunakan rewrite rule plugin dan sekarang mengirim field penerima dari tn_pods_resi.
