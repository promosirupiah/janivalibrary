jQuery(function ($) {
    'use strict';

    if (typeof resiFeeCalculator === 'undefined') {
        return;
    }

    var config = resiFeeCalculator || {};
    var fields = config.fields || {};
    var rates = config.rates || {};
    var corporateCustomers = config.corporateCustomers || {};
    var discountPerKg = parseFloat(config.discountPerKg || 1000);
    var lastKey = '';

    function getValue(selector) {
        var $field = $(selector);
        return $field.length ? $.trim($field.val() || '') : '';
    }

    function normalizeText(value) {
        return $.trim(String(value == null ? '' : value))
            .replace(/\s+/g, ' ')
            .toLowerCase();
    }

    function parseNumber(value) {
        if (value === null || value === undefined || value === '') {
            return 0;
        }

        var text = String(value).trim().replace(/\s/g, '');

        /*
         * Mendukung:
         * 10
         * 10,5
         * 10.5
         * 1.000,5
         */
        if (text.indexOf(',') !== -1 && text.indexOf('.') !== -1) {
            if (text.lastIndexOf(',') > text.lastIndexOf('.')) {
                text = text.replace(/\./g, '').replace(',', '.');
            } else {
                text = text.replace(/,/g, '');
            }
        } else if (text.indexOf(',') !== -1) {
            text = text.replace(',', '.');
        }

        var number = parseFloat(text);
        return isNaN(number) ? 0 : number;
    }

    function formatRupiah(value) {
        var number = Math.round(parseNumber(value));
        if (!isFinite(number)) {
            return 'Rp0';
        }
        return 'Rp' + String(number).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }

    function escapeHtml(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function ensureInfo() {
        var $info = $('#resi-fee-calculator-info');

        if (!$info.length) {
            $info = $('<div id="resi-fee-calculator-info" class="resi-fee-calculator-info"></div>');

            var $fee = $(fields.fee);

            /*
             * Tempatkan Total Ongkir TEPAT DI BAWAH INPUT fee.
             *
             * Pada Pods form berbentuk tabel, input biasanya berada di dalam
             * <td>. Dengan memasukkan calculator ke dalam <td> yang sama,
             * calculator mengikuti lebar area input seperti field Data Customer
             * dan Harga Ongkir, bukan membuat baris baru selebar halaman.
             */
            if ($fee.length) {
                var $feeCell = $fee.closest('td').first();

                if ($feeCell.length) {
                    var $feeControl = $fee.closest(
                        '.pods-form-ui-control, .pods-field__input, .pods-form-ui-field, .pods-field-input'
                    ).first();

                    if ($feeControl.length) {
                        $feeControl.after($info);
                    } else {
                        $fee.after($info);
                    }
                } else {
                    /*
                     * Fallback untuk layout Pods non-table.
                     */
                    var $feeRow = $fee.closest(
                        '.pods-field, .form-group, .pods-field-container, .pods-form-ui-row'
                    ).first();

                    if ($feeRow.length) {
                        $feeRow.find('input, textarea, select').last().after($info);
                    } else {
                        $fee.after($info);
                    }
                }
            } else {
                var $weight = $(fields.weight);
                var $weightCell = $weight.closest('td').first();

                if ($weightCell.length) {
                    $weightCell.append($info);
                } else {
                    $('body').append($info);
                }
            }
        }

        return $info;
    }

    function addStyle() {
        if ($('#resi-fee-calculator-style').length) {
            return;
        }

        $('head').append(
            '<style id="resi-fee-calculator-style">' +
            '#resi-fee-calculator-info{' +
                'display:block;' +
                'width:100%;' +
                'max-width:none;' +
                'box-sizing:border-box;' +
                'margin:12px 0 20px 0;' +
                'padding:18px 22px;' +
                'border:1px solid #dcdcde;' +
                'border-radius:6px;' +
                'background:#f8f9fa;' +
                'font-size:13px;' +
                'clear:both;' +
                'overflow:hidden;' +
                'line-height:1.65;' +
            '}' +
            '#resi-fee-calculator-info .resi-fee-title{' +
                'font-size:14px;' +
                'font-weight:500;' +
                'margin-bottom:3px;' +
            '}' +
            '#resi-fee-calculator-info .resi-fee-price,' +
            '#resi-fee-calculator-info .resi-fee-corporate-price{' +
                'font-size:22px;' +
                'font-weight:700;' +
                'line-height:1.3;' +
            '}' +
            '#resi-fee-calculator-info .resi-fee-corporate-label{' +
                'font-size:14px;' +
                'font-weight:500;' +
                'margin-top:14px;' +
                'margin-bottom:3px;' +
            '}' +
            '#resi-fee-calculator-info .resi-fee-detail{' +
                'margin-top:10px;' +
                'font-size:13px;' +
                'line-height:1.65;' +
                'color:#50575e;' +
            '}' +
            '#resi-fee-calculator-info .resi-fee-detail > div{' +
                'margin:2px 0;' +
            '}' +
            '#resi-fee-calculator-info.corporate{' +
                'border-color:#8ed1b2;' +
                'background:#f0fff7;' +
            '}' +
            '#resi-fee-calculator-info.error{' +
                'border-color:#d63638;' +
                'background:#fcf0f1;' +
                'color:#8a1f1f;' +
            '}' +
            '@media(max-width:782px){' +
                '#resi-fee-calculator-info{' +
                    'max-width:100%;' +
                    'padding:15px;' +
                '}' +
            '}' +
            '</style>'
        );
    }

    function setFee(value) {
        var $fee = $(fields.fee);
        if (!$fee.length) {
            return;
        }

        var newValue = value === '' || value === null || value === undefined
            ? ''
            : String(Math.round(parseNumber(value)));

        if ($fee.val() !== newValue) {
            $fee.val(newValue).trigger('input').trigger('change');
        }
    }

    function clearFee() {
        lastKey = '';
        setFee('');
        ensureInfo().removeClass('corporate error').empty().hide();
    }

    function findRate(origin, destination) {
        var originKey = normalizeText(origin);
        var destinationKey = normalizeText(destination);
        var exactKey = originKey + '|' + destinationKey;

        if (rates[exactKey]) {
            return rates[exactKey];
        }

        /* Fallback fuzzy agar tetap toleran pada perbedaan kecil penulisan. */
        var keys = Object.keys(rates);
        for (var i = 0; i < keys.length; i++) {
            var rate = rates[keys[i]];
            var rateOrigin = normalizeText(rate.origin);
            var rateDestination = normalizeText(rate.destination);

            if (rateOrigin === originKey && rateDestination.indexOf(destinationKey) !== -1) {
                return rate;
            }

            if (rateOrigin.indexOf(originKey) !== -1 && rateDestination === destinationKey) {
                return rate;
            }
        }

        return null;
    }

    function isCorporateCustomer(customer) {
        var key = normalizeText(customer);
        if (!key) {
            return false;
        }

        if (corporateCustomers[key]) {
            return true;
        }

        var names = Object.keys(corporateCustomers);
        for (var i = 0; i < names.length; i++) {
            if (names[i] === key) {
                return true;
            }
        }

        return false;
    }

    function getCorporateType(customer) {
        var key = normalizeText(customer);
        return corporateCustomers[key] && corporateCustomers[key].type
            ? corporateCustomers[key].type
            : 'Corporate';
    }

    function calculate(force) {
        var origin = getValue(fields.origin);
        var destination = getValue(fields.destination);
        var weightRaw = getValue(fields.weight);
        var customer = getValue(fields.customer);
        var weight = parseNumber(weightRaw);

        if (!origin || !destination || weight <= 0) {
            clearFee();
            return;
        }

        var key = [normalizeText(origin), normalizeText(destination), weight, normalizeText(customer)].join('|');
        if (!force && key === lastKey) {
            return;
        }
        lastKey = key;

        var rate = findRate(origin, destination);
        var $info = ensureInfo();

        if (!rate) {
            setFee('');
            $info.removeClass('corporate').addClass('error').html(
                '<div class="resi-fee-title">Perhitungan Biaya</div>' +
                '<div>Tarif untuk Hub Tujuan <strong>' + escapeHtml(destination) + '</strong> tidak ditemukan.</div>'
            ).show();
            return;
        }

        var tariff = parseNumber(rate.tariff);
        var minimumKg = parseNumber(rate.minimum_kg);
        var billableWeight = Math.max(weight, minimumKg);
        var corporateTariff = Math.max(0, tariff - discountPerKg);
        var normalTotal = Math.round(tariff * billableWeight);
        var corporateTotal = Math.round(corporateTariff * billableWeight);
        var customerIsCorporate = isCorporateCustomer(customer);
        var effectiveTariff = customerIsCorporate ? corporateTariff : tariff;
        var fee = customerIsCorporate ? corporateTotal : normalTotal;

        setFee(fee);

        var customerLine = customerIsCorporate
            ? '<div><strong>Customer Corporate:</strong> ' + escapeHtml(getCorporateType(customer)) + '</div>'
            : '<div>Customer: ' + escapeHtml(customer || 'Non-Corporate') + '</div>';

        $info
            .toggleClass('corporate', customerIsCorporate)
            .removeClass('error')
            .html(
                '<div class="resi-fee-title">Total Ongkir</div>' +
                '<div class="resi-fee-price">' + formatRupiah(normalTotal) + '</div>' +
                '<div class="resi-fee-corporate-label">Total Ongkir Corporate</div>' +
                '<div class="resi-fee-corporate-price">' + formatRupiah(corporateTotal) + '</div>' +
                '<div class="resi-fee-detail">' +
                    '<div>Berat: ' + escapeHtml(weight) + ' kg | Ditagihkan: ' + escapeHtml(billableWeight) + ' kg</div>' +
                    '<div>Tarif normal: ' + formatRupiah(tariff) + '/kg | Tarif Corporate: ' + formatRupiah(corporateTariff) + '/kg</div>' +
                    '<div>Diskon Corporate: ' + formatRupiah(discountPerKg) + '/kg</div>' +
                    '<div>Harga yang digunakan: ' + formatRupiah(effectiveTariff) + '/kg</div>' +
                    '<div><strong>Biaya Resi: ' + formatRupiah(fee) + '</strong></div>' +
                    customerLine +
                    (rate.lead_time ? '<div>Lead Time: ' + escapeHtml(rate.lead_time) + '</div>' : '') +
                '</div>'
            )
            .show();
    }

    function bind() {
        var selectors = [
            fields.origin,
            fields.destination,
            fields.weight,
            fields.customer
        ];

        $.each(selectors, function (_, selector) {
            var $field = $(selector);
            if (!$field.length) {
                return;
            }

            $field.off('.resiFeeCalculator').on(
                'input.resiFeeCalculator change.resiFeeCalculator',
                function () {
                    window.setTimeout(function () {
                        calculate(true);
                    }, 30);
                }
            );
        });

        calculate(true);
    }

    addStyle();
    bind();

    /* Pods kadang merender field beberapa saat setelah halaman siap. */
    var attempts = 0;
    var timer = setInterval(function () {
        attempts++;
        bind();

        if (attempts >= 30) {
            clearInterval(timer);
        }
    }, 250);
});
