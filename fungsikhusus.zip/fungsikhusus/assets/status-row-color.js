(function ($) {
    'use strict';

    function applyStatusColors() {
        var $rows = $('#the-list tr');

        $rows.each(function () {
            var $row = $(this);
            var $statusCell = $row.find('td.pods-ui-col-field-status').first();

            if (!$statusCell.length) {
                return;
            }

            var status = $.trim($statusCell.text()).toLowerCase();

            // Hapus class sebelumnya agar aman jika tabel diperbarui/dimuat ulang.
            $row.removeClass('pods-resi-status-missroute pods-resi-status-lost');

            if (status === 'missroute') {
                $row.addClass('pods-resi-status-missroute');
            } else if (status === 'lost') {
                $row.addClass('pods-resi-status-lost');
            }
        });
    }

    $(document).ready(function () {
        applyStatusColors();

        // Pods/WordPress dapat memperbarui isi tabel tanpa reload penuh.
        // Pantau perubahan pada tbody agar warna diterapkan kembali.
        var list = document.getElementById('the-list');

        if (list && window.MutationObserver) {
            var observer = new MutationObserver(function () {
                applyStatusColors();
            });

            observer.observe(list, {
                childList: true,
                subtree: true
            });
        }

        // Antisipasi perubahan tabel setelah aksi tertentu.
        $(document).ajaxComplete(function () {
            applyStatusColors();
        });
    });

})(jQuery);
