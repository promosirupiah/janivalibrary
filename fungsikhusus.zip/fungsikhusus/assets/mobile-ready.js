jQuery(function ($) {
    'use strict';

    /*
     * Pods memakai AJAX untuk memuat beberapa field.
     * Setelah field dimuat, pastikan kontrol baru tetap mengikuti
     * lebar container mobile.
     */
    function refreshMobileSizing() {
        if (window.innerWidth > 600) {
            return;
        }

        $('#pods-meta-box-details .select2-container').each(function () {
            $(this).css({
                width: '100%',
                maxWidth: '100%'
            });
        });

        $('#pods-meta-box-details input, #pods-meta-box-details select, #pods-meta-box-details textarea').each(function () {
            var $el = $(this);

            if (!$el.is(':checkbox') && !$el.is(':radio') && !$el.is(':hidden')) {
                $el.css({
                    maxWidth: '100%',
                    boxSizing: 'border-box'
                });
            }
        });
    }

    refreshMobileSizing();

    // Pods dapat memasukkan field secara dinamis.
    var observerTarget = document.getElementById('pods-meta-box-details');

    if (observerTarget && window.MutationObserver) {
        var observer = new MutationObserver(function () {
            refreshMobileSizing();
        });

        observer.observe(observerTarget, {
            childList: true,
            subtree: true
        });
    }

    $(window).on('resize orientationchange', function () {
        refreshMobileSizing();
    });
});
