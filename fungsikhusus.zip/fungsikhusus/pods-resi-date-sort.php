<?php
/**
 * Plugin Name: Pods Resi Sort by Created
 * Description: Mengurutkan daftar Pods Advanced Content Type "resi" berdasarkan field created terbaru ke terlama pada halaman Pods Manage Resi.
 * Version: 1.0.0
 * Author: Custom
 * License: GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ============================================================
 * KONFIGURASI
 * ============================================================
 */
define( 'PRSC_POD_NAME', 'resi' );
define( 'PRSC_ADMIN_PAGE', 'pods-manage-resi' );
define( 'PRSC_ORDER_COLUMN', 'created' );
define( 'PRSC_ORDER_DIRECTION', 'DESC' );


/**
 * ============================================================
 * CEK APAKAH SEDANG DI HALAMAN PODS MANAGE RESI
 * ============================================================
 */
function prsc_is_resi_manage_page() {

	if ( ! is_admin() ) {
		return false;
	}

	if ( ! isset( $_GET['page'] ) ) {
		return false;
	}

	return sanitize_key( wp_unslash( $_GET['page'] ) ) === PRSC_ADMIN_PAGE;
}


/**
 * ============================================================
 * TAMBAHKAN PARAMETER SORTING KE URL
 *
 * Ini membantu Pods menggunakan parameter sorting pada halaman
 * manage apabila versi Pods mendukung parameter order/orderby.
 * ============================================================
 */
function prsc_modify_resi_manage_url() {

	if ( ! prsc_is_resi_manage_page() ) {
		return;
	}

	/*
	 * Jangan melakukan redirect jika user sedang melakukan:
	 * - bulk action
	 * - delete
	 * - edit
	 * - add
	 * - save
	 */
	$skip_actions = array(
		'edit',
		'add',
		'delete',
		'bulk',
		'duplicate',
	);

	if ( isset( $_GET['action'] ) ) {

		$action = sanitize_key(
			wp_unslash( $_GET['action'] )
		);

		if ( in_array( $action, $skip_actions, true ) ) {
			return;
		}
	}

	/*
	 * Jika parameter sorting sudah ada, jangan redirect lagi.
	 */
	if (
		isset( $_GET['orderby'] ) ||
		isset( $_GET['order'] )
	) {
		return;
	}

	/*
	 * Tambahkan sorting default.
	 *
	 * orderby = created
	 * order   = DESC
	 */
	$url = add_query_arg(
		array(
			'orderby' => PRSC_ORDER_COLUMN,
			'order'   => PRSC_ORDER_DIRECTION,
		),
		admin_url( 'admin.php?page=' . PRSC_ADMIN_PAGE )
	);

	/*
	 * Pertahankan paged jika ada.
	 */
	if ( isset( $_GET['paged'] ) ) {

		$paged = absint(
			$_GET['paged']
		);

		if ( $paged > 0 ) {
			$url = add_query_arg(
				'paged',
				$paged,
				$url
			);
		}
	}

	/*
	 * Redirect sekali untuk menetapkan sorting.
	 */
	wp_safe_redirect( $url );
	exit;
}

add_action(
	'admin_init',
	'prsc_modify_resi_manage_url',
	20
);


/**
 * ============================================================
 * FILTER QUERY PODS
 *
 * Beberapa versi Pods tidak menggunakan parameter URL
 * orderby/order secara langsung. Karena itu kita mencoba
 * mengubah parameter query Pods.
 * ============================================================
 */
function prsc_pods_query_params( $params ) {

	if ( ! prsc_is_resi_manage_page() ) {
		return $params;
	}

	if ( ! is_array( $params ) ) {
		return $params;
	}

	/*
	 * Pastikan sorting berdasarkan created.
	 */
	$params['orderby'] = PRSC_ORDER_COLUMN;
	$params['order']   = PRSC_ORDER_DIRECTION;

	return $params;
}

add_filter(
	'pods_query',
	'prsc_pods_query_params',
	10,
	1
);


/**
 * ============================================================
 * CSS
 *
 * Memberi sedikit indikasi pada halaman bahwa sorting aktif.
 * Tidak mengubah tampilan tabel secara signifikan.
 * ============================================================
 */
function prsc_admin_css() {

	if ( ! prsc_is_resi_manage_page() ) {
		return;
	}
	?>
	<style>
		/*
		 * Jangan mengubah struktur tabel Pods.
		 * CSS ini hanya memastikan area tabel dapat menggunakan
		 * lebar yang tersedia.
		 */
		.pods-manage-table {
			width: 100%;
		}
	</style>
	<?php
}

add_action(
	'admin_head',
	'prsc_admin_css'
);


/**
 * ============================================================
 * JAVASCRIPT FALLBACK
 *
 * Jika versi Pods tidak membaca orderby dari URL, script ini
 * memastikan link sorting "created" diarahkan ke DESC.
 * ============================================================
 */
function prsc_admin_js() {

	if ( ! prsc_is_resi_manage_page() ) {
		return;
	}
	?>
	<script>
	(function () {

		'use strict';

		document.addEventListener('DOMContentLoaded', function () {

			/*
			 * Cari link tabel yang berkaitan dengan created.
			 */
			var links = document.querySelectorAll(
				'a[href*="orderby=created"], a[href*="orderby%3Dcreated"]'
			);

			links.forEach(function (link) {

				try {

					var url = new URL(
						link.href,
						window.location.origin
					);

					url.searchParams.set(
						'orderby',
						'created'
					);

					url.searchParams.set(
						'order',
						'DESC'
					);

					link.href = url.toString();

				} catch (e) {
					// Abaikan jika URL tidak dapat diproses.
				}

			});

		});

	})();
	</script>
	<?php
}

add_action(
	'admin_footer',
	'prsc_admin_js'
);