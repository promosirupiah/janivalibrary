<?php
add_action( 'jet-form-builder/custom-action/approve', function( $request, $handler ) {

$allowapprove = false;
 if (!empty(array_intersect(wp_get_current_user()->roles, array('moderator'))) && get_user_meta(get_current_user_id(),'angkatan',true) == get_user_meta($request['userid'],'angkatan',true) ) {$allowapprove = true;}; //moderator dan angkatan sama
 if (!empty(array_intersect(wp_get_current_user()->roles, array('administrator')))) { $allowapprove = true; }; //admin utama
if($allowapprove)	{
      $user = new WP_User($request['userid']);
	   $user->set_role('customer');
	   update_user_meta( $request['userid'], 'user_activation_status', 1 ); 
    }  else{throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'Anda Tidak Berhak approve user' );} 

}, 10, 2 );