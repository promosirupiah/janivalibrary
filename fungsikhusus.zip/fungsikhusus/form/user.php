<?php
add_action( 'jet-form-builder/custom-action/sync-woo-pods-dynamic', function( $request, $handler ) {
    
    $pod_name = 'user'; // Nama Pod Extended User Anda
    
    // Helper: Validasi ketat untuk field teks biasa
    $is_valid = function( $value ) {
        return isset( $value ) && $value !== '' && $value !== '0' && $value !== 0;
    };

    // 1. Identifikasi Utama
    $user_id_input = $is_valid( $request['id'] ?? null ) ? absint( $request['id'] ) : 0;
    $is_new_user   = ( $user_id_input === 0 );
    $final_user_id = 0;

    // 2. Bangun Data Inti WordPress (Hanya Email, Password, Nama Dasar)
    $user_data = [];
    if ( $is_valid( $request['email'] ?? null ) ) {
        $user_data['user_email'] = sanitize_email( $request['email'] );
    }
    if ( $is_valid( $request['nama_depan'] ?? null ) ) {
        $user_data['first_name'] = sanitize_text_field( $request['nama_depan'] );
    }
    if ( $is_valid( $request['nama_belakang'] ?? null ) ) {
        $user_data['last_name'] = sanitize_text_field( $request['nama_belakang'] );
    }
    
    // 3. Logika Password & Verifikasi Current Password
    if ( $is_valid( $request['password'] ?? null ) ) {
        $new_pass     = $request['password'];
        $confirm_pass = $request['confirm_password'] ?? '';
        
        if ( $new_pass === $confirm_pass ) {
            if ( ! $is_new_user ) {
                $current_pass_input = $request['current_password'] ?? '';
                $existing_user      = get_userdata( $user_id_input );
                
                if ( $existing_user && ! empty( $current_pass_input ) ) {
                    if ( wp_check_password( $current_pass_input, $existing_user->user_pass, $user_id_input ) ) {
                        $user_data['user_pass'] = $new_pass;
                    } else {
                    //    error_log( 'JFB Action Error: Current password salah untuk user ID: ' . $user_id_input );
						throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'Password awal salah' );
                    }
                }
            } else {
                $user_data['user_pass'] = $new_pass;
            }
        } else {
           // error_log( 'JFB Action Error: Password dan konfirmasi tidak cocok.' );
		   throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'Password dan konfirmasi tidak cocok' );
        }
    }

    // 4. Mapping Data ke Pods (TANPA 'photo', karena photo punya logika khusus)
    $pods_map = [
        'nama_depan'           => ['first_name', 'billing_first_name', 'shipping_first_name'],
        'nama_belakang'        => ['last_name', 'billing_last_name', 'shipping_last_name'],
        'email'                => ['billing_email'], 
        'angkatan'             => ['angkatan'],
        'nomor_anggota'        => ['nomor_anggota'],
        'billing_company'      => ['billing_company', 'shipping_company'],
        'billing_address_1'    => ['billing_address_1', 'shipping_address_1'],
        'billing_address_2'    => ['billing_address_2', 'shipping_address_2'],
        'city'                 => ['billing_city', 'shipping_city'],
        'state'                => ['billing_state', 'shipping_state'],
        'country'              => ['billing_country', 'shipping_country'],
        'billing_postcode'     => ['billing_postcode', 'shipping_postcode'],
        'billing_prefix_phone' => ['billing_prefix_phone', 'shipping_prefix_phone'], 
        'billing_phone'        => ['billing_phone', 'shipping_phone'],               
    ];

    $pods_data = [];
    foreach ( $pods_map as $form_key => $pod_columns ) {
        if ( $is_valid( $request[ $form_key ] ?? null ) ) {
            $value = sanitize_text_field( $request[ $form_key ] );
            foreach ( $pod_columns as $col ) {
                $pods_data[ $col ] = $value;
            }
        }
    }

    // 5. LOGIKA SUPER KETAT KHUSUS PHOTO
    // Hanya proses jika photo BENAR-BENAR string URL yang valid.
    // Jika JFB mengirim array kosong [] atau string "0", validasi ini akan MENOLAK.
    $photo_val = $request['photo'] ?? null;
    
    // Cek: Harus ada, harus string (bukan array), tidak kosong, dan bukan "0"
    if ( is_string( $photo_val ) && ! empty( $photo_val ) && $photo_val !== '0' ) {
        $clean_url = esc_url_raw( $photo_val );
        
        // Pastikan esc_url_raw menghasilkan URL yang valid (tidak kosong)
        if ( ! empty( $clean_url ) ) {
		//buat jadi webp
		$orifilepath = wp_upload_url_to_path($clean_url);
		$webpresult = create_webp($orifilepath);
		if($webpresult){
			$orifilepathwebp = $orifilepath . '.webp';
			$newpath = str_replace('jet-form-builder','profile',$orifilepathwebp);
			move_file($orifilepathwebp, $newpath);
			$clean_url = str_replace('jet-form-builder','profile',$clean_url) .'.webp';
						}
        $pods_data['photo'] = $clean_url; //aslinya				
        }
    }
    // PENTING: Jika semua kondisi di atas gagal, $pods_data['photo'] TIDAK akan diset.
    // Saat $pod->save() dipanggil, Pods tidak melihat instruksi untuk mengubah kolom photo,
    // sehingga foto profil lama user DIJAMIN TETAP ADA dan tidak berubah.

    // ==========================================
    // EKSEKUSI PENYIMPANAN
    // ==========================================

    // A. Simpan User Inti WordPress (Create / Update)
    if ( $is_new_user ) {
        if ( empty( $user_data['user_email'] ) ) return;
        if ( email_exists( $user_data['user_email'] ) )  throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'Email sudah terdaftar', 'exists' );;

        if ( empty( $user_data['user_pass'] ) ) {
            $user_data['user_pass'] = wp_generate_password( 12, true );
        }
        
        $user_data['user_login'] = $is_valid( $request['user_login'] ?? null ) 
            ? sanitize_user( $request['user_login'] ) 
            : explode('@', $user_data['user_email'])[0];
            
        $user_data['display_name'] = trim( ( $user_data['first_name'] ?? '' ) . ' ' . ( $user_data['last_name'] ?? '' ) );
        $user_data['role'] = 'unverified';

        $final_user_id = wp_insert_user( $user_data );
        if ( is_wp_error( $final_user_id ) ) {
		//return;
		throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'Gagal input user' );}
        
     //   wp_new_user_notification( $final_user_id, null, 'both' );
	 // sudah menggunakan user verification dari pickplugin

    } else {
	//cek id sesuai?
	$currentuser = get_current_user_id();
	if($currentuser !== $user_id_input){ return throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'id tidak sesuai' );}
	
        $final_user_id = $user_id_input;
        if ( $final_user_id > 0 && ! empty( $user_data ) ) {
            $user_data['ID'] = $final_user_id;
            if ( isset( $user_data['first_name'] ) || isset( $user_data['last_name'] ) ) {
                $user = get_userdata( $final_user_id );
                $fn = $user_data['first_name'] ?? $user->first_name;
                $ln = $user_data['last_name'] ?? $user->last_name;
                $user_data['display_name'] = trim( "$fn $ln" );
            }
            wp_update_user( $user_data );
        }
    }

    if ( $final_user_id === 0 ) return;

    // B. Simpan Semua Data Sisanya ke Pods (Table Storage)
    if ( ! empty( $pods_data ) ) {
        $pod = pods( $pod_name, $final_user_id );
        $pod->save( $pods_data );
    }

}, 10, 2 );


/*pickplugin
user_verification_user_registered($user_id) 
user_verification_profile_update($user_id, $old_user_data)

*/