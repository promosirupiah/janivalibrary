<?php
/**
 * Plugin Name: Pods Resi Status Row Color
 * Description: Memberi warna seluruh baris pada tabel Pods Resi berdasarkan field status: missroute = biru, lost = merah.
 * Version: 1.0.0
 * Author: Custom
 */

defined('ABSPATH') || exit;

add_action('admin_enqueue_scripts', 'pods_resi_status_row_color_enqueue');

function pods_resi_status_row_color_enqueue($hook) {
    // Hanya aktif pada halaman Manage Resi Pods.
    if (!is_admin()) {
        return;
    }

    if (empty($_GET['page']) || $_GET['page'] !== 'pods-manage-resi') {
        return;
    }

    $plugin_url = plugin_dir_url(__FILE__);

    wp_enqueue_style(
        'pods-resi-status-row-color',
        $plugin_url . 'assets/status-row-color.css',
        array(),
        '1.0.0'
    );

    wp_enqueue_script(
        'pods-resi-status-row-color',
        $plugin_url . 'assets/status-row-color.js',
        array('jquery'),
        '1.0.0',
        true
    );
}
