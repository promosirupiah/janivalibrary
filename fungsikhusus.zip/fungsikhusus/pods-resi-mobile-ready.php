<?php
/**
 * Plugin Name: Pods Resi Mobile Ready
 * Description: Membuat halaman Edit resi Pods (pods-manage-resi&action=edit) nyaman digunakan di layar HP tanpa mengubah struktur atau data Pods.
 * Version: 1.0.0
 * Author: TNA Logistics
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Pods_Resi_Mobile_Ready {

    public function __construct() {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Hanya aktif pada halaman Edit resi:
     * /admin.php?page=pods-manage-resi&action=edit
     */
    public function enqueue_assets( $hook ) {
        if ( ! is_admin() ) {
            return;
        }

        if ( ! isset( $_GET['page'] ) || 'pods-manage-resi' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
            return;
        }

        if ( ! isset( $_GET['action'] ) || 'edit' !== sanitize_key( wp_unslash( $_GET['action'] ) ) ) {
            return;
        }

        wp_enqueue_style(
            'pods-resi-mobile-ready',
            plugin_dir_url( __FILE__ ) . 'assets/mobile-ready.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'pods-resi-mobile-ready',
            plugin_dir_url( __FILE__ ) . 'assets/mobile-ready.js',
            array( 'jquery' ),
            '1.0.0',
            true
        );
    }
}

new Pods_Resi_Mobile_Ready();
