<?php
/**
 * Plugin Name: Pods Resi - Hapus Berdasarkan Tanggal
 * Description: Menghapus data Pods Advanced Content Type (ACT) "resi" berdasarkan rentang tanggal created.
 * Version: 1.0.0
 * Author: Custom
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Pods_Resi_Date_Delete {

	const PAGE_SLUG = 'pods-resi-date-delete';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_post_prdd_delete', array( $this, 'handle_delete' ) );
	}

	public function admin_menu() {
		add_management_page(
			'Hapus Pods Resi Berdasarkan Tanggal',
			'Hapus Pods Resi',
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	private function get_pods() {
		if ( ! function_exists( 'pods' ) ) {
			return false;
		}

		$pod = pods( 'resi' );

		if ( ! $pod ) {
			return false;
		}

		return $pod;
	}

	private function normalize_date( $date, $end_of_day = false ) {
		$date = trim( (string) $date );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return false;
		}

		$timestamp = strtotime( $date . ( $end_of_day ? ' 23:59:59' : ' 00:00:00' ) );

		if ( false === $timestamp ) {
			return false;
		}

		return wp_date( 'Y-m-d H:i:s', $timestamp );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Anda tidak memiliki izin.', 'prdd' ) );
		}

		$pods = $this->get_pods();
		?>
		<div class="wrap">
			<h1>Hapus Pods Resi Berdasarkan Tanggal</h1>

			<?php if ( isset( $_GET['result'] ) ) : ?>
				<?php
				$result = sanitize_key( wp_unslash( $_GET['result'] ) );
				$count  = isset( $_GET['count'] ) ? absint( $_GET['count'] ) : 0;
				?>
				<?php if ( 'success' === $result ) : ?>
					<div class="notice notice-success is-dismissible">
						<p><strong><?php echo esc_html( $count ); ?> data resi berhasil dihapus.</strong></p>
					</div>
				<?php elseif ( 'error' === $result ) : ?>
					<div class="notice notice-error is-dismissible">
						<p>Penghapusan gagal atau terjadi kesalahan.</p>
					</div>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( ! function_exists( 'pods' ) ) : ?>
				<div class="notice notice-error">
					<p><strong>Pods belum aktif.</strong> Aktifkan plugin Pods terlebih dahulu.</p>
				</div>
			<?php elseif ( ! $pods ) : ?>
				<div class="notice notice-error">
					<p><strong>Pod "resi" tidak ditemukan.</strong> Pastikan Pod <code>resi</code> adalah Advanced Content Type.</p>
				</div>
			<?php else : ?>
				<div class="card" style="max-width:760px;padding:20px;">
					<h2 style="margin-top:0;">Hapus Data Resi</h2>
					<p>
						Gunakan tanggal <strong>created</strong> sebagai dasar penghapusan.
						Tanggal awal dan akhir termasuk dalam rentang.
					</p>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="prdd_delete">
						<?php wp_nonce_field( 'prdd_delete_resi', 'prdd_nonce' ); ?>

						<table class="form-table" role="presentation">
							<tr>
								<th scope="row"><label for="prdd_start_date">Tanggal mulai</label></th>
								<td>
									<input type="date" id="prdd_start_date" name="start_date" required>
									<p class="description">Contoh: 2026-08-01</p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="prdd_end_date">Tanggal sampai</label></th>
								<td>
									<input type="date" id="prdd_end_date" name="end_date" required>
									<p class="description">Contoh: 2026-08-13. Seluruh data sampai pukul 23:59:59 akan ikut terhapus.</p>
								</td>
							</tr>
						</table>

						<div style="background:#fff3cd;border-left:4px solid #dba617;padding:12px 15px;margin:20px 0;">
							<strong>PERINGATAN:</strong>
							Penghapusan bersifat permanen dan tidak menggunakan Trash.
							Pastikan tanggal sudah benar sebelum melanjutkan.
						</div>

						<p>
							<button type="submit"
								class="button button-primary"
								onclick="return confirm('YAKIN ingin menghapus SEMUA data Pods resi pada rentang tanggal tersebut? Data yang dihapus tidak dapat dikembalikan.');">
								Hapus Data Resi
							</button>
						</p>
					</form>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function handle_delete() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Anda tidak memiliki izin.' );
		}

		if (
			! isset( $_POST['prdd_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['prdd_nonce'] ) ), 'prdd_delete_resi' )
		) {
			wp_die( 'Security check gagal.' );
		}

		$start_raw = isset( $_POST['start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['start_date'] ) ) : '';
		$end_raw   = isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : '';

		$start = $this->normalize_date( $start_raw, false );
		$end   = $this->normalize_date( $end_raw, true );

		if ( ! $start || ! $end || $start > $end ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'   => self::PAGE_SLUG,
						'result' => 'error',
					),
					admin_url( 'tools.php' )
				)
			);
			exit;
		}

		$pod = $this->get_pods();

		if ( ! $pod ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'   => self::PAGE_SLUG,
						'result' => 'error',
					),
					admin_url( 'tools.php' )
				)
			);
			exit;
		}

		/*
		 * Pods::find() digunakan agar penghapusan mengikuti API Pods,
		 * bukan menghapus tabel ACT secara langsung.
		 *
		 * "created" adalah kolom bawaan Pods yang menyimpan tanggal dibuat.
		 */
		$params = array(
			'where'   => "created >= '{$this->escape_sql( $start )}' AND created <= '{$this->escape_sql( $end )}'",
			'limit'   => -1,
			'orderby' => 'created ASC',
		);

		$items = $pod->find( $params );
		$count = 0;

		if ( $items ) {
			while ( $items->fetch() ) {
				$id = $items->id();

				if ( ! empty( $id ) ) {
					$deleted = $pod->delete( $id );

					if ( $deleted ) {
						$count++;
					}
				}
			}
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'   => self::PAGE_SLUG,
					'result' => 'success',
					'count'  => $count,
				),
				admin_url( 'tools.php' )
			)
		);
		exit;
	}

	private function escape_sql( $value ) {
		global $wpdb;

		return $wpdb->_real_escape( $value );
	}
}

new Pods_Resi_Date_Delete();
