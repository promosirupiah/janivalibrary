<?php
/**
 * Resi Customer Autofill
 *
 * Saat customer dipilih pada Pods Resi, data customer otomatis
 * mengisi alamat dan telepon pengirim/asal.
 */

defined('ABSPATH') || exit;

add_action('admin_footer', function () {
    if (!is_admin()) {
        return;
    }

    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    $action = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';
    $id = isset($_GET['id']) ? absint($_GET['id']) : 0;

    if ($page !== 'pods-manage-resi' || $action !== 'edit') {
        return;
    }

    global $wpdb;

    /*
     * Cari struktur tabel customer.
     * Prefix tn_ digunakan sesuai struktur Pods user.
     */
    $customer_table = $wpdb->prefix . 'pods_customer';

    // Ambil kolom tabel agar modul bisa menyesuaikan variasi nama field.
    $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$customer_table}`");

    if (!$columns) {
        return;
    }

    $find_col = function ($candidates) use ($columns) {
        foreach ($candidates as $candidate) {
            foreach ($columns as $column) {
                if (strtolower($column) === strtolower($candidate)) {
                    return $column;
                }
            }
        }
        return null;
    };

    $id_col = $find_col(array('id'));
    $name_col = $find_col(array('name', 'nama', 'customer', 'nama_customer'));
    $address_col = $find_col(array(
        'alamat',
        'address',
        'alamat_pengirim',
        'senderaddress',
        'sender_address'
    ));
    $phone_col = $find_col(array(
        'telepon',
        'telephone',
        'phone',
        'telp',
        'no_telp',
        'nomor_telepon',
        'telpon',
        'telp_pengirim',
        'senderphone',
        'sender_phone'
    ));

    if (!$id_col || !$name_col) {
        return;
    }

    // Ambil semua customer yang tersedia.
    $select = array(
        "`" . esc_sql($id_col) . "` AS customer_id",
        "`" . esc_sql($name_col) . "` AS customer_name",
    );

    if ($address_col) {
        $select[] = "`" . esc_sql($address_col) . "` AS customer_address";
    } else {
        $select[] = "'' AS customer_address";
    }

    if ($phone_col) {
        $select[] = "`" . esc_sql($phone_col) . "` AS customer_phone";
    } else {
        $select[] = "'' AS customer_phone";
    }

    $customers = $wpdb->get_results(
        "SELECT " . implode(', ', $select) .
        " FROM `{$customer_table}` ORDER BY `" . esc_sql($name_col) . "` ASC",
        ARRAY_A
    );

    if (!$customers) {
        return;
    }

    /*
     * Kirim data customer ke JavaScript.
     */
    ?>
    <script id="fungsikhusus-resi-customer-autofill-data">
    window.fungsikhususResiCustomers = <?php
        echo wp_json_encode($customers);
    ?>;
    </script>

    <style>
        .fungsikhusus-customer-autofill-notice {
            margin: 8px 0;
            padding: 6px 10px;
            font-size: 12px;
            background: #f0f6fc;
            border-left: 3px solid #2271b1;
        }
    </style>

    <script>
    jQuery(function ($) {
        'use strict';

        var customers = window.fungsikhususResiCustomers || [];

        if (!customers.length) {
            return;
        }

        /*
         * Cari field Pods berdasarkan nama/ID.
         * Dibuat fleksibel karena Pods dapat menghasilkan selector
         * yang berbeda tergantung konfigurasi field.
         */
        function findField(names) {
            var selectors = [];

            names.forEach(function (name) {
                selectors.push(
                    '#pods-form-ui-' + name,
                    '[name="' + name + '"]',
                    '[name="' + name + '[]"]',
                    '#field-' + name,
                    '[data-name="' + name + '"]'
                );
            });

            for (var i = 0; i < selectors.length; i++) {
                var el = $(selectors[i]).first();

                if (el.length) {
                    return el;
                }
            }

            // Coba berdasarkan label Pods.
            var found = $();
            $('label').each(function () {
                var label = $(this).text().trim().toLowerCase();

                for (var i = 0; i < names.length; i++) {
                    if (label === names[i].toLowerCase()) {
                        var forId = $(this).attr('for');

                        if (forId) {
                            found = $('#' + forId);
                        }

                        if (!found.length) {
                            found = $(this).closest('.pods-field, .form-field').find('input, textarea, select').first();
                        }

                        if (found.length) {
                            return false;
                        }
                    }
                }
            });

            return found;
        }

        /*
         * Customer biasanya merupakan field relationship Pods.
         * Ambil nilai ID dari select/input customer.
         */
        function getCustomerId() {
            var field = findField([
                'customer',
                'customer_id',
                'id_customer'
            ]);

            if (!field.length) {
                return '';
            }

            var value = field.val();

            // Relationship/select2 kadang menggunakan data selection.
            if (Array.isArray(value)) {
                value = value.length ? value[0] : '';
            }

            return String(value || '');
        }

        function setField(names, value) {
            var field = findField(names);

            if (!field.length) {
                return false;
            }

            field.val(value == null ? '' : value);

            // Beritahu Pods/jQuery/Select2 bahwa nilai berubah.
            field.trigger('input');
            field.trigger('change');

            return true;
        }

        function fillCustomerData(customerId) {
            if (!customerId) {
                return;
            }

            var customer = null;

            customers.forEach(function (item) {
                if (String(item.customer_id) === String(customerId)) {
                    customer = item;
                }
            });

            if (!customer) {
                return;
            }

            /*
             * Field tujuan:
             *
             * senderaddress / alamat asal / alamat pengirim
             * senderphone   / telepon asal / telepon pengirim
             *
             * Tambahkan variasi nama jika struktur Pods berbeda.
             */
            setField([
                'senderaddress',
                'sender_address',
                'alamat_asal',
                'alamat_pengirim',
                'asal_address',
                'origin_address'
            ], customer.customer_address);

            setField([
                'senderphone',
                'sender_phone',
                'telpon_asal',
                'telp_asal',
                'telepon_asal',
                'telpon_pengirim',
                'telp_pengirim',
                'telepon_pengirim'
            ], customer.customer_phone);
        }

        /*
         * Event normal select/input.
         */
        $(document).on(
            'change',
            '#pods-form-ui-customer, [name="customer"], [name="customer[]"], select[name*="customer"], input[name*="customer"]',
            function () {
                var value = $(this).val();

                if (Array.isArray(value)) {
                    value = value.length ? value[0] : '';
                }

                fillCustomerData(value);
            }
        );

        /*
         * Select2 pada Pods sering melakukan perubahan pada element select
         * yang tetap ditangkap oleh event change, tetapi ini membantu
         * beberapa konfigurasi Pods.
         */
        $(document).on('select2:select', '[name*="customer"], #pods-form-ui-customer', function (e) {
            var value = $(this).val();

            if (e.params && e.params.data && e.params.data.id) {
                value = e.params.data.id;
            }

            fillCustomerData(value);
        });

        /*
         * Jalankan juga saat halaman edit dibuka jika customer sudah terpilih.
         */
        setTimeout(function () {
            fillCustomerData(getCustomerId());
        }, 500);
    });
    </script>
    <?php
});
