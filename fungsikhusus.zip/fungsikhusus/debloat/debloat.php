<?php
add_action('init', function() {
    remove_action( 'wp_head', 'feed_links', 2 );
	remove_action('wp_head', 'feed_links_extra', 3);
	remove_action('wp_head', 'rsd_link');
	remove_action('wp_head', 'wlwmanifest_link');
	remove_action('wp_head', 'wp_generator');
	remove_action('wp_head', 'start_post_rel_link');
	remove_action('wp_head', 'index_rel_link');
	remove_action('wp_head', 'parent_post_rel_link', 10, 0);
	remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'rest_output_link_wp_head');
    remove_action('template_redirect', 'rest_output_link_header', 11, 0 );
    remove_action('template_redirect', 'wp_shortlink_header', 11, 0 );
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
	remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
	remove_action( 'wp_head', 'wp_oembed_add_host_js' );
	remove_action('rest_api_init', 'wp_oembed_register_route');
	remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
	remove_action( 'wp_head', 'wp_resource_hints', 2 );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    add_action('wp_default_scripts', function( $scripts ) {
        if ( !is_admin() && isset( $scripts->registered['jquery'] ) ) {
            $scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, ['jquery-migrate'] );
        }
    });
});



/// Disables Embeds
function deregister_embed_scripts() {
	wp_dequeue_script( 'wp-embed' );
	wp_deregister_script( 'wp-embed' );
}
add_action( 'wp_print_scripts', 'deregister_embed_scripts' );

//Remove the gutenberg styles
function deregister_gutenberg_styles() {
	wp_dequeue_style( 'wp-block-library' );
	wp_deregister_style( 'wp-block-library' );
}
add_action( 'wp_print_styles', 'deregister_gutenberg_styles', 100 );

//woocommerce
function dequeue_css() {
    wp_dequeue_style('wc-block-vendors-style');
    wp_deregister_style('wc-block-vendors-style');
}
add_action('wp_enqueue_scripts','dequeue_css');

//
/**
 * Removes x-powered-by header which is set by PHP
 */
header_remove('x-powered-by');

/**
 * Remove X-Pingback header
 */
add_filter('pings_open', function() {
    return false;
});

/**
 * Disables xmlrpc.php
 * Disable only if your site does not require use of xmlrpc
 */
add_filter('xmlrpc_enabled', function() {
    return false;
});

/**
 * Disables REST API completely for non-logged in users
 * Use this option only if your site does not require use of REST API
 */
// add_filter('rest_authentication_errors', function($result) {
//    return (is_user_logged_in()) ? $result : new WP_Error('rest_not_logged_in', 'You are not currently logged in.', array('status' => 401));
// });

/**
 * Disables Wordpress default REST API endpoints.
 * Use this option if your plugins require use of REST API, but would still like to disable core endpoints.
 */
add_filter('rest_endpoints', function($endpoints) {
    // If user is logged in, allow all endpoints
    if(is_user_logged_in()) {
        return $endpoints;
    }
    foreach($endpoints as $route => $endpoint) {
        if(stripos($route, '/wp/') === 0) {
            unset($endpoints[ $route ]);
        }
    }
    return $endpoints;
});

/**
 * Disable plugins auto-update email notifications
 */
add_filter( 'auto_plugin_update_send_email', function() {
    return false;
});

/**
 * Disable themes auto-update email notifications
 */
add_filter( 'auto_theme_update_send_email', function() {
    return false;
});



/**
 * List of feeds to disable
*/
$feeds = [
    'do_feed',
    'do_feed_rdf',
    'do_feed_rss',
    'do_feed_rss2',
    'do_feed_atom',
    'do_feed_rss2_comments',
    'do_feed_atom_comments',
];

foreach($feeds as $feed) {
    add_action($feed, function() {
        wp_die('Feed has been disabled.');
    }, 1);
}

/**
 * Remove wp-embed.js file from loading
 */
add_action( 'wp_footer', function() {
    wp_deregister_script('wp-embed');
});
//heartbeat
add_action( 'init', 'my_deregister_heartbeat', 1 );
function my_deregister_heartbeat() {
    global $pagenow;

    if ( 'post.php' != $pagenow && 'post-new.php' != $pagenow )
        wp_deregister_script('heartbeat');
}
//version
function _remove_script_version( $src ){
    $parts = explode( '?ver', $src );
    return $parts[0];
}
add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );