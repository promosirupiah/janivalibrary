jQuery(document).ready(function($) {

    // Preview untuk field yang sudah ada isinya (saat edit)
    $('.resi-upload-wrapper').each(function() {
        var $wrapper = $(this);
        var $input   = $wrapper.find('input[type="text"]');
        var value    = $input.val();

        if (value && isImageUrl(value)) {
            showPreview($wrapper, value);
        }
    });

    // Klik "Upload Foto" ? buka file picker
    $(document).on('click', '.resi-upload-btn', function(e) {
        e.preventDefault();
        $(this).closest('.resi-upload-wrapper').find('.resi-file-input').trigger('click');
    });

    // Klik "Hapus"
    $(document).on('click', '.resi-remove-btn', function(e) {
        e.preventDefault();
        var $w = $(this).closest('.resi-upload-wrapper');
        $w.find('input[type="text"]').val('');
        $w.find('.resi-upload-preview').empty();
        $w.find('.resi-remove-btn').hide();
        $w.find('.resi-file-input').val('');
        $w.find('.resi-upload-status').text('');
    });

    // File dipilih ? upload via AJAX
    $(document).on('change', '.resi-file-input', function() {
        var $wrapper  = $(this).closest('.resi-upload-wrapper');
        var $input    = $wrapper.find('input[type="text"]');
        var $status   = $wrapper.find('.resi-upload-status');
        var $removeBtn = $wrapper.find('.resi-remove-btn');
        var file      = this.files[0];

        if (!file) return;

        // Validasi client-side
        if (!isAllowedType(file.name)) {
            alert(ResiUploader.i18n.error_type);
            $(this).val('');
            return;
        }
        if (file.size > ResiUploader.max_size) {
            alert(ResiUploader.i18n.error_size);
            $(this).val('');
            return;
        }

        // Upload
        var formData = new FormData();
        formData.append('action', 'resi_upload_file');
        formData.append('nonce', ResiUploader.nonce);
        formData.append('file', file);

        $status.text(ResiUploader.i18n.uploading);

        $.ajax({
            url: ResiUploader.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                if (res.success) {
                    $input.val(res.data.url);
                    showPreview($wrapper, res.data.url);
                    $removeBtn.show();
                    $status.text(ResiUploader.i18n.success + ' (' + res.data.size + ')');
                    setTimeout(function() { $status.text(''); }, 3000);
                } else {
                    $status.text('');
                    alert(res.data.message || ResiUploader.i18n.error_upload);
                }
            },
            error: function() {
                $status.text('');
                alert(ResiUploader.i18n.error_upload);
            }
        });

        $(this).val('');
    });

    // --- Helpers ---

    function showPreview($wrapper, url) {
        var $preview = $wrapper.find('.resi-upload-preview');
        $preview.html(
            '<img src="' + url + '" style="max-width:200px;max-height:200px;' +
            'border:1px solid #ccc;padding:3px;background:#fff;display:block;">'
        );
        $wrapper.find('.resi-remove-btn').show();
    }

    function isImageUrl(url) {
        return /\.(jpg|jpeg|png|webp|gif)(\?.*)?$/i.test(url);
    }

    function isAllowedType(filename) {
        var ext = filename.split('.').pop().toLowerCase();
        return ResiUploader.allowed.indexOf(ext) !== -1;
    }
});