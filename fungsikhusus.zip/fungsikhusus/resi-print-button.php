<?php
/**
 * Print Resi button for Pods Resi edit page.
 *
 * URL:
 * /cetakresi.php?idresi=1
 */

defined('ABSPATH') || exit;

/**
 * Tampilkan tombol Print Resi pada:
 * admin.php?page=pods-manage-resi&action=edit&id=1
 */
add_action('admin_footer', function () {

    if (!is_admin()) {
        return;
    }

    $page = isset($_GET['page'])
        ? sanitize_key(wp_unslash($_GET['page']))
        : '';

    $action = isset($_GET['action'])
        ? sanitize_key(wp_unslash($_GET['action']))
        : '';

    $id = isset($_GET['id'])
        ? absint($_GET['id'])
        : 0;

    if ($page !== 'pods-manage-resi' || $action !== 'edit' || $id <= 0) {
        return;
    }

    // URL cetakresi.php yang berada di root website.
    $print_url = add_query_arg(
        'idresi',
        $id,
        home_url('/cetakresi.php')
    );
    ?>
    <style id="fungsikhusus-print-resi-style">
        .fungsikhusus-print-resi-button {
            display: inline-flex !important;
            align-items: center;
            gap: 6px;
            margin-left: 6px !important;
            text-decoration: none !important;
        }

        .fungsikhusus-print-resi-button .dashicons {
            line-height: 1;
        }
    </style>

    <script>
    jQuery(function ($) {
        'use strict';

        var printUrl = <?php echo wp_json_encode($print_url); ?>;

        if (!printUrl) {
            return;
        }

        var button = $('<a/>', {
            class: 'button button-primary fungsikhusus-print-resi-button',
            href: printUrl,
            target: '_blank',
            rel: 'noopener noreferrer',
            title: 'Print Resi'
        }).append(
            $('<span/>', {
                class: 'dashicons dashicons-printer'
            }),
            $('<span/>').text('Print Resi')
        );

        /*
         * Prioritas lokasi tombol:
         * 1. Area judul halaman Pods
         * 2. Tombol Add New / action area
         * 3. Setelah judul utama WordPress
         */
        var $target = $('.wrap h1.wp-heading-inline').first();

        if (!$target.length) {
            $target = $('.wrap h1').first();
        }

        if ($target.length) {
            $target.after(button);
        } else {
            $('.wrap').first().prepend(button);
        }
    });
    </script>
    <?php
});
