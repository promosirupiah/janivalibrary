<?php //shortcode wpdb start
 function custom_wpdb_query_shortcode($atts, $content = null) {
    global $wpdb;

    // Default atribut untuk key yang sudah diketahui
    $defaults = array(
        'select'    => '*',
        'from'      => '',
        'where'     => '1=1',
        'orderby'   => '',
        'limit'     => '',
        'innerjoin' => '', // Legacy single join
        'on'        => '', // Legacy single join
        'joins'     => '', // Raw SQL joins
    );

    // Merge defaults, tapi pertahankan atribut dinamis (seperti innerjoin1, on1)
    $clean_atts = shortcode_atts($defaults, $atts, 'wpdb');
    $atts = array_merge($clean_atts, (array)$atts); 

    // Helper: Menambahkan prefix tabel otomatis
    $resolve_table = function($table) use ($wpdb) {
        if (empty($table)) return '';
        if (isset($wpdb->$table)) return $wpdb->$table; // Tabel WP standar (posts, users, dll)
        if (strpos($table, $wpdb->prefix) === 0) return $table; // Sudah ada prefix
        return $wpdb->prefix . $table; // Tambahkan prefix wp_
    };

    if (empty($atts['from'])) {
        return '<!-- wpdb shortcode error: Atribut "from" wajib diisi -->';
    }

    // Mulai menyusun Query
    $query = "SELECT {$atts['select']} FROM " . $resolve_table($atts['from']);

    // --- PROSES JOIN ---
    if (!empty($atts['joins'])) {
        // METODE 1: Raw SQL (Paling fleksibel, bisa LEFT/RIGHT JOIN)
        $query .= " " . $atts['joins'];
    } else {
        // METODE 2: Multiple Numbered Joins (innerjoin1, on1, innerjoin2, on2...)
        $i = 1;
        $has_numbered_join = false;
        while (true) {
            $join_key = 'innerjoin' . $i;
            $on_key = 'on' . $i;

            if (!empty($atts[$join_key])) {
                $j_table = $resolve_table($atts[$join_key]);
                $j_on = !empty($atts[$on_key]) ? $atts[$on_key] : '1=1';
                $query .= " INNER JOIN {$j_table} ON {$j_on}";
                $has_numbered_join = true;
                $i++;
            } else {
                break;
            }
        }

        // Fallback: Legacy single innerjoin (jika tidak ada numbered join)
        if (!$has_numbered_join && !empty($atts['innerjoin'])) {
            $j_table = $resolve_table($atts['innerjoin']);
            $j_on = !empty($atts['on']) ? $atts['on'] : '1=1';
            $query .= " INNER JOIN {$j_table} ON {$j_on}";
        }
    }

    // WHERE, ORDER BY, LIMIT
    if (!empty($atts['where'])) $query .= " WHERE {$atts['where']}";
    if (!empty($atts['orderby'])) $query .= " ORDER BY {$atts['orderby']}";
    if (!empty($atts['limit'])) $query .= " LIMIT " . intval($atts['limit']);

    // Eksekusi Query
    $results = $wpdb->get_results($query, ARRAY_A);

    if (empty($results)) return '';

    // Proses Template Konten
    $output = '';
    foreach ($results as $row) {
        $row_output = $content;
        foreach ($row as $key => $value) {
            $row_output = str_replace('{' . $key . '}', esc_html($value), $row_output);
        }
        $output .= $row_output;
    }

    return $output;
}
add_shortcode('wpdb', 'custom_wpdb_query_shortcode');

/*cara pakai
[wpdb select="k.id, k.name, p.post_title, m.meta_value" 
      from="pods_karyawan k" 
      where="k.id > 0" 
      innerjoin1="posts p" on1="k.post_id = p.ID" 
      innerjoin2="postmeta m" on2="p.ID = m.post_id AND m.meta_key = '_status'"
      orderby="k.name ASC"
      limit="10"]
       ID: {id} | Nama: {name} | Judul Post: {post_title} | Status: {meta_value}

[/wpdb]
*/
function wp_upsert($table, $data, $pk = 'id') {
    global $wpdb;
    $id = isset($data[$pk]) ? $data[$pk] : null;
    $is_update = false;

    if ($id) {
        $check = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $pk = '$id'");
        if ($check > 0) {
            $is_update = true;
        }
    }

    if ($is_update) {
        $set = [];
        foreach ($data as $k => $v) {
            if ($k !== $pk) {
                $set[] = "$k = '$v'";
            }
        }
        $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE $pk = '$id'";
        $wpdb->query($sql);
        return $id;
    } else {
        $cols = array_keys($data);
        $vals = array_map(function($v) { return "'$v'"; }, array_values($data));
        $sql = "INSERT INTO $table (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
        $wpdb->query($sql);
        return $id ? $id : $wpdb->insert_id;
    }
}
/*how to use
$data = [
    'id' => 1,
    'kolom1' => 'nilai kolom 1',
    'kolom2' => 100
];

wp_upsert('nama_tabel_custom', $data);
*/