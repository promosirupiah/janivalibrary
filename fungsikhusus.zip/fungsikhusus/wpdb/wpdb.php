<?php //shortcode wpdb start
 function get_wpdb_data( $args = array() ) {
    global $wpdb;

    $defaults = array(
        'select'    => '*',
        'from'      => '',
        'where'     => '1=1',
        'orderby'   => '',
        'limit'     => '',
        'joins'     => '', // Raw SQL joins
        'innerjoin' => '', // Legacy single join
        'on'        => '', // Legacy single join
        'debug'     => false, // Jika true, akan mengembalikan array berisi 'query' dan 'results'
    );

    // Gabungkan dengan args bawaan
    $args = wp_parse_args( $args, $defaults );

    // Helper: Menambahkan prefix tabel otomatis
    $resolve_table = function($table) use ($wpdb) {
        if (empty($table)) return '';
        if (isset($wpdb->$table)) return $wpdb->$table; // Tabel WP standar
        if (strpos($table, $wpdb->prefix) === 0) return $table; // Sudah ada prefix
        return $wpdb->prefix . $table; // Tambahkan prefix wp_
    };

    if (empty($args['from'])) {
        return new WP_Error( 'missing_from', 'Parameter "from" wajib diisi.' );
    }

    // Mulai menyusun Query
    $query = "SELECT {$args['select']} FROM " . $resolve_table($args['from']);

    // --- PROSES JOIN ---
    if (!empty($args['joins'])) {
        $query .= " " . $args['joins'];
    } else {
        $i = 1;
        $has_numbered_join = false;
        while (true) {
            $join_key = 'innerjoin' . $i;
            $on_key = 'on' . $i;

            if (!empty($args[$join_key])) {
                $j_table = $resolve_table($args[$join_key]);
                $j_on = !empty($args[$on_key]) ? $args[$on_key] : '1=1';
                $query .= " INNER JOIN {$j_table} ON {$j_on}";
                $has_numbered_join = true;
                $i++;
            } else {
                break;
            }
        }

        if (!$has_numbered_join && !empty($args['innerjoin'])) {
            $j_table = $resolve_table($args['innerjoin']);
            $j_on = !empty($args['on']) ? $args['on'] : '1=1';
            $query .= " INNER JOIN {$j_table} ON {$j_on}";
        }
    }

    // WHERE, ORDER BY, LIMIT
    if (!empty($args['where'])) $query .= " WHERE {$args['where']}";
    if (!empty($args['orderby'])) $query .= " ORDER BY {$args['orderby']}";
    if (!empty($args['limit'])) $query .= " LIMIT " . intval($args['limit']);

    // Eksekusi Query
    $results = $wpdb->get_results($query, ARRAY_A);

    // --- MODE DEBUG ---
    // Jika debug aktif, kembalikan query mentah beserta hasilnya untuk inspeksi
    if ( ! empty( $args['debug'] ) ) {
        return array(
            'query'   => $query,
            'results' => $results,
            'error'   => $wpdb->last_error
        );
    }

    // Error handling standar WordPress
    if ($wpdb->last_error) {
        return new WP_Error( 'db_error', $wpdb->last_error, array( 'query' => $query ) );
    }

    return $results;
}


/**
 * SHORTCODE WRAPPER: Menggunakan fungsi inti get_wpdb_data()
 */
function custom_wpdb_query_shortcode($atts, $content = null) {
    $defaults = array(
        'select'    => '*',
        'from'      => '',
        'where'     => '1=1',
        'orderby'   => '',
        'limit'     => '',
        'innerjoin' => '', 
        'on'        => '', 
        'joins'     => '', 
    );

    $clean_atts = shortcode_atts($defaults, $atts, 'wpdb');
    $args = array_merge($clean_atts, (array)$atts); 

    // Panggil fungsi inti
    $data = get_wpdb_data($args);

    // Handle Error
    if (is_wp_error($data)) {
        return '<!-- wpdb SQL Error: ' . esc_html($data->get_error_message()) . ' -->';
    }

    if (empty($data)) return '';

    // Proses Template Konten
    $output = '';
    foreach ($data as $row) {
        $row_output = $content;
        foreach ($row as $key => $value) {
            $row_output = str_replace('{' . $key . '}', esc_html($value), $row_output);
        }
        $output .= $row_output;
    }

    return $output;
}
add_shortcode('wpdb', 'custom_wpdb_query_shortcode');

/*cara pakai
[wpdb select="k.id, k.name, p.post_title, m.meta_value" 
      from="pods_karyawan k" 
      where="k.id > 0" 
      innerjoin1="posts p" on1="k.post_id = p.ID" 
      innerjoin2="postmeta m" on2="p.ID = m.post_id AND m.meta_key = '_status'"
      orderby="k.name ASC"
      limit="10"]
       ID: {id} | Nama: {name} | Judul Post: {post_title} | Status: {meta_value}

[/wpdb]
versi php
$users = get_wpdb_data( array(
    'select' => 'p.id, p.first_name, p.last_name, p.angkatan as theangkatan',
    'from'   => 'pods_user p',
    'innerjoin1' => 'usermeta r',
    'on1'    => "r.user_id = p.id AND r.meta_key = 'is_capabilities' AND r.meta_value LIKE '%unverified%'",
    'where'  => "p.angkatan = '1996'",
    'limit'  => 10
) );
*/
function wp_upsert($table, $data, $pk = 'id') {
    global $wpdb;
    $id = isset($data[$pk]) ? $data[$pk] : null;
    $is_update = false;

    if ($id) {
        $check = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $pk = '$id'");
        if ($check > 0) {
            $is_update = true;
        }
    }

    if ($is_update) {
        $set = [];
        foreach ($data as $k => $v) {
            if ($k !== $pk) {
                $set[] = "$k = '$v'";
            }
        }
        $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE $pk = '$id'";
        $wpdb->query($sql);
        return $id;
    } else {
        $cols = array_keys($data);
        $vals = array_map(function($v) { return "'$v'"; }, array_values($data));
        $sql = "INSERT INTO $table (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
        $wpdb->query($sql);
        return $id ? $id : $wpdb->insert_id;
    }
}
/*how to use
$data = [
    'id' => 1,
    'kolom1' => 'nilai kolom 1',
    'kolom2' => 100
];

wp_upsert('nama_tabel_custom', $data);
*/


//check exist shortcode
function ifexist_shortcode($atts, $content = null) {
    $atts = shortcode_atts(array(
        'checkvalue' => '',
        'else'       => ''
    ), $atts, 'ifexist');   
    $checkvalue = trim($atts['checkvalue']);
    $else_value = $atts['else'];
    if ($content === null) {
        $content = '';
    }
    if (!empty($checkvalue)) {
        return do_shortcode($content);
    } else {
        return $else_value;
    }
}
// Register shortcode
add_shortcode('ifexist', 'ifexist_shortcode');
// [ifexist checkvalue="https://example.com/photo.jpg" else="no photo"]<img src="https://example.com/photo.jpg">[/ifexist]


//shortcode rolecontent
function tampilkan_content_berdasarkan_role($atts, $content = null) {
    $atts = shortcode_atts(array(
        'role' => '',
        'else' => ''
    ), $atts, 'rolecontent');
    if (empty($atts['role'])) {
        return '';
    }
    $current_user = wp_get_current_user();
    if (!$current_user->exists()) {
        return !empty($atts['else']) ? esc_html($atts['else']) : '';
    }
    $allowed_roles = array_map('trim', explode(',', $atts['role']));
    $user_roles = (array) $current_user->roles;
    if (!empty(array_intersect($user_roles, $allowed_roles))) {
        return do_shortcode($content);
    }
    return !empty($atts['else']) ? esc_html($atts['else']) : '';
}
add_shortcode('rolecontent', 'tampilkan_content_berdasarkan_role');
/* [rolecontent role="administrator,editor" else="konten tidak boleh dilihat"]
    <p>Konten ini hanya terlihat oleh Administrator dan Editor.</p>
[/rolecontent] */

add_shortcode('checkvalue',function($atts,$content = null){
if($atts['check'] == $atts['value']){return do_shortcode($content);};
});
//[checkvalue check={USER_FIELD} value=moderator]run shortcode[/checkvalue]

