<?php
/**
 * Plugin Name: Fungsi Khusus + Resi Uploader
 * Description: Fungsi khusus website, autocomplete Pods Resi/Customer/Kota, endpoint AJAX resi/ongkir, dan upload foto resi tanpa Media Library.
 * Version: 2.2.6
 * Author: Custom
 */

defined('ABSPATH') || exit;

/*
 * Load modules.
 */
require_once __DIR__ . '/ajax/podskota.php';
require_once __DIR__ . '/resi-uploader-module.php';
require_once __DIR__ . '/resi-fee-calculator.php';
require_once __DIR__ . '/resi-inout-layout.php';
require_once __DIR__ . '/resi-print-button.php';
require_once __DIR__ . '/resi-customer-autofill.php';

/*
 * Activation / deactivation.
 */
register_activation_hook(__FILE__, 'fungsikhusus_gabungan_add_htaccess_rules');
register_deactivation_hook(__FILE__, 'fungsikhusus_gabungan_remove_htaccess_rules');

/*
 * Perbaiki rule .htaccess sekali setelah update plugin.
 * Ini penting untuk instalasi yang sebelumnya sudah menghasilkan
 * path filesystem Windows seperti /D:/xampp81/...
 */
add_action( 'admin_init', function () {
    $version = '2.0.2';
    if ( get_option( 'fungsikhusus_gabungan_htaccess_version' ) !== $version ) {
        fungsikhusus_gabungan_add_htaccess_rules();
        update_option( 'fungsikhusus_gabungan_htaccess_version', $version, false );
    }
} );


function fungsikhusus_gabungan_get_htaccess_path() {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    return get_home_path() . '.htaccess';
}

function fungsikhusus_gabungan_rules() {
    /*
     * Gunakan URL path plugin, BUKAN filesystem path Windows.
     * Hasilnya:
     * /wp-content/plugins/fungsikhusus/ajax/ongkirajax.php
     */
    $plugin_url_path = wp_parse_url( plugin_dir_url( __FILE__ ), PHP_URL_PATH );
    $plugin_url_path = '/' . trim( $plugin_url_path, '/' );

    return implode("\n", array(
        '# BEGIN FungsiKhususAjax',
        '<IfModule mod_rewrite.c>',
        'RewriteEngine On',
        'RewriteRule ^ongkirajax.php/?$ ' . $plugin_url_path . '/ajax/ongkirajax.php [L,QSA]',
        'RewriteRule ^resiajax.php/?$ ' . $plugin_url_path . '/ajax/resiajax.php [L,QSA]',
        '</IfModule>',
        '# END FungsiKhususAjax',
    ));
}

/*
 * Hapus blok lama, termasuk blok versi plugin lama yang menunjuk
 * ke /wp-content/plugins/fungsikhusus/...
 */
function fungsikhusus_gabungan_clean_old_htaccess($htaccess) {
    $patterns = array(
        '/\s*# BEGIN FungsiKhususAjax.*?# END FungsiKhususAjax\s*/s',
    );

    foreach ($patterns as $pattern) {
        $htaccess = preg_replace($pattern, "\n\n", $htaccess);
    }

    /*
     * Bersihkan rule lama jika marker sebelumnya rusak/hilang.
     */
    $old_rules = array(
        '/^[ \t]*RewriteRule[ \t]+\^ongkirajax\.php\/\?\$[^\r\n]*\r?\n?/mi',
        '/^[ \t]*RewriteRule[ \t]+\^resiajax\.php\/\?\$[^\r\n]*\r?\n?/mi',
    );

    foreach ($old_rules as $pattern) {
        $htaccess = preg_replace($pattern, '', $htaccess);
    }

    return preg_replace("/\n{3,}/", "\n\n", $htaccess);
}

function fungsikhusus_gabungan_add_htaccess_rules() {
    $htaccess_path = fungsikhusus_gabungan_get_htaccess_path();

    if (!file_exists($htaccess_path)) {
        @file_put_contents($htaccess_path, '');
    }

    $htaccess = @file_get_contents($htaccess_path);
    if ($htaccess === false) {
        return;
    }

    $htaccess = fungsikhusus_gabungan_clean_old_htaccess($htaccess);
    $rules = fungsikhusus_gabungan_rules();

    $wordpress_marker = '# BEGIN WordPress';
    $pos = strpos($htaccess, $wordpress_marker);

    if ($pos !== false) {
        $before = substr($htaccess, 0, $pos);
        $after  = substr($htaccess, $pos);
        $htaccess = rtrim($before) . "\n\n" . $rules . "\n\n" . ltrim($after);
    } else {
        $htaccess = $rules . "\n\n" . ltrim($htaccess);
    }

    @file_put_contents($htaccess_path, $htaccess, LOCK_EX);
}

function fungsikhusus_gabungan_remove_htaccess_rules() {
    $htaccess_path = fungsikhusus_gabungan_get_htaccess_path();

    if (!file_exists($htaccess_path)) {
        return;
    }

    $htaccess = @file_get_contents($htaccess_path);
    if ($htaccess === false) {
        return;
    }

    $htaccess = fungsikhusus_gabungan_clean_old_htaccess($htaccess);
    @file_put_contents($htaccess_path, ltrim($htaccess), LOCK_EX);
}
