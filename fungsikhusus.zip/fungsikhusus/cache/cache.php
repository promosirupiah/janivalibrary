<?php
 function madxajaxcache( $eof_pattern ) {
    global $wp_super_cache_comments;
        $json_object_pattern     = '^[{].*[}]$';
        $json_collection_pattern = '^[\[].*[\]]$';
        $eof_pattern = str_replace(
            '<\?xml',
            sprintf( '<\?xml|%s|%s', $json_object_pattern, $json_collection_pattern ),
            $eof_pattern
        );
 //   $wp_super_cache_comments = false;
     return $eof_pattern;
}
add_filter( 'wp_cache_eof_tags', 'madxajaxcache' );