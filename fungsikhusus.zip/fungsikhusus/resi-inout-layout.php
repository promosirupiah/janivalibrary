<?php
/**
 * Resi Inbound / Outbond Layout
 * Menata field Inbound dan Outbond menjadi dua kolom pada form Pods Resi.
 */

defined('ABSPATH') || exit;

add_action('admin_enqueue_scripts', function ($hook) {
    if (!isset($_GET['page'])) {
        return;
    }

    $page   = sanitize_key(wp_unslash($_GET['page']));
    $action = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';

    $allowed =
        ($page === 'pods-add-new-resi') ||
        ($page === 'pods-manage-resi' && in_array($action, array('add', 'edit'), true));

    if (!$allowed) {
        return;
    }

    wp_register_script('resi-inout-layout', false, array('jquery'), '2.2.4', true);
    wp_enqueue_script('resi-inout-layout');

    $script = <<<'JS'
jQuery(function ($) {
    'use strict';

    function getRow(name) {
        var selectors = [
            '.pods-form-ui-row-name-' + name,
            '.pods-field__container.pods-form-ui-row-name-' + name,
            'tr.pods-form-ui-row-name-' + name
        ];
        var $row = $(selectors.join(',')).first();
        if (!$row.length) {
            $row = $('#pods-form-ui-pods-field-' + name).closest('tr, .pods-form-ui-row, .pods-field__container').first();
        }
        return $row;
    }

    function arrangeInboundOutbond() {
        if ($('.resi-inout-layout').length) return;

        var names = [
            'inbound-name', 'inbound-alamat', 'inbound-pic', 'inbound-telpon',
            'outbond-name', 'outbond-alamat', 'outbond-pic', 'outbond-telpon'
        ];

        // Support kemungkinan nama field tanpa tanda hubung pada bagian tertentu.
        var aliases = {
            'inbound-name': ['inbound_name', 'inbound-name'],
            'inbound-alamat': ['inbound_alamat', 'inbound-alamat'],
            'inbound-pic': ['inbound_pic', 'inbound-pic'],
            'inbound-telpon': ['inbound_telpon', 'inbound-telpon', 'inbound-telepon'],
            'outbond-name': ['outbond_name', 'outbond-name', 'outbound_name', 'outbound-name'],
            'outbond-alamat': ['outbond_alamat', 'outbond-alamat', 'outbound_alamat', 'outbound-alamat'],
            'outbond-pic': ['outbond_pic', 'outbond-pic', 'outbound_pic', 'outbound-pic'],
            'outbond-telpon': ['outbond_telpon', 'outbond-telpon', 'outbond-telepon', 'outbound_telpon', 'outbound-telpon', 'outbound-telepon']
        };

        var rows = {};
        $.each(names, function (_, key) {
            var found = $();
            $.each(aliases[key] || [key], function (_, alias) {
                if (found.length) return false;
                found = getRow(alias);
            });
            if (found.length) rows[key] = found;
        });

        // Hanya aktifkan layout jika sekurangnya pasangan Inbound/Outbond ditemukan.
        var count = Object.keys(rows).length;
        if (count < 2) return;

        var first = null;
        $.each(rows, function (_, $row) {
            if (!first || $row.index() < first.index()) first = $row;
        });
        if (!first || !first.parent().length) return;

        var $parent = first.parent();
        var $layout = $('<tbody class="resi-inout-layout" aria-label="Inbound dan Outbond"></tbody>');

        // Masukkan container tepat sebelum field pertama yang ditemukan.
        $layout.insertBefore(first);

        // Urutan dibuat berpasangan agar menjadi:
        // Inbound Name | Outbond Name
        // Inbound Alamat | Outbond Alamat
        // Inbound PIC | Outbond PIC
        // Inbound Telpon | Outbond Telpon
        var order = [
            'inbound-name', 'outbond-name',
            'inbound-alamat', 'outbond-alamat',
            'inbound-pic', 'outbond-pic',
            'inbound-telpon', 'outbond-telpon'
        ];

        $.each(order, function (i, key) {
            if (!rows[key] || !rows[key].length) return;
            rows[key].addClass('resi-inout-field-row');
            rows[key].attr('data-resi-inout-key', key);
            $layout.append(rows[key]);
        });

        // Jika ada field yang ditemukan tetapi tidak masuk order utama, tetap tampilkan.
        $.each(rows, function (key, $row) {
            if (!$row.closest('.resi-inout-layout').length) {
                $row.addClass('resi-inout-field-row resi-inout-extra');
                $layout.append($row);
            }
        });

        // Bersihkan tbody asal bila sudah kosong, tanpa mengganggu Pods.
        if (!$parent.children().length) {
            $parent.remove();
        }
    }

    function addStyle() {
        if ($('#resi-inout-layout-style').length) return;

        $('head').append(
            '<style id="resi-inout-layout-style">' +
            '.resi-inout-layout{display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;gap:0 24px!important;width:100%!important;margin:0!important;padding:0!important;border:0!important;box-sizing:border-box!important;}' +
            '.resi-inout-layout > tr.resi-inout-field-row{display:block!important;width:100%!important;margin:0!important;padding:0 0 14px!important;box-sizing:border-box!important;}' +
            '.resi-inout-layout > tr.resi-inout-field-row > th,.resi-inout-layout > tr.resi-inout-field-row > td{display:block!important;width:100%!important;box-sizing:border-box!important;padding-left:0!important;padding-right:0!important;}' +
            '.resi-inout-layout > tr.resi-inout-field-row > th{padding-bottom:5px!important;}' +
            '.resi-inout-layout > tr.resi-inout-field-row > td input,.resi-inout-layout > tr.resi-inout-field-row > td textarea,.resi-inout-layout > tr.resi-inout-field-row > td select{max-width:100%!important;width:100%!important;box-sizing:border-box!important;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(odd){grid-column:1;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(even){grid-column:2;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(1){grid-row:1;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(2){grid-row:1;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(3){grid-row:2;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(4){grid-row:2;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(5){grid-row:3;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(6){grid-row:3;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(7){grid-row:4;}' +
            '.resi-inout-layout > tr.resi-inout-field-row:nth-child(8){grid-row:4;}' +
            '.resi-inout-layout .pods-form-ui-label{margin-bottom:0!important;}' +
            '@media(max-width:782px){.resi-inout-layout{grid-template-columns:1fr!important;gap:0!important}.resi-inout-layout > tr.resi-inout-field-row{grid-column:1!important;grid-row:auto!important;}}' +
            '</style>'
        );
    }

    addStyle();

    // Pods dapat membangun ulang form setelah AJAX/tab tertentu, jadi cek beberapa kali.
    arrangeInboundOutbond();
    setTimeout(arrangeInboundOutbond, 250);
    setTimeout(arrangeInboundOutbond, 800);
    setTimeout(arrangeInboundOutbond, 1500);
});
JS;

    wp_add_inline_script('resi-inout-layout', $script);
}, 30);
