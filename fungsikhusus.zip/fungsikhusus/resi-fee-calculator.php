<?php
/**
 * Resi Fee Calculator - pure JavaScript
 *
 * Kalkulasi dilakukan di browser setelah data tarif dan daftar customer
 * Corporate dimuat satu kali dari WordPress.
 *
 * Field Pods Resi:
 * - origin_hub       = Hub Asal
 * - destination_hub  = Hub Tujuan
 * - weight            = Berat (KG)
 * - customer          = Customer
 * - fee               = Biaya
 *
 * Aturan:
 * - Berat tagihan = max(berat aktual, minimum_kg)
 * - Tarif normal = tariff_darat per kg
 * - Corporate = tarif normal - Rp1.000/kg
 * - Total Ongkir dan Total Ongkir Corporate = tarif x berat tagihan
 * - field fee mengikuti jenis customer yang dipilih.
 */

defined('ABSPATH') || exit;

add_action('admin_enqueue_scripts', function ($hook) {
    if (!isset($_GET['page'])) {
        return;
    }

    $page   = sanitize_key(wp_unslash($_GET['page']));
    $action = isset($_GET['action']) ? sanitize_key(wp_unslash($_GET['action'])) : '';

    $allowed =
        ($page === 'pods-add-new-resi') ||
        ($page === 'pods-manage-resi' && in_array($action, array('add', 'edit'), true));

    if (!$allowed) {
        return;
    }

    wp_enqueue_script(
        'resi-fee-calculator',
        plugin_dir_url(__FILE__) . 'resi-fee-calculator.js',
        array('jquery'),
        '2.2.1',
        true
    );

    global $wpdb;

    /*
     * ============================================================
     * Tarif ongkir
     * ============================================================
     * Gunakan satu tarif terendah untuk setiap kombinasi asal/kota,
     * konsisten dengan kalkulasi server sebelumnya.
     */
    $ongkir_table = $wpdb->prefix . 'pods_ongkir';
    $rates = array();

    $rows = $wpdb->get_results(
        "SELECT origin, kabupaten_kota, tariff_darat, minimum_kg, lead_time
         FROM {$ongkir_table}
         WHERE origin IS NOT NULL
           AND kabupaten_kota IS NOT NULL
         ORDER BY origin ASC, kabupaten_kota ASC, tariff_darat ASC, minimum_kg ASC",
        ARRAY_A
    );

    if (is_array($rows)) {
        foreach ($rows as $row) {
            $origin      = trim((string) ($row['origin'] ?? ''));
            $destination = trim((string) ($row['kabupaten_kota'] ?? ''));

            if ($origin === '' || $destination === '') {
                continue;
            }

            $origin_key = preg_replace('/\s+/', ' ', strtolower($origin));
            $dest_key   = preg_replace('/\s+/', ' ', strtolower($destination));
            $key        = $origin_key . '|' . $dest_key;

            $candidate = array(
                'origin'        => $origin,
                'destination'   => $destination,
                'tariff'        => (float) ($row['tariff_darat'] ?? 0),
                'minimum_kg'    => (float) ($row['minimum_kg'] ?? 0),
                'lead_time'     => (string) ($row['lead_time'] ?? ''),
            );

            if (!isset($rates[$key])) {
                $rates[$key] = $candidate;
                continue;
            }

            $existing = $rates[$key];
            if (
                $candidate['tariff'] < $existing['tariff'] ||
                (
                    $candidate['tariff'] === $existing['tariff'] &&
                    $candidate['minimum_kg'] < $existing['minimum_kg']
                )
            ) {
                $rates[$key] = $candidate;
            }
        }
    }

    /*
     * ============================================================
     * Customer Corporate
     * ============================================================
     * Hanya nama customer Corporate yang dikirim ke browser.
     * Dengan begitu data yang dilokalkan tetap kecil dan calculator
     * tidak perlu melakukan AJAX saat berat berubah.
     */
    $customer_table = $wpdb->prefix . 'pods_customer';
    $corporate_customers = array();

    $customer_rows = $wpdb->get_results(
        "SELECT name, tipe
         FROM {$customer_table}
         WHERE tipe IS NOT NULL
           AND tipe <> ''",
        ARRAY_A
    );

    if (is_array($customer_rows)) {
        foreach ($customer_rows as $row) {
            $name = trim((string) ($row['name'] ?? ''));
            $type = strtolower(trim((string) ($row['tipe'] ?? '')));

            if ($name === '' || $type === '') {
                continue;
            }

            $normalized_type = preg_replace('/[^a-z0-9]+/', '', $type);

            if (in_array($normalized_type, array('corporate', 'corporat', 'corp'), true)) {
                $name_key = preg_replace('/\s+/', ' ', strtolower($name));
                $corporate_customers[$name_key] = array(
                    'name' => $name,
                    'type' => (string) ($row['tipe'] ?? ''),
                );
            }
        }
    }

    wp_localize_script('resi-fee-calculator', 'resiFeeCalculator', array(
        'version' => '2.2.2',
        'rates' => $rates,
        'corporateCustomers' => $corporate_customers,
        'discountPerKg' => 1000,
        'fields' => array(
            'origin'      => '#pods-form-ui-pods-field-origin-hub',
            'destination' => '#pods-form-ui-pods-field-destination-hub',
            'weight'      => '#pods-form-ui-pods-field-weight',
            'customer'    => '#pods-form-ui-pods-field-customer',
            'fee'         => '#pods-form-ui-pods-field-fee',
        ),
    ));
});
