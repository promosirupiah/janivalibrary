<?php
/**
 * Plugin Name: Resi Uploader
 * Description: Upload foto resi ke folder uploads/resi/YYYY/MM/ tanpa masuk Media Library
 * Version: 1.1
 */

defined('ABSPATH') || exit;

define('RESI_UPLOAD_DIR', 'resi');
define('RESI_UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('RESI_ALLOWED_TYPES', ['jpg', 'jpeg', 'png', 'webp', 'gif']);

/**
 * Buat folder uploads/resi/YYYY/MM/ jika belum ada
 * Return: array('path' => '/full/path/', 'url' => 'https://.../uploads/resi/2026/08/')
 */
function resi_get_upload_subdir() {
    $upload = wp_upload_dir();
    $year   = date('Y');
    $month  = date('m');

    $base_dir  = trailingslashit($upload['basedir']) . RESI_UPLOAD_DIR;
    $month_dir = $base_dir . '/' . $year . '/' . $month;

    $base_url  = trailingslashit($upload['baseurl']) . RESI_UPLOAD_DIR;
    $month_url = $base_url . '/' . $year . '/' . $month;

    // Buat folder root resi/
    if (!file_exists($base_dir)) {
        wp_mkdir_p($base_dir);
        file_put_contents($base_dir . '/index.html', '<!-- Silence is golden -->');
        file_put_contents(
            $base_dir . '/.htaccess',
            "Options -Indexes\n<FilesMatch \"\\.(php|php3|phtml|phps)$\">\n  Require all denied\n</FilesMatch>"
        );
    }

    // Buat folder tahun/
    $year_dir = $base_dir . '/' . $year;
    if (!file_exists($year_dir)) {
        wp_mkdir_p($year_dir);
    }

    // Buat folder bulan/
    if (!file_exists($month_dir)) {
        wp_mkdir_p($month_dir);
        file_put_contents($month_dir . '/index.html', '<!-- Silence is golden -->');
    }

    return [
        'path' => trailingslashit($month_dir),
        'url'  => trailingslashit($month_url),
    ];
}

/**
 * Enqueue script di halaman admin Pods
 */
add_action('admin_enqueue_scripts', 'resi_uploader_enqueue');

function resi_uploader_enqueue($hook) {
    if (strpos($hook, 'pods') === false) {
        return;
    }

    wp_enqueue_script(
        'resi-uploader-js',
        plugin_dir_url(__FILE__) . 'resi-uploader.js',
        ['jquery'],
        '1.1',
        true
    );

    wp_localize_script('resi-uploader-js', 'ResiUploader', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('resi_upload_nonce'),
        'max_size' => RESI_UPLOAD_MAX_SIZE,
        'allowed'  => RESI_ALLOWED_TYPES,
        'i18n'     => [
            'uploading'    => 'Mengupload...',
            'error_type'   => 'Tipe file tidak diizinkan. Gunakan: jpg, jpeg, png, webp, gif',
            'error_size'   => 'Ukuran file terlalu besar (maks 5MB)',
            'error_upload' => 'Gagal upload file',
            'success'      => 'Upload berhasil',
        ],
    ]);
}

/**
 * Ubah field text 'foto' menjadi area upload
 */
add_filter('pods_form_ui_field_text', 'resi_inject_upload_button', 10, 5);

function resi_inject_upload_button($output, $name, $value, $options, $pod) {
    if ($name !== 'foto') {
        return $output;
    }

    $html  = '<div class="resi-upload-wrapper">';
    $html .= $output;
    $html .= '<div class="resi-upload-actions" style="margin-top:6px;">';
    $html .= '<button type="button" class="button resi-upload-btn">';
    $html .= '<span class="dashicons dashicons-upload" style="vertical-align:middle;margin-right:4px;"></span>';
    $html .= 'Upload Foto</button>';
    $html .= '<button type="button" class="button resi-remove-btn" style="display:none;margin-left:5px;">Hapus</button>';
    $html .= '<input type="file" class="resi-file-input" accept="image/*" style="display:none;">';
    $html .= '</div>';
    $html .= '<div class="resi-upload-preview" style="margin-top:8px;"></div>';
    $html .= '<div class="resi-upload-status" style="margin-top:5px;font-size:12px;color:#666;"></div>';
    $html .= '</div>';

    return $html;
}

/**
 * Handle AJAX upload
 */
add_action('wp_ajax_resi_upload_file', 'resi_handle_upload');

function resi_handle_upload() {
    // Nonce
 /*   if (!check_ajax_referer('resi_upload_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'Invalid nonce']);
    }

    // Permission
    if (!current_user_can('upload_files')) {
        wp_send_json_error(['message' => 'Unauthorized']);
    }
*/
    // File check
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $err = $_FILES['file']['error'] ?? -1;
        wp_send_json_error(['message' => 'Upload error code: ' . $err]);
    }

    $file = $_FILES['file'];

    // Size
    if ($file['size'] > RESI_UPLOAD_MAX_SIZE) {
        wp_send_json_error(['message' => 'File terlalu besar (maks 5MB)']);
    }

    // Extension
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, RESI_ALLOWED_TYPES, true)) {
        wp_send_json_error(['message' => 'Tipe file tidak diizinkan']);
    }

    // MIME
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed_mimes = [
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'webp' => 'image/webp',
        'gif'  => 'image/gif',
    ];

    if (!isset($allowed_mimes[$ext]) || $mime !== $allowed_mimes[$ext]) {
        wp_send_json_error(['message' => 'MIME type tidak valid']);
    }

    // Get subdirectory (YYYY/MM)
    $dir = resi_get_upload_subdir();

    // Generate filename
    $filename = 'resi-' . time() . '-' . wp_generate_password(6, false) . '.' . $ext;
    $filepath = $dir['path'] . $filename;

    // Prevent overwrite
    $counter = 1;
    while (file_exists($filepath)) {
        $filename = 'resi-' . time() . '-' . wp_generate_password(6, false) . '-' . $counter . '.' . $ext;
        $filepath = $dir['path'] . $filename;
        $counter++;
    }

    // Move file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        wp_send_json_error(['message' => 'Gagal menyimpan file']);
    }

    // Set permission
    chmod($filepath, 0644);

    // Build URL
    $file_url = $dir['url'] . $filename;

    wp_send_json_success([
        'url'      => $file_url,
        'filename' => $filename,
        'size'     => size_format($file['size']),
        'path'     => str_replace(ABSPATH, '', $filepath),
    ]);
}

/**
 * (Opsional) Hapus file lama saat field foto diganti
 * Uncomment block ini jika ingin auto-cleanup
 */
/*
add_filter('pods_api_pre_save_pod_item_resi', 'resi_cleanup_old_file', 10, 2);

function resi_cleanup_old_file($pieces, $pod) {
    if (empty($pieces['fields']['foto'])) {
        return $pieces;
    }

    $new_url = $pieces['fields']['foto'];
    $pod_id  = $pod->id();

    if (!$pod_id) {
        return $pieces;
    }

    $old_pod = pods('resi', $pod_id);
    $old_url = $old_pod->field('foto');

    if ($old_url && $old_url !== $new_url && strpos($old_url, '/' . RESI_UPLOAD_DIR . '/') !== false) {
        $upload = wp_upload_dir();
        $old_path = str_replace(
            trailingslashit($upload['baseurl']),
            trailingslashit($upload['basedir']),
            $old_url
        );
        if (file_exists($old_path)) {
            @unlink($old_path);
        }
    }

    return $pieces;
}
*/