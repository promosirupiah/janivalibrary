<?php
function custom_jet_get_item_value( $item, $key ) {
    // 1. Handle Dot Notation (misal: {meta_data.harga})
    if ( strpos( $key, '.' ) !== false ) {
        $keys = explode( '.', $key );
        $value = $item;
        foreach ( $keys as $k ) {
            if ( is_array( $value ) && isset( $value[ $k ] ) ) {
                $value = $value[ $k ];
            } elseif ( is_object( $value ) && isset( $value->$k ) ) {
                $value = $value->$k;
            } else {
                return ''; // Key tidak ditemukan
            }
        }
        return $value;
    }

    // 2. Jika item adalah Array (Umum untuk Custom SQL / CCT tertentu)
    if ( is_array( $item ) ) {
        return isset( $item[ $key ] ) ? $item[ $key ] : '';
    }
    // 3. Jika item adalah Object (WP_Post, WP_Term, WP_User, CCT Object, stdClass dari MySQL)
    if ( is_object( $item ) ) {
        // Cek properti langsung
        if ( isset( $item->$key ) ) {
            return $item->$key;
        }

        // Fallback ke Meta untuk tipe data standar WordPress
        if ( $item instanceof WP_Post ) {
            $meta = get_post_meta( $item->ID, $key, true );
            return ( $meta !== '' ) ? $meta : '';
        }

        if ( $item instanceof WP_Term ) {
            $meta = get_term_meta( $item->term_id, $key, true );
            return ( $meta !== '' ) ? $meta : '';
        }

        if ( $item instanceof WP_User ) {
            $meta = get_user_meta( $item->ID, $key, true );
            return ( $meta !== '' ) ? $meta : '';
        }
        
        // Fallback untuk ArrayAccess (kadang digunakan oleh beberapa object CCT)
        if ( $item instanceof ArrayAccess && isset( $item[ $key ] ) ) {
            return $item[ $key ];
        }
    }

    return '';
}

/**
 * Callback function untuk Shortcode [jetengineitem]
 */
function custom_jetengine_item_shortcode( $atts, $content = null ) {
    // Pastikan kita berada di dalam loop JetEngine Listing
    if ( ! function_exists( 'jet_engine' ) || ! jet_engine()->listings->data->get_current_object() ) {
        return ''; 
    }

    // 1. Ambil object/array saat ini di dalam loop
    $current_item = jet_engine()->listings->data->get_current_object();

    if ( ! $current_item ) {
        return '';
    }

    // 2. Cari semua placeholder dengan format {key} atau {nested.key}
    // Regex ini mencocokkan huruf, angka, underscore, titik, dan strip
    $content = preg_replace_callback( '/\{([a-zA-Z0-9_.\-]+)\}/', function( $matches ) use ( $current_item ) {
        $key   = $matches[1];
        $value = custom_jet_get_item_value( $current_item, $key );

        // Jika nilai yang dikembalikan adalah array atau object (misal field gambar CCT atau JSON), 
        // kita ubah ke JSON string agar tidak error "Array to string conversion"
        if ( is_array( $value ) || is_object( $value ) ) {
            return wp_json_encode( $value );
        }

        // Kembalikan nilai mentah (tanpa esc_html agar bisa digunakan untuk URL/HTML jika perlu)
        // Jika ingin aman dari XSS, ubah menjadi: return esc_html( $value );
        return (string) $value; 
    }, $content );

    return $content;
}

// 3. Daftarkan Shortcode
add_shortcode( 'jetengineitem', 'custom_jetengine_item_shortcode' );