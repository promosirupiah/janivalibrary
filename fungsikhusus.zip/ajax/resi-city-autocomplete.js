jQuery(function ($) {
    'use strict';

    if (typeof resiAutocomplete === 'undefined') {
        return;
    }

    var config = resiAutocomplete;

    var fields = {
        origin: '#pods-form-ui-pods-field-origin-hub',
        destination: '#pods-form-ui-pods-field-destination-hub'
    };

    var ongkirAjaxUrl = '/ongkirajax.php';
    var activeRequests = {};
    var fieldState = {};

    function escapeHtml(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function debounce(fn, delay) {
        var timer;
        return function () {
            var args = arguments;
            var self = this;
            clearTimeout(timer);
            timer = setTimeout(function () {
                fn.apply(self, args);
            }, delay || 300);
        };
    }

    function addStyle() {
        if ($('#resi-autocomplete-style').length) return;

        $('head').append(
            '<style id="resi-autocomplete-style">' +
            '.resi-original-hidden{position:absolute!important;left:-9999px!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important;}' +
            '.resi-autocomplete-wrap{position:relative;width:100%;}' +
            '.resi-autocomplete-input{width:100%!important;box-sizing:border-box;}' +
            '.resi-autocomplete-list{position:absolute;z-index:999999;left:0;right:0;top:calc(100% + 2px);display:none;max-height:280px;overflow-y:auto;background:#fff;border:1px solid #c3c4c7;border-radius:6px;box-shadow:0 4px 12px rgba(0,0,0,.12);padding:4px 0;}' +
            '.resi-autocomplete-list.show{display:block;}' +
            '.resi-autocomplete-item{padding:9px 11px;cursor:pointer;font-size:13px;line-height:1.35;color:#1d2327;}' +
            '.resi-autocomplete-item:hover,.resi-autocomplete-item.active{background:#f0f6fc;color:#135e96;}' +
            '.resi-autocomplete-item small{display:block;margin-top:2px;color:#646970;font-size:11px;}' +
            '.resi-autocomplete-status{padding:9px 11px;color:#646970;font-size:13px;}' +
            '.resi-autocomplete-clear{position:absolute;right:7px;top:50%;transform:translateY(-50%);border:0;background:transparent;color:#787c82;cursor:pointer;font-size:20px;line-height:1;padding:2px 5px;display:none;}' +
            '.resi-autocomplete-wrap.has-value .resi-autocomplete-clear{display:block;}' +
            '.resi-autocomplete-wrap.has-value .resi-autocomplete-input{padding-right:32px;}' +
            '#resi-ongkir-info{margin-top:12px;margin-bottom:15px;padding:12px 15px;border:1px solid #dcdcde;border-radius:6px;background:#f6f7f7;font-size:14px;line-height:1.6;}' +
            '#resi-ongkir-info .resi-ongkir-title{font-weight:600;margin-bottom:5px;}' +
            '#resi-ongkir-info .resi-ongkir-price{font-size:20px;font-weight:700;line-height:1.4;}' +
            '#resi-ongkir-info .resi-ongkir-detail{margin-top:5px;font-size:13px;color:#50575e;}' +
            '#resi-ongkir-info.resi-loading{opacity:.7}' +
            '#resi-ongkir-info.resi-error{border-color:#d63638;background:#fcf0f1;color:#8a1f1f}' +
            '#resi-ongkir-info.resi-success{border-color:#8ed1b2;background:#f0fff7}' +
            '@media(max-width:600px){.resi-autocomplete-list{max-height:240px}.resi-autocomplete-item{padding:10px 11px}}' +
            '</style>'
        );
    }

    function getValue(selector) {
        var $field = $(selector);
        return $field.length ? $.trim($field.val() || '') : '';
    }

    function getOngkirContainer() {
        var $container = $('#resi-ongkir-info');

        if (!$container.length) {
            $container = $('<div id="resi-ongkir-info" class="resi-ongkir-info"></div>');
            var $dest = $(fields.destination);
            var $row = $dest.closest('.pods-field, .form-group, .pods-field-container, .pods-form-ui-row').first();
            if ($row.length) {
                $row.after($container);
            } else {
                $dest.after($container);
            }
        }

        return $container;
    }

    function showOngkirMessage(message, type) {
        getOngkirContainer()
            .removeClass('resi-loading resi-error resi-success')
            .addClass(type ? 'resi-' + type : '')
            .html(message)
            .show();
    }

    function resetOngkir() {
        getOngkirContainer().removeClass('resi-loading resi-error resi-success').empty().hide();
    }

    function formatRupiah(value) {
        if (value === null || value === undefined || value === '') return '-';
        value = String(value).replace(/[^\d]/g, '');
        return value ? 'Rp' + value.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : '-';
    }

    function displayOngkir(row) {
        if (!row) {
            showOngkirMessage('<div class="resi-ongkir-title">Harga Ongkir</div><div>Data harga tidak ditemukan.</div>', 'error');
            return;
        }

        var minTarif = row.min_tarif;
        var maxTarif = row.max_tarif;
        var minKg = row.min_kg;
        var maxKg = row.max_kg;
        var leadTime = row.lead_time || '';

        var price = (minTarif != null && maxTarif != null && String(minTarif) === String(maxTarif))
            ? formatRupiah(minTarif)
            : formatRupiah(minTarif) + ' - ' + formatRupiah(maxTarif);

        var detail = '';
        if (minKg !== null && minKg !== undefined && minKg !== '') {
            detail += '<div>' +
                (maxKg !== null && maxKg !== undefined && maxKg !== '' && String(minKg) !== String(maxKg)
                    ? 'Minimum: ' + escapeHtml(minKg) + ' - ' + escapeHtml(maxKg) + ' kg'
                    : 'Minimum: ' + escapeHtml(minKg) + ' kg') +
                '</div>';
        }
        if (leadTime !== '') {
            detail += '<div>Lead Time: ' + escapeHtml(leadTime) + '</div>';
        }

        showOngkirMessage(
            '<div class="resi-ongkir-title">Harga Ongkir</div>' +
            '<div class="resi-ongkir-price">' + price + '</div>' +
            (detail ? '<div class="resi-ongkir-detail">' + detail + '</div>' : ''),
            'success'
        );
    }

    var ongkirRequest = null;
    var lastOngkirKey = '';

    function loadOngkir(force) {
        var asal = getValue(fields.origin);
        var kota = getValue(fields.destination);

        if (!asal || !kota) {
            lastOngkirKey = '';
            resetOngkir();
            return;
        }

        var requestKey = asal + '|' + kota;
        if (!force && requestKey === lastOngkirKey) return;
        lastOngkirKey = requestKey;

        if (ongkirRequest && ongkirRequest.readyState !== 4) ongkirRequest.abort();

        showOngkirMessage('<div class="resi-ongkir-title">Harga Ongkir</div><div>Mengambil harga ongkir...</div>', 'loading');

        ongkirRequest = $.ajax({
            url: ongkirAjaxUrl,
            method: 'GET',
            dataType: 'json',
            cache: true,
            data: { action: 'get_data_ongkir', asal: asal, kota: kota }
        });

        ongkirRequest.done(function (response) {
            if (requestKey !== getValue(fields.origin) + '|' + getValue(fields.destination)) return;

            if (!response || response.success !== true || !response.data) {
                showOngkirMessage(
                    '<div class="resi-ongkir-title">Harga Ongkir</div><div>' +
                    escapeHtml(response && response.message ? response.message : 'Data ongkir tidak ditemukan.') +
                    '</div>', 'error'
                );
                return;
            }

            if (response.data.mode === 'kota' && response.data.row) {
                displayOngkir(response.data.row);
                return;
            }

            if (response.data.mode === 'kecamatan' && response.data.rows && response.data.rows.length) {
                var rows = response.data.rows;
                var tariffs = [], minimums = [], leadTimes = [];

                $.each(rows, function (_, row) {
                    if (row.tariff_darat !== null && row.tariff_darat !== undefined && row.tariff_darat !== '') tariffs.push(parseFloat(row.tariff_darat));
                    if (row.minimum_kg !== null && row.minimum_kg !== undefined && row.minimum_kg !== '') minimums.push(parseFloat(row.minimum_kg));
                    if (row.lead_time !== null && row.lead_time !== undefined && row.lead_time !== '' && $.inArray(String(row.lead_time), leadTimes) === -1) leadTimes.push(String(row.lead_time));
                });

                if (!tariffs.length) {
                    showOngkirMessage('<div class="resi-ongkir-title">Harga Ongkir</div><div>Tarif tidak tersedia.</div>', 'error');
                    return;
                }

                tariffs.sort(function (a, b) { return a - b; });
                displayOngkir({
                    min_tarif: tariffs[0],
                    max_tarif: tariffs[tariffs.length - 1],
                    min_kg: minimums.length ? Math.min.apply(null, minimums) : '',
                    max_kg: minimums.length ? Math.max.apply(null, minimums) : '',
                    lead_time: leadTimes.join(', ')
                });
                return;
            }

            showOngkirMessage('<div class="resi-ongkir-title">Harga Ongkir</div><div>Format data ongkir tidak dikenali.</div>', 'error');
        });

        ongkirRequest.fail(function (xhr, status) {
            if (status === 'abort') return;
            lastOngkirKey = '';
            var message = xhr && xhr.responseJSON && xhr.responseJSON.message
                ? xhr.responseJSON.message
                : 'Gagal mengambil data harga ongkir.';
            showOngkirMessage('<div class="resi-ongkir-title">Harga Ongkir</div><div>' + escapeHtml(message) + '</div>', 'error');
        });
    }

    function closeList(state) {
        state.$list.removeClass('show').empty();
        state.index = -1;
    }

    function renderStatus(state, text) {
        state.$list.html('<div class="resi-autocomplete-status">' + escapeHtml(text) + '</div>').addClass('show');
    }

    function renderItems(state, items) {
        state.items = items || [];
        state.index = -1;
        state.$list.empty();

        if (!state.items.length) {
            renderStatus(state, 'Kota tidak ditemukan.');
            return;
        }

        $.each(state.items, function (i, item) {
            var value = item && item.value != null ? String(item.value) : '';
            var label = item && item.label != null ? String(item.label) : value;
            if (!value) return;

            var $item = $('<div>', {
                'class': 'resi-autocomplete-item',
                'data-index': i,
                'role': 'option'
            }).text(label);

            if (label !== value) $('<small>').text(value).appendTo($item);

            state.$list.append($item);
        });

        state.$list.addClass('show');
    }

    function setActive(state, index) {
        var count = state.items.length;
        if (!count) return;

        state.index = index;
        state.$list.children('.resi-autocomplete-item').removeClass('active').eq(index).addClass('active');

        var el = state.$list.children('.resi-autocomplete-item').get(index);
        if (el) el.scrollIntoView({ block: 'nearest' });
    }

    function selectItem(state, item) {
        if (!item) return;

        var value = item.value != null ? String(item.value) : String(item.label || '');
        state.$original.val(value).trigger('input').trigger('change');
        state.$input.val(item.label != null ? String(item.label) : value);
        state.$wrap.addClass('has-value');
        state.selected = value;
        closeList(state);

        if (state.key === 'origin' || state.key === 'destination') {
            loadOngkir(true);
        }
    }

    function searchCity(state, keyword) {
        keyword = $.trim(keyword || '');

        if (activeRequests[state.key] && activeRequests[state.key].readyState !== 4) {
            activeRequests[state.key].abort();
        }

        if (keyword.length < 1) {
            closeList(state);
            return;
        }

        renderStatus(state, 'Mencari kota...');

        // Simpan ID request yang benar. Request lama tidak boleh menimpa hasil terbaru.
        var requestId = ++state.latestRequest;

        activeRequests[state.key] = $.ajax({
            url: config.ajaxUrl,
            type: 'GET',
            dataType: 'json',
            data: { term: keyword },
            cache: true
        }).done(function (data) {
            if (requestId !== state.latestRequest) return;
            renderItems(state, Array.isArray(data) ? data : []);
        }).fail(function (xhr, status) {
            if (status === 'abort') return;
            renderStatus(state, 'Gagal mengambil daftar kota.');
        });
    }

    function prepareField(key, selector) {
        var $original = $(selector);
        if (!$original.length || $original.data('resiAutocompleteReady')) return;

        var initial = $.trim($original.val() || '');
        var $wrap = $('<div class="resi-autocomplete-wrap"></div>');
        var $input = $('<input type="text" class="resi-autocomplete-input" autocomplete="off">');
        var $list = $('<div class="resi-autocomplete-list" role="listbox"></div>');
        var $clear = $('<button type="button" class="resi-autocomplete-clear" aria-label="Hapus">&times;</button>');

        var placeholder = key === 'origin' ? 'Ketik kota asal...' : 'Ketik kota tujuan...';
        $input.attr('placeholder', placeholder).val(initial);

        $original.addClass('resi-original-hidden');
        $original.after($wrap);
        $wrap.append($input, $clear, $list);

        var state = {
            key: key,
            $original: $original,
            $wrap: $wrap,
            $input: $input,
            $list: $list,
            $clear: $clear,
            items: [],
            index: -1,
            selected: initial,
            latestRequest: 0
        };

        fieldState[key] = state;
        $original.data('resiAutocompleteReady', true);

        var doSearch = debounce(function () {
            searchCity(state, state.$input.val());
        }, 250);

        $input.on('input', function () {
            var text = $.trim($input.val());
            state.selected = '';

            $original.val(text).trigger('input');
            $wrap.toggleClass('has-value', !!text);

            doSearch();
        });

        $input.on('focus', function () {
            if ($.trim($input.val()).length) doSearch();
        });

        $input.on('keydown', function (e) {
            if (!$list.hasClass('show')) return;

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setActive(state, state.index < state.items.length - 1 ? state.index + 1 : 0);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setActive(state, state.index > 0 ? state.index - 1 : state.items.length - 1);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (state.index >= 0) {
                    selectItem(state, state.items[state.index]);
                } else if (state.items.length === 1) {
                    selectItem(state, state.items[0]);
                }
            } else if (e.key === 'Escape') {
                closeList(state);
            }
        });

        $list.on('mousedown', '.resi-autocomplete-item', function (e) {
            e.preventDefault();
            var index = parseInt($(this).attr('data-index'), 10);
            selectItem(state, state.items[index]);
        });

        $clear.on('click', function () {
            if (activeRequests[key] && activeRequests[key].readyState !== 4) activeRequests[key].abort();
            $input.val('');
            $original.val('').trigger('input').trigger('change');
            state.selected = '';
            closeList(state);
            $wrap.removeClass('has-value');
            $input.focus();
            loadOngkir(true);
        });

        $original.on('change', function () {
            if (!$.trim($input.val())) $input.val($.trim($original.val() || ''));
            loadOngkir(true);
        });

        if (initial) $wrap.addClass('has-value');
    }

    addStyle();
    prepareField('origin', fields.origin);
    prepareField('destination', fields.destination);

    setTimeout(function () {
        loadOngkir(false);
    }, 400);

    var attempts = 0;
    var timer = setInterval(function () {
        attempts++;
        prepareField('origin', fields.origin);
        prepareField('destination', fields.destination);
        if (attempts >= 30) clearInterval(timer);
    }, 250);

    $(document).on('click.resiCityAutocomplete', function (e) {
        $.each(fieldState, function (_, state) {
            if (state.$wrap && !state.$wrap[0].contains(e.target)) closeList(state);
        });
    });
});
