<?php
/**
 * Load Select2 + autocomplete Customer/Kota hanya pada halaman Resi Pods.
 */
add_action( 'admin_enqueue_scripts', function ( $hook ) {

    if ( ! isset( $_GET['page'] ) ) {
        return;
    }

    $page   = sanitize_key( wp_unslash( $_GET['page'] ) );
    $action = isset( $_GET['action'] )
        ? sanitize_key( wp_unslash( $_GET['action'] ) )
        : '';

    /*
     * Halaman yang dipakai Pods:
     * - pods-add-new-resi
     * - pods-manage-resi?action=add
     * - pods-manage-resi?action=edit
     */
    $allowed =
        ( $page === 'pods-add-new-resi' ) ||
        ( $page === 'pods-manage-resi' && in_array( $action, array( 'add', 'edit' ), true ) );

    if ( ! $allowed ) {
        return;
    }

    /*
     * Select2.
     * jQuery sudah tersedia di wp-admin.
     */
    wp_enqueue_style(
        'fungsikhusus-select2',
        'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
        array(),
        '4.1.0-rc.0'
    );

    wp_enqueue_script(
        'fungsikhusus-select2',
        'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js',
        array( 'jquery' ),
        '4.1.0-rc.0',
        true
    );

    /*
     * JS customer.
     */
    wp_enqueue_script(
        'resi-customer-autocomplete',
        plugin_dir_url( __FILE__ ) . 'resi-customer-autocomplete.js',
        array( 'jquery', 'fungsikhusus-select2' ),
        '1.0.0',
        true
    );

    wp_localize_script(
        'resi-customer-autocomplete',
        'resiCustomerAutocomplete',
        array(
            'ajaxUrl' => home_url( '/resiajax.php' ),
            'field' => array(
                'selector' => '#pods-form-ui-pods-field-customer',
                'name'     => 'pods_field_customer',
            ),

            'i18n' => array(
                'searching' => 'Mencari customer...',
                'noResults' => 'Customer tidak ditemukan.',
                'error'     => 'Gagal mengambil data customer.',
                'placeholder' => 'Ketik nama, perusahaan, kontak, atau telepon...',
            ),
        )
    );

    /*
     * File JS kota yang sudah ada tetap dimuat.
     */
    wp_enqueue_script(
        'resi-city-autocomplete',
        plugin_dir_url( __FILE__ ) . 'resi-city-autocomplete.js',
        array( 'jquery', 'fungsikhusus-select2' ),
        '1.1',
        true
    );

    wp_localize_script(
        'resi-city-autocomplete',
        'resiAutocomplete',
        array(
            'ajaxUrl' => plugin_dir_url( __FILE__ ) . 'resi-search-cities.php',
        )
    );
} );
