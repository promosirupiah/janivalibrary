<?php
/**
 * Endpoint autocomplete kota (Sangat Ringan dengan Pre-Cache Check)
 */

// 1. Header JSON & Validasi Request Dasar (Murni PHP, tanpa WP)
header( 'Content-Type: application/json; charset=UTF-8' );

/*
if ( empty( $_SERVER['HTTP_X_REQUESTED_WITH'] )
    || strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) !== 'xmlhttprequest' ) {
    echo json_encode( array() );
    exit;
}
*/

$term = isset( $_GET['term'] ) ? $_GET['term'] : '';

// mb_strlen adalah fungsi native PHP, aman digunakan sebelum load WP

/*
if ( mb_strlen( $term ) < 2 ) {
    echo json_encode( array() );
    exit;
}
*/

// 2. Setup Path Cache
// File ini berada di: wp-content/plugins/fungsikhusus/ajax/resi-search-cities.php
// dirname(__DIR__, 3) akan mundur 3 level ke folder: wp-content/
$base_cache_dir = dirname( __DIR__, 3 ) . '/geo';
$target_folder  = 'autocomplete_cache';
$target_name    = 'resi_cities';

$dirPath       = $base_cache_dir . '/' . $target_folder . '/' . $target_name;
$filename_only = md5( $_SERVER['REQUEST_URI'] ) . '.txt'; // Hash dari URL + parameter
$filename      = $dirPath . '/' . $filename_only;

$ttl = -1; // 1 Hari (Data kota sangat statis)

// 3. PRE-CACHE CHECK: Jika cache ada, langsung baca dan EXIT (TANPA load WP!)
if ( file_exists( $filename ) ) {
    if ( $ttl === -1 || ( time() - filemtime( $filename ) < $ttl ) ) {
        readfile( $filename );
        exit; // Berhenti di sini. Sangat cepat!
    }
}

// ==========================================
// CACHE MISS! Baru aktifkan mode ringan WordPress
// ==========================================

define( 'SHORTINIT', true );

$wp_load = dirname( __DIR__, 4 ) . '/wp-load.php';
if ( ! file_exists( $wp_load ) ) {
    status_header( 500 );
    exit( json_encode( array( 'error' => 'wp-load.php tidak ditemukan' ) ) );
}
require_once $wp_load;

// 4. Buat Folder Cache Jika Belum Ada
if ( ! is_dir( $dirPath ) ) {
    mkdir( $dirPath, 0755, true );
}

// 5. Eksekusi Query Database
global $wpdb;
$table = $wpdb->prefix . 'cities';

// sanitize_text_field() adalah fungsi WP, jadi baru bisa dipanggil di sini
$term_clean = sanitize_text_field( $term ); 
$like = '%' . $wpdb->esc_like( $term_clean ) . '%';

$rows = $wpdb->get_results( $wpdb->prepare(
    "SELECT id, name, state_code
     FROM {$table}
     WHERE name LIKE %s
     ORDER BY name ASC
     LIMIT 15",
    $like
) );

$output = array();
foreach ( $rows as $row ) {
    $output[] = array(
        'id'    => (int) $row->id,
        'label' => $row->name,
        'value' => $row->name,
    );
}

$json_output = json_encode( $output );

// 6. Simpan ke Cache dan Tampilkan
@file_put_contents( $filename, $json_output );
echo $json_output;
exit;