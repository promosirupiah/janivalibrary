jQuery(function ($) {
    'use strict';

    if (typeof resiCustomerAutocomplete === 'undefined') return;

    var config = resiCustomerAutocomplete;
    var selector = config.field.selector;
    var state = null;
    var request = null;
    var latestRequest = 0;

    function escapeHtml(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function debounce(fn, delay) {
        var timer;
        return function () {
            var args = arguments;
            var self = this;
            clearTimeout(timer);
            timer = setTimeout(function () {
                fn.apply(self, args);
            }, delay || 300);
        };
    }

    function addStyle() {
        if ($('#resi-customer-autocomplete-style').length) return;

        $('head').append(
            '<style id="resi-customer-autocomplete-style">' +
            '.resi-customer-original-hidden{position:absolute!important;left:-9999px!important;width:1px!important;height:1px!important;opacity:0!important;pointer-events:none!important;}' +
            '.resi-customer-autocomplete-wrap{position:relative;width:100%;}' +
            '.resi-customer-autocomplete-input{width:100%!important;box-sizing:border-box;}' +
            '.resi-customer-autocomplete-list{position:absolute;z-index:999999;left:0;right:0;top:calc(100% + 2px);display:none;max-height:320px;overflow-y:auto;background:#fff;border:1px solid #c3c4c7;border-radius:6px;box-shadow:0 4px 12px rgba(0,0,0,.12);padding:4px 0;}' +
            '.resi-customer-autocomplete-list.show{display:block;}' +
            '.resi-customer-option{padding:9px 11px;cursor:pointer;line-height:1.35;border-bottom:1px solid #f0f0f1;}' +
            '.resi-customer-option:last-child{border-bottom:0;}' +
            '.resi-customer-option:hover,.resi-customer-option.active{background:#f0f6fc;}' +
            '.resi-customer-name{font-weight:600;color:#1d2327;}' +
            '.resi-customer-meta{margin-top:3px;font-size:12px;color:#646970;}' +
            '.resi-customer-address{margin-top:3px;font-size:11px;color:#8c8f94;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}' +
            '.resi-customer-status{padding:10px 11px;font-size:13px;color:#646970;}' +
            '.resi-customer-clear{position:absolute;right:7px;top:50%;transform:translateY(-50%);border:0;background:transparent;color:#787c82;cursor:pointer;font-size:20px;line-height:1;padding:2px 5px;display:none;}' +
            '.resi-customer-autocomplete-wrap.has-value .resi-customer-clear{display:block;}' +
            '.resi-customer-autocomplete-wrap.has-value .resi-customer-autocomplete-input{padding-right:32px;}' +
            '.resi-customer-details{margin-top:10px;padding:12px 14px;border:1px solid #dcdcde;border-radius:6px;background:#f6f7f7;font-size:13px;line-height:1.45;}' +
            '.resi-customer-details-title{font-weight:600;font-size:14px;margin-bottom:8px;color:#1d2327;}' +
            '.resi-customer-detail-row{display:flex;gap:12px;padding:4px 0;border-top:1px solid #e2e4e7;}' +
            '.resi-customer-detail-row:first-of-type{border-top:0;}' +
            '.resi-customer-detail-label{flex:0 0 90px;font-weight:600;color:#50575e;}' +
            '.resi-customer-detail-value{flex:1;color:#1d2327;word-break:break-word;}' +
            '@media(max-width:600px){.resi-customer-autocomplete-list{max-height:260px}.resi-customer-detail-row{display:block}.resi-customer-detail-label{margin-bottom:1px}}' +
            '</style>'
        );
    }

    function itemFromRow(item) {
        return {
            id: item && item.id ? item.id : (item && item.name ? item.name : ''),
            text: item && item.name ? item.name : '',
            name: item && item.name ? item.name : '',
            company: item && item.company ? item.company : '',
            contact: item && item.contact ? item.contact : '',
            address: item && item.address ? item.address : '',
            phone: item && item.phone ? item.phone : '',
            tipe: item && item.tipe ? item.tipe : '',
            remark: item && item.remark ? item.remark : ''
        };
    }

    function customerMarkup(item) {
        var html = '<div class="resi-customer-option">' +
            '<div class="resi-customer-name">' + escapeHtml(item.name) + '</div>';

        var meta = [];
        if (item.company) meta.push(escapeHtml(item.company));
        if (item.contact) meta.push(escapeHtml(item.contact));
        if (item.phone) meta.push(escapeHtml(item.phone));

        if (meta.length) html += '<div class="resi-customer-meta">' + meta.join(' &bull; ') + '</div>';
        if (item.address) html += '<div class="resi-customer-address">' + escapeHtml(item.address) + '</div>';

        return html + '</div>';
    }

    function customerDetailsMarkup(item) {
        if (!item || !item.name) return '';

        var rows = [];
        function addRow(label, value) {
            if (value !== undefined && value !== null && String(value).trim() !== '') {
                rows.push(
                    '<div class="resi-customer-detail-row">' +
                    '<div class="resi-customer-detail-label">' + escapeHtml(label) + '</div>' +
                    '<div class="resi-customer-detail-value">' + escapeHtml(value) + '</div>' +
                    '</div>'
                );
            }
        }

        addRow('Customer', item.name);
        addRow('Tipe', item.tipe);
        addRow('Perusahaan', item.company);
        addRow('Kontak', item.contact);
        addRow('Telepon', item.phone);
        addRow('Alamat', item.address);
        addRow('Keterangan', item.remark);

        return '<div class="resi-customer-details-title">Data Customer</div>' + rows.join('');
    }

    function showDetails(item) {
        if (!state || !state.$details) return;
        if (!item || !item.name) {
            state.$details.empty().hide();
            return;
        }
        state.$details.html(customerDetailsMarkup(item)).show();
    }

    function closeList() {
        if (!state) return;
        state.$list.removeClass('show').empty();
        state.items = [];
        state.index = -1;
    }

    function renderStatus(text) {
        if (!state) return;
        state.$list.html('<div class="resi-customer-status">' + escapeHtml(text) + '</div>').addClass('show');
    }

    function renderItems(items) {
        if (!state) return;

        state.items = items || [];
        state.index = -1;
        state.$list.empty();

        if (!state.items.length) {
            renderStatus(config.i18n.noResults || 'Customer tidak ditemukan.');
            return;
        }

        $.each(state.items, function (i, raw) {
            var item = itemFromRow(raw);
            if (!item.name) return;

            var $item = $(customerMarkup(item))
                .attr('data-index', i)
                .attr('role', 'option');

            state.$list.append($item);
        });

        state.$list.addClass('show');
    }

    function setActive(index) {
        if (!state || !state.items.length) return;

        state.index = index;
        state.$list.children('.resi-customer-option')
            .removeClass('active')
            .eq(index)
            .addClass('active');

        var el = state.$list.children('.resi-customer-option').get(index);
        if (el) el.scrollIntoView({ block: 'nearest' });
    }

    function syncToPods(value) {
        if (!state || !state.$original.length) return;
        value = value == null ? '' : String(value);
        state.$original.val(value).trigger('input').trigger('change');
    }

    function selectCustomer(raw) {
        var item = itemFromRow(raw);
        if (!item.name) return;

        state.selected = item;
        state.$input.val(item.name);
        state.$wrap.addClass('has-value');
        syncToPods(item.name);
        showDetails(item);
        closeList();
    }

    function searchCustomer(keyword) {
        keyword = $.trim(keyword || '');

        if (request && request.readyState !== 4) request.abort();

        if (keyword.length < 1) {
            closeList();
            return;
        }

        var requestId = ++latestRequest;
        renderStatus(config.i18n.searching || 'Mencari customer...');

        request = $.ajax({
            url: config.ajaxUrl,
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'search_customer',
                term: keyword
            },
            cache: false
        }).done(function (response) {
            if (requestId !== latestRequest) return;

            if (!response || response.success !== true) {
                renderStatus(config.i18n.error || 'Gagal mengambil data customer.');
                return;
            }

            renderItems(response.data || []);
        }).fail(function (xhr, status) {
            if (status === 'abort') return;
            if (requestId !== latestRequest) return;
            renderStatus(config.i18n.error || 'Gagal mengambil data customer.');
        });
    }

    function loadInitialCustomer() {
        var value = $.trim(state.$original.val() || '');
        if (!value || !config.ajaxUrl) return;

        $.ajax({
            url: config.ajaxUrl,
            type: 'GET',
            dataType: 'json',
            data: {
                action: 'search_customer',
                term: value
            },
            cache: false
        }).done(function (response) {
            if (!response || response.success !== true) return;

            var found = null;
            $.each(response.data || [], function (_, item) {
                if (String(item.name || '') === value) {
                    found = itemFromRow(item);
                    return false;
                }
            });

            if (!found) return;

            state.selected = found;
            state.$input.val(found.name);
            state.$wrap.addClass('has-value');
            showDetails(found);
            syncToPods(found.name);
        });
    }

    function prepareField() {
        var $original = $(selector);
        if (!$original.length) return null;

        var existing = $original.data('resiCustomerAutocompleteState');
        if (existing) {
            state = existing;
            return existing;
        }

        var initial = $.trim($original.val() || '');
        var $wrap = $('<div class="resi-customer-autocomplete-wrap"></div>');
        var $input = $('<input type="text" class="resi-customer-autocomplete-input" autocomplete="off">');
        var $list = $('<div class="resi-customer-autocomplete-list" role="listbox"></div>');
        var $clear = $('<button type="button" class="resi-customer-clear" aria-label="Hapus">&times;</button>');
        var $details = $('<div class="resi-customer-details" style="display:none;"></div>');

        $input.attr('placeholder', config.i18n.placeholder || 'Ketik nama customer...').val(initial);

        $original
            .addClass('resi-customer-original-hidden')
            .attr('autocomplete', 'off')
            .after($wrap);

        $wrap.append($input, $clear, $list);
        $wrap.after($details);

        state = {
            $original: $original,
            $wrap: $wrap,
            $input: $input,
            $list: $list,
            $clear: $clear,
            $details: $details,
            items: [],
            index: -1,
            selected: null
        };

        $original.data('resiCustomerAutocompleteState', state);

        var doSearch = debounce(function () {
            searchCustomer(state.$input.val());
        }, 250);

        $input.on('input', function () {
            state.selected = null;
            $original.val($input.val()).trigger('input');
            $wrap.toggleClass('has-value', !!$.trim($input.val()));
            $details.empty().hide();
            doSearch();
        });

        $input.on('focus', function () {
            if ($.trim($input.val())) doSearch();
        });

        $input.on('keydown', function (e) {
            if (!$list.hasClass('show')) return;

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setActive(state.index < state.items.length - 1 ? state.index + 1 : 0);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setActive(state.index > 0 ? state.index - 1 : state.items.length - 1);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (state.index >= 0) {
                    selectCustomer(state.items[state.index]);
                } else if (state.items.length === 1) {
                    selectCustomer(state.items[0]);
                }
            } else if (e.key === 'Escape') {
                closeList();
            }
        });

        $list.on('mousedown', '.resi-customer-option', function (e) {
            e.preventDefault();
            var index = parseInt($(this).attr('data-index'), 10);
            selectCustomer(state.items[index]);
        });

        $clear.on('click', function () {
            if (request && request.readyState !== 4) request.abort();
            latestRequest++;
            $input.val('');
            $original.val('').trigger('input').trigger('change');
            state.selected = null;
            $wrap.removeClass('has-value');
            showDetails(null);
            closeList();
            $input.focus();
        });

        $original.on('change', function () {
            if (!$.trim($input.val())) $input.val($.trim($original.val() || ''));
        });

        if (initial) $wrap.addClass('has-value');
        loadInitialCustomer();

        return state;
    }

    addStyle();

    prepareField();

    var attempts = 0;
    var timer = setInterval(function () {
        attempts++;
        if (prepareField() || attempts >= 30) clearInterval(timer);
    }, 250);

    $(document).on('click.resiCustomerAutocomplete', function (e) {
        if (state && state.$wrap && !state.$wrap[0].contains(e.target)) closeList();
    });
});
