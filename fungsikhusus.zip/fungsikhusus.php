<?php
/**
 * Plugin Name: Fungsi Khusus
 * Description: Mengatur Web ini
 * Version: 1.0
 */
require_once 'form/user.php';
require_once 'form/capture.php';
require_once 'form/file.php';
require_once 'form/approve.php';
require_once 'cache/cache.php';
require_once 'wpdb/wpdb.php';
require_once 'debloat/debloat.php';
require_once 'jetengine/jetengine.php';
require_once 'php/myphp.php';
add_filter( 'https_ssl_verify', '__return_false' );
add_filter( 'https_local_ssl_verify', '__return_false' );


 ?>