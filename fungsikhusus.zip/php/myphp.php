<?php function myphp_shortcode($atts, $content = null) {
    if ($content === null) {
        return '';
    }

    ob_start();
    try {
        eval('?>' . $content);
    } catch (Throwable $e) {
        ob_end_clean();
        return 'PHP Error: ' . $e->getMessage();
    }
    return ob_get_clean();
}

add_shortcode('myphp', 'myphp_shortcode');
/*[myphp]<?php echo 'xxx'; ?>[/myphp] */

add_shortcode('getscript',function($atts,$content = null){
wp_enqueue_script( $atts['name'], $atts['src'], [$atts['dep']], $atts['ver'], $atts['footer'] );
//name,src,dep,ver,footer=true/false [getscript name=daftar src="/wp-content/themes/hello-madxartwork/daftar.js" dep="jquery" ver=1 footer=true][/getscript]
});

add_shortcode('doshortcode',function($atts,$content = null){
return do_shortcode($content);
});
//[doshortcode]someshortcode[/doshortcode]

add_shortcode('replace',function($atts,$content = null){
return str_replace($atts['from'],$atts['to'],$content);
});
//[replace from=ABC to=123]ABC123[/replace]


