<?php namespace FluentSmtpDb\Viocon;


class VioconException extends \Exception
{

}
