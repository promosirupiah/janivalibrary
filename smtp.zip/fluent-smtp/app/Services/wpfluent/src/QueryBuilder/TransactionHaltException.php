<?php

namespace FluentSmtpDb\QueryBuilder;

class TransactionHaltException extends \Exception
{
}
