<?php
  $defaults=array(
    'title'=> __('Blogroll', 'collapsing-links'), 
    'showLinkCount'=> true ,
    'catSort'=> 'catName' ,
    'catSortOrder'=> 'ASC' ,
    'linkSort'=> 'linkName' ,
    'linkSortOrder'=> 'ASC' ,
    'inExclude'=> 'exclude' ,
    'inExcludeCats'=> '' ,
    'expand'=> 0 ,
    'customExpand' => '',
    'customCollapse' => '',
    'defaultExpand'=> '',
    'animate' => 0,
    'nofollow' => true,
    'debug' => false
  );
  ?>
