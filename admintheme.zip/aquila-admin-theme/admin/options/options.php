<?php if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) { exit; }

include('registerSettings.php');
include('helpers.php');
include('createFields.php');
include('callbacks.php');
include('createOptionsPage.php');
include('help.php');
include('setVariables.php');
