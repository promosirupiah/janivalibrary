<?php if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) { exit; }

include('widgets/removeWidgets.php');
include('widgets/welcomeWidget.php');
include('widgets/pluginWidget.php');

include('functions/addClasses.php');
include('functions/hideNag.php');
include('functions/postToBlog.php');
include('functions/footer.php');
