<?php if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) { exit; }

include('adminBar/customLogo.php');
include('adminBar/adminBarStyle.php');
include('adminBar/adminBarIcon.php');
include('adminBar/adminBarLinks.php');
include('adminBar/adminBarTitle.php');
include('adminBar/screenLinks.php');
include('adminBar/removeHowdy.php');
