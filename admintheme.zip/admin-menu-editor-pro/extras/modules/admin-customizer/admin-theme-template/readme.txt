=== {pluginName} ===
Tags: admin theme, custom admin
Requires at least: {requiredWpVersion}
Tested up to: {testedWpVersion}
Stable tag: {pluginVersion}
Requires PHP: 5.6.20

{shortDescription}

== Description ==

{shortDescription}

== Installation ==

1. Upload the `{pluginSlug}` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.