<?php

namespace YahnisElsts\AdminMenuEditor\ProCustomizable\Settings;

class Margins extends SpacingSetting {
	protected $label = 'Margins';
	protected $cssPropertyPrefix = 'margin-';
	//TODO: What about "auto"?
}