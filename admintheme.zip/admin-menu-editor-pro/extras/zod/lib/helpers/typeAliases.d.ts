export declare type Primitive = string | number | symbol | bigint | boolean | null | undefined;
export declare type Scalars = Primitive | Primitive[];
