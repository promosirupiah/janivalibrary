import { ZodErrorMap } from "../ZodError";
declare const errorMap: ZodErrorMap;
export default errorMap;
