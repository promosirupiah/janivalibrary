(function ($) {

  $(document).ready(function() {

    $('#screen-meta-links').addClass('wpapc-screen-meta');

  });

})(jQuery);