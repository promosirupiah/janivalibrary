=== FancyBox ===
Contributors: Kevin Sylvestre
Tags: javascript, images, lightbox, fancybox
Requires at least: 2.7
Tested up to: 2.8
Stable tag: 1.0.5

Enables fancybox on all image links including BMP, GIF, JPG, JPEG, and PNG links.

== Description ==

This plugin uses the jquery implementation of fancybox and makes use of [attr] style selectors by adding a section to the wordpress header.

For more information and examples of slimbox visit:

[FancyBox](http://fancy.klade.lv/)

== Installation ==

1. Upload `fancy-box` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Fancybox in action.
