<?php
if ( ! defined( 'ABSPATH' ) ) exit;
if(!class_exists('Aiomatic_Streaming')) 
{
    class Aiomatic_Streaming
    {
        private static  $instance = null ;
        public static function get_instance()
        {
            if ( is_null( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }
        public function __construct()
        {
            add_action('init', [$this, 'aiomatic_stream'], 1);
        }
        public function aiomatic_stream()
        {
            if(isset($_GET['aiomatic_stream']) && sanitize_text_field($_GET['aiomatic_stream']) == 'yes')
            {
                header('Content-type: text/event-stream');
                header('Cache-Control: no-cache');
                if (!isset($_REQUEST['nonce']) || !wp_verify_nonce($_REQUEST['nonce'], 'aiomatic-streaming-nonce')) 
                {
                    $message = esc_html__('You are not allowed to do this action!', 'aiomatic-automatic-ai-content-writer');
                    $this->aiomatic_event_exit($message);
                }
                else 
                {
                    if (isset($_REQUEST['input_text']) && !empty($_REQUEST['input_text'])) 
                    {
                        if(!isset($_REQUEST['model']) || !isset($_REQUEST['temp']) || !isset($_REQUEST['top_p']) || !isset($_REQUEST['presence']) || !isset($_REQUEST['frequency']) || !isset($_REQUEST['remember_string']))
                        {
                            $message = esc_html__('Incomplete POST request for chat!', 'aiomatic-automatic-ai-content-writer');
                            $this->aiomatic_event_exit($message);
                        }
                        $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
                        if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
                        {
                            $aiomatic_result = esc_html__('You need to insert a valid OpenAI/AiomaticAPI API Key for this to work!', 'aiomatic-automatic-ai-content-writer');
                            $this->aiomatic_event_exit($aiomatic_result);
                        }
                        $user_token_cap_per_day = sanitize_text_field($_REQUEST['user_token_cap_per_day']);
                        if(!empty($user_token_cap_per_day))
                        {
                            $user_token_cap_per_day = intval($user_token_cap_per_day);
                        }
                        $user_id = sanitize_text_field($_REQUEST['user_id']);
                        $input_text = stripslashes($_REQUEST['input_text']);
                        $user_question = stripslashes($_REQUEST['user_question']);
                        $aiomatic_Chatbot_Settings = get_option('aiomatic_Chatbot_Settings', false);
                        if (isset($aiomatic_Chatbot_Settings['max_input_length']) && $aiomatic_Chatbot_Settings['max_input_length'] != '' && is_numeric($aiomatic_Chatbot_Settings['max_input_length'])) 
                        {
                            if(strlen($input_text) > intval($aiomatic_Chatbot_Settings['max_input_length']))
                            {
                                $input_text = substr($input_text, 0, intval($aiomatic_Chatbot_Settings['max_input_length']));
                            }
                        }
                        $remember_string = stripslashes($_REQUEST['remember_string']);
                        if(!empty(trim($remember_string)))
                        {
                            $input_text = trim($remember_string) . PHP_EOL . $input_text;
                        }
                        $model = sanitize_text_field(stripslashes($_REQUEST['model']));
                        $temperature = sanitize_text_field($_REQUEST['temp']);
                        $top_p = sanitize_text_field($_REQUEST['top_p']);
                        $presence_penalty = sanitize_text_field($_REQUEST['presence']);
                        $frequency_penalty = sanitize_text_field($_REQUEST['frequency']);
                        $models = aiomatic_get_all_models();
                        if(!in_array($model, $models))
                        {
                            $aiomatic_result = esc_html__('Invalid model provided: ', 'aiomatic-automatic-ai-content-writer') . $model;
                            $this->aiomatic_event_exit($aiomatic_result);
                        }
                        $vision_file = '';
                        if(isset($_REQUEST['vision_file']))
                        {
                            if(aiomatic_is_vision_model($model))
                            {
                                $vision_file = stripslashes($_REQUEST['vision_file']);
                            }
                        }
                        $temperature = floatval($temperature);
                        $top_p = floatval($top_p);
                        $presence_penalty = floatval($presence_penalty);
                        $frequency_penalty = floatval($frequency_penalty);
                        if($temperature < 0 || $temperature > 1)
                        {
                            $aiomatic_result = esc_html__('Invalid temperature provided: ', 'aiomatic-automatic-ai-content-writer') . $temperature;
                            $this->aiomatic_event_exit($aiomatic_result);
                        }
                        if($top_p < 0 || $top_p > 1)
                        {
                            $aiomatic_result = esc_html__('Invalid top_p provided: ', 'aiomatic-automatic-ai-content-writer') . $top_p;
                            $this->aiomatic_event_exit($aiomatic_result);
                        }
                        if($presence_penalty < -2 || $presence_penalty > 2)
                        {
                            $aiomatic_result = esc_html__('Invalid presence_penalty provided: ', 'aiomatic-automatic-ai-content-writer') . $presence_penalty;
                            $this->aiomatic_event_exit($aiomatic_result);
                        }
                        if($frequency_penalty < -2 || $frequency_penalty > 2)
                        {
                            $aiomatic_result = esc_html__('Invalid frequency_penalty provided: ', 'aiomatic-automatic-ai-content-writer') . $frequency_penalty;
                            $this->aiomatic_event_exit($aiomatic_result);
                        }
                        $used_token_count = 0;
                        if(is_numeric($user_token_cap_per_day))
                        {
                            if(empty($user_id) || $user_id == 0 || !is_numeric($user_id))
                            {
                                $aiomatic_result = sprintf( wp_kses( __( 'You are not allowed to access this form if you are not logged in. Please <a href="%s" target="_blank">log in</a> to continue.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), wp_login_url(get_permalink()) );
                                $this->aiomatic_event_exit($aiomatic_result);
                            }
                            $used_token_count = get_user_meta($user_id, 'aiomatic_used_chat_tokens', true);
                            if($used_token_count !== '' && $used_token_count !== false && is_numeric($used_token_count))
                            {
                                $used_token_count = intval($used_token_count);
                                if($used_token_count > $user_token_cap_per_day)
                                {
                                    $aiomatic_result = esc_html__('Daily token count for your user account was exceeded! Please try again tomorrow.', 'aiomatic-automatic-ai-content-writer');
                                    $this->aiomatic_event_exit($aiomatic_result);
                                }
                            }
                            else
                            {
                                $used_token_count = 0;
                            }
                        }
                        $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                        $appids = array_filter($appids);
                        $token = $appids[array_rand($appids)];
                        $max_tokens = aiomatic_get_max_tokens($model);
                        $query_token_count = count(aiomatic_encode($input_text));
                        $available_tokens = aiomatic_compute_available_tokens($model, $max_tokens, $input_text, $query_token_count);
                        if($available_tokens <= AIOMATIC_MINIMUM_TOKENS_FOR_COMPLETIONS)
                        {
                            $string_len = strlen($input_text);
                            $string_len = $string_len / 2;
                            $string_len = intval(0 - $string_len);
                            $input_text = aiomatic_substr($input_text, 0, $string_len);
                            $input_text = trim($input_text);
                            if(empty($input_text))
                            {
                                $aiomatic_result = esc_html__('Empty API seed expression provided (after processing)', 'aiomatic-automatic-ai-content-writer');
                                $this->aiomatic_event_exit($aiomatic_result);
                            }
                            $query_token_count = count(aiomatic_encode($input_text));
                            $available_tokens = $max_tokens - $query_token_count;
                        }
                        $thread_id = '';
                        $error = '';
                        $finish_reason = '';
                        aiomatic_generate_text($token, $model, $input_text, $available_tokens, $temperature, $top_p, $presence_penalty, $frequency_penalty, true, 'shortcodeChat',  0, $finish_reason, $error, false, true, $vision_file, $user_question, 'user', '', $thread_id);
                    }
                }
                exit;
            }
        }

        private function aiomatic_event_exit($message)
        {
            echo "event: message\n";
            echo 'data: {"error":[{"message":"' . $message . '"}]}';
            echo "\n\n";
            if (ob_get_length())
            {
                ob_end_flush();
            }
            flush();
            echo 'data: {"choices":[{"finish_reason":"stop"}]}';
            echo "\n\n";
            if (ob_get_length())
            {
                ob_end_flush();
            }
            flush();
            exit;
        }
    }
    Aiomatic_Streaming::get_instance();
}
?>