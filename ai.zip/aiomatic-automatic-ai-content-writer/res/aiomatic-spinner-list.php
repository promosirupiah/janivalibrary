<?php
function aiomatic_spinner_panel()
{
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   if (!isset($aiomatic_Main_Settings['app_id']) || trim($aiomatic_Main_Settings['app_id']) == '') 
   {
      ?>
<h1><?php echo esc_html__("You must add an OpenAI/AiomaticAPI API Key into the plugin's 'Main Settings' menu before you can use this feature!", 'aiomatic-automatic-ai-content-writer');?></h1>
<?php
return;
   }
   $all_models = aiomatic_get_all_models(true);
   $all_assistants = aiomatic_get_all_assistants(true);
   $all_edit_models = array_merge($all_models, AIOMATIC_EDIT_MODELS);
?>
<div class="wp-header-end"></div>
<?php
$max_execution = ini_get('max_execution_time');
if($max_execution != 0 && $max_execution < 1000)
{
    ?>
    <div class="notice notice-error">
        <p class="cr_red">
            <?php echo sprintf( wp_kses( __( "Warning! Your PHP INI max_execution_time is less than 1000 seconds (%s). This means that the plugin's execution will be forcefully stopped by your server after this amount of seconds. Please increase it to ensure that the plugin functions properly. Please check details on server settings, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_html($max_execution), esc_url( get_admin_url() . 'admin.php?page=aiomatic_logs#tab-2' ) );?>
        </p>
    </div>
    <?php
}
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div class="wrap">
    <nav class="nav-tab-wrapper">
        <a href="#tab-0" class="nav-tab nav-tab-active"><?php echo esc_html__("Tutorial", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-3" class="nav-tab"><?php echo esc_html__("Automatic Content Editing", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-4" class="nav-tab"><?php echo esc_html__("Existing Content Editor", 'aiomatic-automatic-ai-content-writer');?></a>
        <a href="#tab-1" class="nav-tab"><?php echo esc_html__("Editing Templates and Options", 'aiomatic-automatic-ai-content-writer');?></a>
    </nav>
        <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
        <div class="cr_autocomplete">
 <input type="password" id="PreventChromeAutocomplete" 
  name="PreventChromeAutocomplete" autocomplete="address-level4" />
</div>
<?php
    settings_fields('aiomatic_option_group2');
    do_settings_sections('aiomatic_option_group2');
    $aiomatic_Spinner_Settings = get_option('aiomatic_Spinner_Settings', false);
    if (isset($aiomatic_Spinner_Settings['aiomatic_spinning'])) {
        $aiomatic_spinning = $aiomatic_Spinner_Settings['aiomatic_spinning'];
    } else {
        $aiomatic_spinning = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_posts'])) {
        $post_posts = $aiomatic_Spinner_Settings['post_posts'];
    } else {
        $post_posts = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_pages'])) {
        $post_pages = $aiomatic_Spinner_Settings['post_pages'];
    } else {
        $post_pages = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_custom'])) {
        $post_custom = $aiomatic_Spinner_Settings['post_custom'];
    } else {
        $post_custom = '';
    }
    if (isset($aiomatic_Spinner_Settings['except_type'])) {
        $except_type = $aiomatic_Spinner_Settings['except_type'];
    } else {
        $except_type = '';
    }
    if (isset($aiomatic_Spinner_Settings['disable_tags'])) {
        $disable_tags = $aiomatic_Spinner_Settings['disable_tags'];
    } else {
        $disable_tags = '';
    }
    if (isset($aiomatic_Spinner_Settings['change_status'])) {
        $change_status = $aiomatic_Spinner_Settings['change_status'];
    } else {
        $change_status = '';
    }
    if (isset($aiomatic_Spinner_Settings['delay_post'])) {
        $delay_post = $aiomatic_Spinner_Settings['delay_post'];
    } else {
        $delay_post = '';
    }
    if (isset($aiomatic_Spinner_Settings['process_event'])) {
        $process_event = $aiomatic_Spinner_Settings['process_event'];
    } else {
        $process_event = '';
    }
    if (isset($aiomatic_Spinner_Settings['run_background'])) {
        $run_background = $aiomatic_Spinner_Settings['run_background'];
    } else {
        $run_background = '';
    }
    if (isset($aiomatic_Spinner_Settings['append_spintax'])) {
        $append_spintax = $aiomatic_Spinner_Settings['append_spintax'];
    } else {
        $append_spintax = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_featured_image'])) {
        $ai_featured_image = $aiomatic_Spinner_Settings['ai_featured_image'];
    } else {
        $ai_featured_image = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_featured_image_source'])) {
        $ai_featured_image_source = $aiomatic_Spinner_Settings['ai_featured_image_source'];
    } else {
        $ai_featured_image_source = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_image_command'])) {
        $ai_image_command = $aiomatic_Spinner_Settings['ai_image_command'];
    } else {
        $ai_image_command = '';
    }
    if (isset($aiomatic_Spinner_Settings['url_image_list'])) {
        $url_image_list = $aiomatic_Spinner_Settings['url_image_list'];
    } else {
        $url_image_list = '';
    }
    if (isset($aiomatic_Spinner_Settings['image_size'])) {
        $image_size = $aiomatic_Spinner_Settings['image_size'];
    } else {
        $image_size = '';
    }
    if (isset($aiomatic_Spinner_Settings['image_model'])) {
        $image_model = $aiomatic_Spinner_Settings['image_model'];
    } else {
        $image_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['min_char'])) {
        $min_char = $aiomatic_Spinner_Settings['min_char'];
    } else {
        $min_char = '';
    }
    if (isset($aiomatic_Spinner_Settings['videos'])) {
        $videos = $aiomatic_Spinner_Settings['videos'];
    } else {
        $videos = '';
    }
    if (isset($aiomatic_Spinner_Settings['add_links'])) {
        $add_links = $aiomatic_Spinner_Settings['add_links'];
    } else {
        $add_links = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_links'])) {
        $max_links = $aiomatic_Spinner_Settings['max_links'];
    } else {
        $max_links = '';
    }
    if (isset($aiomatic_Spinner_Settings['link_list'])) {
        $link_list = $aiomatic_Spinner_Settings['link_list'];
    } else {
        $link_list = '';
    }
    if (isset($aiomatic_Spinner_Settings['link_nofollow'])) {
        $link_nofollow = $aiomatic_Spinner_Settings['link_nofollow'];
    } else {
        $link_nofollow = '';
    }
    if (isset($aiomatic_Spinner_Settings['link_type'])) {
        $link_type = $aiomatic_Spinner_Settings['link_type'];
    } else {
        $link_type = 'internal';
    }
    if (isset($aiomatic_Spinner_Settings['link_post_types'])) {
        $link_post_types = $aiomatic_Spinner_Settings['link_post_types'];
    } else {
        $link_post_types = '';
    }
    if (isset($aiomatic_Spinner_Settings['add_cats'])) {
        $add_cats = $aiomatic_Spinner_Settings['add_cats'];
    } else {
        $add_cats = 'disabled';
    }
    if (isset($aiomatic_Spinner_Settings['add_tags'])) {
        $add_tags = $aiomatic_Spinner_Settings['add_tags'];
    } else {
        $add_tags = 'disabled';
    }
    if (isset($aiomatic_Spinner_Settings['max_cats'])) {
        $max_cats = $aiomatic_Spinner_Settings['max_cats'];
    } else {
        $max_cats = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_tags'])) {
        $max_tags = $aiomatic_Spinner_Settings['max_tags'];
    } else {
        $max_tags = '';
    }
    if (isset($aiomatic_Spinner_Settings['skip_inexist'])) {
        $skip_inexist = $aiomatic_Spinner_Settings['skip_inexist'];
    } else {
        $skip_inexist = '';
    }
    if (isset($aiomatic_Spinner_Settings['skip_inexist_tags'])) {
        $skip_inexist_tags = $aiomatic_Spinner_Settings['skip_inexist_tags'];
    } else {
        $skip_inexist_tags = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_cats'])) {
        $ai_cats = $aiomatic_Spinner_Settings['ai_cats'];
    } else {
        $ai_cats = 'Write a comma separated list of 5 categories for post title: %%post_title%%';
    }
    if (isset($aiomatic_Spinner_Settings['ai_tags'])) {
        $ai_tags = $aiomatic_Spinner_Settings['ai_tags'];
    } else {
        $ai_tags = 'Write a comma separated list of 5 tags for post title: %%post_title%%';
    }
    if (isset($aiomatic_Spinner_Settings['cats_model'])) {
        $cats_model = $aiomatic_Spinner_Settings['cats_model'];
    } else {
        $cats_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['tags_model'])) {
        $tags_model = $aiomatic_Spinner_Settings['tags_model'];
    } else {
        $tags_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['tags_assistant_id'])) {
        $tags_assistant_id = $aiomatic_Spinner_Settings['tags_assistant_id'];
    } else {
        $tags_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['add_comments'])) {
        $add_comments = $aiomatic_Spinner_Settings['add_comments'];
    } else {
        $add_comments = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_comments'])) {
        $max_comments = $aiomatic_Spinner_Settings['max_comments'];
    } else {
        $max_comments = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_comments'])) {
        $ai_comments = $aiomatic_Spinner_Settings['ai_comments'];
    } else {
        $ai_comments = '';
    }
    if (isset($aiomatic_Spinner_Settings['prev_comms'])) {
        $prev_comms = $aiomatic_Spinner_Settings['prev_comms'];
    } else {
        $prev_comms = '';
    }
    if (isset($aiomatic_Spinner_Settings['comments_assistant_id'])) {
        $comments_assistant_id = $aiomatic_Spinner_Settings['comments_assistant_id'];
    } else {
        $comments_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['comments_model'])) {
        $comments_model = $aiomatic_Spinner_Settings['comments_model'];
    } else {
        $comments_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['user_list'])) {
        $user_list = $aiomatic_Spinner_Settings['user_list'];
    } else {
        $user_list = '%%random_user%%';
    }
    if (isset($aiomatic_Spinner_Settings['email_list'])) {
        $email_list = $aiomatic_Spinner_Settings['email_list'];
    } else {
        $email_list = '';
    }
    if (isset($aiomatic_Spinner_Settings['url_list'])) {
        $url_list = $aiomatic_Spinner_Settings['url_list'];
    } else {
        $url_list = '';
    }
    if (isset($aiomatic_Spinner_Settings['headings'])) {
        $headings = $aiomatic_Spinner_Settings['headings'];
    } else {
        $headings = '';
    }
    if (isset($aiomatic_Spinner_Settings['headings_model'])) {
        $headings_model = $aiomatic_Spinner_Settings['headings_model'];
    } else {
        $headings_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['headings_assistant_id'])) {
        $headings_assistant_id = $aiomatic_Spinner_Settings['headings_assistant_id'];
    } else {
        $headings_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['categories_assistant_id'])) {
        $categories_assistant_id = $aiomatic_Spinner_Settings['categories_assistant_id'];
    } else {
        $categories_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['headings_ai_command'])) {
        $headings_ai_command = $aiomatic_Spinner_Settings['headings_ai_command'];
    } else {
        $headings_ai_command = '';
    }
    if (isset($aiomatic_Spinner_Settings['append_assistant_id'])) {
        $append_assistant_id = $aiomatic_Spinner_Settings['append_assistant_id'];
    } else {
        $append_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['enable_ai_images'])) {
        $enable_ai_images = $aiomatic_Spinner_Settings['enable_ai_images'];
    } else {
        $enable_ai_images = '';
    }
    if (isset($aiomatic_Spinner_Settings['images'])) {
        $images = $aiomatic_Spinner_Settings['images'];
    } else {
        $images = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_tokens'])) {
        $max_tokens = $aiomatic_Spinner_Settings['max_tokens'];
    } else {
        $max_tokens = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_seed_tokens'])) {
        $max_seed_tokens = $aiomatic_Spinner_Settings['max_seed_tokens'];
    } else {
        $max_seed_tokens = '';
    }
    if (isset($aiomatic_Spinner_Settings['add_seo'])) {
        $add_seo = $aiomatic_Spinner_Settings['add_seo'];
    } else {
        $add_seo = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_seo'])) {
        $ai_seo = $aiomatic_Spinner_Settings['ai_seo'];
    } else {
        $ai_seo = '';
    }
    if (isset($aiomatic_Spinner_Settings['meta_assistant_id'])) {
        $meta_assistant_id = $aiomatic_Spinner_Settings['meta_assistant_id'];
    } else {
        $meta_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['seo_model'])) {
        $seo_model = $aiomatic_Spinner_Settings['seo_model'];
    } else {
        $seo_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['seo_max_char'])) {
        $seo_max_char = $aiomatic_Spinner_Settings['seo_max_char'];
    } else {
        $seo_max_char = '';
    }
    if (isset($aiomatic_Spinner_Settings['seo_copy_excerpt'])) {
        $seo_copy_excerpt = $aiomatic_Spinner_Settings['seo_copy_excerpt'];
    } else {
        $seo_copy_excerpt = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_result_tokens'])) {
        $max_result_tokens = $aiomatic_Spinner_Settings['max_result_tokens'];
    } else {
        $max_result_tokens = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_continue_tokens'])) {
        $max_continue_tokens = $aiomatic_Spinner_Settings['max_continue_tokens'];
    } else {
        $max_continue_tokens = '';
    }
    if (isset($aiomatic_Spinner_Settings['model'])) {
        $model = $aiomatic_Spinner_Settings['model'];
    } else {
        $model = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_command'])) {
        $ai_command = $aiomatic_Spinner_Settings['ai_command'];
    } else {
        $ai_command = '';
    }
    if (isset($aiomatic_Spinner_Settings['temperature'])) {
        $temperature = $aiomatic_Spinner_Settings['temperature'];
    } else {
        $temperature = '';
    }
    if (isset($aiomatic_Spinner_Settings['top_p'])) {
        $top_p = $aiomatic_Spinner_Settings['top_p'];
    } else {
        $top_p = '';
    }
    if (isset($aiomatic_Spinner_Settings['presence_penalty'])) {
        $presence_penalty = $aiomatic_Spinner_Settings['presence_penalty'];
    } else {
        $presence_penalty = '';
    }
    if (isset($aiomatic_Spinner_Settings['frequency_penalty'])) {
        $frequency_penalty = $aiomatic_Spinner_Settings['frequency_penalty'];
    } else {
        $frequency_penalty = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_rewriter'])) {
        $ai_rewriter = $aiomatic_Spinner_Settings['ai_rewriter'];
    } else {
        $ai_rewriter = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_instruction'])) {
        $ai_instruction = $aiomatic_Spinner_Settings['ai_instruction'];
    } else {
        $ai_instruction = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_instruction_title'])) {
        $ai_instruction_title = $aiomatic_Spinner_Settings['ai_instruction_title'];
    } else {
        $ai_instruction_title = '';
    }
    if (isset($aiomatic_Spinner_Settings['edit_temperature'])) {
        $edit_temperature = $aiomatic_Spinner_Settings['edit_temperature'];
    } else {
        $edit_temperature = '';
    }
    if (isset($aiomatic_Spinner_Settings['edit_top_p'])) {
        $edit_top_p = $aiomatic_Spinner_Settings['edit_top_p'];
    } else {
        $edit_top_p = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_char_chunks'])) {
        $max_char_chunks = $aiomatic_Spinner_Settings['max_char_chunks'];
    } else {
        $max_char_chunks = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_char'])) {
        $max_char = $aiomatic_Spinner_Settings['max_char'];
    } else {
        $max_char = '';
    }
    if (isset($aiomatic_Spinner_Settings['no_title'])) {
        $no_title = $aiomatic_Spinner_Settings['no_title'];
    } else {
        $no_title = '';
    }
    if (isset($aiomatic_Spinner_Settings['rewrite_url'])) {
        $rewrite_url = $aiomatic_Spinner_Settings['rewrite_url'];
    } else {
        $rewrite_url = '';
    }
    if (isset($aiomatic_Spinner_Settings['edit_model'])) {
        $edit_model = $aiomatic_Spinner_Settings['edit_model'];
    } else {
        $edit_model = '';
    }
    if (isset($aiomatic_Spinner_Settings['edit_assistant_id'])) {
        $edit_assistant_id = $aiomatic_Spinner_Settings['edit_assistant_id'];
    } else {
        $edit_assistant_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['no_html_check'])) {
        $no_html_check = $aiomatic_Spinner_Settings['no_html_check'];
    } else {
        $no_html_check = '';
    }
    if (isset($aiomatic_Spinner_Settings['protect_html'])) {
        $protect_html = $aiomatic_Spinner_Settings['protect_html'];
    } else {
        $protect_html = '';
    }
    if (isset($aiomatic_Spinner_Settings['no_content'])) {
        $no_content = $aiomatic_Spinner_Settings['no_content'];
    } else {
        $no_content = '';
    }
    if (isset($aiomatic_Spinner_Settings['no_excerpt'])) {
        $no_excerpt = $aiomatic_Spinner_Settings['no_excerpt'];
    } else {
        $no_excerpt = '';
    }
    if (isset($aiomatic_Spinner_Settings['ai_instruction_excerpt'])) {
        $ai_instruction_excerpt = $aiomatic_Spinner_Settings['ai_instruction_excerpt'];
    } else {
        $ai_instruction_excerpt = '';
    }
    if (isset($aiomatic_Spinner_Settings['tag_name'])) {
        $tag_name = $aiomatic_Spinner_Settings['tag_name'];
    } else {
        $tag_name = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_id'])) {
        $post_id = $aiomatic_Spinner_Settings['post_id'];
    } else {
        $post_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_name'])) {
        $post_name = $aiomatic_Spinner_Settings['post_name'];
    } else {
        $post_name = '';
    }
    if (isset($aiomatic_Spinner_Settings['page_id'])) {
        $page_id = $aiomatic_Spinner_Settings['page_id'];
    } else {
        $page_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_parent'])) {
        $post_parent = $aiomatic_Spinner_Settings['post_parent'];
    } else {
        $post_parent = '';
    }
    if (isset($aiomatic_Spinner_Settings['post_status'])) {
        $post_status = $aiomatic_Spinner_Settings['post_status'];
    } else {
        $post_status = '';
    }
    if (isset($aiomatic_Spinner_Settings['type_post'])) {
        $type_post = $aiomatic_Spinner_Settings['type_post'];
    } else {
        $type_post = '';
    }
    if (isset($aiomatic_Spinner_Settings['pagename'])) {
        $pagename = $aiomatic_Spinner_Settings['pagename'];
    } else {
        $pagename = '';
    }
    if (isset($aiomatic_Spinner_Settings['search_offset'])) {
        $search_offset = $aiomatic_Spinner_Settings['search_offset'];
    } else {
        $search_offset = '';
    }
    if (isset($aiomatic_Spinner_Settings['search_query'])) {
        $search_query = $aiomatic_Spinner_Settings['search_query'];
    } else {
        $search_query = '';
    }
    if (isset($aiomatic_Spinner_Settings['meta_name'])) {
        $meta_name = $aiomatic_Spinner_Settings['meta_name'];
    } else {
        $meta_name = '';
    }
    if (isset($aiomatic_Spinner_Settings['meta_value'])) {
        $meta_value = $aiomatic_Spinner_Settings['meta_value'];
    } else {
        $meta_value = '';
    }
    if (isset($aiomatic_Spinner_Settings['year'])) {
        $year = $aiomatic_Spinner_Settings['year'];
    } else {
        $year = '';
    }
    if (isset($aiomatic_Spinner_Settings['month'])) {
        $month = $aiomatic_Spinner_Settings['month'];
    } else {
        $month = '';
    }
    if (isset($aiomatic_Spinner_Settings['day'])) {
        $day = $aiomatic_Spinner_Settings['day'];
    } else {
        $day = '';
    }
    if (isset($aiomatic_Spinner_Settings['order'])) {
        $order = $aiomatic_Spinner_Settings['order'];
    } else {
        $order = '';
    }
    if (isset($aiomatic_Spinner_Settings['orderby'])) {
        $orderby = $aiomatic_Spinner_Settings['orderby'];
    } else {
        $orderby = '';
    }
    if (isset($aiomatic_Spinner_Settings['featured_image'])) {
        $featured_image = $aiomatic_Spinner_Settings['featured_image'];
    } else {
        $featured_image = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_posts'])) {
        $max_posts = $aiomatic_Spinner_Settings['max_posts'];
    } else {
        $max_posts = '';
    }
    if (isset($aiomatic_Spinner_Settings['category_name'])) {
        $category_name = $aiomatic_Spinner_Settings['category_name'];
    } else {
        $category_name = '';
    }
    if (isset($aiomatic_Spinner_Settings['author_id'])) {
        $author_id = $aiomatic_Spinner_Settings['author_id'];
    } else {
        $author_id = '';
    }
    if (isset($aiomatic_Spinner_Settings['author_name'])) {
        $author_name = $aiomatic_Spinner_Settings['author_name'];
    } else {
        $author_name = '';
    }
    if (isset($aiomatic_Spinner_Settings['max_nr'])) {
        $max_nr = $aiomatic_Spinner_Settings['max_nr'];
    } else {
        $max_nr = '';
    }
    if (isset($aiomatic_Spinner_Settings['secret_word'])) {
        $secret_word = $aiomatic_Spinner_Settings['secret_word'];
    } else {
        $secret_word = '';
    }
    if (isset($aiomatic_Spinner_Settings['auto_edit'])) {
        $auto_edit = $aiomatic_Spinner_Settings['auto_edit'];
    } else {
        $auto_edit = 'disabled';
    }
    if (isset($aiomatic_Spinner_Settings['auto_run_interval'])) {
        $auto_run_interval = $aiomatic_Spinner_Settings['auto_run_interval'];
    } else {
        $auto_run_interval = 'No';
    }
    if (isset($aiomatic_Spinner_Settings['no_twice'])) {
        $no_twice = $aiomatic_Spinner_Settings['no_twice'];
    } else {
        $no_twice = '';
    }
    if (isset($aiomatic_Spinner_Settings['custom_name'])) {
        $custom_name = $aiomatic_Spinner_Settings['custom_name'];
    } else {
        $custom_name = 'aiomatic_published';
    }
    if (isset($_GET['settings-updated'])) {
?>
<div id="message" class="updated">
<p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Settings saved.', 'aiomatic-automatic-ai-content-writer');?></strong></p>
</div>
<?php
$get = get_option('coderevolution_settings_changed', 0);
if($get == 1)
{
    delete_option('coderevolution_settings_changed');
?>
<div id="message" class="updated">
<p class="cr_failed_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration failed!', 'aiomatic-automatic-ai-content-writer');?></strong></p>
</div>
<?php 
}
elseif($get == 2)
{
        delete_option('coderevolution_settings_changed');
?>
<div id="message" class="updated">
<p class="cr_saved_notif"><strong>&nbsp;<?php echo esc_html__('Plugin registration successful!', 'aiomatic-automatic-ai-content-writer');?></strong></p>
</div>
<?php 
}
elseif($get != 0)
{
        delete_option('coderevolution_settings_changed');
?>
<div id="message" class="updated">
<p class="cr_failed_notif"><strong>&nbsp;<?php echo esc_html($get);?></strong></p>
</div>
<?php 
}
    }
?>

<div class="aiomatic_class">

<div id="tab-0" class="tab-content">     
    <br/>       
<h2><?php echo esc_html__('Welcome to Automatic AI Content Editing', 'aiomatic-automatic-ai-content-writer');?></h2>
<p>
<?php echo esc_html__('Welcome to this comprehensive guide on how to use the automatic post editing feature of the Aiomatic plugin. This powerful tool leverages artificial intelligence to automatically edit and enhance your WordPress posts, saving you time and effort while ensuring your content is optimized and engaging. Whether you\'re publishing new posts, drafting content, or revising existing posts, the Aiomatic plugin can be configured to automatically apply a range of edits. These include rewriting content, assigning featured images, appending or prepending AI-generated content, adding internal links, inserting related comments, and generating SEO meta descriptions.', 'aiomatic-automatic-ai-content-writer');?>
</p>
<p>
<?php echo esc_html__('In this tutorial, we will walk you through each step of setting up and using this feature, from installation and activation of the plugin, to configuring automatic and manual editing settings, to defining your editing templates and options, and finally, to adjusting advanced AI API settings for the editing process. By the end of this guide, you\'ll be able to harness the power of AI to streamline your content creation process and enhance the quality of your posts. Let\'s get started!', 'aiomatic-automatic-ai-content-writer');?>
</p>
<h2><?php echo esc_html__('"Automatic Content Editing Settings" Tab', 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__('Here, you can set up the conditions for automatic post editing:', 'aiomatic-automatic-ai-content-writer');?>

<ul><li><?php echo esc_html__('When to edit posts: Choose whether you want posts to be edited when they are published, drafted, or set as pending.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('What post types to edit: Select the types of posts you want to be edited. This could be blog posts, pages, or any custom post types you have on your site.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('How long to wait before editing new posts: Set a delay for the editing process. This could be useful if you want to review the posts yourself before they are automatically edited.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('What categories or tags not to edit: If there are certain categories or tags you don\'t want to be edited, you can specify them here.', 'aiomatic-automatic-ai-content-writer');?>
</li></ul>
<h2><?php echo esc_html__('"Manual Content Editing Settings" Tab', 'aiomatic-automatic-ai-content-writer');?></h2>

<?php echo esc_html__('In the \'Manual Content Editing Settings\' tab, you can set up the conditions for manual post editing. This is useful for editing existing posts. You can set detailed filters on what posts/pages/custom post types to automatically edit.', 'aiomatic-automatic-ai-content-writer');?>

<h2><?php echo esc_html__('"Editing Templates and Options" Tab', 'aiomatic-automatic-ai-content-writer');?></h2>

<?php echo esc_html__('In the \'Editing Templates and Options\' tab, you can set how to edit posts. Here are the options:', 'aiomatic-automatic-ai-content-writer');?>
<ul><li>
<?php echo esc_html__('Enable AI Content Rewriting: This will enable the editing and rewriting of the content.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('Enable Featured Image Assignation: This will automatically assign a featured image to the published content.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('Add AI Generated Content: This will automatically append or prepend AI generated content to posts.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('Automatically Add Internal Links: This will automatically add internal links to posts.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('Automatically Add Comments To Posts: This will add related comments to posts.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('Automatically Add AI Generated SEO Description To Posts: This will automatically add SEO meta description for posts.', 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__('You can also change the status of the posts after they were edited, using the \'Change Post Status After Editing\' settings field.', 'aiomatic-automatic-ai-content-writer');?>
</li></ul>

<h2><?php echo esc_html__('"Advanced AI API Settings" Tab', 'aiomatic-automatic-ai-content-writer');?></h2>

<?php echo esc_html__('In the \'Advanced AI API Settings\' tab, you can change advanced AI model settings, which will be used when editing content. This could include things like the complexity of the language used, the tone of the content, and more.', 'aiomatic-automatic-ai-content-writer');?>

<h2><?php echo esc_html__('General Tips', 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__('Be sure to always save settings you change.', 'aiomatic-automatic-ai-content-writer');?>

<?php echo esc_html__('After you\'ve configured all the settings to your liking, make sure to click the "Save Changes" button at the bottom of the page.', 'aiomatic-automatic-ai-content-writer');?>

<?php echo esc_html__('And that\'s it! Your Aiomatic plugin is now set up to automatically edit your posts using AI. Remember, you can always go back and change these settings if you find that the automatic editing isn\'t working quite how you want it to.', 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("AI Content Editor Tutorial Video", 'aiomatic-automatic-ai-content-writer');?></h2>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/WVccxtXQTcc" frameborder="0" allowfullscreen></iframe></div></p>
</div>
<div id="tab-1" class="tab-content">
                    <table class="widefat">
                    <tr><td colspan="2">
                    <h2><?php echo esc_html__("AI Content Rewriter Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will rewrite the textual content of the post, using AI.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Enable AI Content Rewriting:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="ai_rewriter" name="aiomatic_Spinner_Settings[ai_rewriter]" onchange="mainChanged();" >
                              <option value="enabled"<?php
                                 if ($ai_rewriter == "enabled") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="disabled"<?php
                                 if ($ai_rewriter == "disabled") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
        </div>
        </td></tr>
        <tr class="hideMain">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="edit_assistant_id" name="aiomatic_Spinner_Settings[edit_assistant_id]" class="cr_width_full" onchange="assistantSelected('edit_assistant_id', 'disableEdit');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($edit_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($edit_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr>
        <tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Select the AI model to use for text editing. Currently, the specialized edit models from OpenAI/AiomaticAPI are in beta, because of this, at the moment, it is recommended to use a completion model.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model To Use For Text Editing:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <select id="edit_model" name="aiomatic_Spinner_Settings[edit_model]" <?php if($edit_assistant_id != ''){echo ' disabled';}?> class="disableEdit">
<?php
foreach($all_edit_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($edit_model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
            </select>
            </td>
            </tr><tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Do you want to skip post title editing?", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Skip Post Title Editing:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="no_title" name="aiomatic_Spinner_Settings[no_title]"<?php
    if ($no_title == 'on')
        echo ' checked ';
?>>
            </td>
            </tr><tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Do you want to rewrite also post URL with the modified title?", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Rewrite Also Post URL With The Modified Title:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="rewrite_url" name="aiomatic_Spinner_Settings[rewrite_url]"<?php
    if ($rewrite_url == 'on')
        echo ' checked ';
?>>
            </td>
            </tr><tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Instruction for the AI editor, to edit post title. Please specify your instruction without adding the %%post_title%% shortcode, as the content will be automatically added at processing time.  Nested shortcodes from other plugins also supported here. You can also use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Instructions to Send For the AI Editor (Title Editing):", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_instruction_title]" placeholder="Please insert a title editor instruction"><?php
    echo esc_textarea($ai_instruction_title);
?></textarea>
        </div>
        </td></tr>
            <tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Do you want to skip post content editing?", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Skip Post Content Editing:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="no_content" name="aiomatic_Spinner_Settings[no_content]"<?php
    if ($no_content == 'on')
        echo ' checked ';
?>>
            </td>
            </tr><tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Instruction for the AI editor, to edit post content. Please specify your instruction without adding the %%post_content%% shortcode, as the content will be automatically added at processing time. Nested shortcodes from other plugins also supported here. You can also use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Instructions to Send For the AI Editor (Content Editing):", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_instruction]" placeholder="Please insert a content editor instruction"><?php
    echo esc_textarea($ai_instruction);
?></textarea>
        </div>
        </td></tr>
            <tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Do you want to skip post excerpt editing?", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Skip Post Excerpt Editing:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="no_excerpt" name="aiomatic_Spinner_Settings[no_excerpt]"<?php
    if ($no_excerpt == 'on')
        echo ' checked ';
?>>
            </td>
            </tr><tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Instruction for the AI editor, to edit post excerpt. Please specify your instruction without adding the %%post_excerpt%% shortcode, as the excerpt will be automatically added at processing time. Nested shortcodes from other plugins also supported here. You can also use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Instructions to Send For the AI Editor (Excerpt Editing):", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_instruction_excerpt]" placeholder="Please insert a excerpt editor instruction"><?php
    echo esc_textarea($ai_instruction_excerpt);
?></textarea>
        </div>
        </td></tr>
            <tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Content Editor Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" id="edit_temperature" name="aiomatic_Spinner_Settings[edit_temperature]" class="cr_450" value="<?php echo esc_html($edit_temperature);?>" placeholder="0">
        </td></tr><tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Content Editor Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" max="1" id="edit_top_p" name="aiomatic_Spinner_Settings[edit_top_p]" class="cr_450" value="<?php echo esc_html($edit_top_p);?>" placeholder="1">
        </td></tr><tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Do you want to disable automatically editing of content longer than this character count?", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Disable Editing of Content Longer Than This Character Count:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="1" id="max_char" name="aiomatic_Spinner_Settings[max_char]" class="cr_450" value="<?php echo esc_html($max_char);?>" placeholder="Max editing character count">
        </td></tr><tr class="hideMain"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Currently, as the AI editor is in beta, it might have difficulties editing longer texts. If you encounter this issue, you can limit the chunk size which is sent to the AI editor (in characters). Leave this blank if editing works well in your case.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Character Chunk Size To Send To The AI Editor (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="100" step="1" id="max_char_chunks" name="aiomatic_Spinner_Settings[max_char_chunks]" class="cr_450" value="<?php echo esc_html($max_char_chunks);?>" placeholder="Max character count">
        </td></tr>
            <tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Currently, because of an issue with the AI editor, sometimes it might remove parts of the HTML content you send to it for editing. The Aiomatic plugin can check if this happens and not change the post in these cases. If you check this checkbox, the edited content will be published, even if it misses some HTML tags. Do you want to publish edited content even if the AI editor removed some or all HTML content from the text?", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Publish Edited Content Even if the AI Removed Parts of the HTML Text:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="no_html_check" name="aiomatic_Spinner_Settings[no_html_check]"<?php
    if ($no_html_check == 'on')
        echo ' checked ';
?>>
            </td>
            </tr><tr class="hideMain">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Do you want to protect HTML tags in edited text? This will add to the prompt you enter, a phrase which specifies to protect HTML tags from the edited text.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Protect HTML Tags in Edited Text:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="protect_html" name="aiomatic_Spinner_Settings[protect_html]"<?php
    if ($protect_html == 'on')
        echo ' checked ';
?>>
            </td>
            </tr>
                    <tr><td colspan="2">
                    <h2><?php echo esc_html__("AI Generated Featured Image Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will generate AI generated or royalty free images, that will be assigned as featured images for posts.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Enable Featured Image Assignation:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="ai_featured_image" name="aiomatic_Spinner_Settings[ai_featured_image]" onchange="mainChanged2();"  >
                              <option value="enabled"<?php
                                 if ($ai_featured_image == "enabled") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="disabled"<?php
                                 if ($ai_featured_image == "disabled") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
        </div>
        </td></tr><tr class="hideMain2"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the source of the created featured images.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Featured Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="ai_featured_image_source" name="aiomatic_Spinner_Settings[ai_featured_image_source]" onchange="mainChangedImg();">
                              <option value="1"<?php
                                 if ($ai_featured_image_source == "1") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <?php
                                 if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                                 {
                                 ?>
                                 <option value="2"<?php
                                    if ($ai_featured_image_source == "2") {
                                        echo " selected";
                                    }
                                    ?>><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                                <?php
                                 }
                                 ?>
                              <option value="0"<?php
                                 if ($ai_featured_image_source == "0") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="3"<?php
                                    if ($ai_featured_image_source == "3") {
                                        echo " selected";
                                    }
                                    ?>><?php echo esc_html__("Manual URL List", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
        </div>
        </td></tr><tr class="hideMain2 hideMainAgain2"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set an prompt command you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). If you use Royalty Free Images as a source, you can also set their keywords here, if no keywords set, they will be automatically generated.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt To Send To The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_image_command]" placeholder="Please insert a command for the AI image generator"><?php
    echo esc_textarea($ai_image_command);
?></textarea>
        </div>
        </td></tr><tr class="hideMain2 hideMainAgain2"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the size of the generated featured image.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Generated Featured Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="image_size" name="aiomatic_Spinner_Settings[image_size]" >
                              <option value="256x256"<?php
                                 if ($image_size == "256x256") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("256x256 (only for Dall-E 2)", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"<?php
                                 if ($image_size == "512x512") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("512x512 (only for Dall-E 2 & Stable Diffusion)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="1024x1024"<?php
                                 if ($image_size == "1024x1024") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="1024x1792"<?php
                                 if ($image_size == "1024x1792") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("1024x1792 (only for Dall-E 3)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="1792x1024"<?php
                                 if ($image_size == "1792x1024") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("1792x1024 (only for Dall-E 3)", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
        </div>
        </td></tr>
        <tr class="hideImg hideMainAgain2"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the size of the generated featured image.", 'aiomatic-automatic-ai-content-writer');
?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
            </div>
            </td><td>
            <div>
            <select id="image_model" name="aiomatic_Spinner_Settings[image_model]">
                <option value="dalle2"<?php
                    if ($image_model == "dalle2") {
                        echo " selected";
                    }
                    ?>><?php echo esc_html__("Dall-E 2", 'aiomatic-automatic-ai-content-writer');?></option>
                <option value="dalle3"<?php
                    if ($image_model == "dalle3") {
                        echo " selected";
                    }
                    ?>><?php echo esc_html__("Dall-E 3", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="dalle3hd"<?php
                    if ($image_model == "dalle3hd") {
                        echo " selected";
                    }
                    ?>><?php echo esc_html__("Dall-E 3 HD", 'aiomatic-automatic-ai-content-writer');?></option>
            </select>
</div>
</td></tr><tr class="hideMain2 hideMainSecond2"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set a comma sepatated list of images to assign to posts. You can also use the AI to select the best matching image (basd on keywords from image name and URL).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Default Featured Image List:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[url_image_list]" placeholder="Image URL List"><?php
    echo esc_textarea($url_image_list);
?></textarea>
        </div>
        </td></tr><tr><td>
                    <h2><?php echo esc_html__("AI Content Completition Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will generate AI content, that will be prepended or appended to each post's content.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Add AI Generated Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="append_spintax" name="aiomatic_Spinner_Settings[append_spintax]" onchange="mainChanged3();" >
                              <option value="append"<?php
                                 if ($append_spintax == "append") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Append To The End", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="preppend"<?php
                                 if ($append_spintax == "preppend") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Prepend To The Beginning", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="disabled"<?php
                                 if ($append_spintax == "disabled") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
        </div>
        </td></tr>
                    <tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set an prompt command you want to send to the AI text generator. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%post_title%%, %%post_content%%, %%first_content_paragraph_plain_text%%, %%last_content_paragraph_plain_text%%, %%first_content_paragraph%%, %%last_content_paragraph%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt For The AI Text Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_command]" placeholder="Please insert a command for the AI"><?php
    echo esc_textarea($ai_command);
?></textarea>
        </div>
        </td></tr>
        <tr class="hideMain3">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="append_assistant_id" name="aiomatic_Spinner_Settings[append_assistant_id]" class="cr_width_full" onchange="assistantSelected('append_assistant_id', 'disableAppend');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($append_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($append_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr>
        <tr class="hideMain3"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select the AI Model you want to use.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model To Use:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="model" name="aiomatic_Spinner_Settings[model]" <?php if($append_assistant_id != ''){echo ' disabled';}?> class="disableAppend">
<?php
foreach($all_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
        </div>
                    </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set it 4000.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="1" step="1" max="128000" id="max_tokens" name="aiomatic_Spinner_Settings[max_tokens]" class="cr_450" value="<?php echo esc_html($max_tokens);?>" placeholder="Maximum Token Count To Spend on Each Request">
        </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set it 1000.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="1" step="1" max="128000" id="max_seed_tokens" name="aiomatic_Spinner_Settings[max_seed_tokens]" class="cr_450" value="<?php echo esc_html($max_seed_tokens);?>" placeholder="Maximum Prompt Token Count To Spend on Each Request">
        </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the maximum number of result API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set it 2048.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Result Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="1" step="1" max="2048" id="max_result_tokens" name="aiomatic_Spinner_Settings[max_result_tokens]" class="cr_450" value="<?php echo esc_html($max_result_tokens);?>" placeholder="Maximum Result Token Count To Spend on Each Request">
        </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set the maximum number of continue API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set it 2048.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Continue Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="1" step="1" max="2048" id="max_continue_tokens" name="aiomatic_Spinner_Settings[max_continue_tokens]" class="cr_450" value="<?php echo esc_html($max_continue_tokens);?>" placeholder="Maximum Result Continue Count To Spend on Each Request">
        </td></tr><tr class="hideMain3"><td colspan="2">
                    <h2><?php echo esc_html__("Advanced API Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
                    
                    </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Content Writer Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" id="temperature" name="aiomatic_Spinner_Settings[temperature]" class="cr_450" value="<?php echo esc_html($temperature);?>" placeholder="1">
        </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Content Writer Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="0.1" max="1" id="top_p" name="aiomatic_Spinner_Settings[top_p]" class="cr_450" value="<?php echo esc_html($top_p);?>" placeholder="1">
        </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="-2" step="0.1" max="2" id="presence_penalty" name="aiomatic_Spinner_Settings[presence_penalty]" class="cr_450" value="<?php echo esc_html($presence_penalty);?>" placeholder="0">
        </td></tr><tr class="hideMain3"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="-2" step="0.1" max="2" id="frequency_penalty" name="aiomatic_Spinner_Settings[frequency_penalty]" class="cr_450" value="<?php echo esc_html($frequency_penalty);?>" placeholder="0">
        </td></tr><tr class="hideMain3"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo sprintf( wp_kses( __( "Select the minimum number of characters that the content additional content should have. If the API returns content which has fewer characters than this number, another API call will be made, until this character limit is met. Please check about API rate limiting <a href='%s'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://beta.openai.com/docs/api-reference/introduction' );
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Created Content Minimum Character Count:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" min="1" step="1" name="aiomatic_Spinner_Settings[min_char]" value="<?php echo esc_html($min_char);?>" placeholder="Please insert a minimum number of characters for posts" class="cr_width_full">
        </div>
        </td></tr><tr class="hideMain3"><td colspan="2">
                    <h2><?php echo esc_html__("Rich Content Creation Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr class="hideMain3">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set the maximum number of related headings to add to the created post content. This feature will use the 'People Also Ask' feature from Google and Bing. By default, the Bing engine is scraped, if you want to enable also Google scraping, add a SerpAPI key in the plugin's 'Main Settings' menu -> 'SerpAPI API Key' settings field.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Number Of Related Headings to Add To The Content:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="number" min="0" name="aiomatic_Spinner_Settings[headings]" value="<?php echo esc_html($headings);?>" placeholder="Max heading count" class="cr_width_full">
            </td>
            </tr>
        <tr class="hideMain3">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="headings_assistant_id" name="aiomatic_Spinner_Settings[headings_assistant_id]" class="cr_width_full" onchange="assistantSelected('headings_assistant_id', 'disableHeadings');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($headings_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($headings_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr>
            <tr class="hideMain3">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Select the AI Model to be used for headings generator.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model For The Headings Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <select id="headings_model" name="aiomatic_Spinner_Settings[headings_model]" <?php if($headings_assistant_id != ''){echo ' disabled';}?> class="cr_width_full disableHeadings">
            <?php
foreach($all_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($headings_model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
            </select>  
            </td>
            </tr>
            <tr class="hideMain3">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set the prompt you will use when searching for related headings. You can use the following shortcodes: %%post_title%%, %%needed_heading_count%%. The same model will be used, as the one selected for content creation. If you leave this field blank, the default prompt will be used: 'Write %%needed_heading_count%% PAA related questions, each on a new line, for the title: %%post_title%%'", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt For The AI Related Headings Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <textarea rows="2" cols="70" name="aiomatic_Spinner_Settings[headings_ai_command]" placeholder="Write %%needed_heading_count%% PAA related questions, each on a new line, for the title: %%post_title%%" class="cr_width_full"><?php echo esc_textarea($headings_ai_command);?></textarea>
            </td>
            </tr>
            <tr class="hideMain3">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set the maximum number of related images to add to the created post content. This feature will use the 'Royalty Free Image' settings from the plugin's 'Main Settings' menu.'", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Number Of Related Images to Add To The Content:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="number" min="0" name="aiomatic_Spinner_Settings[images]" value="<?php echo esc_html($images);?>" placeholder="Max image count" class="cr_width_full">
            </td>
            </tr>
            <tr class="hideMain3">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Do you want to replace the royalty free image with an AI generated image?", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <select id="enable_ai_images" name="aiomatic_Spinner_Settings[enable_ai_images]" class="cr_width_full">
            <option value="1"<?php
    if ($enable_ai_images == '1' || $enable_ai_images == 'on')
        echo ' selected ';
?>><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
            <?php
            if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
            {
            ?>
            <option value="2"<?php
    if ($enable_ai_images == '2')
        echo ' selected ';
?>><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
            <?php
            }
            ?>
            <option value="0"<?php
    if ($enable_ai_images == '0' || $enable_ai_images == '')
        echo ' selected ';
?>><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
        </select>
            </td>
            </tr>
            <tr class="hideMain3">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Add a related YouTube video to the end of to the created post content. This feature will require you to add at least one YouTube API key in the plugin's 'Main Settings' -> 'YouTube API Key List' settings field.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Add A Related Video To The End Of The Post:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="checkbox" id="videos" name="aiomatic_Spinner_Settings[videos]"<?php
    if ($videos == 'on')
        echo ' checked ';
?>>
            </td>
            </tr><tr><td>
                    <h2><?php echo esc_html__("Post Content Automatic Linking Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will automatically add automatic links to other posts from your site, to keywords from each post.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Automatically Add Links To Posts:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="add_links" name="aiomatic_Spinner_Settings[add_links]" onchange="mainChanged4();" >
                        <option value="disabled"<?php
                            if ($add_links == "disabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="enabled"<?php
                            if ($add_links == "enabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                    </select>
        </div>
        </td></tr>
        <tr class="hideMain4">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking. The default value for this settings field is 3-5", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" id="max_links" name="aiomatic_Spinner_Settings[max_links]" placeholder="3-5" class="cr_width_full" value="<?php echo esc_attr($max_links);?>">
            </td>
        </tr>
        <tr class="hideMain4">
        <td>
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                    <div class="bws_hidden_help_text cr_min_260px">
                    <?php
                        echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                        ?>
                    </div>
                </div>
                <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td>
        <select autocomplete="off" class="cr_width_full" id="link_type" onchange="hideLinks();" name="aiomatic_Spinner_Settings[link_type]">
        <option value="internal"<?php
                            if ($link_type == "internal") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
        <option value="manual"<?php
                            if ($link_type == "manual") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
        <option value="mixed"<?php
                            if ($link_type == "mixed") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Mixed Links", 'aiomatic-automatic-ai-content-writer');?></option>
        </select>   
        </td>
        </tr>
        <tr class="hideMain4 hidelinks">
        <td class="cr_min_width_200">
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                    <div class="bws_hidden_help_text cr_min_260px">
                    <?php
                        echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                        ?>
                    </div>
                </div>
                <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td>
        <textarea rows="1" cols="70" name="aiomatic_Spinner_Settings[link_list]" placeholder="URL list (one per line)" class="cr_width_full"><?php echo esc_textarea($link_list);?></textarea>
        </td>
        </tr>
        <tr class="hideMain4 hidelinks">
        <td class="cr_min_width_200">
                <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                    <div class="bws_hidden_help_text cr_min_260px">
                    <?php
                        echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                        ?>
                    </div>
                </div>
                <b><?php echo esc_html__("Add Nofollow Attribute To Manual Links:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td>
                    <input type="checkbox" id="link_nofollow" name="aiomatic_Spinner_Settings[link_nofollow]"<?php
    if ($link_nofollow == 'on')
        echo ' checked ';
?>>
        </td>
        </tr>
        <tr class="hideMain4">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Post Types Where To Generate Inboud Links:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" id="link_post_types" name="aiomatic_Spinner_Settings[link_post_types]" placeholder="post" class="cr_width_full" value="<?php echo esc_attr($link_post_types);?>">
            </td>
        </tr>
        <tr><td>
                    <h2><?php echo esc_html__("Post Automatic Categories Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will automatically add categories to posts from your site.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Automatically Add Categories To Posts:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="add_cats" name="aiomatic_Spinner_Settings[add_cats]" onchange="mainChanged7();" >
                        <option value="disabled"<?php
                            if ($add_cats == "disabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="enabled"<?php
                            if ($add_cats == "enabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                    </select>
        </div>
        </td></tr>
        <tr class="hideMain7">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Maximum number of categories to add. You can also use value ranges, like: 3-5. The default value is 1-2", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Number Of Categories To Add To The Post:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" id="max_cats" name="aiomatic_Spinner_Settings[max_cats]" placeholder="1-2" class="cr_width_full" value="<?php echo esc_attr($max_cats);?>">
            </td>
        </tr>
        <tr class="hideMain7"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("This option will make the plugin not create categories which are not already existing on your site. For best results in this case, be sure to add to the prompt the list of categories from where the AI should select.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Do Not Add Inexistent Categories:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="checkbox" id="skip_inexist" name="aiomatic_Spinner_Settings[skip_inexist]"<?php
    if ($skip_inexist == 'on')
        echo ' checked ';
?>>
        </td></tr>
        <tr class="hideMain7"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set an prompt command you want to send to the AI category generator. This command can be any given task or order, based on which, it will generate categories for posts. You can use the following shortcodes here: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt For The AI Category Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_cats]" placeholder="Write a comma separated list of 5 categories for post title: %%post_title%%"><?php
    echo esc_textarea($ai_cats);
?></textarea>
        </div>
        </td></tr>
        <tr class="hideMain7">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="categories_assistant_id" name="aiomatic_Spinner_Settings[categories_assistant_id]" class="cr_width_full" onchange="assistantSelected('categories_assistant_id', 'disableCategories');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($categories_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($categories_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr>
            <tr class="hideMain7">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Select the AI Model to be used for categories generator.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model For The Categories Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <select id="cats_model" name="aiomatic_Spinner_Settings[cats_model]" <?php if($categories_assistant_id != ''){echo ' disabled';}?> class="disableCategories cr_width_full">
            <?php
foreach($all_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($cats_model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
            </select>  
            </td>
            </tr>
        <tr><td>
                    <h2><?php echo esc_html__("Post Automatic Tags Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will automatically add tags to posts from your site.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Automatically Add Tags To Posts:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="add_tags" name="aiomatic_Spinner_Settings[add_tags]" onchange="mainChanged8();" >
                        <option value="disabled"<?php
                            if ($add_tags == "disabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="enabled"<?php
                            if ($add_tags == "enabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                    </select>
        </div>
        </td></tr>
        <tr class="hideMain8">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Maximum number of tags to add. You can also use value ranges, like: 3-5. The default value is 1-2", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Number Of Tags To Add To The Post:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" id="max_tags" name="aiomatic_Spinner_Settings[max_tags]" placeholder="1-2" class="cr_width_full" value="<?php echo esc_attr($max_tags);?>">
            </td>
        </tr>
        <tr class="hideMain8"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("This option will make the plugin not create tags which are not already existing on your site. For best results in this case, be sure to add to the prompt the list of tags from where the AI should select.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Do Not Add Inexistent Tags:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="checkbox" id="skip_inexist_tags" name="aiomatic_Spinner_Settings[skip_inexist_tags]"<?php
    if ($skip_inexist_tags == 'on')
        echo ' checked ';
?>>
        </td></tr>
        <tr class="hideMain8"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set an prompt command you want to send to the AI tag generator. This command can be any given task or order, based on which, it will generate tags for posts. You can use the following shortcodes here: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt For The AI Tags Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_tags]" placeholder="Write a comma separated list of 5 tags for post title: %%post_title%%"><?php
    echo esc_textarea($ai_tags);
?></textarea>
        </div>
        </td></tr>
        <tr class="hideMain8">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="tags_assistant_id" name="aiomatic_Spinner_Settings[tags_assistant_id]" class="cr_width_full" onchange="assistantSelected('tags_assistant_id', 'disableTags');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($tags_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($tags_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr>
            <tr class="hideMain8">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Select the AI Model to be used for tags generator.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model For The Tags Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <select id="tags_model" name="aiomatic_Spinner_Settings[tags_model]" <?php if($tags_assistant_id != ''){echo ' disabled';}?> class="disableTags cr_width_full">
            <?php
foreach($all_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($tags_model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
            </select>  
            </td>
            </tr>
        <tr><td>
                    <h2><?php echo esc_html__("Post Automatic Commenting Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will automatically add comments to posts from your site.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Automatically Add Comments To Posts:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="add_comments" name="aiomatic_Spinner_Settings[add_comments]" onchange="mainChanged5();" >
                        <option value="disabled"<?php
                            if ($add_comments == "disabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="enabled"<?php
                            if ($add_comments == "enabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                    </select>
        </div>
        </td></tr>
        <tr class="hideMain5">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Maximum number of comments to add. You can also use value ranges, like: 3-5. The default value is 1-2", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Maximum Number Of Comments To Add To The Post:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" id="max_comments" name="aiomatic_Spinner_Settings[max_comments]" placeholder="1-2" class="cr_width_full" value="<?php echo esc_attr($max_comments);?>">
            </td>
        </tr>
        <tr class="hideMain5"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set an prompt command you want to send to the AI comment generator. This command can be any given task or order, based on which, it will generate comments for posts. You can use the following shortcodes here: %%previous_comments%%, %%post_title%%, %%comment_author_name%%, %%comment_author_email%%, %%comment_author_url%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt For The AI Comment Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_comments]" placeholder="Please insert a command for the AI"><?php
    echo esc_textarea($ai_comments);
?></textarea>
        </div>
        </td></tr>
        <tr class="hideMain5">
            <td class="cr_min_width_200">
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Maximum number of comments to add to the %%previous_comments%% shortcode, The default value is 5", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("%%previous_comments%% Shortcode Comment Count:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="number" min="0" step="1" id="prev_comms" name="aiomatic_Spinner_Settings[prev_comms]" placeholder="5" class="cr_width_full" value="<?php echo esc_attr($prev_comms);?>">
            </td>
        </tr>
        <tr class="hideMain5">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="comments_assistant_id" name="aiomatic_Spinner_Settings[comments_assistant_id]" class="cr_width_full" onchange="assistantSelected('comments_assistant_id', 'disableComments');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($comments_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($comments_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr>
            <tr class="hideMain5">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Select the AI Model to be used for comments generator.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model For The Comments Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <select id="comments_model" name="aiomatic_Spinner_Settings[comments_model]" <?php if($comments_assistant_id != ''){echo ' disabled';}?> class="disableComments cr_width_full">
            <?php
foreach($all_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($comments_model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
            </select>  
            </td>
            </tr>
               <tr class="hideMain5">
                  <td>
                     <div>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo esc_html__("Input a list of user names that the plugin will use when submitting comments. One per line. If you leave this field empty, a random name will be generated. Possible shortcode that can be used here: %%random_user%%, %%author_name%%, %%random_sentence%%, %%random_sentence2%%", 'aiomatic-automatic-ai-content-writer');
                                 ?>
                           </div>
                        </div>
                        <b><?php echo esc_html__("Comment User Name List:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </div>
                  </td>
                  <td>
                     <div>
                        <textarea rows="4" name="aiomatic_Spinner_Settings[user_list]" placeholder="Insert a list of user names to use when submitting comments (one per line)"><?php
                           echo esc_textarea($user_list);
                           ?></textarea>
                     </div>
                  </td>
               </tr>
               <tr class="hideMain5">
                  <td>
                     <div>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo esc_html__("Input a list of e-mails that the plugin will use when submitting comments. One per line. If you leave this field empty, a random email will be generated. Possible shortcode that can be used here: %%random_sentence%%, %%random_sentence2%%", 'aiomatic-automatic-ai-content-writer');
                                 ?>
                           </div>
                        </div>
                        <b><?php echo esc_html__("Comment E-mail List:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </div>
                  </td>
                  <td>
                     <div>
                        <textarea rows="4" name="aiomatic_Spinner_Settings[email_list]" placeholder="Insert a list of e-mails to use when submitting comments (one per line)"><?php
                           echo esc_textarea($email_list);
                           ?></textarea>
                     </div>
                  </td>
               </tr>
               <tr class="hideMain5">
                  <td>
                     <div>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">
                              <?php
                                 echo esc_html__("Input a list of URLs that the plugin will use when submitting comments. One per line. Possible shortcode that can be used here: %%post_link%%, %%random_sentence%%, %%random_sentence2%%", 'aiomatic-automatic-ai-content-writer');
                                 ?>
                           </div>
                        </div>
                        <b><?php echo esc_html__("Comment URL List:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </div>
                  </td>
                  <td>
                     <div>
                        <textarea rows="4" name="aiomatic_Spinner_Settings[url_list]" placeholder="Insert a list of URLs to use when submitting comments (one per line)"><?php
                           echo esc_textarea($url_list);
                           ?></textarea>
                     </div>
                  </td>
               </tr>
               <tr><td>
                    <h2><?php echo esc_html__("SEO Meta Description Options:", 'aiomatic-automatic-ai-content-writer');?></h2>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("The plugin will automatically add AI generated SEO meta descriptions to posts from your site.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b class="wpaiomatic-delete"><?php echo esc_html__("Automatically Add AI Generated SEO Description To Posts:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="add_seo" name="aiomatic_Spinner_Settings[add_seo]" onchange="mainChanged6();" >
                        <option value="disabled"<?php
                            if ($add_seo == "disabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="enabled"<?php
                            if ($add_seo == "enabled") {
                                echo " selected";
                            }
                            ?>><?php echo esc_html__("Enabled", 'aiomatic-automatic-ai-content-writer');?></option>
                    </select>
        </div>
        </td></tr>
        <tr class="hideMain6"><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Set an prompt command you want to send to the AI SEO meta description generator. This command can be any given task or order, based on which, it will generate comments for posts. You can use the following shortcodes here: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. You can also use custom fields (post meta) that it's assigned to posts using custom shortcodes in this format: %%!custom_field_slug!%%. You can also use custom user meta fields (user meta) which is assigned to usersm using custom shortcodes in this format: %%~custom_field_slug~%%. Example: if you wish to add data that is imported from the custom field post_data, you should use this shortcode: %%!post_data!%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). The default value is: Write a SEO meta description for the post title: %%post_title%%", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Prompt For The AI SEO Meta Description Generator:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[ai_seo]" placeholder="Please insert a command for the AI"><?php
    echo esc_textarea($ai_seo);
?></textarea>
        </div>
        </td></tr>
        <tr class="hideMain6">
        <td class="cr_min_width_200">
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                <div class="bws_hidden_help_text cr_min_260px">
                <?php
                    echo esc_html__("Select the AI Assistant to be used. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                    ?>
                </div>
            </div>
            <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
        </td>
        <td><select id="meta_assistant_id" name="aiomatic_Spinner_Settings[meta_assistant_id]" class="cr_width_full" onchange="assistantSelected('meta_assistant_id', 'disableMeta');">
    <?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value=""';
        if($meta_assistant_id == '')
        {
            echo ' selected';
        }
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . $myassistant->ID .'"';
            if($meta_assistant_id == $myassistant->ID)
            {
                echo ' selected';
            }
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
        </td>
        </tr><tr class="hideMain6">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Select the AI Model to be used for AI SEO Meta Description Generator.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("AI Model For The AI SEO Meta Description Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <select id="seo_model" name="aiomatic_Spinner_Settings[seo_model]" <?php if($meta_assistant_id != ''){echo ' disabled';}?> class="disableMeta cr_width_full">
            <?php
foreach($all_models as $modelx)
{
   echo '<option value="' . $modelx .'"';
   if ($seo_model == $modelx) 
   {
       echo " selected";
   }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
            </select>  
            </td>
            </tr><tr class="hideMain6">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set if you want to limit the AI generated meta description length.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Limit AI Generated Meta Description Character Count:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <input type="number" min="0" step="1" id="seo_max_char" name="aiomatic_Spinner_Settings[seo_max_char]" class="cr_450" value="<?php echo esc_html($seo_max_char);?>" placeholder="Maximum character length">
            </td>
            </tr><tr class="hideMain6">
            <td>
                <div>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                            echo esc_html__("Set if you want to copy meta description from post excerpt, instead of creating it. Note that this will disable the AI generator of the SEO meta.", 'aiomatic-automatic-ai-content-writer');
                            ?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Copy Meta Description From Post Excerpt Instead Of Generating It:", 'aiomatic-automatic-ai-content-writer');?></b>   
            </td>
            <td class="cr_min_width_200">
            <input type="checkbox" id="seo_copy_excerpt" name="aiomatic_Spinner_Settings[seo_copy_excerpt]"<?php
    if ($seo_copy_excerpt == 'on')
        echo ' checked ';
?>>
            </td>
            </tr>
        <tr><td colspan="2">
                    <h2><?php echo esc_html__("Extra Features:", 'aiomatic-automatic-ai-content-writer');?></h2>
                    
                    </td></tr>
                    <tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select if you want to change post status after editing posts.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Change Post Status After Editing:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <select id="change_status" name="aiomatic_Spinner_Settings[change_status]" class="cr_width_full">
                    <option value="no" 
<?php
if ($change_status == 'no' || $change_status == '') 
{
    echo " selected";
}
?>
><?php echo esc_html__("No Change", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="pending"<?php
if ($change_status == 'pending') 
{
    echo " selected";
}
?>><?php echo esc_html__("Pending", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="draft"<?php
if ($change_status == 'draft') 
{
    echo " selected";
}
?>><?php echo esc_html__("Draft", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="publish"<?php
if ($change_status == 'publish') 
{
    echo " selected";
}
?>><?php echo esc_html__("Published", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="private"<?php
if ($change_status == 'private') 
{
    echo " selected";
}
?>><?php echo esc_html__("Private", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="trash"<?php
if ($change_status == 'trash') 
{
    echo " selected";
}
?>><?php echo esc_html__("Trash", 'aiomatic-automatic-ai-content-writer');?></option>
                    </select>
        </div>
        </td></tr>
        </table>
        </div>
        <div id="tab-3" class="tab-content">            
    <table class="widefat">
    <tr>
    <td>
        <h1><span class="gs-sub-heading"><b><?php echo esc_html__("Enabled Posts Automatic Editing:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Enable or disable automatic post modifications every time you publish a new post (manually or automatically).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div></h1>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="aiomatic_spinning" name="aiomatic_Spinner_Settings[aiomatic_spinning]"<?php
    if ($aiomatic_spinning == 'on')
        echo ' checked ';
?>>
                            <label for="aiomatic_spinning"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    <hr/>
            <table class="widefat">
            <tr><td colspan="2">
<?php
    echo esc_html__("INFO: You can change the way the posts are edited by changing settings in the 'Editing Templates and Options' tab from above!", 'aiomatic-automatic-ai-content-writer');
?>
</td></tr>
                    <tr><td colspan="2">
                    <h2><?php echo esc_html__("Posts Automatic Editing Filtering:", 'aiomatic-automatic-ai-content-writer');?></h2>
                    
                    </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Select when do you want to automatically process posts.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Automatically Process Posts When They Are:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                     <select id="process_event" name="aiomatic_Spinner_Settings[process_event]">
                     <option value="publish"<?php
                        if ($process_event == "publish") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Published", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="draft"<?php
                        if ($process_event == "draft") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Drafted", 'aiomatic-automatic-ai-content-writer');?></option>
                    <option value="pending"<?php
                        if ($process_event == "pending") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Pending", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Do you want delay automatic editing of the posted article with this amount of seconds from post publish? This will create a single cron job for each post (cron is a requirement for this to function). If you leave this field blank, posts will be automatically spun on post publish.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Delay Article Editing By (Seconds):", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="number" min="0" step="1" id="delay_post" name="aiomatic_Spinner_Settings[delay_post]" class="cr_450" value="<?php echo esc_html($delay_post);?>" placeholder="Delay editing by X seconds">
        </td></tr><tr class="hidethis"><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("This option will allow you to select if you want to run posting in async mode. This means that each time you publish a post, the plugin will try to execute it's task in the background - it will no longer block new post posting, while it finishes it's job.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Use Async Posting Method:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="checkbox" id="run_background" name="aiomatic_Spinner_Settings[run_background]"<?php
    if ($run_background == 'on')
        echo ' checked ';
?>>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Do you want to disable automatically editing of WordPress 'posts'?", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Disable Editing of 'Posts':", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="checkbox" id="post_posts" name="aiomatic_Spinner_Settings[post_posts]"<?php
    if ($post_posts == 'on')
        echo ' checked ';
?>>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Do you want to disable automatically editing of WordPress 'pages'?", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Disable Editing of 'Pages':", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="checkbox" id="post_pages" name="aiomatic_Spinner_Settings[post_pages]"<?php
    if ($post_pages == 'on')
        echo ' checked ';
?>>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Do you want to disable automatically editing of WordPress 'custom post types'?", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Disable Editing of 'Custom Post Types':", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="checkbox" id="post_custom" name="aiomatic_Spinner_Settings[post_custom]"<?php
    if ($post_custom == 'on')
        echo ' checked ';
?>>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("If you checked the above checkbox to disable processing of custom post types, you can define here a comma separated list of posts types which should still be process (excepted from skipping).", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Excepting This Comma Separated List Of Custom Post Types:", 'aiomatic-automatic-ai-content-writer');?></b>
                    
                    </td><td>
                    <input type="text" id="except_type" name="aiomatic_Spinner_Settings[except_type]" value="<?php echo esc_html($except_type);?>" placeholder="Excepted custom post types">
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Do you want to disable automatically editing of WordPress categories?", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Disable Editing of Selected Categories:", 'aiomatic-automatic-ai-content-writer');?></b><br/>
                    <a onclick="toggleCats()" class="cr_pointer"><?php echo esc_html__("Show/Hide Categories List", 'aiomatic-automatic-ai-content-writer');?></a>
                    </td><td>
                    <br/>
                    <div id="hideCats" class="hideCats">
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($aiomatic_Spinner_Settings['disabled_categories']) && !empty($aiomatic_Spinner_Settings['disabled_categories'])) {
            checked(true, in_array($category->term_id, $aiomatic_Spinner_Settings['disabled_categories']));
        }
?>
 type="checkbox" name="aiomatic_Spinner_Settings[disabled_categories][]" value="<?php
        echo esc_html($category->term_id);
?>" /> 
														<span><?php
        echo esc_html(sanitize_text_field($category->name));
?></span>
													</label>
												</div>
<?php
    }
?>

        </div>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                        <div class="bws_hidden_help_text cr_min_260px">
<?php
    echo esc_html__("Input the tags for which you want to disable editing. You can enter more tags, separated by comma. Ex: cars, vehicles, red, luxury. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
?>
                        </div>
                    </div>
                    <b><?php echo esc_html__("Disable Editing of Selected Tags:", 'aiomatic-automatic-ai-content-writer');?></b>
                    </div>
                    </td><td>
                    <div>
                    <textarea rows="1" name="aiomatic_Spinner_Settings[disable_tags]" placeholder="Please insert the tags for which you want to disable editing"><?php
    echo esc_textarea($disable_tags);
?></textarea>
        </div>
        </td></tr>
                    </table>
</div>
        <div id="tab-4" class="tab-content">            
        <table class="widefat">
                  <tr>
                     <td colspan="3">
                        <h2>
                        <?php echo esc_html__("Existing Content Editor:", 'aiomatic-automatic-ai-content-writer');?></h3>
                        <div class="crf_bord cr_color_red cr_width_full"><?php echo esc_html__('Bulk post editing might consume a large number of AI model tokens to complete! Be sure you check', 'aiomatic-automatic-ai-content-writer') . '&nbsp;<a href="https://openai.com/pricing" target="_blank">' .  esc_html__('token pricing', 'aiomatic-automatic-ai-content-writer') . '</a>&nbsp;' .  esc_html__('before you continue. You can filter which posts you need edited. Doing a general site backup is also recommended before doing bulk content editing.', 'aiomatic-automatic-ai-content-writer');?></div>
                     </td>
                  </tr>
                  <tr><td colspan="2">
<?php
    echo esc_html__("INFO: You can change the way the posts are edited by changing settings in the 'Editing Templates and Options' tab from above! Also, be sure to save settings before running bulk post editing!", 'aiomatic-automatic-ai-content-writer');
?>
</td></tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to run manual post editing, now? Please check configuration from below before clicking 'Run Post Editing'.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Manually Run Post Editing Now:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td class="cr_min_100 cr_center">
                     <img id="run_img" src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'images/running.gif');?>" alt="Running" class="cr_hidden cr_align_middle" title="status">
                     </td>
                     <td>
                     <div class="codemainfzr">
                     <select id="actions" class="actions" name="aiomatic_bulk_actions" onchange="actionsChangedManual(this.value);" onfocus="this.selectedIndex = 0;">
                     <option value="select" disabled selected><?php echo esc_html__("Select an Action", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="run"><?php echo esc_html__("Run Post Editing", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select>
                     </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Select the way you want to schedule automatic editing of existing posts from your site, using the below settings.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Automatic Editing Of Existing Posts:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td colspan="2">
                     <select id="auto_edit" class="cr_width_full" onchange="aiomatic_edit_changed();" name="aiomatic_Spinner_Settings[auto_edit]" >
                     <option value="disabled"<?php
                        if ($auto_edit == "disabled") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="wp"<?php
                        if ($auto_edit == "wp") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("WordPress Cron Job", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="external"<?php
                        if ($auto_edit == "external") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("External Cron Job", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select> 
                     </td>
                  </tr>
                  <tr class="hidewp">
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Choose how often you want to automatically check for old posts. This will change the cron scheduling time.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Plugin Autorun Interval:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </div>
                     </td>
                     <td colspan="2">
                        <div >
                           <select class="cr_width_full" id="auto_run_interval" name="aiomatic_Spinner_Settings[auto_run_interval]" >
                              <option value="No"<?php
                                 if ($auto_run_interval == "No") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="monthly"<?php
                                 if ($auto_run_interval == "monthly") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once a month", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="weekly"<?php
                                 if ($auto_run_interval == "weekly") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once a week", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="daily"<?php
                                 if ($auto_run_interval == "daily") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once a day", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="twicedaily"<?php
                                 if ($auto_run_interval == "twicedaily") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Twice a day", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="hourly"<?php
                                 if ($auto_run_interval == "hourly") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once an hour", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="aiomatic_cron_half"<?php
                                 if ($auto_run_interval == "aiomatic_cron_half") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once 30 minutes", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="aiomatic_cron_sfert"<?php
                                 if ($auto_run_interval == "aiomatic_cron_sfert") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once 15 minutes", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="aiomatic_cron_ten"<?php
                                 if ($auto_run_interval == "aiomatic_cron_ten") {
                                     echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Once 10 minutes", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                        </div>
                     </td>
                  </tr>
                    <tr class="hideexternal">
                        <td>
                        <div>
                            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                    echo esc_html__("Select a secret word that will be used when you run the post editing part of the plugin manually by URL/by cron. See details about this below.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                                </div>
                            </div>
                            <b><?php echo esc_html__("Secret Word Used For Cron Running (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td colspan="2">
                        <input type="text" id="secret_word" name="aiomatic_Spinner_Settings[secret_word]" value="<?php echo esc_html($secret_word);?>" placeholder="<?php echo esc_html__("Input a secret word", 'aiomatic-automatic-ai-content-writer');?>">
                        </div>
                        </td>
                    </tr>
                    <tr class="hideexternal">
                        <td colspan="3">
                        <div>
                            <br/><b><?php echo esc_html__("If you want to schedule the cron event manually in your server, to allow recurring editing of existing posts on your site, you should schedule this address:", 'aiomatic-automatic-ai-content-writer');?> <span class="cr_red"><?php if($secret_word != '') { echo get_site_url() . '/?run_aiomatic_edit=' . urlencode($secret_word);} else { echo esc_html__('You must enter a secret word above, to use this feature.', 'aiomatic-automatic-ai-content-writer'); }?></span><br/><?php if($secret_word != '') { echo esc_html__("Example:", 'aiomatic-automatic-ai-content-writer') . '&nbsp;<span class="cr_red">15,45****wget -q -O /dev/null ' . get_site_url() . '/?run_aiomatic_edit=' . urlencode($secret_word) . '</span>';}?></b>
                        </div>
                        <br/><br/>
                        </td>
                    </tr>
               </table>
               <br/>
               <table class="widefat">
                  <tr>
                     <td colspan="2">
                        <h2>
                        <?php echo esc_html__("Bulk AI Editing Settings:", 'aiomatic-automatic-ai-content-writer');?></h3>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the maximum number of posts to be processed at each run.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Maximum Number Of Posts To Process:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                           <input type="number" id="max_nr" step="1" min="1" placeholder="Maximum Post Count" name="aiomatic_Spinner_Settings[max_nr]" value="<?php echo esc_html($max_nr);?>"/>
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Select if you don't want to process the same post twice using bulk post editing.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Don't Process Same Post Twice:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                        <input type="checkbox" onchange="sameChanged();" id="no_twice" name="aiomatic_Spinner_Settings[no_twice]"<?php
    if ($no_twice == 'on')
        echo ' checked ';
?>>
                        </div>
                     </td>
                  </tr>
                  <tr class="hideField">
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Set the name of the custom field which will be set to posts which were already edited. Changing this can be useful if you want to reedit already edited posts. The default is: aiomatic_published", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Duplicate Checking Custom Field Name (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                        </div>
                     </td>
                     <td>
                        <div>
                     <input type="text" id="custom_name" name="aiomatic_Spinner_Settings[custom_name]" value="<?php echo esc_html($custom_name);?>" placeholder="Optional">
                        </div>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <hr/>
                     </td>
                     <td>
                        <hr/>
                     </td>
                  </tr>
                  <tr>
                     <td colspan="2">
                        <h3><?php echo esc_html__("Which Posts Should Bulk AI Editing Affect:", 'aiomatic-automatic-ai-content-writer');?></h3>
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int,int,int) - use author id [use minus (-) to exclude authors by ID ex. -1,-2,-3]", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Author IDs:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="author_id" name="aiomatic_Spinner_Settings[author_id]" value="<?php echo esc_html($author_id);?>" placeholder="Author IDs">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - use 'user_nicename' (NOT name)", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Author Names:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="author_name" name="aiomatic_Spinner_Settings[author_name]" value="<?php echo esc_html($author_name);?>" placeholder="Author names">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string,string,string) - use category slugs instead of names. ", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Category Names:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="category_name" name="aiomatic_Spinner_Settings[category_name]" value="<?php echo esc_html($category_name);?>" placeholder="Category names">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string,string,string) - use tag slugs instead of names. ", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Tag Names:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="tag_name" name="aiomatic_Spinner_Settings[tag_name]" value="<?php echo esc_html($tag_name);?>" placeholder="Tag names">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Comma separated list of post IDs to edit.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Post IDs:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="post_id" name="aiomatic_Spinner_Settings[post_id]" value="<?php echo esc_html($post_id);?>" placeholder="Post ID">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - use post slug.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Post Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="post_name" name="aiomatic_Spinner_Settings[post_name]" value="<?php echo esc_html($post_name);?>" placeholder="Post name">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - use page id.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Page ID:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="page_id" name="aiomatic_Spinner_Settings[page_id]" value="<?php echo esc_html($page_id);?>" placeholder="Page ID">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - use page slug.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Page Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="pagename" name="aiomatic_Spinner_Settings[pagename]" value="<?php echo esc_html($pagename);?>" placeholder="Page name">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - use page id. Return just the child Pages.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Post Parent:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="post_parent" name="aiomatic_Spinner_Settings[post_parent]" value="<?php echo esc_html($post_parent);?>" placeholder="Post parent ID">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string,string) - The post types to return. Valid values are: post, page, revision, attachment, other-custom-post-types. To match any post type enter the keyword: any. The default is post (if left empty).", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Post Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="type_post" name="aiomatic_Spinner_Settings[type_post]" value="<?php echo esc_html($type_post);?>" placeholder="Post type">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - The post status to return. Valid values are:  publish, pending, draft, auto-draft, future, private, inherit, trash, other-custom-post-statuses", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Post Status:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="post_status" name="aiomatic_Spinner_Settings[post_status]" value="<?php echo esc_html($post_status);?>" placeholder="Post status">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - number of post to alter. Use 'posts_per_page'=-1 to alter all posts.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Maximum Posts To Change:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="number" min="-1" step="1" id="max_posts" name="aiomatic_Spinner_Settings[max_posts]" value="<?php echo esc_html($max_posts);?>" placeholder="Max posts">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - number of post to displace or pass over.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Search Offset:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="number" min="-1" step="1" id="search_offset" name="aiomatic_Spinner_Settings[search_offset]" value="<?php echo esc_html($search_offset);?>" placeholder="Post offset">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - Custom field key.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Meta Key Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="meta_name" name="aiomatic_Spinner_Settings[meta_name]" value="<?php echo esc_html($meta_name);?>" placeholder="Meta Key Name">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - Custom field value.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Meta Key Value:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="meta_value" name="aiomatic_Spinner_Settings[meta_value]" value="<?php echo esc_html($meta_value);?>" placeholder="Meta Key Value">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo sprintf( wp_kses( __( "(string) - Passes along the query string variable from a search. For example usage see: <a href='%s' target='_blank'>this link</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'http://www.wprecipes.com/how-to-display-the-number-of-results-in-wordpress-search' );
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Search Query:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="text" id="search_query" name="aiomatic_Spinner_Settings[search_query]" value="<?php echo esc_html($search_query);?>" placeholder="Search query">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - 4 digit year (e.g. 2011).", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Year Query:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="number" min="0" step="1" id="year" name="aiomatic_Spinner_Settings[year]" value="<?php echo esc_html($year);?>" placeholder="Year">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - Month number (from 1 to 12).", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Month Query:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="number" min="1" max="12" step="1" id="month" name="aiomatic_Spinner_Settings[month]" value="<?php echo esc_html($month);?>" placeholder="Month">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(int) - Day of the month (from 1 to 31).", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Day Query:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="number" min="1" max="31" step="1" id="day" name="aiomatic_Spinner_Settings[day]" value="<?php echo esc_html($day);?>" placeholder="Day">
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Select which posts should be processed - posts with or without featured images.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Featured Image Status:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <select id="featured_image" name="aiomatic_Spinner_Settings[featured_image]" >
                     <option value="any"<?php
                        if ($featured_image == "any") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Any", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="with"<?php
                        if ($featured_image == "with") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("With Featured Images", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="without"<?php
                        if ($featured_image == "without") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Without Featured Images", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select> 
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - Designates the ascending or descending order of the 'orderby' parameter. Defaultto 'DESC'.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Order Results:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <select id="order" name="aiomatic_Spinner_Settings[order]" >
                     <option value="default"<?php
                        if ($order == "default") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Default", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="DESC"<?php
                        if ($order == "DESC") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Descendent", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="ASC"<?php
                        if ($order == "ASC") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Ascendent", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select> 
                     </td>
                  </tr>
                  <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("(string) - Sort retrieved posts by parameter. Defaults to 'date'.", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Order Results By:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <select id="orderby" name="aiomatic_Spinner_Settings[orderby]" >
                     <option value="default"<?php
                        if ($orderby == "default") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Default", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="date"<?php
                        if ($orderby == "date") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Date", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="none"<?php
                        if ($orderby == "none") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("None", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="ID"<?php
                        if ($orderby == "ID") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("ID", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="author"<?php
                        if ($orderby == "author") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Author", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="title"<?php
                        if ($orderby == "title") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Title", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="date"<?php
                        if ($orderby == "date") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Date", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="modified"<?php
                        if ($orderby == "modified") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Modified", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="parent"<?php
                        if ($orderby == "parent") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Parent", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="rand"<?php
                        if ($orderby == "rand") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Random", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="comment_count"<?php
                        if ($orderby == "comment_count") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Comment Count", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="menu_order"<?php
                        if ($orderby == "menu_order") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Menu Order", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="meta_value"<?php
                        if ($orderby == "meta_value") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Meta Value", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="meta_value_num"<?php
                        if ($orderby == "meta_value_num") {
                            echo " selected";
                        }
                        ?>><?php echo esc_html__("Meta Value Number", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select> 
                     </td>
                  </tr>
               </table>
</div>
                    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p></div><div>
    <?php echo esc_html__("New! You can use the [aicontent]Your Prompt[/aicontent] shortcode in this or other", 'aiomatic-automatic-ai-content-writer') . " <a href='https://1.envato.market/coderevolutionplugins' target='_blank'>" . esc_html__("'omatic plugins created by CodeRevolution", 'aiomatic-automatic-ai-content-writer') . "</a>" .  esc_html__(", click for details:", 'aiomatic-automatic-ai-content-writer');?>&nbsp;<a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-ai-generated-content-from-any-plugin-built-by-coderevolution/" target="_blank"><img src="https://i.ibb.co/gvTNWr6/artificial-intelligence-badge.png" alt="artificial-intelligence-badge" title="AI content generator support, when used together with the Aiomatic plugin"></a><br/><br/><a href="https://www.youtube.com/watch?v=5rbnu_uis7Y" target="_blank"><?php echo esc_html__("Nested Shortcodes also supported!", 'aiomatic-automatic-ai-content-writer');?></a><br/>
</div>
    </form>
    <div id="running_status_ai"></div>
</div>
<?php
}
?>