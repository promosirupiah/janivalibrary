<?php
function aiomatic_more()
{
?>
<div class="wp-header-end"></div>
<div class="wrap gs_popuptype_holder seo_pops">
<h2 class="cr_center"><?php echo esc_html__("More Features", 'aiomatic-automatic-ai-content-writer');?></h2>
<div class="wrap">
        <nav class="nav-tab-wrapper">
            <a href="#tab-0" class="nav-tab nav-tab-active"><?php echo esc_html__("More Features", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-1" class="nav-tab"><?php echo esc_html__("Media Library Extensions", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-2" class="nav-tab"><?php echo esc_html__("Content Wizard", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-3" class="nav-tab"><?php echo esc_html__("AI Comment Replier", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-5" class="nav-tab"><?php echo esc_html__("AI Taxonomy Description Writer", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-4" class="nav-tab"><?php echo esc_html__("[aicontent] Shortcode", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-6" class="nav-tab"><?php echo esc_html__("'Ultimate Membership Pro' Integration", 'aiomatic-automatic-ai-content-writer');?></a>
            <a href="#tab-7" class="nav-tab"><?php echo esc_html__("Developer Tools Tutorials", 'aiomatic-automatic-ai-content-writer');?></a>
        </nav>
        </nav>
        <div id="tab-0" class="tab-content">
         <br/>
<?php echo esc_html__("In addition to the powerful core features, Aiomatic has some hidden gems that will take your website to the next level. Let's explore these exciting features and see how they can supercharge your site.", 'aiomatic-automatic-ai-content-writer');?>

<h3><?php echo esc_html__("Content Wizard:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("First up, we have the Content Wizard, your reliable companion in managing and optimizing your content. This intelligent assistant helps you with various tasks, from generating AI-powered meta tags to suggesting relevant keywords and optimizing your content for better search engine rankings. The Content Wizard is your virtual content strategist, guiding you every step of the way.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("AI Media Library Extensions:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Aiomatic takes your media library to new heights with the AI Media Library Extension. With Extension 1, you can automatically generate alt text, captions, and descriptions for your images, saving you valuable time and effort. Extension 2 brings even more power by suggesting relevant tags and keywords for your media files, ensuring optimal search engine optimization and discoverability.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("Comment Replier:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Engaging with your audience is crucial, and Aiomatic makes it easier with the Comment Replier feature. This handy tool uses AI algorithms to analyze and understand comments on your website, providing you with suggested responses. You can quickly reply to comments, foster meaningful conversations, and provide better user engagement, all with the help of AI.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("AI Taxonomy Description Writer:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("In WordPress, taxonomies are used to classify and organize content. They allow you to group posts, pages, or custom post types together based on shared characteristics. Taxonomies can be hierarchical (like categories) or non-hierarchical (like tags). When creating taxonomies in WP, it is important to set descriptions for SEO purposes.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("[aicontent] Shortcode:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("This is maybe the biggest 'hidden gem' of Aiomatic. It is able to combine its power with any other plugin I created, allowing AI generated content to be produced in posts created by any other of my plugins. Imagine having AI-generated content in all your plugins, from social media to scraper plugins or news posts. Well, with Aiomatic, that dream is now a reality.", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("In this video, I'll take a closer look at how the latest update of Aiomatic works and what it can do for you. I'll explore how you can easily post AI-generated text to your social media channels, saving you time and effort while keeping your followers engaged.", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("I'll also dive into how Aiomatic can enhance your scraped or news posts, ensuring that your content is always fresh, relevant, and engaging. Say goodbye to boring, uninspired content, and hello to Aiomatic!", 'aiomatic-automatic-ai-content-writer');?></p>
<h3><?php echo esc_html__("Check The Tutorial Videos From The Above Tabs!", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("To access more details about each feature, simply navigate to the respective tabs at the top of this menu page. Within each tab, you'll find tutorial videos that walk you through the setup, configuration, and utilization of each feature. These videos provide step-by-step guidance, ensuring you make the most out of Aiomatic's hidden features.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("Developer Tools Tutorials:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Aiomatic allows developers to customize the prompts sent to the AI models and also the responses returned by the AI, before they are processed in the plugin, allowing high customizability of the AI and its results.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><a href="https://1.envato.market/UltimateMember" target="_blank"><?php echo esc_html__("'Ultimate Membership Pro' Integration:", 'aiomatic-automatic-ai-content-writer');?></a></h3>
<p><?php echo esc_html__("This is a nice feature, which will allow you to connect Aiomatic with the 'Ultimate Membership Pro' plugin, allowing you to give your website's members to the functionality offered by the plugin. You can limit the usage of the plugin for members, based on their subscription plans, allowing you to create an AI membership site with ease.", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("Unlock the true potential of Aiomatic's hidden features, harnessing the power of AI to streamline your content management, optimize your media library, engage with your audience, and enhance the visual impact of your website. It's time to take your WordPress experience to new heights with Aiomatic!", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("Enjoy exploring Aiomatic's hidden features and maximizing the potential of your WordPress website!", 'aiomatic-automatic-ai-content-writer');?></p>
       </div>
        <div id="tab-1" class="tab-content">
         <br/>
         <h3><?php echo esc_html__("Media Library Extensions Tutorial Videos:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/wRY6ElVZawI" frameborder="0" allowfullscreen></iframe></div></p>
    <h3><?php echo esc_html__("Automatic AI Written SEO Tags For Media Library Items:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/7MEPZhMVjf0" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
        <div id="tab-2" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("Content Wizard Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/e5tPgqOB8ss" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
        <div id="tab-3" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("AI Comment Replier Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/VknKvIcKRuw" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
        <div id="tab-5" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("AI Taxonomy Description Writer Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/k5BFo9jcmcs" frameborder="0" allowfullscreen></iframe></div></p>
        <h3><?php echo esc_html__("Automate the AI Taxonomy Description Writing Process:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/1OibwD73JIA" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
        <div id="tab-6" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("'Ultimate Membership Pro' Integration Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/Ej4fPlA91N4" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
        <div id="tab-7" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("AI Content Filters Feature Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/lDJOnhSS_5o" frameborder="0" allowfullscreen></iframe></div></p>
        <h3><?php echo esc_html__("OpenAI API Functions Calling Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/dCOOQXqBHQM" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
        <div id="tab-4" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("[aicontent] Shortcode Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/z_mGPlBsQQA" frameborder="0" allowfullscreen></iframe></div></p>
        <h3><?php echo esc_html__("[aicontent] Nested Shortcode Support (Advanced Feature):", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/SdNjVEfQzhs" frameborder="0" allowfullscreen></iframe></div></p>
        </div>
</div>
<?php
}
?>