<?php
defined('ABSPATH') or die();
function aiomatic_save_assistant($token, $title, $model, $prompt, $description, $assistant_first_message, $avatar, $code_interpreter, $retrieval, $assistant_files, $functions_str = '')
{
    require_once (dirname(__FILE__) . "/res/aiomatic-assistants-api.php"); 
    $assistant_id = '';
    if(empty($title))
    {
        $aiomatic_result['msg'] = 'You need to add a name for the assistant!';
        return $aiomatic_result;
    }
    if(empty($model))
    {
        $aiomatic_result['msg'] = 'You need to add a model for the assistant!';
        return $aiomatic_result;
    }
    $files_ok = false;
    $tools = [];
    if($code_interpreter == 'on')
    {
        $tools[] = ['type' => 'code_interpreter'];
        $files_ok = true;
    }
    if($retrieval == 'on')
    {
        $tools[] = ['type' => 'retrieval'];
        $files_ok = true;
    }
    $functions_json = json_decode($functions_str, true);
    if($functions_json === false)
    {
        $functions = array();
    }
    else
    {
        if(is_array($functions_json) && !isset($functions_json['name']))
        {
            $functions = $functions_json;
        }
        elseif(isset($functions_json['name']))
        {
            $functions = array($functions_json);
        }
        else
        {
            $functions = array();
        }
    }
    foreach($functions as $func)
    {
        $tools[] = ['type' => 'function', 'function' => $func];
    }
    if($files_ok === false)
    {
        $assistant_files = [];
    }
    try
    {
        $assistantData = aiomatic_openai_save_assistant(
            $token,
            $model,
            $title,
            $description,
            $prompt,
            $tools,
            $assistant_files
        );
        if($assistantData === false)
        {
            $aiomatic_result['msg'] = 'Failed to save assistant using the API';
            return $aiomatic_result;
        }
        if(!isset($assistantData['id']))
        {
            $aiomatic_result['msg'] = 'Failed to decode assistant saving request: ' . print_r($assistantData, true);
            return $aiomatic_result;
        }
        $assistant_id = $assistantData['id'];
    }
    catch(Exception $e)
    {
        $aiomatic_result['msg'] = 'Exception occured during Assitant saving: ' . $e->getMessage();
        return $aiomatic_result;
    }
    if(empty($assistant_id))
    {
        $aiomatic_result['msg'] = 'Failed to insert assistant to AI service: ' . $title;
        return $aiomatic_result;
    }
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong assistant saving');
    $assistant_data = array(
        'post_type' => 'aiomatic_assistants',
        'post_title' => $title,
        'post_content' => $prompt,
        'post_excerpt' => $description,
        'post_status' => 'publish'
    );
    $assistant_data = sanitize_post($assistant_data, 'db');
    remove_filter('content_save_pre', 'wp_filter_post_kses');
    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
    $local_assistant_id = wp_insert_post($assistant_data);
    add_filter('content_save_pre', 'wp_filter_post_kses');
    add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
    if(is_wp_error($local_assistant_id))
    {
        $aiomatic_result['msg'] = $local_assistant_id->get_error_message();
    }
    elseif($local_assistant_id === 0)
    {
        $aiomatic_result['msg'] = 'Failed to insert assistant to database: ' . $title;
    }
    else 
    {
        update_post_meta($local_assistant_id, '_assistant_id', $assistant_id);
        if(!empty($assistant_first_message))
        {
            update_post_meta($local_assistant_id, '_assistant_first_message', $assistant_first_message);
        }
        if(!empty($model))
        {
            update_post_meta($local_assistant_id, '_assistant_model', $model);
        }
        if(!empty($tools))
        {
            update_post_meta($local_assistant_id, '_assistant_tools', $tools);
        }
        if(!empty($assistant_files))
        {
            update_post_meta($local_assistant_id, '_assistant_files', $assistant_files);
        }
        if(!empty($avatar))
        {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $res2 = set_post_thumbnail($local_assistant_id, $avatar);
            if ($res2 === FALSE) 
            {
                $aiomatic_result['msg'] = 'Failed to insert assistant avatar to database: ' . $avatar;
            }
        }
        $aiomatic_result['status'] = 'success';
        $aiomatic_result['id'] = $local_assistant_id;
    }
    return $aiomatic_result;
}
function aiomatic_update_assistant($token, $assistant_id, $assistant_id_local, $title, $model, $prompt, $description, $assistant_first_message, $avatar, $code_interpreter, $retrieval, $assistant_files, $functions_str = '')
{
    $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong assistant updating');
    require_once (dirname(__FILE__) . "/res/aiomatic-assistants-api.php"); 
    if(empty($title))
    {
        $aiomatic_result['msg'] = 'You need to add a name for the assistant!';
        return $aiomatic_result;
    }
    if(empty($model))
    {
        $aiomatic_result['msg'] = 'You need to add a model for the assistant!';
        return $aiomatic_result;
    }
    $files_ok = false;
    $tools = [];
    if($code_interpreter == 'on')
    {
        $tools[] = ['type' => 'code_interpreter'];
        $files_ok = true;
    }
    if($retrieval == 'on')
    {
        $tools[] = ['type' => 'retrieval'];
        $files_ok = true;
    }
    $functions_json = json_decode($functions_str, true);
    if($functions_json === false)
    {
        $functions = array();
    }
    else
    {
        if(is_array($functions_json) && !isset($functions_json['name']))
        {
            $functions = $functions_json;
        }
        elseif(isset($functions_json['name']))
        {
            $functions = array($functions_json);
        }
        else
        {
            $functions = array();
        }
    }
    foreach($functions as $func)
    {
        $tools[] = ['type' => 'function', 'function' => $func];
    }
    if($files_ok === false)
    {
        $assistant_files = [];
    }
    try
    {
        $assistantData = aiomatic_openai_modify_assistant(
            $token,
            $assistant_id,
            $model,
            $title,
            $description,
            $prompt,
            $tools,
            $assistant_files
        );
        if($assistantData === false)
        {
            $aiomatic_result['msg'] = 'Failed to update assistant using the API';
            return $aiomatic_result;
        }
        if(!isset($assistantData['id']))
        {
            $aiomatic_result['msg'] = 'Failed to decode assistant updating request: ' . print_r($assistantData, true);
            return $aiomatic_result;
        }
        $assistant_id = $assistantData['id'];
    }
    catch(Exception $e)
    {
        $aiomatic_result['msg'] = 'Exception occured during Assitant updating: ' . $e->getMessage();
        return $aiomatic_result;
    }
    if(empty($assistant_id))
    {
        $aiomatic_result['msg'] = 'Failed to update assistant to AI service: ' . $title;
        return $aiomatic_result;
    }
    $assistant_data = array(
        'post_type' => 'aiomatic_assistants',
        'post_title' => $title,
        'post_content' => $prompt,
        'post_excerpt' => $description,
        'post_status' => 'publish',
        'ID' => $assistant_id_local
    );
    $assistant_data = sanitize_post($assistant_data, 'db');
    remove_filter('content_save_pre', 'wp_filter_post_kses');
    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
    $local_assistant_id = wp_update_post($assistant_data);
    add_filter('content_save_pre', 'wp_filter_post_kses');
    add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
    if(is_wp_error($local_assistant_id))
    {
        $aiomatic_result['msg'] = $local_assistant_id->get_error_message();
    }
    elseif($local_assistant_id === 0)
    {
        $aiomatic_result['msg'] = 'Failed to update assistant to database: ' . $title;
    }
    else 
    {
        update_post_meta($local_assistant_id, '_assistant_id', $assistant_id);
        if(!empty($assistant_first_message))
        {
            update_post_meta($local_assistant_id, '_assistant_first_message', $assistant_first_message);
        }
        if(!empty($model))
        {
            update_post_meta($local_assistant_id, '_assistant_model', $model);
        }
        if(!empty($tools))
        {
            update_post_meta($local_assistant_id, '_assistant_tools', $tools);
        }
        if(!empty($assistant_files))
        {
            update_post_meta($local_assistant_id, '_assistant_files', $assistant_files);
        }
        if(!empty($avatar))
        {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            $res2 = set_post_thumbnail($local_assistant_id, $avatar);
            if ($res2 === FALSE) 
            {
                $aiomatic_result['msg'] = 'Failed to insert assistant avatar to database: ' . $avatar;
            }
        }
        $aiomatic_result['status'] = 'success';
        $aiomatic_result['id'] = $local_assistant_id;
    }
    return $aiomatic_result;
}
function aiomatic_save_assistant_only_local($token, $title, $model, $prompt, $description, $assistant_first_message, $avatar, $assistant_files, $assistant_id, $created_at, $tools)
{
    $args = array(
        'post_type'  => 'aiomatic_assistants',
        'meta_query' => array(
            array(
                'key'     => '_assistant_id',
                'value'   => $assistant_id,
                'compare' => 'EXISTS'
            ),
        ),
    );
    $updated = false;
    $query = new WP_Query( $args );
    require_once (dirname(__FILE__) . "/res/aiomatic-assistants-api.php"); 
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) 
        {
            $query->the_post();
            $post_id = get_the_ID();
            $ass_id = get_post_meta($post_id, '_assistant_id', true);
            if(!empty($ass_id))
            {
                $failed = false;
                try
                {
                    $assistant = aiomatic_openai_retrieve_assistant($token, $ass_id);
                    if(!isset($assistant['id']))
                    {
                        throw new Exception('Incorrect response from assistant grabbing: ' . print_r($assistant, true));
                    }
                }
                catch(Exception $e)
                {
                    aiomatic_log_to_file('Exception in assistant grabbing: ' . $e->getMessage());
                    $failed = true;
                }
                if($failed == false)
                {
                    if(empty($assistant['description']))
                    {
                        $assistant['description'] = '';
                    }
                    if(empty($assistant['instructions']))
                    {
                        $assistant['instructions'] = '';
                    }
                    $assistant_data = array(
                        'post_type' => 'aiomatic_assistants',
                        'post_title' => $assistant['name'],
                        'post_content' => $assistant['instructions'],
                        'post_excerpt' => $assistant['description'],
                        'post_status' => 'publish',
                        'ID' => $post_id
                    );
                    $assistant_data = sanitize_post($assistant_data, 'db');
                    remove_filter('content_save_pre', 'wp_filter_post_kses');
                    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
                    $local_assistant_id = wp_update_post($assistant_data);
                    add_filter('content_save_pre', 'wp_filter_post_kses');
                    add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
                    if(is_wp_error($local_assistant_id))
                    {
                        aiomatic_log_to_file('Failed to update assistant ' . $local_assistant_id->get_error_message());
                    }
                    elseif($local_assistant_id === 0)
                    {
                        aiomatic_log_to_file('Failed to update assistant to database: ' . $assistant['name']);
                    }
                    else 
                    {
                        $updated = true;
                        update_post_meta($local_assistant_id, '_assistant_model', $assistant['model']);
                        update_post_meta($local_assistant_id, '_assistant_tools', (array) $assistant['tools']);
                        update_post_meta($local_assistant_id, '_assistant_files', $assistant['file_ids']);
                        $aiomatic_result['status'] = 'success';
                        $aiomatic_result['id'] = $local_assistant_id;
                    }
                }
            }
        }
    }
    if(!$updated)
    {
        if(empty($title))
        {
            $aiomatic_result['msg'] = 'You need to add a name for the assistant!';
            return $aiomatic_result;
        }
        if(empty($model))
        {
            $aiomatic_result['msg'] = 'You need to add a model for the assistant!';
            return $aiomatic_result;
        }
        if(empty($prompt))
        {
            $prompt = '';
        }
        if(empty($description))
        {
            $description = '';
        }
        $postdate = date("Y-m-d H:i:s", $created_at);
        $aiomatic_result = array('status' => 'error', 'msg' => 'Something went wrong assistant saving');
        $assistant_data = array(
            'post_type' => 'aiomatic_assistants',
            'post_title' => $title,
            'post_content' => $prompt,
            'post_excerpt' => $description,
            'post_date' => $postdate,
            'post_status' => 'publish'
        );
        $assistant_data = sanitize_post($assistant_data, 'db');
        remove_filter('content_save_pre', 'wp_filter_post_kses');
        remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');remove_filter('title_save_pre', 'wp_filter_kses');
        $local_assistant_id = wp_insert_post($assistant_data);
        add_filter('content_save_pre', 'wp_filter_post_kses');
        add_filter('content_filtered_save_pre', 'wp_filter_post_kses');add_filter('title_save_pre', 'wp_filter_kses');
        if(is_wp_error($local_assistant_id))
        {
            $aiomatic_result['msg'] = $local_assistant_id->get_error_message();
        }
        elseif($local_assistant_id === 0)
        {
            $aiomatic_result['msg'] = 'Failed to insert assistant to database: ' . $title;
        }
        else 
        {
            update_post_meta($local_assistant_id, '_assistant_id', $assistant_id);
            if(!empty($assistant_first_message))
            {
                update_post_meta($local_assistant_id, '_assistant_first_message', $assistant_first_message);
            }
            if(!empty($model))
            {
                update_post_meta($local_assistant_id, '_assistant_model', $model);
            }
            if(!empty($tools))
            {
                update_post_meta($local_assistant_id, '_assistant_tools', (array)$tools);
            }
            if(!empty($assistant_files))
            {
                update_post_meta($local_assistant_id, '_assistant_files', $assistant_files);
            }
            if(!empty($avatar))
            {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                require_once(ABSPATH . 'wp-admin/includes/media.php');
                $res2 = set_post_thumbnail($local_assistant_id, $avatar);
                if ($res2 === FALSE) 
                {
                    $aiomatic_result['msg'] = 'Failed to insert assistant avatar to database: ' . $avatar;
                }
            }
            $aiomatic_result['status'] = 'success';
            $aiomatic_result['id'] = $local_assistant_id;
        }
    }
    return $aiomatic_result;
}
?>