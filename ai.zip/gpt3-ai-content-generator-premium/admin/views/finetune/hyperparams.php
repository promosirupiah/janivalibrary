<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<p><strong><?php echo esc_html__('Epochs','gpt3-ai-content-generator')?>: </strong><?php echo esc_html($wpaicg_data->n_epochs);?></p>