
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException, NoSuchElementException, ElementClickInterceptedException,
    ElementNotInteractableException, StaleElementReferenceException,
    WebDriverException # Catch general WebDriver errors
)
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd
import os

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 10 # Set 0 for all pages, 10 for testing as requested
OUTPUT_CSV_BASE_FILENAME = "kemenkes_webinar_page_"
FINAL_OUTPUT_CSV_FILENAME = "kemenkes_webinar_ALL_collected_data_v4.csv" # Updated filename
AJAX_LOAD_WAIT_SECONDS = 3 # Wait time after clicking Next button or filter

# --- User-defined Selectors ---
# Checkbox for Webinar filter
USER_XPATH_CHECKBOX_WEBINAR = "//label[.//span[contains(text(), 'Webinar')]]//input[@type='checkbox']"

# XPath for finding Course Link elements on the listing page
# *** Using the EXACT XPath from your working lms8.py run output ***
USER_XPATH_LINKS_ON_LISTING_PAGE = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a" # This must be finding multiple 'a' tags in your tests

# Detail Page XPaths (User Provided in lms8.py - WARNING: Likely mismatched for Kemenkes structure)
USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div" # Likely incorrect for Kemenkes
USER_XPATH_DETAIL_PAGE_PROVIDER = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[1]/div[2]/div/div[2]/div/span[2]" # Likely incorrect for Kemenkes

# Pagination Button XPath (Working from lms10.py)
PAGINATION_NEXT_BUTTON_XPATH = "//li[@title='Next Page']/button"

# --- End Configuration ---

# Global list for final save
all_accumulated_data_for_final_save = []

def save_data_to_csv(data_list, filename_or_page_num, base_filename=None, is_final_save=False):
    """Saves data list to a CSV file."""
    if not data_list:
        status_msg = "final accumulated data" if is_final_save else f"page {filename_or_page_num}"
        print(f"  No data collected for {status_msg} to save.")
        return

    filename = filename_or_page_num if is_final_save else f"{base_filename}{filename_or_page_num}.csv"

    # Define the desired column order, including the new provider field
    column_order = ['listing_page', 'course_link', 'page_title_selenium',
                    'contact_user_xpath', 'provider_user_xpath']

    df = pd.DataFrame(data_list)

    # Ensure columns exist and handle potential missing columns gracefully
    # Reindex dataframe to ensure consistent column order, filling missing with None/NaN
    df_ordered = df.reindex(columns=column_order)


    try:
        df_ordered.to_csv(filename, index=False, encoding='utf-8-sig')
        status_msg = "Final accumulated data" if is_final_save else f"Data for page {filename_or_page_num}"
        print(f"  {status_msg} saved to {filename}")
    except Exception as e_csv:
        print(f"  Error saving data to {filename}: {e_csv}")


def main():
    global all_accumulated_data_for_final_save
    print("Starting Kemenkes LMS Scraper (Combined Logic, Robust Windows)...")
    print("WARNING: Detail page XPaths (contact, provider) provided in config are UNLIKELY to match actual Kemenkes LMS detail page structure and will likely return 'Not Found'.")
    print(f"Scraping up to {MAX_LISTING_PAGES_TO_SCRAPE} pages (0 means all).")

    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless") # Uncomment to run without opening browser window
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3') # Suppress excessive logging
    driver = None

    try:
        driver = webdriver.Chrome(service=service, options=options)
        wait = WebDriverWait(driver, 20) # Increased default wait timeout
        short_wait = WebDriverWait(driver, 5) # Shorter wait for optional elements

        print(f"Navigating to: {START_URL}")
        driver.get(START_URL)
        # Keep track of the main listing page window handle
        main_tab_handle = driver.current_window_handle

        # 1. Initial Wait (Step 2 from your working flow)
        initial_wait_seconds = 5
        print(f"Waiting {initial_wait_seconds} seconds for initial page load...")
        time.sleep(initial_wait_seconds) # Using time.sleep as this worked for you
        print("Initial wait finished.")


        # 2. Click "Webinar" checkbox (From lms8.py)
        try:
            print(f"Attempting to click 'Webinar' checkbox using XPath: {USER_XPATH_CHECKBOX_WEBINAR}")
            # Wait for the filter widget container to be present as a sign of readiness
            wait.until(EC.presence_of_element_located((By.XPATH, "//div[contains(@class,'course-filter-widget')]")))
            # Wait for the checkbox itself to be clickable
            webinar_checkbox = short_wait.until(EC.element_to_be_clickable((By.XPATH, USER_XPATH_CHECKBOX_WEBINAR)))

            # Check if it's already selected
            if not webinar_checkbox.is_selected():
                webinar_checkbox.click()
                print("'Webinar' checkbox clicked.")
                # Wait for the URL to reflect the filter (e.g., ?search=&type=webinar)
                # Using short_wait here, if it fails, the message will indicate it.
                short_wait.until(EC.url_contains("type=webinar"))
                print("URL reflects filter 'type=webinar'.")
                # Additional sleep after filter for content update (as per your scripts)
                time.sleep(AJAX_LOAD_WAIT_SECONDS)
                print(f"Waited {AJAX_LOAD_WAIT_SECONDS}s after filter.")
            else:
                 print("'Webinar' checkbox was already selected.")

        except TimeoutException:
             print(f"Timeout ({short_wait._timeout}s) waiting for checkbox or URL change using XPath: {USER_XPATH_CHECKBOX_WEBINAR}. Continuing without clicking filter.")
        except NoSuchElementException:
             print(f"Checkbox element not found using XPath: {USER_XPATH_CHECKBOX_WEBINAR}. Continuing without clicking filter.")
        except ElementClickInterceptedException:
             print(f"Checkbox click intercepted using XPath: {USER_XPATH_CHECKBOX_WEBINAR}. Continuing without clicking filter.")
        except Exception as e_checkbox:
            print(f"Unexpected error clicking 'Webinar' checkbox: {e_checkbox}. Continuing without clicking filter.")

        # Ensure we are back on the main window handle after filter attempt
        # This is crucial before starting the pagination loop
        try:
             driver.switch_to.window(main_tab_handle)
             print("Ensured switch back to main listing window.")
        except Exception as e_switch_back_initial:
             print(f"Error switching back to main window after filter attempt: {e_switch_back_initial}. This could cause issues.")
             # Depending on the error, you might need to handle this more severely,
             # potentially by quitting and restarting the driver if the main window is lost.
             # For now, we'll just print and hope the main handle is still valid.


        # --- Pagination Loop ---
        current_listing_page_num = 1
        while True:
            print(f"\n--- Processing Listing Page: {current_listing_page_num} ---")

            data_from_this_page = []
            links_on_this_page = []

            # 3. Get Course Links on Current Page (Step 3 from user flow, using lms8.py's method)
            try:
                # Ensure we are in the main window before finding elements
                driver.switch_to.window(main_tab_handle)
                print(f"Attempting to find course links using XPath: {USER_XPATH_LINKS_ON_LISTING_PAGE}")

                # Use WebDriverWait to wait for presence of at least one link element
                # This helps ensure the AJAX content has loaded after filter/pagination
                wait.until(EC.presence_of_element_located((By.XPATH, USER_XPATH_LINKS_ON_LISTING_PAGE)))
                print("At least one course link element appears to be present.")

                # Find ALL link elements matching the XPath on the current page
                link_elements = driver.find_elements(By.XPATH, USER_XPATH_LINKS_ON_LISTING_PAGE)
                print(f"Found {len(link_elements)} potential link elements on Page {current_listing_page_num} using the provided XPath.")

                # Iterate through each link element and get its href attribute
                for i, element in enumerate(link_elements):
                    try:
                        # Use WebDriverWait for robustness even when getting attribute,
                        # in case the element is temporarily stale
                        href = WebDriverWait(driver, 2).until(lambda d: element.get_attribute("href"))
                        if href:
                            links_on_this_page.append(href)
                    except StaleElementReferenceException:
                        print(f"  Warning: StaleElementReferenceException on link element {i} while getting href. Skipping.")
                        continue
                    except TimeoutException:
                         print(f"  Warning: Timeout getting href for link element {i}. Skipping.")
                         continue
                    except Exception as e_link:
                        print(f"  Warning: Error getting href for element {i}: {e_link}. Skipping.")
                        continue

                # Optional: Remove duplicates if the XPath finds duplicates for some reason
                links_on_this_page = list(dict.fromkeys(links_on_this_page))
                print(f"    Collected {len(links_on_this_page)} unique links for processing on Page {current_listing_page_num}.")


            except TimeoutException:
                 print(f"Timeout ({wait._timeout}s) waiting for any link elements using XPath '{USER_XPATH_LINKS_ON_LISTING_PAGE}' on page {current_listing_page_num}. This might indicate no links loaded or end of results.")
                 # Continue to pagination check below. If no links were found, we still need to see if a "Next" button exists.
            except Exception as e_find_links:
                print(f"  Error finding link elements on page {current_listing_page_num}: {e_find_links}")
                # Continue to pagination check below.


            # --- Process each link on the current page (From lms8.py) ---
            # This part is prone to the "no such window" errors. Let's make it more robust.
            original_window_handles = driver.window_handles # Get handles BEFORE opening new tab

            for i, course_url in enumerate(links_on_this_page):
                detail_tab_handle = None # Initialize detail tab handle

                print(f"    Processing link {i+1}/{len(links_on_this_page)}: {course_url[:70]}...")
                page_data = {
                    'listing_page': current_listing_page_num,
                    'course_link': course_url,
                    'page_title_selenium': "Not Found",
                    'contact_user_xpath': "Not Found", # Uses user provided, likely incorrect XPath
                    'provider_user_xpath': "Not Found" # Uses user provided, likely incorrect XPath
                }

                try:
                    # Use execute_script to open in a new tab
                    driver.execute_script("window.open(arguments[0], '_blank');", course_url)

                    # Wait for a NEW window to appear
                    # Check if the number of windows increases by exactly 1
                    wait.until(EC.number_of_windows_to_be(len(original_window_handles) + 1))

                    # Find the handle of the new tab
                    all_tabs_after_open = driver.window_handles
                    new_tab_handles = [tab for tab in all_tabs_after_open if tab not in original_window_handles]

                    if not new_tab_handles:
                        raise WebDriverException("New tab did not appear after opening link.") # Should not happen if EC.number_of_windows_to_be passed
                    detail_tab_handle = new_tab_handles[0] # Get the handle of the new tab

                    # Switch to the new tab
                    driver.switch_to.window(detail_tab_handle)
                    print("      Switched to new detail tab.")

                    # Wait for the body or some element on the detail page to load
                    wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                    # Give a moment for content rendering (can sometimes help with layout shifts)
                    time.sleep(1)

                    # Get page title
                    try:
                        page_data['page_title_selenium'] = driver.title.strip()
                        print(f"      Page Title: '{page_data['page_title_selenium']}'")
                    except Exception as e_title:
                         print(f"      Error getting page title: {e_title}")


                    # Try to get Contact info using user's provided XPath (likely incorrect)
                    try:
                        # Use short_wait for optional fields
                        contact_element = short_wait.until(EC.presence_of_element_located((By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT)))
                        contact_info = contact_element.text.strip()
                        page_data['contact_user_xpath'] = contact_info if contact_info else "Empty" # Handle empty text
                        print(f"      Contact (User XPath): '{page_data['contact_user_xpath']}'")
                    except (NoSuchElementException, TimeoutException):
                        # print(f"      Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}") # Suppress repeated Not Found messages unless debugging
                        pass # Keep 'Not Found' default
                    except Exception as e_contact:
                        print(f"      Error getting Contact with user XPath: {e_contact}")


                    # Try to get Provider info using user's provided XPath (likely incorrect)
                    try:
                        # Use short_wait for optional fields
                        provider_element = short_wait.until(EC.presence_of_element_located((By.XPATH, USER_XPATH_DETAIL_PAGE_PROVIDER)))
                        provider_info = provider_element.text.strip()
                        page_data['provider_user_xpath'] = provider_info if provider_info else "Empty" # Handle empty text
                        print(f"      Provider (User XPath): '{page_data['provider_user_xpath']}'")
                    except (NoSuchElementException, TimeoutException):
                         # print(f"      Provider NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_PROVIDER}") # Suppress repeated Not Found messages unless debugging
                        pass # Keep 'Not Found' default
                    except Exception as e_provider:
                        print(f"      Error getting Provider with user XPath: {e_provider}")


                except TimeoutException as e_detail_timeout:
                    print(f"      Timeout while waiting for detail page elements on {course_url[:70]}...: {e_detail_timeout}")
                except Exception as e_detail:
                    print(f"      Unexpected error scraping detail page {course_url[:70]}...: {e_detail}")
                finally:
                    # Append data regardless of whether scraping detail fields succeeded
                    data_from_this_page.append(page_data)
                    all_accumulated_data_for_final_save.append(page_data)

                    # --- Robustly Close the current tab and switch back ---
                    try:
                        # Check if the detail tab handle is valid AND exists in the current handles
                        current_handles_before_close = driver.window_handles
                        if detail_tab_handle and detail_tab_handle in current_handles_before_close:
                            # Ensure we are on the detail tab before closing it
                            if driver.current_window_handle != detail_tab_handle:
                                driver.switch_to.window(detail_tab_handle)
                                print("      Switched to detail tab for closing.")
                            driver.close()
                            print("      Closed detail tab.")
                        else:
                            print("      Detail tab handle is invalid or tab already closed. Skipping close.")


                        # After closing, switch back to the main window
                        # Check if the main window handle is still valid and exists
                        current_handles_after_close = driver.window_handles
                        if main_tab_handle in current_handles_after_close:
                            driver.switch_to.window(main_tab_handle)
                            print("      Switched back to main listing window.")
                        else:
                            print("      Main window handle is invalid or main window closed. Cannot switch back.")
                            # This is a critical error, the loop cannot continue safely.
                            raise WebDriverException("Main window lost or closed.")

                        # Short pause after switching back
                        time.sleep(0.5)

                    except WebDriverException as e_window_management:
                        print(f"      Critical window management error: {e_window_management}. Stopping script.")
                        # Re-raise the exception to be caught by the outer try/except
                        raise e_window_management
                    except Exception as e_close:
                        print(f"      Non-critical error during window management: {e_close}")
                    # --- End Robust Window Management ---


            # Save data collected from the current listing page (From lms8.py)
            save_data_to_csv(data_from_this_page, current_listing_page_num, OUTPUT_CSV_BASE_FILENAME)

            # Check if we've reached the max page limit BEFORE trying to go to the next page
            if MAX_LISTING_PAGES_TO_SCRAPE > 0 and current_listing_page_num >= MAX_LISTING_PAGES_TO_SCRAPE:
                print(f"  Reached max configured listing pages ({MAX_LISTING_PAGES_TO_SCRAPE}). Stopping pagination.")
                break

            # 4. Pagination - Find and Click Next (Using working logic from lms10.py)
            print(f"  Attempting to click 'Next Page' button using XPath: '{PAGINATION_NEXT_BUTTON_XPATH}' ...")
            next_button = None
            try:
                # Ensure we are on the correct window (main listing page) before trying to find the button
                if driver.current_window_handle != main_tab_handle:
                    driver.switch_to.window(main_tab_handle)
                    print("  Switched to main window for pagination.")


                # Use WebDriverWait to wait for the Next button to be clickable
                wait_pagination = WebDriverWait(driver, 10) # Use a reasonable timeout
                next_button = wait_pagination.until(EC.element_to_be_clickable((By.XPATH, PAGINATION_NEXT_BUTTON_XPATH)))
                print("  'Next Page' button found and is clickable.")

                # Check if the button is enabled (indicates if it's the last page)
                if not next_button.is_enabled():
                    print("  'Next Page' button is disabled. Assuming last page reached. Stopping pagination.")
                    break # Button is disabled, indicates end of pagination

                # Scroll to the button if needed (sometimes necessary for clicking)
                # driver.execute_script("arguments[0].scrollIntoView(true);", next_button)
                # time.sleep(0.2) # Short pause after scroll

                # Click the button using standard click
                next_button.click()
                print("  Clicked 'Next Page'.")

                # 5. Wait for the page content to load after clicking (Step 5 from user flow)
                # Using time.sleep as this pattern worked for you previously.
                # More robust would be waiting for course items to reappear or page number to update.
                print(f"  Waiting {AJAX_LOAD_WAIT_SECONDS} seconds for AJAX content load...")
                time.sleep(AJAX_LOAD_WAIT_SECONDS)
                print("  Wait after click finished.")

                current_listing_page_num += 1 # Increment page counter only after successful click and wait


            except TimeoutException:
                # If the WebDriverWait for the next button times out
                print(f"  Timeout ({wait_pagination._timeout}s) waiting for 'Next Page' button to be clickable. Assuming no more pages or an issue. Stopping pagination.")
                break
            except (NoSuchElementException, ElementClickInterceptedException, ElementNotInteractableException, StaleElementReferenceException, WebDriverException) as e_pagination:
                # Catch various exceptions during the pagination attempt
                print(f"  Error during pagination attempt: {type(e_pagination).__name__}: {e_pagination}. Stopping pagination.")
                break
            except Exception as e_pagination:
                print(f"  An unexpected error occurred during pagination attempt: {e_pagination}. Stopping pagination.")
                break # Stop on other unexpected errors during pagination

            # Add a check here in case the loop somehow continues without incrementing page_count
            # and no links were found - this might indicate being stuck or end of results.
            # However, the next_button check should primarily handle the break condition.
            # if current_listing_page_num > 1 and not links_on_this_page:
            #      print("  Warning: No links found on the current page. Checking next page button...")
            #      pass # Let the next_button check handle the break.


    except KeyboardInterrupt:
        print("\nCtrl+C pressed. Script interrupted. Attempting to save data...")
    except WebDriverException as e_critical:
        print(f"\nA critical WebDriver error occurred outside the main loop: {e_critical}. Attempting to save data...")
    except Exception as e_main:
        print(f"\nAn unexpected error occurred in the main scraping process: {e_main}. Attempting to save data...")

    finally:
        # --- Ensure we are on the main window before quitting if possible ---
        try:
            if driver and driver.window_handles:
                # Attempt to switch to the main handle, but be careful if it's gone
                if main_tab_handle in driver.window_handles:
                     driver.switch_to.window(main_tab_handle)
                     print("\nSwitched back to main window before final save/quit.")
                else:
                     # If main handle is not found, try switching to ANY available window
                     # This might prevent the "no such window" error on quit
                     print("\nMain window handle invalid or gone. Trying to switch to any available window before quitting.")
                     # Iterate through current handles and switch to the first one
                     available_handles = driver.window_handles
                     if available_handles:
                          driver.switch_to.window(available_handles[0])
                          print(f"Switched to first available window ({available_handles[0][:5]}...)")
                     else:
                          print("No windows available to switch to.")

        except Exception as e_switch_back_final:
             print(f"Error during final switch back attempt: {e_switch_back_final}")

        # --- Save Collected Data to CSV (Step 6) ---
        print(f"\n--- Attempting final save of {len(all_accumulated_data_for_final_save)} collected data rows to {FINAL_OUTPUT_CSV_FILENAME} ---")
        save_data_to_csv(all_accumulated_data_for_final_save, FINAL_OUTPUT_CSV_FILENAME, is_final_save=True)
        # ---------------------------------------------

        # --- Quit Driver ---
        if driver:
            print("Closing WebDriver...")
            driver.quit() # quit() is safer than close() in finally as it closes all windows
        print("Scraping process finished or halted.")

if __name__ == "__main__":
    main()