import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, WebDriverException
from selenium.webdriver.chrome.service import Service as ChromeService # For Chrome
from webdriver_manager.chrome import ChromeDriverManager # For Chrome

# --- Configuration ---
URL = "https://lms.kemkes.go.id/courses?search="
# Set MAX_LISTING_PAGES_TO_SCRAPE = 0 to scrape all pages
# Set MAX_LISTING_PAGES_TO_SCRAPE = 10 for testing as requested
MAX_LISTING_PAGES_TO_SCRAPE = 11
WAIT_TIME_SECONDS = 3

# --- Setup WebDriver ---
# Using webdriver_manager to automatically handle driver download/setup
try:
    # Use ChromeDriverManager to get the latest chromedriver
    service = ChromeService(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)
    print("WebDriver started successfully.")
except Exception as e:
    print(f"Error setting up WebDriver: {e}")
    print("Please ensure you have Chrome installed and webdriver_manager is correctly installed.")
    exit() # Exit if driver setup fails

driver.maximize_window() # Optional: Maximize window for better visibility

# --- Navigation and Pagination ---
page_count = 1

try:
    print(f"Navigating to initial URL: {URL}")
    driver.get(URL)
    # Optional: Add a small initial wait for the first page to load its content via AJAX
    time.sleep(5) # Adjust this time if the initial load takes longer

    while True:
        print(f"--- Currently on Page {page_count} ---")

        # --- (Optional) Add your data extraction logic here ---
        # For example, to find all course list items:
        # try:
        #     course_items = driver.find_elements(By.CSS_SELECTOR, "div.ant-list-item")
        #     print(f"Found {len(course_items)} course items on this page.")
        #     # Process each item...
        # except Exception as e:
        #     print(f"Could not find course items on page {page_count}: {e}")
        # ----------------------------------------------------

        # Check if we've reached the max page limit (unless MAX_LISTING_PAGES_TO_SCRAPE is 0)
        if MAX_LISTING_PAGES_TO_SCRAPE != 0 and page_count >= MAX_LISTING_PAGES_TO_SCRAPE:
            print(f"Reached maximum pages to scrape ({MAX_LISTING_PAGES_TO_SCRAPE}). Stopping.")
            break

        # Find the Next button
        # The XPath targets the button element inside the li element that has title="Next Page"
        next_button_xpath = "//li[@title='Next Page']/button"
        next_button = None

        try:
            next_button = driver.find_element(By.XPATH, next_button_xpath)

            # Check if the button is enabled
            if not next_button.is_enabled():
                print("Next button found but is disabled (likely on the last page). Stopping.")
                break # Button is disabled, indicates end of pagination

            # Click the button
            print(f"Clicking 'Next Page' button...")
            next_button.click()

            # Wait for the page content to load after clicking
            print(f"Waiting for {WAIT_TIME_SECONDS} seconds...")
            time.sleep(WAIT_TIME_SECONDS)

            page_count += 1

        except NoSuchElementException:
            # If the element is not found, it means we are likely on the last page
            print(" 'Next Page' button not found. Assuming end of pagination. Stopping.")
            break
        except WebDriverException as e:
             print(f"A WebDriver error occurred while trying to click Next: {e}")
             break # Stop on WebDriver errors during click/wait
        except Exception as e:
            print(f"An unexpected error occurred during pagination: {e}")
            break # Stop on other unexpected errors

except WebDriverException as e:
    print(f"A critical WebDriver error occurred: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    # Close the browser when done or if an error occurred
    if 'driver' in locals() and driver:
        print("Closing browser...")
        driver.quit()
    print("Script finished.")