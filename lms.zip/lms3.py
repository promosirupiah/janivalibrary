from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 1 # Number of listing pages. 0 means scrape all pages.
OUTPUT_CSV_FILE = "kemenkes_courses_final_user_xpaths.csv"

# --- User-defined XPaths ---
USER_XPATH_CHECKBOX_GRATIS = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[1]/div/div/div[1]/div/div[2]/div/div/div[2]/div/div[2]/div/div/div/div/div[5]/label/span[1]/input"

USER_XPATH_COURSE_CONTAINERS = "//*[@id='publicContainer']/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div[contains(@class, 'ant-card')]"
# Note: This absolute link XPath doesn't iterate based on found containers.
USER_XPATH_SPECIFIC_LINK_A_TAG = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a"

USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div"
USER_XPATH_NEXT_PAGE_LI = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[2]/ul/li[@title='Next Page']"
# --- End User-defined XPaths ---

def main():
    print("Starting Kemenkes LMS Scraper with user-specified XPaths (including checkbox)...")
    print("WARNING: Provided XPaths for course containers and detail page data are UNLIKELY to match Kemenkes LMS.")
    print("         This may result in limited or no course-specific data extraction.")

    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3')
    driver = webdriver.Chrome(service=service, options=options)
    wait = WebDriverWait(driver, 15) # Increased wait time slightly for page loads/filters

    all_scraped_data = []
    current_listing_page_num = 1

    print(f"Navigating to: {START_URL}")
    driver.get(START_URL)

    # 0. Click the checkbox
    try:
        print(f"Attempting to click checkbox with XPath: {USER_XPATH_CHECKBOX_GRATIS}")
        checkbox = wait.until(EC.element_to_be_clickable((By.XPATH, USER_XPATH_CHECKBOX_GRATIS)))
        # Scroll into view if necessary, though click might handle it
        # driver.execute_script("arguments[0].scrollIntoView(true);", checkbox)
        # time.sleep(0.5) # Brief pause after scroll
        checkbox.click()
        print("Checkbox clicked. Waiting for filter to apply...")
        time.sleep(3) # Give time for the filter to apply and content to reload
    except TimeoutException:
        print(f"Timeout: Checkbox not found or not clickable with XPath: {USER_XPATH_CHECKBOX_GRATIS}")
    except Exception as e_checkbox:
        print(f"Error clicking checkbox: {e_checkbox}")


    while True: # Loop indefinitely until a break condition (max pages or no next page)
        print(f"\n--- Processing Listing Page: {current_listing_page_num} ---")
        
        course_links_to_visit = []

        # 1. Attempt to find course containers using USER_XPATH_COURSE_CONTAINERS
        try:
            print(f"Attempting to find course containers with XPath: '{USER_XPATH_COURSE_CONTAINERS}'")
            time.sleep(1) # Brief pause, expect quick failure or empty list on Kemenkes
            course_containers = driver.find_elements(By.XPATH, USER_XPATH_COURSE_CONTAINERS)
            print(f"Found {len(course_containers)} elements matching user's container XPath.")
            if not course_containers:
                print("  No course containers found with the specified XPath.")
        except Exception as e_container:
            print(f"  Error finding containers: {e_container}")

        # 2. Attempt to get links using USER_XPATH_SPECIFIC_LINK_A_TAG
        try:
            print(f"Attempting to find link elements with user's specific link XPath: '{USER_XPATH_SPECIFIC_LINK_A_TAG}'")
            link_a_tag_elements = driver.find_elements(By.XPATH, USER_XPATH_SPECIFIC_LINK_A_TAG)
            print(f"Found {len(link_a_tag_elements)} <a> element(s) matching the user's specific link XPath.")
            
            if link_a_tag_elements:
                for link_a_tag in link_a_tag_elements:
                    href = link_a_tag.get_attribute('href')
                    if href and href not in course_links_to_visit:
                        course_links_to_visit.append(href)
                        print(f"  Extracted link using specific XPath: {href}")
            else:
                print("  No <a> elements found matching the user's specific link XPath.")
        except Exception as e_link_xpath:
            print(f"  Error using user's specific link XPath: {e_link_xpath}")
        
        print(f"Collected {len(course_links_to_visit)} unique course links to visit this page.")

        # 3. Scrape data from each (if any) course link found
        for i, course_url in enumerate(course_links_to_visit):
            page_data = {
                'listing_page': current_listing_page_num,
                'course_link_from_user_xpath': course_url,
                'page_title_selenium': "Not Found",
                'contact_user_xpath': "Not Found"
            }
            print(f"  Opening link ({i+1}/{len(course_links_to_visit)}): {course_url[:70]}...")

            original_window = driver.current_window_handle
            driver.execute_script("window.open(arguments[0], '_blank');", course_url)
            WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(len(driver.window_handles)))
            
            new_window = [window for window in driver.window_handles if window != original_window][0]
            driver.switch_to.window(new_window)
            time.sleep(1)

            try:
                wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                time.sleep(1.5)

                page_data['page_title_selenium'] = driver.title.strip()
                print(f"    - Page Title (Selenium): '{page_data['page_title_selenium']}'")

                try:
                    contact_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT).text.strip()
                    page_data['contact_user_xpath'] = contact_info
                    print(f"    - Contact (User XPath): '{contact_info}'")
                except NoSuchElementException:
                    print(f"    - Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}")
                
            except TimeoutException:
                print(f"    - Timed out loading detail page: {course_url}")
            except Exception as e_detail:
                print(f"    - Error scraping detail page {course_url}: {e_detail}")
            finally:
                all_scraped_data.append(page_data)
                driver.close()
                driver.switch_to.window(original_window)
                time.sleep(0.5)

        # 4. Pagination Logic
        # Check if max pages limit is reached (if MAX_LISTING_PAGES_TO_SCRAPE > 0)
        if MAX_LISTING_PAGES_TO_SCRAPE > 0 and current_listing_page_num >= MAX_LISTING_PAGES_TO_SCRAPE:
            print(f"Reached maximum configured listing pages: {MAX_LISTING_PAGES_TO_SCRAPE}.")
            break

        # Attempt to go to the next page
        print("Attempting to go to the next listing page...")
        try:
            next_page_li_element = driver.find_element(By.XPATH, USER_XPATH_NEXT_PAGE_LI)
            
            if "disabled" in next_page_li_element.get_attribute("class").lower():
                print("Next page button (li) is disabled. No more pages.")
                break 

            next_page_anchor = next_page_li_element.find_element(By.XPATH, ".//a")
            
            driver.execute_script("arguments[0].scrollIntoView(true);", next_page_anchor)
            time.sleep(0.5)
            driver.execute_script("arguments[0].click();", next_page_anchor)
            print("Clicked 'Next Page'.")
            current_listing_page_num += 1
            time.sleep(3) # Wait for new page to load and filters (if any) to apply
        except NoSuchElementException:
            print("Next page button (li or a) not found with user's XPath. Assuming no more pages.")
            break 
        except Exception as e_pagination:
            print(f"An error occurred during pagination: {e_pagination}")
            break 

    print("\nClosing WebDriver...")
    driver.quit()

    # Save data to CSV
    if all_scraped_data:
        print(f"\nProcessed data. Found {len(all_scraped_data)} entries (check for 'Not Found' values).")
        df = pd.DataFrame(all_scraped_data)
        column_order = ['listing_page', 'course_link_from_user_xpath', 'page_title_selenium', 'contact_user_xpath']
        df_ordered = df[[col for col in column_order if col in df.columns]]
        try:
            df_ordered.to_csv(OUTPUT_CSV_FILE, index=False, encoding='utf-8-sig')
            print(f"Data (or lack thereof) saved to {OUTPUT_CSV_FILE}")
        except Exception as e_csv:
            print(f"Error saving data to CSV: {e_csv}")
    else:
        print("No data was processed/collected to save (likely due to XPath mismatches or no links found).")

    print("Scraping process finished.")

if __name__ == "__main__":
    main()