from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 1 # Number of listing pages to process
OUTPUT_CSV_FILE = "kemenkes_courses_new_user_xpaths.csv"

# --- User-defined XPaths ---
USER_XPATH_COURSE_CONTAINERS = "//*[@id='publicContainer']/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div[contains(@class, 'ant-card')]"
# Note: USER_XPATH_LINKS_FROM_CONTAINERS is problematic because it's absolute and doesn't relate to iterating within found containers.
# The script will try to find <a> tags matching the path part, then get @href
USER_XPATH_SPECIFIC_LINK_A_TAG = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a"

# Detail page data XPaths
USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div"

# Next page button XPath (this one is correct for Kemenkes)
USER_XPATH_NEXT_PAGE_LI = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[2]/ul/li[@title='Next Page']"
# --- End User-defined XPaths ---

def main():
    print("Starting Kemenkes LMS Scraper with new user-specified XPaths...")
    print("WARNING: The provided XPaths for course containers and detail page data")
    print("         are unlikely to match the structure of the Kemenkes LMS website.")
    print("         This may result in limited or no course-specific data extraction.")

    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3')
    driver = webdriver.Chrome(service=service, options=options)
    wait = WebDriverWait(driver, 10)

    all_scraped_data = []
    current_listing_page_num = 1

    print(f"Navigating to: {START_URL}")
    driver.get(START_URL)

    while current_listing_page_num <= MAX_LISTING_PAGES_TO_SCRAPE:
        print(f"\n--- Processing Listing Page: {current_listing_page_num} ---")
        
        course_links_to_visit = []

        # 1. Attempt to find course containers using USER_XPATH_COURSE_CONTAINERS
        try:
            print(f"Attempting to find course containers with XPath: '{USER_XPATH_COURSE_CONTAINERS}'")
            # Wait briefly, but expect quick failure or empty list on Kemenkes
            time.sleep(1) 
            course_containers = driver.find_elements(By.XPATH, USER_XPATH_COURSE_CONTAINERS)
            print(f"Found {len(course_containers)} elements matching user's container XPath.")

            if not course_containers:
                print("  No course containers found with the specified XPath.")
                print("  Will now attempt to find links using the user's absolute link XPath, independent of containers.")

            # If containers WERE found (unlikely on Kemenkes), one might try to find links *within* them.
            # However, the user also provided a separate absolute XPath for "link all course".
            # For simplicity and to follow the user's "link all course" instruction,
            # we will use USER_XPATH_SPECIFIC_LINK_A_TAG directly,
            # rather than trying to find links relative to the (likely not found) containers.

        except Exception as e_container:
            print(f"  Error finding containers: {e_container}")
            print("  Will now attempt to find links using the user's absolute link XPath.")

        # 2. Attempt to get links using USER_XPATH_SPECIFIC_LINK_A_TAG
        # This XPath is absolute and likely for a single element, not for iterating "all courses".
        try:
            print(f"Attempting to find link elements with user's specific link XPath: '{USER_XPATH_SPECIFIC_LINK_A_TAG}'")
            link_a_tag_elements = driver.find_elements(By.XPATH, USER_XPATH_SPECIFIC_LINK_A_TAG) # Plural for consistency
            print(f"Found {len(link_a_tag_elements)} <a> element(s) matching the user's specific link XPath.")
            
            if link_a_tag_elements:
                for link_a_tag in link_a_tag_elements:
                    href = link_a_tag.get_attribute('href')
                    if href and href not in course_links_to_visit: # Avoid duplicates if XPath somehow matches multiple identicals
                        course_links_to_visit.append(href)
                        print(f"  Extracted link using specific XPath: {href}")
            else:
                print("  No <a> elements found matching the user's specific link XPath.")

        except Exception as e_link_xpath:
            print(f"  Error using user's specific link XPath '{USER_XPATH_SPECIFIC_LINK_A_TAG}': {e_link_xpath}")
        
        print(f"Collected {len(course_links_to_visit)} unique course links to visit.")

        # 3. Scrape data from each (if any) course link found
        for i, course_url in enumerate(course_links_to_visit):
            page_data = {
                'listing_page': current_listing_page_num,
                'course_link_from_user_xpath': course_url,
                'page_title_selenium': "Not Found", # driver.title
                'contact_user_xpath': "Not Found"
            }
            print(f"  Opening link ({i+1}/{len(course_links_to_visit)}): {course_url[:70]}...")

            original_window = driver.current_window_handle
            driver.execute_script("window.open(arguments[0], '_blank');", course_url)
            WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(len(driver.window_handles)))
            
            new_window = [window for window in driver.window_handles if window != original_window][0]
            driver.switch_to.window(new_window)
            time.sleep(1) 

            try:
                # Wait for body to be present
                wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                time.sleep(1.5)

                # Get Page Title using driver.title
                page_data['page_title_selenium'] = driver.title.strip()
                print(f"    - Page Title (Selenium): '{page_data['page_title_selenium']}'")

                # Attempt to scrape "Contact" using USER_XPATH_DETAIL_PAGE_CONTACT
                try:
                    contact_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT).text.strip()
                    page_data['contact_user_xpath'] = contact_info
                    print(f"    - Contact (User XPath): '{contact_info}'")
                except NoSuchElementException:
                    print(f"    - Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}")
                
            except TimeoutException:
                print(f"    - Timed out loading detail page: {course_url}")
            except Exception as e_detail:
                print(f"    - Error scraping detail page {course_url}: {e_detail}")
            finally:
                all_scraped_data.append(page_data)
                driver.close()
                driver.switch_to.window(original_window)
                time.sleep(0.5)

        # 4. Get next page (using USER_XPATH_NEXT_PAGE_LI - this should work on Kemenkes)
        if current_listing_page_num < MAX_LISTING_PAGES_TO_SCRAPE:
            print("Attempting to go to the next listing page...")
            try:
                next_page_li_element = driver.find_element(By.XPATH, USER_XPATH_NEXT_PAGE_LI)
                
                if "disabled" in next_page_li_element.get_attribute("class").lower():
                    print("Next page button (li) is disabled. No more pages.")
                    break 

                next_page_anchor = next_page_li_element.find_element(By.XPATH, ".//a")
                
                driver.execute_script("arguments[0].scrollIntoView(true);", next_page_anchor)
                time.sleep(0.5)
                driver.execute_script("arguments[0].click();", next_page_anchor)
                print("Clicked 'Next Page'.")
                current_listing_page_num += 1
                time.sleep(2) 
            except NoSuchElementException:
                print("Next page button (li or a) not found with user's XPath. Assuming no more pages.")
                break 
            except Exception as e_pagination:
                print(f"An error occurred during pagination: {e_pagination}")
                break 
        else:
            print("Reached max configured listing pages to scrape.")
            break

    print("\nClosing WebDriver...")
    driver.quit()

    # Save data to CSV
    if all_scraped_data:
        print(f"\nProcessed data. Found {len(all_scraped_data)} entries (check for 'Not Found' values).")
        df = pd.DataFrame(all_scraped_data)
        
        column_order = [
            'listing_page', 
            'course_link_from_user_xpath', 
            'page_title_selenium', 
            'contact_user_xpath'
        ]
        df_ordered = df[[col for col in column_order if col in df.columns]]

        try:
            df_ordered.to_csv(OUTPUT_CSV_FILE, index=False, encoding='utf-8-sig')
            print(f"Data (or lack thereof) saved to {OUTPUT_CSV_FILE}")
        except Exception as e_csv:
            print(f"Error saving data to CSV: {e_csv}")
    else:
        print("No data was processed/collected to save (likely due to XPath mismatches).")

    print("Scraping process finished.")

if __name__ == "__main__":
    main()