from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd
import os # For creating filenames

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 3 # 0 means scrape all pages.
# Base name for CSV files, page number will be appended
OUTPUT_CSV_BASE_FILENAME = "kemenkes_webinar_page_"
AJAX_LOAD_WAIT_SECONDS = 3 # Time to wait after clicking "Next Page"

# --- User-defined Selectors ---
USER_XPATH_CHECKBOX_WEBINAR = "//label[.//span[contains(text(), 'Webinar')]]//input[@type='checkbox']"

# User-provided XPaths (likely mismatched for Kemenkes for these items)
USER_XPATH_COURSE_CONTAINERS = "//*[@id='publicContainer']/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div[contains(@class, 'ant-card')]"
USER_XPATH_SPECIFIC_LINK_A_TAG = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a"
USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div"
# User-provided CSS class for Next Page button (WILL LIKELY FAIL ON KEMENKES if it doesn't exist)
USER_CSS_NEXT_PAGE_BUTTON = ".ant-pagination-item-link"
# --- End Configuration ---

def save_data_to_csv(data_list, page_number, base_filename):
    if not data_list:
        print(f"  No data collected for page {page_number} to save.")
        return

    filename = f"{base_filename}{page_number}.csv"
    df = pd.DataFrame(data_list)
    column_order = ['listing_page', 'course_link', 'page_title_selenium', 'contact_user_xpath']
    # Ensure only existing columns are used in the specified order
    df_ordered = df[[col for col in column_order if col in df.columns]]
    
    try:
        df_ordered.to_csv(filename, index=False, encoding='utf-8-sig')
        print(f"  Data for page {page_number} saved to {filename}")
    except Exception as e_csv:
        print(f"  Error saving data for page {page_number} to CSV: {e_csv}")


def main():
    print("Starting Kemenkes LMS Scraper (Per-Page Processing & Saving, User XPaths)...")
    print("WARNING: Provided XPaths for course containers, links, detail data, AND THE NEXT PAGE BUTTON CLASS")
    print("         are UNLIKELY to match the Kemenkes LMS website structure.")
    print("         This may result in limited/no data extraction and potentially failed pagination.")

    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3')
    driver = webdriver.Chrome(service=service, options=options)
    wait = WebDriverWait(driver, 15) 

    current_listing_page_num = 1

    print(f"Navigating to: {START_URL}")
    driver.get(START_URL)
    main_tab_handle = driver.current_window_handle

    # 0. Click the "Webinar" checkbox filter
    try:
        print(f"Attempting to click 'Webinar' checkbox...")
        wait.until(EC.presence_of_element_located((By.XPATH, "//div[contains(@class,'course-filter-widget')]")))
        time.sleep(0.5)
        webinar_checkbox = wait.until(EC.element_to_be_clickable((By.XPATH, USER_XPATH_CHECKBOX_WEBINAR)))
        webinar_checkbox.click()
        print("'Webinar' checkbox clicked. Waiting for filter to apply...")
        wait.until(EC.url_contains("type=webinar"))
        time.sleep(AJAX_LOAD_WAIT_SECONDS) 
        print("Filter applied (or attempt made) and waited.")
    except Exception as e_checkbox:
        print(f"Error clicking 'Webinar' checkbox or waiting: {e_checkbox}")
        print("Continuing, filter may not be applied.")

    while True: # Loop for pagination
        print(f"\n--- Processing Listing Page: {current_listing_page_num} ---")
        
        data_from_this_page = [] # To store data for the current page's courses
        links_on_this_page = []

        # Attempt to find containers (USER_XPATH_COURSE_CONTAINERS - likely finds 0 on Kemenkes)
        try:
            course_containers = driver.find_elements(By.XPATH, USER_XPATH_COURSE_CONTAINERS)
            if course_containers: print(f"    Found {len(course_containers)} elements matching user's container XPath.")
        except Exception: pass

        # Attempt to get links using USER_XPATH_SPECIFIC_LINK_A_TAG (absolute XPath)
        try:
            link_a_tag_elements = driver.find_elements(By.XPATH, USER_XPATH_SPECIFIC_LINK_A_TAG)
            if link_a_tag_elements: print(f"    Found {len(link_a_tag_elements)} <a> elements with user's specific link XPath.")
            
            for link_a_tag in link_a_tag_elements:
                href = link_a_tag.get_attribute('href')
                if href and href not in links_on_this_page:
                    links_on_this_page.append(href)
        except Exception: pass
        
        print(f"    Found {len(links_on_this_page)} unique link(s) on this page using user's specific link XPath.")

        # Process each link found on the current page
        for i, course_url in enumerate(links_on_this_page):
            print(f"    Processing link {i+1}/{len(links_on_this_page)}: {course_url[:70]}...")
            page_data = {
                'listing_page': current_listing_page_num,
                'course_link': course_url,
                'page_title_selenium': "Not Found",
                'contact_user_xpath': "Not Found"
            }
            
            driver.execute_script("window.open(arguments[0], '_blank');", course_url)
            WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(len(driver.window_handles)))
            
            all_tabs = driver.window_handles
            new_tab_handle = [tab for tab in all_tabs if tab != main_tab_handle][0]
            driver.switch_to.window(new_tab_handle)
            
            try:
                wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                time.sleep(1.5)
                page_data['page_title_selenium'] = driver.title.strip()
                print(f"      Page Title: '{page_data['page_title_selenium']}'")
                try:
                    contact_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT).text.strip()
                    page_data['contact_user_xpath'] = contact_info
                    print(f"      Contact (User XPath): '{contact_info}'")
                except NoSuchElementException:
                    print(f"      Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}")
            except Exception as e_detail:
                print(f"      Error scraping detail page {course_url}: {e_detail}")
            finally:
                data_from_this_page.append(page_data) # Add to current page's data
                driver.close()
                driver.switch_to.window(main_tab_handle)
                time.sleep(0.5)
        
        # Save data collected from this page to a CSV
        save_data_to_csv(data_from_this_page, current_listing_page_num, OUTPUT_CSV_BASE_FILENAME)
        
        # Pagination Logic
        if MAX_LISTING_PAGES_TO_SCRAPE > 0 and current_listing_page_num >= MAX_LISTING_PAGES_TO_SCRAPE:
            print(f"  Reached max configured listing pages: {MAX_LISTING_PAGES_TO_SCRAPE}.")
            break

        print(f"  Attempting to click 'Next Page' using CSS class: '{USER_CSS_NEXT_PAGE_BUTTON}' ...")
        try:
            if driver.current_window_handle != main_tab_handle:
                driver.switch_to.window(main_tab_handle)

            wait.until(EC.presence_of_element_located((By.XPATH, "//ul[contains(@class,'pagination')]")))
            potential_next_buttons = driver.find_elements(By.CSS_SELECTOR, USER_CSS_NEXT_PAGE_BUTTON)
            
            next_page_button_to_click = None
            if len(potential_next_buttons) > 0:
                for button in reversed(potential_next_buttons):
                    try:
                        parent_li = button.find_element(By.XPATH, "./ancestor::li[1]")
                        if "disabled" not in parent_li.get_attribute("class").lower() and \
                           "ant-pagination-disabled" not in parent_li.get_attribute("class").lower():
                            next_page_button_to_click = button
                            break
                    except NoSuchElementException:
                        if not button.get_attribute("disabled"):
                             next_page_button_to_click = button
                             break
            
            if next_page_button_to_click:
                driver.execute_script("arguments[0].scrollIntoView(true);", next_page_button_to_click)
                time.sleep(0.2)
                driver.execute_script("arguments[0].click();", next_page_button_to_click)
                print(f"  Clicked potential 'Next Page' button. Waiting {AJAX_LOAD_WAIT_SECONDS}s for AJAX...")
                time.sleep(AJAX_LOAD_WAIT_SECONDS)
                current_listing_page_num += 1
                print(f"  Assumed page {current_listing_page_num} loaded.")
            else:
                print(f"  No clickable 'Next Page' button found with class '{USER_CSS_NEXT_PAGE_BUTTON}'. Pagination ends.")
                try: # Fallback check for actual Kemenkes next button
                    actual_kemenkes_next_li = driver.find_element(By.XPATH, "//ul[contains(@class,'pagination')]//li[@title='Next Page']")
                    if "disabled" in actual_kemenkes_next_li.get_attribute("class").lower():
                        print("    (Confirmed: Actual Kemenkes 'Next Page' li is disabled).")
                except NoSuchElementException:
                    print("    (Could not find actual Kemenkes 'Next Page' li either).")
                break
        except Exception as e_pagination:
            print(f"  Error during pagination with class '{USER_CSS_NEXT_PAGE_BUTTON}': {e_pagination}. Pagination ends.")
            break
    
    print("\nClosing WebDriver...")
    driver.quit()
    print("Scraping process finished.")

if __name__ == "__main__":
    main()