from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 3 # Number of listing pages to process
OUTPUT_CSV_FILE = "kemenkes_courses_user_specified_selectors.csv"

# --- User-defined Selectors ---
# Common container as specified by user (likely won't match Kemenkes)
USER_COMMON_CONTAINER_CSS = ".ant-card"

# XPath for "link all course" as specified by user (problematic for iteration on Kemenkes)
# The script will find elements matching the path part, then get @href
USER_XPATH_FOR_ALL_LINKS_ON_PAGE_A_TAG = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a"

# XPaths for data on the detail page (likely won't match Kemenkes detail pages)
USER_XPATH_DETAIL_PAGE_TITLE = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[1]/div[2]/h3"
USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div"

# XPath for "Next Page" button (this one IS correct for Kemenkes)
USER_XPATH_NEXT_PAGE_LI = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[2]/ul/li[@title='Next Page']"
# --- End User-defined Selectors ---

def main():
    print("Starting Kemenkes LMS Scraper with user-specified selectors...")
    print("WARNING: The provided selectors for course containers and detail page data")
    print("         are unlikely to match the structure of the Kemenkes LMS website.")
    print("         As a result, limited or no course-specific data may be extracted.")

    # Setup WebDriver
    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3')
    driver = webdriver.Chrome(service=service, options=options)
    wait = WebDriverWait(driver, 10) # Reduced wait time for faster failure if elements not found

    all_scraped_data = []
    current_listing_page_num = 1

    print(f"Navigating to: {START_URL}")
    driver.get(START_URL)

    while current_listing_page_num <= MAX_LISTING_PAGES_TO_SCRAPE:
        print(f"\n--- Processing Listing Page: {current_listing_page_num} ---")
        
        course_links_found_this_page = []

        # 1. Attempt to find common containers (user: .ant-card)
        try:
            print(f"Attempting to find course containers with CSS selector: '{USER_COMMON_CONTAINER_CSS}'")
            # Wait briefly for any potential containers
            # Not using explicit wait here as we expect it to fail or find nothing quickly
            time.sleep(1) # Short pause
            user_course_containers = driver.find_elements(By.CSS_SELECTOR, USER_COMMON_CONTAINER_CSS)
            print(f"Found {len(user_course_containers)} elements matching '{USER_COMMON_CONTAINER_CSS}'.")

            if not user_course_containers:
                print(f"  No elements found with '{USER_COMMON_CONTAINER_CSS}'.")
                print("  Proceeding to attempt link extraction with user's absolute XPath for links.")
        except Exception as e_container:
            print(f"  Error finding containers with '{USER_COMMON_CONTAINER_CSS}': {e_container}")
            print("  Proceeding to attempt link extraction with user's absolute XPath for links.")


        # 2. Attempt to get links using user's absolute XPath for "link all course"
        # This XPath is absolute and likely for a single element, not "all courses" in a list.
        # We will try to find all <a> elements matching this exact path.
        try:
            print(f"Attempting to find link elements with user's XPath: '{USER_XPATH_FOR_ALL_LINKS_ON_PAGE_A_TAG}'")
            link_elements_a_tags = driver.find_elements(By.XPATH, USER_XPATH_FOR_ALL_LINKS_ON_PAGE_A_TAG)
            print(f"Found {len(link_elements_a_tags)} <a> elements matching the user's link XPath.")
            
            if link_elements_a_tags:
                for link_a_tag in link_elements_a_tags:
                    href = link_a_tag.get_attribute('href')
                    if href:
                        course_links_found_this_page.append(href)
                        print(f"  Extracted link: {href}")
                    else:
                        print("  Found <a> tag with user's XPath, but it has no href attribute.")
            else:
                print("  No <a> elements found matching the user's link XPath.")

        except Exception as e_link_xpath:
            print(f"  Error using user's link XPath '{USER_XPATH_FOR_ALL_LINKS_ON_PAGE_A_TAG}': {e_link_xpath}")
        
        print(f"Collected {len(course_links_found_this_page)} course links using user's specified method.")

        # 3. Scrape data from each (if any) course link found
        for i, course_url in enumerate(course_links_found_this_page):
            page_data = {
                'listing_page': current_listing_page_num,
                'course_link_from_user_xpath': course_url,
                'title_user_xpath': "Not Found",
                'contact_user_xpath': "Not Found"
            }
            print(f"  Opening link ({i+1}/{len(course_links_found_this_page)}): {course_url[:70]}...")

            original_window = driver.current_window_handle
            driver.execute_script("window.open(arguments[0], '_blank');", course_url)
            WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(len(driver.window_handles)))
            
            new_window = [window for window in driver.window_handles if window != original_window][0]
            driver.switch_to.window(new_window)
            time.sleep(1) # Allow page to start loading

            try:
                # Wait for some element to consider page loaded, even if it's generic
                wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                time.sleep(1.5)

                # Attempt to scrape Title using USER_XPATH_DETAIL_PAGE_TITLE
                try:
                    title_detail = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_TITLE).text.strip()
                    page_data['title_user_xpath'] = title_detail
                    print(f"    - Title (User XPath): '{title_detail}'")
                except NoSuchElementException:
                    print(f"    - Title NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_TITLE}")

                # Attempt to scrape "Contact" using USER_XPATH_DETAIL_PAGE_CONTACT
                try:
                    contact_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT).text.strip()
                    page_data['contact_user_xpath'] = contact_info
                    print(f"    - Contact (User XPath): '{contact_info}'")
                except NoSuchElementException:
                    print(f"    - Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}")
                
            except TimeoutException:
                print(f"    - Timed out loading detail page: {course_url}")
            except Exception as e_detail:
                print(f"    - Error scraping detail page {course_url}: {e_detail}")
            finally:
                all_scraped_data.append(page_data) # Append data even if some fields are "Not Found"
                driver.close()
                driver.switch_to.window(original_window)
                time.sleep(0.5)

        # 4. Get next page (using USER_XPATH_NEXT_PAGE_LI - this should work on Kemenkes)
        if current_listing_page_num < MAX_LISTING_PAGES_TO_SCRAPE:
            print("Attempting to go to the next listing page...")
            try:
                next_page_li_element = driver.find_element(By.XPATH, USER_XPATH_NEXT_PAGE_LI)
                
                if "disabled" in next_page_li_element.get_attribute("class").lower():
                    print("Next page button (li) is disabled by class. No more pages.")
                    break 

                next_page_anchor = next_page_li_element.find_element(By.XPATH, ".//a") # Find <a> within <li>
                
                driver.execute_script("arguments[0].scrollIntoView(true);", next_page_anchor)
                time.sleep(0.5)
                driver.execute_script("arguments[0].click();", next_page_anchor)
                print("Clicked 'Next Page'.")
                current_listing_page_num += 1
                time.sleep(2) # Wait for new page to start loading
            except NoSuchElementException:
                print("Next page button (li or a) not found using user's XPath. Assuming no more pages.")
                break 
            except Exception as e_pagination:
                print(f"An error occurred during pagination: {e_pagination}")
                break 
        else:
            print("Reached max configured listing pages to scrape.")
            break

    print("\nClosing WebDriver...")
    driver.quit()

    # Save data to CSV
    if all_scraped_data:
        print(f"\nAttempted to scrape data. Found {len(all_scraped_data)} entries (may be mostly 'Not Found').")
        df = pd.DataFrame(all_scraped_data)
        
        column_order = [
            'listing_page', 
            'course_link_from_user_xpath', 
            'title_user_xpath', 
            'contact_user_xpath'
        ]
        df_ordered = df[[col for col in column_order if col in df.columns]]

        try:
            df_ordered.to_csv(OUTPUT_CSV_FILE, index=False, encoding='utf-8-sig')
            print(f"Data (or lack thereof) saved to {OUTPUT_CSV_FILE}")
        except Exception as e_csv:
            print(f"Error saving data to CSV: {e_csv}")
    else:
        print("No data was processed to save (likely due to selector mismatches).")

    print("Scraping process finished.")

if __name__ == "__main__":
    main()