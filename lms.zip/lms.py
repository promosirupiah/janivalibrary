from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd
import os

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 0 # 0 means scrape all pages.
OUTPUT_CSV_BASE_FILENAME = "kemenkes_webinar_page_" 
FINAL_OUTPUT_CSV_FILENAME = "kemenkes_webinar_ALL_collected_data_v2.csv"
AJAX_LOAD_WAIT_SECONDS = 3

# --- User-defined Selectors ---
USER_XPATH_CHECKBOX_WEBINAR = "//label[.//span[contains(text(), 'Webinar')]]//input[@type='checkbox']"
USER_XPATH_COURSE_CONTAINERS = "//*[@id='publicContainer']/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div[contains(@class, 'ant-card')]"
USER_XPATH_SPECIFIC_LINK_A_TAG = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a"

# Detail Page XPaths (User Provided - likely mismatched for Kemenkes)
USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div"
USER_XPATH_DETAIL_PAGE_PROVIDER = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[1]/div[2]/div/div[2]/div/span[2]"

# Pagination (User Provided - likely mismatched for Kemenkes)
USER_CSS_NEXT_PAGE_BUTTON = ".ant-pagination-item-link"
# --- End Configuration ---

# Global list for final save
all_accumulated_data_for_final_save = []

def save_data_to_csv(data_list, filename_or_page_num, base_filename=None, is_final_save=False):
    if not data_list:
        status_msg = "final accumulated data" if is_final_save else f"page {filename_or_page_num}"
        print(f"  No data collected for {status_msg} to save.")
        return

    filename = filename_or_page_num if is_final_save else f"{base_filename}{filename_or_page_num}.csv"
    
    df = pd.DataFrame(data_list)
    # Added 'provider_user_xpath' to column order
    column_order = ['listing_page', 'course_link', 'page_title_selenium', 
                    'contact_user_xpath', 'provider_user_xpath']
    df_ordered = df[[col for col in column_order if col in df.columns]]
    
    try:
        df_ordered.to_csv(filename, index=False, encoding='utf-8-sig')
        status_msg = "Final accumulated data" if is_final_save else f"Data for page {filename_or_page_num}"
        print(f"  {status_msg} saved to {filename}")
    except Exception as e_csv:
        print(f"  Error saving data to {filename}: {e_csv}")


def main():
    global all_accumulated_data_for_final_save
    print("Starting Kemenkes LMS Scraper (Per-Page, Save on Halt, User XPaths, New Provider Field)...")
    print("WARNING: Provided XPaths are UNLIKELY to match Kemenkes LMS structure.")

    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3')
    driver = None 

    try:
        driver = webdriver.Chrome(service=service, options=options)
        wait = WebDriverWait(driver, 15)
        current_listing_page_num = 1

        print(f"Navigating to: {START_URL}")
        driver.get(START_URL)
        main_tab_handle = driver.current_window_handle

        # 0. Click "Webinar" checkbox
        try:
            print(f"Attempting to click 'Webinar' checkbox...")
            wait.until(EC.presence_of_element_located((By.XPATH, "//div[contains(@class,'course-filter-widget')]")))
            time.sleep(0.5)
            webinar_checkbox = wait.until(EC.element_to_be_clickable((By.XPATH, USER_XPATH_CHECKBOX_WEBINAR)))
            webinar_checkbox.click()
            print("'Webinar' checkbox clicked. Waiting for filter...")
            wait.until(EC.url_contains("type=webinar"))
            time.sleep(AJAX_LOAD_WAIT_SECONDS) 
            print("Filter applied (attempted) and waited.")
        except Exception as e_checkbox:
            print(f"Error clicking 'Webinar' checkbox: {e_checkbox}. Continuing.")

        while True: # Pagination loop
            print(f"\n--- Processing Listing Page: {current_listing_page_num} ---")
            
            data_from_this_page = [] 
            links_on_this_page = []

            try: # Containers (likely finds 0 on Kemenkes)
                course_containers = driver.find_elements(By.XPATH, USER_XPATH_COURSE_CONTAINERS)
                if course_containers: print(f"    Found {len(course_containers)} user containers.")
            except Exception: pass

            try: # Links (absolute XPath, likely finds 0 or 1 on Kemenkes)
                link_a_tag_elements = driver.find_elements(By.XPATH, USER_XPATH_SPECIFIC_LINK_A_TAG)
                if link_a_tag_elements: print(f"    Found {len(link_a_tag_elements)} user link elements.")
                for link_a_tag in link_a_tag_elements:
                    href = link_a_tag.get_attribute('href')
                    if href and href not in links_on_this_page:
                        links_on_this_page.append(href)
            except Exception: pass
            
            print(f"    Found {len(links_on_this_page)} unique link(s) on this page using user's link XPath.")

            for i, course_url in enumerate(links_on_this_page):
                print(f"    Processing link {i+1}/{len(links_on_this_page)}: {course_url[:70]}...")
                page_data = {
                    'listing_page': current_listing_page_num,
                    'course_link': course_url,
                    'page_title_selenium': "Not Found",
                    'contact_user_xpath': "Not Found",
                    'provider_user_xpath': "Not Found" # New field
                }
                
                driver.execute_script("window.open(arguments[0], '_blank');", course_url)
                WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(len(driver.window_handles)))
                
                all_tabs = driver.window_handles
                new_tab_handle = [tab for tab in all_tabs if tab != main_tab_handle][0]
                driver.switch_to.window(new_tab_handle)
                
                try:
                    wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                    time.sleep(1.5)
                    page_data['page_title_selenium'] = driver.title.strip()
                    print(f"      Page Title: '{page_data['page_title_selenium']}'")
                    
                    try: # Contact
                        contact_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT).text.strip()
                        page_data['contact_user_xpath'] = contact_info
                        print(f"      Contact (User XPath): '{contact_info}'")
                    except NoSuchElementException:
                        print(f"      Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}")
                    
                    try: # Provider (New)
                        provider_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_PROVIDER).text.strip()
                        page_data['provider_user_xpath'] = provider_info
                        print(f"      Provider (User XPath): '{provider_info}'")
                    except NoSuchElementException:
                        print(f"      Provider NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_PROVIDER}")

                except Exception as e_detail:
                    print(f"      Error scraping detail page {course_url}: {e_detail}")
                finally:
                    data_from_this_page.append(page_data)
                    all_accumulated_data_for_final_save.append(page_data)
                    driver.close()
                    driver.switch_to.window(main_tab_handle)
                    time.sleep(0.5)
            
            save_data_to_csv(data_from_this_page, current_listing_page_num, OUTPUT_CSV_BASE_FILENAME)
            
            # Pagination
            if MAX_LISTING_PAGES_TO_SCRAPE > 0 and current_listing_page_num >= MAX_LISTING_PAGES_TO_SCRAPE:
                print(f"  Reached max configured listing pages.")
                break

            print(f"  Attempting to click 'Next Page' using CSS class: '{USER_CSS_NEXT_PAGE_BUTTON}' ...")
            try:
                if driver.current_window_handle != main_tab_handle:
                    driver.switch_to.window(main_tab_handle)

                wait.until(EC.presence_of_element_located((By.XPATH, "//ul[contains(@class,'pagination')]")))
                potential_next_buttons = driver.find_elements(By.CSS_SELECTOR, USER_CSS_NEXT_PAGE_BUTTON)
                
                next_page_button_to_click = None
                if len(potential_next_buttons) > 0:
                    for button in reversed(potential_next_buttons):
                        try:
                            parent_li = button.find_element(By.XPATH, "./ancestor::li[1]")
                            if "disabled" not in parent_li.get_attribute("class").lower() and \
                               "ant-pagination-disabled" not in parent_li.get_attribute("class").lower():
                                next_page_button_to_click = button
                                break
                        except NoSuchElementException:
                            if not button.get_attribute("disabled"):
                                 next_page_button_to_click = button
                                 break
                
                if next_page_button_to_click:
                    driver.execute_script("arguments[0].scrollIntoView(true);", next_page_button_to_click)
                    time.sleep(0.2)
                    driver.execute_script("arguments[0].click();", next_page_button_to_click)
                    print(f"  Clicked potential 'Next Page'. Waiting {AJAX_LOAD_WAIT_SECONDS}s for AJAX...")
                    time.sleep(AJAX_LOAD_WAIT_SECONDS)
                    current_listing_page_num += 1
                    print(f"  Assumed page {current_listing_page_num} loaded.")
                else:
                    print(f"  No clickable 'Next Page' button with class '{USER_CSS_NEXT_PAGE_BUTTON}'. Pagination ends.")
                    try: 
                        actual_kemenkes_next_li = driver.find_element(By.XPATH, "//ul[contains(@class,'pagination')]//li[@title='Next Page']")
                        if "disabled" in actual_kemenkes_next_li.get_attribute("class").lower():
                            print("    (Confirmed: Actual Kemenkes 'Next Page' li is disabled).")
                    except NoSuchElementException:
                        print("    (Could not find actual Kemenkes 'Next Page' li).")
                    break
            except Exception as e_pagination:
                print(f"  Error during pagination: {e_pagination}. Pagination ends.")
                break
        
    except KeyboardInterrupt:
        print("\nCtrl+C pressed. Script interrupted. Attempting to save data...")
    except Exception as e_main:
        print(f"\nUnexpected error in main loop: {e_main}. Attempting to save data...")
    finally:
        if driver:
            print("\nClosing WebDriver...")
            driver.quit()
        print("\nAttempting final save of all accumulated data...")
        save_data_to_csv(all_accumulated_data_for_final_save, FINAL_OUTPUT_CSV_FILENAME, is_final_save=True)
        print("Scraping process finished or halted.")

if __name__ == "__main__":
    main()