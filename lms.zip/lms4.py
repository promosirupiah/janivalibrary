from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd

# --- User Configuration ---
START_URL = "https://lms.kemkes.go.id/courses?search="
MAX_LISTING_PAGES_TO_SCRAPE = 0 # 0 means scrape all pages.
OUTPUT_CSV_FILE = "kemenkes_webinar_phase_scraping.csv"

# --- User-defined Selectors ---
USER_XPATH_CHECKBOX_WEBINAR = "//label[.//span[contains(text(), 'Webinar')]]//input[@type='checkbox']"

# User-provided XPaths (likely mismatched for Kemenkes for these items)
USER_XPATH_COURSE_CONTAINERS = "//*[@id='publicContainer']/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div[contains(@class, 'ant-card')]"
USER_XPATH_SPECIFIC_LINK_A_TAG = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[3]/div[2]/div[1]/div/div[2]/div/div[2]/div[2]/a"
USER_XPATH_DETAIL_PAGE_CONTACT = "/html/body/div/div/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[6]/div/div"
USER_CSS_NEXT_PAGE_BUTTON = ".ant-pagination-item-link" # WILL LIKELY FAIL ON KEMENKES

# RELIABLE XPath for Kemenkes course cards (used for AJAX wait validation IF pagination worked with a correct selector)
RELIABLE_KEMENKES_COURSE_CARD_XPATH = "//div[contains(@class, 'course-box-wrap')]"
# --- End Configuration ---

def main():
    print("Starting Kemenkes LMS Scraper (Two-Phase: Links First)...")
    print("WARNING: Provided XPaths for course containers, links, detail data, AND THE NEXT PAGE BUTTON CLASS")
    print("         are UNLIKELY to match the Kemenkes LMS website structure.")
    print("         This may result in limited/no data extraction and failed pagination.")

    service = Service(ChromeDriverManager().install())
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    # options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument('log-level=3')
    driver = webdriver.Chrome(service=service, options=options)
    wait = WebDriverWait(driver, 15)

    all_course_links_collected = [] # To store all links before processing details
    current_listing_page_num = 1

    print(f"Navigating to: {START_URL}")
    driver.get(START_URL)

    # Phase 0: Click the "Webinar" checkbox filter
    try:
        print(f"Attempting to click 'Webinar' checkbox...")
        wait.until(EC.presence_of_element_located((By.XPATH, "//div[contains(@class,'course-filter-widget')]")))
        time.sleep(0.5)
        webinar_checkbox = wait.until(EC.element_to_be_clickable((By.XPATH, USER_XPATH_CHECKBOX_WEBINAR)))
        webinar_checkbox.click()
        print("'Webinar' checkbox clicked. Waiting for filter to apply...")
        wait.until(EC.url_contains("type=webinar"))
        time.sleep(1)
        try:
            wait.until(EC.presence_of_element_located((By.XPATH, RELIABLE_KEMENKES_COURSE_CARD_XPATH)))
        except TimeoutException: print("  No webinar courses found after filtering or filter issues.")
        print("Filter applied (or attempt made).")
    except Exception as e_checkbox:
        print(f"Error clicking 'Webinar' checkbox or waiting: {e_checkbox}")
        print("Continuing, filter may not be applied.")

    # Phase 1: Collect all course links
    print("\n--- Phase 1: Collecting All Course Links ---")
    first_page_processed_flag = False
    while True:
        print(f"  Processing Listing Page {current_listing_page_num} for links...")

        if first_page_processed_flag: # For page 2 onwards, verify new content
            print("    Verifying new page content after pagination attempt...")
            try:
                expected_url_param = f"&page={current_listing_page_num}"
                if current_listing_page_num > 1:
                    wait.until(EC.url_contains(expected_url_param))
                wait.until(EC.visibility_of_element_located((By.XPATH, RELIABLE_KEMENKES_COURSE_CARD_XPATH)))
                time.sleep(1)
            except TimeoutException:
                print(f"    Timeout waiting for new content on page {current_listing_page_num}. Pagination likely failed.")
                break

        links_on_this_page = []
        # Attempt to find containers (USER_XPATH_COURSE_CONTAINERS - likely finds 0 on Kemenkes)
        try:
            course_containers = driver.find_elements(By.XPATH, USER_XPATH_COURSE_CONTAINERS)
            if course_containers: print(f"    Found {len(course_containers)} elements matching user's container XPath.")
            else: print(f"    No containers found with user's XPath: '{USER_XPATH_COURSE_CONTAINERS}'.")
        except Exception: pass # Ignore if container XPath fails, proceed to link XPath

        # Attempt to get links using USER_XPATH_SPECIFIC_LINK_A_TAG (absolute XPath)
        try:
            link_a_tag_elements = driver.find_elements(By.XPATH, USER_XPATH_SPECIFIC_LINK_A_TAG)
            if link_a_tag_elements: print(f"    Found {len(link_a_tag_elements)} <a> elements with user's specific link XPath.")
            else: print(f"    No <a> elements found with user's specific link XPath: '{USER_XPATH_SPECIFIC_LINK_A_TAG}'.")
            
            for link_a_tag in link_a_tag_elements:
                href = link_a_tag.get_attribute('href')
                if href and href not in all_course_links_collected: # Add if valid and unique
                    links_on_this_page.append(href)
                    all_course_links_collected.append(href)
        except Exception: pass # Ignore if link XPath fails

        print(f"    Collected {len(links_on_this_page)} new unique links on this page.")
        first_page_processed_flag = True

        # Pagination Logic
        if MAX_LISTING_PAGES_TO_SCRAPE > 0 and current_listing_page_num >= MAX_LISTING_PAGES_TO_SCRAPE:
            print(f"  Reached max configured listing pages for link collection: {MAX_LISTING_PAGES_TO_SCRAPE}.")
            break

        print(f"  Attempting to click 'Next Page' using CSS class: '{USER_CSS_NEXT_PAGE_BUTTON}' ...")
        try:
            wait.until(EC.presence_of_element_located((By.XPATH, "//ul[contains(@class,'pagination')]")))
            potential_next_buttons = driver.find_elements(By.CSS_SELECTOR, USER_CSS_NEXT_PAGE_BUTTON)
            
            next_page_button_to_click = None
            if len(potential_next_buttons) > 0:
                for button in reversed(potential_next_buttons):
                    try: # More robust check for disabled state common in Ant Design
                        parent_li = button.find_element(By.XPATH, "./ancestor::li[1]")
                        if "disabled" not in parent_li.get_attribute("class").lower() and \
                           "ant-pagination-disabled" not in parent_li.get_attribute("class").lower():
                            next_page_button_to_click = button
                            break
                    except NoSuchElementException: # Button might not be in an LI, or structure is different
                        if not button.get_attribute("disabled"): # Simplest check if not in LI
                            next_page_button_to_click = button
                            break 
            
            if next_page_button_to_click:
                driver.execute_script("arguments[0].scrollIntoView(true);", next_page_button_to_click)
                time.sleep(0.2)
                driver.execute_script("arguments[0].click();", next_page_button_to_click)
                print(f"  Clicked potential 'Next Page' button.")
                current_listing_page_num += 1
            else:
                print(f"  No clickable 'Next Page' button found with class '{USER_CSS_NEXT_PAGE_BUTTON}'. Pagination ends.")
                break
        except Exception as e_pagination:
            print(f"  Error during pagination with class '{USER_CSS_NEXT_PAGE_BUTTON}': {e_pagination}. Pagination ends.")
            break
    
    print(f"\n--- Phase 1 Complete: Collected a total of {len(all_course_links_collected)} unique links ---")

    # Phase 2: Open each collected link and get data
    all_detailed_data = []
    if all_course_links_collected:
        print("\n--- Phase 2: Getting Details for Each Collected Link ---")
        for i, course_url in enumerate(all_course_links_collected):
            print(f"  Processing link {i+1}/{len(all_course_links_collected)}: {course_url[:70]}...")
            page_data = {
                'course_link': course_url,
                'page_title_selenium': "Not Found",
                'contact_user_xpath': "Not Found"
            }
            try:
                driver.get(course_url) # Use get() for direct navigation, new tabs not strictly needed here
                wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                time.sleep(1.5)

                page_data['page_title_selenium'] = driver.title.strip()
                print(f"    Page Title: '{page_data['page_title_selenium']}'")

                try:
                    contact_info = driver.find_element(By.XPATH, USER_XPATH_DETAIL_PAGE_CONTACT).text.strip()
                    page_data['contact_user_xpath'] = contact_info
                    print(f"    Contact (User XPath): '{contact_info}'")
                except NoSuchElementException:
                    print(f"    Contact NOT found with user XPath: {USER_XPATH_DETAIL_PAGE_CONTACT}")
                
            except TimeoutException:
                print(f"    Timed out loading detail page: {course_url}")
            except Exception as e_detail:
                print(f"    Error scraping detail page {course_url}: {e_detail}")
            finally:
                all_detailed_data.append(page_data)
                time.sleep(0.5) # Small pause between detail page loads
    else:
        print("No links were collected in Phase 1, skipping Phase 2.")

    print("\nClosing WebDriver...")
    driver.quit()

    # Save data to CSV
    if all_detailed_data:
        print(f"\nProcessed details for {len(all_detailed_data)} links.")
        df = pd.DataFrame(all_detailed_data)
        column_order = ['course_link', 'page_title_selenium', 'contact_user_xpath']
        df_ordered = df[[col for col in column_order if col in df.columns]]
        try:
            df_ordered.to_csv(OUTPUT_CSV_FILE, index=False, encoding='utf-8-sig')
            print(f"Data (or lack thereof) saved to {OUTPUT_CSV_FILE}")
        except Exception as e_csv: print(f"Error saving data to CSV: {e_csv}")
    else:
        print("No detailed data was processed/collected to save.")
    print("Scraping process finished.")

if __name__ == "__main__":
    main()