## Description
Adds new callback to Dynamic Field widget, which allows to convert returns trimmed string.

## Instructions
- Install and activate the plugin;
- Go to Elementor/Blocks editor, Dynamic Field widget and find *Trim string by chars* in the *Callback* option;
- Set chars number you want to display into * String length * option.
