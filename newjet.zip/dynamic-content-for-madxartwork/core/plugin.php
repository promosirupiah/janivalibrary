<?php

namespace DynamicContentFormadxartwork;

use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Features;
use DynamicContentFormadxartwork\Core\Upgrade\Manager as UpgradeManager;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly.
}
/**
 * Main Plugin Class
 *
 * @since 0.0.1
 */
class Plugin
{
    /**
     * @var \DynamicContentFormadxartwork\Controls
     */
    public $controls;
    /**
     * @var \DynamicContentFormadxartwork\Widgets
     */
    public $widgets;
    /**
     * @var \DynamicLicense\License
     */
    public $license_system;
    /**
     * @var \DynamicContentFormadxartwork\Features
     */
    public $features;
    /**
     * @var \DynamicContentFormadxartwork\SaveGuard
     */
    public $save_guard;
    /**
     * @var \DynamicContentFormadxartwork\Cryptocurrency
     */
    public $cryptocurrency;
    /**
     * @var \DynamicContentFormadxartwork\PdfHtmlTemplates
     */
    public $pdf_html_templates;
    /**
     * @var \DynamicContentFormadxartwork\TemplateSystem
     */
    public $template_system;
    /**
     * @var \DynamicContentFormadxartwork\Updates
     */
    public $updates;
    /**
     * @var \DynamicContentFormadxartwork\Wpml
     */
    public $wpml;
    /**
     * @var \DynamicContentFormadxartwork\Stripe
     */
    public $stripe;
    /**
     * @var AdminPages\Manager
     */
    public $admin_pages;
    /**
     * @var \DynamicContentFormadxartwork\PageSettings
     */
    public $page_settings;
    /**
     * @var \DynamicContentFormadxartwork\Extensions
     */
    public $extensions;
    /**
     * @var \DynamicContentFormadxartwork\RollbackManager
     */
    public $rollback_manager;
    public $assets;
    protected static $instance;
    public $cron;
    /**
     * @var UpgradeManager
     */
    public $upgrade;
    /**
     * Constructor
     *
     * @since 0.0.1
     * @access public
     */
    public function __construct()
    {
        self::$instance = $this;
        $this->init();
    }
    /**
     * @return Plugin
     */
    public static function instance()
    {
        if (\is_null(self::$instance)) {
            // Ensure madxartwork Free is active
            if (!did_action('madxartwork/loaded')) {
                add_action('admin_notices', 'dce_fail_load');
                // having a function return ?Plugin would put too much burden on the code:
                // @phpstan-ignore-next-line
                return null;
            }
            // Check madxartwork version
            if (\version_compare(madxartwork_VERSION, DCE_MINIMUM_madxartwork_VERSION, '<')) {
                add_action('admin_notices', 'dce_admin_notice_minimum_madxartwork_version');
                // @phpstan-ignore-next-line
                return null;
            }
            // Check madxartwork Pro version
            if (\defined('madxartwork_PRO_VERSION') && \version_compare(madxartwork_PRO_VERSION, DCE_MINIMUM_madxartwork_PRO_VERSION, '<')) {
                add_action('admin_notices', 'dce_admin_notice_minimum_madxartwork_pro_version');
                // @phpstan-ignore-next-line
                return null;
            }
            new self();
        }
        return self::$instance;
    }
    public function init()
    {
        $this->init_managers();
        add_action('madxartwork/init', [$this, 'add_dce_to_madxartwork'], 0);
        add_filter('plugin_action_links_' . DCE_PLUGIN_BASE, [$this, 'plugin_action_links']);
        add_filter('plugin_row_meta', [$this, 'plugin_row_meta'], 10, 2);
        add_filter('pre_handle_404', '\\DynamicContentFormadxartwork\\Helper::maybe_allow_posts_pagination', 1, 2);
        // Enchanted Tab for madxartwork Pro Form
        $features_enchanted = self::instance()->features->filter_by_tag('enchanted');
        $active_features_enchanted = \array_filter($features_enchanted, function ($e) {
            return 'active' === $e['status'];
        });
        if (!empty($active_features_enchanted)) {
            add_action('madxartwork/element/form/section_form_fields/before_section_end', [$this, 'add_form_fields_enchanted_tab']);
        }
    }
    public function init_managers()
    {
        $this->save_guard = new \DynamicContentFormadxartwork\SaveGuard();
        $this->features = new Features();
        $this->controls = new \DynamicContentFormadxartwork\Controls();
        $this->page_settings = new \DynamicContentFormadxartwork\PageSettings();
        $this->admin_pages = new \DynamicContentFormadxartwork\AdminPages\Manager();
        $this->widgets = new \DynamicContentFormadxartwork\Widgets();
        $this->stripe = new \DynamicContentFormadxartwork\Stripe();
        $this->pdf_html_templates = new \DynamicContentFormadxartwork\PdfHtmlTemplates();
        $this->cryptocurrency = new \DynamicContentFormadxartwork\Cryptocurrency();
        new \DynamicContentFormadxartwork\Ajax();
        $this->assets = new \DynamicContentFormadxartwork\Assets();
        $this->license_system = new \DynamicOOOS\DynamicLicense\License(['prefix' => DCE_PREFIX, 'plugin_base' => DCE_PLUGIN_BASE, 'slug' => DCE_SLUG, 'admin_license_page' => 'dce-license', 'beta_option' => 'dce_beta', 'product_unique_id' => 'WP-DCE-1', 'version' => DCE_VERSION, 'license_url' => DCE_LICENSE_URL, 'pricing_page' => DCE_PRICING_PAGE], $this->admin_pages->notices, [
            // translators: 1: opening HTML anchor tag for activating the license, 2: closing HTML anchor tag, 3: opening HTML anchor tag for purchasing the license, 4: closing HTML anchor tag
            'buy' => esc_html__('It seems that your copy is not activated, please %1$sactivate it%2$s or %3$sbuy a new license%4$s.', 'dynamic-content-for-madxartwork'),
        ]);
        $this->rollback_manager = new \DynamicContentFormadxartwork\RollbackManager();
        $this->updates = new \DynamicContentFormadxartwork\Updates();
        $this->wpml = new \DynamicContentFormadxartwork\Wpml();
        $this->cron = new \DynamicContentFormadxartwork\Cron();
        $this->template_system = new \DynamicContentFormadxartwork\TemplateSystem();
        new \DynamicContentFormadxartwork\Elements();
        // WP-CLI Integration
        if (\defined('WP_CLI') && WP_CLI) {
            new \DynamicContentFormadxartwork\WpCli();
            \WP_CLI::add_command('dce', \DynamicContentFormadxartwork\WpCli::class);
        }
        // Init hook
        do_action('dynamic_content_for_madxartwork/init');
    }
    /**
     * Activation fired by 'register_activation_hook'
     */
    public static function activation()
    {
        set_transient('dce_activation_redirect', \true, MINUTE_IN_SECONDS);
    }
    /**
     * Uninstall fired by 'register_uninstall_hook'
     */
    public static function uninstall()
    {
        self::instance()->license_system->deactivate_license();
        // If the deactivation request returns an error the license key is not removed, so it's better to remove the key manually
        delete_option('dce_license_key');
        self::instance()->cron->clear_all_tasks();
        if (\defined('DCE_REMOVE_ALL_DATA') && DCE_REMOVE_ALL_DATA) {
            delete_option(DCE_TEMPLATE_SYSTEM_OPTION);
            delete_option(Features::FEATURES_STATUS_OPTION);
        }
    }
    /**
     * Add Actions
     *
     * @since 0.0.1
     *
     * @access private
     */
    public function add_dce_to_madxartwork()
    {
        // Global Settings Panel
        \DynamicContentFormadxartwork\GlobalSettings::init();
        $this->upgrade = UpgradeManager::instance();
        // Controls
        add_action('madxartwork/controls/controls_registered', [$this->controls, 'on_controls_registered']);
        // Force Dynamic Tags
        if (!\defined('DCE_NO_CM_OVERRIDE') || !DCE_NO_CM_OVERRIDE) {
            \madxartwork\Plugin::$instance->controls_manager = new \DynamicContentFormadxartwork\ForceDynamicTags();
        }
        // Extensions
        $this->extensions = new \DynamicContentFormadxartwork\Extensions();
        // Page Settings
        $this->page_settings->on_page_settings_registered();
        // Widgets
        add_action('madxartwork/widgets/register', [$this->widgets, 'on_widgets_registered']);
    }
    /**
     * Add Enchanted Tab for Form Fields
     *
     * This form tab is used for many extensions. We put it here avoiding repetition
     *
     * @param \madxartwork\Widget_Base $widget
     * @return void
     */
    public function add_form_fields_enchanted_tab(\madxartwork\Widget_Base $widget)
    {
        $madxartwork = \madxartworkPro\Plugin::madxartwork();
        $control_data = $madxartwork->controls_manager->get_control_from_stack($widget->get_unique_name(), 'form_fields');
        if (is_wp_error($control_data)) {
            return;
        }
        $field_controls = ['form_fields_enchanted_tab' => ['type' => 'tab', 'tab' => 'enchanted', 'label' => '<i class="dynicon icon-dce-logo-dce" aria-hidden="true"></i>', 'tabs_wrapper' => 'form_fields_tabs', 'name' => 'form_fields_enchanted_tab', 'condition' => ['field_type!' => 'step']]];
        $control_data['fields'] = \array_merge($control_data['fields'], $field_controls);
        $widget->update_control('form_fields', $control_data);
    }
    public static function plugin_action_links($links)
    {
        $links['config'] = '<a title="' . esc_html__('Features', 'dynamic-content-for-madxartwork') . '" href="' . admin_url() . 'admin.php?page=dce-features">' . esc_html__('Features', 'dynamic-content-for-madxartwork') . '</a>';
        return $links;
    }
    public function plugin_row_meta($plugin_meta, $plugin_file)
    {
        if ('dynamic-content-for-madxartwork/dynamic-content-for-madxartwork.php' === $plugin_file) {
            $row_meta = ['docs' => '<a href="https://help.dynamic.ooo/" aria-label="' . esc_attr(esc_html__('View Documentation', 'dynamic-content-for-madxartwork')) . '" target="_blank">' . esc_html__('Docs', 'dynamic-content-for-madxartwork') . '</a>', 'community' => '<a href="https://facebook.com/groups/dynamic.ooo" aria-label="' . esc_attr(esc_html__('Facebook Community', 'dynamic-content-for-madxartwork')) . '" target="_blank">' . esc_html__('FB Community', 'dynamic-content-for-madxartwork') . '</a>'];
            $plugin_meta = \array_merge($plugin_meta, $row_meta);
        }
        return $plugin_meta;
    }
}
\DynamicContentFormadxartwork\Plugin::instance();
