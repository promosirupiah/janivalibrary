(
	function ( $ ) {
		var WidgetElements_SvgFilterEffectsHandler = function ( $scope,$ ) {
			var id_scope = $scope.attr( 'data-id' );
			var feDisp = $scope.find( 'feDisplacementMap#displacement-map' )[ 0 ];			
			var tl = gsap.timeline( {
				repeat: -1,
				repeatDelay: 1
			} );
						
			// pulisco tutto
			if ( madxartworkFrontend.isEditMode() ) {
				if ( tl ) {
					tl.kill( feDisp );
				}
				$( '.madxartwork-element[data-id=' + id_scope + '] svg' );
			}
		};
		
		$( window ).on( 'madxartwork/frontend/init',function () {
			madxartworkFrontend.hooks.addAction( 'frontend/element_ready/dyncontel-filtereffects.default',
				WidgetElements_SvgFilterEffectsHandler );
		} );
	}
)( jQuery );
