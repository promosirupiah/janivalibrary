<?php

namespace DynamicContentFormadxartwork\Extensions\DynamicTags;

use DynamicContentFormadxartwork\Extensions\ExtensionPrototype;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class Terms extends ExtensionPrototype
{
    public function __construct()
    {
        parent::__construct();
        $this->add_dynamic_tag('Terms');
    }
}
