<?php

namespace DynamicContentFormadxartwork\Extensions;

use madxartwork\Controls_Manager;
use madxartwork\Group_Control_Background;
use DynamicContentFormadxartwork\Helper;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly
}
class DynamicCountdown extends \DynamicContentFormadxartwork\Extensions\ExtensionPrototype
{
    private $is_common = \false;
    public function get_script_depends()
    {
        return ['dce-dynamic-countdown', 'dce-dayjs'];
    }
    protected function add_actions()
    {
        add_action('madxartwork/element/countdown/section_countdown/before_section_end', [$this, 'add_dynamic_countdown'], 10, 2);
        add_action('madxartwork/frontend/widget/before_render', [$this, 'render_countdown'], 1, 1);
    }
    public function add_dynamic_countdown($element, $args)
    {
        $element->add_control('dynamic_due_date', ['label' => '<span class="color-dce icon-dce-logo-dce"></span> ' . esc_html__('Dynamic Due Date', 'dynamic-content-for-madxartwork'), 'description' => esc_html__('This field, if not empty, overwrites the due date value. This value is shown only on frontend mode. It should be in the format "Y-m-d H:i:s"', 'dynamic-content-for-madxartwork'), 'label_block' => \true, 'separator' => 'before', 'placeholder' => 'Y-m-d H:i:s', 'frontend_available' => \true, 'type' => Controls_Manager::TEXT, 'dynamic' => ['active' => \true], 'condition' => ['countdown_type' => 'due_date']]);
    }
    public function render_countdown($element)
    {
        if ('countdown' === $element->get_name()) {
            $this->enqueue_all();
        }
    }
}
