<?php

namespace DynamicContentFormadxartwork\Controls;

use madxartwork\Control_Base_Multiple;
use madxartwork\Controls_Manager;
if (!\defined('ABSPATH')) {
    exit;
    // Exit if accessed directly.
}
/**
 * madxartwork Transforms Control.
 *
 */
class Control_Transforms extends Control_Base_Multiple
{
    /**
     * Get box shadow control type.
     *
     * Retrieve the control type, in this case `transforms`.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Control type.
     */
    public function get_type()
    {
        return 'transforms';
    }
    public function enqueue()
    {
        // Scripts
        wp_register_script('transforms-control', plugins_url('/assets/js/transforms-control.js', DCE__FILE__), ['jquery'], DCE_VERSION);
        wp_enqueue_script('transforms-control');
    }
    public function get_default_value()
    {
        return ['angle' => 0, 'rotate_x' => 0, 'rotate_y' => 0, 'translate_x' => 0, 'translate_y' => 0, 'translate_z' => 0, 'scale' => 1];
    }
    protected function get_default_settings()
    {
        return ['label_block' => \true];
    }
    /**
     * Get box shadow control sliders.
     *
     * Retrieve the sliders of the box shadow control. Sliders are used while
     * rendering the control output in the editor.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Control sliders.
     */
    public function get_sliders()
    {
        return ['angle' => ['label' => esc_html__('Angle', 'dynamic-content-for-madxartwork'), 'min' => -360, 'max' => 360, 'step' => 1], 'rotate_x' => ['label' => esc_html__('Rotate X', 'dynamic-content-for-madxartwork'), 'min' => -360, 'max' => 360, 'step' => 1], 'rotate_y' => ['label' => esc_html__('Rotate Y', 'dynamic-content-for-madxartwork'), 'min' => -360, 'max' => 360, 'step' => 1], 'translate_x' => ['label' => esc_html__('Translate X', 'dynamic-content-for-madxartwork'), 'min' => -1000, 'max' => 1000, 'step' => 1], 'translate_y' => ['label' => esc_html__('Translate Y', 'dynamic-content-for-madxartwork'), 'min' => -1000, 'max' => 1000, 'step' => 1], 'translate_z' => ['label' => esc_html__('Translate Z', 'dynamic-content-for-madxartwork'), 'min' => -1000, 'max' => 1000, 'step' => 1], 'scale' => ['label' => esc_html__('Scale', 'dynamic-content-for-madxartwork'), 'min' => 0.1, 'max' => 3, 'step' => 0.1]];
    }
    /**
     * Render box shadow control output in the editor.
     *
     * Used to generate the control HTML in the editor using Underscore JS
     * template. The variables for the class are available using `data` JS
     * object.
     *
     * @since 1.0.0
     * @access public
     */
    public function content_template()
    {
        $control_uid = $this->get_control_uid();
        ?>
		<div class="madxartwork-control-field">
			<label class="madxartwork-control-title control-title-first">{{{ data.label }}}</label>
			<button href="#" class="reset-controls" title="Reset"><i class="eicon-close"></i></button>
		</div>
		<?php 
        foreach ($this->get_sliders() as $slider_name => $slider) {
            $control_uid = $this->get_control_uid($slider_name);
            ?>
			<div class="madxartwork-control-field madxartwork-control-type-slider">
				<label for="<?php 
            echo esc_attr($control_uid);
            ?>" class="madxartwork-control-title-transforms"><?php 
            echo $slider['label'];
            ?></label>
				<div class="madxartwork-control-input-wrapper">
					<div class="madxartwork-slider" data-input="<?php 
            echo esc_attr($slider_name);
            ?>"></div>
					<div class="madxartwork-slider-input">
						<input id="<?php 
            echo esc_attr($control_uid);
            ?>" type="number" min="<?php 
            echo esc_attr($slider['min']);
            ?>" max="<?php 
            echo esc_attr($slider['max']);
            ?>" step="<?php 
            echo esc_attr($slider['step']);
            ?>" data-setting="<?php 
            echo esc_attr($slider_name);
            ?>"/>
					</div>
				</div>
			</div>
		<?php 
        }
        ?>
		<?php 
    }
}
