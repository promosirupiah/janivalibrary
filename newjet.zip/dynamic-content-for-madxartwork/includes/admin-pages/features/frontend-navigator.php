<?php

namespace DynamicContentFormadxartwork\AdminPages\Features;

use DynamicContentFormadxartwork\Helper;
use DynamicContentFormadxartwork\Assets;
class FrontendNavigator
{
    /**
     * Get Name
     *
     * @return string
     */
    public function get_name()
    {
        return 'frontend-navigator';
    }
    /**
     * Get Label
     *
     * @return string
     */
    public function get_label()
    {
        return esc_html__('Frontend Navigator', 'dynamic-content-for-madxartwork');
    }
    /**
     * Should Display Count
     *
     * @return boolean
     */
    public function should_display_count()
    {
        return \false;
    }
    /**
     * Render
     *
     * @return void
     */
    public function render()
    {
        ?>

		<form action="" method="post">
			<?php 
        wp_nonce_field('dce-settings-page', 'dce-settings-page');
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['frontend_navigator'])) {
            update_option(DCE_FRONTEND_NAVIGATOR_OPTION, $_POST['frontend_navigator']);
            \DynamicContentFormadxartwork\Plugin::instance()->admin_pages->notices->success(esc_html__('Your preferences have been saved.', 'dynamic-content-for-madxartwork'));
        }
        ?>
			<?php 
        $option = get_option(DCE_FRONTEND_NAVIGATOR_OPTION);
        ?>

			<table class="form-table">
				<tbody>
				<tr>
					<th scope="row">
						<div>
							<label for="frontend_navigator"><?php 
        _e('Frontend Navigator', 'dynamic-content-for-madxartwork');
        ?></label>
						</div>
					</th>
					<td>
					<div>
					<select name="frontend_navigator">
						<option value="active" <?php 
        if ($option === 'active') {
            ?>selected="selected"<?php 
        }
        ?>><?php 
        _e('Active only for administrators', 'dynamic-content-for-madxartwork');
        ?></option>
						<option value="inactive" <?php 
        if ($option === 'inactive' || !$option) {
            ?>selected="selected"<?php 
        }
        ?>><?php 
        _e('Inactive', 'dynamic-content-for-madxartwork');
        ?></option>
					</select>
				</div>
				</td>
				</tr>
			</table>

			<?php 
        submit_button('');
        ?>
		</form>
		<?php 
    }
}
