<?php

namespace DynamicContentFormadxartwork\AdminPages\Features;

use DynamicContentFormadxartwork\AdminPages\Settings;
use DynamicContentFormadxartwork\Tokens;
class TokensSettings extends Settings\SettingsPage
{
    const PAGE_ID = 'dce-settings';
    /**
     * Fix old filter whitelist bug
     *
     * @return void
     */
    public function before_register()
    {
        if (\is_array(get_option('dce_tokens_filters_whitelist'))) {
            Tokens::fix_filters_whitelist();
        }
    }
    /**
     * Get Name
     *
     * @return string
     */
    public function get_name()
    {
        return 'tokens';
    }
    /**
     * Get Label
     *
     * @return string
     */
    public function get_label()
    {
        return 'Tokens';
    }
    /**
     * Should Display Count
     *
     * @return boolean
     */
    public function should_display_count()
    {
        return \false;
    }
    /**
     * @param string $id
     * @return string
     */
    protected function tokens_filters_whitelist($id)
    {
        $value = esc_textarea(get_option('dce_' . $id, ''));
        $html = "<textarea placeholder='my_function' cols='30' rows='5' id='dce_{$id}' name='dce_{$id}'>{$value}</textarea>";
        $html .= '<p class="description">' . esc_html__('One filter per line', 'dynamic-content-for-madxartwork') . '</p>';
        return $html;
    }
    /**
     * @return void
     */
    protected function render_tokens_intro()
    {
        echo '<p>' . esc_html__('A Token is a specially formatted chunk of text that serves as a placeholder for a dynamically generated value.', 'dynamic-content-for-madxartwork') . ' ' . '<a target="_blank" href="https://dnmc.ooo/tokensdoc">' . esc_html__('More info...', 'dynamic-content-for-madxartwork') . '</a><br />';
        echo esc_html__('You can manipulate the results with filters, which are PHP and WordPress functions.', 'dynamic-content-for-madxartwork') . '</p>';
    }
    /**
     * @return array<string,mixed>
     */
    public function create_tabs()
    {
        $tabs = ['tokens' => ['label' => esc_html__('Tokens', 'dynamic-content-for-madxartwork'), 'sections' => ['tokens' => ['callback' => [$this, 'render_tokens_intro'], 'fields' => ['tokens_status' => ['label' => esc_html__('Tokens Status', 'dynamic-content-for-madxartwork'), 'field_args' => ['type' => 'select', 'std' => 'enable', 'options' => ['enable' => esc_html__('Enable', 'dynamic-content-for-madxartwork'), 'disable' => esc_html__('Disable', 'dynamic-content-for-madxartwork')]]], 'active_tokens' => ['label' => esc_html__('Active Tokens', 'dynamic-content-for-madxartwork'), 'field_args' => ['type' => 'checkbox_list', 'std' => \array_keys(Tokens::get_tokens_list()), 'options' => Tokens::get_tokens_options()]], 'tokens_filters_whitelist' => ['label' => esc_html__('Filters Whitelist', 'dynamic-content-for-madxartwork'), 'field_args' => ['type' => 'raw_html', 'html' => $this->tokens_filters_whitelist('tokens_filters_whitelist')]]]]]]];
        return $tabs;
    }
}
