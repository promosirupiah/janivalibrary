<?php

namespace DynamicContentFormadxartwork;

if (!\defined('ABSPATH')) {
    exit;
}
class Elements
{
    public static $elements = [];
    public static $elements_time = [];
    public static $elements_hidden = [];
    public static $elements_categories = [];
    public static $elements_settings = [];
    public static $madxartwork_data = [];
    public static $madxartwork_current = \false;
    public static $madxartwork_data_current = '';
    public static $user_can_copy = \false;
    public static $user_can_madxartwork = \false;
    public function __construct()
    {
        add_action('madxartwork/init', [$this, 'init']);
    }
    public function init()
    {
        if (!is_admin()) {
            // elements report
            add_action('madxartwork/frontend/widget/before_render', array($this, 'start_element'), 11, 2);
            //+exclude_start
            // Frontend Navigator
            $option = get_option(DCE_FRONTEND_NAVIGATOR_OPTION);
            if ('active' !== $option) {
                return;
            }
            self::$user_can_madxartwork = \DynamicContentFormadxartwork\Helper::user_can_madxartwork();
            if (self::$user_can_madxartwork || isset($_GET['dce-nav'])) {
                add_action('madxartwork/frontend/builder_content_data', array($this, 'start_element'), 11, 2);
                // template start
                add_action('madxartwork/frontend/the_content', array($this, 'end_element'), 11, 2);
                // template end
                add_action('madxartwork/frontend/section/before_render', array($this, 'start_element'), 11, 2);
                add_action('madxartwork/frontend/column/before_render', array($this, 'start_element'), 11, 2);
                add_action('madxartwork/frontend/section/after_render', array($this, 'end_element'), 11, 2);
                add_action('madxartwork/frontend/column/after_render', array($this, 'end_element'), 11, 2);
                add_action('madxartwork/frontend/widget/after_render', array($this, 'end_element'), 11, 2);
                add_action('wp_enqueue_scripts', function () {
                    \DynamicContentFormadxartwork\Plugin::instance()->assets->register_and_enqueue_dce_icons();
                    wp_enqueue_style('dce-admin-bar', plugins_url('/assets/css/admin-bar.css', DCE__FILE__), [], DCE_VERSION);
                });
                add_action('admin_bar_menu', array($this, 'add_frontend_navigator'), 100);
                if (isset($_GET['dce-nav'])) {
                    add_action('wp_head', function () {
                        echo '<meta name="robots" content="noindex" />';
                    });
                    add_action('wp_footer', [$this, 'print_frontend_navigator']);
                }
            }
            //+exclude_end
        }
    }
    //+exclude_start
    public static function get_main_template_id()
    {
        $templates = self::get_template_ids();
        if (isset($templates['post'])) {
            return $templates['post'];
        }
        if (isset($templates['pro'])) {
            return $templates['pro'];
        }
        if (isset($templates['dce'])) {
            return $templates['dce'];
        }
        return \false;
    }
    //+exclude_end
    public static function get_template_ids()
    {
        $templates = [];
        //+exclude_start
        // check with DCE Template System
        $template_id = \DynamicContentFormadxartwork\TemplateSystem::get_template_id(\true);
        if ($template_id) {
            $templates['dce'] = $template_id;
        }
        //+exclude_end
        // check with madxartwork PRO Theme Builder
        $pro_template_id = \DynamicContentFormadxartwork\Helper::get_theme_builder_template_id();
        if ($pro_template_id) {
            $templates['pro'] = $pro_template_id;
        }
        //+exclude_start
        $post_template_id = \DynamicContentFormadxartwork\TemplateSystem::get_post_template_id();
        if ($post_template_id) {
            $templates['post'] = $post_template_id;
        }
        //+exclude_end
        return $templates;
    }
    public function start_element($element = \false, $template_id = 0)
    {
        $id = 0;
        if (\is_object($element)) {
            $type = $element->get_type();
            $name = $element->get_name();
            $id = $element->get_id();
            self::$elements_settings[$id] = $element->get_settings();
            self::$madxartwork_current = $element;
        }
        if (self::$user_can_madxartwork || isset($_GET['dce-nav'])) {
            if (\is_string($element) || \is_array($element) || $template_id) {
                if (!$template_id) {
                    if (\is_string($element)) {
                        $template_id = \DynamicContentFormadxartwork\Helper::get_template_id_by_html($element);
                    }
                    if (!$template_id && \is_array($element)) {
                        $template_id = get_the_ID();
                        $template_id = \DynamicContentFormadxartwork\Helper::get_post_id_by_element_data($element, $template_id);
                        self::$elements_settings[$template_id] = $element;
                    }
                }
                $template = get_post($template_id);
                if ($template) {
                    $type = 'template';
                    $name = $template->post_name;
                    $id = $template->ID;
                    $template_id = $id;
                    self::$madxartwork_current = $element;
                }
            }
        }
        if ($id) {
            if (isset(self::$elements[$type][$name][$id])) {
                ++self::$elements[$type][$name][$id];
            } else {
                self::$elements[$type][$name][$id] = 1;
            }
        }
        if ($id) {
            if (!empty(self::$madxartwork_data_current)) {
                self::$madxartwork_data_current .= ' > ';
            }
            self::$madxartwork_data_current .= $type . '-' . $id;
            self::$madxartwork_data[self::$madxartwork_data_current] = $name;
            self::$elements_time[$id]['start'] = \microtime(\true);
        }
        return $element;
    }
    public function end_element($element = \false, $template_id = 0)
    {
        $id = 0;
        if (\is_object($element)) {
            $type = $element->get_type();
            $name = $element->get_name();
            $id = $element->get_id();
        }
        if (\is_string($element) || \is_array($element) || $template_id) {
            if (!$template_id && !\is_array($element)) {
                $template_id = \DynamicContentFormadxartwork\Helper::get_template_id_by_html($element);
            }
            $template = get_post($template_id);
            if ($template) {
                $type = 'template';
                $name = $template->post_name;
                $id = $template->ID;
                $template_id = $id;
            }
        }
        if ($id) {
            $elements = \explode(' > ', self::$madxartwork_data_current);
            \array_pop($elements);
            self::$madxartwork_data_current = \implode(' > ', $elements);
            self::$elements_time[$id]['end'] = \microtime(\true);
        }
        return $element;
    }
    public function get_last_template_id()
    {
        if (!empty(self::$madxartwork_data_current)) {
            $pieces = \explode(' > ', self::$madxartwork_data_current);
            $pieces = \array_reverse($pieces);
            foreach ($pieces as $key => $value) {
                list($type, $id) = \explode('-', $value);
                if ($type == 'template') {
                    return $id;
                }
            }
        }
        return \false;
    }
    //+exclude_start
    /**
     * Add Frontend Navigator
     *
     * @param \WP_Admin_Bar $admin_bar
     * @return void
     */
    public function add_frontend_navigator(\WP_Admin_Bar $admin_bar)
    {
        global $wp;
        $href = home_url(add_query_arg(['dce-nav' => ''], $wp->request));
        $admin_bar->add_menu(['id' => 'dce-frontend-navigator', 'title' => 'Frontend Navigator', 'href' => $href, 'meta' => ['title' => esc_html__('Frontend Navigator', 'dynamic-content-for-madxartwork'), 'class' => 'menupop']]);
        add_action('wp_footer', [$this, 'print_frontend_navigator_submenu']);
        wp_enqueue_script('dce-frontend-navigator-admin-bar', plugins_url('/assets/js/frontend-navigator-admin-bar.js', DCE__FILE__), [], DCE_VERSION);
    }
    public function print_frontend_navigator_submenu()
    {
        if (self::$user_can_madxartwork) {
            wp_enqueue_style('dce-style-editor-navigator');
            wp_enqueue_script('dce-script-editor-navigator');
            $this->parse_madxartwork_data();
            $template_ids = $this->get_madxartwork_submenu_ids(self::$madxartwork_data);
            if (!empty($template_ids)) {
                ?>
				<div id="wp-admin-bar-dce-madxartwork-edit-template-wrapper" class="ab-sub-wrapper" style="visibility: hidden;">
					<ul id="wp-admin-bar-dce-madxartwork-edit-template" class="ab-submenu">
				<?php 
                $this->print_madxartwork_submenu($template_ids);
                ?>
					</ul>
				</div>
				<?php 
            } else {
                ?><style>#wp-admin-bar-dce-frontend-navigator{display: none;}</style><?php 
            }
        }
    }
    public function get_madxartwork_submenu_ids($madxartwork_data, $templates = array())
    {
        if (!empty($madxartwork_data)) {
            if (\is_array($madxartwork_data)) {
                foreach ($madxartwork_data as $ekey => $evalue) {
                    list($type, $id) = \explode('-', $ekey);
                    if ($type == 'template') {
                        $templates[$id] = \intval($id);
                    }
                    $templates = $this->get_madxartwork_submenu_ids($evalue, $templates);
                }
            }
        }
        return $templates;
    }
    public function print_madxartwork_submenu($template_ids)
    {
        if (!empty($template_ids)) {
            $type = 'template';
            foreach ($template_ids as $ekey => $id) {
                $edit_link = $this->get_element_link_by_id($id, $type);
                $name = $this->get_element_name_by_id($id, $type);
                ?>
				<li id="wp-admin-bar-madxartwork-template-edit-<?php 
                echo $id;
                ?>">
					<a class="ab-item" href="<?php 
                echo $edit_link;
                ?>" target="_blank">
						<span class="madxartwork-edit-link-title"><?php 
                echo wp_kses_post(get_the_title($id));
                ?></span>
				<?php 
                $document = \madxartwork\Plugin::$instance->documents->get($id);
                if ($document) {
                    ?>
							<span class="madxartwork-edit-link-type"><?php 
                    echo $document::get_title();
                    ?></span>
				<?php 
                }
                ?>
					</a>
				</li>
						<?php 
            }
        }
    }
    public function parse_madxartwork_data()
    {
        if (self::$madxartwork_data_current != 'ooo') {
            $tmp = array();
            foreach (self::$madxartwork_data as $ekey => $edata) {
                $kpos = \explode(' > ', $ekey);
                $tmp = \DynamicContentFormadxartwork\Helper::set_array_value_by_keys($tmp, $kpos, $edata);
            }
            self::$madxartwork_data = $tmp;
            self::$madxartwork_data_current = 'ooo';
        }
        return self::$madxartwork_data;
    }
    public function print_frontend_navigator()
    {
        wp_register_style('font-awesome', madxartwork_URL . 'assets/lib/font-awesome/css/font-awesome.min.css', [], '4.7.0');
        wp_enqueue_style('font-awesome');
        wp_register_script('tipsy', madxartwork_ASSETS_URL . 'lib/tipsy/tipsy.min.js', ['jquery'], '1.0.0', \true);
        wp_enqueue_script('tipsy');
        wp_enqueue_script('dce-clipboard-js');
        wp_enqueue_style('dce-style-editor-navigator', plugins_url('/assets/css/frontend-navigator.css', DCE__FILE__), [], DCE_VERSION);
        wp_enqueue_script('dce-frontend-navigator', plugins_url('/assets/js/frontend-navigator.js', DCE__FILE__), [], DCE_VERSION);
        $this->parse_madxartwork_data();
        self::$elements_categories = \madxartwork\Plugin::$instance->elements_manager->get_categories();
        ?>
		<div id="madxartwork-navigator" style="display: none;">
			<div id="madxartwork-navigator__inner">
				<div id="madxartwork-navigator__header">
					<i id="madxartwork-navigator__toggle-all" class="eicon-expand" data-madxartwork-action="expand"></i>
					<div id="madxartwork-navigator__header__title"><i class="color-dce icon-dce-logo-dce" style="color: #e52600;"></i> <?php 
        _e('Frontend Navigator', 'dynamic-content-for-madxartwork');
        ?></div>
					<i id="madxartwork-navigator__close" class="eicon-close"></i>
				</div>
				<div id="madxartwork-navigator__elements">
					<div data-model-cid="c44" class="madxartwork-navigator__element madxartwork-navigator__element--has-children">
						<?php 
        $this->print_madxartwork_navigator(self::$madxartwork_data, 0, self::$user_can_madxartwork);
        ?>
					</div>
				</div>
			</div>
		</div>
		<?php 
    }
    public function print_madxartwork_navigator($madxartwork_data, $template_id = 0)
    {
        if (!empty($madxartwork_data)) {
            if (\is_array($madxartwork_data)) {
                echo '<ul class="madxartwork-navigator__elements">';
                foreach ($madxartwork_data as $ekey => $evalue) {
                    list($type, $id) = \explode('-', $ekey);
                    if ($type == 'template') {
                        $template_id = $id;
                    }
                    $name = $this->get_element_name_by_id($id, $type);
                    $target = '.madxartwork-element-' . $id;
                    if ($type == 'template') {
                        $target = '.madxartwork.madxartwork-' . $id;
                    }
                    $aname = $this->get_element_title_by_id($id, $type, $name, $template_id);
                    $element_icon = $this->get_element_icon_by_id($id, $type, $name);
                    $edit_link = $this->get_element_link_by_id($template_id, $type, $id);
                    if (!self::$user_can_madxartwork && isset(self::$elements_hidden[$id]) && empty(self::$elements_hidden[$id]['fallback'])) {
                        continue;
                    }
                    ?>

					<li class="madxartwork-navigator__element madxartwork-navigator__element-<?php 
                    echo $type . (\is_array($evalue) ? ' madxartwork-navigator__element--has-children' : '') . (self::$user_can_madxartwork && isset(self::$elements_hidden[$id]) && empty(self::$elements_hidden[$id]['fallback']) ? ' madxartwork-navigator__element--hidden' : '');
                    ?>">
						<div class="madxartwork-navigator__item madxartwork-active<?php 
                    echo self::$user_can_madxartwork && isset(self::$elements_hidden[$id]) ? ' madxartwork-dce-hidden' : '';
                    ?>" data-target="<?php 
                    echo $target;
                    ?>">
					<?php 
                    if (\is_array($evalue)) {
                        ?>
						<a href="#" class="madxartwork-navigator__element__list-toggle"><i class="eicon-sort-down"></i></a>
					<?php 
                    } else {
                        ?>
						<span class="madxartwork-navigator__element__list-spacer"></span>
					<?php 
                    }
                    ?>
						<span class="madxartwork-navigator__element__element-type"><i class="<?php 
                    echo $element_icon;
                    ?>"></i></span>
						<span class="madxartwork-navigator__element__title"><span class="madxartwork-navigator__element__title__text"><?php 
                    echo $aname;
                    ?></span></span>

						<div class="madxartwork-navigator__element__indicators">
						<?php 
                    if (self::$user_can_madxartwork) {
                        ?>
							<div class="madxartwork-navigator__element__indicator" data-section="section_edit" original-title="Edit">
								<a class="madxartwork-navigator__element__edit" href="<?php 
                        echo $edit_link;
                        ?>" target="_blank"><i class="eicon-pencil"></i></a>
							</div>
						<?php 
                    }
                    ?>

							<div class="madxartwork-navigator__element__indicator madxartwork-navigator__element__indicator__info" data-section="section_info" original-title="Info">
								<a class="madxartwork-navigator__element__info"><i class="eicon-info-circle"></i></a>
							</div>

							<div class="madxartwork-navigator__element__indicator" data-section="section_toggle" original-title="Toggle" <?php 
                    if (!self::$user_can_madxartwork || !isset(self::$elements_hidden[$id])) {
                        ?>style="display: none;"<?php 
                    }
                    ?>>
								<a class="madxartwork-navigator__element__toggle"><i class="fa fas fa-eye<?php 
                    if (isset(self::$elements_hidden[$id]) && empty(self::$elements_hidden[$id]['fallback'])) {
                        ?>-slash<?php 
                    }
                    ?>"></i></a>
							</div>
						</div>

					</div>

					<?php 
                    $this->print_madxartwork_navigator($evalue, $template_id);
                    ?>

						<div class="madxartwork-navigator__element__infobox">
							<div class="madxartwork-navigator__header">
								<i class="eicon-close madxartwork-navigator__close"></i>
								<div class="madxartwork-navigator__header__title"><div class="dce-title-h3"><?php 
                    echo $aname;
                    ?></div></div>
							</div>
							<div class="madxartwork-navigator__element__infobox__body">
								<i class="<?php 
                    echo $element_icon;
                    ?> madxartwork-navigator__element__icon"></i>
								<div class="dce-title-h4"><?php 
                    echo \ucfirst($type);
                    ?></div>
								<div class="dce-title-h5"><?php 
                    _e('ID', 'dynamic-content-for-madxartwork');
                    echo ': ' . $id;
                    ?></div>
								<hr>
								<div class="madxartwork-navigator__element__infobox__details">
									<div class="dce-title-h6"><?php 
                    _e('Details', 'dynamic-content-for-madxartwork');
                    ?>:</div>
									<dl>
										<dt><?php 
                    _e('Name', 'dynamic-content-for-madxartwork');
                    ?></dt> <dd><?php 
                    echo $name;
                    ?></dd>
										<?php 
                    if (!empty(self::$elements_time[$id]) && !empty(self::$elements_time[$id]['start']) && !empty(self::$elements_time[$id]['end'])) {
                        ?>
											<dt><?php 
                        _e('Time', 'dynamic-content-for-madxartwork');
                        ?></dt> <dd><?php 
                        echo self::$elements_time[$id]['end'] - self::$elements_time[$id]['start'];
                        ?></dd>
										<?php 
                    }
                    ?>
										<dt><?php 
                    _e('Element Count', 'dynamic-content-for-madxartwork');
                    ?></dt> <dd><?php 
                    echo self::$elements[$type][$name][$id];
                    ?></dd>
										<dt><?php 
                    _e('Type Count', 'dynamic-content-for-madxartwork');
                    ?></dt> <dd><?php 
                    echo \count(self::$elements[$type][$name]);
                    ?></dd>
										<?php 
                    if ($type == 'template') {
                        $document = \madxartwork\Plugin::$instance->documents->get($id);
                        if ($document) {
                            ?>
												<dt><?php 
                            _e('Type', 'dynamic-content-for-madxartwork');
                            ?></dt> <dd><?php 
                            echo $document::get_title();
                            ?></dd>
												<?php 
                            if (self::$user_can_madxartwork) {
                                ?>
													<dt><?php 
                                _e('Created on', 'dynamic-content-for-madxartwork');
                                ?></dt> <dd><?php 
                                echo $document->get_post()->post_date;
                                ?></dd>
													<dt><?php 
                                _e('Author', 'dynamic-content-for-madxartwork');
                                ?></dt> <dd><a href="<?php 
                                echo \DynamicContentFormadxartwork\Helper::get_user_link($document->get_post()->post_author);
                                ?>" target="_blank"><?php 
                                echo get_the_author_meta('display_name', $document->get_post()->post_author);
                                ?></a></dd>
													<?php 
                                if ($document->get_post()->post_date != $document->get_post()->post_modified) {
                                    ?>
														<dt><?php 
                                    _e('Modified on', 'dynamic-content-for-madxartwork');
                                    ?></dt> <dd><?php 
                                    echo $document->get_post()->post_modified;
                                    ?></dd>
													<?php 
                                }
                                ?>
														<?php 
                                $modified_author_id = get_the_modified_author($id);
                                $modified_author_id = get_post_meta(get_post()->ID, '_edit_last', \true);
                                if ($modified_author_id && $document->get_post()->post_author != $modified_author_id) {
                                    ?>
														<dt><?php 
                                    _e('Modified by', 'dynamic-content-for-madxartwork');
                                    ?></dt>  <dd><a href="<?php 
                                    echo \DynamicContentFormadxartwork\Helper::get_user_link($modified_author_id);
                                    ?>" target="_blank"><?php 
                                    echo get_the_author_meta('display_name', $modified_author_id);
                                    ?></a></dd>
													<?php 
                                }
                            }
                            ?>
												<dt><?php 
                            _e('Status', 'dynamic-content-for-madxartwork');
                            ?></dt> <dd><?php 
                            echo $document->get_post()->post_status;
                            ?></dd>
												<?php 
                        }
                    }
                    $category = 'basic';
                    if ($type == 'widget') {
                        $widget = $this->get_widget_by_id($id);
                        $categories = $widget->get_categories();
                        if (!empty($categories)) {
                            $category = '';
                            foreach ($categories as $ckey => $acat) {
                                if ($ckey) {
                                    $category .= ', ';
                                }
                                $category .= !empty(self::$elements_categories[$acat]['title']) ? self::$elements_categories[$acat]['title'] : $acat;
                            }
                        }
                        ?>
											<dt><?php 
                        _e('Category', 'dynamic-content-for-madxartwork');
                        ?></dt> <dd><?php 
                        echo $category;
                        ?></dd>
											<?php 
                    } else {
                        $categories = array($category);
                    }
                    ?>
									</dl>
								</div>
										<?php 
                    if (isset(self::$elements_hidden[$id]) && self::$user_can_madxartwork) {
                        ?>
									<div class="madxartwork-navigator__element__infobox__visibility">
										<div class="dce-title-h6"><i class="eicon-preview-medium"></i> <?php 
                        _e('Visibility', 'dynamic-content-for-madxartwork');
                        ?>:</div>
										<dt>
											<?php 
                        if (empty(self::$elements_hidden[$id])) {
                            ?>
											<dt><?php 
                            _e('Hidden', 'dynamic-content-for-madxartwork');
                            ?></dt> <dd><?php 
                            _e('Always', 'dynamic-content-for-madxartwork');
                            ?></dd>
												<?php 
                        } else {
                            $element_settings = \DynamicContentFormadxartwork\Helper::get_madxartwork_element_settings_by_id($id, $template_id);
                            foreach (self::$elements_hidden[$id]['triggers'] as $ckey => $cond) {
                                ?>
												<dt><?php 
                                echo $cond;
                                ?></dt> <dd><?php 
                                if (!empty($element_settings[$ckey])) {
                                    echo \DynamicContentFormadxartwork\Helper::to_string($element_settings[$ckey]);
                                }
                                ?></dd>
													<?php 
                            }
                        }
                        ?>
										<dt><?php 
                        _e('Fallback', 'dynamic-content-for-madxartwork');
                        ?></dt> <dd><?php 
                        echo empty(self::$elements_hidden[$id]['fallback']) ? esc_html__('No', 'dynamic-content-for-madxartwork') : esc_html__('Yes', 'dynamic-content-for-madxartwork');
                        ?></dd>
										</dt>
									</div>
									<?php 
                    }
                    ?>


								<div class="madxartwork-navigator__element__footer">
									<a class="madxartwork-button madxartwork-size-xs madxartwork-navigator__element__infobox__toggle tooltip-target" aria-hidden="true" data-tooltip="Toggle" original-title="Toggle" href="#">
										<i class="fa fas fa-eye<?php 
                    if (isset(self::$elements_hidden[$id]) && empty(self::$elements_hidden[$id]['fallback'])) {
                        ?>-slash<?php 
                    }
                    ?>"></i>
									</a>

									<?php 
                    $element_settings = \false;
                    if (self::$user_can_madxartwork) {
                        if (!empty($element_settings)) {
                            ?>
											<button class="madxartwork-button madxartwork-button-info madxartwork-size-xs madxartwork-navigator__element__infobox__copy_mini tooltip-target" aria-hidden="true" data-tooltip="Copy" original-title="Copy" data-clipboard-action="copy" data-clipboard-target="#madxartwork-navigator__element__settings_<?php 
                            echo $id;
                            ?>">
												<i class="eicon-copy"></i>
											</button>
										<?php 
                        }
                        ?>
										<a class="madxartwork-button madxartwork-button-warning madxartwork-size-xs madxartwork-navigator__element__infobox__edit" href="<?php 
                        echo $edit_link;
                        ?>" target="_blank">
											<i class="eicon-pencil"></i> <?php 
                        _e('Edit', 'dynamic-content-for-madxartwork');
                        ?>
										</a>
										<?php 
                    } elseif (!empty($element_settings)) {
                        ?>
											<button class="madxartwork-button madxartwork-button-info madxartwork-size-xs madxartwork-navigator__element__infobox__copy" data-clipboard-action="copy" data-clipboard-target="#madxartwork-navigator__element__settings_<?php 
                        echo $id;
                        ?>">
												<i class="eicon-copy"></i> <?php 
                        _e('Copy', 'dynamic-content-for-madxartwork');
                        ?>
											</button>
											<?php 
                    }
                    ?>
								</div>

							</div>
							<div class="madxartwork-align-center madxartwork-navigator__element__logo">
					<?php 
                    foreach ($categories as $acat) {
                        switch ($acat) {
                            case 'general':
                            case 'basic':
                                echo '<a href="https://madxartwork.com/" target="_blank"><i class="eicon-madxartwork-square"></i></a>';
                                break;
                            case 'pro-elements':
                                echo '<a href="https://madxartwork.com/pro/" target="_blank"><i class="eicon-madxartwork-square"></i><i class="eicon-pro-icon"></i></a>';
                                break;
                            default:
                                if (\substr($acat, 0, 29) == 'dynamic-content-for-madxartwork') {
                                    echo '<a href="https://www.dynamic.ooo/" target="_blank"><i class="color-dce icon-dce-logo-dce" style="color: #e52600;"></i></a>';
                                } elseif (!empty(self::$elements_categories[$acat]['icon'])) {
                                    echo '<i class="' . self::$elements_categories[$acat]['icon'] . '"></i>';
                                }
                        }
                    }
                    ?>
							</div>
								<?php 
                    if ($type == 'widget') {
                        ?>
								<div class="madxartwork-align-center madxartwork-navigator__element__help"><a class="madxartwork-navigator__element__help__link" href="<?php 
                        echo $widget->get_custom_help_url() ? $widget->get_custom_help_url() : $widget->get_help_url();
                        ?>" target="_blank"><?php 
                        _e('Need Help', 'dynamic-content-for-madxartwork');
                        ?> <i class="eicon-help-o"></i></a></div>
							<?php 
                    }
                    ?>
						</div>

					</li>
					<?php 
                }
                echo '</ul>';
            }
        }
    }
    public function get_element_icon_by_id($id, $type, $name)
    {
        switch ($type) {
            case 'column':
            case 'section':
                return 'eicon-' . $type;
                break;
            case 'template':
                return 'eicon-inner-section';
                break;
            case 'widget':
                if ($name) {
                    $widget = \madxartwork\Plugin::instance()->widgets_manager->get_widget_types($name);
                    if ($widget) {
                        return 'eicon-widget ' . $widget->get_icon();
                    }
                }
        }
        return 'eicon-widget eicon-square';
    }
    //+exclude_end
    public function get_widget_by_id($id)
    {
        $name = $this->get_element_name_by_id($id, 'widget');
        if ($name) {
            $widget = \madxartwork\Plugin::instance()->widgets_manager->get_widget_types($name);
            if ($widget) {
                return $widget;
            }
        }
        return \false;
    }
    public function get_element_title_by_id($id, $type, $name, $template_id = 0)
    {
        if ('template' === $type) {
            return esc_html(get_the_title($id));
        } elseif ('column' === $type) {
            return esc_html__('Column', 'dynamic-content-for-madxartwork');
        } elseif ('section' === $type) {
            $settings = \DynamicContentFormadxartwork\Helper::get_madxartwork_element_settings_by_id($id, $template_id);
            if (!empty($settings['_title'])) {
                return $settings['_title'];
            }
            return esc_html__('Section', 'dynamic-content-for-madxartwork');
        } elseif ('widget' === $type) {
            if ($name) {
                $widget = \madxartwork\Plugin::instance()->widgets_manager->get_widget_types($name);
                if ($widget) {
                    return $widget->get_title();
                }
            }
        }
        return $name;
    }
    public function get_element_name_by_id($id, $type)
    {
        if ($type == 'widget') {
            foreach (self::$elements[$type] as $name => $ename) {
                foreach ($ename as $eid => $ecount) {
                    if ($eid == $id) {
                        return $name;
                    }
                }
            }
        }
        if ($type == 'template') {
            $post = get_post($id);
            if ($post) {
                return $post->post_name;
            }
        }
        return $type;
    }
    public function get_element_link_by_id($template_id, $type, $id = \false)
    {
        $edit_link = get_edit_post_link($template_id);
        $pieces = \explode('action=', $edit_link, 2);
        $edit_link = \reset($pieces) . 'action=madxartwork';
        if ($type != 'template' && $id) {
            $edit_link .= '&element=' . $id;
        }
        return $edit_link;
    }
}
