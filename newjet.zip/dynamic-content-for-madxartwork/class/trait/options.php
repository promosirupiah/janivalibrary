<?php

namespace DynamicContentFormadxartwork;

trait Options
{
    /**
     * Get Dynamic Tags Categories
     *
     * @return array<string>
     */
    public static function get_dynamic_tags_categories()
    {
        return ['base', 'text', 'url', 'number', 'post_meta', 'date', 'datetime', 'media', 'image', 'gallery', 'color'];
    }
    /**
     * Compare options
     *
     * @return array<string,mixed>
     */
    public static function compare_options()
    {
        return ['not' => ['title' => esc_html__('Not set or empty', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-circle-o'], 'isset' => ['title' => esc_html__('Valorized with any value', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-dot-circle-o'], 'lt' => ['title' => esc_html__('Less than', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-angle-left'], 'gt' => ['title' => esc_html__('Greater than', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-angle-right'], 'contain' => ['title' => esc_html__('Contains', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-check'], 'not_contain' => ['title' => esc_html__('Doesn\'t contain', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-close'], 'in_array' => ['title' => esc_html__('In Array', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-bars'], 'value' => ['title' => esc_html__('Equal to', 'dynamic-content-for-madxartwork'), 'icon' => 'fa fa-circle'], 'not_value' => ['title' => esc_html__('Not Equal to', 'dynamic-content-for-madxartwork'), 'icon' => 'eicon-exchange']];
    }
    /**
     * Get Post Order By Options
     *
     * @return array<string,string>
     */
    public static function get_post_orderby_options()
    {
        return ['ID' => esc_html__('Post ID', 'dynamic-content-for-madxartwork'), 'author' => esc_html__('Post Author', 'dynamic-content-for-madxartwork'), 'title' => esc_html__('Title', 'dynamic-content-for-madxartwork'), 'date' => esc_html__('Date', 'dynamic-content-for-madxartwork'), 'modified' => esc_html__('Last Modified Date', 'dynamic-content-for-madxartwork'), 'parent' => esc_html__('Parent ID', 'dynamic-content-for-madxartwork'), 'rand' => esc_html__('Random', 'dynamic-content-for-madxartwork'), 'comment_count' => esc_html__('Comment Count', 'dynamic-content-for-madxartwork'), 'menu_order' => esc_html__('Menu Order', 'dynamic-content-for-madxartwork'), 'meta_value' => esc_html__('Meta Value', 'dynamic-content-for-madxartwork'), 'none' => esc_html__('None', 'dynamic-content-for-madxartwork'), 'name' => esc_html__('Name', 'dynamic-content-for-madxartwork'), 'type' => esc_html__('Type', 'dynamic-content-for-madxartwork'), 'relevance' => esc_html__('Relevance', 'dynamic-content-for-madxartwork'), 'post__in' => esc_html__('Preserve Post ID order given', 'dynamic-content-for-madxartwork')];
    }
    /**
     * Get Order By Meta Value - Types
     *
     * @return array<string,string>
     */
    public static function get_post_orderby_meta_value_types()
    {
        return ['NUMERIC' => esc_html__('Numeric', 'dynamic-content-for-madxartwork'), 'BINARY' => esc_html__('Binary', 'dynamic-content-for-madxartwork'), 'CHAR' => esc_html__('Character', 'dynamic-content-for-madxartwork'), 'DATE' => esc_html__('Date', 'dynamic-content-for-madxartwork'), 'DATETIME' => esc_html__('DateTime', 'dynamic-content-for-madxartwork'), 'DECIMAL' => esc_html__('Decimal', 'dynamic-content-for-madxartwork'), 'SIGNED' => esc_html__('Signed', 'dynamic-content-for-madxartwork'), 'TIME' => esc_html__('Time', 'dynamic-content-for-madxartwork'), 'UNSIGNED' => esc_html__('Unsigned', 'dynamic-content-for-madxartwork')];
    }
    /**
     * Get Term Order By Options
     *
     * @return array<string,string>
     */
    public static function get_term_orderby_options()
    {
        return ['parent' => esc_html__('Parent', 'dynamic-content-for-madxartwork'), 'count' => esc_html__('Count (number of associated posts)', 'dynamic-content-for-madxartwork'), 'term_order' => esc_html__('Order', 'dynamic-content-for-madxartwork'), 'name' => esc_html__('Name', 'dynamic-content-for-madxartwork'), 'slug' => esc_html__('Slug', 'dynamic-content-for-madxartwork'), 'term_group' => esc_html__('Group', 'dynamic-content-for-madxartwork'), 'term_id' => 'ID'];
    }
    /**
     * Get Public Taxonomies
     *
     * @return array<string,string>
     */
    public static function get_public_taxonomies()
    {
        $taxonomies = get_taxonomies(['public' => \true]);
        $taxonomy_array = [];
        foreach ($taxonomies as $taxonomy) {
            $taxonomy_object = get_taxonomy($taxonomy);
            $taxonomy_array[$taxonomy] = sanitize_text_field($taxonomy_object->labels->name);
        }
        return $taxonomy_array;
    }
    public static function get_anim_timing_functions()
    {
        $tf_p = ['linear' => esc_html__('Linear', 'dynamic-content-for-madxartwork'), 'ease' => esc_html__('Ease', 'dynamic-content-for-madxartwork'), 'ease-in' => esc_html__('Ease In', 'dynamic-content-for-madxartwork'), 'ease-out' => esc_html__('Ease Out', 'dynamic-content-for-madxartwork'), 'ease-in-out' => esc_html__('Ease In Out', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.755, 0.05, 0.855, 0.06)' => esc_html__('easeInQuint', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.23, 1, 0.32, 1)' => esc_html__('easeOutQuint', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.86, 0, 0.07, 1)' => esc_html__('easeInOutQuint', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.6, 0.04, 0.98, 0.335)' => esc_html__('easeInCirc', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.075, 0.82, 0.165, 1)' => esc_html__('easeOutCirc', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.785, 0.135, 0.15, 0.86)' => esc_html__('easeInOutCirc', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.95, 0.05, 0.795, 0.035)' => esc_html__('easeInExpo', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.19, 1, 0.22, 1)' => esc_html__('easeOutExpo', 'dynamic-content-for-madxartwork'), 'cubic-bezier(1, 0, 0, 1)' => esc_html__('easeInOutExpo', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.6, -0.28, 0.735, 0.045)' => esc_html__('easeInBack', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.175, 0.885, 0.32, 1.275)' => esc_html__('easeOutBack', 'dynamic-content-for-madxartwork'), 'cubic-bezier(0.68, -0.55, 0.265, 1.55)' => esc_html__('easeInOutBack', 'dynamic-content-for-madxartwork')];
        return $tf_p;
    }
    public static function number_format_currency()
    {
        $nf_c = ['en-US' => esc_html__('English (US)', 'dynamic-content-for-madxartwork'), 'af-ZA' => esc_html__('Afrikaans', 'dynamic-content-for-madxartwork'), 'sq-AL' => esc_html__('Albanian', 'dynamic-content-for-madxartwork'), 'ar-AR' => esc_html__('Arabic', 'dynamic-content-for-madxartwork'), 'hy-AM' => esc_html__('Armenian', 'dynamic-content-for-madxartwork'), 'ay-BO' => esc_html__('Aymara', 'dynamic-content-for-madxartwork'), 'az-AZ' => esc_html__('Azeri', 'dynamic-content-for-madxartwork'), 'eu-ES' => esc_html__('Basque', 'dynamic-content-for-madxartwork'), 'be-BY' => esc_html__('Belarusian', 'dynamic-content-for-madxartwork'), 'bn-IN' => esc_html__('Bengali', 'dynamic-content-for-madxartwork'), 'bs-BA' => esc_html__('Bosnian', 'dynamic-content-for-madxartwork'), 'en-GB' => esc_html__('British English', 'dynamic-content-for-madxartwork'), 'bg-BG' => esc_html__('Bulgarian', 'dynamic-content-for-madxartwork'), 'ca-ES' => esc_html__('Catalan', 'dynamic-content-for-madxartwork'), 'ck-US' => esc_html__('Cherokee', 'dynamic-content-for-madxartwork'), 'hr-HR' => esc_html__('Croatian', 'dynamic-content-for-madxartwork'), 'cs-CZ' => esc_html__('Czech', 'dynamic-content-for-madxartwork'), 'da-DK' => esc_html__('Danish', 'dynamic-content-for-madxartwork'), 'nl-NL' => esc_html__('Dutch', 'dynamic-content-for-madxartwork'), 'nl-BE' => esc_html__('Dutch (Belgi?)', 'dynamic-content-for-madxartwork'), 'en-UD' => esc_html__('English (Upside Down)', 'dynamic-content-for-madxartwork'), 'eo-EO' => esc_html__('Esperanto', 'dynamic-content-for-madxartwork'), 'et-EE' => esc_html__('Estonian', 'dynamic-content-for-madxartwork'), 'fo-FO' => esc_html__('Faroese', 'dynamic-content-for-madxartwork'), 'tl-PH' => esc_html__('Filipino', 'dynamic-content-for-madxartwork'), 'fi-FI' => esc_html__('Finland', 'dynamic-content-for-madxartwork'), 'fb-FI' => esc_html__('Finnish', 'dynamic-content-for-madxartwork'), 'fr-CA' => esc_html__('French (Canada)', 'dynamic-content-for-madxartwork'), 'fr-FR' => esc_html__('French (France)', 'dynamic-content-for-madxartwork'), 'gl-ES' => esc_html__('Galician', 'dynamic-content-for-madxartwork'), 'ka-GE' => esc_html__('Georgian', 'dynamic-content-for-madxartwork'), 'de-DE' => esc_html__('German', 'dynamic-content-for-madxartwork'), 'el-GR' => esc_html__('Greek', 'dynamic-content-for-madxartwork'), 'gn-PY' => esc_html__('Guaran?', 'dynamic-content-for-madxartwork'), 'gu-IN' => esc_html__('Gujarati', 'dynamic-content-for-madxartwork'), 'he-IL' => esc_html__('Hebrew', 'dynamic-content-for-madxartwork'), 'hi-IN' => esc_html__('Hindi', 'dynamic-content-for-madxartwork'), 'hu-HU' => esc_html__('Hungarian', 'dynamic-content-for-madxartwork'), 'is-IS' => esc_html__('Icelandic', 'dynamic-content-for-madxartwork'), 'id-ID' => esc_html__('Indonesian', 'dynamic-content-for-madxartwork'), 'ga-IE' => esc_html__('Irish', 'dynamic-content-for-madxartwork'), 'it-IT' => esc_html__('Italian', 'dynamic-content-for-madxartwork'), 'ja-JP' => esc_html__('Japanese', 'dynamic-content-for-madxartwork'), 'jv-ID' => esc_html__('Javanese', 'dynamic-content-for-madxartwork'), 'kn-IN' => esc_html__('Kannada', 'dynamic-content-for-madxartwork'), 'kk-KZ' => esc_html__('Kazakh', 'dynamic-content-for-madxartwork'), 'km-KH' => esc_html__('Khmer', 'dynamic-content-for-madxartwork'), 'tl-ST' => esc_html__('Klingon', 'dynamic-content-for-madxartwork'), 'ko-KR' => esc_html__('Korean', 'dynamic-content-for-madxartwork'), 'ku-TR' => esc_html__('Kurdish', 'dynamic-content-for-madxartwork'), 'la-VA' => esc_html__('Latin', 'dynamic-content-for-madxartwork'), 'lv-LV' => esc_html__('Latvian', 'dynamic-content-for-madxartwork'), 'fb-LT' => esc_html__('Leet Speak', 'dynamic-content-for-madxartwork'), 'li-NL' => esc_html__('Limburgish', 'dynamic-content-for-madxartwork'), 'lt-LT' => esc_html__('Lithuanian', 'dynamic-content-for-madxartwork'), 'mk-MK' => esc_html__('Macedonian', 'dynamic-content-for-madxartwork'), 'mg-MG' => esc_html__('Malagasy', 'dynamic-content-for-madxartwork'), 'ms-MY' => esc_html__('Malay', 'dynamic-content-for-madxartwork'), 'ml-IN' => esc_html__('Malayalam', 'dynamic-content-for-madxartwork'), 'mt-MT' => esc_html__('Maltese', 'dynamic-content-for-madxartwork'), 'mr-IN' => esc_html__('Marathi', 'dynamic-content-for-madxartwork'), 'mn-MN' => esc_html__('Mongolian', 'dynamic-content-for-madxartwork'), 'ne-NP' => esc_html__('Nepali', 'dynamic-content-for-madxartwork'), 'se-NO' => esc_html__('Northern S?mi', 'dynamic-content-for-madxartwork'), 'nb-NO' => esc_html__('Norwegian (bokmal)', 'dynamic-content-for-madxartwork'), 'nn-NO' => esc_html__('Norwegian (nynorsk)', 'dynamic-content-for-madxartwork'), 'ps-AF' => esc_html__('Pashto', 'dynamic-content-for-madxartwork'), 'fa-IR' => esc_html__('Persian', 'dynamic-content-for-madxartwork'), 'pl-PL' => esc_html__('Polish', 'dynamic-content-for-madxartwork'), 'pt-BR' => esc_html__('Portuguese (Brazil)', 'dynamic-content-for-madxartwork'), 'pt-PT' => esc_html__('Portuguese (Portugal)', 'dynamic-content-for-madxartwork'), 'pa-IN' => esc_html__('Punjabi', 'dynamic-content-for-madxartwork'), 'qu-PE' => esc_html__('Quechua', 'dynamic-content-for-madxartwork'), 'ro-RO' => esc_html__('Romanian', 'dynamic-content-for-madxartwork'), 'rm-CH' => esc_html__('Romansh', 'dynamic-content-for-madxartwork'), 'ru-RU' => esc_html__('Russian', 'dynamic-content-for-madxartwork'), 'sa-IN' => esc_html__('Sanskrit', 'dynamic-content-for-madxartwork'), 'sr-RS' => esc_html__('Serbian', 'dynamic-content-for-madxartwork'), 'zh-CN' => esc_html__('Simplified Chinese (China)', 'dynamic-content-for-madxartwork'), 'sk-SK' => esc_html__('Slovak', 'dynamic-content-for-madxartwork'), 'sl-SI' => esc_html__('Slovenian', 'dynamic-content-for-madxartwork'), 'so-SO' => esc_html__('Somali', 'dynamic-content-for-madxartwork'), 'es-LA' => esc_html__('Spanish', 'dynamic-content-for-madxartwork'), 'es-CL' => esc_html__('Spanish (Chile)', 'dynamic-content-for-madxartwork'), 'es-CO' => esc_html__('Spanish (Colombia)', 'dynamic-content-for-madxartwork'), 'es-MX' => esc_html__('Spanish (Mexico)', 'dynamic-content-for-madxartwork'), 'es-ES' => esc_html__('Spanish (Spain)', 'dynamic-content-for-madxartwork'), 'es-VE' => esc_html__('Spanish (Venezuela)', 'dynamic-content-for-madxartwork'), 'sw-KE' => esc_html__('Swahili', 'dynamic-content-for-madxartwork'), 'sv-SE' => esc_html__('Swedish', 'dynamic-content-for-madxartwork'), 'sy-SY' => esc_html__('Syriac', 'dynamic-content-for-madxartwork'), 'tg-TJ' => esc_html__('Tajik', 'dynamic-content-for-madxartwork'), 'ta-IN' => esc_html__('Tamil', 'dynamic-content-for-madxartwork'), 'tt-RU' => esc_html__('Tatar', 'dynamic-content-for-madxartwork'), 'te-IN' => esc_html__('Telugu', 'dynamic-content-for-madxartwork'), 'th-TH' => esc_html__('Thai', 'dynamic-content-for-madxartwork'), 'zh-HK' => esc_html__('Traditional Chinese (Hong Kong)', 'dynamic-content-for-madxartwork'), 'zh-TW' => esc_html__('Traditional Chinese (Taiwan)', 'dynamic-content-for-madxartwork'), 'tr-TR' => esc_html__('Turkish', 'dynamic-content-for-madxartwork'), 'uk-UA' => esc_html__('Ukrainian', 'dynamic-content-for-madxartwork'), 'ur-PK' => esc_html__('Urdu', 'dynamic-content-for-madxartwork'), 'uz-UZ' => esc_html__('Uzbek', 'dynamic-content-for-madxartwork'), 'vi-VN' => esc_html__('Vietnamese', 'dynamic-content-for-madxartwork'), 'cy-GB' => esc_html__('Welsh', 'dynamic-content-for-madxartwork'), 'xh-ZA' => esc_html__('Xhosa', 'dynamic-content-for-madxartwork'), 'yi-DE' => esc_html__('Yiddish', 'dynamic-content-for-madxartwork'), 'zu-ZA' => esc_html__('Zulu', 'dynamic-content-for-madxartwork')];
        return $nf_c;
    }
    public static function get_gsap_ease()
    {
        $tf_p = ['easeNone' => esc_html__('None', 'dynamic-content-for-madxartwork'), 'easeIn' => esc_html__('In', 'dynamic-content-for-madxartwork'), 'easeOut' => esc_html__('Out', 'dynamic-content-for-madxartwork'), 'easeInOut' => esc_html__('InOut', 'dynamic-content-for-madxartwork')];
        return $tf_p;
    }
    public static function get_gsap_timing_functions()
    {
        $tf_p = ['Power0' => esc_html__('Linear', 'dynamic-content-for-madxartwork'), 'Power1' => esc_html__('Power1', 'dynamic-content-for-madxartwork'), 'Power2' => esc_html__('Power2', 'dynamic-content-for-madxartwork'), 'Power3' => esc_html__('Power3', 'dynamic-content-for-madxartwork'), 'Power4' => esc_html__('Power4', 'dynamic-content-for-madxartwork'), 'SlowMo' => esc_html__('SlowMo', 'dynamic-content-for-madxartwork'), 'Back' => esc_html__('Back', 'dynamic-content-for-madxartwork'), 'Elastic' => esc_html__('Elastic', 'dynamic-content-for-madxartwork'), 'Bounce' => esc_html__('Bounce', 'dynamic-content-for-madxartwork'), 'Circ' => esc_html__('Circ', 'dynamic-content-for-madxartwork'), 'Expo' => esc_html__('Expo', 'dynamic-content-for-madxartwork'), 'Sine' => esc_html__('Sine', 'dynamic-content-for-madxartwork')];
        return $tf_p;
    }
    public static function get_anim_in()
    {
        $anim = [['label' => 'Fading', 'options' => ['fadeIn' => 'Fade In', 'fadeInDown' => 'Fade In Down', 'fadeInLeft' => 'Fade In Left', 'fadeInRight' => 'Fade In Right', 'fadeInUp' => 'Fade In Up']], ['label' => 'Zooming', 'options' => ['zoomIn' => 'Zoom In', 'zoomInDown' => 'Zoom In Down', 'zoomInLeft' => 'Zoom In Left', 'zoomInRight' => 'Zoom In Right', 'zoomInUp' => 'Zoom In Up']], ['label' => 'Bouncing', 'options' => ['bounceIn' => 'Bounce In', 'bounceInDown' => 'Bounce In Down', 'bounceInLeft' => 'Bounce In Left', 'bounceInRight' => 'Bounce In Right', 'bounceInUp' => 'Bounce In Up']], ['label' => 'Sliding', 'options' => ['slideInDown' => 'Slide In Down', 'slideInLeft' => 'Slide In Left', 'slideInRight' => 'Slide In Right', 'slideInUp' => 'Slide In Up']], ['label' => 'Rotating', 'options' => ['rotateIn' => 'Rotate In', 'rotateInDownLeft' => 'Rotate In Down Left', 'rotateInDownRight' => 'Rotate In Down Right', 'rotateInUpLeft' => 'Rotate In Up Left', 'rotateInUpRight' => 'Rotate In Up Right']], ['label' => 'Attention Seekers', 'options' => ['bounce' => 'Bounce', 'flash' => 'Flash', 'pulse' => 'Pulse', 'rubberBand' => 'Rubber Band', 'shake' => 'Shake', 'headShake' => 'Head Shake', 'swing' => 'Swing', 'tada' => 'Tada', 'wobble' => 'Wobble', 'jello' => 'Jello']], ['label' => 'Light Speed', 'options' => ['lightSpeedIn' => 'Light Speed In']], ['label' => 'Specials', 'options' => ['rollIn' => 'Roll In']]];
        return $anim;
    }
    public static function get_anim_out()
    {
        $anim = [['label' => 'Fading', 'options' => ['fadeOut' => 'Fade Out', 'fadeOutDown' => 'Fade Out Down', 'fadeOutLeft' => 'Fade Out Left', 'fadeOutRight' => 'Fade Out Right', 'fadeOutUp' => 'Fade Out Up']], ['label' => 'Zooming', 'options' => ['zoomOut' => 'Zoom Out', 'zoomOutDown' => 'Zoom Out Down', 'zoomOutLeft' => 'Zoom Out Left', 'zoomOutRight' => 'Zoom Out Right', 'zoomOutUp' => 'Zoom Out Up']], ['label' => 'Bouncing', 'options' => ['bounceOut' => 'Bounce Out', 'bounceOutDown' => 'Bounce Out Down', 'bounceOutLeft' => 'Bounce Out Left', 'bounceOutRight' => 'Bounce Out Right', 'bounceOutUp' => 'Bounce Out Up']], ['label' => 'Sliding', 'options' => ['slideOutDown' => 'Slide Out Down', 'slideOutLeft' => 'Slide Out Left', 'slideOutRight' => 'Slide Out Right', 'slideOutUp' => 'Slide Out Up']], ['label' => 'Rotating', 'options' => ['rotateOut' => 'Rotate Out', 'rotateOutDownLeft' => 'Rotate Out Down Left', 'rotateOutDownRight' => 'Rotate Out Down Right', 'rotateOutUpLeft' => 'Rotate Out Up Left', 'rotateOutUpRight' => 'Rotate Out Up Right']], ['label' => 'Attention Seekers', 'options' => ['bounce' => 'Bounce', 'flash' => 'Flash', 'pulse' => 'Pulse', 'rubberBand' => 'Rubber Band', 'shake' => 'Shake', 'headShake' => 'Head Shake', 'swing' => 'Swing', 'tada' => 'Tada', 'wobble' => 'Wobble', 'jello' => 'Jello']], ['label' => 'Light Speed', 'options' => ['lightSpeedOut' => 'Light Speed Out']], ['label' => 'Specials', 'options' => ['rollOut' => 'Roll Out']]];
        return $anim;
    }
    public static function get_anim_open()
    {
        $anim_p = ['noneIn' => _x('None', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromFade' => _x('Fade', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromLeft' => _x('Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromRight' => _x('Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromTop' => _x('Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFromBottom' => _x('Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFormScaleBack' => _x('Zoom Back', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'enterFormScaleFront' => _x('Zoom Front', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInLeft' => _x('Flip Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInRight' => _x('Flip Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInTop' => _x('Flip Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipInBottom' => _x('Flip Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork')];
        return $anim_p;
    }
    public static function get_anim_close()
    {
        $anim_p = ['noneOut' => _x('None', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToFade' => _x('Fade', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToLeft' => _x('Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToRight' => _x('Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToTop' => _x('Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToBottom' => _x('Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToScaleBack' => _x('Zoom Back', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'exitToScaleFront' => _x('Zoom Front', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutLeft' => _x('Flip Left', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutRight' => _x('Flip Right', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutTop' => _x('Flip Top', 'Ajax Page', 'dynamic-content-for-madxartwork'), 'flipOutBottom' => _x('Flip Bottom', 'Ajax Page', 'dynamic-content-for-madxartwork')];
        return $anim_p;
    }
    public static function bootstrap_button_sizes()
    {
        return ['xs' => esc_html__('Extra Small', 'dynamic-content-for-madxartwork'), 'sm' => esc_html__('Small', 'dynamic-content-for-madxartwork'), 'md' => esc_html__('Medium', 'dynamic-content-for-madxartwork'), 'lg' => esc_html__('Large', 'dynamic-content-for-madxartwork'), 'xl' => esc_html__('Extra Large', 'dynamic-content-for-madxartwork')];
    }
    public static function get_sql_operators()
    {
        $compare = self::get_wp_meta_compare();
        $compare['IS NULL'] = 'IS NULL';
        $compare['IS NOT NULL'] = 'IS NOT NULL';
        return $compare;
    }
    public static function get_wp_meta_compare()
    {
        return ['=' => '=', '>' => '&gt;', '>=' => '&gt;=', '<' => '&lt;', '<=' => '&lt;=', '!=' => '!=', 'LIKE' => 'LIKE', 'RLIKE' => 'RLIKE', 'NOT LIKE' => 'NOT LIKE', 'IN' => 'IN (...)', 'NOT IN' => 'NOT IN (...)', 'BETWEEN' => 'BETWEEN', 'NOT BETWEEN' => 'NOT BETWEEN', 'EXISTS' => 'EXISTS', 'NOT EXISTS' => 'NOT EXISTS', 'REGEXP' => 'REGEXP', 'NOT REGEXP' => 'NOT REGEXP'];
    }
    public static function get_gravatar_styles()
    {
        $gravatar_images = array('404' => esc_html__('404 (empty with fallback)', 'dynamic-content-for-madxartwork'), 'retro' => esc_html__('8bit', 'dynamic-content-for-madxartwork'), 'monsterid' => esc_html__('Monster (Default)', 'dynamic-content-for-madxartwork'), 'wavatar' => esc_html__('Cartoon face', 'dynamic-content-for-madxartwork'), 'indenticon' => esc_html__('The Quilt', 'dynamic-content-for-madxartwork'), 'mp' => esc_html__('Mystery', 'dynamic-content-for-madxartwork'), 'mm' => esc_html__('Mystery Man', 'dynamic-content-for-madxartwork'), 'robohash' => esc_html__('RoboHash', 'dynamic-content-for-madxartwork'), 'blank' => esc_html__('Transparent GIF', 'dynamic-content-for-madxartwork'), 'gravatar_default' => esc_html__('The Gravatar logo', 'dynamic-content-for-madxartwork'));
        return $gravatar_images;
    }
    public static function get_post_formats()
    {
        return ['standard' => esc_html__('Standard', 'dynamic-content-for-madxartwork'), 'aside' => esc_html__('Aside', 'dynamic-content-for-madxartwork'), 'chat' => esc_html__('Chat', 'dynamic-content-for-madxartwork'), 'gallery' => esc_html__('Gallery', 'dynamic-content-for-madxartwork'), 'link' => esc_html__('Link', 'dynamic-content-for-madxartwork'), 'image' => esc_html__('Image', 'dynamic-content-for-madxartwork'), 'quote' => esc_html__('Quote', 'dynamic-content-for-madxartwork'), 'status' => esc_html__('Status', 'dynamic-content-for-madxartwork'), 'video' => esc_html__('Video', 'dynamic-content-for-madxartwork'), 'audio' => esc_html__('Audio', 'dynamic-content-for-madxartwork')];
    }
    public static function get_button_sizes()
    {
        return ['xs' => esc_html__('Extra Small', 'dynamic-content-for-madxartwork'), 'sm' => esc_html__('Small', 'dynamic-content-for-madxartwork'), 'md' => esc_html__('Medium', 'dynamic-content-for-madxartwork'), 'lg' => esc_html__('Large', 'dynamic-content-for-madxartwork'), 'xl' => esc_html__('Extra Large', 'dynamic-content-for-madxartwork')];
    }
    public static function get_jquery_display_mode()
    {
        return ['' => esc_html__('None', 'dynamic-content-for-madxartwork'), 'slide' => esc_html__('Slide', 'dynamic-content-for-madxartwork'), 'fade' => esc_html__('Fade', 'dynamic-content-for-madxartwork')];
    }
    public static function get_string_comparison()
    {
        return ['empty' => esc_html__('empty', 'dynamic-content-for-madxartwork'), 'not_empty' => esc_html__('not empty', 'dynamic-content-for-madxartwork'), 'equal_to' => esc_html__('equals to', 'dynamic-content-for-madxartwork'), 'not_equal' => esc_html__('not equals', 'dynamic-content-for-madxartwork'), 'gt' => esc_html__('greater than', 'dynamic-content-for-madxartwork'), 'ge' => esc_html__('greater than or equal', 'dynamic-content-for-madxartwork'), 'lt' => esc_html__('less than', 'dynamic-content-for-madxartwork'), 'le' => esc_html__('less than or equal', 'dynamic-content-for-madxartwork'), 'contain' => esc_html__('contains', 'dynamic-content-for-madxartwork'), 'not_contain' => esc_html__('not contains', 'dynamic-content-for-madxartwork'), 'is_checked' => esc_html__('is checked', 'dynamic-content-for-madxartwork'), 'not_checked' => esc_html__('not checked', 'dynamic-content-for-madxartwork')];
    }
    /**
     * Get HTML Tags
     *
     * @param array<string> $tags_to_add
     * @param bool $add_none
     * @return array<string,string>
     */
    public static function get_html_tags(array $tags_to_add = [], bool $add_none = \false)
    {
        $default = ['h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'h6' => 'H6', 'div' => 'div', 'span' => 'span', 'p' => 'p'];
        if ($add_none) {
            $none = ['' => esc_html__('None', 'dynamic-content-for-madxartwork')];
            $default = \array_merge($none, $default);
        }
        $tags_to_add = \array_combine($tags_to_add, $tags_to_add);
        return \array_merge($default, $tags_to_add);
    }
}
