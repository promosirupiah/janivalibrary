<?php

namespace DynamicContentFormadxartwork;

trait Notices
{
    /**
     * Notice
     *
     * @param string|false $title
     * @param string $content
     * @param string $class
     * @param string $id
     * @return void
     */
    public static function notice($title, $content, $class = 'madxartwork-alert-info', $id = '')
    {
        ?>
	<div <?php 
        echo $id ? "id='{$id}'" : '';
        ?>  class="madxartwork-alert <?php 
        echo $class;
        ?> " role="alert">
		<?php 
        if ($title) {
            ?>
			<span class="madxartwork-alert-title"><?php 
            echo wp_kses_post($title);
            ?></span>
		<?php 
        }
        if ($content) {
            ?>
			<span class="madxartwork-alert-description"><?php 
            echo wp_kses_post($content);
            ?></span>
		<?php 
        }
        ?>
	</div>
	<?php 
    }
}
