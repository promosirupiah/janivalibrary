<?php

define('_MAILING', 1); 
$notables = false;
$nocode = false;
session_start();

include("configuration.php"); // admin config, user config in db
include("php/class.emailer.php");

/*the very first install, admin should have also all tables*/
define('PREF', Settings::$tbPrefix);

$app = new Emailer();
$app->loadLanguage();
if ($app->login) {
    $app->login(); 
}

if (isset($_GET['e'])) {
    $db_error ='
    <div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <b>WARNING!</b> '.$_SESSION['e'].'
    </div>
    ';
} else {
    $db_error = '';
}

if (isset($_POST['adding-tables'])) {
    
    $app->checkToken();
    include("php/db_connector.php");
    include("install-user-tables.php");
    

    ?><script> location.href = 'index.php'; </script><?php
}

if (isset($_POST['adata'])) {
    
    $app->checkToken();
    
    $db_host = $_POST['db_host'];
    $db_user = $_POST['db_user'];
    $db_pass = $_POST['db_pass'];
    $db_name = $_POST['db_name'];
    $tb_pref = $_POST['tb_pref'];
    $ecode = $_POST['ecode'];
    $ecode2 = $_POST['ecode2'];
    if (!preg_match("/^([a-f0-9]{8})-(([a-f0-9]{4})-){3}([a-f0-9]{12})$/i", $ecode)) {
        ?><script> location.href = 'install.php?checkcode'; </script><?php
        die();
    }
    if (!$app->checkCode($ecode)) {
        ?><script> location.href = 'install.php?checkcode'; </script><?php
        die();
    }
    if ($ecode == $ecode2) {
        ?><script> location.href = 'install.php?checkcode'; </script><?php
        die();
    }
    $app->changeSetting('licenseDetails', '');
    $app->changeSetting('dbHost', $db_host);
    $app->changeSetting('dbUser', $db_user);
    $app->changeSetting('dbPassword', $db_pass);
    $app->changeSetting('dbName', $db_name);
    $app->changeSetting('tbPrefix', $tb_pref);
    $app->changeSetting('ecode', $ecode);
    ?><script> location.href = 'install.php?checkdb'; </script><?php
}

if (isset($_GET['checkdb'])) {
    include("php/db_connector.php");
    $stmt = $db->query(" show tables like '".PREF."_user' ");
    $stmt->execute();
    $row = $stmt->fetchAll();
    if (count($row) == 0) {
        $notables = true;
    }else{
        ?><script> location.href = 'index.php'; </script><?php
    }
}

if (isset($_GET['checkcode'])) {
    $nocode = true;
}


$fileSettings = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).DIRECTORY_SEPARATOR.'configuration.php';

if (is_writable($fileSettings)) {
    $fileSettingsWittable = true;
} else {
    $fileSettingsWittable = false;
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo INSTALLING_SYSTEM;?></title>
        <link href="production/css/bootstrap.min.css" rel="stylesheet">
        <style>
        body{width:900px; margin:auto;}
        </style>
    </head>
    <body>
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo INSTALLING_SYSTEM;?></h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                    <form class="form-horizontal" method="post" action="install.php">
                        <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                        <?php
                        if (!$fileSettingsWittable) {
                        ?>
                            <div class="alert alert-danger" role="alert">
                                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                <span class="sr-only"><?php echo ERROR;?></span>
                                <b><?php echo WARNING;?></b> <?php echo PLIK;?> '<b>configuration.php</b>' <?php echo NOT_WR;?>
                            </div>
                        <?php
                        }
                        ?>
                        <input type="hidden" name="adata" value="1">
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="code"><?php echo EPC;?></label>
                            <div class="col-sm-7">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="ecode" 
                                    name="ecode" 
                                    placeholder="" 
                                    value="<?php echo Settings::$ecode; ?>" 
                                    required
                                >
                            </div>
                        </div>
                    <?php
                    if ($nocode) {
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                        <span class="sr-only"><?php echo ERROR;?></span>
                        <b><?php echo WARNING;?></b> <?php echo EVALIDEPC;?>
                    </div>
                    <?php
                    }
                    ?>
                    <?php
                    if (Settings::$licenseDetails != '') {
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                        <span class="sr-only"><?php echo ERROR;?></span>
                        <b><?php echo WARNING;?></b> <?php echo Settings::$licenseDetails;?>
                    </div>
                    <input type="hidden" name="ecode2" value="<?php echo Settings::$ecode; ?>">
                    <?php
                    } else {
                    ?>
                    <input type="hidden" name="ecode2" value="">
                    <?php
                    } ?>
                    <div class="x_title">
                        <h3><?php echo SETTINGS_DB_PARAMS;?></h3>
                        <div class="clearfix"></div>
                    </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="db_host"><?php echo SETTINGS_DB_HOST;?></label>
                            <div class="col-sm-7">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="db_host" 
                                    name="db_host" 
                                    placeholder="<?php echo SETTINGS_DB_HOST_PLACEHOLDER;?>" 
                                    value="<?php echo Settings::$dbHost; ?>" 
                                    required
                                >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="db_user"><?php echo SETTINGS_DB_USER;?></label>
                            <div class="col-sm-7">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="db_user" 
                                    name="db_user" 
                                    placeholder="<?php echo SETTINGS_DB_USER_PLACEHOLDER;?>" 
                                    value="<?php echo Settings::$dbUser; ?>"
                                    required
                                >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="db_pass"><?php echo SETTINGS_DB_PASSWORD;?></label>
                            <div class="col-sm-7">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="db_pass" 
                                    name="db_pass"
                                    value="<?php echo Settings::$dbPassword; ?>"
                                >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="db_name"><?php echo SETTINGS_DB_NAME;?></label>
                            <div class="col-sm-7">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="db_name" 
                                    name="db_name" 
                                    placeholder="<?php echo SETTINGS_DB_NAME_PLACEHOLDER;?>" 
                                    value="<?php echo Settings::$dbName; ?>"
                                    required
                                >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="tb_pref"><?php echo SETTINGS_TB_PREFIX;?></label>
                            <div class="col-sm-7">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="tb_pref" 
                                    name="tb_pref" 
                                    placeholder="<?php echo SETTINGS_TB_PREFIX_PLACEHOLDER;?>" 
                                    value="<?php echo PREF; ?>"
                                    required
                                >
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-3">
                                <button type="submit" class="btn btn-<?php echo $notables ? 'default' : 'primary'; ?>"><?php echo SAVE; ?></button>
                            </div>
                        </div>
                        <?php echo $db_error;?>
                    </form>
                    <?php
                    if ($notables) {
                    ?>
                        <form class="form-horizontal" method="post" action="install.php">
                            <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                            <input type="hidden" name="adding-tables" value="1">
                            <h3><?php echo INSTALLING_CONNECTED;?></h3>
                            <div class="form-group">
                                <label class="col-sm-2 control-label"><?php echo INSTALLING_ADD_TABLES;?></label>
                                <div class="col-sm-2">
                                    <button type="submit" class="btn btn-primary"><?php echo INSTALLING_ADD_TABLES_DESC;?></button>
                                </div>
                            </div>
                        </form>
                    <?php
                    }
                    ?>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>