
ALTER TABLE PREFIX_smtp` 
ADD `senderforce` INT(1) NOT NULL DEFAULT '0' AFTER `dkim_identity`, 
ADD `sendermail` VARCHAR(1024) NOT NULL AFTER `senderforce`, 
ADD `senderdescription` VARCHAR(1024) NOT NULL AFTER `sendermail`; 
