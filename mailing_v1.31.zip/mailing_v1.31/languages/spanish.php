<?php
	/*login page*/
	define("LANG","es");
	define("LOGIN_TITLE","Sistema de correo");
	define("LOGIN_SIGN_IN","Por Favor regístrese");
	define("LOGIN","Iniciar sesión");
	define("LOGIN_PASS","Contraseña");
	define("LOGIN_SIGN_IN_BUTTON","Registrarse");
	define("LOGIN_FAILED","Nombre de usuario y/o contraseña incorrectos!");
	define("INSTALLING_SYSTEM","Configuración del sistema");
	define("INSTALLING_CONNECTED","correctamente conectado a la base de datos");
	define("INSTALLING_ADD_TABLES","Añadir tablas");
	define("INSTALLING_ADD_TABLES_DESC","Haga clic aquí para agregar tablas y comenzar a trabajar con el sistema");
	
	/*left menu*/
	define("WELCOME","Bienvenido,");
	define("WELCOME_ASK","¿Qué hacemos?");
	define("MAIN_MENU","Menú principal");
	define("START","Comienzo");
	define("DASHBOARD","Tablero");
	define("EMAIL_ADRESSES","Correos electrónicos");
	define("MENU_RECIPIENT_LIST","Lista de destinatarios");
	define("MENU_ADD_RECIPIENT","Agregar destinatario");
	define("MENU_CSV_IMPORT","Importar correos electrónicos desde un archivo CSV");
	define("MENU_CSV_EXPORT","Exportar correos electrónicos a archivos CSV");
	define("MENU_TAG_LIST","Lista de etiquetas");
	define("MENU_ADD_TAGS","Agregar etiquetas");
	define("MENU_SENDERS_LIST","Lista de remitentes");
	define("MENU_ADD_SENDER","Agregar remitente");
	define("MENU_TEMPLATES","Plantillas de correo electrónico");
	define("MENU_TEMPLATES_LIST","Lista de plantillas");
	define("MENU_TEMPLATES_ADD","Añadir nueva plantilla");
	define("MENU_TEMPLATES_ATTACHMENTS","Archivos adjuntos");
    define("MENU_TEMPLATES_THUMBNAILS","Miniaturas");
	define("MENU_CAMPAIGNS","Sus campañas");
	define("MENU_CAMPAIGNS_ADD","Preparar una nueva campaña");
	define("MENU_CAMPAIGNS_WAITING_LIST","Campaña de lista de espera");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Campañas en curso");
	define("MENU_CAMPAIGNS_SENT","Listar campañas enviadas");
	define("MENU_SYSTEM_CONFIGURATION","Configuración del sistema");
	define("MENU_SETTINGS","Ajustes");
	define("MENU_LOGIN","Iniciar sesión");
	define("MENU_DB","Base de datos");
	define("MENU_SYSTEM_PARAMS","Parámetros del sistema");
	define("MENU_SPECIALS","Complementos especiales");
	define("MENU_ADDONS","Extras útiles");
	define("MENU_CLEAR_DB","Borrar base de datos");
	define("MENU_IMPORT_TEMPLATES","Importación de plantillas de ejemplo");
	define("MENU_IMPORT_DATA","Importar datos de ejemplo");
	define("MENU_FAQ","Preguntas y respuestas");
	define("MENU_ABOUT","Acerca de");
    define("MENU_SMTP_PARAMS","Configuración SMTP");
    define("MENU_UNSUBSCRIBED","Lista de cancelaciones");
    define("MENU_UNSUBSCRIBED_LIST","Lista de destinatarios");
    define("MENU_DOCS","Documentación");
    define("MENU_SUBSCRIBE_WIDGET","Suscribir widget");
    define("MENU_BOUNCED","Compruebe mensajes devueltos");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","Base de datos de correo electrónico");
	define("D_EMAIL_ADD_NEW","Añadir nuevo correo electrónico");
	define("D_EMAIL_TEMPLATES","Plantillas de correo electrónico");
	define("D_EMAIL_TEMPLATES_ADD","Añadir nueva plantilla");
	define("D_EMAIL_SENT","Mensajes enviados");
	define("D_EMAIL_EFFICIENCY","Eficiencia");
	define("D_EMAIL_UNSUBSCIBERS","No suscripto");
	define("D_CAMPAIGNS","Campañas");
	define("D_CAMPAIGNS_ADD","Nueva campaña");
	define("D_CAMPAIGNS_WAITING","Listo para enviar");
	define("D_CAMPAIGNS_SENT","Terminado");
	define("D_STATISTICS","Estadística");
	define("D_THIS_YEAR","Sus campañas publicitarias este año");
	define("D_CHECK_ALL","Compruebe todo...");
	define("JAN","ene");
	define("FEB","feb");
	define("MAR","mar");
	define("APR","abr");
	define("MAY","may");
	define("JUN","jun");
	define("JUL","jul");
	define("AUG","ago");
	define("SEP","sep");
	define("OCT","oct");
	define("NOV","nov");
	define("DEC","dic");
	define("D_PREPARED_OVERALL","Campañas preparadas");
	define("D_SENT_OVERALL","expedido");
	define("D_HOW_TO","¿Cómo funciona?");
	define("D_HOW_STEP_1_TITLE","1. Base de datos de correo electrónico");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Agregar etiquetas</a> Esto le ayudará a encontrar clientes y le ayudará a preparar fácilmente una campaña publicitaria. Siguiente <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>Agregar correos electrónicos</a> s su sistema de base de datos. Tú también puedes <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>cargar archivo CSV</a> con correos electrónicos a su base de datos.");
	define("D_HOW_STEP_2_TITLE","2. Remitentes");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Agregar remitente</a> usted puede decidir de quién sus clientes recibirán un correo electrónico.");
	define("D_HOW_STEP_3_TITLE","3. Plantillas de correo electrónico");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Añadir plantilla</a> Preparar un número ilimitado de plantillas, con un número ilimitado de archivos adjuntos.");
	define("D_HOW_STEP_4_TITLE","4. Campañas publicitarias");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Agregar nueva campaña</a> preparar campañas ilimitadas. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Enviar campaña</a> en cualquier momento.");
	define("D_HOW_STEP_5_TITLE","5. Seguir estadísticas");
	define("D_HOW_STEP_5_DESC","Aquí aprenderá qué campañas son las mejores, cómo y cuándo se preparó la campaña y cuánto se envía y cuál es su eficacia (es decir, cuántas personas abrieron su correo electrónico y cuántas personas no recibieron respuesta de la campaña).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Cambiar acceso");
	define("CHANGE_PASS","Cambia la contraseña");
	define("CLEAR_DATABASE","Borrar base de datos");
	define("LOGOUT","Apagar");
	define("ABOUT","Acerca de");
	
	/*vertical buttons*/
	define("CONFIG","Configuración");
	define("CONFIG_TOOLTIP","Configuración del sistema");
	define("MEDIA_MANAGER","Administrador de archivos adjuntos");
	define("RECIPIENT","Destinatarios");
	define("RECIPIENT_TOOLTIP","Gestión de correos electrónicos");
	define("RECIPIENT_EDIT","Modificar detalles");
	define("RECIPIENT_ADD_NEW","Añadir nuevo");
	define("MENUS","Gestión de menús");
	define("MENUS_TOOLTIP","Configuración del menú");
	define("TEMPLATES","Plantillas");
	define("TEMPLATES_TOOLTIP","Plantillas configuración");
	define("HELP","Ayuda");
	define("HELP_TOOLTIP","Cómo funciona");
	
	define("FILE_MANAGEMENT","Archivos adjuntos");
	define("CSV_IMPORT","Importación de correos electrónicos de archivos CSV");
	
	define("PERSON","Persona");
	define("EMAIL","Dirección de correo electrónico");
	define("TAGS","Etiquetas");
	define("TAGS_LIST","Lista de etiquetas");
	define("TAGS_ADD","Añadir nuevas etiquetas");
	define("TAGS_ADD_NEW","Etiquetas añadiendo");
	define("TAGS_ADD_EDIT","Edición de etiquetas");
	define("TAGS_NAME","Nombre de etiqueta");
	define("TAGS_DESCRIPTION","Descripción");
	define("TAGS_NAME_PLACEHOLDER","Ingrese el nombre de la etiqueta...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","Introducir la descripción de la etiqueta...");
	define("TAGS_USED","Usado (veces)");
	define("TAGS_INFO","Etiquetas para un correo electrónico");
	
	define("RECIPIENT_LIST","Lista de correo");
	define("RECIPIENT_NAME","Nombre del Recipiente");
	define("RECIPIENT_NAME_PLACEHOLDER","Introduzca el nombre completo");
	define("RECIPIENT_MAIL","Correo");
	define("RECIPIENT_MAIL_PLACEHOLDER","Ingrese correo electrónico");
	define("RECIPIENT_ONLY_TXT","Solo correos electrónicos TXT");
	define("RECIPIENT_DESCRIPTION","Descripción");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","Descripción...");
	define("RECIPIENT_DB","Su base de datos de correos electrónicos");
	define("RECIPIENT_DETAILS_EDIT","Editar detalles del destinatario");
	define("RECIPIENT_DETAILS_ADD","Agregar nueva dirección de correo electrónico");
	define("RECIPIENT_IMPORT_CSV","Importar correos electrónicos desde un archivo CSV");
	define("RECIPIENT_PREPARE_CSV","Prepare un archivo CSV con las siguientes líneas");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Para agregar nuevos registros de un archivo de Excel, debe seguir los pasos a continuación");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","Descargar plantilla CSV");

	define("RECIPIENT_UPLOAD_CSV_NAME","Importar archivo CSV");
	define("RECIPIENT_NOT_CSV","<b>Este no es un archivo CSV!!!</b><br/>");
	define("RECIPIENT_ROW","Fila ");
	define("RECIPIENT_WRONG_EMAIL"," - dirección de correo electrónico incorrecta, introducida: ");
	define("RECIPIENT_EMAIL_EXIST"," - esta dirección ya está en la base de datos: ");
	define("RECIPIENT_EMAIL_LACK"," - falta de una dirección de correo electrónico");
	define("RECIPIENT_EMAIL_IN_DB"," - esta dirección de correo electrónico ya existe en el archivo CSV en fila ");
	define("RECIPIENT_TAG_NOT_EXIST"," - ninguna etiqueta: ");
	define("RECIPIENT_CSV_ERRORS","Errores en el archivo ");
	define("RECIPIENT_CSV_ADDED","Adicional ");
	define("RECIPIENT_CSV_ADDED_FROM"," direcciones de correo electrónico del archivo ");
	define("RECIPIENT_CSV_EXPORT","exportar direcciones de correo electrónico a un archivo");
	define("RECIPIENT_CSV_EXPORT_CHK","Seleccione los campos que desea exportar:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Dirección email del destinatario");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Nombre y apellido");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Etiquetas: separadas por un solo espacio");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Comentarios");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Recibir mensajes de texto sólo");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Fecha de introducción");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Fecha de modificación");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","exportar");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Ignore la comprobación de errores CSV (compruebe si el archivo contiene más de 1000 correos electrónicos - los archivos más grandes requieren una gran cantidad de memoria en el servidor)");
	
	define("SAVE","Salvar");
	define("CANCEL","Cancelar");
	define("DELETE","Borrar");
    define("EDIT","Editar");
	define("CREATED","Creado");
	define("MODIFIED","Modificado");
	define("SEND","Enviar");
	define("SENT","Expedido");
	define("PROGRESS","Progreso");
	define("RESUME","Reanudación");
	define("CLOSE","Cerca");
	define("CHANGES_SAVED","Se realizaron cambios con éxito");
	
	define("DELETING","Eliminación");
	define("DELETING_CONFIRM_QUESTION","¿Estás seguro de que desea eliminar?");
	
	define("DATATABLE_LENGTHMENU", "Mostrar _MENU_ registros por página");
	define("DATATABLE_ZERORECORDS", "No se encontró nada - lo siento");
	define("DATATABLE_INFO", "Mostrando la página _PAGE_ de _PAGES_");
	define("DATATABLE_INFOEMPTY", "No hay registros disponibles");
	define("DATATABLE_INFOFILTERED", "(filtrado _TOTAL_ de _MAX_ registros totales)");
	define("DATATABLE_SEARCH", "Buscar");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Añadir nueva plantilla");
	define("TEMPLATES_LIST", "Lista de plantillas");
	define("TEMPLATES_TITLE", "Plantillas disponibles");
	define("TEMPLATES_TITLE_ADD", "Añadir nuevo diseño");
	define("TEMPLATES_TITLE_EDIT", "Edición de diseño");
	define("TEMPLATES_NAME", "Nombre del diseño");
	define("TEMPLATES_MAIL_TITLE", "Título del correo electrónico");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Ingrese el título del correo electrónico");
	define("TMPLATES_HTML", "Versión HTML");
	define("TMPLATES_TXT", "Versión TEXTO");
	define("TMPLATES_VARIABLES", "Variables de plantilla disponibles (comprobar <a href='docs/index.html#variables' target='_blank'>documentación</a> para detalles):");
	define("TEMPLATES_THUMB", "Miniatura");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Edición de miniaturas");
	define("THUMBNAIL_MEDIA_LIST", "Lista de miniaturas disponibles");
	
	define("MEDIA_FILENAME", "Nombre del archivo");
	define("MEDIA_FILENAME_DESCRIPTION", "Descripción del archivo");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Tiempo de subida");
	define("MEDIA_TEMPLATES", "Utilizado como archivo adjunto");
	define("MEDIA_LIST", "Lista de archivos adjuntos disponibles");
	define("MEDIA_ADD_FILES", "Agregar archivos");
	define("MEDIA_BROWSE", "Vistazo");
	define("MEDIA_UPLOAD", "Subir");
	
	define("CAMPAIGN_MENU", "Nueva campaña");
	define("CAMPAIGN_PREPARE", "Preparar la campaña");
	define("CAMPAIGN_RECIPIENTS", "Elegir destinatarios");
	define("CAMPAIGN_TEMPLATES", "Elija el diseño");
	define("CAMPAIGN_SENDERS", "Elegir remitente");
	define("CAMPAIGN_CONFIRM", "Guardar campaña");
	define("CAMPAIGN_SEND", "Enviar campaña");
	define("CAMPAIGN_NAME", "Nombre de campaña");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Ingrese el nombre de la campaña");
	define("CAMPAIGN_RECIPIENT_QTY", "Destinatarios");
	define("CAMPAIGN_TEMPLATE_NAME", "Diseño");
	define("CAMPAIGN_SENDER", "Remitente");
	define("CAMPAIGN_CREATED_DATE", "Preparado");
	define("CAMPAIGN_STEP_1", "1. Seleccione sus destinatarios (use el campo 'Buscar' sobre la tabla)");
	define("CAMPAIGN_STEP_2", "2. Guardar su campaña");
	define("CAMPAIGN_SELECT", "Selecciona la campaña de envío");
	define("CAMPAIGN_FORM_SELECT", "seleccionar...");
	define("CAMPAIGN_CURRENT_STATUS", "Estado de la campaña actual");
	define("CAMPAIGN_SENT_NOW", "Envíalo ahora");
	define("CAMPAIGN_SENT_BUTTON", "Haga clic aquí para comenzar a enviar");
	define("CAMPAIGN_RESUME_BUTTON", "Haga clic aquí para reanudar el envío");
	define("CAMPAIGN_SERVER_CONNECTING", "Conectando al servidor, por favor espere...");
	define("CAMPAIGN_SENDING", "enviando");
	define("CAMPAIGN_PLEASE_WAIT", "por favor espera...");
	define("CAMPAIGN_SENT", "<b>CAMPAÑA ENVIADA</b> destinatarios: ");
	define("CAMPAIGN_IN_PROGRESS", "Campañas en curso...");
	define("CAMPAIGN_COMPLETED", "Campañas enviadas");
	define("CAMPAIGN_LEFT", "Izquierda para enviar");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Eliminar todos los suscriptores");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "Esta acción eliminará todos los suscriptores de su base de datos.");
	define("CAMPAIGN_BG_PROCESS", "Proceso de fondo");
	define("CAMPAIGN_BG_PROCESS_INFO", "Enviar como un proceso de fondo (puede cerrar el navegador)");
	define("CAMPAIGN_WHEN_FINISH", "Correo electrónico cuando termine");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "Dónde enviar notificación");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Confirme el envío de fondo!");
    
    define("HOUR", "hora");
    define("OPENS", "Abre");
    define("BOUNCED", "Rebotado");
    define("CLICKED", "Hizo clic");
    define("UNIQUE_CLICKS", "Clics únicos");
    define("TOTAL_CLICKS", "Total de clics");
	
	define("SENDER_LIST", "Lista de remitentes");
	define("SENDER_ADD", "Agregar remitente");
	define("SENDER_NAME", "Nombre del remitente");
	define("SENDER_NAME_PLACEHOLDER", "Introduzca el nombre del remitente");
	define("SENDER_EMAIL", "Correo electrónico del remitente");
	define("SENDER_EMAIL_PLACEHOLDER", "Introducir correo electrónico del remitente");
	define("SENDER_TITLE_ADD", "Agregar remitente");
	define("SENDER_TITLE_EDIT", "Editar remitente");
	define("SENDER_EMAIL_TITLE", "Dirección de correo electrónico del remitente");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Introduce la dirección de correo electrónico del remitente");
	
	define("SETTINGS", "Ajustes");
	define("SETTINGS_LOGIN_TITLE", "Introducir nuevas credenciales");
	define("SETTINGS_LOGIN_LABEL", "Ingresar nuevo inicio de sesión");
	define("SETTINGS_LOGIN_PLACEHOLDER", "Ingresar login");
	define("SETTINGS_CURR_PASS", "Contraseña actual");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "introducir la contraseña");
	define("SETTINGS_NEW_PASS", "Nueva contraseña");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "nueva contraseña");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "confirmar");
	define("SETTINGS_DB_PARAMS", "Configurar la base de datos");
	define("SETTINGS_DB_HOST", "Host de base de datos");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "p.ej.: localhost");
	define("SETTINGS_DB_USER", "Usuario de la base de datos");
	define("SETTINGS_DB_USER_PLACEHOLDER", "p.ej.: root");
	define("SETTINGS_DB_PASSWORD", "Contraseña de base de datos");
	define("SETTINGS_DB_NAME", "Nombre de la base de datos");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "p.ej.: mailing");
	define("SETTINGS_GLOBAL", "Ajustes globales");
	define("SETTINGS_LANG", "Idioma del sistema");
	define("SETTINGS_LIMIT", "Configurar el límite de correo electrónico por hora");
	define("SETTINGS_LIMIT_PLACEHOLDER", "defecto: 1000");
	define("SETTINGS_TRACKING", "Habilitar el seguimiento de correo electrónico");
	define("SENDING_METHOD", "Método de envío");
	define("SETTINGS_UNSUBSCRIBED", "Eliminación automática no suprimida");
	define("SETTINGS_UNS_INFO", "El correo electrónico se eliminará automáticamente de la lista de destinatarios cuando el usuario haga clic en el enlace unsubscibe");
	define("SETTINGS_TRACK_INFO", "Se agregará una etiqueta img invisible para rastrear a su destinatario");
	define("SETTINGS_API_LABEL", "Mapas de Google<br>API key");
	define("SETTINGS_API_PLACEHOLDER", "Ingresa tus mapas google API v.3 key aquí");
	define("SETTINGS_API_LINK_INFO", "Haga clic aquí para obtener nuevo API key");
	define("SETTINGS_ADMIN_MAIL", "Correo electrónico del administrador");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "Correo electrónico de administración para notificaciones del sistema");
    define("SETTINGS_PHP_TIMEOUT", "Tiempo de espera de PHP (segundos)");
    
	define("SMTP_SERVER_DESCRIPTION", "Servidor SMTP, asegúrese de añadir algunos");
    define("SMTP_LIST", "Lista de servidores");
    define("SMTP_ADD", "Agregando nuevo servidor");
    define("SMTP_EDIT", "Servidor de edición");
    define("SMTP_INFO", "Sus servidores SMTP");
    define("SMTP_ADD_BUTTON", "Haga clic para agregar un nuevo servidor SMTP");
    define("SMTP_NAME", "Nombre de la conexión");
    define("SMTP_NAME_PLACEHOLDER", "p.ej.: Mi mejor conexión");
    define("SMTP_HOST", "Dirección SMTP");
    define("SMTP_HOST_PLACEHOLDER", "Servidor principal y de copia de seguridad (separador ';' para copia de seguridad)");
    define("SMTP_PAUTH", "Autenticación");
    define("SMTP_PAUTH_PLACEHOLDER", "Habilitar la autenticación SMTP");
    define("SMTP_VERIFY_PEER", "Habilitar la verificación del certificado SSL/TLS");
    define("SMTP_FORCE_SMTP", "Fuerza el uso de SMTP");
    define("SMTP_USERNAME", "Nombre de usuario SMTP");
    define("SMTP_USERNAME_PLACEHOLDER", "Nombre de usuario SMTP");
    define("SMTP_LOGIN", "Acceso SMTP");
    define("SMTP_LOGIN_PLACEHOLDER", "Acceso al servidor SMTP");
    define("SMTP_PASSWORD", "Contraseña SMTP");
    define("SMTP_PASSWORD_PLACEHOLDER", "Contraseña SMTP");
    define("SMTP_REPLYTO", "Responder al correo");
    define("SMTP_REPLYTO_PLACEHOLDER", "Establecer una dirección alternativa de respuesta");
    define("SMTP_REPLYTONAME", "Responder al nombre");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Establecer una respuesta alternativa al nombre");
    define("SMTP_SECURE", "Cifrado");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> Como cifrado predeterminado");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> aceptado pero no recomendado");
    define("SMTP_PORT", "Puerto");
    define("SMTP_PORT_PLACEHOLDER", "Puerto de servicio");
    define("SMTP_LIMIT", "Límite por hora");
    define("SMTP_LIMIT_PLACEHOLDER", "defecto: 1000");
    define("CAMPAIGN_SMTP", "Seleccione SMTP");
    define("SMTP_TESTING", "Prueba de conexión SMTP");
    define("SMTP_TESTING_EMAIL", "Dirección para probar el mensaje");
    define("SMTP_RUN_TEST", "Revisalo!");
    define("SMTP_TEST_TXT_TITLE", "Prueba SMTP desde correo electrónico.");
    define("SMTP_TEST_TXT_MESSAGE", "Probar mensaje desde su conexión SMTP.");
    define("SMTP_TEST_OK", "El mensaje ha sido enviado. Revisa tu correo.");
    define("SMTP_TEST_ERROR", "<b>Error de correo: </b>");
    define("SMTP_BEFORE_USE", "<b>Error de correo.</b> Es necesario habilitar la conexión SMTP en la configuración antes de usar.");
    define("BOUNCED_INFO", "Los correos electrónicos devueltos volverán a ese buzón");
    define("SMTP_CONFIG", "Configure su SMTP para enviar");
    define("IMAP_CONFIG", "Configurar IMAP / POP3 para rebotes");
    define("SMTP_INFO_SETUP", "Configuración de SMTP");
    define("IMAP_INFO_SETUP", "Configuración IMAP / POP3");
    define("PROTOCOL", "Protocolo");
    define("FOLDER", "Carpeta para acceder");
	
	define("STATISTICS", "Estadística");
	define("STATISTICS_ADV", "Detalles avanzados");
	define("STATISTICS_TAB_MAP", "Recipientes en el mapa (geolocalización)");
	define("STATISTICS_TAB_DETAILS", "Estadísticas detalladas");
	define("STATISTICS_TAB_ACTIONS", "Acciones especiales");
	define("STATISTICS_BACK", "Volver a la lista");
	define("STATISTICS_BUTTON_OPENERS", "Prepárese para abrir");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Preparar una nueva campaña para todos los que han abierto un correo electrónico");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Prepárate para NO abridores");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Prepare una nueva campaña para todos aquellos que NO han abierto un correo electrónico");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Prepárese para suscribirse");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Preparar una nueva campaña para todos los suscriptores, si se habilita la opción 'Eliminar automáticamente no suscritos' en la configuración del sistema, se eliminarán los correos electrónicos y no se agregará nada.");
	define("STATISTICS_BUTTON_FILTERS", "Preparar con filtros avanzados");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Obtenga una lista de todos los destinatarios de esta campaña con los datos recopilados y prepare una nueva campaña especial basada en filtros avanzados");
	define("STATISTICS_TOP_COUNTRIES", "Los 10 mejores países");
	define("STATISTICS_TOP_CITIES", "Las 10 mejores ciudades");
	define("STATISTICS_TOP_CLICKERS", "Los 15 primeros clics");
	define("STATISTICS_TOP_SOFTWARE", "Los 15 programas más populares");
	define("STATISTICS_OTHER_UA", "Todos los demás agentes de usuario");
	define("STATISTICS_OTHERS", "Otros");
    
	define("SOFTWARE", "Software");
	define("GEODATA", "Localización");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='confirmación'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Se ha cancelado la suscripción al boletín.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Que tengas un buen día.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Eliminación de datos innecesarios de la base de datos");
	define("ADDONS_IMPORT_TITLE", "Adición de plantillas de ejemplo de correo");
	define("ADDONS_FAQ_TITLE", "Lea antes de preguntar");
	define("ADDONS_ABOUT_TITLE", "Información sobre el programa y la licencia");
	define("ADDONS_IMPORT_DATA_TITLE", "Importar datos de muestra al sistema");
	define("ADDONS_IMPORT_BUTTON", "Importar plantillas de correo electrónico");
	define("ADDONS_IMPORT_BUTTON_DESC", "Esto importará plantillas de muestra para el correo");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Confirmar la adición de plantillas de ejemplo para el envío");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Confirme la adición de datos de muestra al sistema. Todos los datos introducidos actualmente se borrarán!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>¿Por qué es mejor tener un servidor dedicado para enviar por correo?</p>
			<p>En primer lugar, sin límites. Para el alojamiento ordinario, puede enviar hasta 1.000 correos electrónicos por hora y probablemente la misma cantidad en un día (dependiendo de los límites de alojamiento de unos pocos cientos a unos miles de correos electrónicos al día). En su servidor, no tiene tales restricciones y también tiene la capacidad de enviar correos electrónicos de su dominio. También puede enviar correos electrónicos como si el servidor tuviera que estar bajo un dominio diferente (en este caso se establecen los llamados registros SPF y el dominio TXT).</p>
		</li>
		<li>
			<p>¿Qué son las etiquetas?</p>
			<p>Facilita la búsqueda de direcciones de correo y la preparación de una campaña publicitaria en destinatarios específicos.</p>
		</li>
		<li>
			<p>¿Cómo agregar el nombre del destinatario a la plantilla de correo electrónico?</p>
			<p>Utilice la frase {RECIPIENT_NAME} en el correo electrónico de la plantilla de contenido o en el título del correo de la plantilla. La frase se sustituirá por el nombre del destinatario de correo electrónico, en caso de que la información se ha añadido a la dirección de correo electrónico del destinatario.</p>
		</li>
		<li>
			<p>¿Cómo añadir una nueva traducción?</p>
			<p>Copia la referencia de archivo english.php, dale un nombre que describe tu idioma por ejemplo mylanguage.php y pégalo en la misma carpeta. Corrija todos los textos contenidos en el nuevo archivo. Asegúrese de guardar el archivo en UTF-8 sin BOM. El archivo de idioma está en el directorio 'languages'.</p>
			<p>Para agregar traducción del editor WYSIWYG, vaya a https://www.tinymce.com/download/language-packages/ - descargar el idioma del archivo apropiado y guardarlo en /emailer/libs/tinymce/langs/ carpeta.</p>
		</li>
		<li>
			<p>¿Cómo puedo añadir etiquetas a un correo electrónico?</p>
			<p>En primer lugar, es necesario agregar algunas etiquetas <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>usando este formulario</a>. A continuación, cuando se agrega / editar cada dirección de correo electrónico se puede asignar a cualquier etiqueta. Todas las etiquetas se agregarán debajo del formulario para agregar / editar destinatarios.</p>
		</li>
		<li>
			<p>¿Cómo agregar la capacidad de cancelar la suscripción de recibir mensajes?</p>
			<p>Utilice la frase {UNSUBSCRIBE} en el enlace del contenido de la plantilla de correo electrónico. La frase será reemplazada por un enlace para el destinatario particullar. Cuando haga clic en él, el sistema guardará en la base de datos información sobre la descarga de la campaña. La dirección de correo electrónico no se eliminará de la base de datos. <br>Uso:<br>&lt;a href='{UNSUBSCRIBE}'&gt;Cancelar la suscripción a la newsletter&lt;/a&gt;</p>
		</li>
		<li>
			<p>¿Cómo agregar la capacidad a la vista del navegador?</p>
			<p>Utilice la frase {BROWSER_VIEW} en el enlace del contenido de la plantilla de correo electrónico. La frase será reemplazada por un enlace para el destinatario particullar. Cuando haga clic en él, el sistema abrirá el mensaje en la ventana del navegador. <br>Uso:<br>&lt;a href='{BROWSER_VIEW}'&gt;Vista del navegador&lt;/a&gt;</p>
		</li>
		<li>
			<p>¿Cómo agregar plantillas predefinidas de correo electrónico?</p>
			<p>30 plantillas de muestra mailing, haga clic aquí <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>para agregar plantillas</a></p>
		</li>
		<li>
			<p>¿Cómo agrego imágenes a los correos electrónicos?</p>
			<p>- Como adjunto a un correo electrónico. En este caso, el atributo de etiqueta IMG de la plantilla SCR debe establecerse en contentID, significa CID, p.ej:<br>&lt;img src='cid:logo.jpg' &gt;<br>- Como enlace absoluto a una imagen en recursos externos, como:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>¿Cómo funciona el seguimiento de correos electrónicos?</p>
			<p>Para cada sistema de correo electrónico enviado puede agregar una etiqueta de imagen IMG, cuyo atributo SRC contiene código de seguimiento para mostrar un mensaje específico. El seguimiento sólo funcionará cuando el destinatario del correo acepte mostrar imágenes del mensaje recibido.</p>
		</li>
		<li>
			<p>¿Cómo no ser un spammer?</p>
			<p>- Recopilar el consentimiento para recibir mensajes al crear una lista de correo.</p>
			<p>- Use una variedad de contenido para cada destinatario, use ex. {RECIPIENT_NAME} para diferenciar las sumas de comprobación de su correo.</p>
			<p>- No utilice las palabras claves como: sexo, viagra, pornografía.</p>
			<p>- No utilice frases clave como: dirección de una base de datos pública, no es información comercial en mente, desinteresado Lo sentimos, no constituye una oferta dentro del significado si no desea, haga clic aquí para anular la suscripción, gratis, oferta especial, Comprar ahora - si usted tiene que utilizar este tipo de frases que usted debe considerar para ponerlos en forma de gráficos.</p>
			<p>- No utilice demasiados gráficos, los filtros de spam examinar la relación de los gráficos con el texto.</p>
			<p>- El correo no debe ser demasiado pesado.</p>
			<p>- Cuantos menos apegos mejor.</p>
			<p>- No suplantar a otro dominio.</p>
			<p>- No envíe correos electrónicos de direcciones de correo electrónico inexistentes.</p>
		</li>
		<li>
			<p>¿Cómo aumentar los clics y leer la campaña?</p>
			<p>La mayor influencia en el contenido que envía a sus clientes y el tiempo y la frecuencia con la que lo hace. En la mayoría de los casos, el contacto no debe ser más frecuente que dos veces al mes. Respeta a tus clientes y no te lanzarán al spam.</p>
		</li>
		<li>
			<p>¿Cómo elegir las direcciones para enviar?</p>
			<p>Utilizando etiquetas, escríbalas por espacios en el campo de búsqueda sobre la tabla de direcciones.</p>
		</li>
		<li>
			<p>¿Cuáles son las limitaciones de este sistema?</p>
			<p>No hay restricciones.</p>
		</li>
		<li>
			<p>Limitar los mensajes en el servidor de alojamiento?</p>
			<p>Dependiendo de los límites de alojamiento de unos pocos cientos a unos miles de correos electrónicos al día, consulte con su proveedor de servicios.</p>
		</li>
		<li>
			<p>¿Conexión rota al enviar campaña?</p>
			<p>Puede reanudar el envío de campañas, los correos electrónicos se enviarán a los otros destinatarios. Cada correo electrónico enviado establece un marcador único en la base de datos y la campaña en sí no se reenviará al mismo destinatario.</p>
		</li>
		<li>
			<p>Requisitos para correos electrónicos devueltos</p>
			<p>Para habilitar el soporte para los correos electrónicos devueltos, tienes que descomentar esta línea en el archivo php.ini.</p>
			<p>;extension=php_imap.dll</p>
			<p>Las funciones de Imap son necesarias para usar las conexiones POP3 / IMAP.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Sea cuidadosamente, las siguientes acciones limpiar tablas en la base de datos!");
	define("ADDONS_DATA_BE_CAREFULLY", "¡Advertencia! Todos los datos serán borrados y reemplazados con datos de muestra");
	define("ADDONS_D_AL", "Eliminar todos los datos");
	define("ADDONS_D_AL_DESC", "Borra todos los datos de la base de datos");
	define("ADDONS_D_AL_CONF", "¿Está seguro de que desea eliminar todos los datos de la base de datos? Se eliminarán todas las direcciones de correo electrónico, plantillas, archivos adjuntos y campañas.");
	define("ADDONS_D_RE", "Eliminar los destinatarios y sus campañas");
	define("ADDONS_D_RE_DESC", "Elimina todas las direcciones de correo electrónico de la base de datos y el historial de campañas publicitarias.");
	define("ADDONS_D_RE_CONF", "Confirme la eliminación de todos los destinatarios");
	define("ADDONS_D_CA", "Eliminar sólo campañas");
	define("ADDONS_D_CA_DESC", "Elimina todas las campañas publicitarias y su historia");
	define("ADDONS_D_CA_CONF", "Confirma la eliminación de todas las campañas y su historial");
	define("ADDONS_D_TE", "Eliminar plantillas únicamente");
	define("ADDONS_D_TE_DESC", "Elimina todas las plantillas de correo electrónico y sus vínculos con campañas y archivos adjuntos");
	define("ADDONS_D_TE_CONF", "Confirmar la eliminación de todas las plantillas");
	define("ADDONS_D_AT", "Eliminar sólo los archivos adjuntos");
	define("ADDONS_D_AT_DESC", "Borra todos los archivos adjuntos");
	define("ADDONS_D_AT_CONF", "Confirmar eliminar todos los archivos adjuntos");
	define("ADDONS_D_SE", "Eliminar sólo los remitentes");
	define("ADDONS_D_SE_DESC", "Elimina todo el correo electrónico de los remitentes ingresados pero deja su ID con fines estadísticos");
	define("ADDONS_D_SE_CONF", "Confirme la eliminación de todos los remitentes");
	define("ADDONS_D_TG", "Eliminar sólo etiquetas");
	define("ADDONS_D_TG_DESC", "Borrar todas las etiquetas introducidas y sus relaciones con los clientes");
	define("ADDONS_D_TG_CONF", "Confirmar eliminar todas las etiquetas");
    
	define("WIDGET_PREPARE", "Prepare su widget de suscripción");
	define("WIDGET_OPTIONS", "Opciones");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Genera tu widget de suscripción aquí");
	define("WIDGET_COMMENT", "Comentario sobre el nuevo destinatario");
	define("WIDGET_COMMENT_PLACEHOLDER", "p.ej.: de domain.ext (Se guardará en la descripción del destinatario)");
	define("WIDGET_NAME", "Nombre");
	define("WIDGET_NAME_SHOW", "Mostrar el campo del nombre del destinatario");
	define("WIDGET_AFTER", "Después de enviar widget de suscripción");
	define("WIDGET_AFTER_NOTHING", "hacer nada");
	define("WIDGET_AFTER_TXT", "Mostrar mensaje de texto");
	define("WIDGET_AFTER_REDIRECT", "Redireccionar a la página");
	define("WIDGET_TAGS", "Agregar etiquetas");
	define("WIDGET_PURE_CODE_TXT", "Código HTML puro. Puede modificarlo según sus necesidades. Agregue clases, etiquetas, descripciones, lo que quiera. Copie el código de abajo y péguelo en su sitio web.");
	define("WIDGET_FULL_CODE_TXT", "Versión completa (todos los campos incluidos)");
	define("WIDGET_MIN_CODE_TXT", "Versión minimizada (sólo correo electrónico incluido)");
	define("WIDGET_CODE_DESC_TXT", "Descripción del formulario");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> necesario.</li>
        <li>Dirección de correo electrónico del suscriptor.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> opcional.</li>
        <li>Nombre del suscriptor.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> opcional.</li>
        <li>Campo escondido.</li>
        <li>Deben añadirse ya a la base de datos.</li>
        <li>Deben estar separados por comas.</li>
        <li>Usando diferentes etiquetas puedes hacer diferentes campañas.</li>
        <li>Puede utilizar el mismo formulario en diferentes sitios y utilizar etiquetas diferentes en cada sitio.</li>
        <li>Esto significa que este componente puede recopilar suscriptores de diferentes sitios y agregarlos a su sistema con diferentes etiquetas.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> opcional.</li>
        <li>Campo escondido.</li>
        <li>Agregue su descripción para el destinatario.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> opcional.</li>
        <li>Campo escondido.</li>
        <li>Habilitar la característica de doble opt-in.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> opcional.</li>
        <li>Campo escondido.</li>
        <li>Dónde redirigir después de suscribirse. Si el campo está vacío o no está incluido en el formulario, se realizará la acción configurada.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Copia el código de abajo y pégalo en tu sitio");
	define("WIDGET_DBL_OPT_IN", "Double opt-in");
	define("WIDGET_DBL_OPT_LABEL", "Compruébelo para usar la confirmación de suscripción doble");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "Mensaje de correo electrónico (HTML de soporte)");
	define("WIDGET_DBL_OPT_HELP", "No te olvides de añadir <b>{CONFIRM_LINK}</b> en su mensaje.<br>También puede agregar:<br><b>{SUBSCRIBER_EMAIL}</b> - Dirección de correo electrónico del suscriptor<br><b>{SUBSCRIBER_NAME}</b> - Nombre del suscriptor<br><b>{SUBSCRIBER_COMMENT}</b> - Tu comentario sobre suscriptor<br><b>{SUBSCRIBER_TAGS}</b> - Etiquetas usadas<br><b>{CURRENT_YEAR}</b> - año corriente<br><b>{CURRENT_MONTH}</b> - mes actual<br><b>{CURRENT_DAY}</b> - día actual");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "Título del correo electrónico");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "Ingrese el título de confirmación de correo electrónico...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "Introduzca el mensaje de confirmación por correo electrónico...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Redirigir a después de la confirmación");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "Ingrese la dirección a donde redirigir después de la confirmación");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Enviar desde la dirección");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "Introduzca la dirección de correo electrónico a partir de la cual se enviará la confirmación");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Descripción del remitente");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "Introduzca la descripción para el remitente");
	define("WIDGET_ADMIN_NOTIFY", "Notificar al administrador acerca del nuevo suscriptor");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "Marque para enviar una notificación por correo electrónico después de que se reciba la nueva suscripción. <br><br> <b>¡ADVERTENCIA!</b> el correo electrónico del administrador debe configurarse en los parámetros del sistema!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Mensaje de administración (HTML de soporte)");
	define("WIDGET_ADMIN_HELP", "Se puede utilizar en su mensaje:<br><b>{SUBSCRIBER_EMAIL}</b> - Dirección de correo electrónico del suscriptor<br><b>{SUBSCRIBER_NAME}</b> - Nombre del suscriptor<br><b>{SUBSCRIBER_COMMENT}</b> - Tu comentario sobre suscriptor<br><b>{SUBSCRIBER_TAGS}</b> - Etiquetas usadas<br><b>{CURRENT_YEAR}</b> - año corriente<br><b>{CURRENT_MONTH}</b> - mes actual<br><b>{CURRENT_DAY}</b> - día actual");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Mensaje de error del servidor en caso de dirección de correo electrónico incorrecta del suscriptor");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Elige tu servidor");
	define("BOUNCED_DEL_EMAILS", "Eliminar automáticamente de la lista de destinatarios");
	define("BOUNCED_DEL_MESSAGES", "Eliminar automáticamente todos los mensajes rechazados y comprobados del servidor");
	define("BOUNCED_MAX", "Límite máximo de mensajes");
	define("BOUNCED_AT_TIME", "Comprobar al mismo tiempo");
	define("BOUNCED_START", "Compruebe el buzón de mensajes devueltos");
	
	define("YES", "Sí");
	define("NO", "No");
	define("DATA_ERROR", "ERROR: Los datos solicitados no existen...<br><br><a href='index.php'>Haga clic aquí para abrir el panel</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "El servidor de correo para enviar widget de suscripción");
    define("TESTING_TEMPLATE", "Plantilla de prueba");
    define("TESTING_TEMPLATE_INFO", "Envía la plantilla al correo electrónico que aparece a continuación. Las variables no serán sustituidas.");
    define("TESTING_CHOOSE_SERVER", "Seleccionar servidor de envío");
    define("ERRORS", "Errores");
    define("TEST", "Pruebame!");
    
    /*v.1.16*/
    define("COPY", "Dupdo");
    define("COPYING", "Albardilla");
    define("CHECK", "Comprobar");
    define("DATA_VERIFY", "Comprobación de integridad de datos");
    define("DATA_VERIFY_QUESTION", "¿Está seguro de que desea verificar la integridad de los datos?");
    define("DATA_VERIFY_DESCRIPTION", "Esta operación puede tardar varios minutos, depende de la cantidad de datos en su base de datos. <br> Hazlo si estás seguro de que la campaña se ha terminado y no es visible en esta lista.");
    define("DATA_VERIFY_BUTTON", "Verificar la integridad de los datos");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Filtrar destinatarios de las etiquetas seleccionadas (OR&nbsp;query)");
    define("REC_QUERY_AND", "Los destinatarios del filtro están en TODAS las etiquetas seleccionadas (AND&nbsp;query)");
    define("REC_RESET", "Restablecer consulta");
    define("REC_BUTTON_DELETE", "Eliminar destinatarios");
    define("CSV_ST_1", "Prepare los datos de acuerdo con la fórmula:");
    define("CSV_COL_NO", "número de columna");
    define("CSV_REQ", "necesario");
    define("CSV_OPT", "opcional");
    define("CSV_ADDR", "dirección de correo electrónico");
    define("CSV_NAME", "Nombre y apellido");
    define("CSV_TAGS", "etiquetas");
    define("CSV_TAGSDESC", "debe estar en la base de datos debe estar separado por un solo espacio");
    define("CSV_COMMENT", "comentarios");
    define("CSV_DESC1", "Guarde la hoja de cálculo como un archivo CSV");
    define("CSV_DESC2", "delimitador");
    define("CSV_MAXLINE", "longitud máxima de línea CSV");
    define("CSV_FORMDESC", "Suba un archivo CSV preparado utilizando el siguiente formulario");
    define("DISABLE_EDITOR", "Deshabilitar editor");
    define("ENABLE_EDITOR", "Habilitar editor");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "Importar correos electrónicos por puente de DB");
    define("TITLE_IMPORT", "Importación de destinatarios");
    define("SUBTITLE_IMPORT", "puente de base de datos - parámetros de origen");
    define("LIST_TITLE_IMPORT", "Importar destinatarios de otra base de datos");
    define("ADD_NEW_BRIDGE", "Agregar nuevo puente");
    define("IMPORT_RECIPIENTS", "Importar destinatarios");
    define("IMPORT_BRIDGE_DESC", "Descripción del puente de importación");
    define("CONFIRM_BRIDGE_DEL", "Eliminar la conexión del puente de la base de datos");
    define("IMPORTING_BRIDGE_REC", "Importar destinatarios");
    define("CHOOSEN_BRIDGE", "Puente elegido para la importación");
    
    define("FORM_BRIDGE_DESC", "Descripción del puente de importación");
    define("BRIDGE_TABLE", "Nombre de la tabla fuente");
    define("BRIDGE_COL_NAME", "Fuente de columna para el nombre del destinatario");
    define("BRIDGE_COL_NAME_INFO", "se importará al campo de nombre del destinatario");
    define("BRIDGE_COL_MAIL", "Fuente columna para dirección de correo electrónico");
    define("BRIDGE_COL_MAIL_INFO", "se importará al campo Correo electrónic");
    define("BRIDGE_COL_DESC", "Columna de origen para descripción del destinatario");
    define("BRIDGE_COL_DESC_INFO", "se importará al campo Descripción");
    define("BRIDGE_CHECK_CON", "Verificar la conexión de la base");
    define("BRIDGE_WAITING", "esperando la prueba...");
    define("BRIDGE_ADD_NAME", "Nombre del destinatario adicional");
    define("BRIDGE_ADD_NAME_INFO", "se agregará después de la columna de nombre de fuente");
    define("BRIDGE_ADD_DESC", "Descripción adicional del destinatario");
    define("BRIDGE_ADD_DESC_INFO", "se agregará después de la columna de descripción de fuente");
    define("BRIDGE_OVERRIDE", "Anular destinatarios existentes");
    define("BRIDGE_OVERRIDE_O1", "update - destinatario de destino correcto según la nueva fuente");
    define("BRIDGE_OVERRIDE_O2", "ignore - no hacer nada si el destinatario de destino ya existe");
    define("BRIDGE_TAGS", "Etiquetas disponibles");
    define("BRIDGE_FILL_FIELDS", "llene todos los campos requeridos antes de probar...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "importación en progreso, por favor espere...");
    define("BRIDGE_TEST_OK", "Su puente de conexión funciona correctamente");
    define("BRIDGE_IMPORT_OK1", "Importar terminado Actualizado:");
    define("BRIDGE_IMPORT_OK2", " Insertado:");
    define("TABLE", "Mesa ");
    define("COLUMN", "Columna ");
    define("NOT_IN_DB", " no existe en la base de datos ");
    define("NOT_IN_TABLE", " no existe en la tabla ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "ingrese su clave de API de geolocalización aquí");
    define("SETTINGS_API_GEO_LINK_INFO", "haga clic aquí para obtener una nueva clave de API de geolocalización");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Usar https");
    define("HTTPS_USAGE_INFO", "marca si estás usando https, esto generará todos los enlaces con https");
    define("TEMPLATE_STATISTICS", "Estadísticas de plantillas: ");
    define("TEMPLATE_CHARS", "llaves: ");
    define("TEMPLATE_USAGE", "usado: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Formulario de suscripción token de registro ");
    define("WIDGET_EMAIL_TOKEN", "Suscripción de correo electrónico registro token ");
    
    /*v.1.22*/
    define("WEBSITE", "Sitio web");
    define("WIDGET_WEBSITE_SHOW", "Mostrar campo de URL del destinatario");
    define("VERIFIED", "Verificado");
    define("VERIFY", "Verificar");
    define("C_PREPARED", "preparado y esperando");
    define("C_AJAX_PROGRESS", "ajax enviando en progreso");
    define("C_FINISHED", "terminado");
    define("C_BG_PROGRESS", "envío de fondo en curso");
    define("C_PAUSED", "en pausa");
    define("C_CRON", "cron enviando en progreso");
    define("B_VER", "Verificación masiva");
    define("B_RV", "Verificación de destinatarios a granel");
    define("B_SEND1", "¿Estás seguro de que quieres enviar");
    define("B_SEND2", "destinatarios para la verificación");
    define("B_CHECK_LIST", "verifique las listas de verificación masiva");
    define("B_VER_INFO", "Sus cheques a granel estarán disponibles en su cuenta emailable.com");
    define("B_VER_IN_PROG", "verificación en progreso");
    define("B_VER_SENT", "Los destinatarios enviados para la comprobación a granel");
    define("B_V_TITLE", "Verificaciones masivas de correo electrónico");
    define("B_V_TITLE2", "listas enviadas");
    define("BUTTON_CHECK_STATUS", "Comprobar estado");
    define("BUTTON_DOWN_UP", "Descarga de la actualización");
    define("V_ID", "verificar id");
    define("V_QTY", "cantidad a verificar");
    define("V_DATE", "fecha enviada");
    define("V_MESSAGE", "estado");
    define("V_PERC", "% completar");
    define("V_WORKING", "trabajando");
    define("RESPONSE", "respuesta");
    define("V_UPDATED_INFO", "Destinatarios actualizados, consultar detalles.");
    define("SETTINGS_API_THECHECKER", "Haga clic aquí para obtener la clave de API emailable.com");
    define("SETTINGS_API_DESCRIPTION", "¡Vamos a matar los rebotes! <br>Al usar el botón a continuación, le daremos <b>30% GRATUITOS GRATUITOS</b> en su primera compra y le otorgaremos un bono del 30% (en efectivo o cheques) por cada compra que realice, ¡para siempre!");
    define("EC_DATA", "Exportar todos los datos de las campañas.");
    define("EC_DATA1", "Exportar datos de campaña");
    define("EX_OPENED_BUTTON", "Destinatarios que abrieron");
    define("EX_OPENED_DESC", "Exportar destinatarios de campaña que abrieron correo electrónico de campaña");
    define("EX_NOT_OPENED_BUTTON", "Destinatarios que no abren");
    define("EX_NOT_OPENED_DESC", "Exportar destinatarios de la campaña que NO abrieron el correo electrónico de la campaña.");
    define("EX_UNSUBSRIBED_BUTTON", "Destinatarios que desuscribieron");
    define("EX_UNSUBSRIBED_DESC", "Exportar destinatarios de campaña que cancelaron su suscripción a la campaña");
    define("EX_CLICKED_BUTTON", "Destinatarios que hicieron clic");
    define("EX_CLICKED_DESC", "Exportar destinatarios de la campaña que hicieron clic en el enlace en el correo electrónico de la campaña.");
    define("EX_ALL_BUTTON", "Todos los datos de los destinatarios");
    define("EX_ALL_DESC", "Exportar todos los datos de los destinatarios de la campaña actual.");
    define("EX_COUNTRY_BUTTON", "Países receptores");
    define("EX_COUNTRY_DESC", "Exportar todos los países de la campaña actual.");
    define("EX_CITY_BUTTON", "Ciudades destinatarias");
    define("EX_CITY_DESC", "Exportar todas las ciudades de la campaña actual.");
    define("EX_BROWSER_BUTTON", "Navegadores de destinatarios");
    define("EX_BROWSER_DESC", "Exportar todos los navegadores de campaña actual.");
    define("SETTINGS_CHARSET", "Configure su conjunto de caracteres para la exportación de datos");
    define("MENU_BULK", "Verificaciones a granel");
    define("B_CONFIRM", "confirmar la eliminación masiva de emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Actualizar destinatarios. Si se importa una dirección de correo electrónico en la base de datos, actualícela utilizando los datos en el archivo CSV.");
    define("TAGS_MANAGER_TITLE", "Administrador de etiquetas de destinatarios, correos electrónicos seleccionados: ");
    define("TAGS_SELECT_ACTION", "Elige tu acción:");
    define("TAGS_MANAGER_ADD", "Agregar etiquetas a los destinatarios seleccionados");
    define("TAGS_MANAGER_REMOVE", "Eliminar etiquetas de destinatarios seleccionados");
    define("TAGS_SELECT", "Selecciona tus etiquetas:");
    define("SAVE_CHANGES", "Guardar cambios");
    define("NOT_SELECTED_TAGS", "Seleccione los destinatarios primero");
    define("TM_BUTTON", "Administrador de etiquetas masivas");
    define("WAITING", "esperando...");
    define("MULTI_SMTP", "Multi SMTP");
    define("MULTI_CHECK_DESC", "marca, si quieres usar la función de envío multi smtp");
    define("MULTI_CHOOSE", "Elige servidores smtp");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Lista negra");
    define("BL1", "Lista de dominios no permitidos e IP");
    define("BL2", "bloqueó las direcciones maliciosas para la suscripción");
    define("BL3", "Tu lista negra");
    define("B_VALUE", "Valor");
    define("B_TYPE", "Tipo");
    define("MENU_ADD_BL", "Agregar nueva entrada");
    define("B_DOMAIN", "dominio");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "Puede importar una lista de direcciones maliciosas a su lista negra aquí <small>(cada registro debe estar en línea separada)</small>");
    define("B_DELETE_ALL", "Borrar lista negra");
    define("B_DELETE_QUESTION", "¿Estás seguro de que quieres eliminar toda la lista negra?");
    define("B_EXPORT", "Exportar lista negra");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM ajustes");
    define("DKIM_USE", "utilizar DKIM");
    define("DKIM_DOMAIN", "Firma de nombre de dominio");
    define("DKIM_PRIVATE", "Ruta del archivo de clave privada");
    define("DKIM_SELECTOR", "Por lo general, la configuración de la tecla de selección en su registro TXT de DNS");
    define("DKIM_PASS", "Se usa si su clave está encriptada");
    define("DKIM_IDENTITY", "Por lo general, la dirección de correo electrónico utilizada como fuente del correo electrónico");
    
    define("ERROR", "Error:");
    define("WARNING", "ADVERTENCIA!");
    define("D_MODE", "Los cambios y algunas funciones no están disponibles en el modo DEMO.");
    define("S_DIS", "Envío desactivado hasta que ingrese su código de compra");
    define("HERE", "aquí");
    define("PLIK", "expediente");
    define("NOT_WR", "no se puede escribir. La configuración no se guardará. Cambiar los permisos de archivo antes de guardar.");
    define("EPC", "Código de compra de Envato");
    define("EVALIDEPC", "Ingrese un código de compra válido");
    define("NO_ADMIN_MAIL", "Primero actualice la dirección de correo electrónico del administrador en la configuración.");
    
    define("SMTP_LABEL", "nivel de depuración");
    define("SMTP_0", "Deshabilitar la depuración");
    define("SMTP_1", "Mensajes de salida enviados por el cliente");
    define("SMTP_2", "como 1, más las respuestas recibidas del servidor (esta es la configuración más útil)");
    define("SMTP_3", "como 2, además de más información sobre la conexión inicial; este nivel puede ayudar a diagnosticar fallas de STARTTLS");
    define("SMTP_4", "como 3, más incluso información de nivel inferior, muy detallada, no se usa para depurar SMTP, solo problemas de bajo nivel ");
    
    define("SMTP_SENDER_FORCE", "Forzar siempre este remitente en campañas para este servidor");
    define("SMTP_SENDER_MAIL", "Dirección de correo electrónico del remitente");
    define("SMTP_SENDER_DESCRIPTION", "Descripción del remitente");

    
    
