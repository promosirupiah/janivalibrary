<?php
	/*login page*/
	define("LANG","hi_IN");
	define("LOGIN_TITLE","डाक व्यवस्था");
	define("LOGIN_SIGN_IN","कृपया साइन इन करें");
	define("LOGIN","लॉग इन करें");
	define("LOGIN_PASS","पासवर्ड");
	define("LOGIN_SIGN_IN_BUTTON","साइन इन करें");
	define("LOGIN_FAILED","गलत लॉगिन और / या पासवर्ड!");
	define("INSTALLING_SYSTEM","प्रणाली विन्यास");
	define("INSTALLING_CONNECTED","सही तरीके से डेटाबेस से जुड़ा");
	define("INSTALLING_ADD_TABLES","टेबल जोड़े");
	define("INSTALLING_ADD_TABLES_DESC","टेबल जोड़ने के लिए यहाँ क्लिक करें और सिस्टम के साथ काम शुरू");
	
	/*left menu*/
	define("WELCOME","स्वागत हे,");
	define("WELCOME_ASK","हम क्या करते हैं?");
	define("MAIN_MENU","मुख्य मेनू");
	define("START","प्रारंभ");
	define("DASHBOARD","डैशबोर्ड");
	define("EMAIL_ADRESSES","ईमेल पता");
	define("MENU_RECIPIENT_LIST","प्राप्तकर्ता सूची");
	define("MENU_ADD_RECIPIENT","प्राप्तकर्ता को जोड़ें");
	define("MENU_CSV_IMPORT","एक सीएसवी फ़ाइल से आयात ईमेल");
	define("MENU_CSV_EXPORT","निर्यात ईमेल सीएसवी फाइल करने के लिए");
	define("MENU_TAG_LIST","टैग सूची");
	define("MENU_ADD_TAGS","टैग लगा दो");
	define("MENU_SENDERS_LIST","प्रेषक सूची");
	define("MENU_ADD_SENDER","इस जोड़े");
	define("MENU_TEMPLATES","ईमेल लेआउट");
	define("MENU_TEMPLATES_LIST","टेम्पलेट्स सूची");
	define("MENU_TEMPLATES_ADD","नई टेम्पलेट जोड़ें");
	define("MENU_TEMPLATES_ATTACHMENTS","संलग्नक");
    define("MENU_TEMPLATES_THUMBNAILS","थम्बनेल");
	define("MENU_CAMPAIGNS","आपका अभियान");
	define("MENU_CAMPAIGNS_ADD","नया अभियान तैयार");
	define("MENU_CAMPAIGNS_WAITING_LIST","प्रतीक्षा सूची अभियान");
	define("MENU_CAMPAIGNS_IN_PROGRESS","प्रगति में अभियान");
	define("MENU_CAMPAIGNS_SENT","सूची भेजी अभियान");
	define("MENU_SYSTEM_CONFIGURATION","प्रणाली विन्यास");
	define("MENU_SETTINGS","सेटिंग्स");
	define("MENU_LOGIN","लॉग इन करें");
	define("MENU_DB","डेटाबेस");
	define("MENU_SYSTEM_PARAMS","प्रणाली पैरामीटर");
	define("MENU_SPECIALS","विशेष लाभ विकल्प");
	define("MENU_ADDONS","उपयोगी एक्स्ट्रा कलाकार");
	define("MENU_CLEAR_DB","डेटाबेस साफ");
	define("MENU_IMPORT_TEMPLATES","आयात नमूना टेम्पलेट्स");
	define("MENU_IMPORT_DATA","आयात नमूना डेटा");
	define("MENU_FAQ","क्यू एंड ए");
	define("MENU_ABOUT","के बारे में");
    define("MENU_SMTP_PARAMS","एसएमटीपी विन्यास");
    define("MENU_UNSUBSCRIBED","सूची छुट्टी दे दी");
    define("MENU_UNSUBSCRIBED_LIST","प्राप्तकर्ताओं की सूची");
    define("MENU_DOCS","प्रलेखन");
    define("MENU_SUBSCRIBE_WIDGET","विजेट सदस्यता लें");
    define("MENU_BOUNCED","चेक बाउंस मेल");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","ईमेल डेटा बेस");
	define("D_EMAIL_ADD_NEW","नई ईमेल जोड़ें");
	define("D_EMAIL_TEMPLATES","ईमेल टेम्पलेट्स");
	define("D_EMAIL_TEMPLATES_ADD","नई टेम्पलेट जोड़ें");
	define("D_EMAIL_SENT","भेजे गए ईमेल");
	define("D_EMAIL_EFFICIENCY","दक्षता");
	define("D_EMAIL_UNSUBSCIBERS","सदस्यता रद्द");
	define("D_CAMPAIGNS","अभियान");
	define("D_CAMPAIGNS_ADD","नया अभियान");
	define("D_CAMPAIGNS_WAITING","भेजने के लिए तैयार");
	define("D_CAMPAIGNS_SENT","पूरा कर लिया है");
	define("D_STATISTICS","सांख्यिकी");
	define("D_THIS_YEAR","अपने विज्ञापन अभियानों में इस वर्ष");
	define("D_CHECK_ALL","सभी की जांच करो...");
	define("JAN","जनवरी");
	define("FEB","फ़रवरी");
	define("MAR","मार्च");
	define("APR","अप्रैल");
	define("MAY","मई");
	define("JUN","जून");
	define("JUL","जुलाई");
	define("AUG","अगस्त");
	define("SEP","सितंबर");
	define("OCT","अक्टूबर");
	define("NOV","नवंबर");
	define("DEC","दिसंबर");
	define("D_PREPARED_OVERALL","तैयार अभियान");
	define("D_SENT_OVERALL","भेज दिया");
	define("D_HOW_TO","यह काम किस प्रकार करता है?");
	define("D_HOW_STEP_1_TITLE","1. ईमेल डेटा बेस");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>टैग लगा दो</a> इस में मदद मिलेगी आप ग्राहकों को खोजने के लिए और मदद से आप आसानी से एक विज्ञापन अभियान तैयार. अगला <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>ईमेल जोड़ने</a> अपने डेटाबेस प्रणाली के लिए. आप भी कर सकते हैं <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>सीएसवी फाइल अपलोड</a> अपने डेटा बेस के लिए ईमेल के साथ.");
	define("D_HOW_STEP_2_TITLE","2. प्रेषक");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>इस जोड़े</a> आप में से जिसे अपने ग्राहकों को एक ईमेल प्राप्त होगा तय कर सकते हैं.");
	define("D_HOW_STEP_3_TITLE","3. ईमेल टेम्पलेट्स");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>टेम्पलेट जोड़ें</a> अनुलग्नकों के असीमित संख्या के साथ, टेम्पलेट्स के एक असीमित संख्या में तैयार.");
	define("D_HOW_STEP_4_TITLE","4. विज्ञापन अभियान");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>नया अभियान जोड़े</a> असीमित अभियान तैयार. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>अभियान भेजें</a> किसी भी समय.");
	define("D_HOW_STEP_5_TITLE","5. आँकड़ों का पालन करें");
	define("D_HOW_STEP_5_DESC","यहाँ आप जो अभियान सर्वोत्तम, कैसे और सीखना होगा जब अभियान तैयार किया गया था और कितना भेज दिया जाता है और क्या उनकी प्रभावकारिता है (यानी कि कितने लोगों को अपने ई-मेल खोला और कितने लोगों को अभियान से खुद को नष्ट कर दिया).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","लॉग इन बदलें");
	define("CHANGE_PASS","पासवर्ड बदलें");
	define("CLEAR_DATABASE","डेटाबेस साफ");
	define("LOGOUT","बंद करना");
	define("ABOUT","के बारे में");
	
	/*vertical buttons*/
	define("CONFIG","विन्यास");
	define("CONFIG_TOOLTIP","प्रणाली विन्यास");
	define("MEDIA_MANAGER","संलग्नक प्रबंधक");
	define("RECIPIENT","प्राप्तकर्ताओं");
	define("RECIPIENT_TOOLTIP","ईमेल प्रबंधन");
	define("RECIPIENT_EDIT","विवरण को संशोधित");
	define("RECIPIENT_ADD_NEW","नया जोड़ें");
	define("MENUS","मेनू प्रबंधन");
	define("MENUS_TOOLTIP","मेनू विन्यास");
	define("TEMPLATES","लेआउट");
	define("TEMPLATES_TOOLTIP","लेआउट विन्यास");
	define("HELP","मदद");
	define("HELP_TOOLTIP","यह काम किस प्रकार करता है");
	
	define("FILE_MANAGEMENT","कुर्की की");
	define("CSV_IMPORT","सीएसवी फाइल ईमेल आयात");
	
	define("PERSON","व्यक्ति");
	define("EMAIL","मेलिंग ई-मेल");
	define("TAGS","टैग");
	define("TAGS_LIST","टैग सूची");
	define("TAGS_ADD","नए टैग जोड़ें");
	define("TAGS_ADD_NEW","उनका कहना है टैग");
	define("TAGS_ADD_EDIT","टैग संस्करण");
	define("TAGS_NAME","टैग नाम");
	define("TAGS_DESCRIPTION","विवरण");
	define("TAGS_NAME_PLACEHOLDER","टैग नाम दर्ज...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","टैग विवरण दर्ज...");
	define("TAGS_USED","प्रयुक्त (बार)");
	define("TAGS_INFO","एक ईमेल के लिए टैग");
	
	define("RECIPIENT_LIST","मेलिंग सूची");
	define("RECIPIENT_NAME","प्राप्तकर्ता का नाम");
	define("RECIPIENT_NAME_PLACEHOLDER","पूरा नाम दर्ज करें");
	define("RECIPIENT_MAIL","ईमेल");
	define("RECIPIENT_MAIL_PLACEHOLDER","ईमेल दर्ज करें");
	define("RECIPIENT_ONLY_TXT","केवल TXT ईमेल");
	define("RECIPIENT_DESCRIPTION","विवरण");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","विवरण...");
	define("RECIPIENT_DB","आपका ईमेल डेटा बेस");
	define("RECIPIENT_DETAILS_EDIT","प्राप्तकर्ता विवरण संपादित");
	define("RECIPIENT_DETAILS_ADD","नया ईमेल पता जोड़ना");
	define("RECIPIENT_IMPORT_CSV","सीएसवी फ़ाइल से आयात ईमेल");
	define("RECIPIENT_PREPARE_CSV","एक सीएसवी निम्नलिखित लाइनों फाइल तैयार");
	define("RECIPIENT_UPLOAD_CSV_TITLE","जोड़ने के लिए नया रिकॉर्ड एक Excel फ़ाइल आप नीचे दिए गए चरणों का पालन करना चाहिए फार्म");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","डाउनलोड सीएसवी टेम्पलेट");

	define("RECIPIENT_UPLOAD_CSV_NAME","आयात सीएसवी फाइल");
	define("RECIPIENT_NOT_CSV","<b>यह एक सीएसवी फ़ाइल नहीं है!!!</b><br/>");
	define("RECIPIENT_ROW","पंक्ति ");
	define("RECIPIENT_WRONG_EMAIL"," - गलत ई-मेल पते में प्रवेश किया: ");
	define("RECIPIENT_EMAIL_EXIST"," - इस पते डेटाबेस में पहले से ही है: ");
	define("RECIPIENT_EMAIL_LACK"," - एक ईमेल पते की कमी");
	define("RECIPIENT_EMAIL_IN_DB"," - इस ईमेल पता पहले से ही पंक्ति में सीएसवी फाइल में मौजूद ");
	define("RECIPIENT_TAG_NOT_EXIST"," - ऐसे में कोई टैग: ");
	define("RECIPIENT_CSV_ERRORS","फ़ाइल में त्रुटियाँ ");
	define("RECIPIENT_CSV_ADDED","जोड़ा ");
	define("RECIPIENT_CSV_ADDED_FROM"," फ़ाइल से ईमेल पते ");
	define("RECIPIENT_CSV_EXPORT","एक फ़ाइल में निर्यात ईमेल पतों");
	define("RECIPIENT_CSV_EXPORT_CHK","निर्यात करने के लिए क्षेत्रों का चयन करें:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","प्राप्तकर्ता का ई - मेल पता");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","पहला नाम और अंतिम नाम");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","टैग - एक ही जगह से अलग");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","टिप्पणियाँ");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","पाठ केवल ईमेल प्राप्त");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","शुरूआत की तिथि");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","संशोधन की तिथि");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","निर्यात");
	define("RECIPIENT_CSV_IGNORE_ERRORS","ध्यान न दें सीएसवी त्रुटियों की जाँच (यह जाँच अगर फाइल के 1000 से अधिक ईमेल शामिल हैं - बड़ी फ़ाइलों को सर्वर पर स्मृति की एक बड़ी राशि की आवश्यकता होती है)");
	
	define("SAVE","बचाना");
	define("CANCEL","रद्द करना");
	define("DELETE","मिटाना");
    define("EDIT","संपादित करें");
	define("CREATED","बनाया था");
	define("MODIFIED","संशोधित");
	define("SEND","भेजना");
	define("SENT","भेज दिया");
	define("PROGRESS","प्रगति");
	define("RESUME","बायोडाटा");
	define("CLOSE","बंद करे");
	define("CHANGES_SAVED","परिवर्तन सफलतापूर्वक किए गए थे");
	
	define("DELETING","हटाना");
	define("DELETING_CONFIRM_QUESTION","क्या आप सचमुच हटाना चाहते हैं?");
	
	define("DATATABLE_LENGTHMENU", "प्रति पृष्ठ प्रदर्शित _MENU_ रिकॉर्ड");
	define("DATATABLE_ZERORECORDS", "कुछ भी नहीं मिला - माफ");
	define("DATATABLE_INFO", "_PAGES_ के पेज _PAGE_ दिखा");
	define("DATATABLE_INFOEMPTY", "कोई रिकॉर्ड उपलब्ध");
	define("DATATABLE_INFOFILTERED", "(_MAX_ कुल अभिलेख से फ़िल्टर _TOTAL_)");
	define("DATATABLE_SEARCH", "खोज");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "नई टेम्पलेट जोड़ें");
	define("TEMPLATES_LIST", "टेम्पलेट्स सूची");
	define("TEMPLATES_TITLE", "उपलब्ध टेम्पलेट्स");
	define("TEMPLATES_TITLE_ADD", "नए लेआउट जोड़े");
	define("TEMPLATES_TITLE_EDIT", "लेआउट संपादन");
	define("TEMPLATES_NAME", "लेआउट नाम");
	define("TEMPLATES_MAIL_TITLE", "ईमेल खिताब");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "ईमेल शीर्षक दर्ज");
	define("TMPLATES_HTML", "HTML संस्करण");
	define("TMPLATES_TXT", "TXT संस्करण");
	define("TMPLATES_VARIABLES", "उपलब्ध टेम्पलेट चर (चेक <a href='docs/index.html#variables' target='_blank'>docs</a> ब्योरा हेतु):");
	define("TEMPLATES_THUMB", "थंबनेल");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "थंबनेल संपादन");
	define("THUMBNAIL_MEDIA_LIST", "उपलब्ध थंबनेल सूची");
	
	define("MEDIA_FILENAME", "फ़ाइल का नाम");
	define("MEDIA_FILENAME_DESCRIPTION", "फाइल विवरण");
	define("MEDIA_FILENAME_UPLOAD_TIME", "अपलोड समय");
	define("MEDIA_TEMPLATES", "एक अनुलग्नक के रूप में प्रयुक्त");
	define("MEDIA_LIST", "उपलब्ध लगाव सूची");
	define("MEDIA_ADD_FILES", "फाइलें जोड़ो");
	define("MEDIA_BROWSE", "ब्राउज");
	define("MEDIA_UPLOAD", "अपलोड");
	
	define("CAMPAIGN_MENU", "नया अभियान");
	define("CAMPAIGN_PREPARE", "अभियान तैयार");
	define("CAMPAIGN_RECIPIENTS", "प्राप्तकर्ताओं चुनें");
	define("CAMPAIGN_TEMPLATES", "लेआउट चुनें");
	define("CAMPAIGN_SENDERS", "इस चुनें");
	define("CAMPAIGN_CONFIRM", "अभियान सहेजें");
	define("CAMPAIGN_SEND", "अभियान भेजें");
	define("CAMPAIGN_NAME", "अभियान का नाम");
	define("CAMPAIGN_NAME_PLACEHOLDER", "अभियान का नाम दर्ज");
	define("CAMPAIGN_RECIPIENT_QTY", "प्राप्तकर्ताओं");
	define("CAMPAIGN_TEMPLATE_NAME", "ख़ाका");
	define("CAMPAIGN_SENDER", "प्रेषक");
	define("CAMPAIGN_CREATED_DATE", "तैयार");
	define("CAMPAIGN_STEP_1", "1. अपने प्राप्तकर्ताओं (प्रयोग 'खोज' टेबल पर क्षेत्र) का चयन करें");
	define("CAMPAIGN_STEP_2", "2. अपने अभियान को सहेजें");
	define("CAMPAIGN_SELECT", "डाक के लिए अभियान का चयन");
	define("CAMPAIGN_FORM_SELECT", "चुनते हैं...");
	define("CAMPAIGN_CURRENT_STATUS", "वर्तमान अभियान की स्थिति");
	define("CAMPAIGN_SENT_NOW", "यह अब भेजें");
	define("CAMPAIGN_SENT_BUTTON", "भेजने शुरू करने के लिए यहाँ क्लिक करें");
	define("CAMPAIGN_RESUME_BUTTON", "भेजने के लिए फिर से शुरू करने के लिए यहाँ क्लिक करें");
	define("CAMPAIGN_SERVER_CONNECTING", "सर्वर से कनेक्ट, कृपया प्रतीक्षा करें...");
	define("CAMPAIGN_SENDING", "भेजना");
	define("CAMPAIGN_PLEASE_WAIT", "कृपया प्रतीक्षा करें...");
	define("CAMPAIGN_SENT", "<b>अभियान भेजा</b> प्राप्तकर्ताओं: ");
	define("CAMPAIGN_IN_PROGRESS", "प्रगति में अभियान...");
	define("CAMPAIGN_COMPLETED", "भेजा अभियान");
	define("CAMPAIGN_LEFT", "भेजने के लिए वाम");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "सभी नष्ट कर दिया मिटाएं");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "यह क्रिया सभी अपने डेटाबेस से हटा नष्ट करेगा.");
	define("CAMPAIGN_BG_PROCESS", "पृष्ठभूमि प्रक्रिया");
	define("CAMPAIGN_BG_PROCESS_INFO", "एक पृष्ठभूमि प्रक्रिया के रूप में भेजें (आप ब्राउज़र बंद कर सकते हैं)");
	define("CAMPAIGN_WHEN_FINISH", "ईमेल जब समाप्त");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "जहां सूचना भेजने के लिए");
	define("CAMPAIGN_BG_CONFIRM_TXT", "भेजने के पृष्ठभूमि की पुष्टि करें!");
    
    define("HOUR", "समय");
    define("OPENS", "खुलती");
    define("BOUNCED", "बाउंस");
    define("CLICKED", "क्लिक किया");
    define("UNIQUE_CLICKS", "विशिष्ट क्लिक");
    define("TOTAL_CLICKS", "कुल क्लिक");
	
	define("SENDER_LIST", "प्रेषक सूची");
	define("SENDER_ADD", "इस जोड़े");
	define("SENDER_NAME", "भेजने वाले का नाम");
	define("SENDER_NAME_PLACEHOLDER", "प्रेषक का नाम दर्ज");
	define("SENDER_EMAIL", "भेजने वाले ईमेल");
	define("SENDER_EMAIL_PLACEHOLDER", "इस ईमेल दर्ज");
	define("SENDER_TITLE_ADD", "इस जोड़े");
	define("SENDER_TITLE_EDIT", "इस संपादित");
	define("SENDER_EMAIL_TITLE", "भेजने वाले ईमेल पता");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "इस ईमेल पता दर्ज करें");
	
	define("SETTINGS", "सेटिंग्स");
	define("SETTINGS_LOGIN_TITLE", "नई क्रेडेंशियल दर्ज करें");
	define("SETTINGS_LOGIN_LABEL", "नई लॉगिन दर्ज");
	define("SETTINGS_LOGIN_PLACEHOLDER", "लॉगिन दर्ज");
	define("SETTINGS_CURR_PASS", "वर्तमान पासवर्ड");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "पास वर्ड दर्ज करें");
	define("SETTINGS_NEW_PASS", "नया पासवर्ड");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "नया पासवर्ड");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "पुष्टि करें");
	define("SETTINGS_DB_PARAMS", "सेटअप डेटाबेस");
	define("SETTINGS_DB_HOST", "डाटाबेस मेजबान");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "पूर्व।: localhost");
	define("SETTINGS_DB_USER", "डेटाबेस उपयोगकर्ता");
	define("SETTINGS_DB_USER_PLACEHOLDER", "पूर्व।: root");
	define("SETTINGS_DB_PASSWORD", "डेटाबेस पासवर्ड");
	define("SETTINGS_DB_NAME", "डेटाबेस का नाम");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "पूर्व।: mailing");
	define("SETTINGS_GLOBAL", "वैश्विक व्यवस्था");
	define("SETTINGS_LANG", "सिस्टम की भाषा");
	define("SETTINGS_LIMIT", "प्रति घंटे सेटअप ईमेल सीमा नहीं");
	define("SETTINGS_LIMIT_PLACEHOLDER", "चूक: 1000");
	define("SETTINGS_TRACKING", "ईमेल ट्रैकिंग सक्षम करें");
	define("SENDING_METHOD", "भेजा जा रहा है विधि");
	define("SETTINGS_UNSUBSCRIBED", "ऑटो नष्ट कर दिया हटाना");
	define("SETTINGS_UNS_INFO", "ईमेल स्वचालित रूप से प्राप्तकर्ता सूची से हटा दिया जाएगा उपयोगकर्ता अपने हटाने लिंक पर क्लिक करें जब");
	define("SETTINGS_TRACK_INFO", "अदृश्य आइएमजी टैग अपने प्राप्तकर्ता को ट्रैक करने के लिए जोड़ दिया जाएगा");
	define("SETTINGS_API_LABEL", "Google नक्शे<br>API कुंजी");
	define("SETTINGS_API_PLACEHOLDER", "यहाँ अपने गूगल मैप्स एपीआई v.3 कुंजी दर्ज");
	define("SETTINGS_API_LINK_INFO", "नई एपीआई कुंजी प्राप्त करने के लिए यहां क्लिक करें");
	define("SETTINGS_ADMIN_MAIL", "व्यवस्थापक ईमेल");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "सिस्टम सूचनाओं के लिए व्यवस्थापक ईमेल");
    define("SETTINGS_PHP_TIMEOUT", "PHP समय समाप्त (सेकंड)");
    
	define("SMTP_SERVER_DESCRIPTION", "SMTP सर्वर, कुछ जोड़ने के लिए सुनिश्चित हो");
    define("SMTP_LIST", "सर्वर सूची");
    define("SMTP_ADD", "नए सर्वर जोड़ने");
    define("SMTP_EDIT", "संपादन सर्वर");
    define("SMTP_INFO", "आपका एसएमटीपी सर्वर");
    define("SMTP_ADD_BUTTON", "नई एसएमटीपी सर्वर से जोड़ने के लिए क्लिक करें");
    define("SMTP_NAME", "कनेक्शन नाम");
    define("SMTP_NAME_PLACEHOLDER", "पूर्व।: मेरे सबसे अच्छे संबंध");
    define("SMTP_HOST", "SMTP पता");
    define("SMTP_HOST_PLACEHOLDER", "(';' बैकअप के लिए विभाजक) मुख्य और बैकअप सर्वर");
    define("SMTP_PAUTH", "प्रमाणीकरण");
    define("SMTP_PAUTH_PLACEHOLDER", "एसएमटीपी प्रमाणीकरण सक्षम करें");
    define("SMTP_VERIFY_PEER", "सक्षम करें SSL/TLS प्रमाण पत्र सत्यापन");
    define("SMTP_FORCE_SMTP", "सेना एसएमटीपी उपयोग");
    define("SMTP_USERNAME", "एसएमटीपी उपयोगकर्ता नाम");
    define("SMTP_USERNAME_PLACEHOLDER", "एसएमटीपी उपयोगकर्ता नाम");
    define("SMTP_LOGIN", "एसएमटीपी लॉगिन");
    define("SMTP_LOGIN_PLACEHOLDER", "एसएमटीपी सर्वर लॉग इन");
    define("SMTP_PASSWORD", "एसएमटीपी पासवर्ड");
    define("SMTP_PASSWORD_PLACEHOLDER", "एसएमटीपी पासवर्ड");
    define("SMTP_REPLYTO", "मेल का जवाब दें");
    define("SMTP_REPLYTO_PLACEHOLDER", "एक वैकल्पिक सेट जबाब-पता");
    define("SMTP_REPLYTONAME", "नाम का जवाब दें");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "एक वैकल्पिक जवाब दें नाम सेट");
    define("SMTP_SECURE", "एन्क्रिप्शन");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> डिफ़ॉल्ट एन्क्रिप्शन के रूप में");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> स्वीकार किए जाते हैं, लेकिन अनुशंसित नहीं");
    define("SMTP_PORT", "बंदरगाह");
    define("SMTP_PORT_PLACEHOLDER", "सर्वर पोर्ट");
    define("SMTP_LIMIT", "प्रति घंटे की सीमा");
    define("SMTP_LIMIT_PLACEHOLDER", "चूक: 1000");
    define("CAMPAIGN_SMTP", "एसएमटीपी का चयन");
    define("SMTP_TESTING", "परीक्षण एसएमटीपी कनेक्शन");
    define("SMTP_TESTING_EMAIL", "परीक्षण संदेश के लिए पता");
    define("SMTP_RUN_TEST", "इसे जाँचे!");
    define("SMTP_TEST_TXT_TITLE", "से एसएमटीपी परीक्षण E-mailer.");
    define("SMTP_TEST_TXT_MESSAGE", "आपके एसएमटीपी कनेक्शन से परीक्षण संदेश.");
    define("SMTP_TEST_OK", "संदेश भेजा जा चुका है। अपना मेलबॉक्स जांचें।");
    define("SMTP_TEST_ERROR", "<b>मेलर त्रुटि: </b>");
    define("SMTP_BEFORE_USE", "<b>मेलर त्रुटि.</b> आप उपयोग करने से पहले सेटिंग्स में एसएमटीपी कनेक्शन को सक्षम करने की जरूरत है।");
    define("BOUNCED_INFO", "ईमेल बाउंस कि मेलबॉक्स करने के लिए वापस होगा");
    define("SMTP_CONFIG", "सेटअप भेजने के लिए अपने एसएमटीपी");
    define("IMAP_CONFIG", "सेटअप अपने IMAP / POP3 बाउंस के लिए");
    define("SMTP_INFO_SETUP", "एसएमटीपी सेटिंग्स");
    define("IMAP_INFO_SETUP", "IMAP / POP3 सेटिंग्स");
    define("PROTOCOL", "मसविदा बनाना");
    define("FOLDER", "उपयोग करने के लिए फ़ोल्डर");
	
	define("STATISTICS", "सांख्यिकी");
	define("STATISTICS_ADV", "उन्नत विवरण");
	define("STATISTICS_TAB_MAP", "नक्शे पर प्राप्तकर्ताओं (जियोलोकेशन)");
	define("STATISTICS_TAB_DETAILS", "विस्तृत आँकड़े");
	define("STATISTICS_TAB_ACTIONS", "विशेष कार्रवाई");
	define("STATISTICS_BACK", "दोबारा सूची को जाएं");
	define("STATISTICS_BUTTON_OPENERS", "सलामी बल्लेबाजों के लिए तैयार");
	define("STATISTICS_BUTTON_OPENERS_INFO", "उन सभी जो एक ईमेल खोला के लिए नया अभियान तैयार");
	define("STATISTICS_BUTTON_NOT_OPENERS", "नहीं सलामी बल्लेबाजों के लिए तैयार");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "सब जो लोग नहीं एक ईमेल खोला के लिए नया अभियान तैयार");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "सदस्यता के लिए तैयार");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "सभी अभियान से हटा लिए नया अभियान तैयार - अगर एक विकल्प 'ऑटो हट नष्ट' सिस्टम सेटिंग्स में सक्षम है ईमेल नष्ट कर दिया जाता है और कुछ भी नहीं यहाँ जोड़ दिया जाएगा");
	define("STATISTICS_BUTTON_FILTERS", "उन्नत फिल्टर के साथ तैयार");
	define("STATISTICS_BUTTON_FILTERS_INFO", "एकत्र आंकड़ों के साथ इस अभियान से सभी प्राप्तकर्ताओं की सूची प्राप्त करें और उन्नत फिल्टर के आधार पर नए विशेष अभियान तैयार");
	define("STATISTICS_TOP_COUNTRIES", "शीर्ष 10 देशों");
	define("STATISTICS_TOP_CITIES", "शीर्ष 10 शहरों");
	define("STATISTICS_TOP_CLICKERS", "शीर्ष 15 क्लिक किया");
	define("STATISTICS_TOP_SOFTWARE", "शीर्ष 15 सबसे लोकप्रिय सॉफ्टवेयर");
	define("STATISTICS_OTHER_UA", "सभी दूसरों को उपयोगकर्ता एजेंटों");
	define("STATISTICS_OTHERS", "अन्य लोग");
    
	define("SOFTWARE", "सॉफ्टवेयर");
	define("GEODATA", "स्थानीयकरण");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='पुष्टीकरण'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>समाचार पत्र से सदस्यता सफलतापूर्वक त्यागी.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>आपका दिन शुभ हो।</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "डेटाबेस से अनावश्यक डेटा को हटाने");
	define("ADDONS_IMPORT_TITLE", "मेलिंग नमूना टेम्पलेट्स जोड़ना");
	define("ADDONS_FAQ_TITLE", "पढ़ें से पहले आप से पूछना");
	define("ADDONS_ABOUT_TITLE", "कार्यक्रम और लाइसेंस के बारे में जानकारी");
	define("ADDONS_IMPORT_DATA_TITLE", "व्यवस्था करने के लिए आयात नमूना डेटा");
	define("ADDONS_IMPORT_BUTTON", "आयात ईमेल टेम्पलेट्स");
	define("ADDONS_IMPORT_BUTTON_DESC", "इस मेलिंग के लिए नमूना टेम्पलेट्स आयात करेगा");
	define("ADDONS_IMPORT_CONFIRM_TXT", "डाक के लिए उदाहरण टेम्पलेट्स जोड़ने की पुष्टि");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "व्यवस्था करने के लिए नमूना डेटा जोड़ने की पुष्टि करें। सभी वर्तमान में दर्ज किया गया डेटा मिट जाएगा!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>ऐसा क्यों है कि डाक के लिए अपने समर्पित सर्वर है बेहतर है?</p>
			<p>सबसे पहले, कोई सीमा नहीं। साधारण होस्टिंग के लिए, आप एक दिन के भीतर प्रति घंटे 1,000 ईमेल और शायद एक ही राशि के लिए भेज सकते हैं (होस्टिंग सीमा के आधार पर कुछ हजार ईमेल एक दिन के लिए कुछ सौ से लेकर)। अपने सर्वर पर है, तो आप इस तरह के प्रतिबंध नहीं है और यह भी अपने डोमेन से ईमेल भेजने की क्षमता है। तुम भी रूप में अगर सर्वर एक अलग डोमेन के तहत हो गया था ई-मेल भेज सकते हैं (- विवरण अपने होस्टिंग प्रदाता पूछने के लिए यह इस मामले तथाकथित एसपीएफ रिकॉर्ड और TXT डोमेन सेट में है)।</p>
		</li>
		<li>
			<p>टैग क्या हैं?</p>
			<p>यह आसान डाक पते खोजने के लिए और एक विशिष्ट प्राप्तकर्ताओं पर एक विज्ञापन अभियान तैयार करने के लिए सुनिश्चित करें।</p>
		</li>
		<li>
			<p>कैसे ईमेल टेम्पलेट करने के लिए प्राप्तकर्ता का नाम जोड़ने के लिए?</p>
			<p>सामग्री टेम्पलेट ईमेल में या टेम्पलेट मेल के शीर्षक में वाक्यांश {RECIPIENT_NAME} का प्रयोग करें। मुहावरा है कि जानकारी प्राप्तकर्ता का ईमेल पता करने के लिए जोड़ दिया गया है मामले में, प्राप्तकर्ता ई-मेल के नाम से प्रतिस्थापित किया जाएगा।</p>
		</li>
		<li>
			<p>कैसे एक नया अनुवाद जोड़ने के लिए?</p>
			<p>फ़ाइल संदर्भ english.php कॉपी, यह एक ऐसा नाम है जो उदाहरण mylanguage.php के लिए अपनी भाषा का वर्णन देने के लिए और एक ही फ़ोल्डर में पेस्ट करें। सभी ग्रंथों नई फ़ाइल में निहित सही। बीओएम बिना UTF-8 में फाइल को बचाने के लिए सुनिश्चित करें। भाषा फाइल निर्देशिका में है 'languages'.</p>
			<p>संपादक का अनुवाद जोड़ने के लिए, पर जाएँ https://www.tinymce.com/download/language-packages/ - उपयुक्त फ़ाइल भाषा डाउनलोड करने और इसे बचाने में /emailer/libs/tinymce/langs/ फ़ोल्डर.</p>
		</li>
		<li>
			<p>कैसे मैं एक ई मेल करने के लिए टैग जोड़ सकता हूँ?</p>
			<p>सबसे पहले, आप कुछ ही टैग जोड़ने की जरूरत <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>इस प्रपत्र का उपयोग</a>। तो जब आप जोड़ने / प्रत्येक ईमेल पते को किसी भी टैग को सौंपा जा सकता संपादित करें। सभी टैग प्राप्तकर्ताओं / संपादित जोड़ने के लिए फार्म नीचे जोड़ दिया जाएगा।</p>
		</li>
		<li>
			<p>कैसे संदेशों को प्राप्त करने के लिए बाहर से सदस्यता समाप्त करने की क्षमता जोड़ने के लिए?</p>
			<p>ईमेल टेम्पलेट सामग्री में कड़ी में वाक्यांश {UNSUBSCRIBE} का प्रयोग करें। वाक्यांश प्राप्तकर्ता के लिए एक लिंक के साथ प्रतिस्थापित किया जाएगा। वह / वह इसे क्लिक करेंगे, जब सिस्टम अभियान के निर्वहन के बारे में डेटाबेस जानकारी में बचत होगी। ईमेल पते डेटाबेस से नहीं हटाया जाएगा। <br>उपयोग:<br>&lt;a href='{UNSUBSCRIBE}'&gt;समाचार पत्र से सदस्यता समाप्त&lt;/a&gt;</p>
		</li>
		<li>
			<p>कैसे ब्राउज़र को देखने की क्षमता जोड़ने के लिए?</p>
			<p>ईमेल टेम्पलेट सामग्री में कड़ी में वाक्यांश {BROWSER_VIEW} का प्रयोग करें। वाक्यांश प्राप्तकर्ता के लिए एक लिंक के साथ प्रतिस्थापित किया जाएगा। वह / वह इसे क्लिक करेंगे, जब सिस्टम ब्राउज़र विंडो में संदेश खुल जाएगा। <br>प्रयोग:<br>&lt;a href='{BROWSER_VIEW}'&gt;ब्राउज़र देखें&lt;/a&gt;</p>
		</li>
		<li>
			<p>कैसे पूर्वनिर्धारित ईमेल टेम्पलेट्स जोड़ने के लिए?</p>
			<p>30 नमूना टेम्पलेट्स मेलिंग, यहाँ क्लिक करें <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>टेम्पलेट्स जोड़ने के लिए</a></p>
		</li>
		<li>
			<p>कैसे मैं ई-मेल के लिए छवियों को जोड़ सकता हूँ?</p>
			<p>- जैसे बाहरी संसाधनों में एक छवि के लिए एक निरपेक्ष कड़ी के रूप में:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>कैसे ईमेल के ट्रैकिंग करता है?</p>
			<p>प्रत्येक भेजे गए ईमेल प्रणाली एक छवि टैग आइएमजी, जो विशेषता एसआरसी एक विशेष संदेश प्रदर्शित करने के लिए ट्रैकिंग कोड है जोड़ सकते हैं। ट्रैकिंग ही काम करेंगे जब मेल प्राप्तकर्ता प्राप्त संदेश की छवियों को दिखाने के लिए सहमत हैं।</p>
		</li>
		<li>
			<p>कैसे नहीं एक स्पैमर हो सकता है?</p>
			<p>- जब एक मेलिंग सूची बनाने के संदेशों को प्राप्त करने के लिए सहमति ले लीजिए।</p>
			<p>- प्रत्येक प्राप्तकर्ता के लिए सामग्री की एक किस्म का प्रयोग करें, पूर्व का उपयोग करें। {RECIPIENT_NAME} अपनी मेलिंग की जांच रकम अंतर करने के लिए।</p>
			<p>- सेक्स, वियाग्रा, अश्लील: जैसे खोजशब्दों का प्रयोग न करें।</p>
			<p>- जैसे कुंजी वाक्यांशों का उपयोग न करें: एक सार्वजनिक डेटाबेस से पता, यह ध्यान में वाणिज्यिक सूचना, रुचि खेद नहीं है, यह अर्थ के भीतर एक प्रस्ताव का गठन नहीं करता है, अगर आप नहीं चाहते हैं, सदस्यता समाप्त करने के लिए, मुक्त, विशेष पेशकश यहाँ क्लिक करें, अब इसे खरीदने के लिए - आप उन्हें ग्राफिक्स के रूप में डाल करने पर विचार करना चाहिए कि आप इस तरह के वाक्यांशों का उपयोग करने के लिए है।</p>
			<p>- बहुत से ग्राफिक्स का उपयोग न करें, स्पैम फिल्टर पाठ करने के लिए ग्राफिक्स के अनुपात की जांच।</p>
			<p>- मेल भी भारी नहीं होना चाहिए।</p>
			<p>- कम बेहतर संलग्नक।</p>
			<p>- अन्य डोमेन धारण न करें।</p>
			<p>- न के बराबर ईमेल पते से ईमेल भेजने मत करो।</p>
		</li>
		<li>
			<p>कैसे बढ़ाने के लिए और क्लिक के अभियान पढ़ता करने के लिए?</p>
			<p>सामग्री है कि आप अपने ग्राहकों के लिए और समय और आवृत्ति जिसके साथ आप यह करने के लिए भेजने पर सबसे बड़ा प्रभाव है। ज्यादातर मामलों में, संपर्क के लिए दो बार एक महीने से भी अधिक लगातार नहीं होना चाहिए। अपने ग्राहकों का सम्मान और वे स्पैम के लिए आप फेंक नहीं होगा।</p>
		</li>
		<li>
			<p>कैसे मेलिंग के लिए पतों चुनने के लिए?</p>
			<p>टैग का प्रयोग, प्रकार उन्हें पतों की तालिका के ऊपर स्थित खोज के क्षेत्र में रिक्त स्थान से अलग कर दिया।</p>
		</li>
		<li>
			<p>इस प्रणाली की सीमाएं क्या हैं?</p>
			<p>वहाँ कोई प्रतिबंध नहीं है।</p>
		</li>
		<li>
			<p>सर्वर होस्टिंग पर संदेशों की सीमा?</p>
			<p>होस्टिंग सीमा पर निर्भर करता है कि कुछ हजार ईमेल एक दिन के लिए कुछ सौ से, अपने सेवा प्रदाता के साथ जांच को लेकर।</p>
		</li>
		<li>
			<p>टूटी कनेक्शन जब अभियान भेजने?</p>
			<p>आप अभियानों के भेजने को फिर से शुरू कर सकते हैं, ईमेल अन्य प्राप्तकर्ताओं के लिए भेजा जाएगा। प्रत्येक भेजे गए ईमेल डेटाबेस में एक अनूठी मार्कर सेट और अभियान में ही एक ही प्राप्तकर्ता को फिर से नहीं भेजा जाएगा।</p>
		</li>
		<li>
			<p>ईमेल बाउंस के लिए आवश्यकताएँ</p>
			<p>ईमेल बाउंस आप php.ini फ़ाइल में इस लाइन टिप्पणी नहीं करना है के लिए समर्थन सक्षम करने के लिए।</p>
			<p>;extension=php_imap.dll</p>
			<p>Imap कार्यों का उपयोग करने की आवश्यकता हैPOP3 / IMAP कनेक्शन.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "ध्यान रहें, डेटाबेस में निम्न क्रियाओं स्वच्छ टेबल!");
	define("ADDONS_DATA_BE_CAREFULLY", "चेतावनी! सभी डेटा को नष्ट कर दिया और नमूना डेटा के साथ प्रतिस्थापित किया जाएगा");
	define("ADDONS_D_AL", "सभी डेटा हटाएं");
	define("ADDONS_D_AL_DESC", "डेटाबेस में सभी डेटा मिटाता");
	define("ADDONS_D_AL_CONF", "आप डेटाबेस से सभी डेटा निकालना चाहते हैं, आप सुनिश्चित हैं? सभी ईमेल पतों, टेम्पलेट्स, संलग्नक और अभियानों को हटा दिया जाएगा।");
	define("ADDONS_D_RE", "प्राप्तकर्ताओं और उनके अभियानों को हटाये");
	define("ADDONS_D_RE_DESC", "डेटाबेस में सभी ई-मेल पते और विज्ञापन अभियानों के इतिहास को हटाता है");
	define("ADDONS_D_RE_CONF", "सभी प्राप्तकर्ताओं के निष्कासन की पुष्टि");
	define("ADDONS_D_CA", "केवल अभियानों को हटाएँ");
	define("ADDONS_D_CA_DESC", "सभी विज्ञापन अभियानों और उनके इतिहास को हटाता है");
	define("ADDONS_D_CA_CONF", "सभी अभियानों और उनके इतिहास के निष्कासन की पुष्टि");
	define("ADDONS_D_TE", "केवल टेम्पलेट्स हटाये");
	define("ADDONS_D_TE_DESC", "अभियान और अनुलग्नकों के साथ सभी ईमेल टेम्पलेट्स और उनके लिंक हटाता");
	define("ADDONS_D_TE_CONF", "सभी टेम्पलेट्स के हटाए जाने की पुष्टि करें");
	define("ADDONS_D_AT", "केवल अटैचमेंट हटा");
	define("ADDONS_D_AT_DESC", "सभी संलग्नक को हटाता है");
	define("ADDONS_D_AT_CONF", "पुष्टि सभी संलग्नक नष्ट");
	define("ADDONS_D_SE", "केवल प्रेषकों को हटाएँ");
	define("ADDONS_D_SE_DESC", "सभी प्रवेश किया प्रेषकों ईमेल हटाता है लेकिन सांख्यिकीय प्रयोजनों के लिए अपने आईडी पत्ते");
	define("ADDONS_D_SE_CONF", "सभी प्रेषकों के निष्कासन की पुष्टि");
	define("ADDONS_D_TG", "केवल टैग हटाएँ");
	define("ADDONS_D_TG_DESC", "सभी प्रवेश किया टैग और ग्राहकों के साथ अपने संबंधों को साफ़");
	define("ADDONS_D_TG_CONF", "पुष्टि सभी टैग हटा");
    
	define("WIDGET_PREPARE", "अपनी सदस्यता विजेट तैयार");
	define("WIDGET_OPTIONS", "विकल्प");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "यहाँ अपनी सदस्यता विजेट उत्पन्न");
	define("WIDGET_COMMENT", "नई प्राप्तकर्ता के बारे में टिप्पणी");
	define("WIDGET_COMMENT_PLACEHOLDER", "पूर्व।: से domain.ext (प्राप्तकर्ता विवरण में सहेजा जाएगा)");
	define("WIDGET_NAME", "नाम");
	define("WIDGET_NAME_SHOW", "शो प्राप्तकर्ता का नाम क्षेत्र");
	define("WIDGET_AFTER", "बाद सदस्यता विजेट प्रस्तुत");
	define("WIDGET_AFTER_NOTHING", "कुछ मत करो");
	define("WIDGET_AFTER_TXT", "पाठ संदेश दिखाएं");
	define("WIDGET_AFTER_REDIRECT", "पृष्ठ पर पुनर्निर्देशित");
	define("WIDGET_TAGS", "टैग लगा दो");
	define("WIDGET_PURE_CODE_TXT", "शुद्ध एचटीएमएल कोड। आप अपनी आवश्यकताओं के लिए इसे संशोधित कर सकते हैं। कक्षाएं, टैग, विवरण, जो आप चाहते जोड़ें। नीचे दिए गए कोड को कॉपी और इसे अपनी वेबसाइट में पेस्ट करें।");
	define("WIDGET_FULL_CODE_TXT", "पूर्ण संस्करण (सभी क्षेत्रों को शामिल)");
	define("WIDGET_MIN_CODE_TXT", "कम से कम संस्करण (केवल ईमेल शामिल है)");
	define("WIDGET_CODE_DESC_TXT", "पर्चा विवरण");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> अपेक्षित.</li>
        <li>ग्राहक का ईमेल पता।</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> वैकल्पिक।</li>
        <li>ग्राहक का नाम।</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> वैकल्पिक।</li>
        <li>छिपाया गया क्षेत्र।</li>
        <li>वे पहले से ही डेटाबेस में जोड़ा जाना चाहिए।</li>
        <li>वे अल्पविराम के द्वारा अलग किया जाना चाहिए।</li>
        <li>अलग टैग का उपयोग कर आप अलग अलग अभियानों के लिए कर सकते हैं।</li>
        <li>आप अलग अलग साइटों पर एक ही फार्म का उपयोग करें और प्रत्येक साइट पर अलग अलग टैग का उपयोग कर सकते हैं।</li>
        <li>इसका मतलब है कि इस घटक अलग अलग साइटों से ग्राहकों को इकट्ठा करने और अलग टैग के साथ अपने सिस्टम के लिए उन्हें जोड़ सकते हैं।</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> वैकल्पिक।</li>
        <li>छिपाया गया क्षेत्र।</li>
        <li>प्राप्तकर्ता के लिए अपने विवरण जोड़ें।</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> वैकल्पिक।</li>
        <li>छिपाया गया क्षेत्र।</li>
        <li>डबल ऑप्ट में सुविधा सक्षम करें।</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> वैकल्पिक।</li>
        <li>छिपाया गया क्षेत्र।</li>
        <li>कहाँ के बाद अनुप्रेषित करने के लिए सदस्यता लें। तो मैदान खाली है या नहीं के रूप में शामिल है, विन्यस्त कार्रवाई आगे बढ़ना कर दिया जाएगा।</li>
    ");
	define("WIDGET_USE_THIS_CODE", "नीचे दिए गए कोड को कॉपी और इसे अपनी साइट पर पेस्ट");
	define("WIDGET_DBL_OPT_IN", "डबल ऑप्ट में");
	define("WIDGET_DBL_OPT_LABEL", "डबल सदस्यता पुष्टि का उपयोग करने के लिए यह जांच");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "ईमेल संदेश (समर्थन एचटीएमएल)");
	define("WIDGET_DBL_OPT_HELP", "जोड़ने के लिए मत भूलना <b>{CONFIRM_LINK}</b> अपने संदेश में।<br>आप यह भी जोड़ सकते हैं:<br><b>{SUBSCRIBER_EMAIL}</b> - ग्राहक ईमेल पता<br><b>{SUBSCRIBER_NAME}</b> - ग्राहक का नाम<br><b>{SUBSCRIBER_COMMENT}</b> - ग्राहक के बारे में अपनी टिप्पणी<br><b>{SUBSCRIBER_TAGS}</b> - खेतों में टैग<br><b>{CURRENT_YEAR}</b> - वर्तमान साल<br><b>{CURRENT_MONTH}</b> - वर्तमान माह<br><b>{CURRENT_DAY}</b> - वर्तमान दिन");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "ईमेल खिताब");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "ईमेल पुष्टि शीर्षक दर्ज...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "ईमेल पुष्टि संदेश दर्ज...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "पुष्टि के बाद पर रीडायरेक्ट");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "पते की पुष्टि के बाद जहां को दिशानिर्देश देने में प्रवेश");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "पते से भेजें");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "ई-मेल पते से पुष्टि भेज दिया जाएगा दर्ज");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "भेजने वाले का विवरण");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "इस के लिए विवरण दर्ज");
	define("WIDGET_ADMIN_NOTIFY", "नए ग्राहक के बारे में सूचित करें व्यवस्थापक");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "बाद नई सदस्यता प्राप्त होता है ईमेल सूचना भेजने के लिए जाँच करें।<br><br><b>चेतावनी!</b> व्यवस्थापक ईमेल प्रणाली पैरामीटर में स्थापित किया जाना है!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "व्यवस्थापक संदेश (समर्थन एचटीएमएल)");
	define("WIDGET_ADMIN_HELP", "अपने संदेश में इस्तेमाल किया जा सकता:<br><b>{SUBSCRIBER_EMAIL}</b> - ग्राहक ईमेल पता<br><b>{SUBSCRIBER_NAME}</b> - ग्राहक का नाम<br><b>{SUBSCRIBER_COMMENT}</b> - ग्राहक के बारे में अपनी टिप्पणी<br><b>{SUBSCRIBER_TAGS}</b> - खेतों में टैग<br><b>{CURRENT_YEAR}</b> - वर्तमान साल<br><b>{CURRENT_MONTH}</b> - वर्तमान माह<br><b>{CURRENT_DAY}</b> - वर्तमान दिन");
    define("WIDGET_ERROR_MESSAGE_LABEL", "गलत ग्राहक ईमेल पते के मामले में सर्वर त्रुटि संदेश");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "अपने सर्वर चुनें");
	define("BOUNCED_DEL_EMAILS", "प्राप्तकर्ता सूची से स्वचालित रूप से हटाएं");
	define("BOUNCED_DEL_MESSAGES", "सर्वर से सभी बाउंस और जाँच संदेशों स्वचालित रूप से हटाएं");
	define("BOUNCED_MAX", "मैक्स संदेशों की सीमा के");
	define("BOUNCED_AT_TIME", "एक समय में जाँच करने के लिए");
	define("BOUNCED_START", "ईमेल बाउंस के लिए मेलबॉक्स चेक");
	
	define("YES", "हाँ");
	define("NO", "नहीं");
	define("DATA_ERROR", "त्रुटि: अनुरोध डेटा मौजूद नहीं...<br><br><a href='index.php'>डैशबोर्ड खोलने के लिए यहाँ क्लिक करें</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "सर्वर सदस्यता विजेट के लिए मेल भेजने के लिए");
    define("TESTING_TEMPLATE", "परीक्षण टेम्पलेट");
    define("TESTING_TEMPLATE_INFO", "नीचे दर्ज ईमेल करने के लिए टेम्पलेट भेजता है। चर प्रतिस्थापित नहीं की जाएगी");
    define("TESTING_CHOOSE_SERVER", "सर्वर भेजने का चयन");
    define("ERRORS", "त्रुटियाँ");
    define("TEST", "मुझे परखें!");
    
    /*v.1.16*/
    define("COPY", "प्रतिलिपि");
    define("COPYING", "मुकाबला");
    define("CHECK", "चेक");
    define("DATA_VERIFY", "डेटा अखंडता जांच");
    define("DATA_VERIFY_QUESTION", "क्या आप वाकई डेटा अखंडता की जांच करना चाहते हैं?");
    define("DATA_VERIFY_DESCRIPTION", "यह ऑपरेशन कुछ मिनट ले सकता है, यह आपके डेटाबेस में डेटा की मात्रा पर निर्भर करता है। <br> क्या आप यह सुनिश्चित कर रहे हैं कि अभियान समाप्त हो गया है और इस सूची में दिखाई नहीं दे रहा है।");
    define("DATA_VERIFY_BUTTON", "डेटा अखंडता सत्यापित करें");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "चयनित टैग से प्राप्तकर्ता फ़िल्टर करें (OR&nbsp;query)");
    define("REC_QUERY_AND", "फ़िल्टर प्राप्तकर्ता सभी चयनित टैग में हैं (AND&nbsp;query)");
    define("REC_RESET", "क्वेरी रीसेट करें");
    define("REC_BUTTON_DELETE", "प्राप्तकर्ता हटाएं");
    define("CSV_ST_1", "सूत्र के अनुसार डेटा तैयार करें:");
    define("CSV_COL_NO", "स्तंभ संख्या");
    define("CSV_REQ", "अपेक्षित");
    define("CSV_OPT", "ऐच्छिक");
    define("CSV_ADDR", "ईमेल पता");
    define("CSV_NAME", "पहला नाम और अंतिम नाम");
    define("CSV_TAGS", "टैग");
    define("CSV_TAGSDESC", "डेटाबेस में होना चाहिए एक ही स्थान से अलग होना चाहिए");
    define("CSV_COMMENT", "टिप्पणियाँ");
    define("CSV_DESC1", "स्प्रेडशीट को एक CSV के रूप में सहेजें");
    define("CSV_DESC2", "सीमांकक");
    define("CSV_MAXLINE", "अधिकतम सीएसवी रेखा की लंबाई");
    define("CSV_FORMDESC", "नीचे दिए गए फॉर्म का उपयोग करके तैयार सीएसवी फ़ाइल अपलोड करें");
    define("DISABLE_EDITOR", "संपादक को अक्षम करें");
    define("ENABLE_EDITOR", "संपादक को सक्षम करें");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "डीबी पुल द्वारा आयात ईमेल");
    define("TITLE_IMPORT", "प्राप्तकर्ता आयात करें");
    define("SUBTITLE_IMPORT", "डेटाबेस पुल - स्रोत परम");
    define("LIST_TITLE_IMPORT", "अन्य डेटाबेस से प्राप्तकर्ताओं को आयात करें");
    define("ADD_NEW_BRIDGE", "नया पुल जोड़ें");
    define("IMPORT_RECIPIENTS", "प्राप्तकर्ताओं को आयात करें");
    define("IMPORT_BRIDGE_DESC", "आयात पुल का विवरण");
    define("CONFIRM_BRIDGE_DEL", "डेटाबेस पुल कनेक्शन को हटा रहा है");
    define("IMPORTING_BRIDGE_REC", "प्राप्तकर्ताओं को आयात करना");
    define("CHOOSEN_BRIDGE", "आयात के लिए चुना पुल");
    
    define("FORM_BRIDGE_DESC", "आयात पुल का विवरण");
    define("BRIDGE_TABLE", "स्रोत तालिका का नाम");
    define("BRIDGE_COL_NAME", "प्राप्तकर्ता नाम के लिए स्रोत स्तंभ");
    define("BRIDGE_COL_NAME_INFO", "प्राप्तकर्ता नाम फ़ील्ड पर आयात किया जाएगा");
    define("BRIDGE_COL_MAIL", "ईमेल पते के लिए स्रोत स्तंभ");
    define("BRIDGE_COL_MAIL_INFO", "ईमेल क्षेत्र में आयात किया जाएगा");
    define("BRIDGE_COL_DESC", "प्राप्तकर्ता विवरण के लिए स्रोत स्तंभ");
    define("BRIDGE_COL_DESC_INFO", "विवरण फ़ील्ड में आयात किया जाएगा");
    define("BRIDGE_CHECK_CON", "डेटाबेस कनेक्शन की जांच करें");
    define("BRIDGE_WAITING", "परीक्षण के लिए प्रतीक्षा कर रहा है...");
    define("BRIDGE_ADD_NAME", "अतिरिक्त प्राप्तकर्ता नाम");
    define("BRIDGE_ADD_NAME_INFO", "स्रोत नाम कॉलम के बाद जोड़ दिया जाएगा");
    define("BRIDGE_ADD_DESC", "अतिरिक्त प्राप्तकर्ता विवरण");
    define("BRIDGE_ADD_DESC_INFO", "स्रोत विवरण कॉलम के बाद जोड़ा जाएगा");
    define("BRIDGE_OVERRIDE", "मौजूदा प्राप्तकर्ताओं को ओवरराइड करें");
    define("BRIDGE_OVERRIDE_O1", "अद्यतन - नए स्रोत के अनुसार सही गंतव्य प्राप्तकर्ता");
    define("BRIDGE_OVERRIDE_O2", "अनदेखा करें - कुछ भी नहीं करें अगर गंतव्य प्राप्तकर्ता पहले से मौजूद है");
    define("BRIDGE_TAGS", "उपलब्ध टैग");
    define("BRIDGE_FILL_FIELDS", "परीक्षण से पहले सभी आवश्यक फ़ील्ड भरें...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "आयात प्रगति पर है, कृपया प्रतीक्षा करें...");
    define("BRIDGE_TEST_OK", "आपका कनेक्शन पुल सही ढंग से काम कर रहा है");
    define("BRIDGE_IMPORT_OK1", "आयात समाप्त, अपडेट किया गया:");
    define("BRIDGE_IMPORT_OK2", " सम्मिलित किया गया:");
    define("TABLE", "तालिका ");
    define("COLUMN", "स्तंभ ");
    define("NOT_IN_DB", " डाटाबेस में मौजूद नहीं है ");
    define("NOT_IN_TABLE", " तालिका में मौजूद नहीं है ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "हां अपनी भौगोलिक स्थिति एपीआई कुंजी दर्ज करें");
    define("SETTINGS_API_GEO_LINK_INFO", "यहां अपनी भौगोलिक स्थिति एपीआई कुंजी दर्ज करें");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Https का प्रयोग करें");
    define("HTTPS_USAGE_INFO", "अगर आप https का उपयोग कर रहे हैं तो चिह्नित करें, यह https के साथ सभी लिंक उत्पन्न करेगा");
    define("TEMPLATE_STATISTICS", "टेम्पलेट आंकड़े: ");
    define("TEMPLATE_CHARS", "अक्षरों की संख्या: ");
    define("TEMPLATE_USAGE", "उपयोग: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "सदस्यता फार्म रजिस्टर टोकन ");
    define("WIDGET_EMAIL_TOKEN", "सदस्यता ईमेल रजिस्टर टोकन ");
    
    /*v.1.22*/
    define("WEBSITE", "वेबसाइट");
    define("WIDGET_WEBSITE_SHOW", "प्राप्तकर्ता url फ़ील्ड दिखाएं");
    define("VERIFIED", "सत्यापित");
    define("VERIFY", "सत्यापित करें");
    define("C_PREPARED", "तैयार है और प्रतीक्षा कर रहा है");
    define("C_AJAX_PROGRESS", "अजाक्स प्रगति पर भेज रहा है");
    define("C_FINISHED", "ख़त्म होना");
    define("C_BG_PROGRESS", "पृष्ठभूमि प्रगति में भेज रहा है");
    define("C_PAUSED", "रोके गए");
    define("C_CRON", "क्रोन प्रगति पर भेज रहा है");
    define("B_VER", "थोक सत्यापन");
    define("B_RV", "थोक प्राप्तकर्ता सत्यापन");
    define("B_SEND1", "क्या आप वाकई भेजना चाहते हैं?");
    define("B_SEND2", "सत्यापन के लिए प्राप्तकर्ता");
    define("B_CHECK_LIST", "थोक सत्यापन सूचियों की जाँच करें");
    define("B_VER_INFO", "आपके थोक चेक आपके emailable.com खाते पर उपलब्ध होंगे");
    define("B_VER_IN_PROG", "प्रगति की पुष्टि कर रहा है");
    define("B_VER_SENT", "थोक चेकिंग के लिए प्राप्तकर्ता भेजे गए");
    define("B_V_TITLE", "थोक ईमेल सत्यापन");
    define("B_V_TITLE2", "भेजी गई सूची");
    define("BUTTON_CHECK_STATUS", "अवस्था जांच");
    define("BUTTON_DOWN_UP", "अद्यतन डाउनलोड करे");
    define("V_ID", "आईडी सत्यापित करें");
    define("V_QTY", "जाँच करने के लिए मात्रा");
    define("V_DATE", "भेजने का दिनांक");
    define("V_MESSAGE", "राज्य");
    define("V_PERC", "% पूर्ण");
    define("V_WORKING", "काम कर रहे");
    define("RESPONSE", "प्रतिक्रिया");
    define("V_UPDATED_INFO", "प्राप्तकर्ता अद्यतन, जाँच विवरण");
    define("SETTINGS_API_THECHECKER", "emailable.com API कुंजी प्राप्त करने के लिए यहां क्लिक करें");
    define("SETTINGS_API_DESCRIPTION", "उछाल को मार देता है! <br>नीचे दिए गए बटन का उपयोग करते हुए, आपको अपनी पहली खरीद में <b> 30% मुफ़्त अतिरिक्त चेक </b> देगा और आपकी प्रत्येक खरीद पर आपको 30% बोनस (नकद या चेक में) देगा, हमेशा के लिए!");
    define("EC_DATA", "डेटा निर्यात के लिए अपना चारसेट सेट करें");
    define("EC_DATA1", "अभियान डेटा निर्यात करें");
    define("EX_OPENED_BUTTON", "खोले गए प्राप्तकर्ता");
    define("EX_OPENED_DESC", "निर्यात अभियान प्राप्तकर्ता जो अभियान ईमेल खोलते हैं");
    define("EX_NOT_OPENED_BUTTON", "प्राप्तकर्ता जो नहीं खोला");
    define("EX_NOT_OPENED_DESC", "निर्यात अभियान प्राप्त करने वालों ने अभियान ईमेल नहीं खोला");
    define("EX_UNSUBSRIBED_BUTTON", "प्राप्तकर्ता जो बिना सदस्यता के हैं");
    define("EX_UNSUBSRIBED_DESC", "निर्यात अभियान प्राप्तकर्ता जो अभियान से सदस्यता समाप्त कर चुके हैं");
    define("EX_CLICKED_BUTTON", "प्राप्तकर्ता जिन्होंने क्लिक किया है");
    define("EX_CLICKED_DESC", "निर्यात अभियान प्राप्तकर्ता जो अभियान ईमेल में लिंक पर क्लिक करते हैं");
    define("EX_ALL_BUTTON", "सभी प्राप्तकर्ता डेटा");
    define("EX_ALL_DESC", "वर्तमान अभियान के सभी प्राप्तकर्ताओं का डेटा निर्यात करें");
    define("EX_COUNTRY_BUTTON", "प्राप्तकर्ता देशों");
    define("EX_COUNTRY_DESC", "वर्तमान अभियान के सभी देशों को निर्यात करें");
    define("EX_CITY_BUTTON", "प्राप्तकर्ता शहरों");
    define("EX_CITY_DESC", "वर्तमान अभियान के सभी शहरों का निर्यात करें");
    define("EX_BROWSER_BUTTON", "प्राप्तकर्ता ब्राउज़र्स");
    define("EX_BROWSER_DESC", "वर्तमान अभियान के सभी ब्राउज़र निर्यात करें");
    define("SETTINGS_CHARSET", "डेटा निर्यात के लिए अपना चारसेट सेट करें");
    define("MENU_BULK", "थोक सत्यापन");
    define("B_CONFIRM", "emailable.com से बल्क डिलीट की पुष्टि करें ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "अपडेट करने वाले। यदि डेटाबेस में एक ईमेल पता आयात किया जाता है, तो इसे CSV फ़ाइल में डेटा का उपयोग करके अपडेट करें।");
    define("TAGS_MANAGER_TITLE", "प्राप्तकर्ता टैग प्रबंधक, चयनित ईमेल: ");
    define("TAGS_SELECT_ACTION", "अपनी कार्रवाई चुनें:");
    define("TAGS_MANAGER_ADD", "चयनित प्राप्तकर्ता को टैग जोड़ें");
    define("TAGS_MANAGER_REMOVE", "चयनित प्राप्तकर्ता से टैग निकालें");
    define("TAGS_SELECT", "अपने टैग का चयन करें:");
    define("SAVE_CHANGES", "परिवर्तनों को सुरक्षित करें");
    define("NOT_SELECTED_TAGS", "पहले प्राप्तकर्ताओं का चयन करें");
    define("TM_BUTTON", "थोक टैग प्रबंधक");
    define("WAITING", "इंतज़ार कर रही...");
    define("MULTI_SMTP", "मल्टी एसएमटीपी");
    define("MULTI_CHECK_DESC", "जाँच करें, यदि आप मल्टी smtp भेजने की सुविधा का उपयोग करना चाहते हैं");
    define("MULTI_CHOOSE", "Smtp सर्वर चुनें");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "काला सूची में डालना");
    define("BL1", "अस्वीकृत डोमेन और IP की सूची");
    define("BL2", "सदस्यता के लिए अवरुद्ध दुर्भावनापूर्ण विज्ञापन");
    define("BL3", "आपकी काली सूची");
    define("B_VALUE", "मूल्य");
    define("B_TYPE", "प्रकार");
    define("MENU_ADD_BL", "नई प्रविष्टि जोड़ें");
    define("B_DOMAIN", "डोमेन");
    define("B_IP", "आईपी");
    define("B_IMPORT_INFO", "आप यहां अपने ब्लैक लिस्ट में दुर्भावनापूर्ण पतों की सूची आयात कर सकते हैं <small>(प्रत्येक रिकॉर्ड को अलग लाइन में होना चाहिए)</small>");
    define("B_DELETE_ALL", "काली सूची साफ करें");
    define("B_DELETE_QUESTION", "क्या आप वाकई पूरी ब्लैकलिस्ट हटाना चाहते हैं?");
    define("B_EXPORT", "काली सूची में निर्यात करें");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM समायोजन");
    define("DKIM_USE", "उपयोग DKIM");
    define("DKIM_DOMAIN", "डोमेन नाम पर हस्ताक्षर");
    define("DKIM_PRIVATE", "निजी कुंजी फ़ाइल पथ");
    define("DKIM_SELECTOR", "आमतौर पर आपके DNS TXT रिकॉर्ड पर चयनकर्ता कुंजी सेटअप");
    define("DKIM_PASS", "उपयोग किया जाता है यदि आपकी कुंजी एन्क्रिप्ट की गई है");
    define("DKIM_IDENTITY", "आमतौर पर ईमेल पते का उपयोग ईमेल के स्रोत के रूप में किया जाता है");
    
    define("ERROR", "त्रुटि:");
    define("WARNING", "चेतावनी!");
    define("D_MODE", "DEMO मोड में परिवर्तन और कुछ सुविधाएँ उपलब्ध नहीं हैं.");
    define("S_DIS", "जब तक आप अपना खरीद कोड दर्ज नहीं करते, अक्षम भेजा जा रहा है");
    define("HERE", "यहां");
    define("PLIK", "फ़ाइल");
    define("NOT_WR", "लेखन योग्य नहीं है। सेटिंग्स को सहेजा नहीं जाएगा। सहेजने से पहले फ़ाइल अनुमतियाँ बदलें.");
    define("EPC", "Envato खरीद कोड");
    define("EVALIDEPC", "वैध खरीद कोड दर्ज करें");
    define("NO_ADMIN_MAIL", "पहले सेटिंग में व्यवस्थापक ईमेल पते को अपडेट करें.");
    
    define("SMTP_LABEL", "डिबग स्तर");
    define("SMTP_0", "डिबगिंग अक्षम करें");
    define("SMTP_1", "क्लाइंट द्वारा भेजे गए आउटपुट संदेश");
    define("SMTP_2", "1 के रूप में, साथ ही सर्वर से प्राप्त प्रतिक्रियाएं (यह सबसे उपयोगी सेटिंग है)");
    define("SMTP_3", "2 के रूप में, साथ ही प्रारंभिक कनेक्शन के बारे में अधिक जानकारी - यह स्तर STARTTLS विफलताओं का निदान करने में मदद कर सकता है");
    define("SMTP_4", "3 के रूप में, साथ ही निचले स्तर की जानकारी, बहुत वर्बोज़, एसएमटीपी डीबग करने के लिए उपयोग न करें, केवल निम्न-स्तरीय समस्याएं ");
    
    define("SMTP_SENDER_FORCE", "इस प्रेषक को हमेशा इस सर्वर के अभियानों में बाध्य करें");
    define("SMTP_SENDER_MAIL", "प्रेषक का ईमेल पता");
    define("SMTP_SENDER_DESCRIPTION", "प्रेषक विवरण");

    
    
    
