<?php
	/*login page*/
	define("LANG","de");
	define("LOGIN_TITLE","Mailing-System");
	define("LOGIN_SIGN_IN","Bitte einloggen");
	define("LOGIN","Anmeldung");
	define("LOGIN_PASS","Passwort");
	define("LOGIN_SIGN_IN_BUTTON","Anmelden");
	define("LOGIN_FAILED","Falsche Anmeldung und/oder Passwort!");
	define("INSTALLING_SYSTEM","Systemkonfiguration");
	define("INSTALLING_CONNECTED","Korrekt mit der Datenbank verbunden");
	define("INSTALLING_ADD_TABLES","Tabellen hinzufügen");
	define("INSTALLING_ADD_TABLES_DESC","Klicken Sie hier, um Tabellen hinzuzufügen und mit dem System zu arbeiten");
	
	/*left menu*/
	define("WELCOME","Herzlich willkommen,");
	define("WELCOME_ASK","Was möchten Sie tun?");
	define("MAIN_MENU","Hauptmenü");
	define("START","Anfang");
	define("DASHBOARD","Dashboard");
	define("EMAIL_ADRESSES","E-Mail-Adressen");
	define("MENU_RECIPIENT_LIST","Empfängerliste");
	define("MENU_ADD_RECIPIENT","Empfänger hinzufügen");
	define("MENU_CSV_IMPORT","E-Mail-Adressen aus einer CSV-Datei importieren");
	define("MENU_CSV_EXPORT","E-Mail-Adressen in eine CSV-Datei exportieren");
	define("MENU_TAG_LIST","Stichwortliste");
	define("MENU_ADD_TAGS","Stichworte hinzufügen");
	define("MENU_SENDERS_LIST","Absenderliste");
	define("MENU_ADD_SENDER","Absender hinzufügen");
	define("MENU_TEMPLATES","E-Mail-Vorlagen");
	define("MENU_TEMPLATES_LIST","Vorlagenliste");
	define("MENU_TEMPLATES_ADD","Neue Vorlage hinzufügen");
	define("MENU_TEMPLATES_ATTACHMENTS","Anhänge");
    define("MENU_TEMPLATES_THUMBNAILS","Miniaturansichten");
	define("MENU_CAMPAIGNS","Ihre Kampagnen");
	define("MENU_CAMPAIGNS_ADD","Neue Kampagne vorbereiten");
	define("MENU_CAMPAIGNS_WAITING_LIST","Kampagnen-Warteliste");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Laufende Kampagnen");
	define("MENU_CAMPAIGNS_SENT","Gesendete Kampagnen");
	define("MENU_SYSTEM_CONFIGURATION","Systemkonfiguration");
	define("MENU_SETTINGS","Einstellungen");
	define("MENU_LOGIN","Anmeldung");
	define("MENU_DB","Datenbank");
	define("MENU_SYSTEM_PARAMS","Systemparameter");
	define("MENU_SPECIALS","Erweiterungen");
	define("MENU_ADDONS","Nützliche Extras");
	define("MENU_CLEAR_DB","Datenbank löschen");
	define("MENU_IMPORT_TEMPLATES","Beispielvorlagen importieren");
	define("MENU_IMPORT_DATA","Beispieldaten importieren");
	define("MENU_FAQ","Fragen und Antworten");
	define("MENU_ABOUT","Über das System");
    define("MENU_SMTP_PARAMS","SMTP Konfiguration");
    define("MENU_UNSUBSCRIBED","Abonnenten");
    define("MENU_UNSUBSCRIBED_LIST","Austragungen");
    define("MENU_DOCS","Dokumentation");
    define("MENU_SUBSCRIBE_WIDGET","Abonnieren-Widget");
    define("MENU_BOUNCED","Prüfe unzustellbare E-Mails");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","E-Mail Datenbank");
	define("D_EMAIL_ADD_NEW","Neue E-Mail hinzufügen");
	define("D_EMAIL_TEMPLATES","E-Mail Vorlagen");
	define("D_EMAIL_TEMPLATES_ADD","Neue Vorlage hinzufügen");
	define("D_EMAIL_SENT","Gesendete E-Mails");
	define("D_EMAIL_EFFICIENCY","Wirkungsgrad");
	define("D_EMAIL_UNSUBSCIBERS","Abbestellt");
	define("D_CAMPAIGNS","Kampagnen");
	define("D_CAMPAIGNS_ADD","Neue Kampagne");
	define("D_CAMPAIGNS_WAITING","Fertig zum Versenden");
	define("D_CAMPAIGNS_SENT","Abgeschlossen");
	define("D_STATISTICS","Statistiken");
	define("D_THIS_YEAR","Ihre Werbekampagnen in diesem Jahr");
	define("D_CHECK_ALL","Alle überprüfen...");
	define("JAN","Jan");
	define("FEB","Feb");
	define("MAR","Mär");
	define("APR","Apr");
	define("MAY","Mai");
	define("JUN","Jun");
	define("JUL","Jul");
	define("AUG","Aug");
	define("SEP","Sep");
	define("OCT","Okt");
	define("NOV","Nov");
	define("DEC","Dez");
	define("D_PREPARED_OVERALL","Vorbereitete Kampagnen");
	define("D_SENT_OVERALL","Gesendet");
	define("D_HOW_TO","Wie wirds gemacht?");
	define("D_HOW_STEP_1_TITLE","1. E-Mail Datenbank");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Tags hinzufügen</a> dies wird Ihnen helfen, Kunden zu finden und eine Werbekampagne vorzubereiten. Als nächstes <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>hinterlegen Sie E-Mail-Adressen</a> in der Datenbank. Sie können auch <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>eine CSV-Datei hochladen</a>, um mit E-Mail-Adressen in die Datenbank zu importieren.");
	define("D_HOW_STEP_2_TITLE","2. Absender");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Absender hinzufügen</a> Hier können Sie entscheiden, von wem Ihre Kunden eine E-Mail erhalten.");
	define("D_HOW_STEP_3_TITLE","3. E-Mail Vorlagen");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Vorlage hinzufügen</a> Erstellen Sie beliebig viele Vorlagen mit beliebig vielen  Anlagen.");
	define("D_HOW_STEP_4_TITLE","4. Werbekampagne");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Neue Kampagne hinzufügen</a> Sie können beliebig viele Kampagnen vorbereiten und mit <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Kampagne senden</a> jederzeit versenden.");
	define("D_HOW_STEP_5_TITLE","5. Statistiken beobachten");
	define("D_HOW_STEP_5_DESC","Hier erfahren Sie, welche Kampagnen am erfolgreichsten sind, wie und wann die Kampagne erstellt wurde, wie viele Mails gesendet wurden und wie effizient die Kampagne war (zum Beispiel, wie viele Personen Ihre E-Mails gelsen haben und wie viele Personen sich aus dem Verteiler ausgetragen haben).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-Mailer");
	
	/**/
	define("CHANGE_LOGIN","Benutzernamen ändern");
	define("CHANGE_PASS","Passwort ändern");
	define("CLEAR_DATABASE","Datenbank löschen");
	define("LOGOUT","Abmelden");
	define("ABOUT","Über");
	
	/*vertical buttons*/
	define("CONFIG","Konfiguration");
	define("CONFIG_TOOLTIP","Systemkonfiguration");
	define("MEDIA_MANAGER","Anhänge verwalten");
	define("RECIPIENT","Empfänger");
	define("RECIPIENT_TOOLTIP","E-Mail Verwaltung");
	define("RECIPIENT_EDIT","Details ändern");
	define("RECIPIENT_ADD_NEW","Neue Empfänger hinzufügen");
	define("MENUS","Menüs");
	define("MENUS_TOOLTIP","Menükonfiguration");
	define("TEMPLATES","Vorlagen");
	define("TEMPLATES_TOOLTIP","Vorlagenkonfiguration");
	define("HELP","Hilfe");
	define("HELP_TOOLTIP","Tipps und Hinweise");
	
	define("FILE_MANAGEMENT","Anhänge");
	define("CSV_IMPORT","E-Mail-Adressen aus CSV-Datei importieren");
	
	define("PERSON","Person");
	define("EMAIL","E-Mail-Adresse");
	define("TAGS","Stichworte");
	define("TAGS_LIST","Stichwort-Liste");
	define("TAGS_ADD","Neue Stichworte hinzufügen");
	define("TAGS_ADD_NEW","Stichworte hinzufügen");
	define("TAGS_ADD_EDIT","Stichworte bearbeiten");
	define("TAGS_NAME","Stichwortbezeichnung");
	define("TAGS_DESCRIPTION","Beschreibung");
	define("TAGS_NAME_PLACEHOLDER","Geben Sie das Stichwort ein...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","Geben Sie die Stichwort-Beschreibung ein...");
	define("TAGS_USED","Verwendet (mal)");
	define("TAGS_INFO","Stichworte zur E-Mail-Adresse");
	
	define("RECIPIENT_LIST","Mailingliste");
	define("RECIPIENT_NAME","Name des Empfängers");
	define("RECIPIENT_NAME_PLACEHOLDER","Geben Sie den vollständigen Namen ein");
	define("RECIPIENT_MAIL","E-Mail");
	define("RECIPIENT_MAIL_PLACEHOLDER","E-Mail-Adresse eingeben");
	define("RECIPIENT_ONLY_TXT","Nur-Text-E-Mails");
	define("RECIPIENT_DESCRIPTION","Beschreibung");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","Beschreibung...");
	define("RECIPIENT_DB","Ihre E-Mail-Datenbank");
	define("RECIPIENT_DETAILS_EDIT","Empfängerdetails bearbeiten");
	define("RECIPIENT_DETAILS_ADD","Neue E-Mail-Adresse hinzufügen");
	define("RECIPIENT_IMPORT_CSV","E-Mails aus CSV-Datei importieren");
	define("RECIPIENT_PREPARE_CSV","Die CSV-Datei muss die folgenden Zeilen/Spalten enthalten");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Um neue Datensätze aus einer Excel-Datei hinzuzufügen, sollten Sie die folgenden Schritte ausführen");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","CSV-Vorlage herunterladen");

	define("RECIPIENT_UPLOAD_CSV_NAME","CSV-Datei importieren");
	define("RECIPIENT_NOT_CSV","<b>Ungültiges Datenformat</b><br/>");
	define("RECIPIENT_ROW","Reihe ");
	define("RECIPIENT_WRONG_EMAIL"," - Falsche E-Mail-Adresse eingegeben: ");
	define("RECIPIENT_EMAIL_EXIST"," - Diese Adresse befindet sich bereits in der Datenbank: ");
	define("RECIPIENT_EMAIL_LACK"," - E-Mail-Adresse fehlt:");
	define("RECIPIENT_EMAIL_IN_DB"," - Diese E-Mail-Adresse existiert bereits in der CSV-Datei: ");
	define("RECIPIENT_TAG_NOT_EXIST"," - Stichwort existiert nicht: ");
	define("RECIPIENT_CSV_ERRORS","Fehler in der Datei ");
	define("RECIPIENT_CSV_ADDED","Hinzugefügt ");
	define("RECIPIENT_CSV_ADDED_FROM"," E-Mail Adressen aus Datei ");
	define("RECIPIENT_CSV_EXPORT","E-Mail-Adressen in eine Datei exportieren");
	define("RECIPIENT_CSV_EXPORT_CHK","Markieren Sie die zu exportierenden Felder:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","E-Mail Adresse des Empfängers");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Vorname und Nachname");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Tags - getrennt durch Leerzeichen");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Bemerkungen");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Empfangen von Nur-Text-E-Mails");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Registrierungsdatum");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Datum der Änderung");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","Export");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Überprüfung von CSV-Fehlern ignorieren (überprüfen Sie, ob die Datei mehr als 1000 E-Mails enthält - größere Dateien benötigen einen großen Speicherplatz auf dem Server)");
	
	define("SAVE","Speichern");
	define("CANCEL","Abbrechen");
	define("DELETE","Löschen");
    define("EDIT","Bearbeiten");
	define("CREATED","Erstellt");
	define("MODIFIED","Geändert");
	define("SEND","Senden");
	define("SENT","Gesendet");
	define("PROGRESS","Fortschritt");
	define("RESUME","Fortsetzen");
	define("CLOSE","Schließen");
	define("CHANGES_SAVED","Änderungen wurden erfolgreich durchgeführt");
	
	define("DELETING","Löschen");
	define("DELETING_CONFIRM_QUESTION","Sind Sie sich sicher, dass Sie den Eintrag entfernen wollen?");
	
	define("DATATABLE_LENGTHMENU", " _MENU_ Einträge pro Seite anzeigen");
	define("DATATABLE_ZERORECORDS", "Nichts gefunden");
	define("DATATABLE_INFO", "Seite  _PAGE_ von _PAGES_");
	define("DATATABLE_INFOEMPTY", "Keine Datensätze vorhanden");
	define("DATATABLE_INFOFILTERED", "(Gefiltert _TOTAL_ von _MAX_ Datensätze insgesamt)");
	define("DATATABLE_SEARCH", "Suche");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Neue Vorlage hinzufügen");
	define("TEMPLATES_LIST", "Vorlagenliste");
	define("TEMPLATES_TITLE", "Vorhandene Vorlagen");
	define("TEMPLATES_TITLE_ADD", "Neue Vorlagen hinzufügen");
	define("TEMPLATES_TITLE_EDIT", "Vorlagen bearbeiten");
	define("TEMPLATES_NAME", "Name der Vorlage");
	define("TEMPLATES_MAIL_TITLE", "E-Mail Titel");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "E-Mail Titel eingeben");
	define("TMPLATES_HTML", "HTML-Vorlage");
	define("TMPLATES_TXT", "Text-Vorlage");
	define("TMPLATES_VARIABLES", "Verfügbare Vorlagenvariablen (siehe <a href='docs/index.html#variables' target='_blank'>Dokumentation</a> für Details):");
	define("TEMPLATES_THUMB", "Miniaturansicht");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Miniaturansicht bearbeiten");
	define("THUMBNAIL_MEDIA_LIST", "Verfügbare Miniaturansichten");
	
	define("MEDIA_FILENAME", "Dateiname");
	define("MEDIA_FILENAME_DESCRIPTION", "Dateibeschreibung");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Uploadzeit");
	define("MEDIA_TEMPLATES", "Wird als Anlage verwendet");
	define("MEDIA_LIST", "Verfügbare Anlagen");
	define("MEDIA_ADD_FILES", "Dateien hinzufügen");
	define("MEDIA_BROWSE", "Durchsuchen");
	define("MEDIA_UPLOAD", "Hochladen");
	
	define("CAMPAIGN_MENU", "Neue Kampagne");
	define("CAMPAIGN_PREPARE", "Kampagne vorbereiten");
	define("CAMPAIGN_RECIPIENTS", "Empfänger auswählen");
	define("CAMPAIGN_TEMPLATES", "Vorlagen wählen");
	define("CAMPAIGN_SENDERS", "Absender auswählen");
	define("CAMPAIGN_CONFIRM", "Kampagne speichern");
	define("CAMPAIGN_SEND", "Kampagne senden");
	define("CAMPAIGN_NAME", "Kampagnenname");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Kampagnenname eingeben");
	define("CAMPAIGN_RECIPIENT_QTY", "Empfänger");
	define("CAMPAIGN_TEMPLATE_NAME", "Vorlagen");
	define("CAMPAIGN_SENDER", "Absender");
	define("CAMPAIGN_CREATED_DATE", "Erstellt");
	define("CAMPAIGN_STEP_1", "1. Wählen Sie die Empfänger aus (verwenden Sie das Suchfeld über der Tabelle)");
	define("CAMPAIGN_STEP_2", "2. Speichern Sie Ihre Kampagne");
	define("CAMPAIGN_SELECT", "Wählen Sie eine Kampagne für das Mailing aus");
	define("CAMPAIGN_FORM_SELECT", "wählen...");
	define("CAMPAIGN_CURRENT_STATUS", "Status der aktuellen Kampagne");
	define("CAMPAIGN_SENT_NOW", "Jetzt versenden");
	define("CAMPAIGN_SENT_BUTTON", "Klicken Sie hier, um mit dem Senden zu beginnen");
	define("CAMPAIGN_RESUME_BUTTON", "Klicken Sie hier, um das Senden fortzusetzen");
	define("CAMPAIGN_SERVER_CONNECTING", "Verbindung zum Server, bitte warten...");
	define("CAMPAIGN_SENDING", "Senden");
	define("CAMPAIGN_PLEASE_WAIT", "Bitte warten");
	define("CAMPAIGN_SENT", "<b>KAMPAGNE Gesendet</b> Empfänger: ");
	define("CAMPAIGN_IN_PROGRESS", "Kampagnen im Gange...");
	define("CAMPAIGN_COMPLETED", "Gesendete Kampagnen");
	define("CAMPAIGN_LEFT", "Noch zu versenden");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Alle abgemeldeten Empfänger löschen");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "Diese Aktion löscht alle abgemeldeten Abonnenten aus Ihrer Datenbank.");
	define("CAMPAIGN_BG_PROCESS", "Hintergrundprozess");
	define("CAMPAIGN_BG_PROCESS_INFO", "Als Hintergrundprozess senden (Sie können den Browser schließen)");
	define("CAMPAIGN_WHEN_FINISH", "Info per E-Mail, wenn Versand beendet");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "Empfänger für Benachrichtigung");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Bitte bestätigen Sie, dass der Versand der Mails als Hintergrundprozess erfolgen soll!");
    
    define("HOUR", "Stunde");
    define("OPENS", "Geöffnet");
    define("BOUNCED", "ZUrückgewiesen");
    define("CLICKED", "Angeklickt");
    define("UNIQUE_CLICKS", "Einmalige Klicks");
    define("TOTAL_CLICKS", "Gesamtanzahl an Klicks");
	
	define("SENDER_LIST", "Absenderliste");
	define("SENDER_ADD", "Absender hinzufügen");
	define("SENDER_NAME", "Absender");
	define("SENDER_NAME_PLACEHOLDER", "Geben Sie den Absendernamen ein");
	define("SENDER_EMAIL", "Absender E-Mail");
	define("SENDER_EMAIL_PLACEHOLDER", "Absender E-Mail eingeben");
	define("SENDER_TITLE_ADD", "Absender hinzufügen");
	define("SENDER_TITLE_EDIT", "Absender bearbeiten");
	define("SENDER_EMAIL_TITLE", "Absender-E-Mail-Adresse");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Geben Sie die E-Mail-Adresse des Absenders ein");
	
	define("SETTINGS", "Einstellungen");
	define("SETTINGS_LOGIN_TITLE", "Neue Anmeldeinformationen eingeben");
	define("SETTINGS_LOGIN_LABEL", "Neues Login eingeben");
	define("SETTINGS_LOGIN_PLACEHOLDER", "Login-Name");
	define("SETTINGS_CURR_PASS", "Aktuelles Passwort");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "Passwort eingeben");
	define("SETTINGS_NEW_PASS", "Neues Passwort");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "neues Passwort");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "Bestätigen");
	define("SETTINGS_DB_PARAMS", "Datenbank einrichten");
	define("SETTINGS_DB_HOST", "Datenbank-Host");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "z.B.: localhost");
	define("SETTINGS_DB_USER", "Datenbankbenutzer");
	define("SETTINGS_DB_USER_PLACEHOLDER", "z.B.: root");
	define("SETTINGS_DB_PASSWORD", "Datenbank-Passwort");
	define("SETTINGS_DB_NAME", "Name der Datenbank");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "z.B.: mailing");
	define("SETTINGS_GLOBAL", "Globale Einstellungen");
	define("SETTINGS_LANG", "Systemsprache");
	define("SETTINGS_LIMIT", "Anzahl versendeter E-Mails pro Stunde");
	define("SETTINGS_LIMIT_PLACEHOLDER", "Standard: 1000");
	define("SETTINGS_TRACKING", "E-Mail-Tracking aktivieren");
	define("SENDING_METHOD", "Sendemethode");
	define("SETTINGS_UNSUBSCRIBED", "Abgemeldete Empfänger automatisch löschen");
	define("SETTINGS_UNS_INFO", "Die E-Mail wird automatisch aus der Empfängerliste gelöscht, sobald der Nutzer auf den Link Unsubscribe geklickt hat");
	define("SETTINGS_TRACK_INFO", "Ein unsichtbares Bild wird der Mail hinzugefügt, um die Zugriffe zu zählen");
	define("SETTINGS_API_LABEL", "Google Maps<br>API key");
	define("SETTINGS_API_PLACEHOLDER", "Geben Sie Ihren Google Maps API v.3 Key ein");
	define("SETTINGS_API_LINK_INFO", "Klicken Sie hier, um einen neuen API Key zu erhalten");
	define("SETTINGS_ADMIN_MAIL", "Admin-E-Mail");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "Admin-E-Mail für Systembenachrichtigungen");
    define("SETTINGS_PHP_TIMEOUT", "PHP Timeout (Sekunden)");
    
	define("SMTP_SERVER_DESCRIPTION", "SMTP Server; Sie sollten verschiedene SMTP-Server zur Auswahl hinterlegen");
    define("SMTP_LIST", "Serverliste");
    define("SMTP_ADD", "Neuen Server hinzufügen");
    define("SMTP_EDIT", "Server bearbeiten");
    define("SMTP_INFO", "Ihre SMTP-Server");
    define("SMTP_ADD_BUTTON", "Neuen SMTP-Server hinzufügen");
    define("SMTP_NAME", "Bezeichnung");
    define("SMTP_NAME_PLACEHOLDER", "z.B.: meine beste Verbindung");
    define("SMTP_HOST", "SMTP Adresse");
    define("SMTP_HOST_PLACEHOLDER", "Haupt- und Fallback-Server (mit ';' trennen)");
    define("SMTP_PAUTH", "Authentifizierung");
    define("SMTP_PAUTH_PLACEHOLDER", "SMTP-Authentifizierung verwenden");
    define("SMTP_VERIFY_PEER", "SSL/TLS Zertifikat verwenden");
    define("SMTP_FORCE_SMTP", "SMTP erzwingen");
    define("SMTP_USERNAME", "SMTP Benutzername");
    define("SMTP_USERNAME_PLACEHOLDER", "SMTP-Server Benutzername");
    define("SMTP_LOGIN", "SMTP login");
    define("SMTP_LOGIN_PLACEHOLDER", "SMTP-Server login");
    define("SMTP_PASSWORD", "SMTP Passwort");
    define("SMTP_PASSWORD_PLACEHOLDER", "SMTP-Server Passwort");
    define("SMTP_REPLYTO", "Antwortadresse");
    define("SMTP_REPLYTO_PLACEHOLDER", "Legen Sie eine alternative Antwortadresse fest");
    define("SMTP_REPLYTONAME", "Name");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Geben Sie einen alternativen Antwort-Namen ein");
    define("SMTP_SECURE", "Verschlüsselung");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> (Standard)");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> (nicht empfohlen)");
    define("SMTP_PORT", "Port");
    define("SMTP_PORT_PLACEHOLDER", "Server port");
    define("SMTP_LIMIT", "Limit pro Stunde");
    define("SMTP_LIMIT_PLACEHOLDER", "Standard: 1000");
    define("CAMPAIGN_SMTP", "SMTP-Server auswählen");
    define("SMTP_TESTING", "SMTP-Verbindung testen");
    define("SMTP_TESTING_EMAIL", "Empfängeradresse für Testnachricht");
    define("SMTP_RUN_TEST", "Prüfen");
    define("SMTP_TEST_TXT_TITLE", "SMTP Test-Mail aus E-Mailer");
    define("SMTP_TEST_TXT_MESSAGE", "Dies ist eine Testnachricht, um die SMTP-Verbindung zu testen.");
    define("SMTP_TEST_OK", "Nachricht wurde gesendet. Überprüfen Sie Ihre Mailbox.");
    define("SMTP_TEST_ERROR", "<b>Mailer-Fehler: </b>");
    define("SMTP_BEFORE_USE", "<b>Mailer-Fehler.</b> Vor der Verwendung müssen Sie die SMTP-Verbindung in den Einstellungen aktivieren.");
    define("BOUNCED_INFO", "Nicht zugestellte E-Mails an diese Adresse zurückschicken");
    define("SMTP_CONFIG", "Richten SMTP-Server zum Senden ein");
    define("IMAP_CONFIG", "Richten IMAP / POP3-Postfächer für Bounces ein");
    define("SMTP_INFO_SETUP", "SMTP-Einstellungen");
    define("IMAP_INFO_SETUP", "IMAP / POP3-Einstellungen");
    define("PROTOCOL", "Protokoll");
    define("FOLDER", "Ordner für den Zugriff");
	
	define("STATISTICS", "Statistiken");
	define("STATISTICS_ADV", "Erweiterte Details");
	define("STATISTICS_TAB_MAP", "Empfänger auf der Karte (Geolokalisierung)");
	define("STATISTICS_TAB_DETAILS", "Detaillierte Statistik");
	define("STATISTICS_TAB_ACTIONS", "Spezielle Aktionen");
	define("STATISTICS_BACK", "Zurück zur Liste");
	define("STATISTICS_BUTTON_OPENERS", "Kampagne für erreichte Empfänger");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Bereiten Sie eine neue Kampagne für alle vor, die eine E-Mail geöffnet haben");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Kampagne für nicht erreichte Empfänger");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Bereiten Sie eine neue Kampagne für alle vor, die eine E-Mail NICHT geöffnet haben");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Vorbereitung auf Abonnement");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Bereiten Sie eine neue Kampagne für alle Abonnenten vor; wenn 'Abgemeldete Empfänger automatisch löschen' in den Systemeinstellungen aktiviert ist, werden E-Mails gelöscht und nichts wird hier hinzugefügt");
	define("STATISTICS_BUTTON_FILTERS", "Vorbereiten mit erweiterten Filtern");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Holen Sie sich die Liste aller Empfänger aus dieser Kampagne mit gesammelten Daten und bereiten Sie eine neue spezielle Kampagne basierend auf erweiterten Filtern vor");
	define("STATISTICS_TOP_COUNTRIES", "Die besten 10 Länder");
	define("STATISTICS_TOP_CITIES", "Die besten 10 Städte");
	define("STATISTICS_TOP_CLICKERS", "Die besten 15 Klicker");
	define("STATISTICS_TOP_SOFTWARE", "Die besten 15 häufigsten Programme");
	define("STATISTICS_OTHER_UA", "Alle anderen Programme");
	define("STATISTICS_OTHERS", "Andere");
    
	define("SOFTWARE", "Software");
	define("GEODATA", "Lokalisierung");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='de'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='confirmation'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Sie haben unseren Newsletter abbestellt.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Wir würden uns freuen, Sie demnächst wieder begrüßen zu können.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Entfernen unnötiger Daten aus der Datenbank");
	define("ADDONS_IMPORT_TITLE", "Hinzufügen von Beispiel-Mailingvorlagen");
	define("ADDONS_FAQ_TITLE", "Lesen Sie, bevor Sie fragen");
	define("ADDONS_ABOUT_TITLE", "Informationen über das Programm und die Lizenz");
	define("ADDONS_IMPORT_DATA_TITLE", "Import von Beispieldaten in das System");
	define("ADDONS_IMPORT_BUTTON", "Importieren von E-Mail-Vorlagen");
	define("ADDONS_IMPORT_BUTTON_DESC", "Dadurch werden Beispielvorlagen importiert");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Hinzufügen von Beispielvorlagen bestätigen");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Import von Beispieldaten bestätigen. ACHTUNG! Alle eingegebenen Daten werden gelöscht!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Warum ist es besser, einen eigenen dedizierten Server für Mailings haben?</p>
			<p>Wenn Sie eine hohe Zahl an Empfängern haben, stoßen Sie beim normalen Shared-Hosting möglicherweise an Kapazitätsgrenzen. Je nach Anbieter können Sie dort z.B. nur bis zu 1.000 E-Mails pro Stunde und/oder pro Tag versenden. Auf einem eigenen Server bestehen solche Einschränkungen nicht, und Sie können sowohl E-Mails von Ihrer Domain als auch E-Mails von einer anderen Domain (in diesem Fall legen Sie die sogenannten SPF-Datensätze und die TXT-Domain fest - für Details fragen Sie Ihren Hosting-Provider) senden.</p>
		</li>
		<li>
			<p>Was sind Stichworte?</p>
			<p>Über Stichworte können Sie E-Mail-Adressen gezielt auswählen und Kampagnen nur für bestimmte Empfängergruppen erstellen.</p>
		</li>
		<li>
			<p>Wie kann der Name des Empfängers zur E-Mail-Vorlage hinzugefügt werden?</p>
			<p>Verwenden Sie den Platzhalter {RECIPIENT_NAME} im Inhalt der E-Mail-Vorlage oder im Titel der E-Mail-Vorlage. Der Platzhalter wird durch den Namen des Empfängers ersetzt.</p>
		</li>
		<li>
			<p>Wie füge ich eine neue Übersetzung hinzu?</p>
			<p>Kopieren Sie die Referenz-Datei /languages/english.php, geben Sie ihr einen Namen, der Ihre Sprache beschreibt, zum Beispiel mylanguage.php und laden Sie sie in den gleichen Ordner hoch. Passen Sie alle in der neuen Datei enthaltenen Texte dann entsprechend an. Achten Sie darauf, die Datei in UTF-8 ohne BOM zu speichern. Die Sprachdatei befindet sich im Verzeichnis 'languages'.</p>
			<p>Um eine Übersetzung des WYSIWYG-Editors hinzuzufügen, können Sie auf https://www.tinymce.com/download/language-packages/ Sprachdateien herunterladen. Laden Sie diese dann in den Ordner /emailer/libs/tinymce/langs/ hoch.</p>
		</li>
		<li>
			<p>Wie weise ich einer E-Mail-Adresse Stichworte zu?</p>
			<p>Zuerst müssen Sie einige Stichworte <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'> mit diesem Formular </a> anlegen. Beim Hinzufügen / Bearbeiten von E-Mail-Adressen können die Stichworte dann der jeweiligen E-Mail-Adresse zugeordnet werden.</p>
		</li>
		<li>
			<p>Wie füge ich für Empfänger die Möglichkeit hinzu, den Newsletter abzubestellen?</p>
			<p>Verwenden Sie den Platzhalter {UNSUBSCRIBE} als Link im Inhalt der E-Mail-Vorlage. Der Platzhalter wird durch einen Link für den jeweiligen Empfänger ersetzt. Wenn darauf geklickt wird, wird die Empfängeradresse für den Verteiler gesperrt. Die E-Mail-Adresse wird aber nicht aus der Datenbank entfernt. <br>Verwendung:<br>&lt;a href='{UNSUBSCRIBE}'&gt;Newsletter abbestellen&lt;/a&gt;</p>
		</li>
		<li>
			<p>Wie fügt man den Link zur Ansicht des Newsletters im Browser hinzu?</p>
			<p>Verwenden Sie den Platzhalter {BROWSER_VIEW} als Link im Inhalt der E-Mail-Vorlage. Der Platzhalter wird durch einen Link für den jeweiligen Empfänger ersetzt. Wird dieser angeklickt, öffnet das System die Nachricht im Browserfenster. <br>Verwendung:<br>&lt;a href='{BROWSER_VIEW}'&gt;Browser-Ansicht&lt;/a&gt;</p>
		</li>
		<li>
			<p>Wie kann ich vordefinierte E-Mail-Vorlagen hinzufügen?</p>
			<p>Um 30 Beispiel- Mailingvorlagen zu importieren, hier auf <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>Vorlagen hinzuzufügen</a> klicken.</p>
		</li>
		<li>
			<p>Wie kann ich Bilder zu E-Mails hinzufügen?</p>
			<p>- Als Anhang zu einer E-Mail. In diesem Fall das Template-IMG-Tag-Attribut SCR contentID, (CID) verwenden,  d.h.:<br>&lt;img src='cid:logo.jpg' &gt;<br>- Als absoluter Link zu einem Bild in externen Ressourcen, wie:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>Wie funktioniert das Tracking von E-Mails?</p>
			<p>In jede gesendete E-Mail kann ein Image-Tag &lt;IMG&gt; hinzugefügt werden, wobei das Attribut SRC einen Tracking-Code enthält, der der jeweiligen Nachricht zugeordnet ist. Das Tracking funktioniert nur, wenn der E-Mail-Empfänger die Bilder der empfangenen Nachricht anzeigt.</p>
		</li>
		<li>
			<p>Wie kann verhindern, Spam zu versenden?</p>
			<p>- Sie müssen (das ist gesetzlich vorgeschrieben) die ausdrückliche Zustimmung der jeweiligen Newsletter-Empfänger haben, deren E-Mail-Adresse in eine Mailingliste aufzunehmen. In Deutschland MÜSSEN Sie zudem das Double-Opt-In-Verfahren verwenden.</p>
			<p>- Um nicht in serverseitigen oder lokalen Spamfiltern zu scheitern, individualisieren Sie die Mails mit möglichst vielen Platzhaltern und personalisieren Sie die Mails für jeden Empfänger. Verwenden Sie z.B. {RECIPIENT_NAME} usw.</p>
			<p>- Verwenden Sie keine Begriffe wie: Sex, Viagra, Porno.</p>
			<p>- Verwenden Sie keine Schlüsselphrasen wie: 'Adresse aus einer öffentlichen Datenbank', 'dies ist keine Werbung', 'Wenn Sie nicht interessiert sind, klicken Sie hier zum Abbestellen', 'kostenlos', 'Sonderangebot', 'Kaufen Sie es jetzt'... - wenn dies unumgänglich sein sollte, verwenden Sie Grafiken, um diese Begriffe darzustellen.</p>
			<p>- Jedoch: Verwenden Sie auch nicht zu viele Grafiken, Spam-Filter prüfen das Verhältnis von Grafiken und Text.</p>
			<p>- Die Mail sollte nicht zu lang sein.</p>
			<p>- Je weniger Anhänge, desto besser.</p>
			<p>- Verwenden Sie keine gefälschte Absender-Domain.</p>
			<p>- Senden Sie keine E-Mails von einer nicht-existierenden E-Mail-Adresse.</p>
		</li>
		<li>
			<p>Wie lassen sich die Anzahl der Klicks und die Leserate erhöhen?</p>
			<p>Ganz einfach: Den größten Einfluss haben die Inhalte, die Sie an Ihre Kunden senden und die Häufigkeit des Newsletterversands. In den meisten Fällen sollten Sie nicht mehr als zwei Newsletter pro Monat an Ihre Kunden versenden. Respektieren Sie Ihre Kunden, und diese werden Sie nicht auf den Spamfilter setzen.</p>
		</li>
		<li>
			<p>Wie wählen Sie die Adressen aus, an die Sie einen Newsletter versenden möchten?</p>
			<p>Geben Sie die Mailadressen oder Stichworte durch Leerzeichen getrennt in das Suchfeld oberhalb der E-Mail-Adressen-Liste ein.</p>
		</li>
		<li>
			<p>Wo liegen die Grenzen dieses Systems?</p>
			<p>Es gibt keine Einschränkungen.</p>
		</li>
		<li>
			<p>Welches Limit gilt serverseitig für den Nachrichtenversand?</p>
			<p>Je nach Anbieter sind dies ein paar hundert bis ein paar tausend E-Mails pro Tag. Bitte wenden Sie sich an Ihren Dienstanbieter.</p>
		</li>
		<li>
			<p>Was ist, wenn die Verbindung beim Senden der Kampagne unterbrochen wird?</p>
			<p>Sie können das Senden von Kampagnen unterbrechen und später fortsetzen, die E-Mails werden dann an die restlichen Empfänger gesendet. Jede gesendete E-Mail setzt einen eindeutigen Marker in der Datenbank und die Kampagne selbst wird nicht erneut an denselben Empfänger gesendet.</p>
		</li>
		<li>
			<p>Voraussetzungen für zurückgewiesene E-Mails (Bounces)</p>
			<p>Um die Unterstützung für zurückgewiesene E-Mails zu aktivieren, müssen Sie die Auskommentierung dieser Zeile in der php.ini-Datei aufheben:</p>
			<p>;extension=php_imap.dll</p>
			<p>Imap-Funktionen sind erforderlich, um POP3 / IMAP-Verbindungen zu verwenden.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Seien Sie vorsichtig, die folgenden Aktionen entfernen Daten aus der Datenbank!");
	define("ADDONS_DATA_BE_CAREFULLY", "Warnung! Alle Daten werden gelöscht und durch Musterdaten ersetzt");
	define("ADDONS_D_AL", "Löschen Sie alle Daten");
	define("ADDONS_D_AL_DESC", "Löscht alle Daten in der Datenbank");
	define("ADDONS_D_AL_CONF", "Sind Sie sicher, dass Sie alle Daten aus der Datenbank entfernen möchten? Alle E-Mail-Adressen, Vorlagen, Anhänge und Kampagnen werden gelöscht.");
	define("ADDONS_D_RE", "Empfänger und Kampagnen entfernen");
	define("ADDONS_D_RE_DESC", "Löscht alle E-Mail-Adressen in der Datenbank und die Historie der Werbekampagnen");
	define("ADDONS_D_RE_CONF", "Entfernen aller Empfänger bestätigen");
	define("ADDONS_D_CA", "Nur Kampagnen löschen");
	define("ADDONS_D_CA_DESC", "Löscht alle Werbekampagnen und deren Verlauf");
	define("ADDONS_D_CA_CONF", "Löschen aller Kampagnen und deren Verlauf bestätigen");
	define("ADDONS_D_TE", "Nur Vorlagen löschen");
	define("ADDONS_D_TE_DESC", "Löscht alle E-Mail-Vorlagen und deren Links zu Kampagnen und Anhängen");
	define("ADDONS_D_TE_CONF", "Löschen aller Vorlagen bestätigen");
	define("ADDONS_D_AT", "Anlagen löschen");
	define("ADDONS_D_AT_DESC", "Löscht alle Anhänge");
	define("ADDONS_D_AT_CONF", "Löschen aller Anlagen bestätigen");
	define("ADDONS_D_SE", "Absender löschen");
	define("ADDONS_D_SE_DESC", "Löscht alle eingegebenen Absender-E-Mails, belässt aber ihre ID für statistische Zwecke");
	define("ADDONS_D_SE_CONF", "Löschen aller Absender bestätigen");
	define("ADDONS_D_TG", "Stichworte löschen");
	define("ADDONS_D_TG_DESC", "Löschen Sie alle eingegebenen Stichworte und ihre Zuordnung zu Empfängern");
	define("ADDONS_D_TG_CONF", "Löschen aller Stichworte bestätigen");
    
	define("WIDGET_PREPARE", "Abonnement-Widget einrichten");
	define("WIDGET_OPTIONS", "Einstellungen");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Erstellen Sie hier Ihr Abonnement-Widget");
	define("WIDGET_COMMENT", "Kommentar für neuen Empfänger");
	define("WIDGET_COMMENT_PLACEHOLDER", "z.B.: von domain.ext (wird in der Empfängerbeschreibung gespeichert)");
	define("WIDGET_NAME", "Name");
	define("WIDGET_NAME_SHOW", "Zeigt den Namen des Empfängernamens an");
	define("WIDGET_AFTER", "Nach dem Absenden des Abonnement-Widgets");
	define("WIDGET_AFTER_NOTHING", "nichts tun");
	define("WIDGET_AFTER_TXT", "Textnachricht anzeigen");
	define("WIDGET_AFTER_REDIRECT", "Weiterleitung zur Seite");
	define("WIDGET_TAGS", "Stichworte hinzufügen");
	define("WIDGET_PURE_CODE_TXT", "Reiner HTML-Code. Sie können ihn an Ihre Bedürfnisse anpassen. Fügen Sie beliebige CSS-Klassen, Stichworte, HTML-Befehle, Beschreibungen usw. ein. Kopieren Sie anschließend den Code unten in die Zwischenablage und fügen Sie ihn in Ihre Website ein.");
	define("WIDGET_FULL_CODE_TXT", "Komplette Daten (Alle Felder enthalten)");
	define("WIDGET_MIN_CODE_TXT", "Minimierte Version (Nur E-Mail enthalten)");
	define("WIDGET_CODE_DESC_TXT", "Formularbeschreibung");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> optional.</li>
        <li>E-Mail-Adresse des Empfängers.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> optional.</li>
        <li>Name des Empfängers.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> optional.</li>
        <li>Verstecktes Feld.</li>
        <li>müssen bereits im System hinterlegt sein</li>
        <li>mit Komma getrennt angeben</li>
        <li>Verwenden Sie unterschiedliche Stichworte für unterschiedliche Kampagnen</li>
        <li>Anhand der Stichworte können Sie auch das gleiche Formular auf verschiedenen Websites einbinden und dann für jede Website ein eigenes Stichwort verwenden und die Empfänger so den jeweiligen Websites bzw. Kampagnen zuordnen</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> optional.</li>
        <li>Verstecktes Feld.</li>
        <li>Hier können Sie Anmerkungen zu den über dieses Formular generierten Empfängern hinterlegen.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> optional.</li>
        <li>Verstecktes Feld.</li>
        <li>Aktiviert die Double-Opt-in-Funktion.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> optional.</li>
        <li>Verstecktes Feld.</li>
        <li>Hier wird übergeben, welche Seite nach dem Absenden des Formulars geladen wird.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Kopieren Sie den Code und fügen Sie ihn auf Ihrer Website ein");
	define("WIDGET_DBL_OPT_IN", "Double opt-in");
	define("WIDGET_DBL_OPT_LABEL", "Double-Opt-in (Bestätigungsmail erforderlich) verwenden");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "E-Mail-Nachricht (HTML möglich)");
	define("WIDGET_DBL_OPT_HELP", "Bitte fügen Sie unbedingt <b>{CONFIRM_LINK}</b> in Ihre Nachricht ein.<br>Sie können auch hinzufügen:<br><b>{SUBSCRIBER_EMAIL}</b> - Empfänger-E-Mail-Adresse<br><b>{SUBSCRIBER_NAME}</b> - Empfängername<br><b>{SUBSCRIBER_COMMENT}</b> - Kommentar <br><b>{SUBSCRIBER_TAGS}</b> - verwendete Stichworte<br><b>{CURRENT_YEAR}</b> - aktuelles Jahr<br><b>{CURRENT_MONTH}</b> - aktueller Monat<br><b>{CURRENT_DAY}</b> - aktueller Tag");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "E-Mail-Betreff");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "Betreff der Bestätigungs-E-Mail");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "Text der Bestätigungs-E-Mail");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Weiterleitung nach Bestätigung");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "Zieladresse nach erfolgreicher Bestätigung");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Absenderadresse");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "E-Mail-Adresse eingeben, von der die Bestätigungsmail gesendet wird");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Absender Beschreibung");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "Beschreibung für Absender eingeben");
	define("WIDGET_ADMIN_NOTIFY", "Administrator über neue Empfänger benachrichtigen");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "Aktivieren Sie diese Option, um eine Benachrichtigung an den Administrator zu senden, sobald ein neuer Empfänger registriert wurde. Achtung: Die Mailadresse des Administrators muss im System hinterlegt sein!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Admin-Nachricht (HTML möglich)");
	define("WIDGET_ADMIN_HELP", "Kann in Ihrer Nachricht verwendet werden:<br><b>{SUBSCRIBER_EMAIL}</b> - Empfänger E-Mail-Adresse<br><b>{SUBSCRIBER_NAME}</b> - Empfängername<br><b>{SUBSCRIBER_COMMENT}</b> - Kommentar zu Empfänger<br><b>{SUBSCRIBER_TAGS}</b> - verwendete Stichworte<br><b>{CURRENT_YEAR}</b> - laufendes Jahr<br><b>{CURRENT_MONTH}</b> - aktueller Monat<br><b>{CURRENT_DAY}</b> - aktueller Tag");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Fehlermeldung bei falscher Empfänger-E-Mail-Adresse");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Server auswählen");
	define("BOUNCED_DEL_EMAILS", "Automatisch aus Empfängerlisten löschen");
	define("BOUNCED_DEL_MESSAGES", "Automatisches Löschen aller zurückgewiesenen und überprüften Nachrichten vom Server");
	define("BOUNCED_MAX", "Max. Anzahl Nachrichten");
	define("BOUNCED_AT_TIME", "auf alle anwenden");
	define("BOUNCED_START", "Mailbox auf zurückgewiesene E-Mails überprüfen");
	
	define("YES", "Ja");
	define("NO", "Nein");
	define("DATA_ERROR", "FEHLER: Angeforderte Daten sind nicht vorhanden...<br><br><a href='index.php'>Klicken Sie hier, um das Dashboard zu öffnen</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "Server, um Mail an Empfänger aus Abonnenten-Widget zu senden");
    define("TESTING_TEMPLATE", "Testvorlage");
    define("TESTING_TEMPLATE_INFO", "Sendet die Vorlage an die eingegebene E-Mail weiter unten. Variablen werden nicht ersetzt.");
    define("TESTING_CHOOSE_SERVER", "Wählen Sie den Versandserver aus");
    define("ERRORS", "Fehler");
    define("TEST", "Testen");
    
    /*v.1.16*/
    define("COPY", "Kopieren");
    define("COPYING", "Bewältigung");
    define("CHECK", "Prüfen");
    define("DATA_VERIFY", "Datenintegritätsprüfung");
    define("DATA_VERIFY_QUESTION", "Sind Sie sicher, dass Sie die Datenintegrität überprüfen möchten?");
    define("DATA_VERIFY_DESCRIPTION", "Dieser Vorgang kann einige Minuten dauern, er hängt von der Datenmenge in Ihrer Datenbank ab. <br> Machen Sie es, wenn Sie sicher sind, dass diese Kampagne beendet ist und auf dieser Liste nicht sichtbar ist.");
    define("DATA_VERIFY_BUTTON", "Die Datenintegrität überprüfen");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Empfänger anhand ausgewählter Tags filtern (OR&nbsp;query)");
    define("REC_QUERY_AND", "Filterempfänger sind ALLE ausgewählten Tags (AND&nbsp;query)");
    define("REC_RESET", "Abfrage zurücksetzen");
    define("REC_BUTTON_DELETE", "Löschen Sie die Empfänger");
    define("CSV_ST_1", "Bereiten Sie die Daten gemäß der Formel vor:");
    define("CSV_COL_NO", "Spaltennummer");
    define("CSV_REQ", "erforderlich");
    define("CSV_OPT", "wahlweise");
    define("CSV_ADDR", "E-Mail-Addresse");
    define("CSV_NAME", "Vorname und Nachname");
    define("CSV_TAGS", "tags");
    define("CSV_TAGSDESC", "muss in der Datenbank muss durch einen einzelnen Raum getrennt sein");
    define("CSV_COMMENT", "Bemerkungen");
    define("CSV_DESC1", "Speichern Sie die Tabelle als CSV");
    define("CSV_DESC2", "Begrenzer");
    define("CSV_MAXLINE", "maximale CSV-Zeilenlänge");
    define("CSV_FORMDESC", "Laden Sie eine vorbereitete CSV-Datei mithilfe des folgenden Formulars hoch");
    define("DISABLE_EDITOR", "Editor deaktivieren");
    define("ENABLE_EDITOR", "Editor aktivieren");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "Importieren Sie E-Mails über die DB-Bridge");
    define("TITLE_IMPORT", "Empfänger importieren");
    define("SUBTITLE_IMPORT", "Datenbankbrücke - Quellparameter");
    define("LIST_TITLE_IMPORT", "Importieren Sie Empfänger aus anderen Datenbanken");
    define("ADD_NEW_BRIDGE", "Neue Brücke hinzufügen");
    define("IMPORT_RECIPIENTS", "Empfänger importieren");
    define("IMPORT_BRIDGE_DESC", "Brückenbeschreibung importieren");
    define("CONFIRM_BRIDGE_DEL", "Datenbankverbindung löschen");
    define("IMPORTING_BRIDGE_REC", "Empfänger importieren");
    define("CHOOSEN_BRIDGE", "Gewählte Brücke für den Import");
    
    define("FORM_BRIDGE_DESC", "Brückenbeschreibung importieren");
    define("BRIDGE_TABLE", "Name der Quellentabelle");
    define("BRIDGE_COL_NAME", "Quellspalte für den Empfängernamen");
    define("BRIDGE_COL_NAME_INFO", "wird in das Feld Empfängername importiert");
    define("BRIDGE_COL_MAIL", "Quellspalte für die E-Mail-Adresse");
    define("BRIDGE_COL_MAIL_INFO", "wird in das E-Mail-Feld importiert");
    define("BRIDGE_COL_DESC", "Quellspalte für die Beschreibung des Empfängers");
    define("BRIDGE_COL_DESC_INFO", "wird in das Beschreibungsfeld importiert");
    define("BRIDGE_CHECK_CON", "Überprüfen Sie die Datenbankverbindung");
    define("BRIDGE_WAITING", "Warten auf Test...");
    define("BRIDGE_ADD_NAME", "Zusätzlicher Empfängername");
    define("BRIDGE_ADD_NAME_INFO", "wird nach der Quellennamensspalte hinzugefügt");
    define("BRIDGE_ADD_DESC", "Zusätzliche Empfängerbeschreibung");
    define("BRIDGE_ADD_DESC_INFO", "wird nach der Spalte der Quellenbeschreibung hinzugefügt");
    define("BRIDGE_OVERRIDE", "Bestehende Empfänger überschreiben");
    define("BRIDGE_OVERRIDE_O1", "update - Korrekter Zielempfänger gemäß neuer Quelle");
    define("BRIDGE_OVERRIDE_O2", "ignorieren - nichts tun, wenn der Zielempfänger bereits existiert");
    define("BRIDGE_TAGS", "Verfügbare Tags");
    define("BRIDGE_FILL_FIELDS", "füllen Sie alle erforderlichen Felder vor dem Testen aus...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "Import läuft, bitte warten...");
    define("BRIDGE_TEST_OK", "Ihre Verbindungsbrücke funktioniert ordnungsgemäß");
    define("BRIDGE_IMPORT_OK1", "Import abgeschlossen Aktualisiert:");
    define("BRIDGE_IMPORT_OK2", " Eingefügt:");
    define("TABLE", "Tabelle ");
    define("COLUMN", "Spalte ");
    define("NOT_IN_DB", " existiert nicht in der Datenbank ");
    define("NOT_IN_TABLE", " existiert nicht in der Tabelle ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "Geben Sie hier Ihren Geolocation-API-Key ein");
    define("SETTINGS_API_GEO_LINK_INFO", "Klicken Sie hier, um den neuen Geolocation-API-Key zu erhalten");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Verwenden Sie https");
    define("HTTPS_USAGE_INFO", "Wenn Sie https verwenden, werden alle Links mit https generiert");
    define("TEMPLATE_STATISTICS", "Template statistics: ");
    define("TEMPLATE_CHARS", "Anzahl der Buchstaben: ");
    define("TEMPLATE_USAGE", "Verwendung: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Anmeldeformular registrieren Token ");
    define("WIDGET_EMAIL_TOKEN", "Abonnement-E-Mail-Registrierungs-Token ");
    
    /*v.1.22*/
    define("WEBSITE", "Webseite");
    define("WIDGET_WEBSITE_SHOW", "URL-Feld des Empfängers anzeigen");
    define("VERIFIED", "Verifiziert");
    define("VERIFY", "Überprüfen");
    define("C_PREPARED", "vorbereitet und warten");
    define("C_AJAX_PROGRESS", "vorbereitet und warten");
    define("C_FINISHED", "fertig");
    define("C_BG_PROGRESS", "Hintergrund wird gesendet");
    define("C_PAUSED", "hielt inne");
    define("C_CRON", "cron wird gesendet");
    define("B_VER", "Bulk-Überprüfung");
    define("B_RV", "Überprüfung von Massenempfängern");
    define("B_SEND1", "Sind Sie sicher, dass Sie senden möchten");
    define("B_SEND2", "Empfänger zur Überprüfung");
    define("B_CHECK_LIST", "Überprüfen Sie die Bulk-Bestätigungslisten");
    define("B_VER_INFO", "Ihre Sammelschecks sind in Ihrem emailable.com-Konto verfügbar");
    define("B_VER_IN_PROG", "Überprüfung läuft");
    define("B_VER_SENT", "Empfänger zur Massenprüfung gesendet");
    define("B_V_TITLE", "Bulk-E-Mail-Überprüfungen");
    define("B_V_TITLE2", "gesendete Listen");
    define("BUTTON_CHECK_STATUS", "Status überprüfen");
    define("BUTTON_DOWN_UP", "Aktualisierung herunterladen");
    define("V_ID", "ID bestätigen");
    define("V_QTY", "Menge zu überprüfen");
    define("V_DATE", "Sendedatum");
    define("V_MESSAGE", "Zustand");
    define("V_PERC", "% Komplett");
    define("V_WORKING", "Arbeiten");
    define("RESPONSE", "Antwort");
    define("V_UPDATED_INFO", "Empfänger aktualisiert, Details überprüfen");
    define("SETTINGS_API_THECHECKER", "Klicken Sie hier, um den API-Schlüssel für emailable.com zu erhalten");
    define("SETTINGS_API_DESCRIPTION", "Lass uns die Bounces töten! <br>Wenn Sie auf die Schaltfläche unten klicken, erhalten Sie bei Ihrem ersten Einkauf <b>30% KOSTENLOSE EXTRAKONTROLLEN</b> und bei jedem Einkauf, den Sie tätigen, 30% Bonus (in bar oder per Scheck) für immer!");
    define("EC_DATA", "Exportieren Sie alle Kampagnendaten");
    define("EC_DATA1", "Kampagnendaten exportieren");
    define("EX_OPENED_BUTTON", "Empfänger, die geöffnet haben");
    define("EX_OPENED_DESC", "Kampagnenempfänger exportieren, die Kampagnen-E-Mails geöffnet haben");
    define("EX_NOT_OPENED_BUTTON", "Empfänger, die nicht geöffnet haben");
    define("EX_NOT_OPENED_DESC", "Kampagnenempfänger exportieren, die keine Kampagnen-E-Mail geöffnet haben");
    define("EX_UNSUBSRIBED_BUTTON", "Empfänger, die sich abgemeldet haben");
    define("EX_UNSUBSRIBED_DESC", "Kampagnenempfänger exportieren, die sich von der Kampagne abgemeldet haben");
    define("EX_CLICKED_BUTTON", "Empfänger, die geklickt haben");
    define("EX_CLICKED_DESC", "Kampagnenempfänger exportieren, die auf den Link in der Kampagnen-E-Mail geklickt haben");
    define("EX_ALL_BUTTON", "Alle Empfängerdaten");
    define("EX_ALL_DESC", "Exportieren Sie alle Empfängerdaten der aktuellen Kampagne");
    define("EX_COUNTRY_BUTTON", "Empfängerländer");
    define("EX_COUNTRY_DESC", "Exportieren Sie alle Länder der aktuellen Kampagne");
    define("EX_CITY_BUTTON", "Empfängerstädte");
    define("EX_CITY_DESC", "Exportieren Sie alle Städte der aktuellen Kampagne");
    define("EX_BROWSER_BUTTON", "Empfänger-Browser");
    define("EX_BROWSER_DESC", "Exportieren Sie alle Browser der aktuellen Kampagne");
    define("SETTINGS_CHARSET", "Stellen Sie Ihren Zeichensatz für den Datenexport ein");
    define("MENU_BULK", "Bulk-Überprüfungen");
    define("B_CONFIRM", "Bestätige Massenlöschung von emailable.com");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Empfänger aktualisieren. Wenn eine E-Mail-Adresse in die Datenbank importiert wird, aktualisieren Sie sie mithilfe der Daten in der CSV-Datei.");
    define("TAGS_MANAGER_TITLE", "Empfänger-Tags-Manager, ausgewählte E-Mails: ");
    define("TAGS_SELECT_ACTION", "Wählen Sie Ihre Aktion:");
    define("TAGS_MANAGER_ADD", "Tags zu ausgewählten Empfängern hinzufügen");
    define("TAGS_MANAGER_REMOVE", "Tags von ausgewählten Empfängern entfernen");
    define("TAGS_SELECT", "Wählen Sie Ihre Tags aus:");
    define("SAVE_CHANGES", "Änderungen speichern");
    define("NOT_SELECTED_TAGS", "Wählen Sie zuerst die Empfänger aus");
    define("TM_BUTTON", "Manager für Bulk-Tags");
    define("WAITING", "warten...");
    define("MULTI_SMTP", "Multi SMTP");
    define("MULTI_CHECK_DESC", "Überprüfen Sie, ob Sie die Multi-SMTP-Sendefunktion verwenden möchten");
    define("MULTI_CHOOSE", "Wählen Sie SMTP-Server");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Schwarze Liste");
    define("BL1", "Liste der nicht zugelassenen Domains und IPs");
    define("BL2", "blockierte böswillige Adressen für das Abonnement");
    define("BL3", "Deine schwarze Liste");
    define("B_VALUE", "Wert");
    define("B_TYPE", "Type");
    define("MENU_ADD_BL", "Neuen Eintrag hinzufügen");
    define("B_DOMAIN", "Domain");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "Hier können Sie eine Liste bösartiger Adressen in Ihre Blacklist importieren <small>(Jeder Datensatz muss in einer separaten Zeile stehen)</small>");
    define("B_DELETE_ALL", "Schwarze Liste löschen");
    define("B_DELETE_QUESTION", "Sind Sie sicher, dass Sie die gesamte schwarze Liste löschen möchten?");
    define("B_EXPORT", "Schwarze Liste exportieren");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM die Einstellungen");
    define("DKIM_USE", "verwenden DKIM");
    define("DKIM_DOMAIN", "Domainnamen signieren");
    define("DKIM_PRIVATE", "Pfad der privaten Schlüsseldatei");
    define("DKIM_SELECTOR", "Normalerweise wird die Auswahltaste in Ihrem DNS-TXT-Eintrag eingerichtet");
    define("DKIM_PASS", "Wird verwendet, wenn Ihr Schlüssel verschlüsselt ist");
    define("DKIM_IDENTITY", "Normalerweise wird die E-Mail-Adresse als Quelle der E-Mail verwendet");
    
    define("ERROR", "Error:");
    define("WARNING", "WARNUNG!");
    define("D_MODE", "Änderungen und einige Funktionen sind im DEMO-Modus nicht verfügbar.");
    define("S_DIS", "Senden deaktiviert, bis Sie Ihren Kaufcode eingeben");
    define("HERE", "hier");
    define("PLIK", "die datei");
    define("NOT_WR", "ist nicht beschreibbar. Einstellungen werden nicht gespeichert. Ändern Sie die Dateiberechtigungen vor dem Speichern.");
    define("EPC", "Envato-Kaufcode");
    define("EVALIDEPC", "Geben Sie einen gültigen Kaufcode ein");
    define("NO_ADMIN_MAIL", "Aktualisieren Sie zuerst die E-Mail-Adresse des Administrators in den Einstellungen.");
    
    define("SMTP_LABEL", "Debug-Ebene");
    define("SMTP_0", "Debugging deaktivieren");
    define("SMTP_1", "Vom Client gesendete Nachrichten ausgeben");
    define("SMTP_2", "als 1 plus vom Server empfangene Antworten (dies ist die nützlichste Einstellung)");
    define("SMTP_3", "wie 2, plus weitere Informationen über die anfängliche Verbindung - diese Stufe kann bei der Diagnose von STARTTLS-Fehlern helfen");
    define("SMTP_4", "wie 3, plus noch Informationen auf niedrigerer Ebene, sehr ausführlich, nicht zum Debuggen von SMTP verwenden, nur Probleme auf niedriger Ebene ");
    
    define("SMTP_SENDER_FORCE", "Erzwingen Sie in Kampagnen für diesen Server immer diesen Absender");
    define("SMTP_SENDER_MAIL", "E-Mail-Adresse des Absenders");
    define("SMTP_SENDER_DESCRIPTION", "Beschreibung des Absenders");

    
