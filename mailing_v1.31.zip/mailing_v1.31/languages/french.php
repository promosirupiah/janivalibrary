<?php
	/*login page*/
	define("LANG","fr_FR");
	define("LOGIN_TITLE","Système d'envoi");
	define("LOGIN_SIGN_IN","Veuillez vous connecter");
	define("LOGIN","S'identifier");
	define("LOGIN_PASS","Mot de passe");
	define("LOGIN_SIGN_IN_BUTTON","se connecter");
	define("LOGIN_FAILED","Connexion et / ou mot de passe erronés!");
	define("INSTALLING_SYSTEM","Configuration du système");
	define("INSTALLING_CONNECTED","Correctement connecté à la base de données");
	define("INSTALLING_ADD_TABLES","Ajouter des tables");
	define("INSTALLING_ADD_TABLES_DESC","Cliquez ici pour ajouter des tables et commencer à travailler avec le système");
	
	/*left menu*/
	define("WELCOME","Bienvenue,");
	define("WELCOME_ASK","Que faisons-nous?");
	define("MAIN_MENU","Menu principal");
	define("START","Démarrer");
	define("DASHBOARD","Tableau de bord");
	define("EMAIL_ADRESSES","Adresses mail");
	define("MENU_RECIPIENT_LIST","Liste des destinataires");
	define("MENU_ADD_RECIPIENT","Ajouter un destinataire");
	define("MENU_CSV_IMPORT","Importer des courriels à partir d'un fichier CSV");
	define("MENU_CSV_EXPORT","Exporter des e-mails vers un fichier CSV");
	define("MENU_TAG_LIST","Liste des tags");
	define("MENU_ADD_TAGS","Ajouter des balises");
	define("MENU_SENDERS_LIST","Liste des expéditeurs");
	define("MENU_ADD_SENDER","Ajouter un expéditeur");
	define("MENU_TEMPLATES","Disposition des e-mails");
	define("MENU_TEMPLATES_LIST","Liste des modèles");
	define("MENU_TEMPLATES_ADD","Ajouter un nouveau modèle");
	define("MENU_TEMPLATES_ATTACHMENTS","Pièces jointes");
    define("MENU_TEMPLATES_THUMBNAILS","Vignettes");
	define("MENU_CAMPAIGNS","Vos campagnes");
	define("MENU_CAMPAIGNS_ADD","Préparer une nouvelle campagne");
	define("MENU_CAMPAIGNS_WAITING_LIST","Campagne de liste d'attente");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Campagnes en cours");
	define("MENU_CAMPAIGNS_SENT","Liste des campagnes envoyées");
	define("MENU_SYSTEM_CONFIGURATION","Configuration du système");
	define("MENU_SETTINGS","Paramètres");
	define("MENU_LOGIN","S'identifier");
	define("MENU_DB","Base de données");
	define("MENU_SYSTEM_PARAMS","Paramètres du système");
	define("MENU_SPECIALS","Compléments spéciaux");
	define("MENU_ADDONS","Des extras utiles");
	define("MENU_CLEAR_DB","Effacer la base de données");
	define("MENU_IMPORT_TEMPLATES","Importer des exemples de modèles");
	define("MENU_IMPORT_DATA","Importer des données d'échantillon");
	define("MENU_FAQ","Questions et réponses");
	define("MENU_ABOUT","Sur");
    define("MENU_SMTP_PARAMS","Configuration SMTP");
    define("MENU_UNSUBSCRIBED","Liste des abonnés");
    define("MENU_UNSUBSCRIBED_LIST","Liste des destinataires");
    define("MENU_DOCS","Documentation");
    define("MENU_SUBSCRIBE_WIDGET","Abonnez le widget");
    define("MENU_BOUNCED","Vérifier les messages renvoyés");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","Base de données de courriel");
	define("D_EMAIL_ADD_NEW","Ajouter un nouvel e-mail");
	define("D_EMAIL_TEMPLATES","Modèles de courrier électronique");
	define("D_EMAIL_TEMPLATES_ADD","Ajouter modéle");
	define("D_EMAIL_SENT","Courriels envoyés");
	define("D_EMAIL_EFFICIENCY","Efficacité");
	define("D_EMAIL_UNSUBSCIBERS","Désabonnement");
	define("D_CAMPAIGNS","Campagnes");
	define("D_CAMPAIGNS_ADD","Nouvelle campagne");
	define("D_CAMPAIGNS_WAITING","Prêt pour l'envoi");
	define("D_CAMPAIGNS_SENT","Terminé");
	define("D_STATISTICS","Statistiques");
	define("D_THIS_YEAR","Vos campagnes publicitaires cette année");
	define("D_CHECK_ALL","Vérifie tout...");
	define("JAN","jan");
	define("FEB","fév");
	define("MAR","mar");
	define("APR","avr");
	define("MAY","mai");
	define("JUN","jui");
	define("JUL","jul");
	define("AUG","aoû");
	define("SEP","sep");
	define("OCT","oct");
	define("NOV","nov");
	define("DEC","déc");
	define("D_PREPARED_OVERALL","Campagnes préparées");
	define("D_SENT_OVERALL","envoyé");
	define("D_HOW_TO","Comment cela fonctionne?");
	define("D_HOW_STEP_1_TITLE","1. Base de données de courriel");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Ajouter des balises</a> Cela vous aidera à trouver des clients et vous aidera à préparer facilement une campagne publicitaire. Prochain <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>Ajouter des emails</a> À votre système de base de données. Vous pouvez aussi <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>Télécharger le fichier CSV</a> avec des courriels à votre base de données.");
	define("D_HOW_STEP_2_TITLE","2. Expéditeurs");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Ajouter un expéditeur</a> Vous pouvez décider de qui vos clients recevront un email.");
	define("D_HOW_STEP_3_TITLE","3. Modèles de courrier électronique");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Ajouter un modèle</a> Préparer un nombre illimité de modèles, avec un nombre illimité de pièces jointes.");
	define("D_HOW_STEP_4_TITLE","4. Campagnes publicitaires");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Ajouter une nouvelle campagne</a> Préparer des campagnes illimitées. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Envoyer une campagne</a> A n'importe quel moment.");
	define("D_HOW_STEP_5_TITLE","5. Suivre les statistiques");
	define("D_HOW_STEP_5_DESC","Ici, vous apprendrez quelles sont les campagnes les meilleures, comment et quand la campagne a été préparée et combien est envoyé et quelle est leur efficacité (c'est-à-dire combien de personnes ont ouvert votre courriel et combien de personnes n'ont pas été exclues de la campagne).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Changer de connexion");
	define("CHANGE_PASS","Changer le mot de passe");
	define("CLEAR_DATABASE","Effacer la base de données");
	define("LOGOUT","Fermer");
	define("ABOUT","Sur");
	
	/*vertical buttons*/
	define("CONFIG","Configuration");
	define("CONFIG_TOOLTIP","Configuration du système");
	define("MEDIA_MANAGER","Gestionnaire de pièces jointes");
	define("RECIPIENT","Destinataires");
	define("RECIPIENT_TOOLTIP","Gestion des e-mails");
	define("RECIPIENT_EDIT","Modifier les détails");
	define("RECIPIENT_ADD_NEW","Ajouter un nouveau");
	define("MENUS","Gestion de menus");
	define("MENUS_TOOLTIP","Configuration du menu");
	define("TEMPLATES","Modèle");
	define("TEMPLATES_TOOLTIP","Configuration du modèle");
	define("HELP","Aidez-moi");
	define("HELP_TOOLTIP","Comment cela fonctionne");
	
	define("FILE_MANAGEMENT","Pièces jointes");
	define("CSV_IMPORT","Importation de courriels de fichiers CSV");
	
	define("PERSON","Personne");
	define("EMAIL","Adresse e-mail");
	define("TAGS","Mots clés");
	define("TAGS_LIST","Liste des tags");
	define("TAGS_ADD","Ajouter des tags");
	define("TAGS_ADD_NEW","Mots-clés ajoutés");
	define("TAGS_ADD_EDIT","Édition Tag");
	define("TAGS_NAME","Nom du tag");
	define("TAGS_DESCRIPTION","La description");
	define("TAGS_NAME_PLACEHOLDER","Entrez le nom du tag...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","Saisir la description de la balise...");
	define("TAGS_USED","Utilisé (fois)");
	define("TAGS_INFO","Mots-clés pour un email");
	
	define("RECIPIENT_LIST","Liste de diffusion");
	define("RECIPIENT_NAME","Nom du destinataire");
	define("RECIPIENT_NAME_PLACEHOLDER","Entrez le nom complet");
	define("RECIPIENT_MAIL","Email");
	define("RECIPIENT_MAIL_PLACEHOLDER","Entrez votre email");
	define("RECIPIENT_ONLY_TXT","Uniquement les e-mails TXT");
	define("RECIPIENT_DESCRIPTION","La description");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","La description...");
	define("RECIPIENT_DB","Votre base de données de courriels");
	define("RECIPIENT_DETAILS_EDIT","Modifier les détails du destinataire");
	define("RECIPIENT_DETAILS_ADD","Ajout d'une nouvelle adresse électronique");
	define("RECIPIENT_IMPORT_CSV","Importer des courriels à partir d'un fichier CSV");
	define("RECIPIENT_PREPARE_CSV","Préparer un fichier CSV avec les lignes suivantes");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Pour ajouter de nouveaux enregistrements à partir d'un fichier Excel, suivez les étapes ci-dessous");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","Télécharger le modèle CSV");

	define("RECIPIENT_UPLOAD_CSV_NAME","Importer un fichier CSV");
	define("RECIPIENT_NOT_CSV","<b>Ce n'est pas un fichier CSV!!!</b><br/>");
	define("RECIPIENT_ROW","Rangée ");
	define("RECIPIENT_WRONG_EMAIL"," - Adresse e-mail incorrecte, saisie: ");
	define("RECIPIENT_EMAIL_EXIST"," - Cette adresse est déjà dans la base de données: ");
	define("RECIPIENT_EMAIL_LACK"," - Absence d'une adresse e-mail");
	define("RECIPIENT_EMAIL_IN_DB"," - Cette adresse e-mail existe déjà dans le fichier CSV en ligne ");
	define("RECIPIENT_TAG_NOT_EXIST"," - Aucun tag: ");
	define("RECIPIENT_CSV_ERRORS","Erreurs dans le fichier ");
	define("RECIPIENT_CSV_ADDED","Ajoutée ");
	define("RECIPIENT_CSV_ADDED_FROM"," Adresses email du fichier ");
	define("RECIPIENT_CSV_EXPORT","Exporter des adresses électroniques vers un fichier");
	define("RECIPIENT_CSV_EXPORT_CHK","Sélectionnez les champs à exporter:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Adresse e-mail du destinataire");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Prénom et nom");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Tags - séparés par un seul espace");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","commentaires");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Recevoir des messages texte uniquement");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Date d'introduction");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Date de modification");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","exportation");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Ignorer la vérification des erreurs CSV (vérifiez si le fichier contient plus de 1000 emails - les fichiers plus volumineux requièrent une grande quantité de mémoire sur le serveur)");
	
	define("SAVE","Sauvegarder");
	define("CANCEL","Annuler");
	define("DELETE","Effacer");
    define("EDIT","Modifier");
	define("CREATED","Créé");
	define("MODIFIED","Modifié");
	define("SEND","Envoyer");
	define("SENT","Envoyé");
	define("PROGRESS","La progression");
	define("RESUME","Restaurer");
	define("CLOSE","Fermer");
	define("CHANGES_SAVED","Les changements ont été effectués avec succès");
	
	define("DELETING","Suppression");
	define("DELETING_CONFIRM_QUESTION","Êtes-vous sûr de vouloir désinstaller?");
	
	define("DATATABLE_LENGTHMENU", "Afficher _MENU_ enregistrements par page");
	define("DATATABLE_ZERORECORDS", "Rien trouvé - désolé");
	define("DATATABLE_INFO", "Affichage de la page _PAGE_ de _PAGES_");
	define("DATATABLE_INFOEMPTY", "Aucun enregistrement disponible");
	define("DATATABLE_INFOFILTERED", "(Filtré _TOTAL_ de _MAX_ total des enregistrements)");
	define("DATATABLE_SEARCH", "Chercher");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Ajouter un nouveau modèle");
	define("TEMPLATES_LIST", "Liste des modèles");
	define("TEMPLATES_TITLE", "Modèles disponibles");
	define("TEMPLATES_TITLE_ADD", "Ajouter une nouvelle présentation");
	define("TEMPLATES_TITLE_EDIT", "Modification de la mise en page");
	define("TEMPLATES_NAME", "Nom de la mise en page");
	define("TEMPLATES_MAIL_TITLE", "Titre de l'email");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Entrez le titre du courrier électronique");
	define("TMPLATES_HTML", "Version HTML");
	define("TMPLATES_TXT", "Version texte");
	define("TMPLATES_VARIABLES", "Variables de modèle disponibles (consultez <a href='docs/index.html#variables' target='_blank'> docs </a> pour plus de détails):");
	define("TEMPLATES_THUMB", "La vignette");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Edition de miniatures");
	define("THUMBNAIL_MEDIA_LIST", "Liste des vignettes disponibles");
	
	define("MEDIA_FILENAME", "Nom de fichier");
	define("MEDIA_FILENAME_DESCRIPTION", "Description du fichier");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Temps de téléchargement");
	define("MEDIA_TEMPLATES", "Utilisé comme pièce jointe");
	define("MEDIA_LIST", "Liste des pièces jointes disponibles");
	define("MEDIA_ADD_FILES", "Ajouter des fichiers");
	define("MEDIA_BROWSE", "Feuilleter");
	define("MEDIA_UPLOAD", "Télécharger");
	
	define("CAMPAIGN_MENU", "Nouvelle campagne");
	define("CAMPAIGN_PREPARE", "Préparer la campagne");
	define("CAMPAIGN_RECIPIENTS", "Choisir des destinataires");
	define("CAMPAIGN_TEMPLATES", "Choisir la disposition");
	define("CAMPAIGN_SENDERS", "Choisir l'expéditeur");
	define("CAMPAIGN_CONFIRM", "Enregistrer la campagne");
	define("CAMPAIGN_SEND", "Envoyer une campagne");
	define("CAMPAIGN_NAME", "Nom de la campagne");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Saisissez le nom de la campagne");
	define("CAMPAIGN_RECIPIENT_QTY", "Destinataires");
	define("CAMPAIGN_TEMPLATE_NAME", "Disposition");
	define("CAMPAIGN_SENDER", "Expéditeur");
	define("CAMPAIGN_CREATED_DATE", "Préparé");
	define("CAMPAIGN_STEP_1", "1. Sélectionnez vos destinataires (utilisez le champ 'Rechercher' sur la table)");
	define("CAMPAIGN_STEP_2", "2. Enregistrez votre campagne");
	define("CAMPAIGN_SELECT", "Sélectionner une campagne pour le publipostage");
	define("CAMPAIGN_FORM_SELECT", "sélectionner...");
	define("CAMPAIGN_CURRENT_STATUS", "État de la campagne en cours");
	define("CAMPAIGN_SENT_NOW", "Envoie le maintenant");
	define("CAMPAIGN_SENT_BUTTON", "Cliquez ici pour commencer l'envoi");
	define("CAMPAIGN_RESUME_BUTTON", "Cliquez ici pour reprendre l'envoi");
	define("CAMPAIGN_SERVER_CONNECTING", "Connexion au serveur, veuillez patienter...");
	define("CAMPAIGN_SENDING", "envoi");
	define("CAMPAIGN_PLEASE_WAIT", "S\'il vous plaît, attendez...");
	define("CAMPAIGN_SENT", "<b>CAMPAGNE ENVOYÉE</b> Destinataires: ");
	define("CAMPAIGN_IN_PROGRESS", "Campagnes en cours...");
	define("CAMPAIGN_COMPLETED", "Campagnes envoyées");
	define("CAMPAIGN_LEFT", "À gauche pour envoyer");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Supprimer tous les désabonnés");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "Cette action supprimera tous les unsubscribers de votre base de données.");
	define("CAMPAIGN_BG_PROCESS", "Processus en arrière-plan");
	define("CAMPAIGN_BG_PROCESS_INFO", "Envoyer en tant que processus en arrière-plan (vous pouvez fermer le navigateur)");
	define("CAMPAIGN_WHEN_FINISH", "Email une fois terminé");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "Où envoyer une notification");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Veuillez confirmer l\'envoi d\'arrière-plan!");
    
    define("HOUR", "heure");
    define("OPENS", "Ouvre");
    define("BOUNCED", "Rebondi");
    define("CLICKED", "Cliqué");
    define("UNIQUE_CLICKS", "Clics uniques");
    define("TOTAL_CLICKS", "Nombre total de clics");
	
	define("SENDER_LIST", "Liste des expéditeurs");
	define("SENDER_ADD", "Ajouter un expéditeur");
	define("SENDER_NAME", "Nom de l'expéditeur");
	define("SENDER_NAME_PLACEHOLDER", "Entrez le nom de l'expéditeur");
	define("SENDER_EMAIL", "Adresse e-mail de l'expéditeur");
	define("SENDER_EMAIL_PLACEHOLDER", "Saisissez l'adresse de l'expéditeur");
	define("SENDER_TITLE_ADD", "Ajouter un expéditeur");
	define("SENDER_TITLE_EDIT", "Modifier l'expéditeur");
	define("SENDER_EMAIL_TITLE", "Adresse e-mail de l'expéditeur");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Entrez l'adresse e-mail de l'expéditeur");
	
	define("SETTINGS", "Paramètres");
	define("SETTINGS_LOGIN_TITLE", "Entrer de nouvelles informations d'identification");
	define("SETTINGS_LOGIN_LABEL", "Entrer une nouvelle connexion");
	define("SETTINGS_LOGIN_PLACEHOLDER", "Entrer login");
	define("SETTINGS_CURR_PASS", "Mot de passe actuel");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "Entrer le mot de passe");
	define("SETTINGS_NEW_PASS", "Nouveau mot de passe");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "Nouveau mot de passe");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "confirmer");
	define("SETTINGS_DB_PARAMS", "Configurer la base de données");
	define("SETTINGS_DB_HOST", "Base de données hôte");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "ex.: localhost");
	define("SETTINGS_DB_USER", "Utilisateur de la base de données");
	define("SETTINGS_DB_USER_PLACEHOLDER", "ex.: root");
	define("SETTINGS_DB_PASSWORD", "Mot de passe de base de données");
	define("SETTINGS_DB_NAME", "Nom de la base de données");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "ex.: mailing");
	define("SETTINGS_GLOBAL", "Paramètres globaux");
	define("SETTINGS_LANG", "Langue du système");
	define("SETTINGS_LIMIT", "Configurer la limite de courrier électronique par heure");
	define("SETTINGS_LIMIT_PLACEHOLDER", "défaut: 1000");
	define("SETTINGS_TRACKING", "Activer le suivi des e-mails");
	define("SENDING_METHOD", "Méthode d'envoi");
	define("SETTINGS_UNSUBSCRIBED", "Suppression automatique désinscrit");
	define("SETTINGS_UNS_INFO", "Email sera automatiquement supprimé de la liste des destinataires lorsque l'utilisateur clique sur votre lien unsubscibe");
	define("SETTINGS_TRACK_INFO", "Invisible tag img sera ajouté pour suivre votre destinataire");
	define("SETTINGS_API_LABEL", "Cartes Google <br> clé d'API");
	define("SETTINGS_API_PLACEHOLDER", "Entrez votre clé google maps API v.3 ici");
	define("SETTINGS_API_LINK_INFO", "Cliquez ici pour obtenir une nouvelle clé API");
	define("SETTINGS_ADMIN_MAIL", "Courriel administrateur");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "Courrier électronique admin pour les notifications système");
    define("SETTINGS_PHP_TIMEOUT", "PHP timeout (secondes)");
    
	define("SMTP_SERVER_DESCRIPTION", "Serveur SMTP, assurez-vous d'ajouter");
    define("SMTP_LIST", "Liste de serveurs");
    define("SMTP_ADD", "Ajout d'un nouveau serveur");
    define("SMTP_EDIT", "Serveur d'édition");
    define("SMTP_INFO", "Vos serveurs SMTP");
    define("SMTP_ADD_BUTTON", "Cliquez pour ajouter un nouveau serveur SMTP");
    define("SMTP_NAME", "Nom de la connexion");
    define("SMTP_NAME_PLACEHOLDER", "ex.: Ma meilleure connexion");
    define("SMTP_HOST", "Adresse SMTP");
    define("SMTP_HOST_PLACEHOLDER", "Serveur principal et de sauvegarde (séparateur ';' pour sauvegarde)");
    define("SMTP_PAUTH", "Authentification");
    define("SMTP_PAUTH_PLACEHOLDER", "Activer l'authentification SMTP");
    define("SMTP_VERIFY_PEER", "Activer la vérification des certificats SSL / TLS");
    define("SMTP_FORCE_SMTP", "Force l'utilisation du SMTP");
    define("SMTP_USERNAME", "Nom d'utilisateur SMTP");
    define("SMTP_USERNAME_PLACEHOLDER", "Nom d'utilisateur SMTP");
    define("SMTP_LOGIN", "Connexion SMTP");
    define("SMTP_LOGIN_PLACEHOLDER", "Connexion au serveur SMTP");
    define("SMTP_PASSWORD", "Mot de passe SMTP");
    define("SMTP_PASSWORD_PLACEHOLDER", "Mot de passe SMTP");
    define("SMTP_REPLYTO", "Répondre au courrier");
    define("SMTP_REPLYTO_PLACEHOLDER", "Définir une autre adresse de réponse");
    define("SMTP_REPLYTONAME", "Répondre au nom");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Définir une réponse alternative au nom");
    define("SMTP_SECURE", "Chiffrement");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> Comme cryptage par défaut");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> Accepté mais non recommandé");
    define("SMTP_PORT", "Port");
    define("SMTP_PORT_PLACEHOLDER", "port de serveur");
    define("SMTP_LIMIT", "Limite par heure");
    define("SMTP_LIMIT_PLACEHOLDER", "défaut: 1000");
    define("CAMPAIGN_SMTP", "Sélectionnez SMTP");
    define("SMTP_TESTING", "Test de connexion SMTP");
    define("SMTP_TESTING_EMAIL", "Adresse pour tester le message");
    define("SMTP_RUN_TEST", "Vérifie ça!");
    define("SMTP_TEST_TXT_TITLE", "Test SMTP à partir du courrier électronique.");
    define("SMTP_TEST_TXT_MESSAGE", "Testez le message de votre connexion SMTP.");
    define("SMTP_TEST_OK", "Le message a été envoyé. Vérifiez votre boîte aux lettres.");
    define("SMTP_TEST_ERROR", "<b>Erreur de publipostage: </b>");
    define("SMTP_BEFORE_USE", "<b>Erreur de publipostage.</b> Vous devez activer la connexion SMTP dans les paramètres avant l'utilisation.");
    define("BOUNCED_INFO", "Les e-mails renvoyés retournent à cette boîte aux lettres");
    define("SMTP_CONFIG", "Configurer votre SMTP pour l'envoi");
    define("IMAP_CONFIG", "Configurer votre IMAP / POP3 pour les rebonds");
    define("SMTP_INFO_SETUP", "Paramètres SMTP");
    define("IMAP_INFO_SETUP", "Paramètres IMAP / POP3");
    define("PROTOCOL", "Protocole");
    define("FOLDER", "Dossier d'accès");
	
	define("STATISTICS", "Statistiques");
	define("STATISTICS_ADV", "Détails avancés");
	define("STATISTICS_TAB_MAP", "Récipients sur la carte (géolocalisation)");
	define("STATISTICS_TAB_DETAILS", "Statistiques détaillées");
	define("STATISTICS_TAB_ACTIONS", "Actions spéciales");
	define("STATISTICS_BACK", "Retour à la liste");
	define("STATISTICS_BUTTON_OPENERS", "Préparez-vous à ouvrir");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Préparer une nouvelle campagne pour tous ceux qui ont ouvert un courriel");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Préparez-vous à l'ouverture des NOT");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Préparez une nouvelle campagne pour tous ceux qui n'ont PAS ouvert un email");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Préparez-vous à vous abonner");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Préparer une nouvelle campagne pour tous les désabonnés, si une option 'Supprimer automatiquement les unsubscribed' dans les paramètres système est activée, les e-mails sont supprimés et rien ne sera ajouté ici");
	define("STATISTICS_BUTTON_FILTERS", "Préparer avec des filtres avancés");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Obtenir la liste de tous les destinataires de cette campagne avec les données collectées et préparer une nouvelle campagne spéciale basée sur des filtres avancés");
	define("STATISTICS_TOP_COUNTRIES", "Top 10 des pays");
	define("STATISTICS_TOP_CITIES", "Top 10 des villes");
	define("STATISTICS_TOP_CLICKERS", "Top 15 clics");
	define("STATISTICS_TOP_SOFTWARE", "Les 15 logiciels les plus populaires");
	define("STATISTICS_OTHER_UA", "Tous les autres agents utilisateurs");
	define("STATISTICS_OTHERS", "Autres");
    
	define("SOFTWARE", "Logiciel");
	define("GEODATA", "Localisation");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='confirmation'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Abandon de la newsletter.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Bonne journée.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Suppression de données inutiles de la base de données");
	define("ADDONS_IMPORT_TITLE", "Ajout de modèles de mailing");
	define("ADDONS_FAQ_TITLE", "Lire avant de demander");
	define("ADDONS_ABOUT_TITLE", "Informations sur le programme et la licence");
	define("ADDONS_IMPORT_DATA_TITLE", "Importer des données d'échantillon dans le système");
	define("ADDONS_IMPORT_BUTTON", "Importer des modèles de courrier électronique");
	define("ADDONS_IMPORT_BUTTON_DESC", "Cela permettra d'importer des exemples de modèles pour le publipostage");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Confirmer l'ajout d'exemples de modèles pour l'envoi");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Confirmez l'ajout de données d'échantillon au système. Toutes les données actuellement saisies seront effacées!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Pourquoi est-il préférable d'avoir propre serveur dédié pour le courrier?</p>
			<p>Tout d'abord, pas de limites. Pour l'hébergement ordinaire, vous pouvez envoyer jusqu'à 1000 courriels par heure et probablement le même montant dans une journée (selon les limites d'hébergement de quelques centaines à quelques milliers d'emails par jour). Sur votre serveur, vous n'avez pas de telles restrictions et pouvez également envoyer des courriels à partir de votre domaine. Vous pouvez également envoyer des e-mails comme si le serveur devait être sous un domaine différent (il est dans ce cas mis les enregistrements dits SPF et le domaine TXT - pour plus de détails, demandez à votre fournisseur d'hébergement).</p>
		</li>
		<li>
			<p>Quels sont les tags?</p>
			<p>Facilitez la recherche d'adresses postales et la préparation d'une campagne publicitaire auprès d'un destinataire spécifique.</p>
		</li>
		<li>
			<p>Comment ajouter le nom du destinataire au modèle de courrier électronique?</p>
			<p>Utilisez la phrase {RECIPIENT_NAME} dans le courrier électronique du modèle de contenu ou dans le titre du courrier du modèle. La phrase sera remplacée par le nom du destinataire e-mail, au cas où les informations ont été ajoutées à l'adresse e-mail du destinataire.</p>
		</li>
		<li>
			<p>Comment ajouter une nouvelle traduction?</p>
			<p>Copiez la référence de fichier english.php, donnez-lui un nom qui décrit votre langue par exemple mylanguage.php et collez dans le même dossier. Corrigez tous les textes contenus dans le nouveau fichier. Veillez à enregistrer le fichier dans UTF-8 sans nomenclature. Le fichier de langue est dans l'annuaire 'languages'.</p>
			<p>Pour ajouter la traduction de l'éditeur WYSIWYG, allez à https://www.tinymce.com/download/language-packages/ - télécharger le langage de fichier approprié et l'enregistrer dans /emailer/libs/tinymce/langs/ dossier.</p>
		</li>
		<li>
			<p>Comment puis-je ajouter des tags à un e-mail?</p>
			<p>Tout d'abord, vous devez ajouter quelques balises <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>en utilisant ce formulaire</a>. Ensuite, lorsque vous ajoutez / modifiez chaque adresse e-mail peut être affecté à n'importe quelle balise. Tous les tags seront ajoutés sous le formulaire pour ajouter / modifier les destinataires.</p>
		</li>
		<li>
			<p>Comment ajouter la possibilité de se désabonner de la réception de messages?</p>
			<p>Utilisez la phrase {UNSUBSCRIBE} dans le lien du contenu du modèle de courrier électronique. La phrase sera remplacée par un lien pour le destinataire particullar. Lorsqu'il clique dessus, le système sauvera dans la base de données des informations sur la décharge de la campagne. L'adresse e-mail ne sera pas supprimée de la base de données. <br>Usage:<br>&lt;a href='{UNSUBSCRIBE}'&gt;Se désabonner de la newsletter&lt;/a&gt;</p>
		</li>
		<li>
			<p>Comment ajouter la fonctionnalité à la vue du navigateur?</p>
			<p>Utilisez la phrase {BROWSER_VIEW} dans le lien du contenu du modèle de courrier électronique. La phrase sera remplacée par un lien pour le destinataire particullar. Quand il / elle va cliquer dessus, le système ouvrira le message dans la fenêtre du navigateur. <br>Usage:<br>&lt;a href='{BROWSER_VIEW}'&gt;Vue du navigateur&lt;/a&gt;</p>
		</li>
		<li>
			<p>Comment ajouter des modèles de courrier électronique prédéfinis?</p>
			<p>30 modèles de mailing, cliquez ici <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>pour ajouter des modèles</a></p>
		</li>
		<li>
			<p>Comment puis-je ajouter des images à des e-mails?</p>
			<p>- En tant que lien absolu vers une image dans des ressources externes, comme:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>Comment fonctionne le suivi des e-mails?</p>
			<p>Pour chaque système de messagerie envoyé, il est possible d'ajouter une balise IMG, laquelle attribut SRC contient le code de suivi pour afficher un message spécifique. Le suivi ne fonctionnera que lorsque le destinataire du courrier accepte d'afficher les images du message reçu.</p>
		</li>
		<li>
			<p>Comment ne pas être un spammeur?</p>
			<p>- Collecter le consentement pour recevoir des messages lors de la création d'une liste de diffusion.</p>
			<p>- Utilisez une variété de contenu pour chaque destinataire, utilisez ex. {RECIPIENT_NAME} pour différencier les sommes de contrôle de votre envoi.</p>
			<p>- Ne pas utiliser les mots-clés comme: sexe, viagra, porno.</p>
			<p>- Ne pas utiliser d'expressions clés telles que: adresse d'une base de données publique, ce n'est pas des informations commerciales à l'esprit, désintéressé Désolé, il ne constitue pas une offre dans le sens si vous ne voulez pas, cliquez ici pour vous désabonner, Achetez-le maintenant - si vous devez utiliser ces expressions telles que vous devriez envisager de les mettre sous la forme de graphiques.</p>
			<p>- N'utilisez pas trop de graphiques, les filtres anti-spam examinent le ratio entre les graphiques et le texte.</p>
			<p>- Le courrier ne doit pas être trop lourd.</p>
			<p>- Moins les meilleurs attachements.</p>
			<p>- Ne pas se faire passer pour un autre domaine.</p>
			<p>- N'envoyez pas d'e-mails à partir d'une adresse e-mail inexistante.</p>
		</li>
		<li>
			<p>Comment augmenter les clics et lire la campagne?</p>
			<p>La plus grande influence sur le contenu que vous envoyez à vos clients et le temps et la fréquence avec laquelle vous le faites. Dans la plupart des cas, le contact ne doit pas être plus fréquent que deux fois par mois. Respectez vos clients et ils ne vous jetteront pas au spam.</p>
		</li>
		<li>
			<p>Comment choisir les adresses pour le courrier?</p>
			<p>À l'aide de balises, saisissez-les séparées par des espaces dans le champ de recherche au-dessus de la table des adresses.</p>
		</li>
		<li>
			<p>Quelles sont les limites de ce système?</p>
			<p>Il n'y a pas de restrictions.</p>
		</li>
		<li>
			<p>Limiter les messages sur le serveur hébergeant?</p>
			<p>Selon les limites d'hébergement allant de quelques centaines à quelques milliers d'emails par jour, vérifiez auprès de votre fournisseur de services.</p>
		</li>
		<li>
			<p>Connexion brisée lors de l'envoi de la campagne?</p>
			<p>Vous pouvez reprendre l'envoi des campagnes, les courriels seront envoyés aux autres destinataires. Chaque email envoyé définit un marqueur unique dans la base de données et la campagne elle-même ne sera pas renvoyée au même destinataire.</p>
		</li>
		<li>
			<p>Exigences relatives aux emails retournés</p>
			<p>Pour activer la prise en charge des emails renvoyés, vous devez décommenter cette ligne dans le fichier php.ini.</p>
			<p>;extension=php_imap.dll</p>
			<p>Les fonctions Imap sont nécessaires pour utiliser les connexions POP3 / IMAP.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Soyez prudent, les actions suivantes nettoient les tables dans la base de données!");
	define("ADDONS_DATA_BE_CAREFULLY", "Attention! Toutes les données seront supprimées et remplacées par des données d'échantillon");
	define("ADDONS_D_AL", "Supprimer toutes les données");
	define("ADDONS_D_AL_DESC", "Efface toutes les données de la base de données");
	define("ADDONS_D_AL_CONF", "Voulez-vous vraiment supprimer toutes les données de la base de données? Toutes les adresses e-mail, les modèles, les pièces jointes et les campagnes seront supprimés..");
	define("ADDONS_D_RE", "Supprimer les destinataires et leurs campagnes");
	define("ADDONS_D_RE_DESC", "Supprime toutes les adresses e-mail dans la base de données et l'historique des campagnes publicitaires");
	define("ADDONS_D_RE_CONF", "Confirmer la suppression de tous les destinataires");
	define("ADDONS_D_CA", "Supprimer uniquement les campagnes");
	define("ADDONS_D_CA_DESC", "Supprime toutes les campagnes publicitaires et leur historique");
	define("ADDONS_D_CA_CONF", "Confirmer la suppression de toutes les campagnes et de leur historique");
	define("ADDONS_D_TE", "Supprimer les modèles uniquement");
	define("ADDONS_D_TE_DESC", "Supprime tous les modèles de courrier électronique et leurs liens avec les campagnes et les pièces jointes");
	define("ADDONS_D_TE_CONF", "Confirmer la suppression de tous les modèles");
	define("ADDONS_D_AT", "Supprimer uniquement les pièces jointes");
	define("ADDONS_D_AT_DESC", "Supprime toutes les pièces jointes");
	define("ADDONS_D_AT_CONF", "Confirmer la suppression de toutes les pièces jointes");
	define("ADDONS_D_SE", "Supprimer uniquement les expéditeurs");
	define("ADDONS_D_SE_DESC", "Supprime tous les expéditeurs envoyés par courriel mais laisse leur ID à des fins statistiques");
	define("ADDONS_D_SE_CONF", "Confirmer la suppression de tous les expéditeurs");
	define("ADDONS_D_TG", "Supprimer uniquement les balises");
	define("ADDONS_D_TG_DESC", "Effacer toutes les balises saisies et leurs relations avec les clients");
	define("ADDONS_D_TG_CONF", "Confirmer supprimer tous les tags");
    
	define("WIDGET_PREPARE", "Préparez votre widget d'abonnement");
	define("WIDGET_OPTIONS", "Options");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Créez votre widget d'abonnement ici");
	define("WIDGET_COMMENT", "Commentaire sur le nouveau destinataire");
	define("WIDGET_COMMENT_PLACEHOLDER", "ex.: de domain.ext (seront enregistrés dans la description du destinataire)");
	define("WIDGET_NAME", "Prénom");
	define("WIDGET_NAME_SHOW", "Afficher le champ du nom du destinataire");
	define("WIDGET_AFTER", "Après avoir envoyé un widget d'abonnement");
	define("WIDGET_AFTER_NOTHING", "ne fais rien");
	define("WIDGET_AFTER_TXT", "Afficher le message texte");
	define("WIDGET_AFTER_REDIRECT", "Redirection vers la page");
	define("WIDGET_TAGS", "Ajouter des balises");
	define("WIDGET_PURE_CODE_TXT", "Code HTML pur. Vous pouvez le modifier selon vos besoins. Ajoutez des classes, des balises, des descriptions, tout ce que vous voulez. Copiez le code ci-dessous et collez-le dans votre site Web.");
	define("WIDGET_FULL_CODE_TXT", "Version complète (tous les champs inclus)");
	define("WIDGET_MIN_CODE_TXT", "Version minimisée (seulement e-mail inclus)");
	define("WIDGET_CODE_DESC_TXT", "Description du formulaire");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> obligatoire.</li>
        <li>Adresse e-mail de l'abonné.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> optionnel.</li>
        <li>Nom de l'abonné.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> optionnel.</li>
        <li>Champ caché.</li>
        <li>Ils doivent déjà être ajoutés à la base de données.</li>
        <li>Ils doivent être séparés par une virgule.</li>
        <li>En utilisant différents tags, vous pouvez créer différentes campagnes.</li>
        <li>Vous pouvez utiliser le même formulaire sur différents sites et utiliser des tags différents sur chaque site.</li>
        <li>Cela signifie que ce composant peut recueillir des abonnés de différents sites et les ajouter à votre système avec des balises différentes.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> optionnel.</li>
        <li>Champ caché.</li>
        <li>Ajoutez votre description pour le destinataire.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> optionnel.</li>
        <li>Champ caché.</li>
        <li>Activer la fonctionnalité double opt-in.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> optionnel.</li>
        <li>Champ caché.</li>
        <li>Où rediriger après s'abonner. Si le champ est vide ou n'est pas inclus dans le formulaire, l'action configurée sera effectuée.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Copiez le code ci-dessous et collez-le sur votre site");
	define("WIDGET_DBL_OPT_IN", "Double opt-in");
	define("WIDGET_DBL_OPT_LABEL", "Le vérifier pour utiliser la confirmation de souscription double");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "Message électronique (HTML de support)");
	define("WIDGET_DBL_OPT_HELP", "N'oubliez pas d'ajouter <b>{CONFIRM_LINK}</b> dans votre message.<br>Vous pouvez également ajouter:<br><b>{SUBSCRIBER_EMAIL}</b> - Adresse e-mail de l'abonné<br><b>{SUBSCRIBER_NAME}</b> - Nom d'abonné<br><b>{SUBSCRIBER_COMMENT}</b> - Votre commentaire sur subscriber<br><b>{SUBSCRIBER_TAGS}</b> - Tags utilisés<br><b>{CURRENT_YEAR}</b> - année actuelle<br><b>{CURRENT_MONTH}</b> - mois en cours<br><b>{CURRENT_DAY}</b> - jour actuel");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "Titre de l'email");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "Entrez le titre de confirmation par e-mail...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "Entrez un message de confirmation...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Redirection après confirmation");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "Saisir l'adresse à laquelle rediriger après confirmation");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Envoyer à partir de l'adresse");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "Entrez l'adresse e-mail à partir de laquelle la confirmation sera envoyée");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Description de l'expéditeur");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "Saisir la description de l'expéditeur");
	define("WIDGET_ADMIN_NOTIFY", "Notifier l'administrateur sur le nouvel abonné");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "Cochez la case pour envoyer une notification par courrier électronique une fois le nouvel abonnement reçu. <br><br><b>AVERTISSEMENT!</b> Le courrier électronique Admin doit être configuré dans les paramètres système!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Message d'administration (HTML de prise en charge)");
	define("WIDGET_ADMIN_HELP", "Peut être utilisé dans votre message:<br><b>{SUBSCRIBER_EMAIL}</b> - Adresse e-mail de l'abonné<br><b>{SUBSCRIBER_NAME}</b> - Nom d'abonné<br><b>{SUBSCRIBER_COMMENT}</b> - Votre commentaire sur subscriber<br><b>{SUBSCRIBER_TAGS}</b> - Tags utilisés<br><b>{CURRENT_YEAR}</b> - année actuelle<br><b>{CURRENT_MONTH}</b> - mois en cours<br><b>{CURRENT_DAY}</b> - jour actuel");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Message d'erreur du serveur en cas de mauvaise adresse e-mail d'abonné");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Choisissez votre serveur");
	define("BOUNCED_DEL_EMAILS", "Supprimer automatiquement de la liste des destinataires");
	define("BOUNCED_DEL_MESSAGES", "Supprimer automatiquement tous les messages renvoyés et vérifiés du serveur");
	define("BOUNCED_MAX", "Limite maximale de messages");
	define("BOUNCED_AT_TIME", "Vérifier à la fois");
	define("BOUNCED_START", "Vérifier la boîte aux lettres pour les emails retournés");
	
	define("YES", "Oui");
	define("NO", "Non");
	define("DATA_ERROR", "ERREUR: Les données demandées n'existent pas...<br><br><a href='index.php'>Cliquez ici pour ouvrir le tableau de bord</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "Le serveur pour envoyer le courrier pour widget d'abonnement");
    define("TESTING_TEMPLATE", "Modèle de test");
    define("TESTING_TEMPLATE_INFO", "Envoie le modèle au courriel ci-dessous. Les variables ne seront pas substituées.");
    define("TESTING_CHOOSE_SERVER", "Sélectionner le serveur d'envoi");
    define("ERRORS", "les erreurs");
    define("TEST", "Teste moi!");
    
    /*v.1.16*/
    define("COPY", "Copie");
    define("COPYING", "Faire face");
    define("CHECK", "Vérifier");
    define("DATA_VERIFY", "Vérification de l'intégrité des données");
    define("DATA_VERIFY_QUESTION", "Voulez-vous vraiment vérifier l'intégrité des données?");
    define("DATA_VERIFY_DESCRIPTION", "Cette opération peut prendre plusieurs minutes, cela dépend de la quantité de données dans votre base de données. <br> Faites-le si vous êtes sûr que la campagne a été terminée et n'est pas visible sur cette liste.");
    define("DATA_VERIFY_BUTTON", "Vérifier l'intégrité des données");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Filtrer les destinataires des tags sélectionnés (OR&nbsp;query)");
    define("REC_QUERY_AND", "Filtrer les destinataires dans tous les tags sélectionnés (AND&nbsp;query)");
    define("REC_RESET", "Réinitialiser la requête");
    define("REC_BUTTON_DELETE", "Supprimer les destinataires");
    define("CSV_ST_1", "Préparer les données selon la formule:");
    define("CSV_COL_NO", "numéro de colonne");
    define("CSV_REQ", "champs requis");
    define("CSV_OPT", "optionnel");
    define("CSV_ADDR", "adresse e-mail");
    define("CSV_NAME", "prénom et nom");
    define("CSV_TAGS", "tags");
    define("CSV_TAGSDESC", "doit être dans la base de données doit être séparé par un seul espace");
    define("CSV_COMMENT", "commentaires");
    define("CSV_DESC1", "Save the spreadsheet as a CSV");
    define("CSV_DESC2", "délimiteur");
    define("CSV_MAXLINE", "Longueur maximale de la ligne CSV");
    define("CSV_FORMDESC", "Télécharger un fichier CSV préparé en utilisant le formulaire ci-dessous");
    define("DISABLE_EDITOR", "Désactiver l'éditeur");
    define("ENABLE_EDITOR", "Activer l'éditeur");
   
    /*v.1.18*/
    define("MENU_BRIDGE", "Importer des e-mails par DB Bridge");
    define("TITLE_IMPORT", "Importation de destinataires");
    define("SUBTITLE_IMPORT", "bridge de base de données - params source");
    define("LIST_TITLE_IMPORT", "Importer des destinataires d'autres bases de données");
    define("ADD_NEW_BRIDGE", "Ajouter un nouveau pont");
    define("IMPORT_RECIPIENTS", "Destinataires");
    define("IMPORT_BRIDGE_DESC", "Description du pont d'importation");
    define("CONFIRM_BRIDGE_DEL", "Suppression de la connexion au pont de la base");
    define("IMPORTING_BRIDGE_REC", "Importation de destinataires");
    define("CHOOSEN_BRIDGE", "Pont choisi pour l'importation");
    
    define("FORM_BRIDGE_DESC", "Description du pont d'importation");
    define("BRIDGE_TABLE", "Nom de la table source");
    define("BRIDGE_COL_NAME", "Colonne source pour le nom du destinataire");
    define("BRIDGE_COL_NAME_INFO", "sera importé dans le champ Nom du destinataire");
    define("BRIDGE_COL_MAIL", "Colonne source pour l'adresse e-mail");
    define("BRIDGE_COL_MAIL_INFO", "sera importé dans le champ Email");
    define("BRIDGE_COL_DESC", "Colonne source pour la description du destinataire");
    define("BRIDGE_COL_DESC_INFO", "sera importé dans le champ Description");
    define("BRIDGE_CHECK_CON", "Vérifier la connexion à la base");
    define("BRIDGE_WAITING", "en attente de test...");
    define("BRIDGE_ADD_NAME", "Nom du destinataire supplémentaire");
    define("BRIDGE_ADD_NAME_INFO", "sera ajouté après la colonne du nom de la source");
    define("BRIDGE_ADD_DESC", "Description du destinataire supplémentaire");
    define("BRIDGE_ADD_DESC_INFO", "sera ajouté après la colonne de description de la source");
    define("BRIDGE_OVERRIDE", "Remplacer les destinataires existants");
    define("BRIDGE_OVERRIDE_O1", "mise à jour - destinataire destinataire correct selon la nouvelle source");
    define("BRIDGE_OVERRIDE_O2", "ignore - ne fait rien si le destinataire de destination existe déjà");
    define("BRIDGE_TAGS", "Tags disponibles");
    define("BRIDGE_FILL_FIELDS", "remplir tous les champs requis avant de tester...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "importation en cours, veuillez patienter...");
    define("BRIDGE_TEST_OK", "Votre pont de connexion fonctionne correctement");
    define("BRIDGE_IMPORT_OK1", "Importation terminée. Actualisé:");
    define("BRIDGE_IMPORT_OK2", " Inséré:");
    define("TABLE", "Table ");
    define("COLUMN", "Colonne ");
    define("NOT_IN_DB", " n'existe pas dans la base de données ");
    define("NOT_IN_TABLE", " n'existe pas dans le tableau ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "entrez votre clé API de géolocalisation ici");
    define("SETTINGS_API_GEO_LINK_INFO", "cliquez ici pour obtenir une nouvelle clé d'API de géolocalisation");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Utilisez https");
    define("HTTPS_USAGE_INFO", "marque si vous utilisez https, cela générera tous les liens avec https");
    define("TEMPLATE_STATISTICS", "Modèle de statistiques: ");
    define("TEMPLATE_CHARS", "caractères: ");
    define("TEMPLATE_USAGE", "utilisé: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Jeton d'inscription au formulaire d'inscription ");
    define("WIDGET_EMAIL_TOKEN", "Jeton d'inscription de courrier électronique d'abonnement ");
    
    /*v.1.22*/
    define("WEBSITE", "Site Internet");
    define("WIDGET_WEBSITE_SHOW", "Afficher le champ URL du destinataire");
    define("VERIFIED", "Vérifié");
    define("VERIFY", "Vérifier");
    define("C_PREPARED", "préparé et en attente");
    define("C_AJAX_PROGRESS", "envoi ajax en cours");
    define("C_FINISHED", "terminé");
    define("C_BG_PROGRESS", "Envoi en tâche de fond");
    define("C_PAUSED", "en pause");
    define("C_CRON", "envoi de cron en cours");
    define("B_VER", "Vérification en vrac");
    define("B_RV", "Vérification des destinataires en vrac");
    define("B_SEND1", "Êtes-vous sûr de vouloir envoyer");
    define("B_SEND2", "destinataires pour vérification");
    define("B_CHECK_LIST", "vérifier les listes de vérification en vrac");
    define("B_VER_INFO", "Vos chèques groupés seront disponibles sur votre compte emailable.com");
    define("B_VER_IN_PROG", "vérification en cours");
    define("B_VER_SENT", "Destinataires envoyés pour vérification en bloc");
    define("B_V_TITLE", "Vérifications par e-mail en masse");
    define("B_V_TITLE2", "listes envoyées");
    define("BUTTON_CHECK_STATUS", "Vérifier le statut");
    define("BUTTON_DOWN_UP", "Télécharger la mise à jour");
    define("V_ID", "vérifier l'identifiant");
    define("V_QTY", "quantité à vérifier");
    define("V_DATE", "Date envoyée");
    define("V_MESSAGE", "Etat");
    define("V_PERC", "% compléter");
    define("V_WORKING", "travail");
    define("RESPONSE", "réponse");
    define("V_UPDATED_INFO", "Destinataires mis à jour, vérifiez les détails");
    define("SETTINGS_API_THECHECKER", "cliquez ici pour obtenir la clé API emailable.com");
    define("SETTINGS_API_DESCRIPTION", "Permet de tuer les rebonds! <br>En utilisant le bouton ci-dessous, vous obtiendrez <b>30% de chèques supplémentaires GRATUITS</b> lors de votre premier achat et un bonus de 30% (en espèces ou par chèques) à chaque achat que vous ferez pour toujours!");
    define("EC_DATA", "Exporter toutes les données de campagnes");
    define("EC_DATA1", "Exporter les données de campagne");
    define("EX_OPENED_BUTTON", "Destinataires ayant ouvert");
    define("EX_OPENED_DESC", "Exporter des destinataires de campagne ayant ouvert un courrier électronique de campagne");
    define("EX_NOT_OPENED_BUTTON", "Destinataires n'ayant pas ouvert");
    define("EX_NOT_OPENED_DESC", "Exporter des destinataires de campagne n'ayant PAS ouvert de courrier électronique de campagne");
    define("EX_UNSUBSRIBED_BUTTON", "Destinataires ayant désabonné");
    define("EX_UNSUBSRIBED_DESC", "Exporter les destinataires de campagne désabonnés de la campagne");
    define("EX_CLICKED_BUTTON", "Destinataires ayant cliqué");
    define("EX_CLICKED_DESC", "Exporter les destinataires de campagne ayant cliqué sur le lien dans le courrier électronique de la campagne");
    define("EX_ALL_BUTTON", "Toutes les données des destinataires");
    define("EX_ALL_DESC", "Exporter toutes les données de destinataires de la campagne en cours");
    define("EX_COUNTRY_BUTTON", "Pays bénéficiaires");
    define("EX_COUNTRY_DESC", "Exporter tous les pays de la campagne en cours");
    define("EX_CITY_BUTTON", "Villes destinataires");
    define("EX_CITY_DESC", "Exporter toutes les villes de la campagne en cours");
    define("EX_BROWSER_BUTTON", "Navigateurs destinataires");
    define("EX_BROWSER_DESC", "Exporter tous les navigateurs de la campagne en cours");
    define("SETTINGS_CHARSET", "Définissez votre jeu de caractères pour l'exportation de données");
    define("MENU_BULK", "Vérifications en vrac");
    define("B_CONFIRM", "confirmer la suppression en bloc de emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Mettre à jour les destinataires. Si une adresse électronique est importée dans la base de données, mettez-la à jour à l'aide des données du fichier CSV.");
    define("TAGS_MANAGER_TITLE", "Gestionnaire de tags de destinataires, emails sélectionnés: ");
    define("TAGS_SELECT_ACTION", "Choisissez votre action:");
    define("TAGS_MANAGER_ADD", "Ajouter des balises aux destinataires sélectionnés");
    define("TAGS_MANAGER_REMOVE", "Supprimer les étiquettes des destinataires sélectionnés");
    define("TAGS_SELECT", "Sélectionnez vos tags:");
    define("SAVE_CHANGES", "Sauvegarder les modifications");
    define("NOT_SELECTED_TAGS", "Sélectionnez d'abord les destinataires");
    define("TM_BUTTON", "Gestionnaire de balises en vrac");
    define("WAITING", "attendre...");
    define("MULTI_SMTP", "Multi SMTP");
    define("MULTI_CHECK_DESC", "cocher, si vous voulez utiliser la fonction d'envoi multi smtp");
    define("MULTI_CHOOSE", "Choisissez les serveurs smtp");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Liste noire");
    define("BL1", "Liste des domaines et IP non autorisés");
    define("BL2", "adresses malveillantes bloquées pour l'abonnement");
    define("BL3", "Votre liste noire");
    define("B_VALUE", "Valeur");
    define("B_TYPE", "Type");
    define("MENU_ADD_BL", "Ajouter une nouvelle entrée");
    define("B_DOMAIN", "domaine");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "Vous pouvez importer la liste des adresses malveillantes dans votre liste noire ici <small>(chaque enregistrement doit être sur une ligne séparée)</small>");
    define("B_DELETE_ALL", "Effacer la liste noire");
    define("B_DELETE_QUESTION", "Voulez-vous vraiment supprimer toute la liste noire?");
    define("B_EXPORT", "Exporter la liste noire");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM réglages");
    define("DKIM_USE", "utilisation DKIM");
    define("DKIM_DOMAIN", "Signature du nom de domaine");
    define("DKIM_PRIVATE", "Chemin du fichier de clé privée");
    define("DKIM_SELECTOR", "Habituellement, la configuration de la touche de sélection sur votre enregistrement DNS TXT");
    define("DKIM_PASS", "Utilisé si votre clé est chiffrée");
    define("DKIM_IDENTITY", "Habituellement, l'adresse e-mail utilisée comme source de l'e-mail");
    
    define("ERROR", "Erreur:");
    define("WARNING", "ATTENTION!");
    define("D_MODE", "Les modifications et certaines fonctionnalités ne sont pas disponibles en mode DEMO.");
    define("S_DIS", "Envoi désactivé jusqu'à ce que vous saisissiez votre code d'achat");
    define("HERE", "ici");
    define("PLIK", "déposer");
    define("NOT_WR", "n'est pas inscriptible. Les paramètres ne seront pas enregistrés. Modifier les autorisations de fichier avant d'enregistrer.");
    define("EPC", "Code d'achat Envato");
    define("EVALIDEPC", "Entrez un code d'achat valide");
    define("NO_ADMIN_MAIL", "Mettez d'abord à jour l'adresse e-mail de l'administrateur dans les paramètres.");
    
    define("SMTP_LABEL", "niveau de débogage ");
    define("SMTP_0", "Désactiver le débogage ");
    define("SMTP_1", "Messages de sortie envoyés par le client ");
    define("SMTP_2", "comme 1, plus les réponses reçues du serveur (c'est le paramètre le plus utile) ");
    define("SMTP_3", "comme 2, plus plus d'informations sur la connexion initiale - ce niveau peut aider à diagnostiquer les échecs STARTTLS ");
    define("SMTP_4", "comme 3, plus des informations de niveau inférieur, très détaillé, ne pas utiliser pour le débogage SMTP, uniquement des problèmes de bas niveau ");
    
    define("SMTP_SENDER_FORCE", "Toujours forcer cet expéditeur dans les campagnes pour ce serveur");
    define("SMTP_SENDER_MAIL", "Adresse e-mail de l'expéditeur");
    define("SMTP_SENDER_DESCRIPTION", "Descriptif de l'expéditeur");

    
    
    
