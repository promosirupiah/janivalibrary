<?php
	/*login page*/
	define("LANG","pt_PT");
	define("LOGIN_TITLE","Sistema de envio");
	define("LOGIN_SIGN_IN","Por favor, inscreva-se");
	define("LOGIN","Entrar");
	define("LOGIN_PASS","Senha");
	define("LOGIN_SIGN_IN_BUTTON","Assinar em");
	define("LOGIN_FAILED","Entrar e/ou senha incorretos!");
	define("INSTALLING_SYSTEM","Configuração do sistema");
	define("INSTALLING_CONNECTED","Corretamente conectado ao banco de dados");
	define("INSTALLING_ADD_TABLES","Adicionar tabelas");
	define("INSTALLING_ADD_TABLES_DESC","Clique aqui para adicionar tabelas e começar a trabalhar com o sistema");
	
	/*left menu*/
	define("WELCOME","Bem vinda,");
	define("WELCOME_ASK","O que nós fazemos?");
	define("MAIN_MENU","Menu principal");
	define("START","Começar");
	define("DASHBOARD","Dashboard");
	define("EMAIL_ADRESSES","Endereço de e-mail");
	define("MENU_RECIPIENT_LIST","Lista de destinatários");
	define("MENU_ADD_RECIPIENT","Adicionar destinatário");
	define("MENU_CSV_IMPORT","Importar e-mails de um arquivo CSV");
	define("MENU_CSV_EXPORT","Exportar e-mails para arquivo CSV");
	define("MENU_TAG_LIST","Lista de tags");
	define("MENU_ADD_TAGS","Adicionar tags");
	define("MENU_SENDERS_LIST","Lista de remetentes");
	define("MENU_ADD_SENDER","Adicionar remetente");
	define("MENU_TEMPLATES","Layouts de e-mail");
	define("MENU_TEMPLATES_LIST","Lista de modelos");
	define("MENU_TEMPLATES_ADD","Adicionar novo modelo");
	define("MENU_TEMPLATES_ATTACHMENTS","Anexos");
    define("MENU_TEMPLATES_THUMBNAILS","Miniaturas");
	define("MENU_CAMPAIGNS","Suas campanhas");
	define("MENU_CAMPAIGNS_ADD","Preparar nova campanha");
	define("MENU_CAMPAIGNS_WAITING_LIST","Campanha da lista de espera");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Campanhas em andamento");
	define("MENU_CAMPAIGNS_SENT","Listar campanhas enviadas");
	define("MENU_SYSTEM_CONFIGURATION","Configuração do sistema");
	define("MENU_SETTINGS","Configurações");
	define("MENU_LOGIN","Entrar");
	define("MENU_DB","Banco de dados");
	define("MENU_SYSTEM_PARAMS","Parâmetros do sistema");
	define("MENU_SPECIALS","Aditivos especiais");
	define("MENU_ADDONS","Aditivos útil");
	define("MENU_CLEAR_DB","Limpar banco de dados");
	define("MENU_IMPORT_TEMPLATES","Importar modelos de amostra");
	define("MENU_IMPORT_DATA","Importar dados de amostra");
	define("MENU_FAQ","Perguntas e respostas");
	define("MENU_ABOUT","Sobre");
    define("MENU_SMTP_PARAMS","SMTP configuração");
    define("MENU_UNSUBSCRIBED","Lista de cancelamentos");
    define("MENU_UNSUBSCRIBED_LIST","Lista de destinatários");
    define("MENU_DOCS","Documentação");
    define("MENU_SUBSCRIBE_WIDGET","Inscrever widget");
    define("MENU_BOUNCED","Verificar emails rejeitados");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","Base de dados de e-mail");
	define("D_EMAIL_ADD_NEW","Adicionar novo email");
	define("D_EMAIL_TEMPLATES","Modelos de e-mail");
	define("D_EMAIL_TEMPLATES_ADD","Adicionar novo modelo");
	define("D_EMAIL_SENT","E-mails enviados");
	define("D_EMAIL_EFFICIENCY","Eficiência");
	define("D_EMAIL_UNSUBSCIBERS","Cancelar inscrição");
	define("D_CAMPAIGNS","Campanhas");
	define("D_CAMPAIGNS_ADD","Nova campanha");
	define("D_CAMPAIGNS_WAITING","Pronto para enviar");
	define("D_CAMPAIGNS_SENT","Concluído");
	define("D_STATISTICS","Estatísticas");
	define("D_THIS_YEAR","Suas campanhas de publicidade este ano");
	define("D_CHECK_ALL","Verificar tudo...");
	define("JAN","jan");
	define("FEB","fev");
	define("MAR","mar");
	define("APR","abr");
	define("MAY","mai");
	define("JUN","jun");
	define("JUL","jul");
	define("AUG","ago");
	define("SEP","set");
	define("OCT","out");
	define("NOV","nov");
	define("DEC","dez");
	define("D_PREPARED_OVERALL","Campanhas preparadas");
	define("D_SENT_OVERALL","enviei");
	define("D_HOW_TO","Como funciona?");
	define("D_HOW_STEP_1_TITLE","1. Base de dados de e-mail");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Adicionar tags</a> isso irá ajudá-lo a encontrar clientes e irá ajudá-lo a preparar facilmente uma campanha publicitária. Próximo <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>adicionar e-mails</a> ao seu sistema de banco de dados. Você também pode <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>upload de arquivo CSV</a> com e-mails para a sua base de dados.");
	define("D_HOW_STEP_2_TITLE","2. Remetentes");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Adicionar remetente</a> você pode decidir de quem seus clientes receberão um email.");
	define("D_HOW_STEP_3_TITLE","3. Modelos de e-mail");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Adicionar modelo</a> preparar um número ilimitado de modelos, com número ilimitado de anexos.");
	define("D_HOW_STEP_4_TITLE","4. Campanhas publicitárias");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Adicionar nova campanha</a> preparar campanhas ilimitadas. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Enviar campanha</a> a qualquer momento.");
	define("D_HOW_STEP_5_TITLE","5. Seguir estatísticas");
	define("D_HOW_STEP_5_DESC","Aqui você vai aprender que campanhas são as melhores, como e quando a campanha foi preparada e quanto é enviado e qual é a sua eficácia (ou seja, quantas pessoas abriram o seu e-mail e quantas pessoas unsubsrcibed da campanha).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Alterar login");
	define("CHANGE_PASS","Mudar senha");
	define("CLEAR_DATABASE","Limpar banco de dados");
	define("LOGOUT","Desligar");
	define("ABOUT","Sobre");
	
	/*vertical buttons*/
	define("CONFIG","Configuração");
	define("CONFIG_TOOLTIP","Configuração do sistema");
	define("MEDIA_MANAGER","Gerente de anexos");
	define("RECIPIENT","Destinatários");
	define("RECIPIENT_TOOLTIP","Gerenciamento de e-mails");
	define("RECIPIENT_EDIT","Modificar detalhes");
	define("RECIPIENT_ADD_NEW","Adicionar nova");
	define("MENUS","Gestão de menu");
	define("MENUS_TOOLTIP","Configuração do menu");
	define("TEMPLATES","Layouts");
	define("TEMPLATES_TOOLTIP","Configuração de layout");
	define("HELP","Ajudar");
	define("HELP_TOOLTIP","Como funciona");
	
	define("FILE_MANAGEMENT","Anexos");
	define("CSV_IMPORT","CSV e-mails de importação de arquivo");
	
	define("PERSON","Pessoa");
	define("EMAIL","E-mail");
	define("TAGS","Etiquetas");
	define("TAGS_LIST","Listas de tags");
	define("TAGS_ADD","Adicionar novas etiquetas");
	define("TAGS_ADD_NEW","Adicionar tags");
	define("TAGS_ADD_EDIT","Edição tag");
	define("TAGS_NAME","Nome da marca");
	define("TAGS_DESCRIPTION","Descrição");
	define("TAGS_NAME_PLACEHOLDER","digite um nome de tag...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","digite uma descrição tag...");
	define("TAGS_USED","Usado (vezes)");
	define("TAGS_INFO","Tags para um e-mail");
	
	define("RECIPIENT_LIST","Lista de discussão");
	define("RECIPIENT_NAME","Nome do Destinatário");
	define("RECIPIENT_NAME_PLACEHOLDER","Insira o nome completo");
	define("RECIPIENT_MAIL","Email");
	define("RECIPIENT_MAIL_PLACEHOLDER","Insira e-mail");
	define("RECIPIENT_ONLY_TXT","Apenas e-mails TXT");
	define("RECIPIENT_DESCRIPTION","Descrição");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","Descrição...");
	define("RECIPIENT_DB","Sua base de dados de e-mails");
	define("RECIPIENT_DETAILS_EDIT","Editar detalhes do destinatário");
	define("RECIPIENT_DETAILS_ADD","Adicionando novo endereço de e-mail");
	define("RECIPIENT_IMPORT_CSV","mportar e-mails do arquivo CSV");
	define("RECIPIENT_PREPARE_CSV","Prepare um arquivo CSV com as seguintes linhas");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Para adicionar novos registros de um arquivo do Excel você deve seguir as etapas abaixo");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","Faça o download do modelo CSV");

	define("RECIPIENT_UPLOAD_CSV_NAME","Importar arquivo CSV");
	define("RECIPIENT_NOT_CSV","<b>Este não é um arquivo CSV!!!</b><br/>");
	define("RECIPIENT_ROW","Linha ");
	define("RECIPIENT_WRONG_EMAIL"," - Endereço de e-mail incorreto, inserido: ");
	define("RECIPIENT_EMAIL_EXIST"," - Este endereço já está no banco de dados: ");
	define("RECIPIENT_EMAIL_LACK"," - Falta de um endereço de e-mail");
	define("RECIPIENT_EMAIL_IN_DB"," - Este endereço de e-mail já existe no arquivo CSV na linha ");
	define("RECIPIENT_TAG_NOT_EXIST"," - Nenhuma tag desse tipo: ");
	define("RECIPIENT_CSV_ERRORS","Erros no arquivo ");
	define("RECIPIENT_CSV_ADDED","Adicionado ");
	define("RECIPIENT_CSV_ADDED_FROM"," Endereços de e-mail do arquivo ");
	define("RECIPIENT_CSV_EXPORT","Exportar endereços de e-mail para um arquivo");
	define("RECIPIENT_CSV_EXPORT_CHK","Selecione os campos a serem exportados:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Endereço de e-mail do destinatário");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Primeiro nome e sobrenome");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Tags - separados por um único espaço");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Comentários");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Receber e-mails somente de texto");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Data de introdução");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Data de modificação");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","exportar");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Ignorar verificação de erros CSV (verifique se o arquivo contém mais de 1000 e-mails - arquivos maiores exigem uma grande quantidade de memória no servidor)");
	
	define("SAVE","Salvar");
	define("CANCEL","Cancelar");
	define("DELETE","Excluir");
    define("EDIT","Editar");
	define("CREATED","Criado");
	define("MODIFIED","Modificado");
	define("SEND","Enviar");
	define("SENT","Enviei");
	define("PROGRESS","Progresso");
	define("RESUME","Currículo");
	define("CLOSE","Fechar");
	define("CHANGES_SAVED","As mudanças foram feitas com sucesso");
	
	define("DELETING","Excluindo");
	define("DELETING_CONFIRM_QUESTION","Você tem certeza que deseja remover?");
	
	define("DATATABLE_LENGTHMENU", "Exibição _MENU_ registros por página");
	define("DATATABLE_ZERORECORDS", "Nada encontrado - desculpe");
	define("DATATABLE_INFO", "Mostrando a página _PAGE_ do _PAGES_");
	define("DATATABLE_INFOEMPTY", "Nenhum registro disponível");
	define("DATATABLE_INFOFILTERED", "(Filtrado _TOTAL_ de _MAX_ registros totais)");
	define("DATATABLE_SEARCH", "Pesquisa");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Adicionar novo modelo");
	define("TEMPLATES_LIST", "Lista de modelos");
	define("TEMPLATES_TITLE", "Modelos disponíveis");
	define("TEMPLATES_TITLE_ADD", "Adicionar novo layout");
	define("TEMPLATES_TITLE_EDIT", "Edição de layout");
	define("TEMPLATES_NAME", "Nome do layout");
	define("TEMPLATES_MAIL_TITLE", "Título do e-mail");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Digite o título do e-mail");
	define("TMPLATES_HTML", "Versão HTML");
	define("TMPLATES_TXT", "Versão TEXTO");
	define("TMPLATES_VARIABLES", "Variáveis de modelo disponíveis (verifica <a href='docs/index.html#variables' target='_blank'>docs</a> para detalhes):");
	define("TEMPLATES_THUMB", "Miniatura");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Edição de miniaturas");
	define("THUMBNAIL_MEDIA_LIST", "Lista de miniaturas disponíveis");
	
	define("MEDIA_FILENAME", "Nome do arquivo");
	define("MEDIA_FILENAME_DESCRIPTION", "Descrição do arquivo");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Tempo de envio");
	define("MEDIA_TEMPLATES", "Usado como anexo");
	define("MEDIA_LIST", "Lista de anexos disponíveis");
	define("MEDIA_ADD_FILES", "Adicionar arquivos");
	define("MEDIA_BROWSE", "Procurar");
	define("MEDIA_UPLOAD", "Envio");
	
	define("CAMPAIGN_MENU", "Nova campanha");
	define("CAMPAIGN_PREPARE", "Preparar campanha");
	define("CAMPAIGN_RECIPIENTS", "Escolher destinatários");
	define("CAMPAIGN_TEMPLATES", "Escolher layout");
	define("CAMPAIGN_SENDERS", "Escolher remetente");
	define("CAMPAIGN_CONFIRM", "Salvar campanha");
	define("CAMPAIGN_SEND", "Enviar campanha");
	define("CAMPAIGN_NAME", "Nome da campanha");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Insira o nome da campanha");
	define("CAMPAIGN_RECIPIENT_QTY", "Destinatários");
	define("CAMPAIGN_TEMPLATE_NAME", "Layout");
	define("CAMPAIGN_SENDER", "Remetente");
	define("CAMPAIGN_CREATED_DATE", "Preparado");
	define("CAMPAIGN_STEP_1", "1. Selecione seus destinatários (use o campo 'pesquisa' sobre a tabela)");
	define("CAMPAIGN_STEP_2", "2. Salvar sua campanha");
	define("CAMPAIGN_SELECT", "Selecionar campanha para envio");
	define("CAMPAIGN_FORM_SELECT", "selecionar...");
	define("CAMPAIGN_CURRENT_STATUS", "Status da campanha atual");
	define("CAMPAIGN_SENT_NOW", "Envie agora");
	define("CAMPAIGN_SENT_BUTTON", "Clique aqui para começar a enviar");
	define("CAMPAIGN_RESUME_BUTTON", "Clique aqui para retomar o envio");
	define("CAMPAIGN_SERVER_CONNECTING", "conectando ao servidor, aguarde...");
	define("CAMPAIGN_SENDING", "envio");
	define("CAMPAIGN_PLEASE_WAIT", "por favor, espere...");
	define("CAMPAIGN_SENT", "<b>CAMPANHA ENVIADA</b> destinatários: ");
	define("CAMPAIGN_IN_PROGRESS", "Campanhas em andamento...");
	define("CAMPAIGN_COMPLETED", "Campanhas enviadas");
	define("CAMPAIGN_LEFT", "Esquerda para enviar");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Eliminar todos os subscritores");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "Essa ação excluirá todos os assinantes da sua base de dados.");
	define("CAMPAIGN_BG_PROCESS", "Processo em segundo plano");
	define("CAMPAIGN_BG_PROCESS_INFO", "Enviar como um processo em segundo plano (você pode fechar o navegador)");
	define("CAMPAIGN_WHEN_FINISH", "E-mail quando terminar");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "Onde enviar notificação");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Confirme o envio de fundo!");
    
    define("HOUR", "hora");
    define("OPENS", "Abre");
    define("BOUNCED", "Devolvido");
    define("CLICKED", "Clicou");
    define("UNIQUE_CLICKS", "Cliques exclusivos");
    define("TOTAL_CLICKS", "Cliques totais");
	
	define("SENDER_LIST", "Lista de remetentes");
	define("SENDER_ADD", "Adicionar remetente");
	define("SENDER_NAME", "Nome do remetente");
	define("SENDER_NAME_PLACEHOLDER", "Introduza o nome do remetente");
	define("SENDER_EMAIL", "E-mail do remetente");
	define("SENDER_EMAIL_PLACEHOLDER", "Digite o e-mail do remetente");
	define("SENDER_TITLE_ADD", "Adicionar remetente");
	define("SENDER_TITLE_EDIT", "Editar remetente");
	define("SENDER_EMAIL_TITLE", "Endereço de e-mail do remetente");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Digite o endereço de e-mail do remetente");
	
	define("SETTINGS", "Configurações");
	define("SETTINGS_LOGIN_TITLE", "Inserir novas credenciais");
	define("SETTINGS_LOGIN_LABEL", "Insira novo login");
	define("SETTINGS_LOGIN_PLACEHOLDER", "insira login");
	define("SETTINGS_CURR_PASS", "Senha atual");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "digite a senha");
	define("SETTINGS_NEW_PASS", "Nova senha");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "nova senha");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "confirmar");
	define("SETTINGS_DB_PARAMS", "Configurar o banco de dados");
	define("SETTINGS_DB_HOST", "Host de banco de dados");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "por exemplo: localhost");
	define("SETTINGS_DB_USER", "Utilizador da base de dados");
	define("SETTINGS_DB_USER_PLACEHOLDER", "por exemplo: root");
	define("SETTINGS_DB_PASSWORD", "Senha do banco de dados");
	define("SETTINGS_DB_NAME", "Nome do banco de dados");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "por exemplo: mailing");
	define("SETTINGS_GLOBAL", "Configurações globais");
	define("SETTINGS_LANG", "Idioma do sistema");
	define("SETTINGS_LIMIT", "Configurar o limite de e-mail por hora");
	define("SETTINGS_LIMIT_PLACEHOLDER", "padrão: 1000");
	define("SETTINGS_TRACKING", "Ativar o acompanhamento de e-mails");
	define("SENDING_METHOD", "Método de envio");
	define("SETTINGS_UNSUBSCRIBED", "Eliminação automática não subscrita");
	define("SETTINGS_UNS_INFO", "O e-mail será automaticamente excluído da lista de destinatários quando o usuário clicar no link unsubscibe");
	define("SETTINGS_TRACK_INFO", "Etiqueta invisível img será adicionada para rastrear seu destinatário");
	define("SETTINGS_API_LABEL", "Google mapas<br>API key");
	define("SETTINGS_API_PLACEHOLDER", "Digite sua chave google maps API v.3 aqui");
	define("SETTINGS_API_LINK_INFO", "Clique aqui para obter uma nova chave da API");
	define("SETTINGS_ADMIN_MAIL", "E-mail do administrador");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "E-mail de administração para notificações do sistema");
    define("SETTINGS_PHP_TIMEOUT", "Tempo limite do PHP (segundos)");
    
	define("SMTP_SERVER_DESCRIPTION", "Servidor SMTP, não se esqueça de adicionar");
    define("SMTP_LIST", "Lista de servidores");
    define("SMTP_ADD", "Adicionando novo servidor");
    define("SMTP_EDIT", "Servidor de edição");
    define("SMTP_INFO", "Os servidores SMTP");
    define("SMTP_ADD_BUTTON", "Clique para adicionar o novo servidor SMTP");
    define("SMTP_NAME", "Nome da conexão");
    define("SMTP_NAME_PLACEHOLDER", "por exemplo: Minha melhor conexão");
    define("SMTP_HOST", "Endereço SMTP");
    define("SMTP_HOST_PLACEHOLDER", "Servidor principal e de backup (separador ';' para backup)");
    define("SMTP_PAUTH", "Autenticação");
    define("SMTP_PAUTH_PLACEHOLDER", "Ativar autenticação SMTP");
    define("SMTP_VERIFY_PEER", "Ativar a verificação de certificados SSL / TLS");
    define("SMTP_FORCE_SMTP", "Forçar o uso do SMTP");
    define("SMTP_USERNAME", "Nome de usuário do SMTP");
    define("SMTP_USERNAME_PLACEHOLDER", "nome de usuário do SMTP");
    define("SMTP_LOGIN", "Login SMTP");
    define("SMTP_LOGIN_PLACEHOLDER", "Login do servidor SMTP");
    define("SMTP_PASSWORD", "Senha SMTP");
    define("SMTP_PASSWORD_PLACEHOLDER", "senha SMTP");
    define("SMTP_REPLYTO", "Responder ao e-mail");
    define("SMTP_REPLYTO_PLACEHOLDER", "Definir um endereço de resposta alternativo");
    define("SMTP_REPLYTONAME", "Responder ao nome");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Definir uma resposta alternativa ao nome");
    define("SMTP_SECURE", "Criptografia");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> como criptografia padrão");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> aceito mas não recomendado");
    define("SMTP_PORT", "Porta");
    define("SMTP_PORT_PLACEHOLDER", "porta do servidor");
    define("SMTP_LIMIT", "Limite por hora");
    define("SMTP_LIMIT_PLACEHOLDER", "padrão: 1000");
    define("CAMPAIGN_SMTP", "Selecione SMTP");
    define("SMTP_TESTING", "Testando a conexão SMTP");
    define("SMTP_TESTING_EMAIL", "Endereço para testar a mensagem");
    define("SMTP_RUN_TEST", "Confira!");
    define("SMTP_TEST_TXT_TITLE", "Teste SMTP de.");
    define("SMTP_TEST_TXT_MESSAGE", "Testar mensagem da sua conexão SMTP.");
    define("SMTP_TEST_OK", "A mensagem foi enviada. Verifique sua caixa postal.");
    define("SMTP_TEST_ERROR", "<b>Erro do Mailer: </b>");
    define("SMTP_BEFORE_USE", "<b>Erro do Mailer.</b> Você precisa habilitar a conexão SMTP nas configurações antes de usar.");
    define("BOUNCED_INFO", "Os emails devolvidos voltarão para essa caixa de correio");
    define("SMTP_CONFIG", "Configurar o SMTP para envio");
    define("IMAP_CONFIG", "Configurar o IMAP / POP3 para saltar");
    define("SMTP_INFO_SETUP", "Configurações de SMTP");
    define("IMAP_INFO_SETUP", "Configurações IMAP / POP3");
    define("PROTOCOL", "Protocolo");
    define("FOLDER", "Pasta para acessar");
	
	define("STATISTICS", "Estatísticas");
	define("STATISTICS_ADV", "Detalhes avançados");
	define("STATISTICS_TAB_MAP", "Recipientes no mapa (geolocalização)");
	define("STATISTICS_TAB_DETAILS", "Estatísticas detalhadas");
	define("STATISTICS_TAB_ACTIONS", "Acções especiais");
	define("STATISTICS_BACK", "De volta à lista");
	define("STATISTICS_BUTTON_OPENERS", "Preparar para abridores");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Prepare uma nova campanha para todos os que abriram um email");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Prepare-se para NÃO abridores");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Prepare uma nova campanha para todos aqueles que NÃO abriram um e-mail");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Preparar para cancelar a inscrição");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Prepare uma nova campanha para todos os canceladores de assinatura, se uma opção 'Eliminar automaticamente cancelado' nas definições do sistema estiver activada, os e-mails serão eliminados e nada será adicionado aqui");
	define("STATISTICS_BUTTON_FILTERS", "Preparar com filtros avançados");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Obter uma lista de todos os destinatários desta campanha com dados coletados e preparar uma nova campanha especial com base em filtros avançados");
	define("STATISTICS_TOP_COUNTRIES", "Topo 10 Países");
	define("STATISTICS_TOP_CITIES", "Topo 10 Cidades");
	define("STATISTICS_TOP_CLICKERS", "Topo 15 clickers");
	define("STATISTICS_TOP_SOFTWARE", "Topo 15 software mais popular");
	define("STATISTICS_OTHER_UA", "Todos os outros agentes de usuário");
	define("STATISTICS_OTHERS", "Outras");
    
	define("SOFTWARE", "Programas");
	define("GEODATA", "Localização");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='confirmação'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Cancelar a subscrição do boletim informativo com êxito.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Tenha um bom dia.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Removendo dados desnecessários do banco de dados");
	define("ADDONS_IMPORT_TITLE", "Adicionando modelos de envio de correspondência");
	define("ADDONS_FAQ_TITLE", "Leia antes de perguntar");
	define("ADDONS_ABOUT_TITLE", "Informações sobre o programa e licença");
	define("ADDONS_IMPORT_DATA_TITLE", "Importar dados de amostra para o sistema");
	define("ADDONS_IMPORT_BUTTON", "Importar modelos de e-mail");
	define("ADDONS_IMPORT_BUTTON_DESC", "Isso importará modelos de amostra para");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Confirmar a adição de modelos de exemplo para envio");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Confirme a adição de dados de amostra ao sistema. Todos os dados atualmente inseridos serão apagados!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Por que é melhor ter um servidor dedicado para enviar?</p>
			<p>Primeiro de tudo, sem limites. Para hospedagem ordinária, você pode enviar até 1.000 e-mails por hora e provavelmente a mesma quantidade dentro de um dia (dependendo da faixa de limites de hospedagem de algumas centenas a alguns milhares de e-mails por dia). No servidor, você não tem essas restrições e também tem a capacidade de enviar e-mails do seu domínio. Você também pode enviar e-mails como se o servidor estivesse sob um domínio diferente (neste caso, configure os chamados registros SPF e o domínio TXT - para obter detalhes, pergunte ao seu provedor de hospedagem).</p>
		</li>
		<li>
			<p>O que são tags?</p>
			<p>Facilite a localização de endereços de correspondência e a preparação de uma campanha publicitária em destinatários específicos.</p>
		</li>
		<li>
			<p>Como adicionar o nome do destinatário ao modelo de e-mail?</p>
			<p>Usar a frase {RECIPIENT_NAME} no e-mail do modelo de conteúdo ou no título do e-mail do modelo. A frase será substituída pelo nome do e-mail do destinatário, caso as informações tenham sido adicionadas ao endereço de e-mail do destinatário.</p>
		</li>
		<li>
			<p>Como adicionar uma nova tradução?</p>
			<p>Copie a referência de arquivo english.php, dê um nome que descreva seu idioma por exemplo mylanguage.php e cole na mesma pasta. Corrija todos os textos contidos no novo arquivo. Certifique-se de salvar o arquivo em UTF-8 sem BOM. O arquivo de idioma está no diretório 'languages'.</p>
			<p>Para adicionar a tradução do editor WYSIWYG, vá para https://www.tinymce.com/download/language-packages/ - baixar o idioma do arquivo apropriado e salvá-lo /emailer/libs/tinymce/langs/ pasta.</p>
		</li>
		<li>
			<p>Como faço para adicionar tags a um e-mail?</p>
			<p>Primeiro, você precisa adicionar algumas tags <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>usando este formulário</a>. Então, quando você adicionar / editar cada endereço de e-mail pode ser atribuído a qualquer tag. Todas as tags serão adicionadas abaixo do formulário para adicionar / editar destinatários.</p>
		</li>
		<li>
			<p>Como adicionar a abilidade de unsubscribe fora de receber mensagens?</p>
			<p>Use a frase {UNSUBSCRIBE} no link no conteúdo do modelo de e-mail. A frase será substituída por um link para o destinatário particullar. Quando ele / ela vai clicar nele, o sistema irá salvar no banco de dados informações sobre a quitação da campanha. O endereço de e-mail não será removido do banco de dados. <br>Uso:<br>&lt;a href='{UNSUBSCRIBE}'&gt;Cancelar a subscrição da newsletter&lt;/a&gt;</p>
		</li>
		<li>
			<p>Como adicionar a capacidade de exibição do navegador?</p>
			<p>Use a frase {BROWSER_VIEW} no link no conteúdo do modelo de e-mail. A frase será substituída por um link para o destinatário particullar. Quando ele / ela vai clicar nele, o sistema irá abrir mensagem na janela do navegador.<br>Uso:<br>&lt;a href='{BROWSER_VIEW}'&gt;Visualização do navegador&lt;/a&gt;</p>
		</li>
		<li>
			<p>Como adicionar modelos de e-mail predefinidos?</p>
			<p>30 modelos de amostra mailing, clique aqui <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>para adicionar modelos</a></p>
		</li>
		<li>
			<p>Como faço para adicionar imagens a e-mails?</p>
			<p>- Como anexo de um e-mail. Nesse caso, o atributo de tag IMG do modelo SCR deve ser definido como contentID, significa CID, eg:<br>&lt;img src='cid:logo.jpg' &gt;<br>- Como um link absoluto para uma imagem em recursos externos, como:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>Como o acompanhamento de e-mails?</p>
			<p>Para cada sistema de e-mail enviado pode adicionar uma imagem tag IMG, cujo atributo SRC contém código de acompanhamento para exibir uma mensagem específica. O rastreamento só funcionará quando o destinatário do email concordar em mostrar imagens da mensagem recebida.</p>
		</li>
		<li>
			<p>Como não ser um spammer?</p>
			<p>- Coletar o consentimento para receber mensagens ao criar uma lista de discussão.</p>
			<p>- Use uma variedade de conteúdo para cada destinatário, use ex. {RECIPIENT_NAME} para diferenciar as somas de verificação de sua correspondência.</p>
			<p>- Não use palavras-chave como: sexo, viagra, pornô.</p>
			<p>- Não use frases-chave como: endereço de um banco de dados público, não é informação comercial em mente, desinteressado Desculpe, não constitui uma oferta dentro do significado, se você não quiser, clique aqui para cancelar, gratuitamente, oferta especial, Compre agora - se você tem que usar este frases como você deve considerar para colocá-los na forma de gráficos.</p>
			<p>- Não use gráficos demais, os filtros de spam examinam a proporção dos gráficos para o texto.</p>
			<p>- Correio não deve ser muito pesado.</p>
			<p>- Quanto menos os melhores anexos.</p>
			<p>- Não representar outro domínio.</p>
			<p>- Não envie e-mails de um endereço de e-mail inexistente.</p>
		</li>
		<li>
			<p>Como aumentar cliques e ler campanha?</p>
			<p>A maior influência sobre o conteúdo que você envia para seus clientes eo tempo ea freqüência com que você fazê-lo. Na maioria dos casos, o contato não deve ser mais freqüente do que duas vezes por mês. Respeite seus clientes e eles não vão jogá-lo para o spam.</p>
		</li>
		<li>
			<p>Como escolher os endereços para envio?</p>
			<p>Usando tags, digite-os separados por espaços no campo de pesquisa acima da tabela de endereços.</p>
		</li>
		<li>
			<p>Quais são as limitações deste sistema?</p>
			<p>Não há restrições.</p>
		</li>
		<li>
			<p>Limitar mensagens no servidor de hospedagem?</p>
			<p>Dependendo da gama de limites de hospedagem de algumas centenas a alguns milhares de e-mails por dia, verifique com seu provedor de serviços.</p>
		</li>
		<li>
			<p>Conexão quebrada ao enviar a campanha?</p>
			<p>Você pode retomar o envio de campanhas, e-mails serão enviados para os outros destinatários. Cada email enviado define um marcador exclusivo no banco de dados e a própria campanha não será reenviada para o mesmo destinatário.</p>
		</li>
		<li>
			<p>Requisitos para e-mails devolvidos</p>
			<p>Para ativar o suporte a emails devolvidos, você tem que descomentar esta linha no arquivo php.ini.</p>
			<p>;extension=php_imap.dll</p>
			<p>As funções Imap são necessárias para usar as conexões POP3 / IMAP.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Tenha cuidado, as seguintes ações limpar tabelas no banco de dados!");
	define("ADDONS_DATA_BE_CAREFULLY", "Atenção! Todos os dados serão apagados e substituídos por dados de amostra");
	define("ADDONS_D_AL", "Excluir todos os dados");
	define("ADDONS_D_AL_DESC", "Apaga todos os dados no banco de dados");
	define("ADDONS_D_AL_CONF", "Tem certeza de que deseja remover todos os dados do banco de dados? Serão excluídos todos os endereços de e-mail, modelos, anexos e campanhas.");
	define("ADDONS_D_RE", "Remover os destinatários e suas campanhas");
	define("ADDONS_D_RE_DESC", "Exclui todos os endereços de e-mail no banco de dados e o histórico de campanhas publicitárias");
	define("ADDONS_D_RE_CONF", "Confirme a remoção de todos os destinatários");
	define("ADDONS_D_CA", "Excluir somente campanhas");
	define("ADDONS_D_CA_DESC", "Exclui todas as campanhas publicitárias e sua história");
	define("ADDONS_D_CA_CONF", "Confirmar a remoção de todas as campanhas e seu histórico");
	define("ADDONS_D_TE", "Remover apenas modelos");
	define("ADDONS_D_TE_DESC", "Exclui todos os modelos de e-mail e seus links com campanhas e anexos");
	define("ADDONS_D_TE_CONF", "Confirme a exclusão de todos os modelos");
	define("ADDONS_D_AT", "Excluir apenas anexos");
	define("ADDONS_D_AT_DESC", "Exclui todos os anexos");
	define("ADDONS_D_AT_CONF", "Confirmar excluir todos os anexos");
	define("ADDONS_D_SE", "Excluir somente remetentes");
	define("ADDONS_D_SE_DESC", "Exclui todos os remetentes enviados por e-mail, mas deixa seu ID para fins estatísticos");
	define("ADDONS_D_SE_CONF", "Confirme a remoção de todos os remetentes");
	define("ADDONS_D_TG", "Excluir somente tags");
	define("ADDONS_D_TG_DESC", "Limpar todas as tags inseridas e suas relações com os clientes");
	define("ADDONS_D_TG_CONF", "Confirmar remover todas as etiquetas");
    
	define("WIDGET_PREPARE", "Prepare seu widget de assinatura");
	define("WIDGET_OPTIONS", "Opções");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Gere seu widget de assinatura aqui");
	define("WIDGET_COMMENT", "Comentário sobre o novo destinatário");
	define("WIDGET_COMMENT_PLACEHOLDER", "por exemplo: a partir de domain.ext (Será salvo na descrição do destinatário)");
	define("WIDGET_NAME", "Nome");
	define("WIDGET_NAME_SHOW", "Mostrar o campo do nome do destinatário");
	define("WIDGET_AFTER", "Depois de enviar widget de subscrição");
	define("WIDGET_AFTER_NOTHING", "fazer nada");
	define("WIDGET_AFTER_TXT", "Mostrar mensagem de texto");
	define("WIDGET_AFTER_REDIRECT", "Redirecionar para a página");
	define("WIDGET_TAGS", "Adicionar tags");
	define("WIDGET_PURE_CODE_TXT", "Código HTML puro. Você pode modificá-lo para suas necessidades. Adicione classes, tags, descrições, o que você quiser. Copie o código abaixo e cole-o em seu site.");
	define("WIDGET_FULL_CODE_TXT", "Versão completa (todos os campos incluídos)");
	define("WIDGET_MIN_CODE_TXT", "Versão minimizada (apenas e-mail incluído)");
	define("WIDGET_CODE_DESC_TXT", "Descrição do formulário");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> requeridos.</li>
        <li>Endereço de e-mail do assinante.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> opcional.</li>
        <li>Nome do assinante.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> opcional.</li>
        <li>Campo oculto.</li>
        <li>Eles já devem ser adicionados ao banco de dados.</li>
        <li>Eles devem ser separados por vírgula.</li>
        <li>Usando tags diferentes você pode fazer campanhas diferentes.</li>
        <li>Você pode usar o mesmo formulário em sites diferentes e usar tags diferentes em cada site.</li>
        <li>Isso significa que esse componente pode coletar assinantes de sites diferentes e adicioná-los ao seu sistema com tags diferentes.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> opcional.</li>
        <li>Campo oculto.</li>
        <li>Adicione sua descrição para o destinatário.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> opcional.</li>
        <li>Campo oculto.</li>
        <li>Ativar recurso duplo de ativação.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> opcional.</li>
        <li>Campo oculto.</li>
        <li>Onde redirecionar depois de se inscrever. Se o campo estiver vazio ou não estiver incluído no formulário, a ação configurada será.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Copie o código abaixo e cole-o em seu site");
	define("WIDGET_DBL_OPT_IN", "Opt-in duplo");
	define("WIDGET_DBL_OPT_LABEL", "Verifique se usa a confirmação de assinatura dupla");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "Mensagem de e-mail (HTML de suporte)");
	define("WIDGET_DBL_OPT_HELP", "Não se esqueça de adicionar <b>{CONFIRM_LINK}</b> na sua mensagem.<br>Você também pode adicionar:<br><b>{SUBSCRIBER_EMAIL}</b> - Endereço de e-mail do assinante<br><b>{SUBSCRIBER_NAME}</b> - Nome do assinante<br><b>{SUBSCRIBER_COMMENT}</b> - Seu comentário sobre assinante<br><b>{SUBSCRIBER_TAGS}</b> - Tags usados<br><b>{CURRENT_YEAR}</b> - ano atual<br><b>{CURRENT_MONTH}</b> - mês atual<br><b>{CURRENT_DAY}</b> - dia atual");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "Título do e-mail");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "Digite o título de confirmação de e-mail...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "Digite uma mensagem de confirmação por e-mail...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Redirecionar para após a confirmação");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "Digite o endereço para o qual redirecionar após a confirmação");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Enviar a partir do endereço");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "Digite o endereço de e-mail a partir do qual a confirmação será enviada");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Descrição do remetente");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "Insira a descrição para o remetente");
	define("WIDGET_ADMIN_NOTIFY", "Notificar o administrador sobre o novo assinante");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "Verificar para enviar notificação por e-mail após a nova inscrição é recebida.<br><br><b>ATENÇÃO!</b> O email de administração deve ser configurado em parâmetros do sistema!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Mensagem de administração (HTML de suporte)");
	define("WIDGET_ADMIN_HELP", "Pode ser usado em sua mensagem:<br><b>{SUBSCRIBER_EMAIL}</b> - Endereço de e-mail do assinante<br><b>{SUBSCRIBER_NAME}</b> - Nome do assinante<br><b>{SUBSCRIBER_COMMENT}</b> - Seu comentário sobre assinante<br><b>{SUBSCRIBER_TAGS}</b> - Tags usados<br><b>{CURRENT_YEAR}</b> - ano atual<br><b>{CURRENT_MONTH}</b> - mês atual<br><b>{CURRENT_DAY}</b> - dia atual");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Mensagem de erro do servidor em caso de endereço de e-mail de assinante errado");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Escolha o seu servidor");
	define("BOUNCED_DEL_EMAILS", "Excluir automaticamente da lista de destinatários");
	define("BOUNCED_DEL_MESSAGES", "Excluir automaticamente todas as mensagens rejeitadas e verificadas do servidor");
	define("BOUNCED_MAX", "Limite máximo de mensagens");
	define("BOUNCED_AT_TIME", "para verificar ao mesmo tempo");
	define("BOUNCED_START", "Verificar caixa de correio para emails devolvidos");
	
	define("YES", "Sim");
	define("NO", "Não");
	define("DATA_ERROR", "ERRO: Os dados solicitados não existem...<br><br><a href='index.php'>Clique aqui para abrir o dashboard</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "O servidor para enviar e-mail para o widget de subscrição");
    define("TESTING_TEMPLATE", "Modelo de teste");
    define("TESTING_TEMPLATE_INFO", "Envia o modelo para o e-mail inserido abaixo. As variáveis não serão substituídas.");
    define("TESTING_CHOOSE_SERVER", "Selecionar servidor de envio");
    define("ERRORS", "Erros");
    define("TEST", "Me teste!");
    
    /*v.1.16*/
    define("COPY", "Cópia de");
    define("COPYING", "Lidar");
    define("CHECK", "Verifica");
    define("DATA_VERIFY", "Verificação de integridade dos dados");
    define("DATA_VERIFY_QUESTION", "Tem certeza de que deseja verificar a integridade dos dados?");
    define("DATA_VERIFY_DESCRIPTION", "Esta operação pode demorar vários minutos, depende da quantidade de dados no seu banco de dados. <br> Faça isso se tiver certeza de que a campanha foi concluída e não está visível nessa lista.");
    define("DATA_VERIFY_BUTTON", "Verificar a integridade dos dados");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Filtre os destinatários das tags selecionadas (OR&nbsp;query)");
    define("REC_QUERY_AND", "Os destinatários do filtro estão em TODAS as tags selecionadas (AND&nbsp;query)");
    define("REC_RESET", "Redefinir consulta");
    define("REC_BUTTON_DELETE", "Eliminar destinatários");
    define("CSV_ST_1", "Prepare os dados de acordo com a fórmula:");
    define("CSV_COL_NO", "número da coluna");
    define("CSV_REQ", "requeridos");
    define("CSV_OPT", "opcional");
    define("CSV_ADDR", "endereço de e-mail");
    define("CSV_NAME", "primeiro nome e sobrenome");
    define("CSV_TAGS", "Tag");
    define("CSV_TAGSDESC", "deve estar no banco de dados deve ser separado por um único espaço");
    define("CSV_COMMENT", "comentários");
    define("CSV_DESC1", "Salve a planilha como CSV");
    define("CSV_DESC2", "delimitador");
    define("CSV_MAXLINE", "comprimento máximo da linha CSV");
    define("CSV_FORMDESC", "Faça o upload de um arquivo CSV preparado usando o formulário abaixo");
    define("DISABLE_EDITOR", "Desativar editor");
    define("ENABLE_EDITOR", "Ativar editor");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "Importar e-mails pela ponte DB");
    define("TITLE_IMPORT", "Importação de destinatários");
    define("SUBTITLE_IMPORT", "ponte de banco de dados - params fonte");
    define("LIST_TITLE_IMPORT", "Importar destinatários de outro banco de dados");
    define("ADD_NEW_BRIDGE", "Adicionar nova ponte");
    define("IMPORT_RECIPIENTS", "Importar destinatários");
    define("IMPORT_BRIDGE_DESC", "Descrição da ponte de importação");
    define("CONFIRM_BRIDGE_DEL", "Excluindo conexão de ponte de banco de dados");
    define("IMPORTING_BRIDGE_REC", "Importando destinatários");
    define("CHOOSEN_BRIDGE", "Ponte escolhida para importação");
    
    define("FORM_BRIDGE_DESC", "Descrição da ponte de importação");
    define("BRIDGE_TABLE", "Nome da tabela de origem");
    define("BRIDGE_COL_NAME", "Coluna de origem para o nome do destinatário");
    define("BRIDGE_COL_NAME_INFO", "será importado para o campo Nome do destinatário");
    define("BRIDGE_COL_MAIL", "Coluna de origem para endereço de e-mail");
    define("BRIDGE_COL_MAIL_INFO", "será importado para campo de email");
    define("BRIDGE_COL_DESC", "Coluna de origem para a descrição do destinatário");
    define("BRIDGE_COL_DESC_INFO", "será importado para o campo Descrição");
    define("BRIDGE_CHECK_CON", "Verifique a conexão do banco de dados");
    define("BRIDGE_WAITING", "esperando teste...");
    define("BRIDGE_ADD_NAME", "Nome do destinatário adicional");
    define("BRIDGE_ADD_NAME_INFO", "será adicionado após a coluna do nome da fonte");
    define("BRIDGE_ADD_DESC", "Descrição adicional do destinatário");
    define("BRIDGE_ADD_DESC_INFO", "será adicionado após a coluna de descrição da fonte");
    define("BRIDGE_OVERRIDE", "Substituir os destinatários existentes");
    define("BRIDGE_OVERRIDE_O1", "update - destinatário de destino correto de acordo com a nova fonte");
    define("BRIDGE_OVERRIDE_O2", "ignore - não faça nada se o destinatário já existe");
    define("BRIDGE_TAGS", "Etiquetas disponíveis");
    define("BRIDGE_FILL_FIELDS", "preencha todos os campos obrigatórios antes de testar...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "importação em andamento, aguarde...");
    define("BRIDGE_TEST_OK", "Sua ponte de conexão está funcionando corretamente");
    define("BRIDGE_IMPORT_OK1", "Importação concluída, atualizada:");
    define("BRIDGE_IMPORT_OK2", " Inserido:");
    define("TABLE", "Mesa ");
    define("COLUMN", "Coluna ");
    define("NOT_IN_DB", " não existe no banco de dados ");
    define("NOT_IN_TABLE", " não existe na tabela ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "insira sua chave de API de localização geográfica aqui");
    define("SETTINGS_API_GEO_LINK_INFO", "clique aqui para obter a nova chave da API de geolocalização");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Use https");
    define("HTTPS_USAGE_INFO", "marque se você estiver usando https, isso vai gerar todos os links com https");
    define("TEMPLATE_STATISTICS", "Estatísticas do modelo: ");
    define("TEMPLATE_CHARS", "chaves: ");
    define("TEMPLATE_USAGE", "usava: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Token de registro de formulário de assinatura ");
    define("WIDGET_EMAIL_TOKEN", "Token de registro de e-mail de assinatura ");
    
    /*v.1.22*/
    define("WEBSITE", "Local na rede Internet");
    define("WIDGET_WEBSITE_SHOW", "Mostrar campo de URL do destinatário");
    define("VERIFIED", "Verificado");
    define("VERIFY", "Verificar");
    define("C_PREPARED", "preparado e esperando");
    define("C_AJAX_PROGRESS", "envio de ajax em andamento");
    define("C_FINISHED", "acabado");
    define("C_BG_PROGRESS", "envio de plano de fundo em andamento");
    define("C_PAUSED", "pausado");
    define("C_CRON", "envio cron em progresso");
    define("B_VER", "Verificação em massa");
    define("B_RV", "Confirmação de destinatários em massa");
    define("B_SEND1", "Tem certeza de que deseja enviar");
    define("B_SEND2", "destinatários para verificação");
    define("B_CHECK_LIST", "verificar listas de verificação em massa");
    define("B_VER_INFO", "Seus cheques em massa estarão disponíveis na sua conta do emailable.com");
    define("B_VER_IN_PROG", "verificação em andamento");
    define("B_VER_SENT", "Destinatários enviados para verificação em massa");
    define("B_V_TITLE", "Verificações de email em massa");
    define("B_V_TITLE2", "listas enviadas");
    define("BUTTON_CHECK_STATUS", "Verifique o status");
    define("BUTTON_DOWN_UP", "Baixar atualização");
    define("V_ID", "verificar id");
    define("V_QTY", "quantidade a verificar");
    define("V_DATE", "data de envio");
    define("V_MESSAGE", "Estado");
    define("V_PERC", "% completo");
    define("V_WORKING", "trabalhando");
    define("RESPONSE", "resposta");
    define("V_UPDATED_INFO", "Destinatários atualizados, verifique detalhes");
    define("SETTINGS_API_THECHECKER", "Clique aqui para obter a chave de API emailable.com");
    define("SETTINGS_API_DESCRIPTION", "Vamos matar os saltos! <br>Utilizando o botão abaixo, você receberá <b>30% de EXTRAÇÕES GRATUITAS GRATUITAS</b> na sua primeira compra e dará a você um bônus de 30% (em dinheiro ou cheques) a cada compra que fizer, para sempre!");
    define("EC_DATA", "Exportar todos os dados das campanhas");
    define("EC_DATA1", "Exportar dados da campanha");
    define("EX_OPENED_BUTTON", "Destinatários que abriram");
    define("EX_OPENED_DESC", "Exportar os destinatários da campanha que abriram o email da campanha");
    define("EX_NOT_OPENED_BUTTON", "Destinatários que não abriram");
    define("EX_NOT_OPENED_DESC", "Exportar os destinatários da campanha que NÃO abriram o email da campanha");
    define("EX_UNSUBSRIBED_BUTTON", "Destinatários que não se inscreveram");
    define("EX_UNSUBSRIBED_DESC", "Exportar os destinatários da campanha que cancelaram a inscrição da campanha");
    define("EX_CLICKED_BUTTON", "Destinatários que clicaram");
    define("EX_CLICKED_DESC", "Exportar os destinatários da campanha que clicaram no link no email da campanha");
    define("EX_ALL_BUTTON", "Todos os dados dos destinatários");
    define("EX_ALL_DESC", "Exportar todos os dados dos destinatários da campanha atual");
    define("EX_COUNTRY_BUTTON", "Países destinatários");
    define("EX_COUNTRY_DESC", "Exportar todos os países da campanha atual");
    define("EX_CITY_BUTTON", "Cidades dos destinatários");
    define("EX_CITY_DESC", "Exportar todas as cidades da campanha atual");
    define("EX_BROWSER_BUTTON", "Navegadores de destinatários");
    define("EX_BROWSER_DESC", "Exportar todos os navegadores da campanha atual");
    define("SETTINGS_CHARSET", "Defina seu charset para exportação de dados");
    define("MENU_BULK", "Verificações em massa");
    define("B_CONFIRM", "confirmar a exclusão em massa de emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Atualize destinatários. Se um endereço de email for importado no banco de dados, atualize-o usando os dados no arquivo CSV.");
    define("TAGS_MANAGER_TITLE", "Gerenciador de tags de destinatários, e-mails selecionados: ");
    define("TAGS_SELECT_ACTION", "Escolha sua ação:");
    define("TAGS_MANAGER_ADD", "Adicionar tags aos destinatários selecionados");
    define("TAGS_MANAGER_REMOVE", "Remover tags dos destinatários selecionados");
    define("TAGS_SELECT", "Selecione suas tags:");
    define("SAVE_CHANGES", "Salvar alterações");
    define("NOT_SELECTED_TAGS", "Selecione os destinatários primeiro");
    define("TM_BUTTON", "Gerenciador de tags em massa");
    define("WAITING", "esperando...");
    define("MULTI_SMTP", "Multi SMTP");
    define("MULTI_CHECK_DESC", "verifique se você deseja usar o recurso de envio multi-smtp");
    define("MULTI_CHOOSE", "Escolha servidores smtp");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Lista negra");
    define("BL1", "Lista de domínios e IPs não permitidos");
    define("BL2", "endereços maliciosos bloqueados para assinatura");
    define("BL3", "Sua lista negra");
    define("B_VALUE", "Valor");
    define("B_TYPE", "Tipo");
    define("MENU_ADD_BL", "Adicionar nova entrada");
    define("B_DOMAIN", "domínio");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "Você pode importar a lista de endereços maliciosos para sua lista negra aqui <small>(cada registro deve estar em linha separada)</small>");
    define("B_DELETE_ALL", "Limpar lista negra");
    define("B_DELETE_QUESTION", "Tem certeza de que deseja excluir toda a lista negra?");
    define("B_EXPORT", "Exportar lista negra");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM configurações");
    define("DKIM_USE", "use DKIM");
    define("DKIM_DOMAIN", "Assinando nome de domínio");
    define("DKIM_PRIVATE", "Caminho do arquivo de chave privada");
    define("DKIM_SELECTOR", "Normalmente, a configuração da chave seletora no registro TXT do DNS");
    define("DKIM_PASS", "Usado se a sua chave estiver criptografada");
    define("DKIM_IDENTITY", "Normalmente, o endereço de e-mail usado como fonte do e-mail");
    
    define("ERROR", "Erro:");
    define("WARNING", "AVISO!");
    define("D_MODE", "Alterações e alguns recursos não estão disponíveis no modo DEMO.");
    define("S_DIS", "Envio desativado até você inserir seu código de compra");
    define("HERE", "aqui");
    define("PLIK", "Arquivo");
    define("NOT_WR", "não é gravável. As configurações não serão salvas. Altere as permissões do arquivo antes de salvar.");
    define("EPC", "Código de compra Envato");
    define("EVALIDEPC", "Insira o código de compra válido");
    define("NO_ADMIN_MAIL", "Atualize primeiro o endereço de e-mail do administrador nas configurações.");
    
    define("SMTP_LABEL", "nível de depuração");
    define("SMTP_0", "Desativar depuração");
    define("SMTP_1", "Mensagens de saída enviadas pelo cliente");
    define("SMTP_2", "como 1, mais as respostas recebidas do servidor (esta é a configuração mais útil)");
    define("SMTP_3", "como 2, além de mais informações sobre a conexão inicial - este nível pode ajudar a diagnosticar falhas de STARTTLS");
    define("SMTP_4", "como 3, mais ainda informações de nível inferior, muito prolixo, não use para depurar SMTP, apenas problemas de baixo nível ");
    
    define("SMTP_SENDER_FORCE", "Forçar sempre este remetente em campanhas para este servidor");
    define("SMTP_SENDER_MAIL", "endereço de e-mail do remetente");
    define("SMTP_SENDER_DESCRIPTION", "descrição do remetente");

    
    
