<?php
	/*login page*/
	define("LANG","pl");
	define("LOGIN_TITLE","Mailing system");
	define("LOGIN_SIGN_IN","Zaloguj się");
	define("LOGIN","Login");
	define("LOGIN_PASS","Hasło");
	define("LOGIN_SIGN_IN_BUTTON","Zaloguj");
	define("LOGIN_FAILED","Wproadzono niepoprawny login i/lub hasło!");
	define("INSTALLING_SYSTEM","Konfiguracja systemu");
	define("INSTALLING_CONNECTED","prawidłowo połączono z bazą danych");
	define("INSTALLING_ADD_TABLES","Dodaj tabele");
	define("INSTALLING_ADD_TABLES_DESC","kliknij tu by dodać tabele i uruchomić system");
	
	/*left menu*/
	define("WELCOME","Witam w systemie,");
	define("WELCOME_ASK","Co robimy?");
	define("MAIN_MENU","Menu główne");
	define("START","Start");
	define("DASHBOARD","Dashboard");
	define("EMAIL_ADRESSES","Adresy email");
	define("MENU_RECIPIENT_LIST","Lista odbiorców");
	define("MENU_ADD_RECIPIENT","Dodaj odbiorcę");
	define("MENU_CSV_IMPORT","Import maili z pliku CSV");
	define("MENU_CSV_EXPORT","Export maili do pliku CSV");
	define("MENU_TAG_LIST","Lista tagów");
	define("MENU_ADD_TAGS","Dodaj tagi");
	define("MENU_SENDERS_LIST","Lista nadawców");
	define("MENU_ADD_SENDER","Dodaj nadawcę");
	define("MENU_TEMPLATES","Szablony email");
	define("MENU_TEMPLATES_LIST","Lista szablonów");
	define("MENU_TEMPLATES_ADD","Dodaj nowy szablon");
	define("MENU_TEMPLATES_ATTACHMENTS","Załączniki");
	define("MENU_TEMPLATES_THUMBNAILS","Miniaturki");
	define("MENU_CAMPAIGNS","Twoje kampanie");
	define("MENU_CAMPAIGNS_ADD","Przygotuj nową kampanię");
	define("MENU_CAMPAIGNS_WAITING_LIST","Lista oczekujących kampanii");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Lista kampanii w toku");
	define("MENU_CAMPAIGNS_SENT","Lista wysłanych kampanii");
	define("MENU_SYSTEM_CONFIGURATION","Konfiguracja systemu");
	define("MENU_SETTINGS","Ustawienia");
	define("MENU_LOGIN","Logowanie");
	define("MENU_DB","Baza danych");
	define("MENU_SYSTEM_PARAMS","Parametry systemu");
	define("MENU_SPECIALS","Dodatki specjalne");
	define("MENU_ADDONS","Użyteczne funkcje");
	define("MENU_CLEAR_DB","Wyczyść bazę danych");
	define("MENU_IMPORT_TEMPLATES","Importuj szablony mailingowe");
	define("MENU_IMPORT_DATA","Importuj przykładowe dane");
	define("MENU_FAQ","Dział Q&A");
	define("MENU_ABOUT","O programie");
	define("MENU_SMTP_PARAMS","konfiguracja SMTP");
    define("MENU_UNSUBSCRIBED","Wypisani");
    define("MENU_UNSUBSCRIBED_LIST","lista odbiorców");
    define("MENU_DOCS","Dokumentacja");
    define("MENU_SUBSCRIBE_WIDGET","Widżet subskrybcji");
    define("MENU_BOUNCED","Nie dostarczone (bounced)");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","Baza adresów");
	define("D_EMAIL_ADD_NEW","Dodaj nowy adres");
	define("D_EMAIL_TEMPLATES","Szablony email");
	define("D_EMAIL_TEMPLATES_ADD","Dodaj nowy szablon");
	define("D_EMAIL_SENT","Wysłane maile");
	define("D_EMAIL_EFFICIENCY","Skuteczność");
	define("D_EMAIL_UNSUBSCIBERS","Wypisało się");
	define("D_CAMPAIGNS","Kampanie");
	define("D_CAMPAIGNS_ADD","Dodaj kampanię");
	define("D_CAMPAIGNS_WAITING","Do wysłania");
	define("D_CAMPAIGNS_SENT","Zrealizowane");
	define("D_STATISTICS","Statystyki");
	define("D_THIS_YEAR","Twoje kampanie reklamowe w tym roku");
	define("D_CHECK_ALL","Zobacz wszystkie");
	define("JAN","sty");
	define("FEB","lut");
	define("MAR","mar");
	define("APR","kwi");
	define("MAY","maj");
	define("JUN","cze");
	define("JUL","lip");
	define("AUG","sie");
	define("SEP","wrz");
	define("OCT","paź");
	define("NOV","lis");
	define("DEC","gru");
	define("D_PREPARED_OVERALL","przygotowanych kampanii reklamowych");
	define("D_SENT_OVERALL","wysłanych");
	define("D_HOW_TO","Jak przygotować mailing?");
	define("D_HOW_STEP_1_TITLE","1. Baza adresów email");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Dodaj tagi</a>ułatwią wyszukiwanie odbiorców i pozwolą w łatwy sposób przygotować kampanię reklamową. Następnie <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>dodaj adresy email</a>. <br>Aby szybko uzupełnić adresy email, możesz również <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>zaimportować plik CSV</a>z bazą adresów.");
	define("D_HOW_STEP_2_TITLE","2. Nadawcy");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Dodaj nadawcę</a>możesz zdecydować, od kogo Twoi klienci otrzymają maila.");
	define("D_HOW_STEP_3_TITLE","3. Szablony");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Dodaj szablon</a>przygotuj nieograniczoną ilość szablonów email wraz z dowolną liczbą załączników.");
	define("D_HOW_STEP_4_TITLE","4. Kampanie reklamowe");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Dodaj nową kampanię</a>przygotuj nieograniczoną ilość kampanii. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Wysyłaj kampanie</a>w dowolnym momecie.");
	define("D_HOW_STEP_5_TITLE","5. Obserwuj statystyki");
	define("D_HOW_STEP_5_DESC","Tu się dowiesz, które kampanie są najlepsze, ile kampanii i kiedy zostało przygotowanych a ile wysłanych oraz jaka jest ich skuteczność (czyli ile osób otworzyło Twojego maila).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Zmień login");
	define("CHANGE_PASS","Zmień hasło");
	define("CLEAR_DATABASE","Wyczyść bazę");
	define("LOGOUT","Wyloguj");
	define("ABOUT","O programie");
	
	/*vertical buttons*/
	define("CONFIG","Konfiguracja");
	define("CONFIG_TOOLTIP","Ustawienia systemu");
	define("MEDIA_MANAGER","Załączniki");
	define("RECIPIENT","Adresy email");
	define("RECIPIENT_TOOLTIP","Lista adresów email");
	define("RECIPIENT_EDIT","Modyfikuj odbiorcę");
	define("RECIPIENT_ADD_NEW","Dodaj odbiorcę");
	define("MENUS","Menu");
	define("MENUS_TOOLTIP","Ustawienia menu");
	define("TEMPLATES","Szablony email");
	define("TEMPLATES_TOOLTIP","Ustawienia szablonu");
	define("HELP","Pomoc");
	define("HELP_TOOLTIP","Pomoc na temat programu");
	
	define("FILE_MANAGEMENT","Załączniki");
	define("CSV_IMPORT","Import CSV");
	
	define("PERSON","Osoba");
	define("EMAIL","Adres e-mail");
	define("TAGS","Tagi");
	define("TAGS_LIST","Lista tagów");
	define("TAGS_ADD","Dodaj tagi");
	define("TAGS_ADD_NEW","Dodawanie nowych tagów");
	define("TAGS_ADD_EDIT","Edycja tagu");
	define("TAGS_NAME","Nazwa tagu");
	define("TAGS_DESCRIPTION","Opis");
	define("TAGS_NAME_PLACEHOLDER","Wpisz nazwę tagu");
	define("TAGS_DESCRIPTION_PLACEHOLDER","Opis opcjonalnie...");
	define("TAGS_USED","Wykorzystano");
	define("TAGS_INFO","Tagi do adresów email");
	
	define("RECIPIENT_LIST","Lista odbiorców");
	define("RECIPIENT_NAME","Imię i nazwisko");
	define("RECIPIENT_NAME_PLACEHOLDER","Wpisz imię i nazwisko");
	define("RECIPIENT_MAIL","Adres email");
	define("RECIPIENT_MAIL_PLACEHOLDER","Wpisz adres email");
	define("RECIPIENT_ONLY_TXT","tylko tekstowe maile");
	define("RECIPIENT_DESCRIPTION","Uwagi");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","opcjonalnie...");
	define("RECIPIENT_DB","Baza adresów mailowych");
	define("RECIPIENT_DETAILS_EDIT","Edycja adresu email");
	define("RECIPIENT_DETAILS_ADD","Dodawanie nowego adresu email");
	define("RECIPIENT_IMPORT_CSV","Import adresów email z pliku CSV");
	define("RECIPIENT_PREPARE_CSV","Przygotuj plik CSV zgodnie z poniższymi wytycznymi");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Aby dodać adresy email z Excela należy");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","wzór CSV do pobrania");

	define("RECIPIENT_UPLOAD_CSV_NAME","Importuj plik CSV");
	define("RECIPIENT_NOT_CSV","<b>to nie jest plik CSV !!!</b><br/>");
	define("RECIPIENT_ROW","Wiersz ");
	define("RECIPIENT_WRONG_EMAIL"," - nie poprawny adres mailowy, wpisano: ");
	define("RECIPIENT_EMAIL_EXIST"," - ten adres jest już w bazie danych: ");
	define("RECIPIENT_EMAIL_LACK"," - brak adresu email");
	define("RECIPIENT_EMAIL_IN_DB"," - adres już jest w pliku CSV w wierszu ");
	define("RECIPIENT_TAG_NOT_EXIST"," - nie ma tekiego tagu: ");
	define("RECIPIENT_CSV_ERRORS","Błędy w pliku ");
	define("RECIPIENT_CSV_ADDED","Dodano ");
	define("RECIPIENT_CSV_ADDED_FROM"," adresów mailowych z pliku ");
	define("RECIPIENT_CSV_EXPORT","Eksportowanie adresów mailowych do pliku");
	define("RECIPIENT_CSV_EXPORT_CHK","Zaznacz pola do eksportu:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Adres email odbiorcy");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Imię i nazwisko");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Tagi - oddzielane pojedynczą spacją");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Uwagi");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Czy odbiera tylko tekstowe maile");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Data wprowadzenie");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Data modyfikacji");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","exportuj");
    define("RECIPIENT_CSV_IGNORE_ERRORS","Ignoruj sprawdzanie błędów CSV (zaznacz dla pliku zawierającego więcej niż 1000 emaili - validacja większych plików wymaga dużej ilości pamięci na serwerze)");
	
	define("SAVE","Zapisz");
	define("CANCEL","Anuluj");
	define("DELETE","Usuń");
	define("EDIT","Edytuj");
	define("CREATED","Utworzono");
	define("MODIFIED","Zmodyfikowano");
	define("SEND","Wyślij");
	define("SENT","Wysłano");
	define("PROGRESS","Postęp");
	define("RESUME","Wznów");
	define("CLOSE","Zamknij");
	define("CHANGES_SAVED","Zmiany wprowadzono pomyślnie");
	
	define("DELETING","Usuwanie");
	define("DELETING_CONFIRM_QUESTION","Czy na pewno chcesz usunąć?");
	
	define("DATATABLE_LENGTHMENU", "Pokaż _MENU_ rekordów na stronie");
	define("DATATABLE_ZERORECORDS", "Brak danych");
	define("DATATABLE_INFO", "Strona _PAGE_ z _PAGES_");
	define("DATATABLE_INFOEMPTY", "Brak dostępnych danych");
	define("DATATABLE_INFOFILTERED", "(wybrano _TOTAL_ z _MAX_ wszystkich rekordów)");
	define("DATATABLE_SEARCH", "Szukaj ");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");
	
	define("TEMPLATES_ADD", "Dodaj nowy szablon");
	define("TEMPLATES_LIST", "Lista szablonów");
	define("TEMPLATES_TITLE", "Szablony do mailingu");
	define("TEMPLATES_TITLE_ADD", "Dodawanie nowego szablonu");
	define("TEMPLATES_TITLE_EDIT", "Edycja szablonu");
	define("TEMPLATES_NAME", "Nazwa szablonu");
	define("TEMPLATES_MAIL_TITLE", "Tytuł maila");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Wpisz tytuł maila");
	define("TMPLATES_HTML", "Wersja HTML");
	define("TMPLATES_TXT", "Wersja tekstowa");
	define("TMPLATES_VARIABLES", "Dostępne zmienne (<a href='docs/index.html#variables' target='_blank'>lista zmiennych</a>):");
    define("TEMPLATES_THUMB", "Pogląd");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Edytowanie miniaturek");
	define("THUMBNAIL_MEDIA_LIST", "Lista dostępnych miniaturek");
	
	define("MEDIA_FILENAME", "Nazwa pliku");
	define("MEDIA_FILENAME_DESCRIPTION", "Opis/Uwagi o pliku");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Czas wgrania");
	define("MEDIA_TEMPLATES", "Używany jako załącznik");
	define("MEDIA_LIST", "Lista dostępnych załączników");
	define("MEDIA_ADD_FILES", "Dodaj pliki");
	define("MEDIA_BROWSE", "Szukaj");
	define("MEDIA_UPLOAD", "Wgraj");
	
	define("CAMPAIGN_MENU", "Nowa kampania");
	define("CAMPAIGN_PREPARE", "Przygotuj kampanię");
	define("CAMPAIGN_RECIPIENTS", "Wybierz odbiorców");
	define("CAMPAIGN_TEMPLATES", "Wybierz szablon");
	define("CAMPAIGN_SENDERS", "Wybierz nadawcę");
	define("CAMPAIGN_CONFIRM", "Zapisz kampanię");
	define("CAMPAIGN_SEND", "Wyślij kampanię");
	define("CAMPAIGN_NAME", "Nazwa kampanii");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Wpisz nazwę kampanii");
	define("CAMPAIGN_RECIPIENT_QTY", "Odbiorców");
	define("CAMPAIGN_TEMPLATE_NAME", "Wybrany szablon");
	define("CAMPAIGN_SENDER", "Nadawca");
	define("CAMPAIGN_CREATED_DATE", "Utworzono");
	define("CAMPAIGN_STEP_1", "1. Wybierz adresy (wprowadź filtry w polu szukaj, np. nazwa tagu)");
	define("CAMPAIGN_STEP_2", "2. Zatwierdź kampanię");
	define("CAMPAIGN_SELECT", "Wybierz kampanię do wysłania");
	define("CAMPAIGN_FORM_SELECT", "wybierz...");
	define("CAMPAIGN_CURRENT_STATUS", "Stan wysyłanej kampanii");
	define("CAMPAIGN_SENT_NOW", "Wyślij teraz");
	define("CAMPAIGN_SENT_BUTTON", "Kliknij by rozpocząć wysyłkę");
	define("CAMPAIGN_RESUME_BUTTON", "Kliknij by wznowić wysyłkę");
	define("CAMPAIGN_SERVER_CONNECTING", "łączenie z serwerem, proszę czekać...");
	define("CAMPAIGN_SENDING", "wysyłanie mailingu");
	define("CAMPAIGN_PLEASE_WAIT", "proszę czekać...");
	define("CAMPAIGN_SENT", "<b>MAILING WYSŁANY</b> obiorców: ");
	define("CAMPAIGN_IN_PROGRESS", "Kampanie w trakcie wysyłania");
	define("CAMPAIGN_COMPLETED", "Wysłane kampanie");
	define("CAMPAIGN_LEFT", "Pozostało do wysłania");
    define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Usuń wszystkich wypisanych");
    define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "To spowoduje skasowanie w bazie wszystkch wypisanych odbiorców.");
	define("CAMPAIGN_BG_PROCESS", "Wysyłanie w tle");
	define("CAMPAIGN_BG_PROCESS_INFO", "Urochom jako proces na serwerze (można zamknąć przeglądarkę)");
	define("CAMPAIGN_WHEN_FINISH", "poinformuj gdy skończysz");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "adres na który wysłać informację");
    define("CAMPAIGN_BG_CONFIRM_TXT", "Potwierdź wysyłanie w tle!");
    
    define("HOUR", "godz.");
    define("OPENS", "Otwartych");
    define("BOUNCED", "Nie dostarczono");
    define("CLICKED", "Kliknięć");
    define("UNIQUE_CLICKS", "Unikalnych klików");
    define("TOTAL_CLICKS", "Wszystkich klików");
	
	define("SENDER_LIST", "Lista nadawców");
	define("SENDER_ADD", "Dodaj nadawcę");
	define("SENDER_NAME", "Nazwa nadawcy");
	define("SENDER_NAME_PLACEHOLDER", "Wpisz nazwę nadawcy");
	define("SENDER_EMAIL", "Email nadawcy");
	define("SENDER_EMAIL_PLACEHOLDER", "Wpisz email nadawcy");
	define("SENDER_TITLE_ADD", "Dodawanie nadawcy");
	define("SENDER_TITLE_EDIT", "Edycja nadawcy");
	define("SENDER_EMAIL_TITLE", "Adres email nadawcy");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Wpisz adres email nadawcy");
	
	define("SETTINGS", "Ustawienia");
	define("SETTINGS_LOGIN_TITLE", "Wprowadź nowe ustawienia logowania");
	define("SETTINGS_LOGIN_LABEL", "Nowy login");
	define("SETTINGS_LOGIN_PLACEHOLDER", "login...");
	define("SETTINGS_CURR_PASS", "Obecne hasło");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "wpisz hasło");
	define("SETTINGS_NEW_PASS", "Nowe hasło");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "nowe hasło");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "potwierdź");
	define("SETTINGS_DB_PARAMS", "Ustaw parametry bazy danych");
	define("SETTINGS_DB_HOST", "Serwer bazy danych");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "np. localhost");
	define("SETTINGS_DB_USER", "Użytkownik");
	define("SETTINGS_DB_USER_PLACEHOLDER", "np. root");
	define("SETTINGS_DB_PASSWORD", "Hasło do bazy");
	define("SETTINGS_DB_NAME", "Nazwa bazy");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "np. mailing");
	define("SETTINGS_GLOBAL", "Ustawienia globalne");
	define("SETTINGS_LANG", "Język");
	define("SETTINGS_LIMIT", "Limit maili/godzinę");
	define("SETTINGS_LIMIT_PLACEHOLDER", "domyślnie 1000");
	define("SETTINGS_TRACKING", "Włącz śledzenie maili");
	define("SENDING_METHOD", "Sposób wysyłania");
    define("SETTINGS_UNSUBSCRIBED", "Automatycznie usuwaj wypisanych");
    define("SETTINGS_UNS_INFO", "email będzie automatycznie usuwany, gdy użytkownik kliknie link do wypisania się");
    define("SETTINGS_TRACK_INFO", "znacznik img zostanie dodany aby śledzić odbiorcę");
	define("SETTINGS_API_LABEL", "Mapy Google<br>klucz API");
	define("SETTINGS_API_PLACEHOLDER", "wprowadź swój klucz do API v.3");
	define("SETTINGS_API_LINK_INFO", "uzyskaj klucz do API");
	define("SETTINGS_ADMIN_MAIL", "Email admina");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "email do komunikatów systemowych");
	define("SETTINGS_PHP_TIMEOUT", "PHP timeout (w sekundach)");
    
	define("SMTP_SERVER_DESCRIPTION", "Serwer SMTP, pamiętaj aby skonfigurować");
	define("SMTP_LIST", "lista serwerów");
    define("SMTP_ADD", "dodawanie nowego serwera");
    define("SMTP_EDIT", "edycja serwera");
    define("SMTP_INFO", "Twoje serwery SMTP");
    define("SMTP_ADD_BUTTON", "Dodaj nowy serwer");
    define("SMTP_NAME", "Nazwa połączenia");
    define("SMTP_NAME_PLACEHOLDER", "np.: moj serwer XXX");
    define("SMTP_HOST", "Adres serwera");
    define("SMTP_HOST_PLACEHOLDER", "serwer SMTP z którego będziemy wysyłać maile");
    define("SMTP_PAUTH", "Authorization");
    define("SMTP_PAUTH_PLACEHOLDER", "Wymagana autoryzacja do serwera SMTP");
    define("SMTP_VERIFY_PEER", "Włącz weryfikację zertyfikatu SSL/TLS");
    define("SMTP_FORCE_SMTP", "Wymuszaj użycie SMTP");
    define("SMTP_USERNAME", "Login");
    define("SMTP_USERNAME_PLACEHOLDER", "odbite maile");
    define("SMTP_LOGIN", "SMTP login");
    define("SMTP_LOGIN_PLACEHOLDER", "login do serwera SMTP");
    define("SMTP_PASSWORD", "Hasło");
    define("SMTP_PASSWORD_PLACEHOLDER", "Hasło do zalogowania");
    define("SMTP_REPLYTO", "Odpowiedz do");
    define("SMTP_REPLYTO_PLACEHOLDER", "Adres alternatywny na który ma wracać poczta");
    define("SMTP_REPLYTONAME", "Nazwa zwrotna");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Opis adresu alternatywnego na który ma wracać poczta");
    define("SMTP_SECURE", "Szyfrowanie");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> domyślnie");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> akceptowalne, nie zalecane");
    define("SMTP_PORT", "port serwera");
    define("SMTP_PORT_PLACEHOLDER", "Port używany do komunikacji z serwerem SMTP");
    define("SMTP_LIMIT", "Limit maili/godz.");
    define("SMTP_LIMIT_PLACEHOLDER", "domyślnie 1000");
    define("CAMPAIGN_SMTP", "Wybierz SMTP");
    define("SMTP_TESTING", "Testowanie połączenia SMTP");
    define("SMTP_TESTING_EMAIL", "Wyślij maila testowego na ten adres");
    define("SMTP_RUN_TEST", "Wyślij teraz!");
    define("SMTP_TEST_TXT_TITLE", "Test połączenia SMTP od E-mailer.");
    define("SMTP_TEST_TXT_MESSAGE", "Wiadomość testowa z Twojego połączenia SMTP.");
    define("SMTP_TEST_OK", "Wiadomość została wysłana. Sprawdź swoją skrzynkę");
    define("SMTP_TEST_ERROR", "<b>Błąd wysyłania: </b>");
    define("SMTP_BEFORE_USE", "<b>Błąd wysyłania.</b> Włącz obsługę SMTP aby wysłać maila.");
    define("BOUNCED_INFO", "maile zwrotne nie dostarczone przyjdą na tą skrzynkę");
    define("SMTP_CONFIG", "Konfiguracja serwera SMTP do wysyłania");
    define("IMAP_CONFIG", "Konfiguracja serwera IMAP / POP3 do odbierania");
    define("SMTP_INFO_SETUP", "ustawienia SMTP");
    define("IMAP_INFO_SETUP", "ustawienia IMAP / POP3");
    define("PROTOCOL", "Protokół");
    define("FOLDER", "Folder");
	
	define("STATISTICS", "Statystyki");
    define("STATISTICS_ADV", "Dane szczegółowe");
	define("STATISTICS_TAB_MAP", "Odbiorcy na mapie");
	define("STATISTICS_TAB_DETAILS", "Szczegółowe dane");
	define("STATISTICS_TAB_ACTIONS", "Zadania specjalne");
	define("STATISTICS_BACK", "Powrót do listy");
	define("STATISTICS_BUTTON_OPENERS", "Dla tych którzy otworzyli");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Przygotuj nową kampanię dla tych którzy otworzyli maila");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Dla tych którzy NIE otworzyli");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Przygotuj nową kampanię dla tych którzy NIE otworzyli maila");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Dla tych którzy się wypisali");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Przygotuj nową kampanię dla tych którzy się wypisali. Jeżeli opcja automatycznego usuwania maila, gdy klient się wypisuje, jest włączona to nie będzie co dodać do listy");
	define("STATISTICS_BUTTON_FILTERS", "Użyj zaawansowanych filtrów");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Przygotuj dla wszystkich odbiorców kampanii stosując zaawansowane filtry");
	define("STATISTICS_TOP_COUNTRIES", "Państwa");
	define("STATISTICS_TOP_CITIES", "Miasta");
	define("STATISTICS_TOP_CLICKERS", "Odbiorcy");
	define("STATISTICS_TOP_SOFTWARE", "Najpopularniejsze oprogramowanie");
	define("STATISTICS_OTHER_UA", "Pozostałe przeglądarki");
	define("STATISTICS_OTHERS", "Pozostałe");
    
	define("SOFTWARE", "Oprogramowanie");
	define("GEODATA", "Lokalizacja");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='pl'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='potwierdzenie'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Pomyślnie wypisano adres z newslettera.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Miłego dnia.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Usuwanie niepotrzebnych informacji z bazy danych");
	define("ADDONS_IMPORT_TITLE", "Dodawanie przykładowych szablonów mailingowych");
	define("ADDONS_FAQ_TITLE", "Przeczytaj zanim zapytasz");
	define("ADDONS_ABOUT_TITLE", "Informacje na temat programu i licencji");
	define("ADDONS_IMPORT_DATA_TITLE", "Importowanie przykładowych danych do systemu");
	define("ADDONS_IMPORT_BUTTON", "Importuj szablony mailowe");
	define("ADDONS_IMPORT_BUTTON_DESC", "Wprowadź do systemu przykładowe szablony do mailingu");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Potwierdź dodanie przykładowych szablonów mailingowych");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Potwierdź dodanie przykładowych danych do systemu. Wszystkie aktualnie wprowadzone dane zostaną skasowane!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Dlaczego warto mieć własny serwer dedykowany do mailingu?</p>
			<p>Przede wszystkim brak limitów. Na zwykłym hostingu możesz wysłać maksymalnie do 1000 maili w ciągu godziny i prawdopodobnie tyle samo w ciagu jednej doby (w zależności od hostingu limity wahają się od kilkuset do kilku tysięcy maili dziennie). Na swoim serwerze nie masz takich ograniczeń i posiadasz też możliwość wysyłania maili ze swojej domeny. Możesz też wysyłać maile tak, jakby serwer znajdował by się pod inną domeną (warto w takim przypadku ustawić tak zwane rekordy SPF oraz TXT na domenie - o szczegóły zapytaj swojego dostawcę hostingu).</p>
		</li>
		<li>
			<p>Do czego służą tagi?</p>
			<p>Ułatwiają wyszukiwanie adresów mailowych i przygotowanie kampanii reklamowej pod konkretnych odbiorców.</p>
		</li>
		<li>
			<p>Jak dodać imię i nazwisko odbiorcy do wysyłanego maila?</p>
			<p>Użyj frazy {RECIPIENT_NAME} w treści szablonu maila lub w tytule szablonu maila. Fraza zostanie zastąpiona imieniem i nazwiskiem odbiorcy maila, pod warunkiem że informacje te zostały dopisane do adresu email odbiorcy.</p>
		</li>
		<li>
			<p>Jak dodać nowy język?</p>
			<p>Skopiuj plik wzorcowy english.php do tego samego folderu, nadaj mu nazwę opisującą Twój język np. mylanguage.php. Popraw wszystkie teksty zawarte w nowym pliku. Pamiętaj aby zapisać plik w formacie UTF-8 w/o BOM. Wzorcowy plik językowy znajduje się w katalogu 'languages'.</p>
		</li>
		<li>
			<p>Jak dodać tagi do adresu email?</p>
			<p>W pierwszej kolejności musisz dodać kilka tagów <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>używając tego formularza</a>. Następnie przy dodawaniu/edycji do każdego adresu email możesz przyporządkować dowolny tag. Wszytkie dodane tagi będą pod formularzem do dodawania/edycji odbiorcy.</p>
		</li>
		<li>
			<p>Jak dodać możliwość rezygnacji z otrzymywania wiadomości?</p>
			<p>Użyj frazy {UNSUBSCRIBE} w linku w treści szablonu maila. Fraza zostanie zastąpiona linkiem dla odbiorcy, który po kliknięciu zapisze w bazie informacje o wypisaniu się z danej kampanii. Adres email nie zostanie usunięty z bazy. <br>Sposób użycia:<br>&lt;a href='{UNSUBSCRIBE}'&gt;wypisz się z newslettera&lt;/a&gt;</p>
		</li>
		<li>
			<p>Jak dodać możliwość obejrzenia wiadomości w oknie przeglądarki?</p>
			<p>Użyj frazy {BROWSER_VIEW} w linku w treści szablonu maila. Fraza zostanie zastąpiona linkiem dla odbiorcy, który po kliknięciu otworzy wiadomość w przeglądarce. <br>Sposób użycia:<br>&lt;a href='{BROWSER_VIEW}'&gt;wyświetl w przeglądarce&lt;/a&gt;</p>
		</li>
		<li>
			<p>Jak dodać predefiniowane szablony mailowe?</p>
			<p>30 przykładowych szablonów mailowych, kliknij tu <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>aby dodać szablony</a></p>
		</li>
		<li>
			<p>Jak dodawać obrazki do maili?</p>
			<p>- Jako załącznik do maila. W tym przypadku w szablonie znacznik IMG w atrybucie SCR musi mieć ustawiony contentID, czyli CID, przykład:<br>&lt;img src='cid:logo.jpg' &gt;.<br>- Jako link bezwzględny do obrazka w zewnętrznych zasobach, przykład:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>Jak działa śledzenie maili?</p>
			<p>Do każdej wysłanej wiadomości email, dodawany jest znacznik obrazka IMG, który w atrybucie SRC zawiera kod śledzący wyświetlenie konkretnego maila. Śledzenie zadziała tylko wtedy, gdy odbiorca maila zgodzi się na pokazywanie obrazków w otrzymanej wiadomości.</p>
		</li>
		<li>
			<p>Jak nie zostać spamerem?</p>
			<p>- Zbieraj zgody na otrzymywanie wiadomości przy tworzeniu listy mailingowej.</p>
			<p>- Używaj róznej treści dla każdego odbiorcy, używaj np {RECIPIENT_NAME} aby sumy kontrolne twojego mailingu się nie powtarzały.</p>
			<p>- Nie używaj słów kluczowych typu: sex, viagra, porn.</p>
			<p>- Nie używaj fraz kluczowych typu: adres pochodzi z ogólnodostępnej bazy, to nie jest informacja handlowa w myśl, niezainteresowanych przepraszamy, nie stanowi oferty w rozumieniu, jeżeli nie chcesz, kliknij tutaj, wypisz, darmowy, oferta specjalna, kup teraz - jeżeli chcesz używać tego typu fraz warto umieszczać je w formie grafiki.</p>
			<p>- Nie używaj za dużo grafiki, filtry antyspamowe badają stosunek ilości grafiki do tekstu.</p>
			<p>- Mail nie powinien być zbyt ciężki.</p>
			<p>- Im mniej załączników tym lepiej.</p>
			<p>- Nie podszywaj się pod inną domenę.</p>
			<p>- Nie wysyłaj z nie istniejących adresów email.</p>
		</li>
		<li>
			<p>Jak zwiększyć otwieralność i klikalność kampanii?</p>
			<p>Największy wpływ ma treść, jaką przesyłasz do swoich odbiorców oraz czas i częstotliwość z jaką to robisz. W większości przypadków kontakt nie powinien być częstszy niż 2 razy w miesiącu. Szanuj swoich odbiorców to nie wrzucą Cię do spamu.</p>
		</li>
		<li>
			<p>Jak wybrać adresy do mailingu?</p>
			<p>Używaj tagów, wpisuj je oddzielane spacjami w polu szukaj ponad tabelką z adresami.</p>
		</li>
		<li>
			<p>Jakie są ograniczenia tego systemu?</p>
			<p>Nie wprowadzono żadnych ograniczeń.</p>
		</li>
		<li>
			<p>Limity wiadomości na serwerze hostingowym?</p>
			<p>W zależności od hostingu limity wahają się od kilkuset do kilku tysięcy maili dziennie, sprawdź u swojego usługodawcy.</p>
		</li>
		<li>
			<p>Zerwane połączenie w trakcie wysyłania kampanii?</p>
			<p>Możesz wznowić wysyłanie kampanii, emaile będą wysyłane do pozostałych odbiorców. Każdy wysłany email ustawia unikatowy znacznik w bazie danych i ta sama kampania nie będzie ponownie wysłana do tego samego odbiorcy.</p>
		</li>
		<li>
			<p>Wymagania dla bounced email</p>
			<p>Aby można było obsłużyć połączenia POP3 / IMAP, proszę w pliku php.ini file odkomentować poniższą linię.</p>
			<p>;extension=php_imap.dll</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Działaj ostrożnie, poniższe akcje czyszczą tabele w bazie danych!");
	define("ADDONS_DATA_BE_CAREFULLY", "Uwaga! Wszystkie dane w bazie zostaną SKASOWANE i zastąpione przykładowymi wpisami");
	define("ADDONS_D_AL", "Usuń wszystkie dane");
	define("ADDONS_D_AL_DESC", "Kasuje wszystkie dane w bazie");
	define("ADDONS_D_AL_CONF", "Czy na pewno usunąć wszystkie dane z bazy danych? Zostaną skasowane wszystkie adresy email, szablony, załączniki i kampanie.");
	define("ADDONS_D_RE", "Usuń odbiorców i ich kampanie");
	define("ADDONS_D_RE_DESC", "Kasuje wszystkie adresy mailowe w bazie danych oraz historię kampanii reklamowych");
	define("ADDONS_D_RE_CONF", "Potwierdź usuwanie wszystkich odbiorców");
	define("ADDONS_D_CA", "Usuń tylko kampanie");
	define("ADDONS_D_CA_DESC", "Kasuje wszystkie kampanie reklamowe wraz z ich historią");
	define("ADDONS_D_CA_CONF", "Potwierdź usuwanie wszystkich kampanii wraz z ich historią");
	define("ADDONS_D_TE", "Usuń tylko szablony");
	define("ADDONS_D_TE_DESC", "Kasuje wszystkie szablony email oraz ich powiązania z kampaniami i załącznikami");
	define("ADDONS_D_TE_CONF", "Potwierdź usuwanie wszystkich szablonów");
	define("ADDONS_D_AT", "Usuń tylko załączniki");
	define("ADDONS_D_AT_DESC", "Kasuje wszystkie załączniki");
	define("ADDONS_D_AT_CONF", "Potwierdź usuwanie wszystkich załączników");
	define("ADDONS_D_SE", "Usuń tylko nadawców");
	define("ADDONS_D_SE_DESC", "Kasuje wszystkich wprowadzonych nadawców email ale pozostawia ich ID w kampaniach w celach statystycznych");
	define("ADDONS_D_SE_CONF", "Potwierdź usuwanie wszystkich nadawców");
	define("ADDONS_D_TG", "Usuń tylko tagi");
	define("ADDONS_D_TG_DESC", "Kasuje wszystkie wprowadzone tagi i ich powiązania z odbiorcami");
	define("ADDONS_D_TG_CONF", "Potwierdź usuwanie wszystkich tagów");
    
	define("WIDGET_PREPARE", "Przygotuj formularz do subskrybcji");
	define("WIDGET_OPTIONS", "Opcje");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Generowanie widżetu subskrybcji");
	define("WIDGET_COMMENT", "Opis nowego odbiorcy");
	define("WIDGET_COMMENT_PLACEHOLDER", "np.: z domeny domain.ext (opis odbiorcy)");
	define("WIDGET_NAME", "Nazwa odbiorcy");
	define("WIDGET_NAME_SHOW", "Pokaż pole z nazwą");
	define("WIDGET_AFTER", "Po zapisaniu");
	define("WIDGET_AFTER_NOTHING", "nic nie rób");
	define("WIDGET_AFTER_TXT", "pokaż tekst");
	define("WIDGET_AFTER_REDIRECT", "przekieruj na stronę");
	define("WIDGET_TAGS", "Dodaj tagi");
	define("WIDGET_PURE_CODE_TXT", "Czysty kod HTML. Można zmodyfikować go do swoich potrzeb. Dodaj klasy, tagi, opisy, co chcesz. Skopiuj poniższy kod i wklej go na swojej stronie.");
	define("WIDGET_FULL_CODE_TXT", "Pełna wersja (wszystkie pola zawarte)");
	define("WIDGET_MIN_CODE_TXT", "Wersja zminimalizowana (tylko e-mail w formularzu)");
	define("WIDGET_CODE_DESC_TXT", "Opis pól formularza");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> wymagane.</li>
        <li>Adres e-mail odbiorcy.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> opcjonalnie.</li>
        <li>Nazwa odbiorcy.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> opcjonalnie.</li>
        <li>Ukryte pole.</li>
        <li>Muszą już być dodawane do bazy.</li>
        <li>Muszą być oddzielone przecinkiem.</li>
        <li>Korzystając z różnych tagów można przygotować różne kampanie.</li>
        <li>Można używać tego samego formularza na różnych stronach. Na każdej mogą być inne tagi.</li>
        <li>Oznacza to, że ten komponent może zbierać subskrybentów z różnych stron i dodawać je do twojego systemu z różnymi tagami.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> opcjonalnie.</li>
        <li>Ukryte pole.</li>
        <li>Opis dla nowego odbiorcy.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> opcjonalnie.</li>
        <li>Ukryte pole.</li>
        <li>Potwierdzenie subskrybcji mailem.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> opcjonalnie.</li>
        <li>Ukryte pole.</li>
        <li>Gdzie przekierować po zapisaniu odbiorcy. Jak będzie puste, użyte zostaną parametry konfiguracyjne.</li>
    ");
    
    
    define("WIDGET_USE_THIS_CODE", "Skopiuj poniższy kod i wklej go na swojej stronie");
    define("WIDGET_DBL_OPT_IN", "Dwu etapowy system subskrybcji");
    define("WIDGET_DBL_OPT_LABEL", "zaznacz by użyć potwierdzania subskrybcji mailem");
    define("WIDGET_DBL_OPT_LABEL_EMAIL", "Wiadomość");
    define("WIDGET_DBL_OPT_HELP", "dodaj <b>{CONFIRM_LINK}</b> do wiadomości<br>Dodatkowe opcje:<br><b>{SUBSCRIBER_EMAIL}</b> - adres mailowy odbiorcy<br><b>{SUBSCRIBER_NAME}</b> - nazwa odbiorcy<br><b>{SUBSCRIBER_COMMENT}</b> - twój komentarz<br><b>{SUBSCRIBER_TAGS}</b> - użyte tagi<br><b>{CURRENT_YEAR}</b> - bieżący rok<br><b>{CURRENT_MONTH}</b> - bieżący miesiąc<br><b>{CURRENT_DAY}</b> - bieżący dzień");
    define("WIDGET_DBL_OPT_TITLE_EMAIL", "Tytuł maila");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "wprowadź tytuł maila");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "wprowadź wiadomość");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Przekieruj tu po potwierdzeniu");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "wprowadź adres z http:// na który ma nastąpić przekierowanie");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "wyślij z adresu");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "wprowadź adres z którego wysłać maila");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "opis nadawcy");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "wprowadź opis nadawcy");
	define("WIDGET_ADMIN_NOTIFY", "Potwierdzenie subskrybcji");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "mysyła maila do admina po wykonaniu prawidłowej subskrybcji<br><br><b>UWAGA!</b> Adres mailowy administratora musi być ustawiony w parametrach systemu!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Wiadomość");
	define("WIDGET_ADMIN_HELP", "Dostępne zmienne:<br><b>{SUBSCRIBER_EMAIL}</b> - adres mailowy odbiorcy<br><b>{SUBSCRIBER_NAME}</b> - nazwa odbiorcy<br><b>{SUBSCRIBER_COMMENT}</b> - twój komentarz<br><b>{SUBSCRIBER_TAGS}</b> - użyte tagi<br><b>{CURRENT_YEAR}</b> - bieżący rok<br><b>{CURRENT_MONTH}</b> - bieżący miesiąc<br><b>{CURRENT_DAY}</b> - bieżący dzień");
	define("WIDGET_ERROR_MESSAGE_LABEL", "Komunikat zwracany przez serwer przy podaniu nieprawidłowego adresu mailowego");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Wybierz serwer");
	define("BOUNCED_DEL_EMAILS", "Automatycznie usuwaj maile z listy odbiorców");
	define("BOUNCED_DEL_MESSAGES", "Automatycznie usuwaj wiadomości z serwera pocztowego");
	define("BOUNCED_MAX", "Limit wiadomości");
	define("BOUNCED_AT_TIME", "sprawdzanych na raz");
	define("BOUNCED_START", "Rozpocznij sprawdzanie niedostarczonych maili");
	
	define("YES", "Tak");
	define("NO", "Nie");
	define("DATA_ERROR", "ERROR: Żądane dane nie istnieją...<br><br><a href='index.php'>kliknij tu by otworzyć stronę główną</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "Serwer do wysyłania maili dla widżetu subskrybcji");
    define("TESTING_TEMPLATE", "Testowanie szablonu");
    define("TESTING_TEMPLATE_INFO", "Wysyła szablon na podany poniżej email. Zmnienne nie będą podstawiane.");
    define("TESTING_CHOOSE_SERVER", "Wybierz serwer do wysłania maila z szablonem");
    define("ERRORS", "Błędy");
    define("TEST", "Testuj!");
    
    /*v.1.16*/
    define("COPY", "Kopiuj");
    define("COPYING", "Kopiowanie");
    define("CHECK", "Sprawdź");
    define("DATA_VERIFY", "Sprawdzanie integralności danych");
    define("DATA_VERIFY_QUESTION", "Czy jesteś pewien że chcesz uruchomić sprawdzanie integralności danych?");
    define("DATA_VERIFY_DESCRIPTION", "To może zająć trochę czasu w zależności od ilości danych w bazie. Wykonaj jeżeli jesteś pewien że kampania jest zakończona ale nie widoczna na bieżącej liście.");
    define("DATA_VERIFY_BUTTON", "Sprawdź integralność danych");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Znajdź odbiorców wg tagów (OR&nbsp;query)");
    define("REC_QUERY_AND", "Znajdź odbiorców z wieloma tagami (AND&nbsp;query)");
    define("REC_RESET", "Pokaż wszystko");
    define("REC_BUTTON_DELETE", "Usuń odbiorców");
    define("CSV_ST_1", "Przygotować dane wg wzoru:");
    define("CSV_COL_NO", "kolumna nr");
    define("CSV_REQ", "wymagane");
    define("CSV_OPT", "opcjonalnie");
    define("CSV_ADDR", "adres email");
    define("CSV_NAME", "imię i nazwisko");
    define("CSV_TAGS", "tagi");
    define("CSV_TAGSDESC", "muszą być w bazie danych, muszą być oddzielane pojedynczą spacją");
    define("CSV_COMMENT", "uwagi");
    define("CSV_DESC1", "Zapisać arkusz w formacie CSV");
    define("CSV_DESC2", "separator");
    define("CSV_MAXLINE", "maksymalna długość linii w pliku CSV");
    define("CSV_FORMDESC", "Wgrać przygotowany plik CSV za pomocą poniższego formularza");
    define("DISABLE_EDITOR", "Wyłącz edytor");
    define("ENABLE_EDITOR", "Włącz edytor");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "Import maili z innej bazy");
    define("TITLE_IMPORT", "Importowanie maili");
    define("SUBTITLE_IMPORT", "połączenia do innej bazy danych");
    define("LIST_TITLE_IMPORT", "Importuj odbiorców z innej bazy danych");
    define("ADD_NEW_BRIDGE", "Dodaj nowy import");
    define("IMPORT_RECIPIENTS", "Importuj adresy email");
    define("IMPORT_BRIDGE_DESC", "Dostępne importy danych");
    define("CONFIRM_BRIDGE_DEL", "Usuń import");
    define("IMPORTING_BRIDGE_REC", "Importowanie odbiorców");
    define("CHOOSEN_BRIDGE", "Wybrany import");
    
    define("FORM_BRIDGE_DESC", "Nazwa importu");
    define("BRIDGE_TABLE", "Źródłowa tabela");
    define("BRIDGE_COL_NAME", "Kolumna źródłowa dla nazwy odbiorcy");
    define("BRIDGE_COL_NAME_INFO", "zostanie zaimportowane do pola Nazwa odbiorcy");
    define("BRIDGE_COL_MAIL", "Kolumna źródłowa adresu e-mail");
    define("BRIDGE_COL_MAIL_INFO", "zostanie zaimportowane do pola Email");
    define("BRIDGE_COL_DESC", "Kolumna źródłowa do opisu odbiorcy");
    define("BRIDGE_COL_DESC_INFO", "zostanie zaimportowane do pola Opis");
    define("BRIDGE_CHECK_CON", "Sprawdź połączenie z bazą danych");
    define("BRIDGE_WAITING", "czekam na test...");
    define("BRIDGE_ADD_NAME", "Dodatkowa nazwa odbiorcy");
    define("BRIDGE_ADD_NAME_INFO", "zostanie dodana po polu z nazwą");
    define("BRIDGE_ADD_DESC", "Dodatkowy opis odbiorcy");
    define("BRIDGE_ADD_DESC_INFO", "zostanie dodany po polu opisu");
    define("BRIDGE_OVERRIDE", "Zastąp istniejących odbiorców");
    define("BRIDGE_OVERRIDE_O1", "update - aktualizuj dane istniejącego odbiorcę");
    define("BRIDGE_OVERRIDE_O2", "ignore - nie rób nic, jeśli odbiorca docelowy już istnieje");
    define("BRIDGE_TAGS", "Dostępne tagi");
    define("BRIDGE_FILL_FIELDS", "wypełnij wymagane pola przed testowaniem...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "importowanie w toku, proszę czekać...");
    define("BRIDGE_TEST_OK", "Twoje połączenie działa poprawnie");
    define("BRIDGE_IMPORT_OK1", "Importowanie zakończone. Zaktualizowano:");
    define("BRIDGE_IMPORT_OK2", " Dodano:");
    define("TABLE", "Tabela ");
    define("COLUMN", "Kolumna ");
    define("NOT_IN_DB", " nie istnieje w bazie danych ");
    define("NOT_IN_TABLE", " nie istnieje w tabeli ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "geolokalizacja ipstack<br>klucz API");
    define("SETTINGS_API_GEO_PLACEHOLDER", "wprowadź swój klucz API do geolokalizacji");
    define("SETTINGS_API_GEO_LINK_INFO", "kliknij tu aby uzyskać klucz API do geolokalizacji");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Użyj https");
    define("HTTPS_USAGE_INFO", "zaznacz jeśli używasz https, wygeneruje linki w szablonie z https");
    define("TEMPLATE_STATISTICS", "Szablon: ");
    define("TEMPLATE_CHARS", "znaków: ");
    define("TEMPLATE_USAGE", "wykorzystano: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Klucz autoryzacyjny formularza rejestracyjnego ");
    define("WIDGET_EMAIL_TOKEN", "Klucz autoryzacyjny maila z subskrypcją ");
    
    /*v.1.22*/
    define("WEBSITE", "Strona www");
    define("WIDGET_WEBSITE_SHOW", "Pokaż pole z adresem strony www");
    define("VERIFIED", "Sprawdzone");
    define("VERIFY", "Sprawdź");
    define("C_PREPARED", "przygotowane i czeka");
    define("C_AJAX_PROGRESS", "wysyłanie ajax w toku");
    define("C_FINISHED", "zakończono");
    define("C_BG_PROGRESS", "wysyłanie w toku");
    define("C_PAUSED", "przerwano");
    define("C_CRON", "wysyłanie cron w toku");
    define("B_VER", "Sprawdź całą paczkę maili");
    define("B_RV", "Hurtowe sprawdzanie adresów email");
    define("B_SEND1", "Czy na pewno wysłać ");
    define("B_SEND2", "adresów email do sprawdzenia");
    define("B_CHECK_LIST", "Lista wysłanych paczek do sprawdzenia");
    define("B_VER_INFO", "Paczka z adresami będzie dostępna na twoim koncie emailable.com");
    define("B_VER_IN_PROG", "sprawdzanie w toku");
    define("B_VER_SENT", "Adresy wysłane do sprawdzenia hurtowego");
    define("B_V_TITLE", "Sprawdzanie paczek z mailami");
    define("B_V_TITLE2", "wysłane listy");
    define("BUTTON_CHECK_STATUS", "Sprawdź status");
    define("BUTTON_DOWN_UP", "Pobierz i aktualizuj");
    define("V_ID", "identyfikator paczki");
    define("V_QTY", "ilość");
    define("V_DATE", "data wysyłki");
    define("V_MESSAGE", "stan paczki");
    define("V_PERC", "% sprawdzone");
    define("V_WORKING", "w toku");
    define("RESPONSE", "odpowiedź");
    define("V_UPDATED_INFO", "Adresy zaktualizowane, sprawdź listę odbiorców");
    define("SETTINGS_API_THECHECKER", "kliknij tutaj, aby uzyskać klucz API emailable.com");
    define("SETTINGS_API_DESCRIPTION", "Zredukuj maksymalnie iloć bounców! <br> Korzystając z poniższego przycisku, otrzymasz <b>30% bonus</b> przy pierwszym i 30% premii przy każdym kolejnym dokonanym przez Ciebie zakupie, na zawsze!");
    define("EC_DATA", "Eksportuj wszystkie dane kampanii");
    define("EC_DATA1", "Eksportuj dane kampanii");
    define("EX_OPENED_BUTTON", "Odbiorcy, którzy otworzyli");
    define("EX_OPENED_DESC", "Eksportuj odbiorców kampanii, którzy otworzyli e-maile z kampanii");
    define("EX_NOT_OPENED_BUTTON", "Odbiorcy, którzy nie otworzyli");
    define("EX_NOT_OPENED_DESC", "Eksportuj odbiorców kampanii, którzy NIE otworzyli e-maila z kampanii");
    define("EX_UNSUBSRIBED_BUTTON", "Odbiorcy, którzy anulowali subskrypcję");
    define("EX_UNSUBSRIBED_DESC", "Eksportuj odbiorców kampanii, którzy anulowali subskrypcję kampanii");
    define("EX_CLICKED_BUTTON", "Odbiorcy, którzy kliknęli");
    define("EX_CLICKED_DESC", "Eksportuj odbiorców kampanii, którzy kliknęli link w e-mailu kampanii");
    define("EX_ALL_BUTTON", "Wszystkie dane odbiorców");
    define("EX_ALL_DESC", "Eksportuj wszystkie dane odbiorców z bieżącej kampanii");
    define("EX_COUNTRY_BUTTON", "Kraje odbiorców");
    define("EX_COUNTRY_DESC", "Eksportuj wszystkie kraje bieżącej kampanii");
    define("EX_CITY_BUTTON", "Miasta odbiorców");
    define("EX_CITY_DESC", "Eksportuj wszystkie miasta bieżącej kampanii");
    define("EX_BROWSER_BUTTON", "Przeglądarki odbiorców");
    define("EX_BROWSER_DESC", "Eksportuj wszystkie dane przeglądarek odbiorców bieżącej kampanii");
    define("SETTINGS_CHARSET", "Ustaw swój zestaw znaków do eksportu danych");
    define("MENU_BULK", "Zbiorcze weryfikacje");
    define("B_CONFIRM", "potwierdź usunięcie całej paczki z emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Aktualizuj odbiorców. Jeżeli w bazie danych jest importowany adres mailowy, zaktualizuj go używając danych w pliku CSV.");
    define("TAGS_MANAGER_TITLE", "Zarządzanie tagami, ilość wybranych adresów: ");
    define("TAGS_SELECT_ACTION", "Wybierz metodę:");
    define("TAGS_MANAGER_ADD", "Dodawanie tagów do wybranych adresów");
    define("TAGS_MANAGER_REMOVE", "Usuwanie tagów z wybranych adresów");
    define("TAGS_SELECT", "Wybierz tagi:");
    define("SAVE_CHANGES", "Zastosuj zmiany");
    define("NOT_SELECTED_TAGS", "Najpierw wybierz adresy email");
    define("TM_BUTTON", "Zarządzaj tagami");
    define("WAITING", "oczekiwanie...");
    define("MULTI_SMTP", "Wiele SMTP");
    define("MULTI_CHECK_DESC", "zaznacz, jeśli chcesz wysłać kampanię, używając wielu serwerów SMTP");
    define("MULTI_CHOOSE", "Wybierz serwery");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Czarna lista");
    define("BL1", "Lista niedozwolonych domen i adresów IP");
    define("BL2", "zablokowane szkodliwe adresy do subskrypcji");
    define("BL3", "Twoja czarna lista");
    define("B_VALUE", "Wartość");
    define("B_TYPE", "Typ");
    define("MENU_ADD_BL", "Dodaj nowy wpis");
    define("B_DOMAIN", "domena");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "Tutaj możesz zaimportować listę szkodliwych adresów do czarnej listy <small>(każdy rekord musi znajdować się w osobnej linii)</small>");
    define("B_DELETE_ALL", "Wyczyść czarną listę");
    define("B_DELETE_QUESTION", "Czy na pewno chcesz usunąć całą czarną listę?");
    define("B_EXPORT", "Eksportuj czarną listę");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM ustawienia");
    define("DKIM_USE", "użyj DKIM");
    define("DKIM_DOMAIN", "Nazwa domeny podpisującej");
    define("DKIM_PRIVATE", "Ścieżka do pliku klucza prywatnego");
    define("DKIM_SELECTOR", "Zwykle konfiguracja klucza selektora w rekordzie TXT DNS");
    define("DKIM_PASS", "Używane, jeśli klucz jest zaszyfrowany");
    define("DKIM_IDENTITY", "Zwykle adres e-mail używany jako nadawca wiadomości e-mail");
    
    define("ERROR", "Błąd:");
    define("WARNING", "UWAGA!");
    define("D_MODE", "Zmiany i niektóre funkcje nie są dostępne w trybie DEMO .");
    define("S_DIS", "Wysyłanie jest wyłączone, dopóki nie wprowadzisz kodu zakupu ");
    define("HERE", "tutaj");
    define("PLIK", "plik");
    define("NOT_WR", "nie jest zapisywalny. Ustawienia nie zostaną zapisane. Zmień uprawnienia do plików przed zapisaniem.");
    define("EPC", "Kod zakupu Envato");
    define("EVALIDEPC", "Wpisz prawidłowy kod zakupu");
    define("NO_ADMIN_MAIL", "Zaktualizuj najpierw adres e-mail administratora w ustawieniach.");
    
    define("SMTP_LABEL", "poziom debugowania");
    define("SMTP_0", "Wyłącz debugowanie");
    define("SMTP_1", "Komunikaty wyjściowe wysyłane przez klienta");
    define("SMTP_2", "jak 1, plus odpowiedzi otrzymane z serwera (to najbardziej przydatne ustawienie)");
    define("SMTP_3", "jak 2, plus więcej informacji o początkowym połączeniu - ten poziom może pomóc zdiagnozować awarie STARTTLS");
    define("SMTP_4", "jak 3, plus jeszcze informacje niższego poziomu, bardzo szczegółowe, nie używaj do debugowania SMTP, tylko problemów niskiego poziomu ");
    
    define("SMTP_SENDER_FORCE", "Zawsze wymuszaj tego nadawcę w kampaniach dla tego serwera");
    define("SMTP_SENDER_MAIL", "Adres e-mail nadawcy");
    define("SMTP_SENDER_DESCRIPTION", "Opis nadawcy");

    
    
