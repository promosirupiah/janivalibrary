<?php
	/*login page*/
	define("LANG","ru");
	define("LOGIN_TITLE","Cистема рассылки");
	define("LOGIN_SIGN_IN","Пожалуйста войдите");
	define("LOGIN","Авторизоваться");
	define("LOGIN_PASS","Пароль");
	define("LOGIN_SIGN_IN_BUTTON","Bойти в систему");
	define("LOGIN_FAILED","Неправильное имя пользователя и / или пароль!");
	define("INSTALLING_SYSTEM","Kонфигурация системы");
	define("INSTALLING_CONNECTED","ПРАВИЛЬНО подключен к базе данных");
	define("INSTALLING_ADD_TABLES","Добавить таблицы");
	define("INSTALLING_ADD_TABLES_DESC","Нажмите здесь, чтобы добавить таблицы и начать работать с системой");
	
	/*left menu*/
	define("WELCOME","Доброе утро,");
	define("WELCOME_ASK","Что мы делаем?");
	define("MAIN_MENU","Главное меню");
	define("START","Начало");
	define("DASHBOARD","Панель приборов");
	define("EMAIL_ADRESSES","Адрес почты");
	define("MENU_RECIPIENT_LIST","Cписок Получатели");
	define("MENU_ADD_RECIPIENT","Добавить получателя");
	define("MENU_CSV_IMPORT","Импорт сообщений электронной почты из файла CSV");
	define("MENU_CSV_EXPORT","Экспорт сообщений электронной почты в CSV-файл");
	define("MENU_TAG_LIST","Cписок Теги");
	define("MENU_ADD_TAGS","Добавить теги");
	define("MENU_SENDERS_LIST","Cписок Отправители");
	define("MENU_ADD_SENDER","Добавить отправителя");
	define("MENU_TEMPLATES","Mакеты почты");
	define("MENU_TEMPLATES_LIST","Cписок шаблонов");
	define("MENU_TEMPLATES_ADD","Добавить новый шаблон");
	define("MENU_TEMPLATES_ATTACHMENTS","Вложения");
    define("MENU_TEMPLATES_THUMBNAILS","Миниатюры");
	define("MENU_CAMPAIGNS","Ваши кампании");
	define("MENU_CAMPAIGNS_ADD","Подготовить новую кампанию");
	define("MENU_CAMPAIGNS_WAITING_LIST","Список ожидания кампании");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Кампании в прогрессе");
	define("MENU_CAMPAIGNS_SENT","Список послал кампании");
	define("MENU_SYSTEM_CONFIGURATION","Конфигурация системы");
	define("MENU_SETTINGS","Настройки");
	define("MENU_LOGIN","Авторизоваться");
	define("MENU_DB","База данных");
	define("MENU_SYSTEM_PARAMS","Параметры системы");
	define("MENU_SPECIALS","Специальные аддоны");
	define("MENU_ADDONS","Полезные дополнения");
	define("MENU_CLEAR_DB","Очистить базу данных");
	define("MENU_IMPORT_TEMPLATES","Шаблоны Импорт образцов");
	define("MENU_IMPORT_DATA","Импорт данных образцов");
	define("MENU_FAQ","Вопросы и ответы");
	define("MENU_ABOUT","Информация о программе");
    define("MENU_SMTP_PARAMS","Kонфигурация SMTP");
    define("MENU_UNSUBSCRIBED","Список уволенных лиц");
    define("MENU_UNSUBSCRIBED_LIST","Cписки получателей");
    define("MENU_DOCS","Документация");
    define("MENU_SUBSCRIBE_WIDGET","Подписка виджет");
    define("MENU_BOUNCED","Проверить отскочил почту");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","База данных по электронной почте");
	define("D_EMAIL_ADD_NEW","Добавить новое сообщение электронной почты");
	define("D_EMAIL_TEMPLATES","Шаблоны писем");
	define("D_EMAIL_TEMPLATES_ADD","Добавить новый шаблон");
	define("D_EMAIL_SENT","Oтправленных писем");
	define("D_EMAIL_EFFICIENCY","Kоэффициент");
	define("D_EMAIL_UNSUBSCIBERS","Отписался");
	define("D_CAMPAIGNS","Кампании");
	define("D_CAMPAIGNS_ADD","Новая кампания");
	define("D_CAMPAIGNS_WAITING","Готов к передаче");
	define("D_CAMPAIGNS_SENT","Завершенный");
	define("D_STATISTICS","Статистика");
	define("D_THIS_YEAR","Ваши рекламные кампании в этом году");
	define("D_CHECK_ALL","Отметить все...");
	define("JAN","янв");
	define("FEB","фев");
	define("MAR","мар");
	define("APR","апр");
	define("MAY","май");
	define("JUN","июн");
	define("JUL","июл");
	define("AUG","авг");
	define("SEP","сен");
	define("OCT","окт");
	define("NOV","ноя");
	define("DEC","дек");
	define("D_PREPARED_OVERALL","Подготовленные кампании");
	define("D_SENT_OVERALL","послал");
	define("D_HOW_TO","Как это работает?");
	define("D_HOW_STEP_1_TITLE","1. База данных по электронной почте");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Добавить теги</a> это поможет вам найти клиентов и поможет вам легко подготовить рекламную кампанию. Cледующий <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>добавить электронную почту</a> к вашей системе базы данных. Вы также можете <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>загрузить файл CSV</a> с электронной почты к базе данных.");
	define("D_HOW_STEP_2_TITLE","2. Отправители");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Добавить отправителя</a> вы можете решить, от которого ваши клиенты будут получать по электронной почте.");
	define("D_HOW_STEP_3_TITLE","3. Шаблоны писем");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Добавить шаблон</a> подготовить неограниченное количество шаблонов, с неограниченным числом вложений.");
	define("D_HOW_STEP_4_TITLE","4. Рекламные кампании");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Добавить новую кампанию</a> подготовить неограниченное количество кампаний. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Отправить кампанию</a> в любое время.");
	define("D_HOW_STEP_5_TITLE","5. Следуйте статистике");
	define("D_HOW_STEP_5_DESC","Здесь вы узнаете, какие кампании являются лучшими, как и когда кампания была подготовлена и сколько отправляется и какова их эффективность (т.е. сколько людей открыли свою электронную почту и сколько людей unsubsrcibed из кампании).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Изменить Войти");
	define("CHANGE_PASS","Изменить пароль");
	define("CLEAR_DATABASE","Очистить базу данных");
	define("LOGOUT","Выйти");
	define("ABOUT","Около");
	
	/*vertical buttons*/
	define("CONFIG","Kонфигурация");
	define("CONFIG_TOOLTIP","Конфигурация системы");
	define("MEDIA_MANAGER","Mенеджер Вложения");
	define("RECIPIENT","Получатели");
	define("RECIPIENT_TOOLTIP","Mенеджер почты");
	define("RECIPIENT_EDIT","Изменить детали");
	define("RECIPIENT_ADD_NEW","Добавить новый");
	define("MENUS","Yправление меню");
	define("MENUS_TOOLTIP","Mеню конфигурации");
	define("TEMPLATES","Макеты");
	define("TEMPLATES_TOOLTIP","Макеты конфигурации");
	define("HELP","Помощь");
	define("HELP_TOOLTIP","Как это работает?");
	
	define("FILE_MANAGEMENT","Вложения");
	define("CSV_IMPORT","CSV импорт файлов электронной почты");
	
	define("PERSON","Человек");
	define("EMAIL","Адрес электронной почты");
	define("TAGS","Теги");
	define("TAGS_LIST","Cписок тегов");
	define("TAGS_ADD","Добавить новые теги");
	define("TAGS_ADD_NEW","Метки добавляющие");
	define("TAGS_ADD_EDIT","Тэг издание");
	define("TAGS_NAME","Название тэга");
	define("TAGS_DESCRIPTION","Описание");
	define("TAGS_NAME_PLACEHOLDER","введите имя тега...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","введите описание тега...");
	define("TAGS_USED","Используемый (раз)");
	define("TAGS_INFO","Метки по электронной почте");
	
	define("RECIPIENT_LIST","Список рассылки");
	define("RECIPIENT_NAME","Имя получателя");
	define("RECIPIENT_NAME_PLACEHOLDER","Введите полное имя");
	define("RECIPIENT_MAIL","Электронная почта");
	define("RECIPIENT_MAIL_PLACEHOLDER","Введите адрес электронной почты");
	define("RECIPIENT_ONLY_TXT","только TXT сообщения электронной почты");
	define("RECIPIENT_DESCRIPTION","Описание");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","Описание...");
	define("RECIPIENT_DB","Ваша база данных электронных писем");
	define("RECIPIENT_DETAILS_EDIT","Изменить данные получателей");
	define("RECIPIENT_DETAILS_ADD","Добавление нового адреса электронной почты");
	define("RECIPIENT_IMPORT_CSV","Импорт электронных писем из CSV-файла");
	define("RECIPIENT_PREPARE_CSV","Приготовьте CSV файл следующие строки");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Для добавления новых записей образуют Excel файл, который вы должны следовать ниже шагов");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","скачать шаблон CSV");

	define("RECIPIENT_UPLOAD_CSV_NAME","Файл CSV Импорт");
	define("RECIPIENT_NOT_CSV","<b>это не файл CSV!!!</b><br/>");
	define("RECIPIENT_ROW","Ряд ");
	define("RECIPIENT_WRONG_EMAIL"," - неверный адрес электронной почты, введен: ");
	define("RECIPIENT_EMAIL_EXIST"," - этот адрес уже в базе данных: ");
	define("RECIPIENT_EMAIL_LACK"," - отсутствие адреса электронной почты");
	define("RECIPIENT_EMAIL_IN_DB"," - Этот адрес электронной почты уже существует в CSV-файле в строке ");
	define("RECIPIENT_TAG_NOT_EXIST"," - нет такой тег: ");
	define("RECIPIENT_CSV_ERRORS","Ошибки в файле ");
	define("RECIPIENT_CSV_ADDED","добавленной ");
	define("RECIPIENT_CSV_ADDED_FROM"," Адреса электронной почты из файла ");
	define("RECIPIENT_CSV_EXPORT","Экспорт адресов электронной почты в файл");
	define("RECIPIENT_CSV_EXPORT_CHK","Выберите поля для экспорта:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Электронная почта получателя");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Имя и фамилия");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Теги - разделенные одним пробелом");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Комментарии");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Получайте только текстовые сообщения электронной почты");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Дата введения");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Дата модификации");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","экспорт");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Игнорировать проверки CSV ошибок (проверьте, если файл содержит более 1000 электронных писем - большие файлы требуют большого объема памяти на сервере)");
	
	define("SAVE","Сохранить");
	define("CANCEL","Отмена");
	define("DELETE","Удалить");
    define("EDIT","Изменить");
	define("CREATED","Дата создания");
	define("MODIFIED","Дата изменения");
	define("SEND","Послать");
	define("SENT","Отправлено");
	define("PROGRESS","Прогресс");
	define("RESUME","Продолжить");
	define("CLOSE","Закрыть");
	define("CHANGES_SAVED","Изменения были сделаны успешно");
	
	define("DELETING","Удаление");
	define("DELETING_CONFIRM_QUESTION","Вы уверены, что хотите удалить?");
	
	define("DATATABLE_LENGTHMENU", "Дисплей _MENU_ записей на странице");
	define("DATATABLE_ZERORECORDS", "Ничего не найдено - извините");
	define("DATATABLE_INFO", "Показаны страницы _PAGE_ из _PAGES_");
	define("DATATABLE_INFOEMPTY", "Нет записей в наличии");
	define("DATATABLE_INFOFILTERED", "(фильтруют _TOTAL_ из _MAX_ Всего записей)");
	define("DATATABLE_SEARCH", "Поиск");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Добавить новый шаблон");
	define("TEMPLATES_LIST", "Cписок шаблонов");
	define("TEMPLATES_TITLE", "Доступные шаблоны");
	define("TEMPLATES_TITLE_ADD", "Добавить новый шаблоны");
	define("TEMPLATES_TITLE_EDIT", "Шаблон для редактирования");
	define("TEMPLATES_NAME", "Имя Шаблона");
	define("TEMPLATES_MAIL_TITLE", "Tитул почты");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Введите имя электронной почты");
	define("TMPLATES_HTML", "HTML версия");
	define("TMPLATES_TXT", "Текстовая версия");
	define("TMPLATES_VARIABLES", "Доступные переменные шаблона (проверка <a href='docs/index.html#variables' target='_blank'>документация</a> для получения дополнительной информации):");
	define("TEMPLATES_THUMB", "Шаблон вид");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Значок редактирования");
	define("THUMBNAIL_MEDIA_LIST", "Cписок доступные миниатюры");
	
	define("MEDIA_FILENAME", "Имя файла");
	define("MEDIA_FILENAME_DESCRIPTION", "Описание файла");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Загрузить время");
	define("MEDIA_TEMPLATES", "Используется в качестве вложения");
	define("MEDIA_LIST", "Доступный список вложений");
	define("MEDIA_ADD_FILES", "Добавить файлы");
	define("MEDIA_BROWSE", "Просматривать");
	define("MEDIA_UPLOAD", "Загрузить");
	
	define("CAMPAIGN_MENU", "Новая кампания");
	define("CAMPAIGN_PREPARE", "Подготовка кампании");
	define("CAMPAIGN_RECIPIENTS", "Выберите получателей");
	define("CAMPAIGN_TEMPLATES", "Выберите шаблон");
	define("CAMPAIGN_SENDERS", "Выберите отправителя");
	define("CAMPAIGN_CONFIRM", "Сохранить кампанию");
	define("CAMPAIGN_SEND", "Отправить кампанию");
	define("CAMPAIGN_NAME", "Название кампании");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Введите название кампании");
	define("CAMPAIGN_RECIPIENT_QTY", "Получатели");
	define("CAMPAIGN_TEMPLATE_NAME", "Шаблон");
	define("CAMPAIGN_SENDER", "Oтправитель");
	define("CAMPAIGN_CREATED_DATE", "Подготовленный");
	define("CAMPAIGN_STEP_1", "1. Выберите получателей (используйте 'поиск' поле над таблицей)");
	define("CAMPAIGN_STEP_2", "2. Сохранить кампанию");
	define("CAMPAIGN_SELECT", "Выберите кампанию для рассылки");
	define("CAMPAIGN_FORM_SELECT", "выбрать...");
	define("CAMPAIGN_CURRENT_STATUS", "Статус текущей кампании");
	define("CAMPAIGN_SENT_NOW", "Отправить сейчас");
	define("CAMPAIGN_SENT_BUTTON", "Нажмите здесь, чтобы начать отправку");
	define("CAMPAIGN_RESUME_BUTTON", "Нажмите здесь, чтобы возобновить передачу");
	define("CAMPAIGN_SERVER_CONNECTING", "подключения к серверу, пожалуйста, подождите...");
	define("CAMPAIGN_SENDING", "отправка");
	define("CAMPAIGN_PLEASE_WAIT", "Пожалуйста, подождите...");
	define("CAMPAIGN_SENT", "<b>ПОСЛАННЫЙ КАМПАНИЯ</b> получатели: ");
	define("CAMPAIGN_IN_PROGRESS", "Кампании в прогрессе...");
	define("CAMPAIGN_COMPLETED", "Переданные кампании");
	define("CAMPAIGN_LEFT", "Слева отправить");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Удалить все уволенных лиц");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "Это действие удалит все unsubscribers из базы данных.");
	define("CAMPAIGN_BG_PROCESS", "Фоновый процесс");
	define("CAMPAIGN_BG_PROCESS_INFO", "Отправить как фоновый процесс (вы можете закрыть браузер)");
	define("CAMPAIGN_WHEN_FINISH", "по электронной почте, когда закончите");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "куда посылать уведомление");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Пожалуйста, подтвердите фон отправка!");
    
    define("HOUR", "час");
    define("OPENS", "Открытие");
    define("BOUNCED", "Возвращенные");
    define("CLICKED", "Нажал");
    define("UNIQUE_CLICKS", "Уникальные клики");
    define("TOTAL_CLICKS", "Всего кликов");
	
	define("SENDER_LIST", "Cписок oтправители");
	define("SENDER_ADD", "Добавить отправителя");
	define("SENDER_NAME", "Имя отправителя");
	define("SENDER_NAME_PLACEHOLDER", "Введите имя отправителя");
	define("SENDER_EMAIL", "Почтa отправителя");
	define("SENDER_EMAIL_PLACEHOLDER", "Введите отправителя электронной почты");
	define("SENDER_TITLE_ADD", "Добавить отправителя");
	define("SENDER_TITLE_EDIT", "Изменить отправителя");
	define("SENDER_EMAIL_TITLE", "Адрес электронной почты отправителя");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Введите адрес электронной почты отправителя");
	
	define("SETTINGS", "Hастройки");
	define("SETTINGS_LOGIN_TITLE", "Введите новые учетные данные");
	define("SETTINGS_LOGIN_LABEL", "Введите новый логин");
	define("SETTINGS_LOGIN_PLACEHOLDER", "введите логин");
	define("SETTINGS_CURR_PASS", "Текущий пароль");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "введите пароль");
	define("SETTINGS_NEW_PASS", "Новый пароль");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "новый пароль");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "подтвердить");
	define("SETTINGS_DB_PARAMS", "Настройка базы данных");
	define("SETTINGS_DB_HOST", "Xост базы данных");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "например: localhost");
	define("SETTINGS_DB_USER", "Пользователь базы данных");
	define("SETTINGS_DB_USER_PLACEHOLDER", "например: root");
	define("SETTINGS_DB_PASSWORD", "Пароль базы данных");
	define("SETTINGS_DB_NAME", "Имя базы данных");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "например: mailing");
	define("SETTINGS_GLOBAL", "Глобальные настройки");
	define("SETTINGS_LANG", "Язык системы");
	define("SETTINGS_LIMIT", "Установка ограничения по электронной почте в час");
	define("SETTINGS_LIMIT_PLACEHOLDER", "по умолчанию: 1000");
	define("SETTINGS_TRACKING", "Включение отслеживания электронной почты");
	define("SENDING_METHOD", "Cпособ отправки");
	define("SETTINGS_UNSUBSCRIBED", "Автоматическое удаление уволенных лиц");
	define("SETTINGS_UNS_INFO", "электронная почта будет автоматически удалена из списка получателей, когда пользователь щелкните ссылку unsubscibe");
	define("SETTINGS_TRACK_INFO", "невидимый IMG тег будет добавлен для отслеживания получателя");
	define("SETTINGS_API_LABEL", "Google карты<br>API key");
	define("SETTINGS_API_PLACEHOLDER", "введите ваш google карты API v.3 key здесь");
	define("SETTINGS_API_LINK_INFO", "нажмите здесь, чтобы получить новый API key");
	define("SETTINGS_ADMIN_MAIL", "Адрес электронной почты администратора");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "администратора электронной почты для системных уведомлений");
    define("SETTINGS_PHP_TIMEOUT", "PHP Тайм-аут (секунд)");
    
	define("SMTP_SERVER_DESCRIPTION", "SMTP сервер, не забудьте добавить некоторые");
    define("SMTP_LIST", "Cписок серверов");
    define("SMTP_ADD", "Добавление нового сервера");
    define("SMTP_EDIT", "Pедактирование сервера");
    define("SMTP_INFO", "Ваши серверы SMTP");
    define("SMTP_ADD_BUTTON", "Нажмите, чтобы добавить новый SMTP сервер");
    define("SMTP_NAME", "Название соединения");
    define("SMTP_NAME_PLACEHOLDER", "например: мое самое лучшее соединение");
    define("SMTP_HOST", "SMTP адрес");
    define("SMTP_HOST_PLACEHOLDER", "Основной и резервный сервер (разделитель ';' для резервного копирования)");
    define("SMTP_PAUTH", "Аутентификация");
    define("SMTP_PAUTH_PLACEHOLDER", "Включение проверки подлинности SMTP");
    define("SMTP_VERIFY_PEER", "Включить SSL/TLS проверки сертификата");
    define("SMTP_FORCE_SMTP", "Использование силы SMTP");
    define("SMTP_USERNAME", "SMTP имя пользователя");
    define("SMTP_USERNAME_PLACEHOLDER", "SMTP имя пользователя");
    define("SMTP_LOGIN", "SMTP Войти");
    define("SMTP_LOGIN_PLACEHOLDER", "Войти сервер SMTP");
    define("SMTP_PASSWORD", "SMTP пароль");
    define("SMTP_PASSWORD_PLACEHOLDER", "SMTP пароль");
    define("SMTP_REPLYTO", "Ответить на почте");
    define("SMTP_REPLYTO_PLACEHOLDER", "Установить альтернативный обратный адрес");
    define("SMTP_REPLYTONAME", "Ответить на имя");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Установить альтернативный для ответа имя");
    define("SMTP_SECURE", "Шифрование");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> как шифрование по умолчанию");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> общепринятый, но не рекомендуется");
    define("SMTP_PORT", "порт");
    define("SMTP_PORT_PLACEHOLDER", "сервер порт");
    define("SMTP_LIMIT", "Лимит в час");
    define("SMTP_LIMIT_PLACEHOLDER", "по умолчанию: 1000");
    define("CAMPAIGN_SMTP", "Выберите SMTP");
    define("SMTP_TESTING", "Тестирование соединения SMTP");
    define("SMTP_TESTING_EMAIL", "Адрес для тестирования сообщения");
    define("SMTP_RUN_TEST", "Проверь это!");
    define("SMTP_TEST_TXT_TITLE", "Tест SMTP от электронной почты.");
    define("SMTP_TEST_TXT_MESSAGE", "Тестовое сообщение от подключения к SMTP.");
    define("SMTP_TEST_OK", "Сообщение было отправлено. Проверьте свой почтовый ящик.");
    define("SMTP_TEST_ERROR", "<b>Мейлер Ошибка: </b>");
    define("SMTP_BEFORE_USE", "<b>Мейлер Ошибка.</b> Вам необходимо включить SMTP-соединение в настройках перед использованием.");
    define("BOUNCED_INFO", "Письма с отступит в этот почтовый ящик");
    define("SMTP_CONFIG", "Настройте SMTP для отправки");
    define("IMAP_CONFIG", "Настройте IMAP / POP3 для отскока");
    define("SMTP_INFO_SETUP", "Hастройки SMTP");
    define("IMAP_INFO_SETUP", "IMAP / POP3 настройки");
    define("PROTOCOL", "Протокол");
    define("FOLDER", "Папка для доступа");
	
	define("STATISTICS", "Статистика");
	define("STATISTICS_ADV", "Дополнительные сведения");
	define("STATISTICS_TAB_MAP", "Получатели на карте (геолокации)");
	define("STATISTICS_TAB_DETAILS", "Детальная статистика");
	define("STATISTICS_TAB_ACTIONS", "Специальные акции");
	define("STATISTICS_BACK", "Обратно к списку");
	define("STATISTICS_BUTTON_OPENERS", "Подготовка к замкам");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Подготовить новую кампанию для всех тех, кто открыл электронную почту");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Подготовка к NOT открывалки");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Подготовить новую кампанию для всех тех, кто не открыл по электронной почте");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Подготовка к отписались");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Подготовить новую кампанию для всех unsubscribers, если опция 'Автоматическое удаление отписались' в системных настройках включена электронная почта будут удалены, и ничего не будет добавлять здесь");
	define("STATISTICS_BUTTON_FILTERS", "Приготовьте с расширенными фильтрами");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Получить список всех получателей из этой кампании с собранными данными и подготовить новую специальную кампанию на основе передовых фильтров");
	define("STATISTICS_TOP_COUNTRIES", "Топ 10 стран");
	define("STATISTICS_TOP_CITIES", "Топ 10 городов");
	define("STATISTICS_TOP_CLICKERS", "Топ 15 кликеры");
	define("STATISTICS_TOP_SOFTWARE", "Топ 15 самых популярных программного обеспечения");
	define("STATISTICS_OTHER_UA", "Все остальные агента пользователя");
	define("STATISTICS_OTHERS", "Другие");
    
	define("SOFTWARE", "Программного обеспечения");
	define("GEODATA", "Локализация");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='подтверждение'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Успешно отписались от подписки на рассылку.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Хорошего дня.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Удаление ненужных данных из базы данных");
	define("ADDONS_IMPORT_TITLE", "Добавление шаблонов образцов рассылки");
	define("ADDONS_FAQ_TITLE", "Прочитайте, прежде чем спросить");
	define("ADDONS_ABOUT_TITLE", "Информация о программе и лицензии");
	define("ADDONS_IMPORT_DATA_TITLE", "Импорт выборки данных в системе");
	define("ADDONS_IMPORT_BUTTON", "Импорт шаблонов электронной почты");
	define("ADDONS_IMPORT_BUTTON_DESC", "Это позволит импортировать образцы шаблонов для рассылки");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Подтверждение добавления примеров шаблонов для рассылки");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Подтверждение добавления примерных данных в систему. Все введенные в настоящее время данные будут удалены!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Почему это лучше иметь собственный выделенный сервер для рассылки?</p>
			<p>Во-первых, никаких ограничений. Для обычного хостинга, вы можете отправить до 1000 писем в час и, вероятно, на ту же сумму в течение одного дня (в зависимости от хостинга ограничений в диапазоне от нескольких сотен до нескольких тысяч писем в день). На сервере, у вас нет таких ограничений, а также имеют возможность отправлять сообщения электронной почты с вашего домена. Вы также можете отправить электронную почту, как если сервер должен был быть под другим доменом (именно в этом случае установить так называемые SPF записи и TXT домен - подробнее спросить своего хостинг-провайдера).</p>
		</li>
		<li>
			<p>Что такое теги?</p>
			<p>Сделать это легко найти почтовые адреса и подготовка рекламной кампании на конкретном получателей.</p>
		</li>
		<li>
			<p>Как добавить имя получателя в шаблон электронной почты?</p>
			<p>Используйте фразы {recipient_name} в шаблоне контента по электронной почте или в названии почтового шаблона. Фраза будет заменен на имя получателя сообщения электронной почты, в случае, когда информация была добавлена на адрес электронной почты получателя.</p>
		</li>
		<li>
			<p>Как добавить новый перевод?</p>
			<p>Скопируйте эталонный english.php файл, дать ему имя, которое описывает ваш язык, например, mylanguage.php и вставить в ту же папку. Исправить все тексты, содержащиеся в новом файле. Не забудьте сохранить файл в кодировке UTF-8 без BOM. Язык файл находится в каталоге 'languages'.</p>
			<p>Чтобы добавить перевод визуального редактора, перейдите https://www.tinymce.com/download/language-packages/ - скачать соответствующий язык файла и сохранить его в /emailer/libs/tinymce/langs/ каталоге.</p>
		</li>
		<li>
			<p>Как добавить теги к электронной почте?</p>
			<p>Во-первых, вам нужно добавить несколько тегов <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>с помощью этой формы</a>. Затем, когда вы добавляете / редактировать каждый адрес электронной почты может быть назначен любой тег. Все теги будут добавлены ниже форму для добавления / редактирования получателей.</p>
		</li>
		<li>
			<p>Как добавить возможность отказаться от подписки от получения сообщений?</p>
			<p>Используйте фразу {} UNSUBSCRIBE в ссылке в содержимом шаблона электронной почты. Фраза будет заменена ссылкой для particullar получателя. Когда он / она будет нажимать его, система будет сохранять в базу данных информацию о выполнении кампании. Адрес электронной почты не будут удалены из базы данных. <br>Применение:<br>&lt;a href='{UNSUBSCRIBE}'&gt;отписаться от рассылки&lt;/a&gt;</p>
		</li>
		<li>
			<p>Как добавить возможность просмотра в браузере?</p>
			<p>Используйте фразу {} BROWSER_VIEW в ссылке в содержимом шаблона электронной почты. Фраза будет заменена ссылкой для particullar получателя. Когда он / она будет нажать ее, система откроет сообщение в окне браузера. <br>Применение:<br>&lt;a href='{BROWSER_VIEW}'&gt;вид браузера&lt;/a&gt;</p>
		</li>
		<li>
			<p>Как добавить предопределенные шаблоны писем?</p>
			<p>30 Образцы шаблонов рассылки, нажмите здесь <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>добавить шаблоны</a></p>
		</li>
		<li>
			<p>Как добавить изображения на электронную почту?</p>
			<p>- В качестве приложения к электронному письму. В этом случае шаблон IMG атрибут тега SCR должен быть установлен в ContentID, означает ИДС, пример:<br>&lt;img src='cid:logo.jpg' &gt;<br>- В качестве абсолютной ссылки на изображения во внешних ресурсов, таких как:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>Как работает отслеживание сообщений электронной почты?</p>
			<p>Для каждого отправленного системы электронной почты можно добавить изображение тега IMG, который атрибут SRC содержит код отслеживания для отображения конкретного сообщения. Отслеживание будет работать только тогда, когда получатель почты соглашается показать изображения полученного сообщения.</p>
		</li>
		<li>
			<p>Как не спамер?</p>
			<p>- Собирают согласие на получение сообщений при создании списка рассылки.</p>
			<p>- Используйте различные виды контента для каждого получателя, используйте напр. {RECIPIENT_NAME} дифференцировать контрольные суммы вашей рассылки.</p>
			<p>- Не используйте ключевые слова, как: секс, виагра, порно.</p>
			<p>- Не используйте ключевые фразы, такие как: адрес из публичной базы данных, это не коммерческая информация в виду, незаинтересованные К сожалению, это не является предложением в смысле, если вы не хотите, нажмите здесь, чтобы отменить подписку, бесплатное, специальное предложение, купить сейчас - если вы должны использовать это такие фразы, вы должны рассмотреть, чтобы поместить их в виде графиков.</p>
			<p>- Не используйте слишком много графики, спам-фильтры проверяют отношение графики к тексту.</p>
			<p>- Почта не должна быть слишком тяжелым.</p>
			<p>- Чем меньше, тем лучше навесное оборудование.</p>
			<p>- Не выдавать себя за другого домена.</p>
			<p>- Не отправлять электронные письма от несуществующего адреса электронной почты.</p>
		</li>
		<li>
			<p>Как увеличить количество кликов и читает кампанию?</p>
			<p>Самое большое влияние на содержание, которое вы посылаете своим клиентам и время и частоту, с которой вы это делаете. В большинстве случаев контакт не должен быть более частым, чем два раза в месяц. Уважайте своих клиентов, и они не будут бросать вас в спам.</p>
		</li>
		<li>
			<p>Как выбрать адреса для рассылки?</p>
			<p>С помощью тегов, введите их разделенных пробелами в поле поиска над таблицей адресов.</p>
		</li>
		<li>
			<p>Каковы ограничения этой системы?</p>
			<p>Там нет никаких ограничений.</p>
		</li>
		<li>
			<p>Ограничить сообщения на сервер хостинг?</p>
			<p>В зависимости от хостинга ограничений в диапазоне от нескольких сотен до нескольких тысяч писем в день, проконсультируйтесь с вашим поставщиком услуг.</p>
		</li>
		<li>
			<p>Прерванное соединение при отправке кампании?</p>
			<p>Вы можете возобновить отправку кампаний, письма будут отправлены другим получателям. Каждое отправленное по электронной почте задает уникальный маркер в базе данных и сама кампания не будет повторно отправлено одному получателю.</p>
		</li>
		<li>
			<p>Требования, предъявляемые к отскочил сообщения электронной почты</p>
			<p>Чтобы включить поддержку письма с вы должны раскомментировать эту строку в файле php.ini.</p>
			<p>;extension=php_imap.dll</p>
			<p>Функции Imap должны использовать соединения POP3 / IMAP.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Будьте внимательно, следующие действия чистых таблиц в базе данных!");
	define("ADDONS_DATA_BE_CAREFULLY", "Предупреждение! Все данные будут удалены и заменены данными выборки");
	define("ADDONS_D_AL", "Удалить все данные");
	define("ADDONS_D_AL_DESC", "Стирает все данные в базе данных");
	define("ADDONS_D_AL_CONF", "Вы уверены, что хотите удалить все данные из базы данных? Будут удалены все адреса электронной почты, шаблоны, вложения и кампании.");
	define("ADDONS_D_RE", "Удалить получателей и их кампании");
	define("ADDONS_D_RE_DESC", "Удаляет все адреса электронной почты в базе данных и истории рекламных кампаний");
	define("ADDONS_D_RE_CONF", "Подтвердите удаление всех получателей");
	define("ADDONS_D_CA", "Удалить только кампании");
	define("ADDONS_D_CA_DESC", "Удаляет все рекламные кампании и их истории");
	define("ADDONS_D_CA_CONF", "Подтвердите удаление всех кампаний и их истории");
	define("ADDONS_D_TE", "Удалить только шаблоны");
	define("ADDONS_D_TE_DESC", "Удаляет все шаблоны писем и их связей с кампаний и вложений");
	define("ADDONS_D_TE_CONF", "Подтвердите удаление всех шаблонов");
	define("ADDONS_D_AT", "Удаление только вложения");
	define("ADDONS_D_AT_DESC", "Удаляет все вложения");
	define("ADDONS_D_AT_CONF", "Подтвердить удаление всех вложений");
	define("ADDONS_D_SE", "Удалить только отправителям");
	define("ADDONS_D_SE_DESC", "Удаляет все введенные электронной почты отправителей, но оставляет их ID для статистических целей");
	define("ADDONS_D_SE_CONF", "Подтвердите удаление всех отправителей");
	define("ADDONS_D_TG", "Удалить только теги");
	define("ADDONS_D_TG_DESC", "Очистить все введенные теги и их отношения с клиентами");
	define("ADDONS_D_TG_CONF", "Подтвердить удалить все теги");
    
	define("WIDGET_PREPARE", "Подготовьте свой виджет подписки");
	define("WIDGET_OPTIONS", "Опции");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Сформировать свой виджет подписки здесь");
	define("WIDGET_COMMENT", "Комментарий о новом получателя");
	define("WIDGET_COMMENT_PLACEHOLDER", "напр .: от domain.ext (будет сохранено в описании получателя)");
	define("WIDGET_NAME", "Имя");
	define("WIDGET_NAME_SHOW", "Показать поля Имя получателя");
	define("WIDGET_AFTER", "После того, как отправить подписки виджет");
	define("WIDGET_AFTER_NOTHING", "ничего не делать");
	define("WIDGET_AFTER_TXT", "показать текстовое сообщение");
	define("WIDGET_AFTER_REDIRECT", "перенаправление на страницу");
	define("WIDGET_TAGS", "Добавить теги");
	define("WIDGET_PURE_CODE_TXT", "Чистый HTML-код. Вы можете изменить его под свои нужды. Добавить классы, теги, описания, что вы хотите. Скопируйте код и вставьте его в свой веб-сайт.");
	define("WIDGET_FULL_CODE_TXT", "Полная версия (все поля в комплекте)");
	define("WIDGET_MIN_CODE_TXT", "Минимизация версия (только по электронной почте в комплекте)");
	define("WIDGET_CODE_DESC_TXT", "Oписание Форма");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> обязательный.</li>
        <li>Адрес электронной почты абонента.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> необязательный.</li>
        <li>Имя абонента.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> необязательный.</li>
        <li>Скрытые поля.</li>
        <li>Они уже должны быть добавлены в базу данных.</li>
        <li>Они должны быть разделены запятой.</li>
        <li>Используя различные теги вы можете сделать различные кампании.</li>
        <li>Вы можете использовать ту же форму на разных сайтах и использовать различные метки на каждом сайте.</li>
        <li>Это означает, что этот компонент может собирать абонентов с разных сайтов и добавить их к вашей системе с различными тегами.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> необязательный.</li>
        <li>Скрытые поля.</li>
        <li>Добавьте ваше описание для получателя.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> необязательный.</li>
        <li>Скрытые поля.</li>
        <li>Включить двойную функцию выбора в.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> необязательный.</li>
        <li>Скрытые поля.</li>
        <li>Где перенаправить после подписки. Если поле пусто или не включены в форму, настроенное действие будет исходить.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Скопируйте код и вставьте его на свой сайт");
	define("WIDGET_DBL_OPT_IN", "Двойной неавтоматического");
	define("WIDGET_DBL_OPT_LABEL", "проверить его использовать двойное подтверждение подписки");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "Сообщение электронной почты (поддержка HTML)");
	define("WIDGET_DBL_OPT_HELP", "Не забудьте добавить <b>{CONFIRM_LINK}</b> в сообщение электронной почты.<br>Вы можете также добавить:<br><b>{SUBSCRIBER_EMAIL}</b> - абонентский адрес электронной почты<br><b>{SUBSCRIBER_NAME}</b> - имя абонента<br><b>{SUBSCRIBER_COMMENT}</b> - bаш комментарий о абонента<br><b>{SUBSCRIBER_TAGS}</b> - используемые теги<br><b>{CURRENT_YEAR}</b> - текущий год<br><b>{CURRENT_MONTH}</b> - текущий месяц<br><b>{CURRENT_DAY}</b> - текущий день");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "Hазвание E-mail");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "введите название подтверждения адреса электронной почты...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "введите подтверждающее сообщение электронной почты...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Перенаправление после подтверждения");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "введите адрес куда перенаправить после подтверждения");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Отправить с адреса");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "введите адрес электронной почты, с которого будет отправить подтверждение");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Oписание отправителя");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "введите описание для отправителя");
	define("WIDGET_ADMIN_NOTIFY", "Уведомить администратора о новых абонентов");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "Проверьте, чтобы отправить уведомление по электронной почте после того, как новая подписка принимается.<br><br><b>ВНИМАНИЕ!</b> Администратор электронной почты должен быть настроен в параметрах системы!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Администратор сообщений (поддержка HTML)");
	define("WIDGET_ADMIN_HELP", "Может использоваться в вашем сообщении:<br><b>{SUBSCRIBER_EMAIL}</b> - абонентский адрес электронной почты<br><b>{SUBSCRIBER_NAME}</b> - имя абонента<br><b>{SUBSCRIBER_COMMENT}</b> - Ваш комментарий о абонента<br><b>{SUBSCRIBER_TAGS}</b> - используемые теги<br><b>{CURRENT_YEAR}</b> - текущий год<br><b>{CURRENT_MONTH}</b> - текущий месяц<br><b>{CURRENT_DAY}</b> - текущий день");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Cообщение об ошибке сервера в случае неправильного адреса электронной почты абонента");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Выберите сервер");
	define("BOUNCED_DEL_EMAILS", "Автоматическое удаление из списка получателей");
	define("BOUNCED_DEL_MESSAGES", "Автоматически удалять все отскочил и проверяются сообщения с сервера");
	define("BOUNCED_MAX", "Максимальный лимит сообщений");
	define("BOUNCED_AT_TIME", "чтобы проверить в одно время");
	define("BOUNCED_START", "Проверьте почтовый ящик для писем отскочил");
	
	define("YES", "Да");
	define("NO", "Нет");
	define("DATA_ERROR", "ОШИБКА: запрошенные данные не существует...<br><br><a href='index.php'>Нажмите сюда, чтобы открыть панель</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "Сервер для отправки почты для подписки виджета");
    define("TESTING_TEMPLATE", "Шаблон Тестирование");
    define("TESTING_TEMPLATE_INFO", "Посылает шаблон введенному электронной почты ниже. Переменные не подставляются.");
    define("TESTING_CHOOSE_SERVER", "Выберите сервер отправки");
    define("ERRORS", "Oшибки");
    define("TEST", "Проверь меня!");
    
    /*v.1.16*/
    define("COPY", "Kопия");
    define("COPYING", "Cправляясь");
    define("CHECK", "Проверить");
    define("DATA_VERIFY", "Проверка целостности данных");
    define("DATA_VERIFY_QUESTION", "Вы действительно хотите проверить целостность данных?");
    define("DATA_VERIFY_DESCRIPTION", "Эта операция может занять несколько минут, это зависит от объема данных в вашей базе данных. Сделайте это, если вы уверены, что кампания завершена и не отображается в этом списке.");
    define("DATA_VERIFY_BUTTON", "Проверка целостности данных");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Фильтровать получателей из выбранных тегов (OR&nbsp;query)");
    define("REC_QUERY_AND", "Фильтровать получателей во ВСЕХ выбранных тегах (AND&nbsp;query)");
    define("REC_RESET", "Сбросить запрос");
    define("REC_BUTTON_DELETE", "Удалить получателей");
    define("CSV_ST_1", "Подготовьте данные по формуле:");
    define("CSV_COL_NO", "число колумны");
    define("CSV_REQ", "обязательный");
    define("CSV_OPT", "необязательный");
    define("CSV_ADDR", "адрес электронной почты");
    define("CSV_NAME", "имя и фамилия");
    define("CSV_TAGS", "теги");
    define("CSV_TAGSDESC", "должны находиться в базе данных, должны быть разделены одним пространством");
    define("CSV_COMMENT", "Комментарии");
    define("CSV_DESC1", "Сохраните таблицу как CSV");
    define("CSV_DESC2", "ограничитель");
    define("CSV_MAXLINE", "максимальная длина линии CSV");
    define("CSV_FORMDESC", "Загрузите подготовленный файл CSV, используя форму ниже");
    define("DISABLE_EDITOR", "Отключить редактор");
    define("ENABLE_EDITOR", "Включить редактор");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "Импорт писем по мосту DB");
    define("TITLE_IMPORT", "Импорт получателей");
    define("SUBTITLE_IMPORT", "Мост базы данных - исходные параметры");
    define("LIST_TITLE_IMPORT", "Импортировать получателей из другой базы данных");
    define("ADD_NEW_BRIDGE", "Добавить новый мост");
    define("IMPORT_RECIPIENTS", "Импорт получателей");
    define("IMPORT_BRIDGE_DESC", "Описание моста импорта");
    define("CONFIRM_BRIDGE_DEL", "Удаление соединения с мостом базы данных");
    define("IMPORTING_BRIDGE_REC", "Импорт получателей");
    define("CHOOSEN_BRIDGE", "Выбранный мост для импорта");
    
    define("FORM_BRIDGE_DESC", "Описание моста импорта");
    define("BRIDGE_TABLE", "Имя исходной таблицы");
    define("BRIDGE_COL_NAME", "Исходный столбец для имени получателя");
    define("BRIDGE_COL_NAME_INFO", "будут импортированы в поле Имя получателя");
    define("BRIDGE_COL_MAIL", "Исходный столбец для адреса электронной почты");
    define("BRIDGE_COL_MAIL_INFO", "будут импортированы в поле «Электронная почта»");
    define("BRIDGE_COL_DESC", "Исходный столбец для описания получателя");
    define("BRIDGE_COL_DESC_INFO", "будут импортированы в поле Описание");
    define("BRIDGE_CHECK_CON", "Проверить подключение к базе данных");
    define("BRIDGE_WAITING", "ожидая испытания...");
    define("BRIDGE_ADD_NAME", "Дополнительное имя получателя");
    define("BRIDGE_ADD_NAME_INFO", "будет добавлен после столбца с именем источника");
    define("BRIDGE_ADD_DESC", "Дополнительное описание получателя");
    define("BRIDGE_ADD_DESC_INFO", "будет добавлен после колонки описания источника");
    define("BRIDGE_OVERRIDE", "Переопределение существующих получателей");
    define("BRIDGE_OVERRIDE_O1", "update - правильный получатель получателя в соответствии с новым источником");
    define("BRIDGE_OVERRIDE_O2", "ignore - ничего не делать, если получатель адресата уже существует");
    define("BRIDGE_TAGS", "Доступные теги");
    define("BRIDGE_FILL_FIELDS", "заполните все обязательные поля перед тестированием...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "импорт в процессе, пожалуйста, подождите...");
    define("BRIDGE_TEST_OK", "Ваш соединительный мост работает правильно");
    define("BRIDGE_IMPORT_OK1", "Импорт завершен. обновленный:");
    define("BRIDGE_IMPORT_OK2", " вставленный:");
    define("TABLE", "Таблица ");
    define("COLUMN", "колонка ");
    define("NOT_IN_DB", " не существует в базе данных ");
    define("NOT_IN_TABLE", " не существует в таблице ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "введите ключ API геолокации здесь");
    define("SETTINGS_API_GEO_LINK_INFO", "нажмите здесь, чтобы получить новый ключ API геолокации");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Использовать https");
    define("HTTPS_USAGE_INFO", "если вы используете https, это приведет к созданию всех ссылок с https");
    define("TEMPLATE_STATISTICS", "Статистика шаблонов: ");
    define("TEMPLATE_CHARS", "символы клавиш: ");
    define("TEMPLATE_USAGE", "используемый: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Форма подписки регистрационный токен ");
    define("WIDGET_EMAIL_TOKEN", "Подписка токена регистрации электронной почты ");
    
    /*v.1.22*/
    define("WEBSITE", "Веб-сайт");
    define("WIDGET_WEBSITE_SHOW", "Показать поле URL получателя");
    define("VERIFIED", "проверенный");
    define("VERIFY", "проверить");
    define("C_PREPARED", "подготовлен и ждет");
    define("C_AJAX_PROGRESS", "Ajax отправка в процессе");
    define("C_FINISHED", "законченный");
    define("C_BG_PROGRESS", "отправка в фоновом режиме");
    define("C_PAUSED", "приостановлена");
    define("C_CRON", "Cron отправка в процессе");
    define("B_VER", "Массовая проверка");
    define("B_RV", "Массовая проверка получателей");
    define("B_SEND1", "Вы уверены, что хотите отправить");
    define("B_SEND2", "получатели для проверки");
    define("B_CHECK_LIST", "проверить списки массовых проверок");
    define("B_VER_INFO", "Ваши массовые чеки будут доступны в вашей учетной записи emailable.com");
    define("B_VER_IN_PROG", "проверка в процессе");
    define("B_VER_SENT", "Получатели отправлены для массовой проверки");
    define("B_V_TITLE", "Массовая проверка по электронной почте");
    define("B_V_TITLE2", "отправленные списки");
    define("BUTTON_CHECK_STATUS", "Проверить состояние");
    define("BUTTON_DOWN_UP", "Скачать и обновить");
    define("V_ID", "подтвердить идентификатор");
    define("V_QTY", "количество, чтобы проверить");
    define("V_DATE", "дата отправки");
    define("V_MESSAGE", "состояние");
    define("V_PERC", "% полный");
    define("V_WORKING", "за работой");
    define("RESPONSE", "ответ");
    define("V_UPDATED_INFO", "Получатели обновлены, проверьте детали");
    define("SETTINGS_API_THECHECKER", "нажмите здесь, чтобы получить ключ API emailable.com");
    define("SETTINGS_API_DESCRIPTION", "Позволяет убить отказов! <br>Используя кнопку ниже, вы получите <b>30% БЕСПЛАТНЫХ ДОПОЛНИТЕЛЬНЫХ ЧЕКОВ</b> при первой покупке и получите 30% бонус (наличными или чеками) за каждую покупку, которую вы совершаете, навсегда!");
    define("EC_DATA", "Экспортировать все данные кампаний");
    define("EC_DATA1", "Экспорт данных кампании");
    define("EX_OPENED_BUTTON", "Получатели, которые открыли");
    define("EX_OPENED_DESC", "Экспорт получателей кампании, открывших электронную почту кампании");
    define("EX_NOT_OPENED_BUTTON", "Получатели, которые не открылись");
    define("EX_NOT_OPENED_DESC", "Экспортируйте получателей кампании, которые НЕ открывали электронную почту кампании");
    define("EX_UNSUBSRIBED_BUTTON", "Получатели, которые отписались");
    define("EX_UNSUBSRIBED_DESC", "Экспорт получателей кампании, которые отписались от кампании");
    define("EX_CLICKED_BUTTON", "Получатели, которые нажали");
    define("EX_CLICKED_DESC", "Экспорт получателей кампании, которые перешли по ссылке в электронном письме кампании");
    define("EX_ALL_BUTTON", "Все данные получателей");
    define("EX_ALL_DESC", "Экспортировать данные всех получателей текущей кампании");
    define("EX_COUNTRY_BUTTON", "Страны-получатели");
    define("EX_COUNTRY_DESC", "Экспорт всех стран текущей кампании");
    define("EX_CITY_BUTTON", "Города-получатели");
    define("EX_CITY_DESC", "Экспортировать все города текущей кампании");
    define("EX_BROWSER_BUTTON", "Браузеры получателей");
    define("EX_BROWSER_DESC", "Экспортировать все браузеры текущей кампании");
    define("SETTINGS_CHARSET", "Установите кодировку для экспорта данных");
    define("MENU_BULK", "Массовые проверки");
    define("B_CONFIRM", "подтвердить массовое удаление из emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Обновление получателей. Если адрес электронной почты импортирован в базу данных, обновите его, используя данные в файле CSV.");
    define("TAGS_MANAGER_TITLE", "Менеджер тегов получателей, выбранные электронные письма: ");
    define("TAGS_SELECT_ACTION", "Выберите свое действие:");
    define("TAGS_MANAGER_ADD", "Добавить теги выбранным получателям");
    define("TAGS_MANAGER_REMOVE", "Удалить теги из выбранных получателей");
    define("TAGS_SELECT", "Выберите ваши теги:");
    define("SAVE_CHANGES", "Сохранить изменения");
    define("NOT_SELECTED_TAGS", "Сначала выберите получателей");
    define("TM_BUTTON", "Диспетчер массовых тегов");
    define("WAITING", "ожидание ...");
    define("MULTI_SMTP", "Мульти SMTP");
    define("MULTI_CHECK_DESC", "проверьте, хотите ли вы использовать мульти SMTP-отправку");
    define("MULTI_CHOOSE", "Выберите SMTP-серверы");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Черный список");
    define("BL1", "Список запрещенных доменов и IP-адресов");
    define("BL2", "заблокированы вредоносные адреса для подписки");
    define("BL3", "Ваш черный список");
    define("B_VALUE", "Значение");
    define("B_TYPE", "Тип");
    define("MENU_ADD_BL", "Добавить новую запись");
    define("B_DOMAIN", "домен");
    define("B_IP", "IP");
    define("B_IMPORT_INFO", "Вы можете импортировать список вредоносных адресов в черный список здесь <small>(каждая запись должна быть в отдельной строке)</small>");
    define("B_DELETE_ALL", "Очистить черный список");
    define("B_DELETE_QUESTION", "Вы уверены, что хотите удалить весь черный список?");
    define("B_EXPORT", "Экспорт черного списка");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM настройки");
    define("DKIM_USE", "использовать DKIM");
    define("DKIM_DOMAIN", "Подписание доменного имени");
    define("DKIM_PRIVATE", "Путь к файлу закрытого ключа");
    define("DKIM_SELECTOR", "Обычно ключ селектора настраивается в вашей записи DNS TXT");
    define("DKIM_PASS", "Используется, если ваш ключ зашифрован");
    define("DKIM_IDENTITY", "Обычно адрес электронной почты, используемый в качестве источника электронного письма");
    
    define("ERROR", "Ошибка:");
    define("WARNING", "ПРЕДУПРЕЖДЕНИЕ!");
    define("D_MODE", "Изменения и некоторые функции недоступны в ДЕМО-режиме.");
    define("S_DIS", "Отправка отключена, пока вы не введете код покупки");
    define("HERE", "здесь");
    define("PLIK", "файл");
    define("NOT_WR", "не доступен для записи. Настройки не сохранятся. Измените права доступа к файлу перед сохранением.");
    define("EPC", "Код покупки Envato");
    define("EVALIDEPC", "Введите действительный код покупки");
    define("NO_ADMIN_MAIL", "Сначала обновите адрес электронной почты администратора в настройках.");
    
    define("SMTP_LABEL", "уровень отладки");
    define("SMTP_0", "Отключить отладку");
    define("SMTP_1", "Выходные сообщения, отправленные клиентом");
    define("SMTP_2", "как 1 плюс ответы, полученные от сервера (это наиболее полезный параметр)");
    define("SMTP_3", "как 2, плюс дополнительная информация о начальном подключении - этот уровень может помочь диагностировать сбои STARTTLS");
    define("SMTP_4", "как 3, плюс даже низкоуровневая информация, очень подробная, не используется для отладки SMTP, только низкоуровневые проблемы ");
    
    define("SMTP_SENDER_FORCE", "Всегда использовать этого отправителя в кампаниях для этого сервера");
    define("SMTP_SENDER_MAIL", "Адрес электронной почты отправителя");
    define("SMTP_SENDER_DESCRIPTION", "Описание отправителя");

    
    
