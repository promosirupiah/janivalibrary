<?php
	/*login page*/
	define("LANG","ar");
	define("LOGIN_TITLE","نظام البريدية");
	define("LOGIN_SIGN_IN","الرجاء تسجيل الدخول");
	define("LOGIN","تسجيل الدخول");
	define("LOGIN_PASS","كلمه السر");
	define("LOGIN_SIGN_IN_BUTTON","تسجيل الدخول");
	define("LOGIN_FAILED","تسجيل الدخول الخاطئ و / أو كلمة المرور!");
	define("INSTALLING_SYSTEM","أعدادات النظام");
	define("INSTALLING_CONNECTED","متصل بشكل صحيح إلى قاعدة البيانات");
	define("INSTALLING_ADD_TABLES","إضافة الجداول");
	define("INSTALLING_ADD_TABLES_DESC","انقر هنا لإضافة الجداول وبدء العمل مع النظام");
	
	/*left menu*/
	define("WELCOME","أهلا بك");
	define("WELCOME_ASK","ماذا نفعل؟");
	define("MAIN_MENU","القائمة الرئيسية");
	define("START","بداية");
	define("DASHBOARD","لوحة القيادة");
	define("EMAIL_ADRESSES","عناوين البريد الإلكتروني");
	define("MENU_RECIPIENT_LIST","قائمة المستفيدين");
	define("MENU_ADD_RECIPIENT","أضافة متلقي");
	define("MENU_CSV_IMPORT","رسائل البريد الإلكتروني استيراد من ملف CSV");
	define("MENU_CSV_EXPORT","رسائل البريد الإلكتروني التصدير إلى ملف CSV");
	define("MENU_TAG_LIST","قائمة الكلمات");
	define("MENU_ADD_TAGS","اضف اشارة");
	define("MENU_SENDERS_LIST","قائمة المرسلين");
	define("MENU_ADD_SENDER","إضافة مرسل");
	define("MENU_TEMPLATES","تخطيطات البريد الإلكتروني");
	define("MENU_TEMPLATES_LIST","قائمة قوالب");
	define("MENU_TEMPLATES_ADD","إضافة قالب جديد");
	define("MENU_TEMPLATES_ATTACHMENTS","مرفقات");
    define("MENU_TEMPLATES_THUMBNAILS","الصور المصغرة");
	define("MENU_CAMPAIGNS","حملاتك");
	define("MENU_CAMPAIGNS_ADD","إعداد حملة جديدة");
	define("MENU_CAMPAIGNS_WAITING_LIST","في انتظار حملة قائمة");
	define("MENU_CAMPAIGNS_IN_PROGRESS","حملات في التقدم");
	define("MENU_CAMPAIGNS_SENT","حملات قائمة أرسلت");
	define("MENU_SYSTEM_CONFIGURATION","أعدادات النظام");
	define("MENU_SETTINGS","إعدادات");
	define("MENU_LOGIN","تسجيل الدخول");
	define("MENU_DB","قاعدة البيانات");
	define("MENU_SYSTEM_PARAMS","بارامس النظام");
	define("MENU_SPECIALS","أدونس الخاصة");
	define("MENU_ADDONS","إضافات مفيدة");
	define("MENU_CLEAR_DB","قاعدة بيانات واضحة");
	define("MENU_IMPORT_TEMPLATES","قوالب استيراد عينة");
	define("MENU_IMPORT_DATA","استيراد بيانات عينة");
	define("MENU_FAQ","سؤال وجواب");
	define("MENU_ABOUT","حول");
    define("MENU_SMTP_PARAMS","التكوين SMTP");
    define("MENU_UNSUBSCRIBED","حذف من قائمة الاشتراك");
    define("MENU_UNSUBSCRIBED_LIST","قائمة المستفيدين");
    define("MENU_DOCS","توثيق");
    define("MENU_SUBSCRIBE_WIDGET","الاشتراك القطعة");
    define("MENU_BOUNCED","الاختيار ارتد رسائل");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","قاعدة بيانات البريد الإلكتروني");
	define("D_EMAIL_ADD_NEW","إضافة بريد إلكتروني جديد");
	define("D_EMAIL_TEMPLATES","قوالب البريد الإلكتروني");
	define("D_EMAIL_TEMPLATES_ADD","إضافة قالب جديد");
	define("D_EMAIL_SENT","رسائل البريد الإلكتروني المرسلة");
	define("D_EMAIL_EFFICIENCY","كفاءة");
	define("D_EMAIL_UNSUBSCIBERS","غير المكتتب به");
	define("D_CAMPAIGNS","حملات");
	define("D_CAMPAIGNS_ADD","حملة جديدة");
	define("D_CAMPAIGNS_WAITING","على استعداد لإرسال");
	define("D_CAMPAIGNS_SENT","منجز");
	define("D_STATISTICS","إحصائيات");
	define("D_THIS_YEAR","حملات الإعلانية هذا العام");
	define("D_CHECK_ALL","تحقق من الكل");
	define("JAN","يناير");
	define("FEB","فبراير");
	define("MAR","مارس");
	define("APR","أبريل");
	define("MAY","قد");
	define("JUN","يونيو");
	define("JUL","يوليو");
	define("AUG","أغسطس");
	define("SEP","سبتمبر");
	define("OCT","أكتوبر");
	define("NOV","تشرين الثاني");
	define("DEC","ديسمبر");
	define("D_PREPARED_OVERALL","حملات مستعدة");
	define("D_SENT_OVERALL","أرسلت");
	define("D_HOW_TO","كيف يعمل؟");
	define("D_HOW_STEP_1_TITLE","1. قاعدة 1. بيانات البريد الإلكتروني");
	define("D_HOW_STEP_1_DESC","إضافة علامات - وهذا سوف تساعدك على العثور على العملاء، وسوف تساعدك بسهولة إعداد حملة إعلانية. التالي إضافة رسائل البريد الإلكتروني لنظام قاعدة البيانات الخاصة بك. يمكنك أيضا تحميل ملف CSV مع رسائل البريد الإلكتروني لقاعدة البيانات الخاصة بك.");
	define("D_HOW_STEP_2_TITLE","2. المرسلين");
	define("D_HOW_STEP_2_DESC","إضافة مرسل - يمكنك أن تقرر من الذي عملائك سوف تتلقى رسالة بريد إلكتروني.");
	define("D_HOW_STEP_3_TITLE","3. قوالب البريد الإلكتروني");
	define("D_HOW_STEP_3_DESC","إضافة قالب - إعداد عدد غير محدود من القوالب، مع عدد غير محدود من المرفقات.");
	define("D_HOW_STEP_4_TITLE","4. الحملات الإعلانية");
	define("D_HOW_STEP_4_DESC","إضافة حملة جديدة - إعداد حملات غير محدودة وإرسالها في أي وقت.");
	define("D_HOW_STEP_5_TITLE","5. اتبع احصائيات");
	define("D_HOW_STEP_5_DESC","هنا سوف تتعلم التي الحملات هي الأفضل، كيف ومتى تم إعداد حملة وكم يتم إرسالها وما هي فعاليتها (أي كيف فتحت كثير من الناس البريد الإلكتروني الخاص بك وكيفية حذف كثير من الناس أنفسهم من الحملة).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","تغيير تسجيل الدخول");
	define("CHANGE_PASS","تغيير كلمة السر");
	define("CLEAR_DATABASE","قاعدة بيانات واضحة");
	define("LOGOUT","اغلق");
	define("ABOUT","حول");
	
	/*vertical buttons*/
	define("CONFIG","ترتيب");
	define("CONFIG_TOOLTIP","أعدادات النظام");
	define("MEDIA_MANAGER","مدير إرفاق ملفات");
	define("RECIPIENT","متلقي");
	define("RECIPIENT_TOOLTIP","إدارة رسائل البريد الإلكتروني");
	define("RECIPIENT_EDIT","تعديل التفاصيل");
	define("RECIPIENT_ADD_NEW","اضف جديد");
	define("MENUS","إدارة القائمة");
	define("MENUS_TOOLTIP","تكوين القائمة");
	define("TEMPLATES","تخطيطات");
	define("TEMPLATES_TOOLTIP","التكوين تخطيط");
	define("HELP","مساعدة");
	define("HELP_TOOLTIP","كيف يعمل");
	
	define("FILE_MANAGEMENT","مرفق ل");
	define("CSV_IMPORT","CSV رسائل البريد الإلكتروني ملف الاستيراد");
	
	define("PERSON","شخص");
	define("EMAIL","عنوان مزود البريد الإلكتروني");
	define("TAGS","الكلمات");
	define("TAGS_LIST","قائمة البطاقات");
	define("TAGS_ADD","إضافة العلامات الجديدة");
	define("TAGS_ADD_NEW","إضافة علامات");
	define("TAGS_ADD_EDIT","العلامة طبعة");
	define("TAGS_NAME","اشر على اسم");
	define("TAGS_DESCRIPTION","وصف");
	define("TAGS_NAME_PLACEHOLDER","إدخال اسم العلامة");
	define("TAGS_DESCRIPTION_PLACEHOLDER","إدخال وصف العلامة");
	define("TAGS_USED","تستخدم (مرات)");
	define("TAGS_INFO","الكلمات الدلالية لرسالة بريد إلكتروني");
	
	define("RECIPIENT_LIST","القائمة البريدية");
	define("RECIPIENT_NAME","اسم المستلم");
	define("RECIPIENT_NAME_PLACEHOLDER","أدخل الاسم الكامل");
	define("RECIPIENT_MAIL","البريد الإلكتروني");
	define("RECIPIENT_MAIL_PLACEHOLDER","أدخل البريد الإلكتروني");
	define("RECIPIENT_ONLY_TXT","فقط رسائل البريد الإلكتروني TXT");
	define("RECIPIENT_DESCRIPTION","وصف");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","وصف");
	define("RECIPIENT_DB","لديك قاعدة بيانات البريد الإلكتروني");
	define("RECIPIENT_DETAILS_EDIT","تفاصيل تحرير المتلقي");
	define("RECIPIENT_DETAILS_ADD","إضافة عنوان بريد إلكتروني جديد");
	define("RECIPIENT_IMPORT_CSV","رسائل البريد الإلكتروني الاستيراد من ملف CSV");
	define("RECIPIENT_PREPARE_CSV","استعد ملف CSV الأسطر التالية");
	define("RECIPIENT_UPLOAD_CSV_TITLE","تشكل إضافة سجلات جديدة ملف Excel يجب عليك اتباع الخطوات التالية");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","تحميل قالب CSV");

	define("RECIPIENT_UPLOAD_CSV_NAME","ملف CSV استيراد");
	define("RECIPIENT_NOT_CSV","<b>هذا ليس ملف CSV !!!</b><br/>");
	define("RECIPIENT_ROW","صف ");
	define("RECIPIENT_WRONG_EMAIL"," - عنوان البريد الإلكتروني غير صحيح، دخل: ");
	define("RECIPIENT_EMAIL_EXIST"," - هذا العنوان هو بالفعل في قاعدة البيانات: ");
	define("RECIPIENT_EMAIL_LACK"," - عدم وجود عنوان البريد الإلكتروني");
	define("RECIPIENT_EMAIL_IN_DB"," - عنوان البريد الإلكتروني هذا موجود بالفعل في ملف CSV في الصف ");
	define("RECIPIENT_TAG_NOT_EXIST"," - لا يوجد مثل هذه العلامة: ");
	define("RECIPIENT_CSV_ERRORS","أخطاء في ملف ");
	define("RECIPIENT_CSV_ADDED","وأضاف ");
	define("RECIPIENT_CSV_ADDED_FROM"," عناوين البريد الإلكتروني من ملف ");
	define("RECIPIENT_CSV_EXPORT","عناوين البريد الإلكتروني تصدير إلى ملف");
	define("RECIPIENT_CSV_EXPORT_CHK","تحديد الحقول لتصدير:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","عنوان البريد الإلكتروني المستلم");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","اسمك واسم عائلتك");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","الكلمات - مفصولة بمسافة واحدة");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","تعليقات");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","استقبال رسائل البريد الإلكتروني النص فقط");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","تاريخ التقديم");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","تاريخ التعديل");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","تصدير");
	define("RECIPIENT_CSV_IGNORE_ERRORS","تجاهل أخطاء CSV فحص (التحقق من ذلك إذا كان الملف يحتوي على أكثر من 1000 رسائل البريد الإلكتروني - تتطلب ملفات أكبر كمية كبيرة من الذاكرة على الملقم)");
	
	define("SAVE","حفظ");
	define("CANCEL","إلغاء");
	define("DELETE","حذف");
    define("EDIT","تحرير");
	define("CREATED","مكون");
	define("MODIFIED","تم التعديل");
	define("SEND","إرسال");
	define("SENT","أرسلت");
	define("PROGRESS","تقدم");
	define("RESUME","استئنف");
	define("CLOSE","قريب");
	define("CHANGES_SAVED","تم إجراء تغييرات بنجاح");
	
	define("DELETING","حذف");
	define("DELETING_CONFIRM_QUESTION","هل أنت متأكد من أنك تريد إزالة؟");
	
	define("DATATABLE_LENGTHMENU", "عرض السجلات _MENU_ في كل صفحة");
	define("DATATABLE_ZERORECORDS", "وجدت شيئا - آسف");
	define("DATATABLE_INFO", "عرض _PAGE_ صفحة من _PAGES_");
	define("DATATABLE_INFOEMPTY", "لا السجلات المتاحة");
	define("DATATABLE_INFOFILTERED", "(_TOTAL_ تصفيتها من _MAX_ إجمالي السجلات)");
	define("DATATABLE_SEARCH", "بحث");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "إضافة قالب جديد");
	define("TEMPLATES_LIST", "قائمة قوالب");
	define("TEMPLATES_TITLE", "القوالب المتوفرة");
	define("TEMPLATES_TITLE_ADD", "إضافة تصميم جديد");
	define("TEMPLATES_TITLE_EDIT", "تعديل نسق");
	define("TEMPLATES_NAME", "اسم تخطيط");
	define("TEMPLATES_MAIL_TITLE", "عنوان البريد الإلكتروني");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "أدخل عنوان البريد الإلكتروني");
	define("TMPLATES_HTML", "إصدار HTML");
	define("TMPLATES_TXT", "نسخة TXT");
	define("TMPLATES_VARIABLES", "متغيرات قالب المتاحة (راجع <a href='docs/index.html#variables' target='_blank'> مستندات </a> للحصول على مزيد من التفاصيل):");
	define("TEMPLATES_THUMB", "صورة مصغرة");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "تحرير الصور المصغرة");
	define("THUMBNAIL_MEDIA_LIST", "قائمة الصور المصغرة المتاحة");
	
	define("MEDIA_FILENAME", "اسم الملف");
	define("MEDIA_FILENAME_DESCRIPTION", "وصف الملف");
	define("MEDIA_FILENAME_UPLOAD_TIME", "تحميل الوقت");
	define("MEDIA_TEMPLATES", "يستخدم كملحق");
	define("MEDIA_LIST", "تتوفر قائمة المرفقات");
	define("MEDIA_ADD_FILES", "إضافة ملفات");
	define("MEDIA_BROWSE", "تصفح");
	define("MEDIA_UPLOAD", "تحميل");
	
	define("CAMPAIGN_MENU", "حملة جديدة");
	define("CAMPAIGN_PREPARE", "إعداد حملة");
	define("CAMPAIGN_RECIPIENTS", "اختيار المستفيدين");
	define("CAMPAIGN_TEMPLATES", "اختيار تخطيط");
	define("CAMPAIGN_SENDERS", "اختيار المرسل");
	define("CAMPAIGN_CONFIRM", "حفظ الحملة");
	define("CAMPAIGN_SEND", "إرسال حملة");
	define("CAMPAIGN_NAME", "اسم الحملة");
	define("CAMPAIGN_NAME_PLACEHOLDER", "أدخل اسم الحملة");
	define("CAMPAIGN_RECIPIENT_QTY", "متلقي");
	define("CAMPAIGN_TEMPLATE_NAME", "نسق");
	define("CAMPAIGN_SENDER", "مرسل");
	define("CAMPAIGN_CREATED_DATE", "أعدت");
	define("CAMPAIGN_STEP_1", "1. حدد المستلمين (استخدام الحقل 'البحث' على الطاولة)");
	define("CAMPAIGN_STEP_2", "2. احفظ حملتك");
	define("CAMPAIGN_SELECT", "اختر حملة بريدية");
	define("CAMPAIGN_FORM_SELECT", "اختار...");
	define("CAMPAIGN_CURRENT_STATUS", "وضع الحملة الحالية");
	define("CAMPAIGN_SENT_NOW", "أرسلها الآن");
	define("CAMPAIGN_SENT_BUTTON", "انقر هنا لبدء إرسال");
	define("CAMPAIGN_RESUME_BUTTON", "انقر هنا لاستئناف إرسال");
	define("CAMPAIGN_SERVER_CONNECTING", "لربط الخادم، يرجى الانتظار");
	define("CAMPAIGN_SENDING", "إرسال");
	define("CAMPAIGN_PLEASE_WAIT", "أرجو الإنتظار...");
	define("CAMPAIGN_SENT", "<b>حملة أرسلها</b> متلقي: ");
	define("CAMPAIGN_IN_PROGRESS", "حملات في التقدم");
	define("CAMPAIGN_COMPLETED", "حملات أرسلت");
	define("CAMPAIGN_LEFT", "غادر لإرسال");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "حذف جميع المحذوفة من حملة");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "وهذا الإجراء إلى حذف جميع المستفيدين إزالتها من قاعدة البيانات الخاصة بك.");
	define("CAMPAIGN_BG_PROCESS", "عملية خلفية");
	define("CAMPAIGN_BG_PROCESS_INFO", "إرسال كعملية خلفية (يمكنك إغلاق المتصفح)");
	define("CAMPAIGN_WHEN_FINISH", "البريد الإلكتروني عند الانتهاء");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "حيث لإرسال إشعار");
	define("CAMPAIGN_BG_CONFIRM_TXT", "الرجاء التأكد من خلفية الإرسال!");
    
    define("HOUR", "ساعة");
    define("OPENS", "يفتح");
    define("BOUNCED", "وثب");
    define("CLICKED", "النقر");
    define("UNIQUE_CLICKS", "نقرات فريدة من نوعها");
    define("TOTAL_CLICKS", "مجموع النقرات");
	
	define("SENDER_LIST", "قائمة المرسلين");
	define("SENDER_ADD", "إضافة مرسل");
	define("SENDER_NAME", "اسم المرسل");
	define("SENDER_NAME_PLACEHOLDER", "أدخل اسم المرسل");
	define("SENDER_EMAIL", "البريد الإلكتروني المرسل");
	define("SENDER_EMAIL_PLACEHOLDER", "أدخل البريد الإلكتروني المرسل");
	define("SENDER_TITLE_ADD", "إضافة مرسل");
	define("SENDER_TITLE_EDIT", "تحرير مرسل");
	define("SENDER_EMAIL_TITLE", "عنوان البريد الإلكتروني المرسل");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "أدخل عنوان البريد الإلكتروني المرسل");
	
	define("SETTINGS", "إعدادات");
	define("SETTINGS_LOGIN_TITLE", "إدخال بيانات جديدة");
	define("SETTINGS_LOGIN_LABEL", "أدخل تسجيل الدخول الجديد");
	define("SETTINGS_LOGIN_PLACEHOLDER", "دخول تسجيل الدخول");
	define("SETTINGS_CURR_PASS", "كلمة السر الحالية");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "أدخل كلمة المرور");
	define("SETTINGS_NEW_PASS", "كلمة السر الجديدة");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "كلمة السر الجديدة");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "أكد");
	define("SETTINGS_DB_PARAMS", "إعداد قاعدة البيانات");
	define("SETTINGS_DB_HOST", "المضيف قاعدة بيانات");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "مثال localhost");
	define("SETTINGS_DB_USER", "مستخدم قاعدة البيانات");
	define("SETTINGS_DB_USER_PLACEHOLDER", "مثال root");
	define("SETTINGS_DB_PASSWORD", "كلمة مرور قاعدة البيانات");
	define("SETTINGS_DB_NAME", "اسم قاعدة البيانات");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "مثال mailing");
	define("SETTINGS_GLOBAL", "الاعدادات العامة");
	define("SETTINGS_LANG", "لغة النظام");
	define("SETTINGS_LIMIT", "الحد إعداد البريد الإلكتروني في ساعة");
	define("SETTINGS_LIMIT_PLACEHOLDER", "الافتراضي: 1000");
	define("SETTINGS_TRACKING", "تمكين تتبع البريد الإلكتروني");
	define("SENDING_METHOD", "طريقة الإرسال");
	define("SETTINGS_UNSUBSCRIBED", "وحذف تلقائي المتلقين إزالتها");
	define("SETTINGS_UNS_INFO", "سيتم حذف البريد الإلكتروني تلقائيا من قائمة المستلمين عند المستخدم النقر بك إزالة لي صلة");
	define("SETTINGS_TRACK_INFO", "وستضاف غير مرئية IMG علامة لتتبع المتلقي");
	define("SETTINGS_API_LABEL", "خرائط جوجل<br>مفتاح API");
	define("SETTINGS_API_PLACEHOLDER", "أدخل خرائط جوجل API مفتاح V.3 هنا");
	define("SETTINGS_API_LINK_INFO", "انقر هنا للحصول على مفتاح API جديد");
	define("SETTINGS_ADMIN_MAIL", "البريد الإلكتروني مشرف");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "البريد الإلكتروني مشرف للالإخطارات النظام");
    define("SETTINGS_PHP_TIMEOUT", "PHP المهلة (ثانية)");
    
	define("SMTP_SERVER_DESCRIPTION", "خادم SMTP، ومن المؤكد أن إضافة بعض");
    define("SMTP_LIST", "قائمة الخادم");
    define("SMTP_ADD", "واضاف الخادم الجديد");
    define("SMTP_EDIT", "الخادم التحرير");
    define("SMTP_INFO", "خوادم SMTP الخاص بك");
    define("SMTP_ADD_BUTTON", "انقر لإضافة خادم SMTP جديد");
    define("SMTP_NAME", "اسم الاتصال");
    define("SMTP_NAME_PLACEHOLDER", "مثال أفضل ارتباطي");
    define("SMTP_HOST", "عنوان SMTP");
    define("SMTP_HOST_PLACEHOLDER", "الخادم الرئيسي والنسخ الاحتياطي (فاصل '؛' للنسخ الاحتياطي)");
    define("SMTP_PAUTH", "المصادقة");
    define("SMTP_PAUTH_PLACEHOLDER", "تمكين مصادقة SMTP");
    define("SMTP_VERIFY_PEER", "تمكين SSL / TLS التحقق من الشهادة");
    define("SMTP_FORCE_SMTP", "استخدام القوة SMTP");
    define("SMTP_USERNAME", "اسم المستخدم SMTP");
    define("SMTP_USERNAME_PLACEHOLDER", "اسم المستخدم SMTP");
    define("SMTP_LOGIN", "تسجيل الدخول SMTP");
    define("SMTP_LOGIN_PLACEHOLDER", "تسجيل الدخول خادم SMTP");
    define("SMTP_PASSWORD", "كلمة المرور SMTP");
    define("SMTP_PASSWORD_PLACEHOLDER", "كلمة المرور SMTP");
    define("SMTP_REPLYTO", "الرد على البريد");
    define("SMTP_REPLYTO_PLACEHOLDER", "تعيين بديل الرد لمعالجة");
    define("SMTP_REPLYTONAME", "رد على اسم");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "تعيين بديل الرد إلى اسم");
    define("SMTP_SECURE", "التشفير");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> كما التشفير الافتراضي");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> قبلت ولكن ليس من المستحسن");
    define("SMTP_PORT", "ميناء");
    define("SMTP_PORT_PLACEHOLDER", "منفذ الخادم");
    define("SMTP_LIMIT", "حد لكل ساعة");
    define("SMTP_LIMIT_PLACEHOLDER", "الافتراضي: 1000");
    define("CAMPAIGN_SMTP", "حدد SMTP");
    define("SMTP_TESTING", "اتصال اختبار SMTP");
    define("SMTP_TESTING_EMAIL", "عنوان رسالة اختبار");
    define("SMTP_RUN_TEST", "افحصها!");
    define("SMTP_TEST_TXT_TITLE", "اختبار SMTP من البريد الإلكتروني.");
    define("SMTP_TEST_TXT_MESSAGE", "رسالة اختبار من اتصال SMTP الخاص بك.");
    define("SMTP_TEST_OK", "تم ارسال الرسالة. تفقد بريدك الالكتروني.");
    define("SMTP_TEST_ERROR", "<b>الارسال خطأ: </b>");
    define("SMTP_BEFORE_USE", "<b>خطأ الإرسال.</b> تحتاج إلى تمكين اتصال SMTP في إعدادات قبل الاستخدام.");
    define("BOUNCED_INFO", "ارتدت رسائل البريد الإلكتروني ستساند إلى علب");
    define("SMTP_CONFIG", "إعداد SMTP الخاص بك لإرسال");
    define("IMAP_CONFIG", "الإعداد IMAP / POP3 عن مستبعد");
    define("SMTP_INFO_SETUP", "إعدادات SMTP");
    define("IMAP_INFO_SETUP", "إعدادات IMAP / POP3");
    define("PROTOCOL", "بروتوكول");
    define("FOLDER", "مجلد الوصول");
	
	define("STATISTICS", "إحصائيات");
	define("STATISTICS_ADV", "تفاصيل متقدمة");
	define("STATISTICS_TAB_MAP", "المستلمين على الخريطة (الموقع الجغرافي)");
	define("STATISTICS_TAB_DETAILS", "إحصاءات مفصلة");
	define("STATISTICS_TAB_ACTIONS", "إجراءات خاصة");
	define("STATISTICS_BACK", "الرجوع للقائمة");
	define("STATISTICS_BUTTON_OPENERS", "الاستعداد لالفتاحات");
	define("STATISTICS_BUTTON_OPENERS_INFO", "إعداد حملة جديدة لجميع أولئك الذين فتحت البريد الإلكتروني");
	define("STATISTICS_BUTTON_NOT_OPENERS", "الاستعداد للا الفتاحات");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "إعداد حملة جديدة لجميع أولئك الذين ليس افتتح بريد إلكتروني");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "الاستعداد لإلغاء اشتراكك");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "إعداد حملة جديدة لجميع رسائل البريد الإلكتروني التي تمت إزالتها، إذا كان الخيار 'تلقائي حذف رسائل البريد الإلكتروني التي تمت إزالتها' في إعدادات النظام تمكين يتم حذف رسائل البريد الإلكتروني وشيء سيتم إضافة هنا");
	define("STATISTICS_BUTTON_FILTERS", "إعداد مع مرشحات المتقدمة");
	define("STATISTICS_BUTTON_FILTERS_INFO", "الحصول على قائمة من جميع المستفيدين من هذه الحملة مع البيانات التي تم جمعها وإعداد حملة خاصة جديدة تقوم على مرشحات المتقدمة");
	define("STATISTICS_TOP_COUNTRIES", "أفضل 10 دول");
	define("STATISTICS_TOP_CITIES", "أفضل 10 مدن");
	define("STATISTICS_TOP_CLICKERS", "أفضل 15 الأفراس");
	define("STATISTICS_TOP_SOFTWARE", "أفضل 15 البرامج الأكثر شعبية");
	define("STATISTICS_OTHER_UA", "جميع وكلاء المستخدم الآخرين");
	define("STATISTICS_OTHERS", "آخرون");
    
	define("SOFTWARE", "البرمجيات");
	define("GEODATA", "التعريب");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='تأكيد'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>إلغاء الاشتراك بنجاح من النشرة الإخبارية.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>أتمنى لك نهارا سعيد.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "إزالة البيانات غير الضرورية من قاعدة البيانات");
	define("ADDONS_IMPORT_TITLE", "مضيفا القوالب عينة البريدية");
	define("ADDONS_FAQ_TITLE", "اقرأ قبل أن تسأل");
	define("ADDONS_ABOUT_TITLE", "معلومات عن البرنامج والترخيص");
	define("ADDONS_IMPORT_DATA_TITLE", "استيراد بيانات العينة إلى نظام");
	define("ADDONS_IMPORT_BUTTON", "قوالب استيراد البريد الإلكتروني");
	define("ADDONS_IMPORT_BUTTON_DESC", "هذا وسوف استيراد القوالب عينة للالبريدية");
	define("ADDONS_IMPORT_CONFIRM_TXT", "تأكيد مضيفا سبيل المثال نماذج لالبريدية");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "تأكيد إضافة بيانات العينة إلى النظام. سوف يتم مسح جميع البيانات المدخلة حاليا!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>السبب في أنه من الأفضل أن يكون خادم مخصص الخاصة للالبريدية؟</p>
			<p>أولا وقبل كل شيء، لا حدود لها. لاستضافة عادية، يمكنك إرسال ما يصل إلى 1000 رسائل البريد الإلكتروني للساعة الواحدة، وربما نفس المبلغ في غضون يوم واحد (اعتمادا على حدود استضافة تتراوح من بضع مئات إلى بضعة آلاف من رسائل البريد الإلكتروني يوميا). على الخادم الخاص بك، فإنك لا تملك مثل هذه القيود وأيضا لديها القدرة على إرسال رسائل البريد الإلكتروني من المجال الخاص بك. يمكنك أيضا إرسال رسائل البريد الإلكتروني كما لو كان الخادم ليكون ضمن نطاق مختلف (وهو في هذه الحالة تعيين ما يسمى سجلات SPF ونطاق TXT - للحصول على التفاصيل نسأل مزود الاستضافة).</p>
		</li>
		<li>
			<p>ما هي العلامات؟</p>
			<p>تجعل من السهل العثور على عناوين بريدية وإعداد حملة إعلانية في أشخاص بعينهم.</p>
		</li>
		<li>
			<p>كيفية إضافة اسم المستلم إلى قالب البريد الإلكتروني؟</p>
			<p>استخدام عبارة {RECIPIENT_NAME} في البريد الإلكتروني قالب المحتوى أو في عنوان البريد القالب. سيتم استبدال العبارة التي كتبها اسم البريد الإلكتروني المتلقي، في حالة أن تم إضافة المعلومات إلى عنوان البريد الإلكتروني المستلم.</p>
		</li>
		<li>
			<p>كيفية إضافة ترجمة جديدة؟</p>
			<p>نسخ english.php مرجع ملف، وإعطائها اسم يصف لغتك على سبيل المثال mylanguage.php ولصق لنفس المجلد. تصحيح جميع النصوص الواردة في الملف الجديد. تأكد من حفظ الملف في UTF-8 ث / س BOM. ملف اللغة في الدليل 'languages'.</p>
			<p>لإضافة ترجمة محرر، انتقل إلى https://www.tinymce.com/download/language-packages/ - تحميل اللغة لغة الملف وحفظه في مجلد /emailer/libs/tinymce/langs/.</p>
		</li>
		<li>
			<p>كيف يمكنني إضافة علامات إلى رسالة بالبريد الإلكتروني؟</p>
			<p>أولا، تحتاج إلى إضافة بعض العلامات. ثم عند إضافة / تحرير كل عنوان البريد الإلكتروني يمكن أن تسند إلى أي علامة.</p>
		</li>
		<li>
			<p>كيفية إضافة القدرة على إلغاء الاشتراك من تلقي الرسائل؟</p>
			<p>استخدام عبارة {UNSUBSCRIBE} في الارتباط في محتوى القالب البريد الإلكتروني. سيتم استبدال العبارة مع وصلة للمتلقي. عندما قال انه / انها سوف فوقه، ونظام حفظ في قاعدة البيانات معلومات عن أداء الحملة. لن يتم إزالة عنوان البريد الإلكتروني من قاعدة البيانات. <br>استعمال:<br>&lt;a href='{UNSUBSCRIBE}'&gt;إلغاء الاشتراك من النشرة الإخبارية&lt;/a&gt;</p>
		</li>
		<li>
			<p>كيفية إضافة القدرة على عرض المتصفح؟</p>
			<p>استخدام عبارة {BROWSER_VIEW} في الارتباط في محتوى القالب البريد الإلكتروني. سيتم استبدال العبارة مع وصلة للمتلقي. عندما قال انه / انها سوف فوقه، ونظام فتح الرسالة في نافذة المتصفح. <br>استعمال:<br>&lt;a href='{BROWSER_VIEW}'&gt;عرض المستعرض&lt;/a&gt;</p>
		</li>
		<li>
			<p>كيفية إضافة قوالب البريد الإلكتروني مسبقا؟</p>
			<p>30 القوالب عينة البريدية، انقر هنا <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>لإضافة قوالب</a></p>
		</li>
		<li>
			<p>كيف يمكنني إضافة الصور إلى رسائل البريد الإلكتروني؟</p>
			<p>- باعتبارها ارتباط مطلق إلى صورة في الموارد الخارجية، مثل:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>كيف تتبع رسائل البريد الإلكتروني؟</p>
			<p>لكل نظام البريد الإلكتروني المرسل يمكن أن تضيف علامة صورة IMG، التي تنسب SRC يحتوي على شفرة تتبع لعرض رسالة معينة. سوف تتبع تعمل فقط عند موافقة المتلقي الإلكتروني لإظهار صور من الرسالة التي وردت.</p>
		</li>
		<li>
			<p>كيف لا يكون مرسلي البريد المزعج؟</p>
			<p>- اجمع الموافقة على استقبال الرسائل عند إنشاء قائمة بريدية.</p>
			<p>- استخدام مجموعة متنوعة من المحتوى لكل مستلم، استخدم مثال. {RECIPIENT_NAME} في التفريق اختبارية من البريد الخاص بك.</p>
			<p>- لا تستخدم كلمات مثل: الجنس، الفياجرا، الاباحية.</p>
			<p>- لا تستخدم العبارات الرئيسية مثل: عنوان من قاعدة بيانات عامة، فإنه ليس المعلومات التجارية في الاعتبار، غير مهتم عذرا، لا يشكل عرضا بالمعنى المقصود إذا كنت لا تريد، انقر هنا لإلغاء الاشتراك، مجانا، عرض خاص، شرائه الآن - إذا كان لديك لاستخدام هذه هذه العبارات يجب عليك أن تنظر لوضعها في شكل رسومات.</p>
			<p>- لا تستخدم الكثير من الرسومات، مرشحات البريد المزعج بفحص نسبة من الرسومات إلى نص.</p>
			<p>- لا ينبغي أن يكون البريد ثقيلة جدا.</p>
			<p>- وكلما قل عدد المرفقات أفضل.</p>
			<p>- لا انتحال مجال آخر.</p>
			<p>- لا ترسل رسائل البريد الإلكتروني من عنوان البريد الإلكتروني غير موجود.</p>
		</li>
		<li>
			<p>كيفية زيادة النقرات ويقرأ الحملة؟</p>
			<p>أكبر تأثير على المحتوى الذي تقوم بإرسالها إلى الزبائن والوقت والتردد الذي كنت تفعل ذلك. في معظم الحالات، لا ينبغي أن يكون الاتصال أكثر تواترا من مرتين في الشهر. احترام الزبائن وأنها لن يرميك إلى البريد المزعج.</p>
		</li>
		<li>
			<p>كيفية اختيار عناوين البريدية؟</p>
			<p>إن استخدام بصمات، اكتب لهم مفصولة بمسافات في حقل البحث أعلى جدول عناوين.</p>
		</li>
		<li>
			<p>ما هي حدود هذا النظام؟</p>
			<p>لا يوجد أي قيود.</p>
		</li>
		<li>
			<p>الحد من الرسائل على استضافة الخادم؟</p>
			<p>اعتمادا على حدود استضافة تتراوح من بضع مئات إلى بضعة آلاف من رسائل البريد الإلكتروني يوميا، تحقق مع مزود الخدمة الخاص بك.</p>
		</li>
		<li>
			<p>كسر اتصال عند إرسال الحملة؟</p>
			<p>يمكنك استئناف ارسال حملات، سيتم إرسال رسائل البريد الإلكتروني إلى جهات أخرى. كل رسائل البريد الإلكتروني المرسلة يضع علامة فريدة من نوعها في قاعدة البيانات والحملة نفسها لن يعاد إرسالها إلى نفس المتلقي.</p>
		</li>
		<li>
			<p>متطلبات لرسائل البريد الإلكتروني المرتجعة</p>
			<p>لتمكين دعم لرسائل البريد الإلكتروني المرتجعة لديك لغير تعليق هذا الخط في ملف php.ini.</p>
			<p>;extension=php_imap.dll</p>
			<p>مطلوبة وظائف IMAP استخدام الاتصالات POP3 / IMAP.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "كن بعناية، الإجراءات التالية تنظيف الجداول في قاعدة البيانات!");
	define("ADDONS_DATA_BE_CAREFULLY", "تحذير! سيتم حذف جميع البيانات واستبدالها بيانات عينة");
	define("ADDONS_D_AL", "حذف جميع البيانات");
	define("ADDONS_D_AL_DESC", "يمحو كافة البيانات في قاعدة البيانات");
	define("ADDONS_D_AL_CONF", "هل أنت متأكد أنك تريد إزالة كافة البيانات من قاعدة البيانات؟ سيتم حذف جميع عناوين البريد الإلكتروني والقوالب والمرفقات والحملات.");
	define("ADDONS_D_RE", "إزالة المتلقين وحملاتهم");
	define("ADDONS_D_RE_DESC", "حذف كافة عناوين البريد الإلكتروني في قاعدة بيانات وتاريخ الحملات الإعلانية");
	define("ADDONS_D_RE_CONF", "تأكيد إزالة جميع المستفيدين");
	define("ADDONS_D_CA", "حذف الحملات الوحيدة");
	define("ADDONS_D_CA_DESC", "حذف جميع الحملات الإعلانية وتاريخهم");
	define("ADDONS_D_CA_CONF", "تأكيد إزالة جميع الحملات وتاريخهم");
	define("ADDONS_D_TE", "إزالة القوالب فقط");
	define("ADDONS_D_TE_DESC", "حذف جميع قوالب البريد الإلكتروني وصلاتها مع حملات والمرفقات");
	define("ADDONS_D_TE_CONF", "تأكيد حذف جميع القوالب");
	define("ADDONS_D_AT", "حذف المرفقات فقط");
	define("ADDONS_D_AT_DESC", "حذف كافة المرفقات");
	define("ADDONS_D_AT_CONF", "تؤكد حذف كافة المرفقات");
	define("ADDONS_D_SE", "حذف المرسلين الوحيد");
	define("ADDONS_D_SE_DESC", "حذف كافة دخل المرسلين البريد الإلكتروني لكنه يترك هوياتهم لأغراض إحصائية");
	define("ADDONS_D_SE_CONF", "تأكيد إزالة جميع المرسلين");
	define("ADDONS_D_TG", "حذف العلامات فقط");
	define("ADDONS_D_TG_DESC", "مسح كافة العلامات دخلت وعلاقاتهم مع العملاء");
	define("ADDONS_D_TG_CONF", "تؤكد إزالة كافة العلامات");
    
	define("WIDGET_PREPARE", "إعداد القطعة اشتراكك");
	define("WIDGET_OPTIONS", "خيارات");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "توليد القطعة اشتراكك هنا");
	define("WIDGET_COMMENT", "التعليق على مستلم جديد");
	define("WIDGET_COMMENT_PLACEHOLDER", "مثال: من عند domain.ext (سيتم حفظها في وصف المتلقي)");
	define("WIDGET_NAME", "اسم");
	define("WIDGET_NAME_SHOW", "مشاهدة الحقل اسم المستلم");
	define("WIDGET_AFTER", "بعد تقديم القطعة الاشتراك");
	define("WIDGET_AFTER_NOTHING", "لا تفعل شيئا");
	define("WIDGET_AFTER_TXT", "تظهر رسالة نصية");
	define("WIDGET_AFTER_REDIRECT", "إعادة توجيه إلى صفحة");
	define("WIDGET_TAGS", "اضف اشارة");
	define("WIDGET_PURE_CODE_TXT", "النقي كود HTML. يمكنك تعديله لاحتياجاتك. إضافة فئات، والعلامات، والأوصاف، كل ما تريد. نسخ الشفرة ادناه ولصقه في موقع الويب الخاص بك.");
	define("WIDGET_FULL_CODE_TXT", "النسخة الكاملة (شملت جميع المجالات)");
	define("WIDGET_MIN_CODE_TXT", "نسخة الحد الأدنى (البريد الإلكتروني فقط وشملت)");
	define("WIDGET_CODE_DESC_TXT", "وصف شكل");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> مطلوب.</li>
        <li>عنوان البريد الإلكتروني للمشترك.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> اختياري.</li>
        <li>اسم المشترك.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> اختياري.</li>
        <li>حقل مخفي.</li>
        <li>ويجب بالفعل أن تضاف إلى قاعدة البيانات.</li>
        <li>ويجب أن تكون مفصولة بفواصل.</li>
        <li>استخدام العلامات المختلفة التي يمكن أن تجعل حملات مختلفة.</li>
        <li>يمكنك استخدام نفس النموذج على مواقع مختلفة، واستخدام علامات مختلفة على كل موقع.</li>
        <li>وهو ما يعني هذا العنصر يمكن أن تجمع المشتركين من مواقع مختلفة، وإضافتها إلى النظام الخاص بك مع علامات مختلفة.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> اختياري.</li>
        <li>حقل مخفي.</li>
        <li>إضافة صفك للمتلقي.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> اختياري.</li>
        <li>حقل مخفي.</li>
        <li>تمكين مزدوجة ميزة التقيد في.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> اختياري.</li>
        <li>حقل مخفي.</li>
        <li>حيث لإعادة توجيه بعد الاشتراك. إذا كان حقل فارغ أو غير المدرجة في النموذج، عمل تكوين سيتم المضي قدما.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "نسخ الشفرة ادناه ولصقه على موقع الويب الخاص بك");
	define("WIDGET_DBL_OPT_IN", "ضعف التقيد في");
	define("WIDGET_DBL_OPT_LABEL", "التحقق من ذلك من استخدام تأكيد الاشتراك مزدوج");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "رسالة البريد الإلكتروني (دعم HTML)");
	define("WIDGET_DBL_OPT_HELP", "لا تنس أن تضيف <b>{CONFIRM_LINK}</b> في رسالتك.<br>يمكنك أيضا إضافة:<br><b>{SUBSCRIBER_EMAIL}</b> - عنوان البريد الإلكتروني المشترك<br><b>{SUBSCRIBER_NAME}</b> - اسم المشترك<br><b>{SUBSCRIBER_COMMENT}</b> - تعليقك عن المشترك<br><b>{SUBSCRIBER_TAGS}</b> - العلامات المستخدمة<br><b>{CURRENT_YEAR}</b> - السنة الحالية<br><b>{CURRENT_MONTH}</b> - الشهر الحالي<br><b>{CURRENT_DAY}</b> - اليوم الحالي");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "عنوان البريد الإلكتروني");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "أدخل عنوان تأكيد البريد الإلكتروني...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "كتابة رسالة تأكيد عبر البريد الإلكتروني...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "إعادة توجيه إلى بعد تأكيد");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "ادخل عنوان حيث لإعادة توجيه بعد تأكيد");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "إرسال من عنوان");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "ادخل عنوان البريد الإلكتروني الذي سيتم إرسال تأكيد");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "وصف مرسل");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "أدخل وصف للمرسل");
	define("WIDGET_ADMIN_NOTIFY", "إبلاغ المشرف عن مشترك جديد");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "تحقق لإرسال إشعار البريد الإلكتروني بعد استلام اشتراك جديد.<br><br><b>تحذير!</b> البريد الإلكتروني المشرف أن تقام في بارامس النظام!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "رسالة المشرف (دعم HTML)");
	define("WIDGET_ADMIN_HELP", "يمكن استخدامها في رسالتك:<br><b>{SUBSCRIBER_EMAIL}</b> - عنوان البريد الإلكتروني المشترك<br><b>{SUBSCRIBER_NAME}</b> - اسم المشترك<br><b>{SUBSCRIBER_COMMENT}</b> - تعليقك عن المشترك<br><b>{SUBSCRIBER_TAGS}</b> - العلامات المستخدمة<br><b>{CURRENT_YEAR}</b> - السنة الحالية<br><b>{CURRENT_MONTH}</b> - الشهر الحالي<br><b>{CURRENT_DAY}</b> - اليوم الحالي");
    define("WIDGET_ERROR_MESSAGE_LABEL", "رسالة خطأ الخادم في حالة عنوان البريد الإلكتروني المشترك خطأ");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "اختر الخادم الخاص بك");
	define("BOUNCED_DEL_EMAILS", "حذف تلقائيا من قائمة المستلمين");
	define("BOUNCED_DEL_MESSAGES", "حذف الرسائل كل ارتدت والتحقق من الملقم تلقائيا");
	define("BOUNCED_MAX", "ماكس الحد الرسائل");
	define("BOUNCED_AT_TIME", "للتحقق في وقت واحد");
	define("BOUNCED_START", "التحقق من صندوق البريد لرسائل البريد الإلكتروني المرتجعة");
	
	define("YES", "نعم فعلا");
	define("NO", "لا");
	define("DATA_ERROR", "خطأ: المطلوب البيانات غير موجود...<br><br><a href='index.php'>انقر هنا لفتح لوحة القيادة</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "خادم لإرسال البريد للحصول على القطعة الاشتراك");
    define("TESTING_TEMPLATE", "قالب الاختبار");
    define("TESTING_TEMPLATE_INFO", "يرسل القالب إلى البريد الإلكتروني دخلت أدناه. لن تكون بديلا المتغيرات");
    define("TESTING_CHOOSE_SERVER", "اختر إرسال الخادم");
    define("ERRORS", "أخطاء");
    define("TEST", "اختبار لي!");
    
    /*v.1.16*/
    define("COPY", "نسخ");
    define("COPYING", "التعامل");
    define("CHECK", "التحقق من");
    define("DATA_VERIFY", "سلامة البيانات والتحقق");
    define("DATA_VERIFY_QUESTION", "هل أنت متأكد أنك تريد التحقق من سلامة البيانات؟");
    define("DATA_VERIFY_DESCRIPTION", "قد تستغرق هذه العملية عدة دقائق، وذلك يعتمد على كمية البيانات في قاعدة البيانات الخاصة بك. <BR> تفعل ذلك إذا كنت متأكدا من ان تلك الحملة المصنعة وغير مرئية على هذه القائمة.");
    define("DATA_VERIFY_BUTTON", "تحقق من سلامة البيانات");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "تصفية المستلمين من العلامات المحددة (OR&nbsp;query)");
    define("REC_QUERY_AND", "يتم تعيين مستلمي الفلتر في جميع العلامات المحددة (AND&nbsp;query)");
    define("REC_RESET", "إعادة تعيين طلب البحث");
    define("REC_BUTTON_DELETE", "حذف المستلمين");
    define("CSV_ST_1", "إعداد البيانات وفقا للصيغة:");
    define("CSV_COL_NO", "رقم العمود");
    define("CSV_REQ", "مطلوب");
    define("CSV_OPT", "اختياري");
    define("CSV_ADDR", "عنوان البريد الإلكتروني");
    define("CSV_NAME", "الاسم الأول واسم العائلة");
    define("CSV_TAGS", "علامات");
    define("CSV_TAGSDESC", "يجب أن تكون في قاعدة البيانات يجب أن يتم فصلها من قبل مساحة واحدة");
    define("CSV_COMMENT", "تعليقات");
    define("CSV_DESC1", "حفظ جدول البيانات كملف كسف");
    define("CSV_DESC2", "محدد");
    define("CSV_MAXLINE", "ماكس كسف طول الخط");
    define("CSV_FORMDESC", "حمل ملف كسف تم إعداده باستخدام النموذج أدناه");
    define("DISABLE_EDITOR", "تعطيل المحرر");
    define("ENABLE_EDITOR", "تمكين المحرر");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "استيراد رسائل البريد الإلكتروني باستخدام الجسر");
    define("TITLE_IMPORT", "المستلمون الاستيراد");
    define("SUBTITLE_IMPORT", "جسر قاعدة البيانات - المعلمات المصدر");
    define("LIST_TITLE_IMPORT", "استيراد المستلمين من قاعدة البيانات الأخرى");
    define("ADD_NEW_BRIDGE", "إضافة اتصال جديد");
    define("IMPORT_RECIPIENTS", "استيراد المستلمين");
    define("IMPORT_BRIDGE_DESC", "وصف جسر الاستيراد");
    define("CONFIRM_BRIDGE_DEL", "حذف اتصال جسر قاعدة البيانات");
    define("IMPORTING_BRIDGE_REC", "استيراد المستلمين");
    define("CHOOSEN_BRIDGE", "جسر المختار للاستيراد");
    
    define("FORM_BRIDGE_DESC", "وصف جسر الاستيراد");
    define("BRIDGE_TABLE", "اسم الجدول المصدر");
    define("BRIDGE_COL_NAME", "العمود المصدر لاسم المستلم");
    define("BRIDGE_COL_NAME_INFO", "سيتم استيرادها إلى حقل اسم المستلم");
    define("BRIDGE_COL_MAIL", "عمود المصدر لعنوان البريد الإلكتروني");
    define("BRIDGE_COL_MAIL_INFO", "سيتم استيرادها إلى حقل البريد الإلكتروني");
    define("BRIDGE_COL_DESC", "عمود المصدر لوصف المستلم");
    define("BRIDGE_COL_DESC_INFO", "سيتم استيرادها إلى حقل الوصف");
    define("BRIDGE_CHECK_CON", "تحقق من اتصال قاعدة البيانات");
    define("BRIDGE_WAITING", "في انتظار الاختبار ...");
    define("BRIDGE_ADD_NAME", "اسم مستلم إضافي");
    define("BRIDGE_ADD_NAME_INFO", "ستضاف بعد عمود اسم المصدر");
    define("BRIDGE_ADD_DESC", "وصف المستلم إضافي");
    define("BRIDGE_ADD_DESC_INFO", "ستتم إضافتها بعد عمود وصف المصدر");
    define("BRIDGE_OVERRIDE", "تجاوز المستلمين الحاليين");
    define("BRIDGE_OVERRIDE_O1", "تحديث - مستلم الوجهة الصحيح وفقًا للمصدر الجديد");
    define("BRIDGE_OVERRIDE_O2", "تجاهل - لا تفعل شيئًا إذا كان مستلم الوجهة موجودًا بالفعل");
    define("BRIDGE_TAGS", "العلامات المتاحة");
    define("BRIDGE_FILL_FIELDS", "ملء جميع الحقول المطلوبة قبل الاختبار ...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "الاستيراد قيد التقدم ، يرجى الانتظار ...");
    define("BRIDGE_TEST_OK", "جسر الاتصال الخاص بك يعمل بشكل صحيح");
    define("BRIDGE_IMPORT_OK1", "اكتمل الاستيراد. محدث:");
    define("BRIDGE_IMPORT_OK2", " إدراج:");
    define("TABLE", "الطاولة ");
    define("COLUMN", "عمود ");
    define("NOT_IN_DB", " غير موجود في قاعدة البيانات ");
    define("NOT_IN_TABLE", " غير موجود في الجدول ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "أدخل مفتاح واجهة برمجة التطبيقات للموقع الجغرافي هنا");
    define("SETTINGS_API_GEO_LINK_INFO", "انقر هنا للحصول على مفتاح واجهة برمجة تطبيقات الموقع الجغرافي الجديد");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "استخدم https");
    define("HTTPS_USAGE_INFO", "تحقق مما إذا كنت تستخدم https، فسيؤدي ذلك إلى إنشاء جميع الروابط باستخدام https");
    define("TEMPLATE_STATISTICS", "إحصائيات القالب: ");
    define("TEMPLATE_CHARS", "الشخصيات: ");
    define("TEMPLATE_USAGE", "مستخدم: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "رمز تسجيل نموذج الاشتراك ");
    define("WIDGET_EMAIL_TOKEN", "رمز تسجيل البريد الإلكتروني للاشتراك ");
    
    /*v.1.22*/
    define("WEBSITE", "موقع الكتروني");
    define("WIDGET_WEBSITE_SHOW", "إظهار حقل عنوان url الخاص بالمستلم");
    define("VERIFIED", "التحقق");
    define("VERIFY", "التحقق");
    define("C_PREPARED", "أعدت والانتظار");
    define("C_AJAX_PROGRESS", "اياكس إرسال في التقدم");
    define("C_FINISHED", "تم الانتهاء من");
    define("C_BG_PROGRESS", "إرسال الخلفية في التقدم");
    define("C_PAUSED", "توقف");
    define("C_CRON", "إرسال كرون في التقدم");
    define("B_VER", "التحقق بالجملة");
    define("B_RV", "التحقق من المستلمين بالجملة");
    define("B_SEND1", "هل أنت متأكد أنك تريد الإرسال؟");
    define("B_SEND2", "المستلمين للتحقق");
    define("B_CHECK_LIST", "التحقق من قوائم التحقق بالجملة");
    define("B_VER_INFO", "ستكون الشيكات المجمعة متاحة على حساب emailable.com");
    define("B_VER_IN_PROG", "التحقق في التقدم");
    define("B_VER_SENT", "إرسال المستلمين للتحقق بالجملة");
    define("B_V_TITLE", "التحقق من البريد الإلكتروني بالجملة");
    define("B_V_TITLE2", "أرسلت القوائم");
    define("BUTTON_CHECK_STATUS", "تحقق من حالة");
    define("BUTTON_DOWN_UP", "حمل التحديث");
    define("V_ID", "التحقق من الهوية");
    define("V_QTY", "كمية للتحقق");
    define("V_DATE", "تاريخ الإرسال");
    define("V_MESSAGE", "حالة");
    define("V_PERC", "% اكتمال");
    define("V_WORKING", "عامل");
    define("RESPONSE", "استجابة");
    define("V_UPDATED_INFO", "تحديث المستلمين ، والتحقق من التفاصيل");
    define("SETTINGS_API_THECHECKER", "انقر هنا للحصول على مفتاح ");
    define("SETTINGS_API_DESCRIPTION", "هيا نقتل المرتدون! <br> باستخدام الزر أدناه ، ستمنحك <b> 30٪ شيكات مجانية إضافية </b> في أول عملية شراء لك ومنحك مكافأة 30٪ (نقدًا أو بشيكات) عند كل عملية شراء تقوم بها ، إلى الأبد!");
    define("EC_DATA", "تصدير جميع بيانات الحملات");
    define("EC_DATA1", "تصدير بيانات الحملة");
    define("EX_OPENED_BUTTON", "المستلمون الذين فتحوا");
    define("EX_OPENED_DESC", "تصدير مستلمي الحملة الذين فتحوا بريد الحملة الإلكتروني");
    define("EX_NOT_OPENED_BUTTON", "المستلمون الذين لم يفتحوا");
    define("EX_NOT_OPENED_DESC", "تصدير مستلمي الحملة الذين لم يفتحوا البريد الإلكتروني للحملة");
    define("EX_UNSUBSRIBED_BUTTON", "المستلمون الذين ألغيت اشتراكهم");
    define("EX_UNSUBSRIBED_DESC", "تصدير مستلمي الحملة الذين ألغيت اشتراكهم في الحملة");
    define("EX_CLICKED_BUTTON", "المستلمون الذين نقروا");
    define("EX_CLICKED_DESC", "تصدير مستلمي الحملة الذين نقروا على الرابط في البريد الإلكتروني للحملة");
    define("EX_ALL_BUTTON", "جميع المستلمين البيانات");
    define("EX_ALL_DESC", "تصدير جميع بيانات المستلمين للحملة الحالية");
    define("EX_COUNTRY_BUTTON", "البلدان المستفيدة");
    define("EX_COUNTRY_DESC", "تصدير جميع بلدان الحملة الحالية");
    define("EX_CITY_BUTTON", "مدن المستفيدين");
    define("EX_CITY_DESC", "تصدير جميع مدن الحملة الحالية");
    define("EX_BROWSER_BUTTON", "المستلمين المتصفحات");
    define("EX_BROWSER_DESC", "تصدير جميع متصفحات الحملة الحالية");
    define("SETTINGS_CHARSET", "تعيين charset الخاص بك لتصدير البيانات");
    define("MENU_BULK", "التحقق بالجملة");
    define("B_CONFIRM", "تأكيد الحذف الكامل من emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "تحديث المستلمين. إذا تم استيراد عنوان بريد إلكتروني في قاعدة البيانات ، فقم بتحديثه باستخدام البيانات الموجودة في ملف CSV.");
    define("TAGS_MANAGER_TITLE", "المستلمون مدير العلامات ، رسائل البريد الإلكتروني المحددة: ");
    define("TAGS_SELECT_ACTION", "اختر عملك:");
    define("TAGS_MANAGER_ADD", "إضافة علامات إلى المستلمين المحددين");
    define("TAGS_MANAGER_REMOVE", "إزالة العلامات من المستلمين المحددين");
    define("TAGS_SELECT", "حدد العلامات الخاصة بك:");
    define("SAVE_CHANGES", "حفظ التغييرات");
    define("NOT_SELECTED_TAGS", "حدد المستلمين أولاً");
    define("TM_BUTTON", "مدير العلامات بالجملة");
    define("WAITING", "انتظار...");
    define("MULTI_SMTP", "SMTP متعددة");
    define("MULTI_CHECK_DESC", "تحقق ، إذا كنت تريد استخدام ميزة إرسال متعددة smtp");
    define("MULTI_CHOOSE", "اختيار خوادم بروتوكول نقل البريد الإلكتروني");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "القائمة السوداء");
    define("BL1", "قائمة المجالات غير المسموح بها و IP");
    define("BL2", "حظر العناوين الخبيثة للاشتراك");
    define("BL3", "القائمة السوداء الخاصة بك");
    define("B_VALUE", "القيمة");
    define("B_TYPE", "اكتب");
    define("MENU_ADD_BL", "أضف مدخل جديد");
    define("B_DOMAIN", "نطاق");
    define("B_IP", "الملكية الفكرية");
    define("B_IMPORT_INFO", "يمكنك استيراد قائمة من العناوين الضارة إلى قائمتك السوداء هنا <small>(يجب أن يكون كل سجل في سطر منفصل)</small>");
    define("B_DELETE_ALL", "القائمة السوداء واضحة");
    define("B_DELETE_QUESTION", "هل أنت متأكد من أنك تريد حذف القائمة السوداء بأكملها?");
    define("B_EXPORT", "تصدير القائمة السوداء");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM إعدادات");
    define("DKIM_USE", "استعمال DKIM");
    define("DKIM_DOMAIN", "توقيع اسم المجال");
    define("DKIM_PRIVATE", "مسار ملف المفتاح الخاص");
    define("DKIM_SELECTOR", "عادةً ما يكون إعداد مفتاح المحدد في سجل TXT لنظام أسماء النطاقات");
    define("DKIM_PASS", "تستخدم إذا كان مفتاحك مشفرًا");
    define("DKIM_IDENTITY", "عادة عنوان البريد الإلكتروني المستخدم كمصدر للبريد الإلكتروني");
    
    define("ERROR", "خطأ:");
    define("WARNING", "تحذير!");
    define("D_MODE", "التغييرات وبعض الميزات غير متوفرة في الوضع التجريبي.");
    define("S_DIS", "تم تعطيل الإرسال حتى تقوم بإدخال رمز الشراء الخاص بك");
    define("HERE", "هنا");
    define("PLIK", "ملف");
    define("NOT_WR", "غير قابل للكتابة. لن يتم حفظ الإعدادات. قم بتغيير أذونات الملف قبل الحفظ.");
    define("EPC", "كود الشراء Envato");
    define("EVALIDEPC", "أدخل رمز شراء صالح");
    define("NO_ADMIN_MAIL", "قم بتحديث عنوان البريد الإلكتروني للمسؤول في الإعدادات أولاً.");
    
    define("SMTP_LABEL", "مستوى التصحيح");
    define("SMTP_0", "تعطيل التصحيح");
    define("SMTP_1", "رسائل الإخراج المرسلة من قبل العميل");
    define("SMTP_2", "ك 1 ، بالإضافة إلى الردود الواردة من الخادم (هذا هو الإعداد الأكثر فائدة)");
    define("SMTP_3", "2 ، بالإضافة إلى مزيد من المعلومات حول الاتصال الأولي - يمكن أن يساعد هذا المستوى في تشخيص حالات فشل STARTTLS");
    define("SMTP_4", "كما 3 ، بالإضافة إلى معلومات ذات مستوى أدنى ، مطولة جدًا ، لا تستخدم لتصحيح أخطاء SMTP ، فقط المشكلات ذات المستوى المنخفض ");
    
    define("SMTP_SENDER_FORCE", "قم دائمًا بفرض هذا المرسل في حملات لهذا الخادم");
    define("SMTP_SENDER_MAIL", "عنوان البريد الإلكتروني المرسل");
    define("SMTP_SENDER_DESCRIPTION", "وصف المرسل");

    
    
