<?php
	/*login page*/
	define("LANG","en");
	define("LOGIN_TITLE","Mailing system");
	define("LOGIN_SIGN_IN","Please sign in");
	define("LOGIN","Login");
	define("LOGIN_PASS","Password");
	define("LOGIN_SIGN_IN_BUTTON","Sign in");
	define("LOGIN_FAILED","Wrong login and/or password!");
	define("INSTALLING_SYSTEM","System configuration");
	define("INSTALLING_CONNECTED","correctly connected to database");
	define("INSTALLING_ADD_TABLES","Add tables");
	define("INSTALLING_ADD_TABLES_DESC","Click here to add tables and start working with the system");
	
	/*left menu*/
	define("WELCOME","Welcome,");
	define("WELCOME_ASK","What we do?");
	define("MAIN_MENU","Main menu");
	define("START","Start");
	define("DASHBOARD","Dashboard");
	define("EMAIL_ADRESSES","Email addresses");
	define("MENU_RECIPIENT_LIST","Recipients list");
	define("MENU_ADD_RECIPIENT","Add recipient");
	define("MENU_CSV_IMPORT","Import emails from a CSV file");
	define("MENU_CSV_EXPORT","Export emails to CSV file");
	define("MENU_TAG_LIST","Tags list");
	define("MENU_ADD_TAGS","Add tags");
	define("MENU_SENDERS_LIST","Senders list");
	define("MENU_ADD_SENDER","Add sender");
	define("MENU_TEMPLATES","Email layouts");
	define("MENU_TEMPLATES_LIST","Templates list");
	define("MENU_TEMPLATES_ADD","Add new template");
	define("MENU_TEMPLATES_ATTACHMENTS","Attachments");
    define("MENU_TEMPLATES_THUMBNAILS","Thumbnails");
	define("MENU_CAMPAIGNS","Your campaigns");
	define("MENU_CAMPAIGNS_ADD","Prepare new campaign");
	define("MENU_CAMPAIGNS_WAITING_LIST","Waiting list campaign");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Campaigns in progress");
	define("MENU_CAMPAIGNS_SENT","List sent campaigns");
	define("MENU_SYSTEM_CONFIGURATION","System configuration");
	define("MENU_SETTINGS","Settings");
	define("MENU_LOGIN","Login");
	define("MENU_DB","Database");
	define("MENU_SYSTEM_PARAMS","System params");
	define("MENU_SPECIALS","Special addons");
	define("MENU_ADDONS","Usefull extras");
	define("MENU_CLEAR_DB","Clear database");
	define("MENU_IMPORT_TEMPLATES","Import sample templates");
	define("MENU_IMPORT_DATA","Import sample data");
	define("MENU_FAQ","Q&A");
	define("MENU_ABOUT","About");
    define("MENU_SMTP_PARAMS","SMTP configuration");
    define("MENU_UNSUBSCRIBED","Unsubscribers list");
    define("MENU_UNSUBSCRIBED_LIST","list of recipients");
    define("MENU_DOCS","Documentation");
    define("MENU_SUBSCRIBE_WIDGET","Subscribe widget");
    define("MENU_BOUNCED","Check bounced mails");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","Email data base");
	define("D_EMAIL_ADD_NEW","Add new email");
	define("D_EMAIL_TEMPLATES","Email templates");
	define("D_EMAIL_TEMPLATES_ADD","Add new template");
	define("D_EMAIL_SENT","Sent emails");
	define("D_EMAIL_EFFICIENCY","Efficiency");
	define("D_EMAIL_UNSUBSCIBERS","Unsubscribed");
	define("D_CAMPAIGNS","Campaigns");
	define("D_CAMPAIGNS_ADD","New campaign");
	define("D_CAMPAIGNS_WAITING","Ready for sending");
	define("D_CAMPAIGNS_SENT","Completed");
	define("D_STATISTICS","Statistics");
	define("D_THIS_YEAR","Your advertising campaigns this year");
	define("D_CHECK_ALL","Check all...");
	define("JAN","jan");
	define("FEB","feb");
	define("MAR","mar");
	define("APR","apr");
	define("MAY","may");
	define("JUN","jun");
	define("JUL","jul");
	define("AUG","aug");
	define("SEP","sep");
	define("OCT","oct");
	define("NOV","nov");
	define("DEC","dec");
	define("D_PREPARED_OVERALL","prepared camaigns");
	define("D_SENT_OVERALL","sent");
	define("D_HOW_TO","How it works?");
	define("D_HOW_STEP_1_TITLE","1. Email data base");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Add tags</a> this will help you find customers and will help you easily prepare an advertising campaign. Next <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>add emails</a> to your database system. You can also <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>upload CSV file</a> with emails to your data base.");
	define("D_HOW_STEP_2_TITLE","2. Senders");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Add sender</a> you can decide from whom your customers will receive an email.");
	define("D_HOW_STEP_3_TITLE","3. Email templates");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Add template</a> prepare an unlimited number of templates, with unlimited number of attachments.");
	define("D_HOW_STEP_4_TITLE","4. Advertising campaigns");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Add new campaign</a> prepare unlimited campaigns. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Send campaign</a> at any time.");
	define("D_HOW_STEP_5_TITLE","5. Follow stats");
	define("D_HOW_STEP_5_DESC","Here you will learn which campaigns are the best, how and when the campaign was prepared and how much is sent and what is their efficacy (ie how many people opened your email and how many people unsubsrcibed from campaign).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Change login");
	define("CHANGE_PASS","Change password");
	define("CLEAR_DATABASE","Clear database");
	define("LOGOUT","Shut down");
	define("ABOUT","About");
	
	/*vertical buttons*/
	define("CONFIG","Configuration");
	define("CONFIG_TOOLTIP","System configuration");
	define("MEDIA_MANAGER","Attachments manager");
	define("RECIPIENT","Recipients");
	define("RECIPIENT_TOOLTIP","Emails management");
	define("RECIPIENT_EDIT","Modify details");
	define("RECIPIENT_ADD_NEW","Add new");
	define("MENUS","Menu management");
	define("MENUS_TOOLTIP","Menu configuration");
	define("TEMPLATES","Layouts");
	define("TEMPLATES_TOOLTIP","Layout configuration");
	define("HELP","Help");
	define("HELP_TOOLTIP","How it works");
	
	define("FILE_MANAGEMENT","Attachment's");
	define("CSV_IMPORT","CSV file emails import");
	
	define("PERSON","Person");
	define("EMAIL","Adres e-mail");
	define("TAGS","Tags");
	define("TAGS_LIST","Tag list");
	define("TAGS_ADD","Add new tags");
	define("TAGS_ADD_NEW","Tags adding");
	define("TAGS_ADD_EDIT","Tag edition");
	define("TAGS_NAME","Tag name");
	define("TAGS_DESCRIPTION","Description");
	define("TAGS_NAME_PLACEHOLDER","enter tag name...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","enter tag description...");
	define("TAGS_USED","Used (times)");
	define("TAGS_INFO","Tags for an email");
	
	define("RECIPIENT_LIST","Mailing list");
	define("RECIPIENT_NAME","Recipient name");
	define("RECIPIENT_NAME_PLACEHOLDER","Enter full name");
	define("RECIPIENT_MAIL","Email");
	define("RECIPIENT_MAIL_PLACEHOLDER","Enter email");
	define("RECIPIENT_ONLY_TXT","only TXT emails");
	define("RECIPIENT_DESCRIPTION","Description");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","Description...");
	define("RECIPIENT_DB","Your emails data base");
	define("RECIPIENT_DETAILS_EDIT","Edit recipient details");
	define("RECIPIENT_DETAILS_ADD","Adding new email address");
	define("RECIPIENT_IMPORT_CSV","Import emails from CSV file");
	define("RECIPIENT_PREPARE_CSV","Prepare a CSV file the following lines");
	define("RECIPIENT_UPLOAD_CSV_TITLE","To add new records form an Excel file you should follow below steps");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","download CSV template");

	define("RECIPIENT_UPLOAD_CSV_NAME","Import CSV file");
	define("RECIPIENT_NOT_CSV","<b>this is not a CSV file!!!</b><br/>");
	define("RECIPIENT_ROW","Row ");
	define("RECIPIENT_WRONG_EMAIL"," - incorrect email address, entered: ");
	define("RECIPIENT_EMAIL_EXIST"," - this address is already in the database: ");
	define("RECIPIENT_EMAIL_LACK"," - lack of an email address");
	define("RECIPIENT_EMAIL_IN_DB"," - this email address already exist in CSV file in row ");
	define("RECIPIENT_TAG_NOT_EXIST"," - no such tag: ");
	define("RECIPIENT_CSV_ERRORS","Errors in file ");
	define("RECIPIENT_CSV_ADDED","Added ");
	define("RECIPIENT_CSV_ADDED_FROM"," email adresses from file ");
	define("RECIPIENT_CSV_EXPORT","Export email addresses to a file");
	define("RECIPIENT_CSV_EXPORT_CHK","Select the fields to export:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Recipient's email address");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","First name and last name");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Tags - separated by a single space");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Comments");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Receive text-only emails");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Date of introduction");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Date of modification");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","export");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Ignore CSV errors checking (check it if the file contains more than 1000 emails - larger files require a large amount of memory on the server)");
	
	define("SAVE","Save");
	define("CANCEL","Cancel");
	define("DELETE","Delete");
    define("EDIT","Edit");
	define("CREATED","Created");
	define("MODIFIED","Modified");
	define("SEND","Send");
	define("SENT","Sent");
	define("PROGRESS","Progress");
	define("RESUME","Resume");
	define("CLOSE","Close");
	define("CHANGES_SAVED","Changes were made successfully");
	
	define("DELETING","Deleting");
	define("DELETING_CONFIRM_QUESTION","Are you sure you want to remove?");
	
	define("DATATABLE_LENGTHMENU", "Display _MENU_ records per page");
	define("DATATABLE_ZERORECORDS", "Nothing found - sorry");
	define("DATATABLE_INFO", "Showing page _PAGE_ of _PAGES_");
	define("DATATABLE_INFOEMPTY", "No records available");
	define("DATATABLE_INFOFILTERED", "(filtered _TOTAL_ from _MAX_ total records)");
	define("DATATABLE_SEARCH", "Search");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Add new template");
	define("TEMPLATES_LIST", "Templates list");
	define("TEMPLATES_TITLE", "Available templates");
	define("TEMPLATES_TITLE_ADD", "Add new layout");
	define("TEMPLATES_TITLE_EDIT", "Layout editing");
	define("TEMPLATES_NAME", "Layout name");
	define("TEMPLATES_MAIL_TITLE", "Email title");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Enter email title");
	define("TMPLATES_HTML", "HTML version");
	define("TMPLATES_TXT", "TEXT version");
	define("TMPLATES_VARIABLES", "Available template variables (check <a href='docs/index.html#variables' target='_blank'>docs</a> for details):");
	define("TEMPLATES_THUMB", "Thumbnail");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Thumbnail editing");
	define("THUMBNAIL_MEDIA_LIST", "Available thumbnails list");
	
	define("MEDIA_FILENAME", "File name");
	define("MEDIA_FILENAME_DESCRIPTION", "File description");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Upload time");
	define("MEDIA_TEMPLATES", "Used as an attachment");
	define("MEDIA_LIST", "Available attachemnt list");
	define("MEDIA_ADD_FILES", "Add files");
	define("MEDIA_BROWSE", "Browse");
	define("MEDIA_UPLOAD", "Upload");
	
	define("CAMPAIGN_MENU", "New campaign");
	define("CAMPAIGN_PREPARE", "Prepare campaign");
	define("CAMPAIGN_RECIPIENTS", "Choose recipients");
	define("CAMPAIGN_TEMPLATES", "Choose layout");
	define("CAMPAIGN_SENDERS", "Choose sender");
	define("CAMPAIGN_CONFIRM", "Save campaign");
	define("CAMPAIGN_SEND", "Send campaign");
	define("CAMPAIGN_NAME", "Campaign Name");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Enter campaign name");
	define("CAMPAIGN_RECIPIENT_QTY", "Recipients");
	define("CAMPAIGN_TEMPLATE_NAME", "Layout");
	define("CAMPAIGN_SENDER", "Sender");
	define("CAMPAIGN_CREATED_DATE", "Prepared");
	define("CAMPAIGN_STEP_1", "1. Select your recipients (use 'search' field over the table)");
	define("CAMPAIGN_STEP_2", "2. Save your campaign");
	define("CAMPAIGN_SELECT", "Select campaign for mailing");
	define("CAMPAIGN_FORM_SELECT", "select...");
	define("CAMPAIGN_CURRENT_STATUS", "Status of current campaign");
	define("CAMPAIGN_SENT_NOW", "Send it now");
	define("CAMPAIGN_SENT_BUTTON", "Click here to start sending");
	define("CAMPAIGN_RESUME_BUTTON", "Click here to resume sending");
	define("CAMPAIGN_SERVER_CONNECTING", "connecting to server, please wait...");
	define("CAMPAIGN_SENDING", "sending");
	define("CAMPAIGN_PLEASE_WAIT", "please wait...");
	define("CAMPAIGN_SENT", "<b>CAPAIGN SENT</b> recipients: ");
	define("CAMPAIGN_IN_PROGRESS", "Campaigns in progress...");
	define("CAMPAIGN_COMPLETED", "Sent campaigns");
	define("CAMPAIGN_LEFT", "Left to send");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Delete All unsubscribers");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "This action will delete all unsubscribers from your database.");
	define("CAMPAIGN_BG_PROCESS", "Background process");
	define("CAMPAIGN_BG_PROCESS_INFO", "Send as a background process (you can close browser)");
	define("CAMPAIGN_WHEN_FINISH", "email when finished");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "where to send notification");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Please confirm background sending!");
    
    define("HOUR", "hour");
    define("OPENS", "Opens");
    define("BOUNCED", "Bounced");
    define("CLICKED", "Clicked");
    define("UNIQUE_CLICKS", "Unique clicks");
    define("TOTAL_CLICKS", "Total clicks");
	
	define("SENDER_LIST", "Senders list");
	define("SENDER_ADD", "Add sender");
	define("SENDER_NAME", "Sender name");
	define("SENDER_NAME_PLACEHOLDER", "Enter sender name");
	define("SENDER_EMAIL", "Sender email");
	define("SENDER_EMAIL_PLACEHOLDER", "Enter sender email");
	define("SENDER_TITLE_ADD", "Add sender");
	define("SENDER_TITLE_EDIT", "Edit sender");
	define("SENDER_EMAIL_TITLE", "Sender email address");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Enter sender email address");
	
	define("SETTINGS", "Settings");
	define("SETTINGS_LOGIN_TITLE", "Enter new credentials");
	define("SETTINGS_LOGIN_LABEL", "Enter new login");
	define("SETTINGS_LOGIN_PLACEHOLDER", "enter login");
	define("SETTINGS_CURR_PASS", "Current password");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "enter password");
	define("SETTINGS_NEW_PASS", "New password");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "new password");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "confirm");
	define("SETTINGS_DB_PARAMS", "Setup the database");
	define("SETTINGS_DB_HOST", "Database host");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "ex.: localhost");
	define("SETTINGS_DB_USER", "Database user");
	define("SETTINGS_DB_USER_PLACEHOLDER", "ex.: root");
	define("SETTINGS_DB_PASSWORD", "Database password");
	define("SETTINGS_DB_NAME", "Database name");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "ex.: mailing");
	define("SETTINGS_GLOBAL", "Global settings");
	define("SETTINGS_LANG", "System language");
	define("SETTINGS_LIMIT", "Setup email limit per hour");
	define("SETTINGS_LIMIT_PLACEHOLDER", "default: 1000");
	define("SETTINGS_TRACKING", "Enable email tracking");
	define("SENDING_METHOD", "Sending method");
	define("SETTINGS_UNSUBSCRIBED", "Auto delete unsubscrbed");
	define("SETTINGS_UNS_INFO", "email will be automatically deleted from recipient list when user click your unsubscibe link");
	define("SETTINGS_TRACK_INFO", "invisible img tag will be added to track your recipient");
	define("SETTINGS_API_LABEL", "Google maps<br>API key");
	define("SETTINGS_API_PLACEHOLDER", "enter your google maps API v.3 key here");
	define("SETTINGS_API_LINK_INFO", "click here to obtain new API key");
	define("SETTINGS_ADMIN_MAIL", "Admin email");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "admin email for system notifications");
    define("SETTINGS_PHP_TIMEOUT", "PHP timeout (seconds)");
    
	define("SMTP_SERVER_DESCRIPTION", "SMTP Server, be sure to add some");
    define("SMTP_LIST", "server list");
    define("SMTP_ADD", "adding new server");
    define("SMTP_EDIT", "editing server");
    define("SMTP_INFO", "Your SMTP servers");
    define("SMTP_ADD_BUTTON", "Click to add new SMTP server");
    define("SMTP_NAME", "Connection name");
    define("SMTP_NAME_PLACEHOLDER", "ex.: my best connection");
    define("SMTP_HOST", "SMTP address");
    define("SMTP_HOST_PLACEHOLDER", "Main and backup server (separator ';' for backup)");
    define("SMTP_PAUTH", "Authentication");
    define("SMTP_PAUTH_PLACEHOLDER", "Enable SMTP authentication");
    define("SMTP_VERIFY_PEER", "Enable SSL/TLS certificate verification");
    define("SMTP_FORCE_SMTP", "Force SMTP usage");
    define("SMTP_USERNAME", "SMTP username");
    define("SMTP_USERNAME_PLACEHOLDER", "SMTP username");
    define("SMTP_LOGIN", "SMTP login");
    define("SMTP_LOGIN_PLACEHOLDER", "SMTP server login");
    define("SMTP_PASSWORD", "SMTP password");
    define("SMTP_PASSWORD_PLACEHOLDER", "SMTP password");
    define("SMTP_REPLYTO", "Reply to mail");
    define("SMTP_REPLYTO_PLACEHOLDER", "Set an alternative reply-to address");
    define("SMTP_REPLYTONAME", "Reply to name");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Set an alternative reply-to name");
    define("SMTP_SECURE", "Encryption");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> as default encryption");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> accepted but not recommended");
    define("SMTP_PORT", "Port");
    define("SMTP_PORT_PLACEHOLDER", "server port");
    define("SMTP_LIMIT", "Limit per hour");
    define("SMTP_LIMIT_PLACEHOLDER", "default: 1000");
    define("CAMPAIGN_SMTP", "Select SMTP");
    define("SMTP_TESTING", "Testing SMTP connection");
    define("SMTP_TESTING_EMAIL", "Address for testing message");
    define("SMTP_RUN_TEST", "Check It!");
    define("SMTP_TEST_TXT_TITLE", "SMTP test from E-mailer.");
    define("SMTP_TEST_TXT_MESSAGE", "Test message from your SMTP connection.");
    define("SMTP_TEST_OK", "Message has been sent. Check your mailbox.");
    define("SMTP_TEST_ERROR", "<b>Mailer Error: </b>");
    define("SMTP_BEFORE_USE", "<b>Mailer Error.</b> You need to enable SMTP connection in the settings before use.");
    define("BOUNCED_INFO", "bounced emails will back to that mailbox");
    define("SMTP_CONFIG", "Setup your SMTP for sending");
    define("IMAP_CONFIG", "Setup your IMAP / POP3 for bounces");
    define("SMTP_INFO_SETUP", "SMTP settings");
    define("IMAP_INFO_SETUP", "IMAP / POP3 settings");
    define("PROTOCOL", "Protocol");
    define("FOLDER", "Folder to access");
	
	define("STATISTICS", "Statistics");
	define("STATISTICS_ADV", "Advanced details");
	define("STATISTICS_TAB_MAP", "Recipients on the map (geoloacation)");
	define("STATISTICS_TAB_DETAILS", "Detailed statistics");
	define("STATISTICS_TAB_ACTIONS", "Special actions");
	define("STATISTICS_BACK", "Back to list");
	define("STATISTICS_BUTTON_OPENERS", "Prepare for openers");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Prepare new campaign for all those who opened an email");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Prepare for NOT openers");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Prepare new campaign for all those who NOT opened an email");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Prepare for unsubscribed");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Prepare new campaign for all unsubscribers, if an option 'Auto delete unsubscribed' in the system settings is enabled emails are deleted and nothing will be add here");
	define("STATISTICS_BUTTON_FILTERS", "Prepare with advanced filters");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Get list of all recipients from this campaign with collected data and prepare new special campaign based on advanced filters");
	define("STATISTICS_TOP_COUNTRIES", "Top 10 Countries");
	define("STATISTICS_TOP_CITIES", "Top 10 Cities");
	define("STATISTICS_TOP_CLICKERS", "Top 15 clickers");
	define("STATISTICS_TOP_SOFTWARE", "Top 15 most popular software");
	define("STATISTICS_OTHER_UA", "All others user agents");
	define("STATISTICS_OTHERS", "Others");
    
	define("SOFTWARE", "Software");
	define("GEODATA", "Localization");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='confirmation'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Successfully unsubscibed from newsletter.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Have a nice day.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Removing unnecessary data from the database");
	define("ADDONS_IMPORT_TITLE", "Adding sample templates mailing");
	define("ADDONS_FAQ_TITLE", "Read before you ask");
	define("ADDONS_ABOUT_TITLE", "Information about the program and license");
	define("ADDONS_IMPORT_DATA_TITLE", "Import sample data to the system");
	define("ADDONS_IMPORT_BUTTON", "Import email templates");
	define("ADDONS_IMPORT_BUTTON_DESC", "This will import sample templates for mailing");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Confirm adding example templates for mailing");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Confirm adding sample data to the system. All the currently entered data will be erased!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Why it is better to have own dedicated server for mailing?</p>
			<p>First of all, no limits. For ordinary hosting, you can send up to 1,000 emails per hour and probably the same amount within one day (depending on the hosting limits range from a few hundred to a few thousand emails a day). On your server, you do not have such restrictions and also have the ability to send emails from your domain. You can also send e-mails as if the server was to be under a different domain (it is in this case set the so-called SPF records and TXT domain - for details ask your hosting provider).</p>
		</li>
		<li>
			<p>What are tags?</p>
			<p>Make it easy to find mailing addresses and preparing an advertising campaign at a specific recipients.</p>
		</li>
		<li>
			<p>How to add the name of the recipient to email template?</p>
			<p>Use phrase {RECIPIENT_NAME} in the content template email or in the title of the template mail. The phrase will be replaced by the name of the recipient e-mail, in case that the information has been added to the recipient's email address.</p>
		</li>
		<li>
			<p>How to add a new translation?</p>
			<p>Copy the file reference english.php, give it a name that describes your language for example mylanguage.php and paste to the same folder. Correct all the texts contained in the new file. Be sure to save the file in UTF-8 w / o BOM. Language file is in the directory 'languages'.</p>
			<p>To add translation of WYSIWYG editor, go to https://www.tinymce.com/download/language-packages/ - download appriopriate file language and save it in /emailer/libs/tinymce/langs/ folder.</p>
		</li>
		<li>
			<p>How do I add tags to an e mail?</p>
			<p>First, you need to add a few tags <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>using this form</a>. Then when you add/edit each email address can be assigned to any tag. All tags will be added below the form to add/edit recipients.</p>
		</li>
		<li>
			<p>How to add the ability to unsubscribe out of receiving messages?</p>
			<p>Use phrase {UNSUBSCRIBE} in the link in the email template content. The phrase will be replaced with a link for the particullar recipient. When he/she will click it, system will save in the database information about the discharge of the campaign. Email address will not be removed from the database. <br>Usage:<br>&lt;a href='{UNSUBSCRIBE}'&gt;unsubscribe from the newsletter&lt;/a&gt;</p>
		</li>
		<li>
			<p>How to add the ability to browser view?</p>
			<p>Use phrase {BROWSER_VIEW} in the link in the email template content. The phrase will be replaced with a link for the particullar recipient. When he/she will click it, system will open message in browser window. <br>Usage:<br>&lt;a href='{BROWSER_VIEW}'&gt;browser view&lt;/a&gt;</p>
		</li>
		<li>
			<p>How to add predefined email templates?</p>
			<p>30 sample templates mailing, click here <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>to add templates</a></p>
		</li>
		<li>
			<p>How do I add images to e-mails?</p>
			<p>- As an attachment to an email. In this case, the template IMG tag attribute SCR must be set to contentID, means CID, eg:<br>&lt;img src='cid:logo.jpg' &gt;<br>- As an absolute link to an image in external resources, such as:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>How does the tracking of emails?</p>
			<p>For each sent email system can add an image tag IMG, which attribute SRC contains tracking code to display a specific message. Tracking will only work when the mail recipient agrees to show images of the received message.</p>
		</li>
		<li>
			<p>How not to be a spammer?</p>
			<p>- Collect consent to receive messages when creating a mailing list.</p>
			<p>- Use a variety of content for each recipient, use ex. {RECIPIENT_NAME} to differentiate checksums of your mailing.</p>
			<p>- Do not use the keywords like: sex, viagra, porn.</p>
			<p>- Do not use key phrases such as: address from a public database, it is not commercial information in mind, uninterested Sorry, it does not constitute an offer within the meaning if you do not want, click here to unsubscribe, free, special offer, buy it now - if you have to use this such phrases you should consider to put them in the form of graphics.</p>
			<p>- Do not use too many graphics, spam filters examine the ratio of the graphics to text.</p>
			<p>- Mail should not be too heavy.</p>
			<p>- The fewer the better attachments.</p>
			<p>- Do not impersonate another domain.</p>
			<p>- Do not send emails from non-existent email address.</p>
		</li>
		<li>
			<p>How to increase clicks and reads campaign?</p>
			<p>The biggest influence on the content that you send to your customers and the time and the frequency with which you do it. In most cases, the contact should not be more frequent than two times a month. Respect your customers and they will not throw you to the spam.</p>
		</li>
		<li>
			<p>How to choose the addresses for mailing?</p>
			<p>Using tags, type them separated by spaces in the search field above the table of addresses.</p>
		</li>
		<li>
			<p>What are the limitations of this system?</p>
			<p>There is no restrictions.</p>
		</li>
		<li>
			<p>Limit messages on the server hosting?</p>
			<p>Depending on the hosting limits range from a few hundred to a few thousand emails a day, check with your service provider.</p>
		</li>
		<li>
			<p>Broken connection when sending campaign?</p>
			<p>You can resume the sending of campaigns, emails will be sent to the other recipients. Each sent email sets a unique marker in the database and the campaign itself will not be re-sent to the same recipient.</p>
		</li>
		<li>
			<p>Requirements for bounced emails</p>
			<p>To enable support for bounced emails you have to uncomment this line in php.ini file.</p>
			<p>;extension=php_imap.dll</p>
			<p>Imap functions are required to use POP3 / IMAP connections.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Be carefully, the following actions clean tables in the database!");
	define("ADDONS_DATA_BE_CAREFULLY", "Warning! All data will be deleted and replaced with sample data");
	define("ADDONS_D_AL", "Delete all data");
	define("ADDONS_D_AL_DESC", "Erases all data in the database");
	define("ADDONS_D_AL_CONF", "Are you sure you want to remove all data from the database? Will be deleted all email addresses, templates, attachments and campaigns.");
	define("ADDONS_D_RE", "Remove the recipients and their campaigns");
	define("ADDONS_D_RE_DESC", "Deletes all e-mail addresses in the database and the history of advertising campaigns");
	define("ADDONS_D_RE_CONF", "Confirm the removal of all recipients");
	define("ADDONS_D_CA", "Delete only campaigns");
	define("ADDONS_D_CA_DESC", "Deletes all advertising campaigns and their history");
	define("ADDONS_D_CA_CONF", "Confirm the removal of all campaigns and their history");
	define("ADDONS_D_TE", "Remove templates only");
	define("ADDONS_D_TE_DESC", "Deletes all email templates and their links with campaigns and attachments");
	define("ADDONS_D_TE_CONF", "Confirm the deletion of all templates");
	define("ADDONS_D_AT", "Delete only attachments");
	define("ADDONS_D_AT_DESC", "Deletes all attachments");
	define("ADDONS_D_AT_CONF", "Confirm delete all attachments");
	define("ADDONS_D_SE", "Delete only senders");
	define("ADDONS_D_SE_DESC", "Deletes all entered senders email but leaves their ID for statistical purposes");
	define("ADDONS_D_SE_CONF", "Confirm the removal of all senders");
	define("ADDONS_D_TG", "Delete only tags");
	define("ADDONS_D_TG_DESC", "Clear all entered tags and their relationships with customers");
	define("ADDONS_D_TG_CONF", "Confirm remove all tags");
    
	define("WIDGET_PREPARE", "Prepare your subscription widget");
	define("WIDGET_OPTIONS", "Options");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Generate you subscribtion widget here");
	define("WIDGET_COMMENT", "Comment about new recipient");
	define("WIDGET_COMMENT_PLACEHOLDER", "ex.: from domain.ext (will be saved in recipient description)");
	define("WIDGET_NAME", "Name");
	define("WIDGET_NAME_SHOW", "Show recipient name field");
	define("WIDGET_AFTER", "After submit subscription widget");
	define("WIDGET_AFTER_NOTHING", "do nothing");
	define("WIDGET_AFTER_TXT", "show txt message");
	define("WIDGET_AFTER_REDIRECT", "redirect to page");
	define("WIDGET_TAGS", "Add tags");
	define("WIDGET_PURE_CODE_TXT", "Pure HTML code. You can modify it to your needs. Add classes, tags, descriptions, whatever you want. Copy the code below and paste it into your website.");
	define("WIDGET_FULL_CODE_TXT", "Full version (all fields included)");
	define("WIDGET_MIN_CODE_TXT", "Minimized version (only email included)");
	define("WIDGET_CODE_DESC_TXT", "Form description");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> required.</li>
        <li>Email address of subscriber.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> optional.</li>
        <li>Name of subscriber.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> optional.</li>
        <li>Hidden field.</li>
        <li>They must already be added to the database.</li>
        <li>They must be separated by comma.</li>
        <li>Using different tags you can make different campaigns.</li>
        <li>You can use the same form on different sites and use different tags on each site.</li>
        <li>It means this component can collect subscribers from different sites and add them to your system with different tags.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> optional.</li>
        <li>Hidden field.</li>
        <li>Add your description for recipient.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> optional.</li>
        <li>Hidden field.</li>
        <li>Enable double opt-in feature.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> optional.</li>
        <li>Hidden field.</li>
        <li>Where to redirect after subscribe. If field is empty or not included in the form, configured action will be proceed.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Copy the code below and paste it on your site");
	define("WIDGET_DBL_OPT_IN", "Double opt-in");
	define("WIDGET_DBL_OPT_LABEL", "check it to use double subscription confirmation");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "Email message (support HTML)");
	define("WIDGET_DBL_OPT_HELP", "Do not forget to add <b>{CONFIRM_LINK}</b> in your message.<br>You can also add:<br><b>{SUBSCRIBER_EMAIL}</b> - subscriber email address<br><b>{SUBSCRIBER_NAME}</b> - subscriber name<br><b>{SUBSCRIBER_COMMENT}</b> - your comment about subscriber<br><b>{SUBSCRIBER_TAGS}</b> - used tags<br><b>{CURRENT_YEAR}</b> - current year<br><b>{CURRENT_MONTH}</b> - current month<br><b>{CURRENT_DAY}</b> - current day");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "Email title");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "enter email confirmation title...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "enter email confirmation message...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Redirect to after confirmation");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "enter adress where to redirect after confirmation");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Send from address");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "enter email adress from which confirmation will be send");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Sender description");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "enter description for sender");
	define("WIDGET_ADMIN_NOTIFY", "Notify admin about new subscriber");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "check to send email notification after new subscribtion is received.<br><br><b>WARNING!</b> Admin email has to be set up in System params!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Admin message (support HTML)");
	define("WIDGET_ADMIN_HELP", "Can be used in your message:<br><b>{SUBSCRIBER_EMAIL}</b> - subscriber email address<br><b>{SUBSCRIBER_NAME}</b> - subscriber name<br><b>{SUBSCRIBER_COMMENT}</b> - your comment about subscriber<br><b>{SUBSCRIBER_TAGS}</b> - used tags<br><b>{CURRENT_YEAR}</b> - current year<br><b>{CURRENT_MONTH}</b> - current month<br><b>{CURRENT_DAY}</b> - current day");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Server error message in case of wrong subscriber email address");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Choose your server");
	define("BOUNCED_DEL_EMAILS", "Automatically delete from recipient list");
	define("BOUNCED_DEL_MESSAGES", "Automatically delete all bounced and checked messages from server");
	define("BOUNCED_MAX", "Max messages limit");
	define("BOUNCED_AT_TIME", "to check at one time");
	define("BOUNCED_START", "Check mailbox for bounced emails");
	
	define("YES", "Yes");
	define("NO", "No");
	define("DATA_ERROR", "ERROR: Requested data not exists...<br><br><a href='index.php'>click here to open dashboard</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "The server to send mail for subscription widget");
    define("TESTING_TEMPLATE", "Testing template");
    define("TESTING_TEMPLATE_INFO", "Sends the template to the entered email below. Variables will not be substituted.");
    define("TESTING_CHOOSE_SERVER", "Select sending server.");
    define("ERRORS", "Errors");
    define("TEST", "Test me!");
    
    /*v.1.16*/
    define("COPY", "Copy");
    define("COPYING", "Copying");
    define("CHECK", "Check");
    define("DATA_VERIFY", "Data integrity checking");
    define("DATA_VERIFY_QUESTION", "Are you sure you want to check data integrity?");
    define("DATA_VERIFY_DESCRIPTION", "This operation can take severel minutes, it depends on the amount of data in your database. <br>Do it if you are sure that campaign was finished and is not visible on this list.");
    define("DATA_VERIFY_BUTTON", "Verify data integrity");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Filter recipients from selected tags (OR&nbsp;query)");
    define("REC_QUERY_AND", "Filter recipients being in ALL selected tags (AND&nbsp;query)");
    define("REC_RESET", "Reset query");
    define("REC_BUTTON_DELETE", "Delete recipients");
    define("CSV_ST_1", "Prepare the data according to the formula:");
    define("CSV_COL_NO", "column no.");
    define("CSV_REQ", "required");
    define("CSV_OPT", "optional");
    define("CSV_ADDR", "email address");
    define("CSV_NAME", "first name and last name");
    define("CSV_TAGS", "tags");
    define("CSV_TAGSDESC", "must be in the database must be separated by a single space");
    define("CSV_COMMENT", "comments");
    define("CSV_DESC1", "Save the spreadsheet as a CSV");
    define("CSV_DESC2", "delimiter");
    define("CSV_MAXLINE", "max CSV line length");
    define("CSV_FORMDESC", "Upload a prepared CSV file using the form below");
    define("DISABLE_EDITOR", "Disable editor");
    define("ENABLE_EDITOR", "Enable editor");

    /*v.1.18*/
    define("MENU_BRIDGE", "Import emails by DB bridge");
    define("TITLE_IMPORT", "Recipients import");
    define("SUBTITLE_IMPORT", "database bridge - source params");
    define("LIST_TITLE_IMPORT", "Import recipients from other database");
    define("ADD_NEW_BRIDGE", "Add new bridge");
    define("IMPORT_RECIPIENTS", "Import recipients");
    define("IMPORT_BRIDGE_DESC", "Import bridge description");
    define("CONFIRM_BRIDGE_DEL", "Deleting database bridge connection");
    define("IMPORTING_BRIDGE_REC", "Importing recipients");
    define("CHOOSEN_BRIDGE", "Choosen bridge for import");
    
    define("FORM_BRIDGE_DESC", "Import bridge description");
    define("BRIDGE_TABLE", "Source table name");
    define("BRIDGE_COL_NAME", "Source column for recipient name");
    define("BRIDGE_COL_NAME_INFO", "will be imported to Recipient name field");
    define("BRIDGE_COL_MAIL", "Source column for email address");
    define("BRIDGE_COL_MAIL_INFO", "will be imported to Email field");
    define("BRIDGE_COL_DESC", "Source column for recipient description");
    define("BRIDGE_COL_DESC_INFO", "will be imported to Description field");
    define("BRIDGE_CHECK_CON", "Check database connection");
    define("BRIDGE_WAITING", "waiting for test...");
    define("BRIDGE_ADD_NAME", "Additional recipient name");
    define("BRIDGE_ADD_NAME_INFO", "will be added after source name column");
    define("BRIDGE_ADD_DESC", "Additional recipient description");
    define("BRIDGE_ADD_DESC_INFO", "will be added after source description column");
    define("BRIDGE_OVERRIDE", "Override existing recipients");
    define("BRIDGE_OVERRIDE_O1", "update - correct destination recipient according to new source");
    define("BRIDGE_OVERRIDE_O2", "ignore - do nothing if destination recipient already exist");
    define("BRIDGE_TAGS", "Available tags");
    define("BRIDGE_FILL_FIELDS", "fill all required fields before testing...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "import in progress, please wait...");
    define("BRIDGE_TEST_OK", "Your connection bridge is working correctly");
    define("BRIDGE_IMPORT_OK1", "Import finished. Updated:");
    define("BRIDGE_IMPORT_OK2", " Inserted:");
    define("TABLE", "Table ");
    define("COLUMN", "Column ");
    define("NOT_IN_DB", " not exists in database ");
    define("NOT_IN_TABLE", " not exists in table ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "enter your geolocation API key here");
    define("SETTINGS_API_GEO_LINK_INFO", "click here to obtain new geolocation API key");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Use https");
    define("HTTPS_USAGE_INFO", "check if you are using https, this will generate all links with https");
    define("TEMPLATE_STATISTICS", "Template statistics: ");
    define("TEMPLATE_CHARS", "characters: ");
    define("TEMPLATE_USAGE", "used: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Subsciption CSRF form register token ");
    define("WIDGET_EMAIL_TOKEN", "Subsciption email register token ");
    
    /*v.1.22*/
    define("WEBSITE", "Website");
    define("WIDGET_WEBSITE_SHOW", "Show recipient url field");
    define("VERIFIED", "Verified");
    define("VERIFY", "Verify");
    define("C_PREPARED", "prepared and waiting");
    define("C_AJAX_PROGRESS", "ajax sending in progress");
    define("C_FINISHED", "finished");
    define("C_BG_PROGRESS", "background sending in progress");
    define("C_PAUSED", "paused");
    define("C_CRON", "cron sending in progress");
    define("B_VER", "Bulk verification");
    define("B_RV", "Bulk recipients verification");
    define("B_SEND1", "Are you sure you want to send");
    define("B_SEND2", "recipients for verification");
    define("B_CHECK_LIST", "check bulk verification lists");
    define("B_VER_INFO", "Your bulk checks will be available on your emailable.com account");
    define("B_VER_IN_PROG", "verifying in progress");
    define("B_VER_SENT", "Recipients sent for bulk checking");
    define("B_V_TITLE", "Bulk email verifications");
    define("B_V_TITLE2", "sent lists");
    define("BUTTON_CHECK_STATUS", "Check status");
    define("BUTTON_DOWN_UP", "Download & Update");
    define("V_ID", "verify id");
    define("V_QTY", "qty to check");
    define("V_DATE", "sent date");
    define("V_MESSAGE", "state");
    define("V_PERC", "% complete");
    define("V_WORKING", "working");
    define("RESPONSE", "response");
    define("V_UPDATED_INFO", "Recipients updated, check details");
    define("SETTINGS_API_THECHECKER", "click here to obtain emailable.com API key");
    define("SETTINGS_API_DESCRIPTION", "Lets kill the bounces! <br>Using the button below, will give you <b>30% FREE EXTRA CHECKS</b> in your first purchase and give you a 30% bonus (in cash or checks) at each your purchase you make, forever!");
    define("EC_DATA", "Export all campaigns data");
    define("EC_DATA1", "Export campaign data");
    define("EX_OPENED_BUTTON", "Recipients who opened");
    define("EX_OPENED_DESC", "Export campaign recipients who opened campaign email");
    define("EX_NOT_OPENED_BUTTON", "Recipients who not opened");
    define("EX_NOT_OPENED_DESC", "Export campaign recipients who NOT opened campaign email");
    define("EX_UNSUBSRIBED_BUTTON", "Recipients who unsubscribed");
    define("EX_UNSUBSRIBED_DESC", "Export campaign recipients who unsubscribed from campaign");
    define("EX_CLICKED_BUTTON", "Recipients who clicked");
    define("EX_CLICKED_DESC", "Export campaign recipients who clicked link in campaign email");
    define("EX_ALL_BUTTON", "All recipients data");
    define("EX_ALL_DESC", "Export all recipients data of current campaign");
    define("EX_COUNTRY_BUTTON", "Recipients countries");
    define("EX_COUNTRY_DESC", "Export all countries of current campaign");
    define("EX_CITY_BUTTON", "Recipients cities");
    define("EX_CITY_DESC", "Export all cities of current campaign");
    define("EX_BROWSER_BUTTON", "Recipients browsers");
    define("EX_BROWSER_DESC", "Export all browsers of current campaign");
    define("SETTINGS_CHARSET", "Set your charset for data export");
    define("MENU_BULK", "Bulk verifications");
    define("B_CONFIRM", "confirm bulk delete from emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Update recipients. If an email address exists in the database, update it using the data from the CSV file.");
    define("TAGS_MANAGER_TITLE", "Recipients tags manager, selected emails: ");
    define("TAGS_SELECT_ACTION", "Choose your action:");
    define("TAGS_MANAGER_ADD", "Add tags to selected recipients");
    define("TAGS_MANAGER_REMOVE", "Remove tags from selected recipients");
    define("TAGS_SELECT", "Select your tags:");
    define("SAVE_CHANGES", "Save changes");
    define("NOT_SELECTED_TAGS", "Select recipients first");
    define("TM_BUTTON", "Bulk tags manager");
    define("WAITING", "waiting...");
    define("MULTI_SMTP", "Multi SMTP");
    define("MULTI_CHECK_DESC", "check, if you want use multi smtp sending feature");
    define("MULTI_CHOOSE", "Choose smtp servers");
    
    /*v.1.25*/
    define("MENU_BLACKLIST", "Blacklist");
    define("BL1", "List of disallowed domains and IP's");
    define("BL2", "blocked malicious adresses for subscription");
    define("BL3", "Your blacklist");
    define("B_VALUE", "Value");
    define("B_TYPE", "Type");
    define("MENU_ADD_BL", "Add new entry");
    define("B_DOMAIN", "domain");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "You can import list of malicious adresses to your blacklist here <small>(each record must be in separated line)</small>");
    define("B_DELETE_ALL", "Clear blacklist");
    define("B_DELETE_QUESTION", "Are you sure you want to delete whole blacklist?");
    define("B_EXPORT", "Export blacklist");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM settings");
    define("DKIM_USE", "use DKIM");
    define("DKIM_DOMAIN", "Signing domain name");
    define("DKIM_PRIVATE", "Private key file path");
    define("DKIM_SELECTOR", "Usually the selector key setup on your DNS TXT record");
    define("DKIM_PASS", "Used if your key is encrypted");
    define("DKIM_IDENTITY", "Usually the email address used as the source of the email");
    
    define("ERROR", "Error:");
    define("WARNING", "WARNING!");
    define("D_MODE", "Changes and some features are not available in DEMO mode.");
    define("S_DIS", "Sending disabled until you enter your purchase code");
    define("HERE", "here");
    define("PLIK", "file");
    define("NOT_WR", "is not writtable. Settings will not be saved. Change file permissions before saving.");
    define("EPC", "Envato purchase code");
    define("EVALIDEPC", "Enter Valid purchase code");
    define("NO_ADMIN_MAIL", "Update admin email address in settings first.");
    
    define("SMTP_LABEL", "debug level");
    define("SMTP_0", "Disable debugging");
    define("SMTP_1", "Output messages sent by the client");
    define("SMTP_2", "as 1, plus responses received from the server (this is the most useful setting)");
    define("SMTP_3", "as 2, plus more information about the initial connection - this level can help diagnose STARTTLS failures");
    define("SMTP_4", "as 3, plus even lower-level information, very verbose, don't use for debugging SMTP, only low-level problems");
    
    define("SMTP_SENDER_FORCE", "Always force this sender in campaigns for this server");
    define("SMTP_SENDER_MAIL", "Sender email address");
    define("SMTP_SENDER_DESCRIPTION", "Sender description");
