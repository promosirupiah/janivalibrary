<?php
	/*login page*/
	define("LANG","it");
	define("LOGIN_TITLE","Sistema di mailing");
	define("LOGIN_SIGN_IN","Entra");
	define("LOGIN","Accesso");
	define("LOGIN_PASS","Parola d'ordine");
	define("LOGIN_SIGN_IN_BUTTON","Registrati");
	define("LOGIN_FAILED","Login e / o password sbagliata!");
	define("INSTALLING_SYSTEM","Configurazione di sistema");
	define("INSTALLING_CONNECTED","Correttamente collegato alla banca dati");
	define("INSTALLING_ADD_TABLES","Aggiungere tabelle");
	define("INSTALLING_ADD_TABLES_DESC","Clicca qui per aggiungere tavoli e iniziare a lavorare con il sistema");
	
	/*left menu*/
	define("WELCOME","Benvenuto,");
	define("WELCOME_ASK","Cosa facciamo?");
	define("MAIN_MENU","Menu principale");
	define("START","Inizio");
	define("DASHBOARD","Scrivania");
	define("EMAIL_ADRESSES","Indirizzi email");
	define("MENU_RECIPIENT_LIST","Elenco dei destinatari");
	define("MENU_ADD_RECIPIENT","Aggiungere il destinatario");
	define("MENU_CSV_IMPORT","Importare messaggi di posta elettronica da un file CSV");
	define("MENU_CSV_EXPORT","E-mail esporta in un file CSV");
	define("MENU_TAG_LIST","Lista etichetta");
	define("MENU_ADD_TAGS","Aggiungere etichette");
	define("MENU_SENDERS_LIST","Lista mittenti");
	define("MENU_ADD_SENDER","Aggiungi mittente");
	define("MENU_TEMPLATES","Layout e-mail");
	define("MENU_TEMPLATES_LIST","Nell'elenco modelli");
	define("MENU_TEMPLATES_ADD","Aggiungere nuovo modello");
	define("MENU_TEMPLATES_ATTACHMENTS","Allegati");
    define("MENU_TEMPLATES_THUMBNAILS","Miniature");
	define("MENU_CAMPAIGNS","Le tue campagne");
	define("MENU_CAMPAIGNS_ADD","Preparare nuova campagna");
	define("MENU_CAMPAIGNS_WAITING_LIST","In attesa campagna di lista");
	define("MENU_CAMPAIGNS_IN_PROGRESS","Campagne in corso");
	define("MENU_CAMPAIGNS_SENT","Elenco inviato campagne");
	define("MENU_SYSTEM_CONFIGURATION","Configurazione di sistema");
	define("MENU_SETTINGS","Impostazioni");
	define("MENU_LOGIN","Accesso");
	define("MENU_DB","Banca dati");
	define("MENU_SYSTEM_PARAMS","Params di sistema");
	define("MENU_SPECIALS","Addons speciali");
	define("MENU_ADDONS","Extra utili");
	define("MENU_CLEAR_DB","Database chiaro");
	define("MENU_IMPORT_TEMPLATES","Modelli di importazione di esempio");
	define("MENU_IMPORT_DATA","Importa i dati del campione");
	define("MENU_FAQ","Q&A");
	define("MENU_ABOUT","Riguardo a noi");
    define("MENU_SMTP_PARAMS","Configurazione SMTP");
    define("MENU_UNSUBSCRIBED","Lista unsubscribers");
    define("MENU_UNSUBSCRIBED_LIST","elenco dei destinatari");
    define("MENU_DOCS","Documentazione");
    define("MENU_SUBSCRIBE_WIDGET","Iscriviti widget di");
    define("MENU_BOUNCED","Controllare rimbalzato mail");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","Base di dati e-mail");
	define("D_EMAIL_ADD_NEW","Aggiungere un nuovo e-mail");
	define("D_EMAIL_TEMPLATES","Modelli di posta elettronica");
	define("D_EMAIL_TEMPLATES_ADD","Aggiungere nuovo modello");
	define("D_EMAIL_SENT","E-mail inviate");
	define("D_EMAIL_EFFICIENCY","Efficienza");
	define("D_EMAIL_UNSUBSCIBERS","Unsubscribed");
	define("D_CAMPAIGNS","Campagne");
	define("D_CAMPAIGNS_ADD","Nuova campagna");
	define("D_CAMPAIGNS_WAITING","Pronto per l'invio");
	define("D_CAMPAIGNS_SENT","Completato");
	define("D_STATISTICS","Statistica");
	define("D_THIS_YEAR","Le vostre campagne pubblicitarie di quest'anno");
	define("D_CHECK_ALL","Seleziona tutto...");
	define("JAN","gen");
	define("FEB","feb");
	define("MAR","mar");
	define("APR","apr");
	define("MAY","mag");
	define("JUN","giu");
	define("JUL","lug");
	define("AUG","aug");
	define("SEP","set");
	define("OCT","ott");
	define("NOV","nov");
	define("DEC","dic");
	define("D_PREPARED_OVERALL","campagne preparate");
	define("D_SENT_OVERALL","inviato");
	define("D_HOW_TO","Come funziona?");
	define("D_HOW_STEP_1_TITLE","1. Base di dati e-mail");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>Aggiungere etichette</a> questo ti aiuterà a trovare i clienti e vi aiuterà a preparare facilmente una campagna pubblicitaria. Il prossimo <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>aggiungere messaggi di posta elettronica</a> per il sistema di database. Puoi anche <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>caricare file CSV</a> con e-mail alla vostra base di dati.");
	define("D_HOW_STEP_2_TITLE","2. Mittenti");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>Aggiungi mittente</a> si può decidere da cui i clienti riceveranno una e-mail.");
	define("D_HOW_STEP_3_TITLE","3. Modelli di posta elettronica");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>Aggiungere template</a> preparare un numero illimitato di modelli, con un numero illimitato di allegati.");
	define("D_HOW_STEP_4_TITLE","4. Campagne pubblicitarie");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>Aggiungi nuova campagna</a> preparare campagne illimitate. <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>Invia campagna</a> in ogni momento.");
	define("D_HOW_STEP_5_TITLE","5. Seguire statistiche");
	define("D_HOW_STEP_5_DESC","Qui si impara che le campagne sono i migliori, come e quando la campagna è stata preparata e quanto viene inviato e qual è la loro efficacia (vale a dire quante persone hanno aperto la tua email e quante persone unsubsrcibed da campagna).");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","Cambiare login");
	define("CHANGE_PASS","Cambia la password");
	define("CLEAR_DATABASE","Database chiaro");
	define("LOGOUT","Fermare");
	define("ABOUT","A proposito di sistema");
	
	/*vertical buttons*/
	define("CONFIG","Configurazione");
	define("CONFIG_TOOLTIP","Configurazione di sistema");
	define("MEDIA_MANAGER","Allegati direttore");
	define("RECIPIENT","Destinatari");
	define("RECIPIENT_TOOLTIP","La gestione e-mail");
	define("RECIPIENT_EDIT","Modificare i dettagli");
	define("RECIPIENT_ADD_NEW","Aggiungere nuova");
	define("MENUS","Gestione menu");
	define("MENUS_TOOLTIP","Menu di configurazione");
	define("TEMPLATES","Modello");
	define("TEMPLATES_TOOLTIP","Modello configurazione");
	define("HELP","Aiuto");
	define("HELP_TOOLTIP","Come funziona");
	
	define("FILE_MANAGEMENT","Attaccamento");
	define("CSV_IMPORT","CSV e-mail file di importazione");
	
	define("PERSON","Persona");
	define("EMAIL","Indirizzo e-mail");
	define("TAGS","Tag");
	define("TAGS_LIST","Lista tag");
	define("TAGS_ADD","Aggiungere nuove tag");
	define("TAGS_ADD_NEW","Tag aggiunta");
	define("TAGS_ADD_EDIT","Edizione tag");
	define("TAGS_NAME","Nome tag");
	define("TAGS_DESCRIPTION","Descrizione");
	define("TAGS_NAME_PLACEHOLDER","inserire il nome tag...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","inserire tag description...");
	define("TAGS_USED","Usato (volte)");
	define("TAGS_INFO","Tag per una e-mail");
	
	define("RECIPIENT_LIST","Mailing list");
	define("RECIPIENT_NAME","Nome destinatario");
	define("RECIPIENT_NAME_PLACEHOLDER","Inserire nome e cognome");
	define("RECIPIENT_MAIL","E-mail");
	define("RECIPIENT_MAIL_PLACEHOLDER","Inserisci l'email");
	define("RECIPIENT_ONLY_TXT","solo messaggi di posta elettronica TXT");
	define("RECIPIENT_DESCRIPTION","Descrizione");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","Descrizione...");
	define("RECIPIENT_DB","La vostra base di dati e-mail");
	define("RECIPIENT_DETAILS_EDIT","Modificare i dettagli del destinatario");
	define("RECIPIENT_DETAILS_ADD","L'aggiunta di nuovo indirizzo email");
	define("RECIPIENT_IMPORT_CSV","Importare e-mail da file CSV");
	define("RECIPIENT_PREPARE_CSV","Preparare un file CSV le seguenti righe");
	define("RECIPIENT_UPLOAD_CSV_TITLE","Per aggiungere nuovi record formano un file di Excel si dovrebbe seguire la procedura");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","Scarica modello CSV");

	define("RECIPIENT_UPLOAD_CSV_NAME","Importa file CSV");
	define("RECIPIENT_NOT_CSV","<b>questo non è un file CSV!!!</b><br/>");
	define("RECIPIENT_ROW","Riga ");
	define("RECIPIENT_WRONG_EMAIL"," - indirizzo e-mail errato, entrato: ");
	define("RECIPIENT_EMAIL_EXIST"," - questo indirizzo è già nel database: ");
	define("RECIPIENT_EMAIL_LACK"," - la mancanza di un indirizzo e-mail");
	define("RECIPIENT_EMAIL_IN_DB"," - questo indirizzo e-mail è già presente nel file CSV in fila ");
	define("RECIPIENT_TAG_NOT_EXIST"," - tale tag: ");
	define("RECIPIENT_CSV_ERRORS","Gli errori nel file ");
	define("RECIPIENT_CSV_ADDED","Aggiunto ");
	define("RECIPIENT_CSV_ADDED_FROM"," Indirizzi e-mail da file ");
	define("RECIPIENT_CSV_EXPORT","Indirizzi di posta elettronica Esporta in un file");
	define("RECIPIENT_CSV_EXPORT_CHK","Selezionare i campi da esportare:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","Indirizzo e-mail del destinatario");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","Nome e cognome");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","Tag - separate da un singolo spazio");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","Commenti");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","Ricevere e-mail di solo testo");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","Data di introduzione");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","Data di modifica");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","esportare");
	define("RECIPIENT_CSV_IGNORE_ERRORS","Ignora CSV errori di controllo (verificare se il file contiene più di 1000 messaggi di posta elettronica - file più grandi richiedono una grande quantità di memoria sul server)");
	
	define("SAVE","Salvare");
	define("CANCEL","Annulla");
	define("DELETE","Cancellare");
    define("EDIT","Modifica");
	define("CREATED","Creato");
	define("MODIFIED","Modificata");
	define("SEND","Inviare");
	define("SENT","Inviato");
	define("PROGRESS","Progresso");
	define("RESUME","Ripresa");
	define("CLOSE","Vicino");
	define("CHANGES_SAVED","Le modifiche sono state fatte con successo");
	
	define("DELETING","Eliminazione");
	define("DELETING_CONFIRM_QUESTION","Sei sicuro di voler rimuovere?");
	
	define("DATATABLE_LENGTHMENU", "record di visualizzazione _MENU_ per pagina");
	define("DATATABLE_ZERORECORDS", "Non abbiamo trovato nulla - mi dispiace");
	define("DATATABLE_INFO", "Questa è la pagina _PAGE_ di _PAGES_");
	define("DATATABLE_INFOEMPTY", "No records disponibili");
	define("DATATABLE_INFOFILTERED", "(_TOTAL_ Filtrato da _MAX_ record totali)");
	define("DATATABLE_SEARCH", "Ricerca");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "Aggiungere nuovo modello");
	define("TEMPLATES_LIST", "Nell'elenco modelli");
	define("TEMPLATES_TITLE", "Modelli disponibili");
	define("TEMPLATES_TITLE_ADD", "Aggiungere nuovo layout");
	define("TEMPLATES_TITLE_EDIT", "Modifica layout");
	define("TEMPLATES_NAME", "Nome del layout");
	define("TEMPLATES_MAIL_TITLE", "Titolo e-mail");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "Inserisci il titolo e-mail");
	define("TMPLATES_HTML", "Versione HTML");
	define("TMPLATES_TXT", "Versione TESTO");
	define("TMPLATES_VARIABLES", "Variabili di template disponibili (dai un'occhiata <a href='docs/index.html#variables' target='_blank'>documenti</a> per dettagli):");
	define("TEMPLATES_THUMB", "Miniature");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "Editing miniature");
	define("THUMBNAIL_MEDIA_LIST", "Lista miniature disponibili");
	
	define("MEDIA_FILENAME", "Nome del file");
	define("MEDIA_FILENAME_DESCRIPTION", "Descrizione del File");
	define("MEDIA_FILENAME_UPLOAD_TIME", "Carica tempo");
	define("MEDIA_TEMPLATES", "Usato come un allegato");
	define("MEDIA_LIST", "Lista attaccamento Disponibile");
	define("MEDIA_ADD_FILES", "Aggiungere i file");
	define("MEDIA_BROWSE", "Navigare");
	define("MEDIA_UPLOAD", "Caricare");
	
	define("CAMPAIGN_MENU", "Nuova campagna");
	define("CAMPAIGN_PREPARE", "Preparare la campagna");
	define("CAMPAIGN_RECIPIENTS", "Scegli i destinatari");
	define("CAMPAIGN_TEMPLATES", "Scegli il layout");
	define("CAMPAIGN_SENDERS", "Scegli mittente");
	define("CAMPAIGN_CONFIRM", "Salva campagna");
	define("CAMPAIGN_SEND", "Invia campagna");
	define("CAMPAIGN_NAME", "Nome della campagna");
	define("CAMPAIGN_NAME_PLACEHOLDER", "Inserire nome della campagna");
	define("CAMPAIGN_RECIPIENT_QTY", "Destinatari");
	define("CAMPAIGN_TEMPLATE_NAME", "Layout");
	define("CAMPAIGN_SENDER", "Mittente");
	define("CAMPAIGN_CREATED_DATE", "Preparato");
	define("CAMPAIGN_STEP_1", "1. Selezionare i destinatari (uso 'ricerca' campo sopra il tavolo)");
	define("CAMPAIGN_STEP_2", "2. Salvare la campagna di");
	define("CAMPAIGN_SELECT", "Selezionare la campagna per la spedizione");
	define("CAMPAIGN_FORM_SELECT", "selezionare...");
	define("CAMPAIGN_CURRENT_STATUS", "Stato della campagna in corso");
	define("CAMPAIGN_SENT_NOW", "Mandalo ora");
	define("CAMPAIGN_SENT_BUTTON", "Clicca qui per iniziare a inviare");
	define("CAMPAIGN_RESUME_BUTTON", "Clicca qui per riprendere l'invio");
	define("CAMPAIGN_SERVER_CONNECTING", "connessione al server, attendere prego...");
	define("CAMPAIGN_SENDING", "invio");
	define("CAMPAIGN_PLEASE_WAIT", "attendere prego...");
	define("CAMPAIGN_SENT", "<b>Mailing inviato</b> destinatari: ");
	define("CAMPAIGN_IN_PROGRESS", "Campagne in corso...");
	define("CAMPAIGN_COMPLETED", "campagne inviati");
	define("CAMPAIGN_LEFT", "Da sinistra a trasmettere");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "Elimina tutto rimosso");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "Questa azione cancellerà tutte le email rimosse dal database.");
	define("CAMPAIGN_BG_PROCESS", "Processo in background");
	define("CAMPAIGN_BG_PROCESS_INFO", "Invia come un processo in background (si può chiudere il browser)");
	define("CAMPAIGN_WHEN_FINISH", "e-mail una volta terminato");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "dove inviare la notifica");
	define("CAMPAIGN_BG_CONFIRM_TXT", "Si prega di confermare l\'invio di sfondo!");
    
    define("HOUR", "ora");
    define("OPENS", "Si apre");
    define("BOUNCED", "Rimbalzo");
    define("CLICKED", "Cliccato");
    define("UNIQUE_CLICKS", "Scatti unici");
    define("TOTAL_CLICKS", "Clic totali");
	
	define("SENDER_LIST", "Lista mittenti");
	define("SENDER_ADD", "Aggiungi mittente");
	define("SENDER_NAME", "Nome del mittente");
	define("SENDER_NAME_PLACEHOLDER", "Inserire il nome del mittente");
	define("SENDER_EMAIL", "E-mail del mittente");
	define("SENDER_EMAIL_PLACEHOLDER", "Inserisci e-mail del mittente");
	define("SENDER_TITLE_ADD", "Aggiungi mittente");
	define("SENDER_TITLE_EDIT", "Modifica mittente");
	define("SENDER_EMAIL_TITLE", "Indirizzo e-mail del mittente");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "Inserisci indirizzo e-mail del mittente");
	
	define("SETTINGS", "Impostazioni");
	define("SETTINGS_LOGIN_TITLE", "Inserire nuove credenziali");
	define("SETTINGS_LOGIN_LABEL", "Inserisci nuovo login");
	define("SETTINGS_LOGIN_PLACEHOLDER", "Inserire nome utente");
	define("SETTINGS_CURR_PASS", "Password attuale");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "inserire la password");
	define("SETTINGS_NEW_PASS", "Nuova password");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "Nuova password");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "confermare");
	define("SETTINGS_DB_PARAMS", "Impostazione del database");
	define("SETTINGS_DB_HOST", "host del database");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "esempio localhost");
	define("SETTINGS_DB_USER", "Utente del database");
	define("SETTINGS_DB_USER_PLACEHOLDER", "esempio root");
	define("SETTINGS_DB_PASSWORD", "La password del database");
	define("SETTINGS_DB_NAME", "Nome del database");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "esempio mailing");
	define("SETTINGS_GLOBAL", "Impostazioni globali");
	define("SETTINGS_LANG", "La lingua del sistema");
	define("SETTINGS_LIMIT", "limite di e-mail Impostazione all'ora");
	define("SETTINGS_LIMIT_PLACEHOLDER", "predefinito: 1000");
	define("SETTINGS_TRACKING", "Attiva il monitoraggio e-mail");
	define("SENDING_METHOD", "Metodo di invio");
	define("SETTINGS_UNSUBSCRIBED", "Auto cancellare messaggi di posta elettronica rimossi");
	define("SETTINGS_UNS_INFO", "e-mail verrà automaticamente eliminato dalla lista dei destinatari quando l'utente clicca il tuo link rimuovere me");
	define("SETTINGS_TRACK_INFO", "tag img invisibile verrà aggiunto per monitorare il destinatario");
	define("SETTINGS_API_LABEL", "Google maps<br>chiave API");
	define("SETTINGS_API_PLACEHOLDER", "inserire il codice v.3 API google maps qui");
	define("SETTINGS_API_LINK_INFO", "clicca qui per ottenere la nuova chiave API");
	define("SETTINGS_ADMIN_MAIL", "mail Admin");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "e-mail di amministrazione per le notifiche di sistema");
    define("SETTINGS_PHP_TIMEOUT", "timeout PHP (secondi)");
    
	define("SMTP_SERVER_DESCRIPTION", "SMTP Server, assicurarsi di aggiungere un po '");
    define("SMTP_LIST", "elenco dei server");
    define("SMTP_ADD", "L'aggiunta di nuovo server");
    define("SMTP_EDIT", "server di editing");
    define("SMTP_INFO", "I server SMTP");
    define("SMTP_ADD_BUTTON", "Fai clic per aggiungere nuovi server SMTP");
    define("SMTP_NAME", "Nome connessione");
    define("SMTP_NAME_PLACEHOLDER", "esempio my best connection");
    define("SMTP_HOST", "Indirizzo SMTP");
    define("SMTP_HOST_PLACEHOLDER", "Del server principale e di backup (separatore ';' per il backup)");
    define("SMTP_PAUTH", "Autenticazione");
    define("SMTP_PAUTH_PLACEHOLDER", "Abilitare l'autenticazione SMTP");
    define("SMTP_VERIFY_PEER", "Attiva SSL / TLS verifica del certificato");
    define("SMTP_FORCE_SMTP", "L'uso della forza SMTP");
    define("SMTP_USERNAME", "Nome utente SMTP");
    define("SMTP_USERNAME_PLACEHOLDER", "Nome utente SMTP");
    define("SMTP_LOGIN", "Login SMTP");
    define("SMTP_LOGIN_PLACEHOLDER", "accesso al server SMTP");
    define("SMTP_PASSWORD", "Password SMTP");
    define("SMTP_PASSWORD_PLACEHOLDER", "Password SMTP");
    define("SMTP_REPLYTO", "Rispondere alla posta");
    define("SMTP_REPLYTO_PLACEHOLDER", "Impostare un'alternativa indirizzo di risposta");
    define("SMTP_REPLYTONAME", "Rispondi a nome");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "Impostare un'alternativa risposta a nome");
    define("SMTP_SECURE", "Crittografia");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> come crittografia predefinita");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> accettato ma non è raccomandato");
    define("SMTP_PORT", "Porto");
    define("SMTP_PORT_PLACEHOLDER", "porta del server");
    define("SMTP_LIMIT", "Limite all'ora");
    define("SMTP_LIMIT_PLACEHOLDER", "predefinito: 1000");
    define("CAMPAIGN_SMTP", "Selezionare SMTP");
    define("SMTP_TESTING", "Verifica della connessione SMTP");
    define("SMTP_TESTING_EMAIL", "Indirizzo per il messaggio di prova");
    define("SMTP_RUN_TEST", "Controllalo!");
    define("SMTP_TEST_TXT_TITLE", "test SMTP da E-mailer.");
    define("SMTP_TEST_TXT_MESSAGE", "Messaggio di prova dalla connessione SMTP.");
    define("SMTP_TEST_OK", "Il messaggio è stato inviato. Controlla la tua casella di posta.");
    define("SMTP_TEST_ERROR", "<b>Errore Mailer: </b>");
    define("SMTP_BEFORE_USE", "<b>Errore Mailer.</b> È necessario attivare la connessione SMTP nelle impostazioni prima dell'uso.");
    define("BOUNCED_INFO", "Email rimbalzato sosterranno a quella cassetta postale");
    define("SMTP_CONFIG", "Imposta il tuo SMTP per l'invio");
    define("IMAP_CONFIG", "Imposta il tuo IMAP / POP3 per rimbalzi");
    define("SMTP_INFO_SETUP", "Impostazioni SMTP");
    define("IMAP_INFO_SETUP", "Impostazioni IMAP / POP3");
    define("PROTOCOL", "Protocollo");
    define("FOLDER", "Cartella per l'accesso");
	
	define("STATISTICS", "Statistica");
	define("STATISTICS_ADV", "Dettagli avanzati");
	define("STATISTICS_TAB_MAP", "I destinatari sulla mappa (geolocalizzazione)");
	define("STATISTICS_TAB_DETAILS", "Statistiche dettagliate");
	define("STATISTICS_TAB_ACTIONS", "Le azioni speciali");
	define("STATISTICS_BACK", "Torna alla lista");
	define("STATISTICS_BUTTON_OPENERS", "Preparati per apriscatole");
	define("STATISTICS_BUTTON_OPENERS_INFO", "Preparare nuova campagna per tutti coloro che hanno aperto una e-mail");
	define("STATISTICS_BUTTON_NOT_OPENERS", "Preparati per NON apri");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "Preparare nuova campagna per tutti coloro che non ha aperto una e-mail");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "Preparati per sottoscritte");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "Preparare nuova campagna per tutti unsubscribers, se un'opzione 'Auto eliminare sottoscritte' nelle impostazioni di sistema è attivato, messaggi di posta elettronica vengono eliminati e non saranno aggiungono qui");
	define("STATISTICS_BUTTON_FILTERS", "Preparare con filtri avanzati");
	define("STATISTICS_BUTTON_FILTERS_INFO", "Ottenere l'elenco di tutti i destinatari di questa campagna con i dati raccolti e preparare nuova campagna speciale in base a filtri avanzati");
	define("STATISTICS_TOP_COUNTRIES", "Superiore 10 Paesi");
	define("STATISTICS_TOP_CITIES", "Superiore 10 delle città");
	define("STATISTICS_TOP_CLICKERS", "Superiore 15 clicker");
	define("STATISTICS_TOP_SOFTWARE", "Superiore 15 più popolare software");
	define("STATISTICS_OTHER_UA", "Tutti gli agenti gli altri utenti");
	define("STATISTICS_OTHERS", "Altri");
    
	define("SOFTWARE", "Software");
	define("GEODATA", "Localizzazione");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='conferma'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>Con successo cancellato dalla newsletter.</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>Buona giornata.</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "Rimozione di dati non necessari dal database");
	define("ADDONS_IMPORT_TITLE", "L'aggiunta di modelli di esempio mailing");
	define("ADDONS_FAQ_TITLE", "Leggere prima di chiedere");
	define("ADDONS_ABOUT_TITLE", "Informazioni sul programma e la licenza");
	define("ADDONS_IMPORT_DATA_TITLE", "Importa i dati di esempio al sistema");
	define("ADDONS_IMPORT_BUTTON", "Modelli di importazione e-mail");
	define("ADDONS_IMPORT_BUTTON_DESC", "Questo importerà modelli di esempio per l'invio");
	define("ADDONS_IMPORT_CONFIRM_TXT", "Confermare l'aggiunta di esempi di modelli per la spedizione");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "Confermare l'aggiunta di dati di esempio al sistema. Tutti i dati attualmente inseriti saranno cancellati!");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>Perché è meglio avere un proprio server dedicato per la spedizione?</p>
			<p>Prima di tutto, senza limiti. Per l'hosting ordinaria, è possibile inviare fino a 1.000 e-mail all'ora e probabilmente la stessa quantità entro un giorno (a seconda dei limiti di hosting vanno da poche centinaia a qualche migliaio di mail al giorno). Sul server, non avere tali restrizioni e hanno anche la possibilità di inviare messaggi di posta elettronica dal proprio dominio. È inoltre possibile inviare e-mail come se il server è stato quello di essere sotto un dominio diverso (è in questo caso impostare i cosiddetti record SPF e TXT dominio - per i dettagli chiedete al vostro fornitore di hosting).</p>
		</li>
		<li>
			<p>Cosa sono i tag?</p>
			<p>Rendere più facile da trovare indirizzi postali e la preparazione di una campagna pubblicitaria a uno specifico destinatario.</p>
		</li>
		<li>
			<p>Come aggiungere il nome del destinatario per modello e-mail?</p>
			<p>Utilizzare frase {RECIPIENT_NAME} nella e-mail modello contenuto o nel titolo del messaggio modello. La frase sarà sostituito dal nome della posta elettronica del destinatario, nel caso in cui l'informazione è stata aggiunta indirizzo di posta elettronica del destinatario.</p>
		</li>
		<li>
			<p>Come aggiungere una nuova traduzione?</p>
			<p>Copiare il file di english.php di riferimento, dargli un nome che descrive la lingua per esempio mylanguage.php e incollarlo nella stessa cartella. Correggere tutti i testi contenuti nel nuovo file. Assicurarsi di salvare il file in formato UTF-8 w / o BOM. Il file della lingua si trova nella directory 'languages'.</p>
			<p>Per aggiungere traduzione di editor WYSIWYG, andare a https://www.tinymce.com/download/language-packages/ - scaricare file appropriato linguaggio e salvarlo in /emailer/libs/tinymce/langs/ cartella.</p>
		</li>
		<li>
			<p>Come faccio ad aggiungere i tag di una e-mail?</p>
			<p>In primo luogo, è necessario aggiungere alcuni tag <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>utilizzando questo modulo</a>. Poi, quando si aggiungere / modificare ogni indirizzo e-mail può essere assegnato a qualsiasi tag. saranno aggiunti tutti i tag sotto forma di aggiungere / modificare i destinatari.</p>
		</li>
		<li>
			<p>Come aggiungere la possibilità di annullare l'iscrizione di non ricevere messaggi?</p>
			<p>Utilizzare frase {UNSUBSCRIBE} nel link nel contenuto modello e-mail. La frase sarà sostituito con un link per il destinatario particullar. Quando lui / lei sarà clic su di esso, il sistema salverà le informazioni database riguardo la scarica della campagna. L'indirizzo email non verrà rimosso dal database. <br>Uso:<br>&lt;a href='{UNSUBSCRIBE}'&gt;cancellarti dalla newsletter&lt;/a&gt;</p>
		</li>
		<li>
			<p>Come aggiungere la possibilità di vista del browser?</p>
			<p>Utilizzare frase {BROWSER_VIEW} nel link nel contenuto modello e-mail. La frase sarà sostituito con un link per il destinatario particullar. Quando lui / lei sarà clic su di esso, il sistema aprirà messaggio nella finestra del browser. <br>Uso:<br>&lt;a href='{BROWSER_VIEW}'&gt;vista del browser&lt;/a&gt;</p>
		</li>
		<li>
			<p>Come aggiungere modelli e-mail predefiniti?</p>
			<p>30 modelli di esempio mailing, clicca qui <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>per aggiungere modelli</a></p>
		</li>
		<li>
			<p>Come posso aggiungere immagini alle e-mail?</p>
			<p>- Come un collegamento assoluto a un'immagine in risorse esterne, quali:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>Come funziona il monitoraggio delle e-mail?</p>
			<p>Per ogni sistema di posta elettronica inviata in grado di aggiungere un tag di immagine IMG, che attributo src contiene il codice di monitoraggio per visualizzare un messaggio specifico. Monitoraggio funziona solo quando il destinatario di posta accetta di mostrare le immagini del messaggio ricevuto.</p>
		</li>
		<li>
			<p>Come non essere uno spammer?</p>
			<p>- Raccogliere il consenso a ricevere messaggi durante la creazione di una mailing list.</p>
			<p>- Utilizzare una varietà di contenuti per ogni destinatario, utilizzare es. {RECIPIENT_NAME} per differenziare checksum di tua mailing.</p>
			<p>- Non utilizzare le parole chiave come: il sesso, viagra, porno.</p>
			<p>- Non usare frasi chiave quali: l'indirizzo da una banca dati pubblica, non è informazione commerciale in mente, disinteressato Ci dispiace ma non costituisce un'offerta ai sensi se non si desidera, fare clic qui per annullare l'iscrizione, gratuita, offerta speciale, compralo subito - se si deve usare questo tali frasi si dovrebbe considerare di mettere loro sotto forma di grafico.</p>
			<p>- Non usare troppo molti elementi grafici, filtri anti-spam esaminare il rapporto della grafica in testo.</p>
			<p>- Mail non dovrebbe essere troppo pesante.</p>
			<p>- Il minor numero di allegati il migliore.</p>
			<p>- Non impersonare un altro dominio.</p>
			<p>- Non inviare messaggi di posta elettronica dall'indirizzo email inesistente.</p>
		</li>
		<li>
			<p>Come aumentare i clic e legge campagna?</p>
			<p>La più grande influenza sul contenuto che trasmettete ai vostri clienti e il tempo e la frequenza con cui lo fate. Nella maggior parte dei casi, il contatto non deve essere più frequente di due volte al mese. Rispetta i tuoi clienti e che non si getteranno al di spam.</p>
		</li>
		<li>
			<p>Come scegliere gli indirizzi per l'invio?</p>
			<p>L'uso dei nomi, digitare loro separate da spazi nel campo di ricerca sopra la tabella degli indirizzi.</p>
		</li>
		<li>
			<p>Quali sono i limiti di questo sistema?</p>
			<p>Non ci sono restrizioni.</p>
		</li>
		<li>
			<p>Limitare i messaggi sul server di hosting?</p>
			<p>A seconda dei limiti di hosting variare da poche centinaia a qualche migliaio di email al giorno, verificare con il fornitore di servizi.</p>
		</li>
		<li>
			<p>Connessione interrotta durante l'invio di campagna?</p>
			<p>È possibile riprendere l'invio di campagne, e-mail saranno inviati agli altri destinatari. Ogni email inviata imposta un indicatore univoco nel database e la campagna stessa non verrà nuovamente inviata allo stesso destinatario.</p>
		</li>
		<li>
			<p>Requisiti per le email rimbalzato</p>
			<p>Per abilitare il supporto per le email rimbalzati bisogna togliere il commento di questa linea nel file php.ini.</p>
			<p>;extension=php_imap.dll</p>
			<p>Funzioni imap sono tenuti a utilizzare le connessioni POP3 / IMAP.</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "Essere attentamente, le seguenti azioni tavole pulite nel database!");
	define("ADDONS_DATA_BE_CAREFULLY", "Avvertimento! Tutti i dati saranno cancellati e sostituiti con i dati di esempio");
	define("ADDONS_D_AL", "Elimina tutti i dati");
	define("ADDONS_D_AL_DESC", "Cancella tutti i dati nel database");
	define("ADDONS_D_AL_CONF", "Sei sicuro di voler rimuovere tutti i dati dal database? Saranno eliminati tutti gli indirizzi email, i modelli, gli allegati e le campagne.");
	define("ADDONS_D_RE", "Rimuovere i destinatari e le loro campagne");
	define("ADDONS_D_RE_DESC", "Elimina tutti gli indirizzi e-mail presenti nel database e la storia di campagne pubblicitarie");
	define("ADDONS_D_RE_CONF", "Confermare la rimozione di tutti i destinatari");
	define("ADDONS_D_CA", "Eliminare solo le campagne");
	define("ADDONS_D_CA_DESC", "Elimina tutte le campagne pubblicitarie e la loro storia");
	define("ADDONS_D_CA_CONF", "Confermare la rimozione di tutte le campagne e la loro storia");
	define("ADDONS_D_TE", "Rimuovere solo i modelli");
	define("ADDONS_D_TE_DESC", "Elimina tutti i modelli di posta elettronica ed i loro legami con le campagne e gli allegati");
	define("ADDONS_D_TE_CONF", "Confermare l'eliminazione di tutti i modelli");
	define("ADDONS_D_AT", "Eliminare solo gli allegati");
	define("ADDONS_D_AT_DESC", "Elimina tutti gli allegati");
	define("ADDONS_D_AT_CONF", "Conferma eliminazione di tutti gli allegati");
	define("ADDONS_D_SE", "Eliminare solo i mittenti");
	define("ADDONS_D_SE_DESC", "Elimina tutti i mittenti di posta elettronica inserito, ma lascia la loro identificazione per fini statistici");
	define("ADDONS_D_SE_CONF", "Confermare la rimozione di tutti i mittenti");
	define("ADDONS_D_TG", "Eliminare solo tag");
	define("ADDONS_D_TG_DESC", "Cancellare tutti i tag inseriti e le loro relazioni con i clienti");
	define("ADDONS_D_TG_CONF", "Conferma rimuovere tutti i tag");
    
	define("WIDGET_PREPARE", "Preparare il widget di abbonamento");
	define("WIDGET_OPTIONS", "Opzioni");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "Genera il tuo widget iscrizione qui");
	define("WIDGET_COMMENT", "Commento su nuovo destinatario");
	define("WIDGET_COMMENT_PLACEHOLDER", "esempio da parte di domain.ext (saranno salvati nella descrizione del destinatario)");
	define("WIDGET_NAME", "Nome");
	define("WIDGET_NAME_SHOW", "Campo Mostra nome del destinatario");
	define("WIDGET_AFTER", "Dopo presentare widget di abbonamento");
	define("WIDGET_AFTER_NOTHING", "fare niente");
	define("WIDGET_AFTER_TXT", "mostrare un messaggio di testo");
	define("WIDGET_AFTER_REDIRECT", "reindirizzamento alla pagina");
	define("WIDGET_TAGS", "Aggiungere etichette");
	define("WIDGET_PURE_CODE_TXT", "Il codice HTML puro. È possibile modificare alle proprie esigenze. Aggiungere le classi, tag, descrizioni, quello che volete. Copia il codice qui sotto e incollalo nel tuo sito web.");
	define("WIDGET_FULL_CODE_TXT", "La versione completa (tutti i campi inclusi)");
	define("WIDGET_MIN_CODE_TXT", "Versione ridotta (solo e-mail incluso)");
	define("WIDGET_CODE_DESC_TXT", "Descrizione modulo");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> richiesto.</li>
        <li>Indirizzo e-mail di abbonati.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> facoltativo.</li>
        <li>Nome del sottoscrittore.</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> facoltativo.</li>
        <li>Campo nascosto.</li>
        <li>Devono già essere aggiunti al database.</li>
        <li>Essi devono essere separati da una virgola.</li>
        <li>Utilizzando diversi tag è possibile effettuare diverse campagne.</li>
        <li>È possibile utilizzare lo stesso modulo a diversi siti e utilizzare diversi tag su ogni sito.</li>
        <li>Significa che questa componente in grado di raccogliere gli abbonati da diversi siti e aggiungerli al vostro sistema con diversi tag.</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> facoltativo.</li>
        <li>Campo nascosto.</li>
        <li>Aggiungi la tua descrizione per il destinatario.</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> facoltativo.</li>
        <li>Campo nascosto.</li>
        <li>Aggiungi la tua descrizione per il destinatario.</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> facoltativo.</li>
        <li>Campo nascosto.</li>
        <li>Aggiungi la tua descrizione per il destinatario.</li>
    ");
	define("WIDGET_USE_THIS_CODE", "Copia il codice qui sotto e incollalo sul tuo sito");
	define("WIDGET_DBL_OPT_IN", "Double opt-in");
	define("WIDGET_DBL_OPT_LABEL", "controllare di utilizzare la conferma doppia iscrizione");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "Messaggio e-mail (supporto HTML)");
	define("WIDGET_DBL_OPT_HELP", "Non dimenticate di aggiungere <b>{CONFIRM_LINK}</b> nel messaggio.<br>È inoltre possibile aggiungere:<br><b>{SUBSCRIBER_EMAIL}</b> - indirizzo di posta elettronica dell'abbonato<br><b>{SUBSCRIBER_NAME}</b> - nome abbonato<br><b>{SUBSCRIBER_COMMENT}</b> - i suoi commenti su abbonato<br><b>{SUBSCRIBER_TAGS}</b> - tag utilizzati<br><b>{CURRENT_YEAR}</b> - anno corrente<br><b>{CURRENT_MONTH}</b> - corrente mese<br><b>{CURRENT_DAY}</b> - giorno corrente");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "Titolo e-mail");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "entrare email titolo di conferma...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "entrare e-mail messaggio di conferma...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "Redirect a dopo la conferma");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "inserire l'indirizzo dove reindirizzare dopo la conferma");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "Invia dall'indirizzo");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "inserire l'indirizzo email da cui sarà inviata la conferma");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "Descrizione mittente");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "entrare descrizione per mittente");
	define("WIDGET_ADMIN_NOTIFY", "Notifica di amministrazione su nuovo abbonato");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "controllo per inviare notifiche e-mail dopo la nuova sottoscrizione ricevuto. <br><br><b>ATTENZIONE!</b> e-mail amministratore deve essere configurato in params di sistema!");
	define("WIDGET_ADMIN_LABEL_EMAIL", "Messaggio di Admin (supporto HTML)");
	define("WIDGET_ADMIN_HELP", "Può essere utilizzato nel tuo messaggio:<br><b>{SUBSCRIBER_EMAIL}</b> - indirizzo di posta elettronica dell'abbonato<br><b>{SUBSCRIBER_NAME}</b> - nome abbonato<br><b>{SUBSCRIBER_COMMENT}</b> - i suoi commenti su abbonato<br><b>{SUBSCRIBER_TAGS}</b> - tag utilizzati<br><b>{CURRENT_YEAR}</b> - anno corrente<br><b>{CURRENT_MONTH}</b> - corrente mese<br><b>{CURRENT_DAY}</b> - giorno corrente");
    define("WIDGET_ERROR_MESSAGE_LABEL", "Messaggio di errore del server in caso di indirizzo email sbagliato abbonati");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "Scegli il server");
	define("BOUNCED_DEL_EMAILS", "Elimina automaticamente dalla lista dei destinatari");
	define("BOUNCED_DEL_MESSAGES", "Eliminare automaticamente i messaggi rimbalzati tutti e controllato da server");
	define("BOUNCED_MAX", "limite massimo messaggi");
	define("BOUNCED_AT_TIME", "Di verificare in una sola volta");
	define("BOUNCED_START", "Controllare la cassetta postale per le email rimbalzati");
	
	define("YES", "Sì");
	define("NO", "No");
	define("DATA_ERROR", "Errore: i dati richiesti non esisteranno...<br><br><a href='index.php'>clicca qui per aprire cruscotto</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "Il server di inviare posta per widget di abbonamento");
    define("TESTING_TEMPLATE", "Modello di prova");
    define("TESTING_TEMPLATE_INFO", "Invia il modello per l'e-mail inserito in basso. Le variabili non verranno sostituiti.");
    define("TESTING_CHOOSE_SERVER", "Selezionare l'invio del server");
    define("ERRORS", "Errori");
    define("TEST", "Testare!");
    
    /*v.1.16*/
    define("COPY", "Copia");
    define("COPYING", "Cimasa");
    define("CHECK", "Dai un'occhiata");
    define("DATA_VERIFY", "Controllo dell'integrità dei dati");
    define("DATA_VERIFY_QUESTION", "Sei sicuro che si desidera verificare l'integrità dei dati?");
    define("DATA_VERIFY_DESCRIPTION", "Questa operazione può richiedere diversi minuti, dipende dalla quantità di dati nel database. <br> farlo se si è certi che la campagna era finita e non è visibile in questa lista.");
    define("DATA_VERIFY_BUTTON", "Verificare l'integrità dei dati");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "Filtra i destinatari dai tag selezionati (OR&nbsp;query)");
    define("REC_QUERY_AND", "Filtra i destinatari in TUTTI i tag selezionati (AND&nbsp;query)");
    define("REC_RESET", "Reimposta query");
    define("REC_BUTTON_DELETE", "Elimina destinatari");
    define("CSV_ST_1", "Preparare i dati in base alla formula:");
    define("CSV_COL_NO", "numero di colonna");
    define("CSV_REQ", "necessario");
    define("CSV_OPT", "opzionale");
    define("CSV_ADDR", "indirizzo email");
    define("CSV_NAME", "nome e cognome");
    define("CSV_TAGS", "tag");
    define("CSV_TAGSDESC", "deve essere nel database deve essere separato da un singolo spazio");
    define("CSV_COMMENT", "Commenti");
    define("CSV_DESC1", "Salva il foglio di lavoro come CSV");
    define("CSV_DESC2", "delimitatore");
    define("CSV_MAXLINE", "lunghezza massima della linea CSV");
    define("CSV_FORMDESC", "Carica un file CSV preparato utilizzando il modulo sottostante");
    define("DISABLE_EDITOR", "Disattiva editor");
    define("ENABLE_EDITOR", "Abilita editor");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "Importa e-mail dal ponte DB");
    define("TITLE_IMPORT", "Importazione dei destinatari");
    define("SUBTITLE_IMPORT", "ponte del database - parametri sorgente");
    define("LIST_TITLE_IMPORT", "Importa destinatari da altri database");
    define("ADD_NEW_BRIDGE", "Aggiungi un nuovo ponte");
    define("IMPORT_RECIPIENTS", "Importa destinatari");
    define("IMPORT_BRIDGE_DESC", "Importa descrizione del ponte");
    define("CONFIRM_BRIDGE_DEL", "Eliminazione della connessione bridge del database");
    define("IMPORTING_BRIDGE_REC", "Importare i destinatari");
    define("CHOOSEN_BRIDGE", "Ponte scelto per l'importazione");
    
    define("FORM_BRIDGE_DESC", "Importa descrizione del ponte");
    define("BRIDGE_TABLE", "Nome della tabella di origine");
    define("BRIDGE_COL_NAME", "Colonna di origine per il nome del destinatario");
    define("BRIDGE_COL_NAME_INFO", "verrà importato nel campo Nome destinatario");
    define("BRIDGE_COL_MAIL", "Colonna sorgente per l'indirizzo email");
    define("BRIDGE_COL_MAIL_INFO", "sarà importato nel campo Email");
    define("BRIDGE_COL_DESC", "Colonna sorgente per la descrizione del destinatario");
    define("BRIDGE_COL_DESC_INFO", "sarà importato nel campo Descrizione");
    define("BRIDGE_CHECK_CON", "Verifica la connessione al database");
    define("BRIDGE_WAITING", "in attesa di test...");
    define("BRIDGE_ADD_NAME", "Nome del destinatario aggiuntivo");
    define("BRIDGE_ADD_NAME_INFO", "verrà aggiunto dopo la colonna del nome di origine");
    define("BRIDGE_ADD_DESC", "Ulteriori descrizione del destinatario");
    define("BRIDGE_ADD_DESC_INFO", "sarà aggiunto dopo la colonna di descrizione del sorgente");
    define("BRIDGE_OVERRIDE", "Sostituisci i destinatari esistenti");
    define("BRIDGE_OVERRIDE_O1", "aggiornamento - destinazione corretta del destinatario in base alla nuova fonte");
    define("BRIDGE_OVERRIDE_O2", "ignora - non fare nulla se il destinatario della destinazione esiste già");
    define("BRIDGE_TAGS", "Tag disponibili");
    define("BRIDGE_FILL_FIELDS", "riempire tutti i campi richiesti prima di testare...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "importazione in corso, attendere prego...");
    define("BRIDGE_TEST_OK", "Il tuo bridge di connessione funziona correttamente");
    define("BRIDGE_IMPORT_OK1", "Importa finito. aggiornato:");
    define("BRIDGE_IMPORT_OK2", " inserito:");
    define("TABLE", "tavolo ");
    define("COLUMN", "Colonna ");
    define("NOT_IN_DB", " non esiste nel database ");
    define("NOT_IN_TABLE", " non esiste nella tabella ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "inserisci la tua chiave API di geolocalizzazione qui");
    define("SETTINGS_API_GEO_LINK_INFO", "clicca qui per ottenere la nuova chiave API di geolocalizzazione");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "Usa https");
    define("HTTPS_USAGE_INFO", "segna se stai usando https, questo genererà tutti i link con https");
    define("TEMPLATE_STATISTICS", "Statistiche dei modelli: ");
    define("TEMPLATE_CHARS", "caratteri chiave: ");
    define("TEMPLATE_USAGE", "usato: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "Token del registro del modulo di abbonamento ");
    define("WIDGET_EMAIL_TOKEN", "Token di registrazione e-mail di sottoscrizione ");
    
    /*v.1.22*/
    define("WEBSITE", "Sito web");
    define("WIDGET_WEBSITE_SHOW", "Mostra il campo dell'URL del destinatario");
    define("VERIFIED", "verificata");
    define("VERIFY", "Verificare");
    define("C_PREPARED", "preparato e in attesa");
    define("C_AJAX_PROGRESS", "invio di posta elettronica in corso");
    define("C_FINISHED", "finito");
    define("C_BG_PROGRESS", "invio in corso");
    define("C_PAUSED", "in pausa");
    define("C_CRON", "cron in corso");
    define("B_VER", "Verifica collettiva");
    define("B_RV", "Verifica dei destinatari collettivi");
    define("B_SEND1", "Sei sicuro di voler inviare");
    define("B_SEND2", "destinatari per la verifica");
    define("B_CHECK_LIST", "controlla gli elenchi di verifica collettiva");
    define("B_VER_INFO", "I tuoi controlli collettivi saranno disponibili sul tuo account emailable.com");
    define("B_VER_IN_PROG", "verifica in corso");
    define("B_VER_SENT", "Destinatari inviati per il controllo di massa");
    define("B_V_TITLE", "Verifica e-mail collettiva");
    define("B_V_TITLE2", "liste inviate");
    define("BUTTON_CHECK_STATUS", "Controllare lo stato");
    define("BUTTON_DOWN_UP", "Scarica e aggiorna");
    define("V_ID", "verifica id");
    define("V_QTY", "quantità da controllare");
    define("V_DATE", "data di invio");
    define("V_MESSAGE", "stato");
    define("V_PERC", "% completare");
    define("V_WORKING", "lavoro");
    define("RESPONSE", "risposta");
    define("V_UPDATED_INFO", "Destinatari aggiornati, verificare i dettagli");
    define("SETTINGS_API_THECHECKER", "clicca qui per ottenere la chiave API emailable.com");
    define("SETTINGS_API_DESCRIPTION", "Lasciamo uccidere i rimbalzi! <br>Utilizzando il pulsante in basso, otterrai <b>30% di CONTROLLI EXTRA GRATUITI</b> nel tuo primo acquisto e riceverai un bonus del 30% (in contanti o assegni) per ogni tuo acquisto effettuato per sempre!");
    define("EC_DATA", "Esporta tutti i dati delle campagne");
    define("EC_DATA1", "Esportare i dati della campagna");
    define("EX_OPENED_BUTTON", "Destinatari che hanno aperto");
    define("EX_OPENED_DESC", "Esportare i destinatari della campagna che hanno aperto la posta elettronica della campagna");
    define("EX_NOT_OPENED_BUTTON", "Destinatari che non hanno aperto");
    define("EX_NOT_OPENED_DESC", "Esportare i destinatari della campagna che NON hanno aperto la posta elettronica della campagna");
    define("EX_UNSUBSRIBED_BUTTON", "Destinatari che hanno annullato l'iscrizione");
    define("EX_UNSUBSRIBED_DESC", "Esportare i destinatari della campagna che hanno annullato l'iscrizione alla campagna");
    define("EX_CLICKED_BUTTON", "Destinatari che hanno fatto clic");
    define("EX_CLICKED_DESC", "Esportare i destinatari della campagna che hanno fatto clic sul collegamento nell'e-mail della campagna");
    define("EX_ALL_BUTTON", "Tutti i dati dei destinatari");
    define("EX_ALL_DESC", "Esportare tutti i dati dei destinatari della campagna corrente");
    define("EX_COUNTRY_BUTTON", "Paesi destinatari");
    define("EX_COUNTRY_DESC", "Esporta tutti i paesi della campagna corrente");
    define("EX_CITY_BUTTON", "Città destinatarie");
    define("EX_CITY_DESC", "Esporta tutte le città della campagna corrente");
    define("EX_BROWSER_BUTTON", "Browser dei destinatari");
    define("EX_BROWSER_DESC", "Esporta tutti i browser della campagna corrente");
    define("SETTINGS_CHARSET", "Imposta il tuo set di caratteri per l'esportazione dei dati");
    define("MENU_BULK", "Verifiche di massa");
    define("B_CONFIRM", "confermare l'eliminazione collettiva da emailable.com ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "Aggiorna destinatari. Se un indirizzo e-mail viene importato nel database, aggiornarlo utilizzando i dati nel file CSV.");
    define("TAGS_MANAGER_TITLE", "Gestione tag destinatari, e-mail selezionate: ");
    define("TAGS_SELECT_ACTION", "Scegli la tua azione:");
    define("TAGS_MANAGER_ADD", "Aggiungi tag ai destinatari selezionati");
    define("TAGS_MANAGER_REMOVE", "Rimuovi i tag dai destinatari selezionati");
    define("TAGS_SELECT", "Seleziona i tuoi tag:");
    define("SAVE_CHANGES", "Salvare le modifiche");
    define("NOT_SELECTED_TAGS", "Seleziona prima i destinatari");
    define("TM_BUTTON", "Gestore di etichette collettive");
    define("WAITING", "inatteso...");
    define("MULTI_SMTP", "Multi SMTP");
    define("MULTI_CHECK_DESC", "controlla, se vuoi usare la funzione di invio multi smtp");
    define("MULTI_CHOOSE", "Scegli server SMTP");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "Lista nera");
    define("BL1", "Elenco di domini e IP non consentiti");
    define("BL2", "indirizzi malevoli bloccati per l'abbonamento");
    define("BL3", "La tua lista nera");
    define("B_VALUE", "Valore");
    define("B_TYPE", "genere");
    define("MENU_ADD_BL", "Aggiungi nuova voce");
    define("B_DOMAIN", "dominio");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "Puoi importare un elenco di indirizzi dannosi nella tua lista nera qui <small>(ogni record deve essere in linea separata)</small>");
    define("B_DELETE_ALL", "Cancella lista nera");
    define("B_DELETE_QUESTION", "Sei sicuro di voler eliminare l'intera lista nera?");
    define("B_EXPORT", "Esporta lista nera");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM impostazioni");
    define("DKIM_USE", "uso DKIM");
    define("DKIM_DOMAIN", "Firma del nome di dominio");
    define("DKIM_PRIVATE", "Percorso del file della chiave privata");
    define("DKIM_SELECTOR", "Di solito la configurazione della chiave di selezione sul record DNS TXT");
    define("DKIM_PASS", "Utilizzato se la tua chiave è crittografata");
    define("DKIM_IDENTITY", "Di solito l'indirizzo e-mail utilizzato come origine dell'e-mail");
    
    define("ERROR", "Errore:");
    define("WARNING", "AVVERTIMENTO!");
    define("D_MODE", "Le modifiche e alcune funzionalità non sono disponibili in modalità DEMO.");
    define("S_DIS", "Invio disabilitato fino a quando non inserisci il codice di acquisto");
    define("HERE", "qui");
    define("PLIK", "file");
    define("NOT_WR", "non è scrivibile. Le impostazioni non verranno salvate. Modificare le autorizzazioni del file prima di salvare.");
    define("EPC", "Codice di acquisto Envato");
    define("EVALIDEPC", "Inserisci un codice di acquisto valido");
    define("NO_ADMIN_MAIL", "Aggiorna prima l'indirizzo email dell'amministratore nelle impostazioni.");
    
    define("SMTP_LABEL", "livello di debug");
    define("SMTP_0", "Disabilita il debug");
    define("SMTP_1", "Messaggi di output inviati dal cliente");
    define("SMTP_2", "come 1, più le risposte ricevute dal server (questa è l'impostazione più utile)");
    define("SMTP_3", "come 2, più ulteriori informazioni sulla connessione iniziale: questo livello può aiutare a diagnosticare gli errori di STARTTLS");
    define("SMTP_4", "come 3, più anche informazioni di livello inferiore, molto prolisse, non utilizzare per il debug di SMTP, solo problemi di basso livello ");
    
    define("SMTP_SENDER_FORCE", "Forza sempre questo mittente nelle campagne per questo server");
    define("SMTP_SENDER_MAIL", "Indirizzo email del mittente");
    define("SMTP_SENDER_DESCRIPTION", "Descrizione del mittente");

    
    
