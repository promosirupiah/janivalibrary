<?php
	/*login page*/
	define("LANG","ja");
	define("LOGIN_TITLE","郵送システム");
	define("LOGIN_SIGN_IN","サインインしてください");
	define("LOGIN","ログイン");
	define("LOGIN_PASS","パスワード");
	define("LOGIN_SIGN_IN_BUTTON","サインイン");
	define("LOGIN_FAILED","間違ったログインやパスワード！");
	define("INSTALLING_SYSTEM","システム構成");
	define("INSTALLING_CONNECTED","データベースに正しく接続されている");
	define("INSTALLING_ADD_TABLES","テーブルを追加する");
	define("INSTALLING_ADD_TABLES_DESC","テーブルを追加してシステムの使用を開始するには、ここをクリックしてください");
	
	/*left menu*/
	define("WELCOME","ようこそ,");
	define("WELCOME_ASK","私達がすること？");
	define("MAIN_MENU","メインメニュー");
	define("START","開始");
	define("DASHBOARD","ダッシュボード");
	define("EMAIL_ADRESSES","メールアドレス");
	define("MENU_RECIPIENT_LIST","受信者リスト");
	define("MENU_ADD_RECIPIENT","受信者を追加");
	define("MENU_CSV_IMPORT","CSVファイルからメールをインポートする");
	define("MENU_CSV_EXPORT","電子メールをCSVファイルにエクスポートする");
	define("MENU_TAG_LIST","タグリスト");
	define("MENU_ADD_TAGS","タグを追加する");
	define("MENU_SENDERS_LIST","送信者リスト");
	define("MENU_ADD_SENDER","送信者を追加する");
	define("MENU_TEMPLATES","メールのレイアウト");
	define("MENU_TEMPLATES_LIST","テンプレートリスト");
	define("MENU_TEMPLATES_ADD","新しいテンプレートを追加する");
	define("MENU_TEMPLATES_ATTACHMENTS","添付ファイル");
    define("MENU_TEMPLATES_THUMBNAILS","サムネイル");
	define("MENU_CAMPAIGNS","あなたのキャンペーン");
	define("MENU_CAMPAIGNS_ADD","新しいキャンペーンを準備する");
	define("MENU_CAMPAIGNS_WAITING_LIST","待ちリストキャンペーン");
	define("MENU_CAMPAIGNS_IN_PROGRESS","進行中のキャンペーン");
	define("MENU_CAMPAIGNS_SENT","送信したキャンペーンを一覧表示する");
	define("MENU_SYSTEM_CONFIGURATION","システム構成");
	define("MENU_SETTINGS","設定");
	define("MENU_LOGIN","ログイン");
	define("MENU_DB","データベース");
	define("MENU_SYSTEM_PARAMS","システムパラメータ");
	define("MENU_SPECIALS","特別アドオン");
	define("MENU_ADDONS","役に立つエキストラ");
	define("MENU_CLEAR_DB","データベースのクリア");
	define("MENU_IMPORT_TEMPLATES","サンプルテンプレートをインポートする");
	define("MENU_IMPORT_DATA","サンプルデータのインポート");
	define("MENU_FAQ","質問と回答");
	define("MENU_ABOUT","約");
    define("MENU_SMTP_PARAMS","SMTP設定");
    define("MENU_UNSUBSCRIBED","サブスクライバリスト");
    define("MENU_UNSUBSCRIBED_LIST","受信者のリスト");
    define("MENU_DOCS","ドキュメンテーション");
    define("MENU_SUBSCRIBE_WIDGET","ウィジェットを購読する");
    define("MENU_BOUNCED","バウンスされたメールをチェックする");
	
	/*dashboard*/
	define("D_EMAIL_ADDRESS","電子メールデータベース");
	define("D_EMAIL_ADD_NEW","新しいメールを追加");
	define("D_EMAIL_TEMPLATES","メールテンプレート");
	define("D_EMAIL_TEMPLATES_ADD","新しいテンプレートを追加する");
	define("D_EMAIL_SENT","送信済みメール");
	define("D_EMAIL_EFFICIENCY","効率");
	define("D_EMAIL_UNSUBSCIBERS","登録されていない");
	define("D_CAMPAIGNS","キャンペーン");
	define("D_CAMPAIGNS_ADD","新しいキャンペーン");
	define("D_CAMPAIGNS_WAITING","送信準備完了");
	define("D_CAMPAIGNS_SENT","完了しました");
	define("D_STATISTICS","統計");
	define("D_THIS_YEAR","今年あなたの広告キャンペーン");
	define("D_CHECK_ALL","すべてチェック");
	define("JAN","一月");
	define("FEB","二月");
	define("MAR","行進");
	define("APR","四月");
	define("MAY","五月");
	define("JUN","六月");
	define("JUL","七月");
	define("AUG","八月");
	define("SEP","九月");
	define("OCT","十月");
	define("NOV","十一月");
	define("DEC","十二月");
	define("D_PREPARED_OVERALL","準備されたキャンペーン");
	define("D_SENT_OVERALL","送られた");
	define("D_HOW_TO","使い方？");
	define("D_HOW_STEP_1_TITLE","1. 電子メールデータベース");
	define("D_HOW_STEP_1_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=tags&action=add'>タグを追加する</a> これはお客様を見つけるのに役立ち、簡単に広告キャンペーンを作成するのに役立ちます。 次 <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=add'>メールを追加</a> データベースシステムに転送します。 あなたもすることができます <a class='btn btn-primary btn-xs' href='index.php?manage=recipient&action=import'>CSVファイルをアップロードする</a> あなたのデータベースに電子メールを送ります。");
	define("D_HOW_STEP_2_TITLE","2. 送信者");
	define("D_HOW_STEP_2_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=sender&action=add'>送信者を追加する</a> 顧客に電子メールを受け取る相手を決定することができます。");
	define("D_HOW_STEP_3_TITLE","3. メールテンプレート");
	define("D_HOW_STEP_3_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=templates&action=add'>テンプレートを追加</a> 無制限の数のテンプレートを無制限に用意してください。");
	define("D_HOW_STEP_4_TITLE","4. 広告キャンペーン");
	define("D_HOW_STEP_4_DESC","<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=prepare'>新しいキャンペーンを追加する</a> 無制限のキャンペーンを準備する。 <a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=waiting'>キャンペーンを送信する</a> いつでも。");
	define("D_HOW_STEP_5_TITLE","5. 統計をフォローする");
	define("D_HOW_STEP_5_DESC","ここでは、どのキャンペーンが最適か、キャンペーンがいつ、どのように準備され、どのくらい送信され、どれが効果的であるか（つまり、あなたのメールを開いた人の数とキャンペーンからの不参加人の数）");
	
	/*main page*/
	define("NAZWA_SYSTEMU","E-mailer");
	
	/**/
	define("CHANGE_LOGIN","ログインを変更する");
	define("CHANGE_PASS","パスワードを変更する");
	define("CLEAR_DATABASE","データベースのクリア");
	define("LOGOUT","シャットダウン");
	define("ABOUT","約");
	
	/*vertical buttons*/
	define("CONFIG","構成");
	define("CONFIG_TOOLTIP","システム構成");
	define("MEDIA_MANAGER","添付ファイルマネージャ");
	define("RECIPIENT","受信者");
	define("RECIPIENT_TOOLTIP","メール管理");
	define("RECIPIENT_EDIT","詳細を変更する");
	define("RECIPIENT_ADD_NEW","新しく追加する");
	define("MENUS","メニュー管理");
	define("MENUS_TOOLTIP","メニュー構成");
	define("TEMPLATES","レイアウト");
	define("TEMPLATES_TOOLTIP","レイアウト構成");
	define("HELP","助けて");
	define("HELP_TOOLTIP","使い方");
	
	define("FILE_MANAGEMENT","添付ファイル");
	define("CSV_IMPORT","CSVファイルの電子メールのインポート");
	
	define("PERSON","人");
	define("EMAIL","電子メールアドレス");
	define("TAGS","タグ");
	define("TAGS_LIST","タグリスト");
	define("TAGS_ADD","新しいタグを追加");
	define("TAGS_ADD_NEW","タグの追加");
	define("TAGS_ADD_EDIT","タグの編集");
	define("TAGS_NAME","タグ名");
	define("TAGS_DESCRIPTION","説明");
	define("TAGS_NAME_PLACEHOLDER","タグ名を入力...");
	define("TAGS_DESCRIPTION_PLACEHOLDER","タグの説明を入力...");
	define("TAGS_USED","使用回数（回）");
	define("TAGS_INFO","電子メールのタグ");
	
	define("RECIPIENT_LIST","メーリングリスト");
	define("RECIPIENT_NAME","受信者の名前");
	define("RECIPIENT_NAME_PLACEHOLDER","氏名を入力");
	define("RECIPIENT_MAIL","電子メイル");
	define("RECIPIENT_MAIL_PLACEHOLDER","メールを入力");
	define("RECIPIENT_ONLY_TXT","TXTメールのみ");
	define("RECIPIENT_DESCRIPTION","説明");
	define("RECIPIENT_DESCRIPTION_PLACEHOLDER","説明...");
	define("RECIPIENT_DB","あなたのメールデータベース");
	define("RECIPIENT_DETAILS_EDIT","受信者の詳細を編集する");
	define("RECIPIENT_DETAILS_ADD","新しいメールアドレスを追加する");
	define("RECIPIENT_IMPORT_CSV","CSVファイルからメールをインポートする");
	define("RECIPIENT_PREPARE_CSV","CSVファイルを次のように準備する");
	define("RECIPIENT_UPLOAD_CSV_TITLE","新しいレコードをExcelファイルから追加するには、以下の手順に従ってください");
	define("RECIPIENT_UPLOAD_CSV_TEMPLATE","CSVテンプレートをダウンロードする");

	define("RECIPIENT_UPLOAD_CSV_NAME","CSVファイルをインポートする");
	define("RECIPIENT_NOT_CSV","<b>これはCSVファイルではありません！</b><br/>");
	define("RECIPIENT_ROW","行 ");
	define("RECIPIENT_WRONG_EMAIL"," - 間違ったメールアドレスが入力されました: ");
	define("RECIPIENT_EMAIL_EXIST"," - このアドレスは既にデータベースにあります: ");
	define("RECIPIENT_EMAIL_LACK"," - 電子メールアドレスがない");
	define("RECIPIENT_EMAIL_IN_DB"," - この電子メールアドレスはすでに行内のCSVファイルに存在します ");
	define("RECIPIENT_TAG_NOT_EXIST"," - そのようなタグはありません: ");
	define("RECIPIENT_CSV_ERRORS","ファイル内のエラー ");
	define("RECIPIENT_CSV_ADDED","追加されました ");
	define("RECIPIENT_CSV_ADDED_FROM"," ファイルからのメールアドレス ");
	define("RECIPIENT_CSV_EXPORT","電子メールアドレスをファイルにエクスポートする");
	define("RECIPIENT_CSV_EXPORT_CHK","エクスポートするフィールドを選択する:");
	define("RECIPIENT_CSV_EXPORT_CHK_EMAIL","受信者のメールアドレス");
	define("RECIPIENT_CSV_EXPORT_CHK_PERSO","名字");
	define("RECIPIENT_CSV_EXPORT_CHK_TAG","タグ - 単一のスペースで区切られています");
	define("RECIPIENT_CSV_EXPORT_CHK_COMM","コメント");
	define("RECIPIENT_CSV_EXPORT_CHK_TXT","テキストのみのメールを受信する");
	define("RECIPIENT_CSV_EXPORT_CHK_DINPUT","導入日");
	define("RECIPIENT_CSV_EXPORT_CHK_DMODIF","修正日");
	define("RECIPIENT_CSV_EXPORT_SUBMIT","輸出する");
	define("RECIPIENT_CSV_IGNORE_ERRORS","CSVエラーチェックを無視します（ファイルに1000以上の電子メールが含まれているかどうかを確認します - ファイルが大きいほど大量のメモリが必要です）");
	
	define("SAVE","セーブ");
	define("CANCEL","キャンセル");
	define("DELETE","削除");
    define("EDIT","編集");
	define("CREATED","作成した");
	define("MODIFIED","変更された");
	define("SEND","送信");
	define("SENT","送信済み");
	define("PROGRESS","進捗");
	define("RESUME","履歴書");
	define("CLOSE","閉じる");
	define("CHANGES_SAVED","変更は正常に完了しました");
	
	define("DELETING","削除");
	define("DELETING_CONFIRM_QUESTION","削除してもよろしいですか？");
	
	define("DATATABLE_LENGTHMENU", "1ページに_MENU_件のレコードを表示する");
	define("DATATABLE_ZERORECORDS", "何も見つかりませんでした - ごめんなさい");
	define("DATATABLE_INFO", "_PAGES_の_PAGE_ページを表示しています");
	define("DATATABLE_INFOEMPTY", "レコードがありません");
	define("DATATABLE_INFOFILTERED", "(フィルタリングされた_TOTAL_ _MAX_合計レコード)");
	define("DATATABLE_SEARCH", "サーチ");
	define("DATATABLE_FIRST", "|<");
	define("DATATABLE_LAST", ">|");
	define("DATATABLE_PREVIOUS", "<<");
	define("DATATABLE_NEXT", ">>");

	define("TEMPLATES_ADD", "新しいテンプレートを追加する");
	define("TEMPLATES_LIST", "テンプレートリスト");
	define("TEMPLATES_TITLE", "使用可能なテンプレート");
	define("TEMPLATES_TITLE_ADD", "新しいレイアウトを追加");
	define("TEMPLATES_TITLE_EDIT", "レイアウト編集");
	define("TEMPLATES_NAME", "レイアウト名");
	define("TEMPLATES_MAIL_TITLE", "メールのタイトル");
	define("TEMPLATES_MAIL_TITLE_PLACEHOLDER", "メールのタイトルを入力");
	define("TMPLATES_HTML", "HTMLバージョン");
	define("TMPLATES_TXT", "TEXTバージョン");
	define("TMPLATES_VARIABLES", "使用可能なテンプレート変数 (チェック <a href='docs/index.html#variables' target='_blank'>ドキュメント</a> 詳細は):");
	define("TEMPLATES_THUMB", "サムネイル");
	define("TEMPLATES_THUMBNAIL_TITLE_EDIT", "サムネイル編集");
	define("THUMBNAIL_MEDIA_LIST", "利用可能なサムネイル一覧");
	
	define("MEDIA_FILENAME", "ファイル名");
	define("MEDIA_FILENAME_DESCRIPTION", "ファイルの説明");
	define("MEDIA_FILENAME_UPLOAD_TIME", "アップロード時間");
	define("MEDIA_TEMPLATES", "添付ファイルとして使用");
	define("MEDIA_LIST", "利用可能な添付ファイル一覧");
	define("MEDIA_ADD_FILES", "追加ファイル");
	define("MEDIA_BROWSE", "ブラウズ");
	define("MEDIA_UPLOAD", "アップロード");
	
	define("CAMPAIGN_MENU", "新しいキャンペーン");
	define("CAMPAIGN_PREPARE", "キャンペーンを準備する");
	define("CAMPAIGN_RECIPIENTS", "受信者を選択");
	define("CAMPAIGN_TEMPLATES", "レイアウトを選択する");
	define("CAMPAIGN_SENDERS", "送信者を選択");
	define("CAMPAIGN_CONFIRM", "キャンペーンを保存する");
	define("CAMPAIGN_SEND", "キャンペーンを送信する");
	define("CAMPAIGN_NAME", "キャンペーン名");
	define("CAMPAIGN_NAME_PLACEHOLDER", "キャンペーン名を入力してください");
	define("CAMPAIGN_RECIPIENT_QTY", "受信者");
	define("CAMPAIGN_TEMPLATE_NAME", "レイアウト");
	define("CAMPAIGN_SENDER", "送信者");
	define("CAMPAIGN_CREATED_DATE", "準備された");
	define("CAMPAIGN_STEP_1", "1. 受信者を選択します（表の上にある「検索」フィールドを使用してください）");
	define("CAMPAIGN_STEP_2", "2. キャンペーンを保存する");
	define("CAMPAIGN_SELECT", "郵送のキャンペーンを選択");
	define("CAMPAIGN_FORM_SELECT", "選択する...");
	define("CAMPAIGN_CURRENT_STATUS", "現在のキャンペーンのステータス");
	define("CAMPAIGN_SENT_NOW", "今すぐ送信する");
	define("CAMPAIGN_SENT_BUTTON", "送信を開始するにはここをクリック");
	define("CAMPAIGN_RESUME_BUTTON", "送信を再開するにはここをクリック");
	define("CAMPAIGN_SERVER_CONNECTING", "サーバーに接続中です。しばらくお待ちください...");
	define("CAMPAIGN_SENDING", "送信");
	define("CAMPAIGN_PLEASE_WAIT", "お待ちください...");
	define("CAMPAIGN_SENT", "<b>キャンペーンが送信されました</b> 受信者: ");
	define("CAMPAIGN_IN_PROGRESS", "進行中のキャンペーン...");
	define("CAMPAIGN_COMPLETED", "送信済みのキャンペーン");
	define("CAMPAIGN_LEFT", "左に送る");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE", "すべての登録解除を削除する");
	define("CAMPAIGN_UNSUBSCRIBERS_DELETE_INFO", "この操作により、データベースからすべてのサブスクライバが削除されます。");
	define("CAMPAIGN_BG_PROCESS", "バックグラウンドプロセス");
	define("CAMPAIGN_BG_PROCESS_INFO", "バックグラウンドプロセスとして送信する（ブラウザを閉じることができます）");
	define("CAMPAIGN_WHEN_FINISH", "完了したら電子メール");
	define("CAMPAIGN_EMAIL_FIN_PLACEHOLDER", "通知を送信する場所");
	define("CAMPAIGN_BG_CONFIRM_TXT", "バックグラウンド送信を確認してください!");
    
    define("HOUR", "時");
    define("OPENS", "開ける");
    define("BOUNCED", "バウンス");
    define("CLICKED", "クリックされた");
    define("UNIQUE_CLICKS", "ユニーククリック数");
    define("TOTAL_CLICKS", "合計クリック数");
	
	define("SENDER_LIST", "送信者リスト");
	define("SENDER_ADD", "送信者を追加する");
	define("SENDER_NAME", "送信者名");
	define("SENDER_NAME_PLACEHOLDER", "送信者名を入力してください");
	define("SENDER_EMAIL", "送信者の電子メール");
	define("SENDER_EMAIL_PLACEHOLDER", "送信者のメールアドレスを入力");
	define("SENDER_TITLE_ADD", "送信者を追加する");
	define("SENDER_TITLE_EDIT", "送信者を編集する");
	define("SENDER_EMAIL_TITLE", "送信者の電子メールアドレス");
	define("SENDER_EMAIL_TITLE_PLACEHOLDER", "送信者のメールアドレスを入力してください");
	
	define("SETTINGS", "設定");
	define("SETTINGS_LOGIN_TITLE", "新しい資格情報を入力");
	define("SETTINGS_LOGIN_LABEL", "新しいログインを入力");
	define("SETTINGS_LOGIN_PLACEHOLDER", "ログインを入力");
	define("SETTINGS_CURR_PASS", "現在のパスワード");
	define("SETTINGS_CURR_PASS_PLACEHOLDER", "パスワードを入力する");
	define("SETTINGS_NEW_PASS", "新しいパスワード");
	define("SETTINGS_NEW_PASS_PLACEHOLDER1", "新しいパスワード");
	define("SETTINGS_NEW_PASS_PLACEHOLDER2", "確認する");
	define("SETTINGS_DB_PARAMS", "データベースの設定");
	define("SETTINGS_DB_HOST", "データベースホスト");
	define("SETTINGS_DB_HOST_PLACEHOLDER", "例。: localhost");
	define("SETTINGS_DB_USER", "データベースユーザー");
	define("SETTINGS_DB_USER_PLACEHOLDER", "例。: root");
	define("SETTINGS_DB_PASSWORD", "データベースのパスワード");
	define("SETTINGS_DB_NAME", "データベース名");
	define("SETTINGS_DB_NAME_PLACEHOLDER", "例。: mailing");
	define("SETTINGS_GLOBAL", "全体設定");
	define("SETTINGS_LANG", "システム言語");
	define("SETTINGS_LIMIT", "1時間あたりの電子メールの制限を設定する");
	define("SETTINGS_LIMIT_PLACEHOLDER", "デフォルト: 1000");
	define("SETTINGS_TRACKING", "電子メールトラッキングを有効にする");
	define("SENDING_METHOD", "送信方法");
	define("SETTINGS_UNSUBSCRIBED", "自動的にサブスクライブ解除されます");
	define("SETTINGS_UNS_INFO", "ユーザーがあなたの脱退者のリンクをクリックすると、受信者リストからメールが自動的に削除されます");
	define("SETTINGS_TRACK_INFO", "あなたの受信者を追跡するために目に見えないimgタグが追加されます");
	define("SETTINGS_API_LABEL", "Googleマップと<br>APIキー");
	define("SETTINGS_API_PLACEHOLDER", "GoogleマップAPI v.3キーをここに入力してください");
	define("SETTINGS_API_LINK_INFO", "新しいAPIキーを入手するには、ここをクリックしてください");
	define("SETTINGS_ADMIN_MAIL", "管理者のメールアドレス");
	define("SETTINGS_ADMIN_MAIL_PLACEHOLDER", "システム通知用の管理者用電子メール");
    define("SETTINGS_PHP_TIMEOUT", "PHPのタイムアウト（秒）");
    
	define("SMTP_SERVER_DESCRIPTION", "SMTPサーバーを追加するときは、必ず");
    define("SMTP_LIST", "サーバリスト");
    define("SMTP_ADD", "新しいサーバーを追加する");
    define("SMTP_EDIT", "編集サーバー");
    define("SMTP_INFO", "あなたのSMTPサーバー");
    define("SMTP_ADD_BUTTON", "クリックして新しいSMTPサーバーを追加する");
    define("SMTP_NAME", "接続名");
    define("SMTP_NAME_PLACEHOLDER", "例。: 私の最高のつながり");
    define("SMTP_HOST", "SMTPアドレス");
    define("SMTP_HOST_PLACEHOLDER", "メインサーバーとバックアップサーバー（バックアップ用のセパレータ ';'）");
    define("SMTP_PAUTH", "認証");
    define("SMTP_PAUTH_PLACEHOLDER", "SMTP認証を有効にする");
    define("SMTP_VERIFY_PEER", "SSL / TLS証明書検証を有効にする");
    define("SMTP_FORCE_SMTP", "SMTPの使用を強制する");
    define("SMTP_USERNAME", "SMTPユーザー名");
    define("SMTP_USERNAME_PLACEHOLDER", "SMTPユーザー名");
    define("SMTP_LOGIN", "SMTPログイン");
    define("SMTP_LOGIN_PLACEHOLDER", "SMTPサーバーログイン");
    define("SMTP_PASSWORD", "SMTPパスワード");
    define("SMTP_PASSWORD_PLACEHOLDER", "SMTPパスワード");
    define("SMTP_REPLYTO", "メールに返信する");
    define("SMTP_REPLYTO_PLACEHOLDER", "別の返信先アドレスを設定する");
    define("SMTP_REPLYTONAME", "名前に返信");
    define("SMTP_REPLYTONAME_PLACEHOLDER", "別の返信先の名前を設定する");
    define("SMTP_SECURE", "暗号化");
    define("SMTP_SECURE_TLS", "<b>'tls'</b> デフォルトの暗号化として");
    define("SMTP_SECURE_SSL", "<b>'ssl'</b> 受け入れられるが推奨されない");
    define("SMTP_PORT", "ポート");
    define("SMTP_PORT_PLACEHOLDER", "サーバポート");
    define("SMTP_LIMIT", "1時間あたりの制限");
    define("SMTP_LIMIT_PLACEHOLDER", "デフォルト: 1000");
    define("CAMPAIGN_SMTP", "SMTPを選択");
    define("SMTP_TESTING", "SMTP接続のテスト");
    define("SMTP_TESTING_EMAIL", "メッセージをテストするためのアドレス");
    define("SMTP_RUN_TEST", "それをチェックする!");
    define("SMTP_TEST_TXT_TITLE", "からのSMTPテスト E-mailer.");
    define("SMTP_TEST_TXT_MESSAGE", "SMTP接続からのテストメッセージ。");
    define("SMTP_TEST_OK", "メッセージが送信されました。 メールボックスを確認してください。");
    define("SMTP_TEST_ERROR", "<b>メーラーエラー: </b>");
    define("SMTP_BEFORE_USE", "<b>メーラーエラー.</b> 使用する前に、設定でSMTP接続を有効にする必要があります。");
    define("BOUNCED_INFO", "バウンスされた電子メールはそのメールボックスに戻ります");
    define("SMTP_CONFIG", "送信用にSMTPを設定する");
    define("IMAP_CONFIG", "バウンス用にIMAP / POP3をセットアップする");
    define("SMTP_INFO_SETUP", "SMTP設定");
    define("IMAP_INFO_SETUP", "IMAP / POP3設定");
    define("PROTOCOL", "プロトコル");
    define("FOLDER", "アクセスするフォルダ");
	
	define("STATISTICS", "統計");
	define("STATISTICS_ADV", "高度な詳細");
	define("STATISTICS_TAB_MAP", "地図上の受信者（ジオロケーション）");
	define("STATISTICS_TAB_DETAILS", "詳細な統計");
	define("STATISTICS_TAB_ACTIONS", "特別な行動");
	define("STATISTICS_BACK", "リストに戻る");
	define("STATISTICS_BUTTON_OPENERS", "オープナーのために準備する");
	define("STATISTICS_BUTTON_OPENERS_INFO", "メールを開いたすべての人に新しいキャンペーンを準備する");
	define("STATISTICS_BUTTON_NOT_OPENERS", "オープナーにならないように準備する");
	define("STATISTICS_BUTTON_NOT_OPENERS_INFO", "メールを開いていないすべての人に新しいキャンペーンを準備する");
	define("STATISTICS_BUTTON_UNSUBSCRIBED", "登録を解除する準備をする");
	define("STATISTICS_BUTTON_UNSUBSCRIBED_INFO", "システム設定で[自動削除を解除する]オプションが有効になっている場合、すべての登録解除者の新しいキャンペーンを準備します。電子メールは削除され、ここには何も追加されません");
	define("STATISTICS_BUTTON_FILTERS", "高度なフィルタを使用して準備する");
	define("STATISTICS_BUTTON_FILTERS_INFO", "収集したデータでこのキャンペーンのすべての受信者のリストを取得し、高度なフィルタに基づいて新しい特別キャンペーンを作成する");
	define("STATISTICS_TOP_COUNTRIES", "上位10カ国");
	define("STATISTICS_TOP_CITIES", "上位10都市");
	define("STATISTICS_TOP_CLICKERS", "トップ15クリッカー");
	define("STATISTICS_TOP_SOFTWARE", "最も人気のある上位ソフトウェア15");
	define("STATISTICS_OTHER_UA", "その他すべてのユーザエージェント");
	define("STATISTICS_OTHERS", "その他");
    
	define("SOFTWARE", "ソフトウェア");
	define("GEODATA", "ローカリゼーション");
    
	define("UNSUBSCRIBE_MESSAGE", "
	<!DOCTYPE html>
		<html lang='en'>
			<head>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
				<meta title='確認'>
			</head>
			<body>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p style='text-align:center;'>ニュースレターの登録を解除しました。</p>
				<p style='text-align:center;'>&nbsp;</p>
				<p style='text-align:center;'>良い一日を。</p>
			</body>
		</html>	
	");
	
	define("ADDONS_DB_TITLE", "データベースから不要なデータを削除する");
	define("ADDONS_IMPORT_TITLE", "サンプルテンプレートの郵送の追加");
	define("ADDONS_FAQ_TITLE", "聞く前にお読みください");
	define("ADDONS_ABOUT_TITLE", "プログラムとライセンスに関する情報");
	define("ADDONS_IMPORT_DATA_TITLE", "サンプルデータをシステムにインポートする");
	define("ADDONS_IMPORT_BUTTON", "メールテンプレートをインポートする");
	define("ADDONS_IMPORT_BUTTON_DESC", "これにより、郵送用のサンプルテンプレートがインポートされます");
	define("ADDONS_IMPORT_CONFIRM_TXT", "メーリングのサンプルテンプレートの追加を確認する");
	define("ADDONS_IMPORT_DATA_CONFIRM_TXT", "システムにサンプルデータを追加することを確認します。 現在入力されているデータはすべて消去されます。");
	define("ADDONS_FAQ_DESCRIPTION", "
	<ol>
		<li>
			<p>なぜ郵送用の専用サーバを所有する方が良いのですか？</p>
			<p>まず、制限はありません。 通常のホスティングでは、1時間に最大1,000件の電子メールを送信できます（1日に数百件から数千件の電子メールの制限に応じて） サーバー上では、このような制限はなく、ドメインから電子メールを送信する機能もあります。 あたかもサーバーが別のドメインの下にあるかのように電子メールを送信することもできます（この場合、いわゆるSPFレコードとTXTドメインを設定します）。</p>
		</li>
		<li>
			<p>タグとは何ですか？</p>
			<p>郵送先の住所を見つけたり、特定の受取人の広告キャンペーンを準備したりするのが簡単です。</p>
		</li>
		<li>
			<p>電子メールテンプレートに受信者の名前を追加するには？</p>
			<p>コンテンツテンプレートメールまたはテンプレートメールの題名に{RECIPIENT_NAME}というフレーズを使用してください。 フレーズは、受信者の電子メールアドレスに情報が追加された場合に、受信者の電子メールの名前に置き換えられます。</p>
		</li>
		<li>
			<p>新しい翻訳を追加するには？</p>
			<p>ファイル参照english.phpをコピーし、あなたの言語を記述する名前（例：mylanguage.php）を与え、同じフォルダに貼り付けます。 新しいファイルに含まれるすべてのテキストを修正します。 UTF-8なしのBOMでファイルを保存してください。 言語ファイルはディレクトリにあります 'languages'.</p>
			<p>WYSIWYGエディタの翻訳を追加するには、に行きます。 https://www.tinymce.com/download/language-packages/ - 適切なファイル言語をダウンロードして保存する /emailer/libs/tinymce/langs/ フォルダ.</p>
		</li>
		<li>
			<p>電子メールにタグを追加するにはどうすればよいですか？</p>
			<p>まず、いくつかのタグを追加する必要があります <a class='btn btn-default btn-xs' href='index.php?manage=tags&action=add'>このフォームを使用して</a>. その後、各電子メールアドレスを追加/編集すると、任意のタグに割り当てることができます。 受信者を追加/編集するために、フォームの下にすべてのタグが追加されます。</p>
		</li>
		<li>
			<p>受信メッセージから脱退する機能を追加するにはどうすればよいですか？</p>
			<p>電子メールテンプレートのコンテンツのリンクには、フレーズ{UNSUBSCRIBE}を使用してください。 フレーズは、特定の受信者のリンクに置き換えられます。 クリックすると、キャンペーンの排出に関する情報がデータベースに保存されます。 電子メールアドレスはデータベースから削除されません。 <br>使用法:<br>&lt;a href='{UNSUBSCRIBE}'&gt;ニュースレターの購読を停止する&lt;/a&gt;</p>
		</li>
		<li>
			<p>ブラウザビューに能力を追加するには？</p>
			<p>電子メールテンプレートのコンテンツのリンクには、フレーズ{BROWSER_VIEW}を使用してください。 フレーズは、特定の受信者のリンクに置き換えられます。 クリックすると、ブラウザウィンドウにメッセージが表示されます。 <br>使用法:<br>&lt;a href='{BROWSER_VIEW}'&gt;ブラウザビュー&lt;/a&gt;</p>
		</li>
		<li>
			<p>定義済みの電子メールテンプレートを追加するには？</p>
			<p>30サンプルのテンプレートの郵送はこちら <a class='btn btn-default btn-xs' href='index.php?manage=addons&action=import_templates'>テンプレートを追加する</a></p>
		</li>
		<li>
			<p>画像を電子メールに追加するにはどうすればよいですか？</p>
			<p>- 外部リソース内の画像への絶対的なリンクとして、:<br>&lt;img src='http://www.domain.ext/logo.jpg' &gt;.</p>
		</li>
		<li>
			<p>電子メールの追跡方法は？</p>
			<p>送信された電子メールシステムごとにイメージタグIMGを追加することができます。この属性SRCには、特定のメッセージを表示するトラッキングコードが含まれています。 トラッキングは、メール受信者が受信したメッセージの画像を表示することに同意する場合にのみ機能します。</p>
		</li>
		<li>
			<p>どのようにスパマーになれないのですか？</p>
			<p>- メーリングリストの作成時にメッセージを受け取る同意を集める。</p>
			<p>- 受信者ごとにさまざまなコンテンツを使用してください。 {RECIPIENT_NAME}さんがあなたのメールのチェックサムを区別しています。</p>
			<p>- sex、viagra、pornのようなキーワードは使用しないでください。</p>
			<p>- 公的データベースからの住所、興味のない商業情報ではない、無関心、申し訳ありませんが、あなたが望んでいない場合は意味の範囲内のオファーを構成しません。 今すぐ買う - このようなフレーズを使用する必要がある場合は、それらをグラフィックの形にすることを検討する必要があります。</p>
			<p>- あまりにも多くのグラフィックスを使用しないで、スパムフィルタはグラフィックスとテキストの比率を調べます。</p>
			<p>- メールは重すぎるべきではありません。</p>
			<p>- より良い添付ファイルが少なくなります。</p>
			<p>- 別のドメインに偽装しないでください。</p>
			<p>- 存在しない電子メールアドレスから電子メールを送信しないでください。</p>
		</li>
		<li>
			<p>クリック数を増やしてキャンペーンを読み込む方法</p>
			<p>あなたの顧客に送るコンテンツと、それを行う時間と頻度に最大の影響を与えます。 ほとんどの場合、連絡先は月に2回以上にするべきではありません。 あなたの顧客を尊重し、彼らはあなたを迷惑メールに送りません。</p>
		</li>
		<li>
			<p>郵送先の選択方法は？</p>
			<p>タグを使用して、アドレスの表の上の検索フィールドにスペースで区切って入力します。</p>
		</li>
		<li>
			<p>このシステムの限界は何ですか？</p>
			<p>制限はありません。</p>
		</li>
		<li>
			<p>サーバーホスティングのメッセージを制限しますか？</p>
			<p>1日に数百から数千の電子メールのホスティング制限に応じて、サービスプロバイダに確認してください。</p>
		</li>
		<li>
			<p>キャンペーンを送信するときに壊れた接続？</p>
			<p>キャンペーンの送信を再開すると、他の受信者にメールが送信されます。 送信された各電子メールはデータベースに一意のマーカーを設定し、キャンペーン自体は同じ受信者に再送信されません。</p>
		</li>
		<li>
			<p>バウンスされたメールの要件</p>
			<p>バウンスされた電子メールのサポートを有効にするには、php.iniファイルでこの行のコメントを解除する必要があります。</p>
			<p>;extension=php_imap.dll</p>
			<p>Imap関数はPOP3 / IMAP接続を使用する必要があります。</p>
		</li>
	</ol>
	");
	define("ADDONS_BE_CAREFULLY", "慎重に、以下のアクションはデータベースのテーブルをきれいにします！");
	define("ADDONS_DATA_BE_CAREFULLY", "警告！ すべてのデータが削除され、サンプルデータに置き換えられます");
	define("ADDONS_D_AL", "すべてのデータを削除する");
	define("ADDONS_D_AL_DESC", "データベース内のすべてのデータを消去します。");
	define("ADDONS_D_AL_CONF", "データベースからすべてのデータを削除してもよろしいですか？ すべてのメールアドレス、テンプレート、添付ファイル、キャンペーンが削除されます。");
	define("ADDONS_D_RE", "受信者とそのキャンペーンを削除する");
	define("ADDONS_D_RE_DESC", "データベース内のすべての電子メールアドレスと広告キャンペーンの履歴を削除します。");
	define("ADDONS_D_RE_CONF", "すべての受信者の削除を確認する");
	define("ADDONS_D_CA", "キャンペーンのみを削除する");
	define("ADDONS_D_CA_DESC", "すべての広告キャンペーンとその履歴を削除する");
	define("ADDONS_D_CA_CONF", "すべてのキャンペーンとその履歴の削除を確認する");
	define("ADDONS_D_TE", "テンプレートのみを削除する");
	define("ADDONS_D_TE_DESC", "すべてのメールテンプレートとそのリンクをキャンペーンや添付ファイルとともに削除します");
	define("ADDONS_D_TE_CONF", "すべてのテンプレートの削除を確認する");
	define("ADDONS_D_AT", "添付ファイルのみを削除する");
	define("ADDONS_D_AT_DESC", "すべての添付ファイルを削除します。");
	define("ADDONS_D_AT_CONF", "すべての添付ファイルの削除を確認する");
	define("ADDONS_D_SE", "送信者のみを削除");
	define("ADDONS_D_SE_DESC", "入力されたすべての送信者の電子メールを削除しますが、統計的な目的でIDを残します。");
	define("ADDONS_D_SE_CONF", "すべての送信者の削除を確認する");
	define("ADDONS_D_TG", "タグのみを削除する");
	define("ADDONS_D_TG_DESC", "入力したすべてのタグと顧客との関係をクリアする");
	define("ADDONS_D_TG_CONF", "すべてのタグを削除することを確認する");
    
	define("WIDGET_PREPARE", "サブスクリプションウィジェットを準備する");
	define("WIDGET_OPTIONS", "オプション");
	define("WIDGET_HTML", "HTML");
	define("WIDGET_GENERATE", "ここであなたのサブスクリプションウィジェットを生成する");
	define("WIDGET_COMMENT", "新しい受信者についてのコメント");
	define("WIDGET_COMMENT_PLACEHOLDER", "例。: から domain.ext (受信者の説明に保存されます)");
	define("WIDGET_NAME", "名");
	define("WIDGET_NAME_SHOW", "受信者名フィールドを表示する");
	define("WIDGET_AFTER", "投稿サブウィジェット");
	define("WIDGET_AFTER_NOTHING", "何もしない");
	define("WIDGET_AFTER_TXT", "テキストメッセージを表示する");
	define("WIDGET_AFTER_REDIRECT", "ページにリダイレクトする");
	define("WIDGET_TAGS", "タグを追加する");
	define("WIDGET_PURE_CODE_TXT", "純粋なHTMLコード。 必要に応じて変更することができます。 クラス、タグ、説明などを追加します。 下のコードをコピーしてウェブサイトに貼り付けます。");
	define("WIDGET_FULL_CODE_TXT", "完全版（すべてのフィールドを含む）");
	define("WIDGET_MIN_CODE_TXT", "最小化バージョン（電子メールのみ）");
	define("WIDGET_CODE_DESC_TXT", "フォームの説明");
	define("WIDGET_MAIL_DESC_TXT", "
        <li><b>recipientmail</b> 必須.</li>
        <li>購読者の電子メールアドレス.</li>
    ");
	define("WIDGET_NAME_DESC_TXT", "
        <li><b>recipientname</b> 任意.</li>
        <li>サブスクライバの名前。</li>
    ");
	define("WIDGET_TAGS_DESC_TXT", "
        <li><b>tags</b> 任意.</li>
        <li>隠されたフィールド。</li>
        <li>それらはすでにデータベースに追加されている必要があります。</li>
        <li>カンマで区切る必要があります。</li>
        <li>さまざまなタグを使用すると、異なるキャンペーンを作成できます。</li>
        <li>異なるサイトで同じフォームを使用し、各サイトで異なるタグを使用することができます。</li>
        <li>これは、このコンポーネントが異なるサイトから加入者を収集し、異なるタグを使用してシステムに追加できることを意味します。</li>
    ");
	define("WIDGET_COMMENT_DESC_TXT", "
        <li><b>recipientcomment</b> 任意.</li>
        <li>隠されたフィールド。</li>
        <li>受信者の説明を追加します。</li>
    ");
	define("WIDGET_DBL_OPT_IN_DESC_TXT", "
        <li><b>dbloptin</b> 任意.</li>
        <li>隠されたフィールド。</li>
        <li>ダブルオプトイン機能を有効にする。</li>
    ");
	define("WIDGET_REDIRECT_DESC_TXT", "
        <li><b>redirectto</b> 任意.</li>
        <li>隠されたフィールド。</li>
        <li>購読後にリダイレクトする場所。 フィールドが空であるか、フォームに含まれていない場合、設定されたアクションが実行されます。</li>
    ");
	define("WIDGET_USE_THIS_CODE", "下のコードをコピーしてサイトに貼り付けてください");
	define("WIDGET_DBL_OPT_IN", "ダブルオプトイン");
	define("WIDGET_DBL_OPT_LABEL", "それをチェックして二重契約確認を使用する");
	define("WIDGET_DBL_OPT_LABEL_EMAIL", "電子メールメッセージ（HTMLサポート）");
	define("WIDGET_DBL_OPT_HELP", "追加することを忘れないでください <b>{CONFIRM_LINK}</b> あなたのメッセージに。<br>追加することもできます:<br><b>{SUBSCRIBER_EMAIL}</b> - 加入者の電子メールアドレス<br><b>{SUBSCRIBER_NAME}</b> - 加入者名<br><b>{SUBSCRIBER_COMMENT}</b> - 購読者に関するあなたのコメント<br><b>{SUBSCRIBER_TAGS}</b> - 使用タグ<br><b>{CURRENT_YEAR}</b> - 今年<br><b>{CURRENT_MONTH}</b> - 今月<br><b>{CURRENT_DAY}</b> - 当日");
	define("WIDGET_DBL_OPT_TITLE_EMAIL", "メールのタイトル");
	define("WIDGET_DBL_OPT_TITLE_PLACEHOLDER", "電子メール確認のタイトルを入力...");
	define("WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER", "メール確認メッセージを入力...");
	define("WIDGET_DBL_OPT_REDIRECT_TO_LABEL", "確認後にリダイレクトする");
	define("WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER", "確認後にリダイレクトするアドレスを入力します");
	define("WIDGET_DBL_OPT_ADR_EMAIL", "住所から送信する");
	define("WIDGET_DBL_OPT_ADR_PLACEHOLDER", "確認を送信するメールアドレスを入力してください");
	define("WIDGET_DBL_OPT_DESC_EMAIL", "送信者の説明");
	define("WIDGET_DBL_OPT_DESC_PLACEHOLDER", "送信者の説明を入力");
	define("WIDGET_ADMIN_NOTIFY", "新しい加入者について管理者に通知する");
	define("WIDGET_ADMIN_NOTIFY_LABEL", "新しいサブスクリプションを受信した後に電子メール通知を送信するようにチェックしてください。<br><br> <b>警告！</b>管理者の電子メールは、システムパラメータで設定する必要があります。");
	define("WIDGET_ADMIN_LABEL_EMAIL", "管理者メッセージ（HTMLサポート）");
	define("WIDGET_ADMIN_HELP", "あなたのメッセージに使用することができます:<br><b>{SUBSCRIBER_EMAIL}</b> - 加入者の電子メールアドレス<br><b>{SUBSCRIBER_NAME}</b> - 加入者名<br><b>{SUBSCRIBER_COMMENT}</b> - 購読者に関するあなたのコメント<br><b>{SUBSCRIBER_TAGS}</b> - 使用タグ<br><b>{CURRENT_YEAR}</b> - 今年<br><b>{CURRENT_MONTH}</b> - 今月<br><b>{CURRENT_DAY}</b> - 当日");
    define("WIDGET_ERROR_MESSAGE_LABEL", "間違ったサブスクライバ電子メールアドレスの場合のサーバエラーメッセージ");
    
    
    
	define("BOUNCED_CHOOSE_SERVER", "あなたのサーバーを選択してください");
	define("BOUNCED_DEL_EMAILS", "受信者リストから自動的に削除");
	define("BOUNCED_DEL_MESSAGES", "バウンスされたメッセージとチェックされたメッセージをすべてサーバーから自動的に削除する");
	define("BOUNCED_MAX", "最大メッセージ数の制限");
	define("BOUNCED_AT_TIME", "一度にチェックする");
	define("BOUNCED_START", "メールボックスにバウンスされたメールがないかチェックする");
	
	define("YES", "はい");
	define("NO", "いいえ");
	define("DATA_ERROR", "エラー：要求されたデータが存在しません...<br><br><a href='index.php'>ダッシュボードを開くにはここをクリックしてください</a>");
	
	/*v.1.14*/
    define("WIDGET_SERVERID_LABEL", "サブスクリプションウィジェットのメールを送信するサーバー");
    define("TESTING_TEMPLATE", "テストテンプレート");
    define("TESTING_TEMPLATE_INFO", "下の入力メールにテンプレートを送信します。 変数は置換されません.");
    define("TESTING_CHOOSE_SERVER", "送信サーバーを選択します。");
    define("ERRORS", "エラー");
    define("TEST", "私をテストする");
    
    /*v.1.16*/
    define("COPY", "コピー");
    define("COPYING", "対処する");
    define("CHECK", "チェック");
    define("DATA_VERIFY", "データの整合性チェック");
    define("DATA_VERIFY_QUESTION", "データの整合性をチェックしてもよろしいですか？");
    define("DATA_VERIFY_DESCRIPTION", "この操作には数分かかることがあります。データベースのデータ量によって異なります。 <br>キャンペーンが終了し、このリストに表示されていないことを確認してください。");
    define("DATA_VERIFY_BUTTON", "データの整合性を確認する");
    
    /*v.1.17*/
    define("SETTINGS_TB_PREFIX", "Data table prefix");
    define("SETTINGS_TB_PREFIX_PLACEHOLDER", "ex.: m_");
    define("REC_QUERY_OR", "選択したタグから受信者をフィルタする (OR&nbsp;query)");
    define("REC_QUERY_AND", "すべての選択されたタグに受信者をフィルターする (AND&nbsp;query)");
    define("REC_RESET", "クエリをリセットする");
    define("REC_BUTTON_DELETE", "受信者を削除する");
    define("CSV_ST_1", "数式に従ってデータを準備する:");
    define("CSV_COL_NO", "列番号");
    define("CSV_REQ", "必須");
    define("CSV_OPT", "オプション");
    define("CSV_ADDR", "電子メールアドレス");
    define("CSV_NAME", "姓と名");
    define("CSV_TAGS", "タグ");
    define("CSV_TAGSDESC", "データベース内になければならず、単一のスペースで区切らなければならない");
    define("CSV_COMMENT", "コメント");
    define("CSV_DESC1", "スプレッドシートをCSV形式で保存する");
    define("CSV_DESC2", "デリミタ");
    define("CSV_MAXLINE", "最大CSV行の長さ");
    define("CSV_FORMDESC", "下のフォームを使用して準備されたCSVファイルをアップロードする");
    define("DISABLE_EDITOR", "エディタを無効にする");
    define("ENABLE_EDITOR", "エディタを有効にする");
    
    /*v.1.18*/
    define("MENU_BRIDGE", "DBブリッジによる電子メールのインポート");
    define("TITLE_IMPORT", "受信者のインポート");
    define("SUBTITLE_IMPORT", "データベースブリッジ - ソースパラメータ");
    define("LIST_TITLE_IMPORT", "他のデータベースから受信者をインポートする");
    define("ADD_NEW_BRIDGE", "新しい橋を追加");
    define("IMPORT_RECIPIENTS", "受信者のインポート");
    define("IMPORT_BRIDGE_DESC", "インポートブリッジの説明");
    define("CONFIRM_BRIDGE_DEL", "データベースブリッジ接続の削除");
    define("IMPORTING_BRIDGE_REC", "受信者のインポート");
    define("CHOOSEN_BRIDGE", "選択された橋");
    
    define("FORM_BRIDGE_DESC", "インポートブリッジの説明");
    define("BRIDGE_TABLE", "ソーステーブル名");
    define("BRIDGE_COL_NAME", "受信者名のソース列");
    define("BRIDGE_COL_NAME_INFO", "[受信者名]フィールドにインポートされます。");
    define("BRIDGE_COL_MAIL", "電子メールアドレスのソース列");
    define("BRIDGE_COL_MAIL_INFO", "メールフィールドにインポートされます");
    define("BRIDGE_COL_DESC", "受信者の説明のソース列");
    define("BRIDGE_COL_DESC_INFO", "[説明]フィールドにインポートされます");
    define("BRIDGE_CHECK_CON", "データベース接続を確認する");
    define("BRIDGE_WAITING", "テストを待っている...");
    define("BRIDGE_ADD_NAME", "追加の受信者名");
    define("BRIDGE_ADD_NAME_INFO", "ソース名列の後に追加されます");
    define("BRIDGE_ADD_DESC", "追加の受信者の説明");
    define("BRIDGE_ADD_DESC_INFO", "ソース記述列の後ろに追加されます");
    define("BRIDGE_OVERRIDE", "既存の受信者を上書きする");
    define("BRIDGE_OVERRIDE_O1", "更新 - 新しい送信元に応じて宛先の受信者を修正する");
    define("BRIDGE_OVERRIDE_O2", "無視する - 宛先受信者が既に存在する場合は何もしない");
    define("BRIDGE_TAGS", "利用可能なタグ");
    define("BRIDGE_FILL_FIELDS", "テストする前に必要なフィールドをすべて記入してください...");
    define("BRIDGE_IMPORT_IN_PROGRESS", "インポートが進行中です。しばらくお待ちください...");
    define("BRIDGE_TEST_OK", "接続ブリッジが正常に動作しています");
    define("BRIDGE_IMPORT_OK1", "インポートが完了しました。 更新しました：");
    define("BRIDGE_IMPORT_OK2", " 挿入された:");
    define("TABLE", "表 ");
    define("COLUMN", "カラム ");
    define("NOT_IN_DB", " データベースに存在しません ");
    define("NOT_IN_TABLE", " 表には存在しません ");
    
    /*v.1.19*/
    define("SETTINGS_API_GEO_LABEL", "ipstack geolocation <br>API key");
    define("SETTINGS_API_GEO_PLACEHOLDER", "ここにあなたのジオロケーションAPIキーを入力してください");
    define("SETTINGS_API_GEO_LINK_INFO", "新しいジオロケーションAPIキーを入手するには、ここをクリックしてください");
    
    /*v.1.20*/
    define("HTTPS_USAGE", "https を使用する");
    define("HTTPS_USAGE_INFO", "https を使用している場合は、https ですべてのリンクを生成します");
    define("TEMPLATE_STATISTICS", "テンプレート統計: ");
    define("TEMPLATE_CHARS", "キー文字: ");
    define("TEMPLATE_USAGE", "中古: ");
    
    /*v.1.21*/
    define("WIDGET_FORM_TOKEN", "購読フォーム登録トークン ");
    define("WIDGET_EMAIL_TOKEN", "購読メール登録トークン ");
    
    /*v.1.22*/
    define("WEBSITE", "ウェブサイト");
    define("WIDGET_WEBSITE_SHOW", "受信者のURLフィールドを表示");
    define("VERIFIED", "確認済み");
    define("VERIFY", "確認する");
    define("C_PREPARED", "準備して待っている");
    define("C_AJAX_PROGRESS", "ajax送信中");
    define("C_FINISHED", "終わった");
    define("C_BG_PROGRESS", "バックグラウンド送信中");
    define("C_PAUSED", "一時停止");
    define("C_CRON", "進行中のcron");
    define("B_VER", "一括確認");
    define("B_RV", "一括受信者の確認");
    define("B_SEND1", "送信してよろしいですか");
    define("B_SEND2", "確認のための受信者");
    define("B_CHECK_LIST", "一括確認リストを確認する");
    define("B_VER_INFO", "あなたの一括チェックはあなたのemailable.comアカウントで利用可能になります");
    define("B_VER_IN_PROG", "進行中の確認");
    define("B_VER_SENT", "一括チェック用に送信された受信者");
    define("B_V_TITLE", "一括メール確認");
    define("B_V_TITLE2", "送信済みリスト");
    define("BUTTON_CHECK_STATUS", "状況を確認する");
    define("BUTTON_DOWN_UP", "ダウンロードと更新");
    define("V_ID", "IDを確認");
    define("V_QTY", "確認する数量");
    define("V_DATE", "送信日");
    define("V_MESSAGE", "状態");
    define("V_PERC", "% コンプリート");
    define("V_WORKING", "ワーキング");
    define("RESPONSE", "応答");
    define("V_UPDATED_INFO", "受信者が更新されました。詳細を確認してください");
    define("SETTINGS_API_THECHECKER", "emailable.com APIキーを入手するには、ここをクリックしてください。");
    define("SETTINGS_API_DESCRIPTION", "バウンスを殺すことができます！ <br>下のボタンを使用すると、初回購入時に<b> 30％の追加料金チェック</b>が行われ、購入するたびに（現金または小切手で）30％のボーナスが支払われます。");
    define("EC_DATA", "すべてのキャンペーンデータをエクスポートする");
    define("EC_DATA1", "キャンペーンデータをエクスポートする");
    define("EX_OPENED_BUTTON", "開封した受信者");
    define("EX_OPENED_DESC", "キャンペーンEメールを開いたキャンペーン受信者のエクスポート");
    define("EX_NOT_OPENED_BUTTON", "開かなかった受信者");
    define("EX_NOT_OPENED_DESC", "キャンペーンEメールを開かなかったキャンペーン受信者のエクスポート");
    define("EX_UNSUBSRIBED_BUTTON", "退会した受信者");
    define("EX_UNSUBSRIBED_DESC", "キャンペーンの購読を解除したキャンペーンの受信者をエクスポートする");
    define("EX_CLICKED_BUTTON", "クリックした受信者");
    define("EX_CLICKED_DESC", "キャンペーンEメールのリンクをクリックしたキャンペーン受信者のエクスポート");
    define("EX_ALL_BUTTON", "全受信者データ");
    define("EX_ALL_DESC", "現在のキャンペーンのすべての受信者データをエクスポートする");
    define("EX_COUNTRY_BUTTON", "受取国");
    define("EX_COUNTRY_DESC", "現在のキャンペーンのすべての国をエクスポート");
    define("EX_CITY_BUTTON", "受信者の都市");
    define("EX_CITY_DESC", "現在のキャンペーンの全都市をエクスポート");
    define("EX_BROWSER_BUTTON", "受信者のブラウザ");
    define("EX_BROWSER_DESC", "現在のキャンペーンのすべてのブラウザをエクスポートする");
    define("SETTINGS_CHARSET", "データエクスポート用の文字セットを設定する");
    define("MENU_BULK", "一括確認");
    define("B_CONFIRM", "emailable.comからの一括削除を確認します ");
    
    /*v.1.23*/
    define("RECIPIENT_CSV_UPDATE", "受信者を更新します。 データベースに電子メールアドレスがインポートされている場合は、CSVファイルのデータを使用して更新します。");
    define("TAGS_MANAGER_TITLE", "受信者タグマネージャー、選択したメール: ");
    define("TAGS_SELECT_ACTION", "アクションを選択してください:");
    define("TAGS_MANAGER_ADD", "選択した受信者にタグを追加します");
    define("TAGS_MANAGER_REMOVE", "選択した受信者からタグを削除する");
    define("TAGS_SELECT", "タグを選択してください:");
    define("SAVE_CHANGES", "変更内容を保存");
    define("NOT_SELECTED_TAGS", "最初に受信者を選択");
    define("TM_BUTTON", "一括タグマネージャー");
    define("WAITING", "待って...");
    define("MULTI_SMTP", "マルチSMTP");
    define("MULTI_CHECK_DESC", "マルチSMTP送信機能を使用したい場合はチェックしてください");
    define("MULTI_CHOOSE", "SMTPサーバーを選択する");
    
    /*V.1.25*/
    define("MENU_BLACKLIST", "ブラックリスト");
    define("BL1", "許可されていないドメインとIPのリスト");
    define("BL2", "サブスクリプションの悪意のあるアドレスをブロックしました");
    define("BL3", "あなたのブラックリスト");
    define("B_VALUE", "値");
    define("B_TYPE", "タイプ");
    define("MENU_ADD_BL", "新しいエントリを追加");
    define("B_DOMAIN", "ドメイン");
    define("B_IP", "ip");
    define("B_IMPORT_INFO", "ここでブラックリストに悪意のあるアドレスのリストをインポートできます <small>(各レコードは別々の行にある必要があります)</small>");
    define("B_DELETE_ALL", "ブラックリストをクリア");
    define("B_DELETE_QUESTION", "ブラックリスト全体を削除してもよろしいですか？");
    define("B_EXPORT", "ブラックリストをエクスポート");
    
    /*v.1.26*/
    define("DKIM_SETTINGS", "DKIM 設定");
    define("DKIM_USE", "使用する DKIM");
    define("DKIM_DOMAIN", "ドメイン名に署名する");
    define("DKIM_PRIVATE", "秘密鍵ファイルのパス");
    define("DKIM_SELECTOR", "通常、DNSTXTレコードのセレクターキーの設定");
    define("DKIM_PASS", "キーが暗号化されている場合に使用されます");
    define("DKIM_IDENTITY", "通常、電子メールの送信元として使用される電子メールアドレス");
    
    define("ERROR", "エラー:");
    define("WARNING", "警告!");
    define("D_MODE", "変更点と一部の機能はデモモードでは使用できません.");
    define("S_DIS", "購入コードを入力するまで送信は無効です");
    define("HERE", "ここに");
    define("PLIK", "ファイル");
    define("NOT_WR", "書き込み可能ではありません。 設定は保存されません。 保存する前にファイルのアクセス許可を変更する.");
    define("EPC", "Envato購入コード");
    define("EVALIDEPC", "有効な購入コードを入力してください");
    define("NO_ADMIN_MAIL", "最初に設定で管理者のメールアドレスを更新します.");
    
    define("SMTP_LABEL", "デバッグレベル");
    define("SMTP_0", "デバッグを無効にする");
    define("SMTP_1", "クライアントから送信された出力メッセージ");
    define("SMTP_2", "1として、さらにサーバーから受信した応答（これが最も便利な設定です）");
    define("SMTP_3", "2として、さらに初期接続に関する詳細情報-このレベルはSTARTTLS障害の診断に役立ちます");
    define("SMTP_4", "3として、さらに低レベルの情報、非常に冗長、SMTPのデバッグには使用せず、低レベルの問題のみ ");
    
    define("SMTP_SENDER_FORCE", "このサーバーのキャンペーンでは常にこの送信者を強制します");
    define("SMTP_SENDER_MAIL", "送信者のメールアドレス");
    define("SMTP_SENDER_DESCRIPTION", "送信者の説明");

    
    
