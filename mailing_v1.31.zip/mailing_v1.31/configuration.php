<?php

defined( '_MAILING' ) or die( 'Restricted access' );

/**
 * Configuration of the system
 *
 * just in case, for login and password you can
 * use '89e495e7941cf9e40e6980d14a16bf023ccd4c91' for 'demo'
 */
class Settings
{
    public static $loginName = '89e495e7941cf9e40e6980d14a16bf023ccd4c91';
    public static $loginPassword = '89e495e7941cf9e40e6980d14a16bf023ccd4c91';
    public static $dbHost = '';
    public static $dbUser = '';
    public static $dbPassword = '';
    public static $dbName = '';
    public static $tbPrefix = '';
    public static $limitPerHour = '1000';
    public static $systemLanguage = 'english';
    public static $enableTracking = '1';
    public static $useSMTP = '1';
    public static $afterSubscribe = '1';
    public static $afterSubscribeMessage = 'Thank you for subscribing v.1.31';
    public static $afterSubscribeRedirectTo = 'http://google.com';
    public static $afterSubscribeTags = '';
    public static $afterSubscribeComment = '';
    public static $SubscriberShowName = '0';
    public static $SubscriberShowWebsite = '0';
    public static $deleteUnsubscribed = '0';
    public static $googleMapsApiKey = '';
    public static $adminMail = '';
    public static $subscribeDblOptIn = '0';
    public static $subscribeEmailMessage = 'PGgzPkRlYXIge1NVQlNDUklCRVJfTkFNRX0sPC9oMz4NCjxwPkNsaWNrIHRvIGNvbmZpcm0geW91ciBzdWJzY3JpcHRpb246IDxhIGhyZWY9IntDT05GSVJNX0xJTkt9Ij5TVUJTQ1JJQkU8L2E+PC9wPg0KPHA+QmVzdCBSZWdhcmRzPC9wPg==';
    public static $subscribeEmailTitle = 'Confirm your subscription';
    public static $subscribeRedirectConfirmedTo = 'http://www.google.com';
    public static $subscribeEmailAddressFrom = '';
    public static $subscribeEmailDescriptionFrom = 'Subscriber Confirmer';
    public static $subscribeErrorMessage = 'wrong email address...';
    public static $adminSubscribtionNotify = '0';
    public static $adminEmailMessage = 'PHA+TmV3IHN1YnNjcmliZXI6PC9wPg0KPHA+TmFtZToge1NVQlNDUklCRVJfTkFNRX0sPC9wPg0KPHA+RW1haWw6IHtTVUJTQ1JJQkVSX0VNQUlMfSw8L3A+DQo8cD5Db21tZW50OiB7U1VCU0NSSUJFUl9DT01NRU5UfSw8L3A+DQo8cD5UYWdzOiB7U1VCU0NSSUJFUl9UQUdTfSw8L3A+';
    public static $phpTimeOutLimit = '999999';
    public static $serverEmailSenderID = '1';
    public static $systemEditor = 'tinymce';
    public static $timezone = 'Europe/London';
    public static $ipstackGeoApiKey = '';
    public static $useHTTPS = '0';
    public static $subscriptionFormToken = 'secret_token_1';
    public static $subscriptionEmailToken = 'secret_token_2';
    public static $cronToken = 'cron';
    public static $thechecker = '';
    public static $charset = 'cp1250';
    public static $ecode = '';
    public static $euser = '';
    public static $licenseDetails = '';
}
