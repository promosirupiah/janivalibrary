<?php echo '
<script>
var 
    dataTableTranslation = {
        lengthMenu: "'.DATATABLE_LENGTHMENU.'",
        zeroRecords: "'.DATATABLE_ZERORECORDS.'",
        sZeroRecords: "'.DATATABLE_ZERORECORDS.'",
        info: "'.DATATABLE_INFO.'",
        infoEmpty: "'.DATATABLE_INFOEMPTY.'",
        infoFiltered: "'.DATATABLE_INFOFILTERED.'",
        sSearch: "'.DATATABLE_SEARCH.'",
        oPaginate:{
            sFirst:"'.DATATABLE_FIRST.'",
            sLast:"'.DATATABLE_LAST.'",
            sNext:"'.DATATABLE_NEXT.'",
            sPrevious:"'.DATATABLE_PREVIOUS.'"
        }
    },
    lang_c_finished = "'.C_FINISHED.'",
    lang_campaign_please_wait = "'.CAMPAIGN_PLEASE_WAIT.'",
    lang_campaign_smtp = "'.CAMPAIGN_SMTP.'",
    lang_campaign_bg_confirm_txt = "'.CAMPAIGN_BG_CONFIRM_TXT.'",
    lang_campaign_server_connecting = "'.CAMPAIGN_SERVER_CONNECTING.'",
    lang_campaign_sending = "'.CAMPAIGN_SENDING.'",
    lang_campaign_sent = "'.CAMPAIGN_SENT.'",
    lang_jan = "'.JAN.'",
    lang_feb = "'.FEB.'",
    lang_mar = "'.MAR.'",
    lang_apr = "'.APR.'",
    lang_may = "'.MAY.'",
    lang_jun = "'.JUN.'",
    lang_jul = "'.JUL.'",
    lang_aug = "'.AUG.'",
    lang_sep = "'.SEP.'",
    lang_oct = "'.OCT.'",
    lang_nov = "'.NOV.'",
    lang_dec = "'.DEC.'",
    lang_d_prepared_overall = "'.D_PREPARED_OVERALL.'",
    lang_d_sent_overall = "'.D_SENT_OVERALL.'",
    lang_b_ver_info = "'.B_VER_INFO.'",
    lang_b_ver_in_prog = "'.B_VER_IN_PROG.'",
    lang_verify = "'.VERIFY.'",
    lang_v_working = "'.V_WORKING.'",
    lang_button_check_status = "'.BUTTON_CHECK_STATUS.'",
    lang_button_down_up = "'.BUTTON_DOWN_UP.'",
    lang_response = "'.RESPONSE.'",
    lang = "'.LANG.'",
    lang_copy = "'.COPY.'",
    lang_bridge_fill_fields = "'.BRIDGE_FILL_FIELDS.'",
    lang_bridge_import_in_progress = "'.BRIDGE_IMPORT_IN_PROGRESS.'"
;
</script>
';