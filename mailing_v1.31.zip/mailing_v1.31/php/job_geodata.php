<?php

defined('_MAILING') or die('Restricted access');

//ob_end_clean();
//header("Connection: close");
ignore_user_abort();
//ob_start();
//echo ('&nbsp;');
//$size = ob_get_length();
//header("Content-Length: $size");
//ob_end_flush();
flush();


// BELOW BACKGROUND JOB/CODE

// get geodata
//$url = "http://freegeoip.net/json/".$_SERVER["REMOTE_ADDR"];

if (Settings::$ipstackGeoApiKey != '') {
    $url = "http://api.ipstack.com/".$_SERVER["REMOTE_ADDR"]."?access_key=".Settings::$ipstackGeoApiKey;

    // backup service for future use, just in case
    //$url2 = "http://www.geoplugin.net/php.gp?ip=".$ip;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL,$url);
    $result = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($result, true);

    try {

        $user_agent = substr($_SERVER["HTTP_USER_AGENT"], 0, 1000);
        $ip_receiver = $json['ip'];
        $country_code = $json['country_code'];
        $country_name = $json['country_name'];
        $region = '';
        $region_code = $json['region_code'];
        $region_name = $json['region_name'];
        $continent_code = '';
        $city = $json['city'];
        //$zip_code = $json['zip_code'];
        //$time_zone = $json['time_zone'];
        $latitude = $json['latitude'];
        $longitude = $json['longitude'];
        //$metro_code = $json['metro_code'];
        $currency_code = '';
        
        $sql = "
            INSERT INTO ".PREF."_geolocation (
                ip_receiver,
                user_agent,
                city,
                region,
                country_code,
                country_name,
                continent_code,
                latitude,
                longitude,
                region_code,
                region_name,
                currency_code
            ) VALUES (
                :ip_receiver,
                :user_agent,
                :city,
                :region,
                :country_code,
                :country_name,
                :continent_code,
                :latitude,
                :longitude,
                :region_code,
                :region_name,
                :currency_code
            )
        ";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':ip_receiver', $ip_receiver, PDO::PARAM_STR);
        $stmt->bindParam(':user_agent', $user_agent, PDO::PARAM_STR);
        $stmt->bindParam(':city', $city, PDO::PARAM_STR);
        $stmt->bindParam(':region', $region, PDO::PARAM_STR);
        $stmt->bindParam(':country_code', $country_code, PDO::PARAM_STR);
        $stmt->bindParam(':country_name', $country_name, PDO::PARAM_STR);
        $stmt->bindParam(':continent_code', $continent_code, PDO::PARAM_STR);
        $stmt->bindParam(':latitude', $latitude, PDO::PARAM_STR);
        $stmt->bindParam(':longitude', $longitude, PDO::PARAM_STR);
        $stmt->bindParam(':region_code', $region_code, PDO::PARAM_STR);
        $stmt->bindParam(':region_name', $region_name, PDO::PARAM_STR);
        $stmt->bindParam(':currency_code', $currency_code, PDO::PARAM_STR);
        $stmt->execute();

    } catch (PDOException $e) {
        @mail($email_to, "ERROR", $e->getMessage());
    }
}





