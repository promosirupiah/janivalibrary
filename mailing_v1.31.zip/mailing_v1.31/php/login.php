<?php

defined('_MAILING') or die('Restricted access');

$komunikat = "&nbsp;";
$login = $_POST['login'] ?? '';
$pass = $_POST['password'] ?? '';

if (isset($_POST['login']) && isset($_POST['password'])) {
    if ($_POST['secure_login'] != $_SESSION['secure_login']) {
        die("access denied");
    }
    if (
    (md5($login) == Settings::$loginName || sha1($login) == Settings::$loginName || hash('sha256', $login) == Settings::$loginName || hash('sha512', $login) == Settings::$loginName)
    &&
    (md5($pass) == Settings::$loginPassword || sha1($pass) == Settings::$loginPassword || hash('sha256', $pass) == Settings::$loginPassword || hash('sha512', $pass) == Settings::$loginPassword)
    ) {
        $_SESSION['admin'] = 'true';
        $_SESSION['csrf_token'] = sha1((date("r")).rand());
        $app = new Emailer();
        $app->checkCode(Settings::$ecode);
        if ($app->checkedEcode()) {
            echo "<script> window.location.replace('index.php');</script>";
        } else {
            echo "<script> window.location.replace('install.php');</script>";
        }
    } else {
        $komunikat = LOGIN_FAILED;
    }
}

$csrf_token = date("YmdHis");

$_SESSION['secure_login'] = $csrf_token;

?><!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo LOGIN_TITLE;?></title>
        <link rel="stylesheet" type="text/css" href="production/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="production/css/login.css" />
    </head>
    <body>
        <div class="container">
          <form class="form-signin" method="post">
            <input type="hidden" name="secure_login" value="<?php echo $csrf_token;?>" >
            <h2 class="form-signin-heading"><?php echo LOGIN_SIGN_IN;?></h2>
            <label for="inputLogin" class="sr-only"><?php echo LOGIN;?></label>
            <input name="login" type="text" id="inputLogin" class="form-control" placeholder="<?php echo LOGIN;?>" required autofocus>
            <label for="inputPassword" class="sr-only"><?php echo LOGIN_PASS;?></label>
            <input name="password" type="password" id="inputPassword" class="form-control" placeholder="<?php echo LOGIN_PASS;?>" required>
            <div class="checkbox">
              <p><?php echo $komunikat;?></p>
            </div>
            <button class="btn btn-lg btn-primary btn-block" type="submit"><?php echo LOGIN_SIGN_IN_BUTTON;?></button>
          </form>
        </div>
    </body>
</html>