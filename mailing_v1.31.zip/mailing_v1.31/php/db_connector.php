<?php

defined('_MAILING') or die('Restricted access');

// CUBRID (PDO) docs http://php.net/manual/en/ref.pdo-cubrid.php
//$dsn = "cubrid:dbname=".Settings::$dbName.";host=".Settings::$dbHost.";";

$dsn = "mysql:dbname=".Settings::$dbName.";host=".Settings::$dbHost.";";
try {
    @$db = new PDO($dsn, Settings::$dbUser, Settings::$dbPassword);
} catch (PDOException $e) {
    $_SESSION['e'] = "Connection error: ".$e->getMessage();
    ?><html><head></head><body><script> location.href = "install.php?e=error"; </script></body></html><?php
    exit();
}

$db->query(" SET NAMES utf8mb4; ");
$db->query(" SET sql_mode='STRICT_ALL_TABLES'; ");
