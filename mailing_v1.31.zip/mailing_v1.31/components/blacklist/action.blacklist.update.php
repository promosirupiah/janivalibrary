<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=blacklist&action=list");
    exit();
}

$app->checkToken();

try {
    $value = $_POST['blacklistvalue'];
    $type = $_POST['blacklisttype'];
    $id = (int)$_POST['id'];

    $sql = "
        UPDATE ".PREF."_blacklist SET 
            value = :value,
            type = :type
        WHERE
            id = :id
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':value', $value, PDO::PARAM_STR);
    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: index.php?manage=blacklist&action=list");
        
} catch (Exception $e) {
    echo 'ERROR: ',  $e->getMessage(), "\n";
}
