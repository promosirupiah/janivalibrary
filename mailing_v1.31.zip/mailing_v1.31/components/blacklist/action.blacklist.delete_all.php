<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=blacklist&action=list");
    exit();
}

$app->checkToken();

try {
    $sql = " truncate table ".PREF."_blacklist ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    
    header("Location: index.php?manage=blacklist&action=list");
    
} catch (Exception $e) {
    echo 'ERROR: ',  $e->getMessage(), "\n";
}
