<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=blacklist&action=list");
    exit();
}

$app->checkToken();

try {
    $value = $_POST['blacklistvalue'];
    $type = (int) $_POST['blacklisttype'];

    $sql = "
        INSERT INTO ".PREF."_blacklist (
            value,
            type
        ) VALUES (
            :value,
            :type
        )
    ";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':value', $value, PDO::PARAM_STR);
    $stmt->bindParam(':type', $type, PDO::PARAM_INT);
    $stmt->execute();

    $id = $db->lastInsertId();

    header("Location: index.php?manage=blacklist&action=list");
    
} catch (Exception $e) {
    echo 'ERROR: ',  $e->getMessage(), "\n";
}