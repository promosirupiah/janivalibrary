<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$blacklist_head = '';
$blacklist_body = '';

$result = $db->query("
    select * from ".PREF."_blacklist
");

$blacklist_head .= "<tr><th>#</th><th>".B_VALUE."</th><th>".B_TYPE."</th><th></th></tr>";

foreach ($result as $row) {
    $i++;
    $blacklist_body .= "<tr>
        <td>".$i."</td>
        <td><a href='index.php?manage=blacklist&action=edit&id=".$row['id']."'>".$row['value']."</a></td>
        <td>".($row['type'] == 1 ? B_DOMAIN : B_IP)."</td>
        <td>
            <button type='button' class='btn btn-danger btn-xs pull-right' data-toggle='modal' data-target='#blacklistDelete' data-blacklistvalue='".$row['value']."' data-blacklisttype='".($row['type'] == 1 ? B_DOMAIN : B_IP)."' data-id='".$row['id']."' >".DELETE."</button>
            <a class='btn btn-warning btn-xs pull-right' href='index.php?manage=blacklist&action=edit&id=".$row['id']."'>".EDIT."</a>
        </td>
    </tr>";
}

?>

<div class="modal fade" id="blacklistDelete" tabindex="-1" role="dialog" aria-labelledby="blacklistDeleteLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="blacklistDeleteLabel"><?php echo DELETING; ?></h4>
        </div>
        <form action="index.php?manage=blacklist&data=modify&action=delete" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
            <div class="modal-body">
                <input type="hidden" name="id" class="id" value="">
                <div class="form-group">
                    <label for="blacklistvalue" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                    <input type="text" class="form-control blacklistvalue" disabled>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="modal fade" id="confirmBlacklistDelete" tabindex="-1" role="dialog" aria-labelledby="confirmBlacklistDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="confirmBlacklistDeleteLabel"><?php echo B_DELETE_ALL; ?></h4>
            </div>
            <form action="index.php?manage=blacklist&data=modify&action=delete_all" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="campaignname" class="control-label"><?php echo B_DELETE_QUESTION; ?></label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo BL1;?> <small>(<?php echo BL2;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo BL3;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <p>
                <form id="blacklist_list_form" action="index.php?manage=statistics&action=export" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <input type="hidden" name="adata" value="1">
                    <input type="hidden" name="type" value="blacklist">
                    <input type="submit" value="<?php echo B_EXPORT; ?>" class="btn btn-warning btn-xs">
                <a id="clear_blacklist" class="btn btn-danger btn-xs pull-right" data-toggle='modal' data-target='#confirmBlacklistDelete' ><?php echo B_DELETE_ALL; ?></a>
                </form>
                <a href="index.php?manage=blacklist&action=add" class="btn btn-primary"><?php echo MENU_ADD_BL;?></a>
                </p>
                <table class="table table-striped responsive-utilities jambo_table" id="blacklist">
                    <thead>
                        <?php echo $blacklist_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $blacklist_body; ?>
                    </tbody>
                </table>
            </div>
            
            <hr>
            
            <h4><?php echo B_IMPORT_INFO;?></h4>

            <form class="form-inline" method="post" enctype="multipart/form-data" action="index.php?manage=blacklist&data=modify&action=import">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="row">
                    <div class="">
                        <label class="col-sm-1 control-label" for="blacklisttype"><?php echo B_TYPE;?>*</label>
                        <div class="col-sm-1">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="1" type="radio" name="blacklisttype" class="flat" checked="checked">
                                    <ins class="iCheck-helper"></ins>
                                </div> <?php echo B_DOMAIN;?>
                                </label>
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="2" type="radio" name="blacklisttype" class="flat">
                                    <ins class="iCheck-helper">
                                    </ins></div> <?php echo B_IP;?>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <p>&nbsp;</p>
                <label for="upload"><?php echo RECIPIENT_UPLOAD_CSV_NAME;?></label>
                <div class="input-group">
                    <span class="input-group-btn">
                        <span class="btn btn-primary btn-file">
                            <?php echo MEDIA_BROWSE;?> <input id="upload" class="form-control input-sm" name="file" type="file" size="100" placeholder=""/>
                        </span>
                    </span>
                    <input id="upload_info" type="text" readonly="" class="form-control">
                </div><button id="blacklist_list_submit" type="submit" class="btn btn-primary"><?php echo MEDIA_UPLOAD;?></button>
            </form>
            
        </div>
    </div>
</div>
<script src="components/blacklist/view.blacklist.list.js"></script>
