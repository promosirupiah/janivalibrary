"use strict";

$(document).ready(function(){
    
    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    $('#blacklist').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });
    
    $('#blacklistDelete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var blacklistvalue = button.data('blacklistvalue');
        var blacklisttype = button.data('blacklisttype');
        var id = button.data('id');
        var modal = $(this);
        modal.find('.blacklistvalue').val(blacklistvalue + ' (' + blacklisttype + ') ' );
        modal.find('.id').val(id);
    });
    
    $(document).on('change', '.btn-file :file', function() {
        var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [numFiles, label]);
    });
    
    $('.btn-file :file').on('fileselect', function(event, numFiles, label) {
         $('#upload_info').val(label);
    });
    
});