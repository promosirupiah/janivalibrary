<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.blacklist.add.php";
        break;
    case "edit":
        $load = "view.blacklist.edit.php";
        break;
    case "list":
        $load = "view.blacklist.list.php";
        break;
    case "update":
        $load = "action.blacklist.update.php";
        break;
    case "insert":
        $load = "action.blacklist.insert.php";
        break;
    case "delete":
        $load = "action.blacklist.delete.php";
        break;
    case "import":
        $load = "action.blacklist.import.php";
        break;
    case "delete_all":
        $load = "action.blacklist.delete_all.php";
        break;
    default:
        $load = "view.blacklist.list.php";
        break;
}

include($load);	
