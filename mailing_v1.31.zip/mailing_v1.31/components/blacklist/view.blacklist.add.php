<?php

defined('_MAILING') or die('Restricted access');

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo BL1;?> <small>(<?php echo BL2;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo MENU_ADD_BL;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" action="index.php?manage=blacklist&data=modify&action=insert" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <div class="form-group">
                        <label for="blacklistvalue" class="col-sm-2 control-label"><?php echo B_VALUE;?>*</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="blacklistvalue" 
                                name="blacklistvalue" 
                                placeholder="<?php echo MENU_ADD_BL;?>"
                                required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="blacklisttype"><?php echo B_TYPE;?>*</label>
                        <div class="col-sm-6">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="1" type="radio" name="blacklisttype" class="flat" checked="checked">
                                    <ins class="iCheck-helper"></ins>
                                </div> <?php echo B_DOMAIN;?>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="blacklisttype"></label>
                        <div class="col-sm-4">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="2" type="radio" name="blacklisttype" class="flat">
                                    <ins class="iCheck-helper"></ins></div> <?php echo B_IP;?>
                                </label>
                            </div>
                        </div>
                    </div>
                    <p>&nbsp;</p>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <a href="index.php?manage=blacklist&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-3 col-sm-1">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="components/blacklist/view.blacklist.flat.js"></script>
