<?php

defined('_MAILING') or die('Restricted access');

$id_campaign = (int)$_GET['id'];
$recipient_status = isset($_GET['recipient_status']) ? $_GET['recipient_status'] : 0;

/*all data*/
if ($recipient_status == '0') {
    $recipient_status_sql = "";
    $recipient_status_txt = "all recipients";
}
/*sent*/
if ($recipient_status == '1') {
    $recipient_status_sql = " AND crc.status = '1' ";
    $recipient_status_txt = "not yet opened";
}
/*opened (and unsubscribed)*/
if ($recipient_status == '2') {
    $recipient_status_sql = " AND crc.status IN('2', '3') ";
    $recipient_status_txt = "opened";
}
/*not opened yet*/
if ($recipient_status == '3') {
    $recipient_status_sql = " AND crc.status = '3' ";
    $recipient_status_txt = "unsubscribed only";
}

?>
<div class="page-title">
  <div class="title_left">
    <h3><?php echo MENU_CAMPAIGNS;?> <small>(<?php echo CAMPAIGN_PREPARE;?>)</small></h3>
  </div>
</div>
<div class="clearfix"></div>

<div data-example-id="togglable-tabs" role="tabpanel" class="">
    <ul role="tablist" class="nav nav-tabs bar_tabs" id="myTab">
        <li class="active" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab" role="tab" href="#tab_content2"><?php echo CAMPAIGN_STEP_1;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab2" role="tab" href="#tab_content3"><?php echo CAMPAIGN_STEP_2;?></a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">

        <div aria-labelledby="profile-tab" id="tab_content2" class="tab-pane fade active in" role="tabpanel">
            <?php include("view.statistics.special.campaign.tab.recipients.php");?>
        </div>
        <div aria-labelledby="profile-tab" id="tab_content3" class="tab-pane fade" role="tabpanel">
            <?php include("view.statistics.special.campaign.tab.confirm.php");?>
        </div>
    </div>
</div>

<script src="components/statistics/statistics.campaign.prepare.js"></script>
