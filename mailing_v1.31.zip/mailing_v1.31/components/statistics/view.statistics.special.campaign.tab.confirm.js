"use strict";

$(document).ready(function(){
    $('#template_name').on('change update', function(){
        var img;
        img = $('option:selected', this).attr('data-imagesrc');
        if (img === undefined) {
            img = 'uploads/no-picture.png';
        }
        $('#layoutPicture').attr('src', img);
    });
});