<?php

$result = $db->query("
    SELECT * 
    FROM 
        ".PREF."_campaign_rec_conn as crc 
    LEFT JOIN ".PREF."_geolocation as g ON(crc.ip_receiver = g.ip_receiver)
    LEFT JOIN ".PREF."_recipient as r ON(r.id = crc.id_recipient)
    WHERE 1 
        and crc.id_campaign = '".$campaign_id."'
        and crc.status IN('2','3')
    ");

$markers = '';
$i = 0;

foreach ( $result as $row ) {
    if ( $row['latitude'] !='' && $row['longitude'] !='' ) {
        $i++;
        $id_recipient   = clearWater($row['id_recipient']);
        $person         = clearWater($row['person']);
        $email          = clearWater($row['email']);
        $country_name   = clearWater($row['country_name']);
        $region_name    = clearWater($row['region_name']);
        $person         = clearWater($row['person']);
        
        if ( $row['latitude'] !='' && $row['longitude'] !='' ) {
            $markers .= "
                var marker_".$i." = new google.maps.Marker({
                  position: {lat: ".$row['latitude'].", lng: ".$row['longitude']."},
                  map: map
                });
                var infowindow_".$i." = new google.maps.InfoWindow({
                    content: '<h4><a href=\'index.php?manage=recipient&action=edit&id=".$id_recipient."\' target=\'_blank\'>".$person."</a></h4><p>".$email."<br>".$country_name." / ".$region_name."</p>',
                    title: '".$person."'
                });
                marker_".$i.".addListener('click', function() {
                    infowindow_".$i.".open(map, marker_".$i.");
                });
                
            ";
        }
    }
}
function clearWater($txt)
{
    $txt = str_replace("'", "", $txt);
    $txt = str_replace('"', '', $txt);
    $txt = str_replace('/', '', $txt);
    $txt = str_replace('\\','', $txt);
    return $txt;
}
?>
<div id="map"></div>
<script>
  function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 2,
      scrollwheel: false,
      center: {lat: 20, lng: 0}
    });
    <?php echo $markers; ?>
  }
</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo Settings::$googleMapsApiKey; ?>&callback=initMap"></script>

