<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "getlist":
        $load = "action.statistics.special.campaign.getlist.php";
        break;
    case "insert":
        $load = "action.statistics.special.campaign.insert.php";
        break;
    case "details":
        $load = "view.statistics.details.php";
        break;
    case "special.campaign":
        $load = "view.statistics.special.campaign.prepare.php";
        break;
    case "export":
        $load = "action.statistics.export.php";
        break;
    default:
        $load = "view.statistics.php";
        break;
}

include($load);	
