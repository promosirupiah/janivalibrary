<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$campaign_list = '';
$campaign_id = (int)($_GET['id']);

/*template name*/
$stmt = $db->query(" SELECT id_template, name FROM ".PREF."_campaign WHERE id='".$campaign_id."' ");
$stmt->execute();
$row = $stmt->fetchAll();

// in case you want to edit not existent data
if (! @$data = $row[0]){
    echo DATA_ERROR;
    exit();
}

$template_name = $row[0]['name'];
$template_id = $row[0]['id_template'];


$result = $db->query("
    SELECT
        c.id,
        c.name,
        c.recipient_qty,
        status,
        date_create,
        date_start,
        (
            SELECT count(crc.id_recipient) FROM ".PREF."_campaign_rec_conn AS crc WHERE crc.id_campaign = c.id and crc.status IN('2','3')
        ) AS receivers,
        (
            SELECT count(crc.id_recipient) FROM ".PREF."_campaign_rec_conn AS crc WHERE crc.id_campaign = c.id and crc.bounced='1'
        ) AS bounced,
        (
            SELECT count(crc.clicked) FROM ".PREF."_campaign_rec_conn AS crc WHERE crc.id_campaign = c.id and crc.clicked != '0'
        ) AS clicked,
        (
            SELECT sum(crc.clicked) FROM ".PREF."_campaign_rec_conn AS crc WHERE crc.id_campaign = c.id
        ) AS clicks,
        (
            SELECT count(crc.id_recipient) FROM ".PREF."_campaign_rec_conn AS crc WHERE crc.id_campaign = c.id and crc.status='3'
        ) AS unsubscribers,
        (
            SELECT count(crc.id_recipient) FROM ".PREF."_campaign_rec_conn AS crc WHERE crc.id_campaign = c.id and crc.status='4'
        ) AS errors,
        (
            SELECT t.thumb_filename FROM ".PREF."_template AS t WHERE t.id = c.id_template
        ) AS filename
    FROM 
        ".PREF."_campaign AS c
    WHERE
        c.id = '".$campaign_id."'
    ORDER BY id DESC
");

foreach ($result as $row) {
    $i++;
    
    $thumb_filename = $row['filename'] !='' ? $row['filename'] : 'no-picture.png';
    
    $number = ((int)($row['receivers']) / (int)($row['recipient_qty'])) * 100;
    $number = number_format($number, 2, ',', '');
    $number2 = ((int)($row['bounced']) / (int)($row['recipient_qty'])) * 100;
    $number2 = number_format($number2, 2, ',', '');
    $number3 = ((int)($row['clicked']) / (int)($row['recipient_qty'])) * 100;
    $number3 = number_format($number3, 2, ',', '');
    $number4 = ((int)($row['unsubscribers']) / (int)($row['recipient_qty'])) * 100;
    $number4 = number_format($number4, 2, ',', '');
    
    $campaign_rec_qty = $row['recipient_qty'];
    $campaign_opens_qty = $row['receivers'];
    $campaign_bounced_qty = $row['bounced'];
    $campaign_clicked_qty = $row['clicked'];
    $campaign_total_clicks_qty = $row['clicks'];
    $campaign_unsubscribers_qty = $row['unsubscribers'];
    $campaign_date_create = $row['date_create'];
    $campaign_date_start = $row['date_start'];
    $campaign_name = $row['name'];
    
    $campaign_list .= '
            <h2>'.$campaign_name.'</h2>
            <a type="button" href="index.php?manage=campaign&action=sent" class="btn btn-primary btn-xs pull-right">'.STATISTICS_BACK.'</a>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">

            <div class="col-md-2">
                <div>'.CAMPAIGN_RECIPIENT_QTY.': '.$campaign_rec_qty.'</div>
                <div>'.OPENS.': '.$campaign_opens_qty.'</div>
                <div>'.BOUNCED.': '.$campaign_bounced_qty.'</div>
                <div>'.UNIQUE_CLICKS.': '.$campaign_clicked_qty.'</div>
                <div>'.TOTAL_CLICKS.': '.$campaign_total_clicks_qty.'</div>
                <div>'.D_EMAIL_UNSUBSCIBERS.': '.$campaign_unsubscribers_qty.'</div>
                <div>'.CAMPAIGN_CREATED_DATE.': '.substr($campaign_date_create, 0, 10).'</div>
                <div>'.SENT.': '.substr($campaign_date_start, 0, 10).'</div>
                <div>'.ERRORS.': '.$row['errors'].'</div>

            </div>
            <div class="col-md-2">
                <p>'.OPENS.'</p>
                <div class="pie_div">
                    <span class="chart" data-percent="'.$number.'"><span class="percent"></span></span>
                </div>
                <div class="pie_bg">
                    <canvas id="canvas_doughnut" height="130"></canvas>
                </div>
            </div>
            <div class="col-md-2">
                <p>'.BOUNCED.'</p>
                <div class="pie_div">
                    <span class="chart" data-percent="'.$number2.'"><span class="percent"></span></span>
                </div>
                <div class="pie_bg">
                    <canvas id="canvas_doughnut" height="130"></canvas>
                </div>
            </div>
            <div class="col-md-2">
                <p>'.CLICKED.'</p>
                <div class="pie_div">
                    <span class="chart" data-percent="'.$number3.'"><span class="percent"></span></span>
                </div>
                <div class="pie_bg">
                    <canvas id="canvas_doughnut" height="130"></canvas>
                </div>
            </div>
            <div class="col-md-2">
                <p>'.D_EMAIL_UNSUBSCIBERS.'</p>
                <div class="pie_div">
                    <span class="chart" data-percent="'.$number4.'"><span class="percent"></span></span>
                </div>
                <div class="pie_bg">
                    <canvas id="canvas_doughnut" height="130"></canvas>
                </div>
            </div>
            <div class="col-md-2">
                <p><button type="button" class="btn btn-danger btn-xs pull-right" data-toggle="modal" data-target="#campaignDelete" data-campaignname="'.$campaign_name.'" data-campaignid="'.$campaign_id.'" >'.DELETE.'</button></p>
                <p class="mini_thumb"><img src="uploads/'.$thumb_filename.'"></p>
            </div>
            <div class="clearfix"></div>
    
    ';
    
     
    
}

?>

<div class="modal fade" id="campaignDelete" tabindex="-1" role="dialog" aria-labelledby="campaignDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="campaignDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=campaign&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" name="back_to_sent" value="1">
                <div class="modal-body">
                    <input type="hidden" name="campaignid" class="campaignid" value="">
                    <div class="form-group">
                        <label for="campaignname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control campaignname" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="page-title">
  <div class="title_left">
    <h3><?php echo MENU_CAMPAIGNS;?> <small>(<?php echo MENU_CAMPAIGNS_SENT;?>)</small></h3>
  </div>
</div>
<div class="clearfix"></div>


<div data-example-id="togglable-tabs" role="tabpanel" class="">
    <ul role="tablist" class="nav nav-tabs bar_tabs" id="myTab">
        <li class="active" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab" role="tab" href="#tab_content1"><?php echo STATISTICS_TAB_MAP;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab2" role="tab" href="#tab_content2"><?php echo STATISTICS_TAB_DETAILS;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab3" role="tab" href="#tab_content3"><?php echo STATISTICS_TAB_ACTIONS;?></a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">

        <div aria-labelledby="profile-tab" id="tab_content1" class="tab-pane fade active in" role="tabpanel">
            <div class="clearfix"></div>
            <div>
                <div class="x_panel">
                    <div class="x_title bg-custom">
                        <div class="x_title">
                            <h2><?php echo $campaign_name; ?></h2>
                            <a type="button" href="index.php?manage=campaign&action=sent" class="btn btn-primary btn-xs pull-right"><?php echo STATISTICS_BACK;?></a>
                            <div class="clearfix"></div>
                        </div>
                        <div ><?php include('view.statistics.googlemaps.php'); ?></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <p>&nbsp;</p>
        </div>
        
        <div aria-labelledby="profile-tab" id="tab_content2" class="tab-pane fade" role="tabpanel">
            <div class="x_panel">
                <div class="x_title bg-custom">
                    <h2><?php echo $campaign_name; ?></h2>
                            <a type="button" href="index.php?manage=campaign&action=sent" class="btn btn-primary btn-xs pull-right"><?php echo STATISTICS_BACK;?></a>
                    <div class="clearfix"></div>
                </div>
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td>
                                <?php 
                                echo '<h4><img src="uploads/'.$thumb_filename.'">&nbsp;'.CAMPAIGN_CREATED_DATE.': '.substr($campaign_date_create, 0, 10).' / '.
                                SENT.': '.substr($campaign_date_start, 0, 10).' / '.TEMPLATES_NAME.': <a href="index.php?manage=templates&action=edit&id='.$template_id.'" target="_blank">'.$template_name.'</a></h4>'; 
                                ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            <!--<p>
                <b>Export campaign data: </b>
                <a class="btn btn-primary btn-xs" >All records</a>
                <a class="btn btn-primary btn-xs" >Countries</a>
                <a class="btn btn-primary btn-xs" >Clickers</a>
                <a class="btn btn-primary btn-xs" >Browsers</a>
                <a class="btn btn-primary btn-xs" >Cities</a>
                <a class="btn btn-primary btn-xs" >Recipients</a>
            </p>-->
            </div>
            <?php include('view.statistics.charts.php'); ?>
        </div>
        
        <div aria-labelledby="profile-tab" id="tab_content3" class="tab-pane fade" role="tabpanel">
            <div class="x_panel">
              <div class="x_title bg-custom">
                <?php echo $campaign_list; ?>
              </div>
            </div>

            <div class="x_panel tile ">
                <div class="x_title">
                    <h2><?php echo STATISTICS_TAB_ACTIONS;?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <td class="w300"><a class="btn btn-primary btn-xs" href="index.php?manage=statistics&action=special.campaign&id=<?php echo $campaign_id; ?>&recipient_status=2"><?php echo STATISTICS_BUTTON_OPENERS;?></a></td>
                                <td><?php echo STATISTICS_BUTTON_OPENERS_INFO;?></td>
                            </tr>
                            <tr>
                                <td><a class="btn btn-primary btn-xs" href="index.php?manage=statistics&action=special.campaign&id=<?php echo $campaign_id; ?>&recipient_status=1"><?php echo STATISTICS_BUTTON_NOT_OPENERS;?></a></td>
                                <td><?php echo STATISTICS_BUTTON_NOT_OPENERS_INFO;?></td>
                            </tr>
                            <tr>
                                <td><a class="btn btn-primary btn-xs" href="index.php?manage=statistics&action=special.campaign&id=<?php echo $campaign_id; ?>&recipient_status=3"><?php echo STATISTICS_BUTTON_UNSUBSCRIBED;?></a></td>
                                <td><?php echo STATISTICS_BUTTON_UNSUBSCRIBED_INFO;?></td>
                            </tr>
                            <tr>
                                <td><a class="btn btn-primary btn-xs" href="index.php?manage=statistics&action=special.campaign&id=<?php echo $campaign_id; ?>&recipient_status=0"><?php echo STATISTICS_BUTTON_FILTERS;?></a></td>
                                <td><?php echo STATISTICS_BUTTON_FILTERS_INFO;?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="x_panel tile ">
                <div class="x_title">
                    <h2><?php echo EC_DATA1; ?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <td class="w300">
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="open">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_OPENED_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_OPENED_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="not-open">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_NOT_OPENED_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_NOT_OPENED_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="unsubscribed">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_UNSUBSRIBED_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_UNSUBSRIBED_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="clicked">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_CLICKED_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_CLICKED_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="all">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_ALL_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_ALL_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="country">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_COUNTRY_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_COUNTRY_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="city">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_CITY_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_CITY_DESC; ?></td>
                            </tr>
                            <tr>
                                <td>
                                <form action="index.php?manage=statistics&action=export" method="post">
                                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                                    <input type="hidden" name="adata" value="1">
                                    <input type="hidden" name="type" value="browser">
                                    <input type="hidden" name="id_campaign" value="<?php echo $campaign_id;?>">
                                    <input type="submit" value="<?php echo EX_BROWSER_BUTTON; ?>" class="btn btn-primary btn-xs">
                                </form>
                                </td>
                                <td><?php echo EX_BROWSER_DESC; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
        
    </div>
</div>

<script src="components/statistics/view.statistics.js"></script>
