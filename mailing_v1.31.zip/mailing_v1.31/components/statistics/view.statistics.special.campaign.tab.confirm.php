<?php

defined('_MAILING') or die('Restricted access');

$sender_select = "<option value=''>".CAMPAIGN_FORM_SELECT."</option>";
$template_select = "<option value='' style='background-image:url(uploads/no-picture.png); '>".CAMPAIGN_FORM_SELECT."</option>";

$result = $db->query(" SELECT * FROM ".PREF."_sender ORDER BY name ASC ");
foreach ($result as $row) {
    $sender_select .= "<option value='".$row['id']."'>".$row['name']." (".$row['email'].")</option>";
}

$result = $db->query(" 
    SELECT t.id, t.name, t.subject, t.thumb_filename AS filename FROM ".PREF."_template AS t ORDER BY name ASC 
    ");
foreach ($result as $row) {
    $thumb_filename = $row['filename'] != '' ? $row['filename'] : 'no-picture.png';
    $template_select .= "<option data-imagesrc='uploads/".$thumb_filename."' value='".$row['id']."' style='background-image:url(uploads/".$thumb_filename."); '>".$row['name']." (".$row['subject'].")</option>";
}

?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo CAMPAIGN_CONFIRM;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" id="campaignForm">
                    <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $app->getToken();?>">
                    <input type="hidden" name="id_campaign" id="id_campaign" value="<?php echo $id_campaign;?>">
                    <input type="hidden" name="recipient_status" id="recipient_status" value="<?php echo $recipient_status;?>">
                    <div class="form-group">
                        <label for="campaign_name" class="col-sm-2 control-label"><?php echo CAMPAIGN_NAME;?>*</label>
                        <div class="col-sm-5">
                                <input 
                                type="text" 
                                class="form-control" 
                                id="campaign_name" 
                                name="campaign_name" 
                                placeholder="<?php echo CAMPAIGN_NAME_PLACEHOLDER;?>"
                                required
                            >
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="recipient_qty" class="col-sm-2 control-label"><?php echo CAMPAIGN_RECIPIENT_QTY;?>*</label>
                        <div class="col-sm-2">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipient_qty" 
                                name="recipient_qty" 
                                placeholder="0"
                                required
                                disabled
                            >
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="template_name" class="col-sm-2 control-label"><?php echo CAMPAIGN_TEMPLATE_NAME;?>*</label>
                        <div class="col-sm-5">
                            <select class="form-control" name="template_name" id="template_name" required>
                                <?php echo $template_select; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="template_name" class="col-sm-2 control-label"></label>
                        <div class="col-sm-5">
                            <img id="layoutPicture" src="uploads/no-picture.png">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="sender_name" class="col-sm-2 control-label"><?php echo CAMPAIGN_SENDER;?>*</label>
                            <div class="col-sm-5">
                            <select class="form-control" name="sender_name" required>
                                <?php echo $sender_select; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="saveCampaign" class="col-sm-2 control-label"></label>
                        <div class="col-sm-5">
                            <button type="submit" class="btn btn-primary" id="saveCampaign"><?php echo CAMPAIGN_CONFIRM; ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="components/statistics/view.statistics.special.campaign.tab.confirm.js"></script>
