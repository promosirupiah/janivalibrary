<?php

defined('_MAILING') or die('Restricted access');

include("view.html.php");
