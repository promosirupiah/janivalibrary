<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=addons&action=import_templates&ok");
    exit();
}

$app->checkToken();

// set path for images
$example_path = HTTP."://".$_SERVER['SERVER_NAME'].dirname($_SERVER['SCRIPT_NAME'])."/images";

// get table with templates data
include('components/addons/example_templates.php');

// insert templates to database
foreach ($templates as $name => $layout) {
    $sql = "
        INSERT INTO ".PREF."_template (
            date_create,
            date_modify,
            name,
            doctype,
            subject,
            html_header,
            body_attribs,
            content_html,
            content_txt,
            thumb_filename
        ) VALUES (
            '2000-01-01 00:00:01',
            '2000-01-01 00:00:01',
            '".$name."',
            '!DOCTYPE html',
            'Dear Sirs! 😷',
            '<title>".$name."</title>',
            'class=\"myClass\"',
            '".$layout[1]."',
            'This is HTML version, please turn on HTML view.',
            '".$layout[0]."'
        );
    ";
    $stmt = $db->prepare($sql);              
    $stmt->execute(); 
}

// insert thumbnails data
$sql = "
    INSERT INTO ".PREF."_template_thumb (filename) VALUES
    ('rwd-free-template.jpg'),
    ('tempo-by-kevin.jpg'),
    ('wooshi-by-kevin.jpg'),
    ('simples.jpg'),
    ('underscore.jpg'),
    ('nexit.jpg'),
    ('minty.jpg'),
    ('tubor.jpg'),
    ('kids.jpg'),
    ('tripnews.jpg'),
    ('email.jpg'),
    ('businesstemplate.jpg'),
    ('roselle.jpg'),
    ('cantino.jpg'),
    ('vanessa.jpg'),
    ('suplements.jpg'),
    ('university.jpg'),
    ('perfume.jpg'),
    ('financial.jpg'),
    ('woman.jpg'),
    ('nature.jpg'),
    ('hosting.jpg'),
    ('life.jpg'),
    ('spa.jpg'),
    ('lastminute.jpg'),
    ('office.jpg'),
    ('vipticket.jpg'),
    ('press.jpg'),
    ('cosmetics.jpg'),
    ('christmas.jpg');
";
$stmt = $db->prepare($sql);              
$stmt->execute(); 

header("Location: index.php?manage=addons&action=import_templates&ok");
