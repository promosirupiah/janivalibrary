<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SPECIALS;?> <small>(<?php echo MENU_IMPORT_TEMPLATES;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <?php
    if (isset($_GET['ok'])) {
    ?>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div role="alert" class="alert alert-success alert-dismissible fade in">
                <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                <?php echo CHANGES_SAVED;?>
            </div>
        </div>
    <?php
    }
    ?>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo ADDONS_IMPORT_TITLE;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <p>&nbsp;</p>
                <p><a class="btn btn-primary" data-toggle="modal" data-target="#importTemplates"><?php echo ADDONS_IMPORT_BUTTON;?></a> <?php echo ADDONS_IMPORT_BUTTON_DESC;?></p>
                <p>&nbsp;</p>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<div class="modal fade" id="importTemplates" tabindex="-1" role="dialog" aria-labelledby="importExampleTemplates">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="importExampleTemplates"><?php echo TEMPLATES_TITLE; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=insert_templates" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="recipientid" class="recipientid" value="">
                    <div class="form-group">
                        <p><?php echo ADDONS_IMPORT_CONFIRM_TXT;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo SAVE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>