<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=addons&action=import_sample_data&ok");
    exit();
}

$app->checkToken();

// deleting all data
$sql = " truncate table ".PREF."_campaign ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_campaign_rec_conn ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_recipient ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_recipient_tag ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_recipient_tag_conn ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_sender ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_template ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_template_att_conn ";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = " truncate table ".PREF."_template_thumb ";
$stmt = $db->prepare($sql);
$stmt->execute();

$result = $db->query(" select * from ".PREF."_template_att ");
foreach ($result as $row) {
    unlink($_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).'/uploads/'.$row['filename']);
}

$sql = " truncate table ".PREF."_template_att ";
$stmt = $db->prepare($sql); $stmt->execute();

$year = date("Y");

// insert sample data
$sql = "
    INSERT INTO ".PREF."_campaign (id, name, recipient_qty, id_template, id_sender, status, date_create, date_start) VALUES
    (1, 'store only', 6, 1, 1, 2, '".$year."-01-10 08:55:33', '".$year."-02-10 09:17:35'),
    (2, 'all recipients', 15, 1, 1, 0, '".$year."-09-10 07:56:00', '2000-01-01 00:00:01'),
    (3, 'maedia filter', 9, 1, 1, 2, '".$year."-09-10 07:56:42', '".$year."-11-10 09:17:48'),
    (4, 'sample campaign', 15, 1, 1, 2, '".$year."-02-10 08:58:12', '".$year."-12-10 09:26:47'),
    (5, 'special offer', 15, 1, 1, 0, '".$year."-02-10 09:10:23', '2000-01-01 00:00:01'),
    (6, 'user letter t filter', 6, 1, 1, 0, '".$year."-12-10 09:12:08', '2000-01-01 00:00:01'),
    (7, 'user double o filter', 4, 1, 1, 2, '".$year."-04-10 08:13:19', '".$year."-09-10 08:26:59'),
    (8, 'holly campaign', 15, 1, 1, 2, '".$year."-05-10 08:14:05', '".$year."-05-10 08:29:20'),
    (9, 'your mailing', 15, 1, 1, 1, '".$year."-11-10 09:14:32', '".$year."-05-10 08:27:15'),
    (10, 'mini information', 15, 1, 1, 2, '".$year."-12-10 09:14:47', '".$year."-12-10 09:28:27'),
    (11, 'electric plane', 15, 1, 1, 2, '".$year."-12-10 09:15:34', '".$year."-12-10 09:28:44'),
    (12, 'new portal', 15, 1, 1, 2, '".$year."-12-10 09:16:01', '".$year."-05-10 08:28:11'),
    (13, 'weekend events', 15, 1, 1, 2, '".$year."-07-10 08:16:51', '".$year."-08-10 08:29:01'),
    (14, 'easter eggs', 25, 1, 1, 2, '".$year."-08-10 08:17:07', '".$year."-09-10 08:27:49'),
    (15, 'vacation', 5, 1, 1, 0, '".$year."-09-10 08:17:26', '2000-01-01 00:00:01');
";
$stmt = $db->prepare($sql);
$stmt->execute();

/*
    status
    0 - prepared
    1 - sent
    2 - opened
    3 - unsubscribed

*/
$sql = "
    INSERT INTO ".PREF."_campaign_rec_conn (id_campaign, id_recipient, date_sent, status, bounced, clicked, ip_receiver) VALUES
    (1, 1, '".$year."-03-10 09:17:32', 1, 1, 0, '103.192.236.4'),
    (1, 2, '".$year."-03-10 09:17:32', 1, 0, 0, '103.24.22.69'),
    (1, 3, '".$year."-03-10 09:17:33', 1, 1, 0, '103.47.133.24'),
    (1, 5, '".$year."-03-10 09:17:33', 1, 0, 0, '103.59.179.130'),
    (1, 11, '".$year."-03-10 09:17:35', 3, 0, 1, '106.51.173.251'),
    (1, 12, '".$year."-03-10 09:17:34', 3, 0, 1, '107.145.107.96'),
    (2, 1, '2000-01-01 00:00:01', 0, 1, 0, '108.72.44.140'),
    (2, 2, '2000-01-01 00:00:01', 0, 0, 0, '109.228.19.161'),
    (2, 3, '2000-01-01 00:00:01', 0, 0, 0, '109.242.0.234'),
    (2, 4, '2000-01-01 00:00:01', 2, 0, 0, '109.242.145.214'),
    (2, 5, '2000-01-01 00:00:01', 0, 1, 0, '112.71.206.6'),
    (2, 6, '2000-01-01 00:00:01', 0, 0, 0, '113.190.233.181'),
    (2, 7, '2000-01-01 00:00:01', 3, 0, 0, '115.112.129.194'),
    (2, 8, '2000-01-01 00:00:01', 3, 0, 0, '117.5.36.25'),
    (2, 9, '2000-01-01 00:00:01', 2, 0, 1, '117.6.57.138'),
    (2, 10, '2000-01-01 00:00:01', 2, 1, 1, '118.143.131.27'),
    (2, 11, '2000-01-01 00:00:01', 2, 0, 1, '122.162.152.156'),
    (2, 12, '2000-01-01 00:00:01', 2, 0, 0, '123.202.93.195'),
    (2, 13, '2000-01-01 00:00:01', 0, 0, 0, '125.164.158.221'),
    (2, 14, '2000-01-01 00:00:01', 0, 1, 0, '125.253.27.102'),
    (2, 15, '2000-01-01 00:00:01', 0, 0, 0, '129.205.133.74'),
    (3, 4, '".$year."-03-10 09:17:43', 2, 0, 1, '14.141.58.140'),
    (3, 6, '".$year."-03-10 09:17:43', 1, 1, 0, '151.16.253.192'),
    (3, 7, '".$year."-03-10 09:17:45', 1, 0, 0, '154.118.58.81'),
    (3, 8, '".$year."-03-10 09:17:44', 1, 0, 0, '156.212.219.190'),
    (3, 9, '".$year."-03-10 09:17:45', 2, 0, 0, '160.178.240.217'),
    (3, 10, '".$year."-03-10 09:17:46', 2, 0, 1, '166.170.5.88'),
    (3, 13, '".$year."-03-10 09:17:46', 2, 0, 1, '169.1.134.164'),
    (3, 14, '".$year."-03-10 09:17:47', 2, 1, 1, '17.103.78.247'),
    (3, 15, '".$year."-03-10 09:17:48', 3, 0, 1, '173.78.80.65'),
    (4, 1, '".$year."-03-10 09:26:39', 3, 0, 1, '176.27.244.30'),
    (4, 2, '".$year."-03-10 09:26:39', 3, 0, 0, '177.189.114.137'),
    (4, 3, '".$year."-03-10 09:26:40', 1, 1, 0, '177.205.216.215'),
    (4, 4, '".$year."-03-10 09:26:41', 1, 1, 0, '178.12.60.16'),
    (4, 5, '".$year."-03-10 09:26:41', 1, 0, 0, '178.4.40.247'),
    (4, 6, '".$year."-03-10 09:26:42', 3, 0, 0, '179.184.9.53'),
    (4, 7, '".$year."-03-10 09:26:42', 2, 1, 0, '179.9.192.65'),
    (4, 8, '".$year."-03-10 09:26:43', 1, 0, 0, '180.151.75.180'),
    (4, 9, '".$year."-03-10 09:26:44', 2, 0, 1, '182.48.89.118'),
    (4, 10, '".$year."-03-10 09:26:44', 2, 0, 1, '183.171.164.243'),
    (4, 11, '".$year."-03-10 09:26:45', 2, 0, 1, '184.94.62.114'),
    (4, 12, '".$year."-03-10 09:26:46', 2, 0, 1, '185.25.232.7'),
    (4, 13, '".$year."-03-10 09:26:46', 3, 0, 1, '185.57.72.161'),
    (4, 14, '".$year."-03-10 09:26:47', 2, 0, 1, '186.213.222.38'),
    (4, 15, '".$year."-03-10 09:26:47', 2, 0, 1, '186.4.34.131'),
    (5, 1, '2000-01-01 00:00:01', 2, 0, 1, '186.81.90.231'),
    (5, 2, '2000-01-01 00:00:01', 2, 0, 1, '187.213.15.134'),
    (5, 3, '2000-01-01 00:00:01', 0, 0, 0, '187.220.46.203'),
    (5, 4, '2000-01-01 00:00:01', 2, 1, 0, '188.146.66.188'),
    (5, 5, '2000-01-01 00:00:01', 0, 0, 0, '188.26.80.151'),
    (5, 6, '2000-01-01 00:00:01', 0, 0, 0, '188.4.199.39'),
    (5, 7, '2000-01-01 00:00:01', 0, 1, 0, '189.10.171.11'),
    (5, 8, '2000-01-01 00:00:01', 0, 1, 0, '189.202.38.133'),
    (5, 9, '2000-01-01 00:00:01', 2, 0, 1, '189.216.167.60'),
    (5, 10, '2000-01-01 00:00:01', 3, 0, 1, '189.59.37.107'),
    (5, 11, '2000-01-01 00:00:01', 0, 0, 0, '190.43.122.43'),
    (5, 12, '2000-01-01 00:00:01', 2, 0, 0, '190.47.113.46'),
    (5, 13, '2000-01-01 00:00:01', 0, 0, 0, '190.66.220.149'),
    (5, 14, '2000-01-01 00:00:01', 2, 0, 0, '191.251.218.125'),
    (5, 15, '2000-01-01 00:00:01', 2, 0, 1, '193.146.115.134'),
    (6, 1, '2000-01-01 00:00:01', 2, 0, 1, '194.96.60.212'),
    (6, 2, '2000-01-01 00:00:01', 0, 0, 0, '195.191.142.196'),
    (6, 3, '2000-01-01 00:00:01', 0, 1, 0, '197.1.12.164'),
    (6, 5, '2000-01-01 00:00:01', 0, 0, 0, '197.1.129.84'),
    (6, 11, '2000-01-01 00:00:01', 2, 0, 1, '197.27.93.198'),
    (6, 12, '2000-01-01 00:00:01', 2, 0, 1, '2.103.8.61'),
    (7, 5, '".$year."-03-10 09:26:57', 3, 0, 1, '2.80.45.74'),
    (7, 6, '".$year."-03-10 09:26:58', 3, 1, 1, '2.82.163.144'),
    (7, 8, '".$year."-03-10 09:26:58', 2, 0, 1, '200.101.57.44'),
    (7, 10, '".$year."-03-10 09:26:59', 2, 0, 1, '200.69.172.11'),
    (8, 1, '".$year."-03-10 09:29:11', 1, 0, 0, '201.14.171.74'),
    (8, 2, '".$year."-03-10 09:29:12', 2, 0, 0, '201.16.183.229'),
    (8, 3, '".$year."-03-10 09:29:12', 1, 1, 0, '201.217.40.128'),
    (8, 4, '".$year."-03-10 09:29:13', 3, 0, 0, '201.28.121.163'),
    (8, 5, '".$year."-03-10 09:29:13', 3, 0, 0, '203.106.154.192'),
    (8, 6, '".$year."-03-10 09:29:14', 2, 0, 0, '210.56.21.170'),
    (8, 7, '".$year."-03-10 09:29:15', 1, 0, 0, '212.156.147.198'),
    (8, 8, '".$year."-03-10 09:29:15', 2, 1, 0, '212.170.218.90'),
    (8, 9, '".$year."-03-10 09:29:16', 2, 0, 0, '212.252.143.202'),
    (8, 10, '".$year."-03-10 09:29:17', 2, 0, 1, '212.252.56.139'),
    (8, 11, '".$year."-03-10 09:29:17', 2, 0, 0, '213.196.219.198'),
    (8, 12, '".$year."-03-10 09:29:18', 1, 1, 0, '213.230.76.108'),
    (8, 13, '".$year."-03-10 09:29:18', 1, 0, 0, '217.233.90.36'),
    (8, 14, '".$year."-03-10 09:29:19', 1, 0, 0, '217.55.124.26'),
    (8, 15, '".$year."-03-10 09:29:20', 2, 0, 1, '27.99.37.182'),
    (9, 1, '".$year."-03-10 09:27:11', 2, 0, 1, '36.83.201.215'),
    (9, 2, '".$year."-03-10 09:27:11', 1, 0, 0, '37.44.85.212'),
    (9, 3, '".$year."-03-10 09:27:12', 1, 1, 0, '41.13.0.11'),
    (9, 4, '".$year."-03-10 09:27:13', 1, 0, 0, '41.145.177.231'),
    (9, 5, '".$year."-03-10 09:27:13', 2, 0, 0, '41.198.202.56'),
    (9, 6, '".$year."-03-10 09:27:14', 1, 0, 0, '41.248.42.254'),
    (9, 7, '".$year."-03-10 09:27:14', 3, 0, 0, '41.249.1.82'),
    (9, 8, '".$year."-03-10 09:27:15', 2, 0, 0, '42.113.152.172'),
    (9, 9, '2000-01-01 00:00:01', 2, 0, 1, '42.113.17.142'),
    (9, 10, '2000-01-01 00:00:01', 2, 0, 1, '43.242.119.167'),
    (9, 11, '2000-01-01 00:00:01', 0, 0, 0, '46.149.93.179'),
    (9, 12, '2000-01-01 00:00:01', 0, 0, 0, '5.228.11.241'),
    (9, 13, '2000-01-01 00:00:01', 0, 0, 0, '50.100.120.121'),
    (9, 14, '2000-01-01 00:00:01', 0, 0, 0, '50.76.59.236'),
    (9, 15, '2000-01-01 00:00:01', 2, 0, 0, '59.95.233.20'),
    (10, 1, '".$year."-03-10 09:28:18', 2, 0, 1, '61.93.82.140'),
    (10, 2, '".$year."-03-10 09:28:19', 1, 0, 0, '67.177.249.9'),
    (10, 3, '".$year."-03-10 09:28:20', 1, 0, 0, '68.134.9.171'),
    (10, 4, '".$year."-03-10 09:28:20', 3, 1, 0, '71.47.31.34'),
    (10, 5, '".$year."-03-10 09:28:21', 3, 0, 0, '71.80.249.225'),
    (10, 6, '".$year."-03-10 09:28:22', 3, 0, 0, '72.166.33.66'),
    (10, 7, '".$year."-03-10 09:28:22', 3, 1, 0, '73.226.75.189'),
    (10, 8, '".$year."-03-10 09:28:23', 1, 0, 0, '75.180.13.26'),
    (10, 9, '".$year."-03-10 09:28:23', 1, 0, 0, '76.175.66.242'),
    (10, 10, '".$year."-03-10 09:28:24', 2, 0, 1, '77.58.56.109'),
    (10, 11, '".$year."-03-10 09:28:25', 1, 0, 0, '78.113.17.197'),
    (10, 12, '".$year."-03-10 09:28:25', 1, 1, 0, '78.178.238.41'),
    (10, 13, '".$year."-03-10 09:28:26', 1, 0, 0, '78.31.138.140'),
    (10, 14, '".$year."-03-10 09:28:27', 1, 0, 0, '78.56.117.87'),
    (10, 15, '".$year."-03-10 09:28:27', 2, 0, 1, '81.106.57.182'),
    (11, 1, '".$year."-03-10 09:28:36', 1, 0, 10, '81.172.74.71'),
    (11, 2, '".$year."-03-10 09:28:36', 1, 0, 3, '82.135.30.164'),
    (11, 3, '".$year."-03-10 09:28:37', 1, 0, 0, '83.11.208.62'),
    (11, 4, '".$year."-03-10 09:28:37', 1, 0, 8, '83.220.43.122'),
    (11, 5, '".$year."-03-10 09:28:38', 2, 0, 0, '84.107.105.52'),
    (11, 6, '".$year."-03-10 09:28:39', 1, 1, 0, '91.195.173.61'),
    (11, 7, '".$year."-03-10 09:28:39', 1, 0, 0, '91.208.93.176'),
    (11, 8, '".$year."-03-10 09:28:40', 2, 0, 0, '92.96.223.216'),
    (11, 9, '".$year."-03-10 09:28:41', 1, 0, 0, '93.46.66.32'),
    (11, 10, '".$year."-03-10 09:28:41', 1, 0, 6, '99.164.4.142'),
    (11, 11, '".$year."-03-10 09:28:42', 2, 0, 0, '103.192.236.4'),
    (11, 12, '".$year."-03-10 09:28:42', 2, 1, 0, '103.24.22.69'),
    (11, 13, '".$year."-03-10 09:28:43', 2, 0, 0, '103.47.133.24'),
    (11, 14, '".$year."-03-10 09:28:44', 1, 0, 0, '103.59.179.130'),
    (11, 15, '".$year."-03-10 09:28:44', 3, 0, 5, '107.145.107.96'),
    (12, 1, '".$year."-03-10 09:28:03', 2, 0, 1, '108.72.44.140'),
    (12, 2, '".$year."-03-10 09:28:03', 2, 0, 1, '109.228.19.161'),
    (12, 3, '".$year."-03-10 09:28:04', 1, 0, 0, '113.190.233.181'),
    (12, 4, '".$year."-03-10 09:28:05', 2, 0, 0, '115.112.129.194'),
    (12, 5, '".$year."-03-10 09:28:05', 1, 0, 0, '117.5.36.25'),
    (12, 6, '".$year."-03-10 09:28:06', 1, 1, 0, '117.6.57.138'),
    (12, 7, '".$year."-03-10 09:28:06', 1, 0, 0, '122.162.152.156'),
    (12, 8, '".$year."-03-10 09:28:07', 1, 1, 0, '123.202.93.195'),
    (12, 9, '".$year."-03-10 09:28:08', 2, 1, 1, '125.164.158.221'),
    (12, 10, '".$year."-03-10 09:28:08', 2, 0, 1, '125.253.27.102'),
    (12, 11, '".$year."-03-10 09:28:09', 1, 0, 0, '14.141.58.140'),
    (12, 12, '".$year."-03-10 09:28:10', 2, 1, 0, '151.16.253.192'),
    (12, 13, '".$year."-03-10 09:28:10', 2, 1, 0, '169.1.134.164'),
    (12, 14, '".$year."-03-10 09:28:11', 1, 1, 0, '17.103.78.247'),
    (12, 15, '".$year."-03-10 09:28:11', 2, 0, 1, '173.78.80.65'),
    (13, 1, '".$year."-03-10 09:28:52', 2, 0, 1, '176.27.244.30'),
    (13, 2, '".$year."-03-10 09:28:53', 1, 0, 0, '177.189.114.137'),
    (13, 3, '".$year."-03-10 09:28:53', 1, 0, 0, '177.205.216.215'),
    (13, 4, '".$year."-03-10 09:28:54', 1, 0, 0, '178.12.60.16'),
    (13, 5, '".$year."-03-10 09:28:55', 1, 0, 0, '178.4.40.247'),
    (13, 6, '".$year."-03-10 09:28:55', 2, 0, 0, '179.184.9.53'),
    (13, 7, '".$year."-03-10 09:28:56', 1, 0, 0, '180.151.75.180'),
    (13, 8, '".$year."-03-10 09:28:56', 1, 0, 0, '183.171.164.243'),
    (13, 9, '".$year."-03-10 09:28:57', 2, 0, 1, '185.25.232.7'),
    (13, 10, '".$year."-03-10 09:28:58', 2, 0, 1, '185.57.72.161'),
    (13, 11, '".$year."-03-10 09:28:58', 1, 0, 0, '186.213.222.38'),
    (13, 12, '".$year."-03-10 09:28:59', 2, 1, 0, '186.4.34.131'),
    (13, 13, '".$year."-03-10 09:28:59', 1, 1, 0, '188.146.66.188'),
    (13, 14, '".$year."-03-10 09:29:00', 1, 1, 0, '188.26.80.151'),
    (13, 15, '".$year."-03-10 09:29:01', 2, 0, 1, '189.10.171.11'),
    (14, 1, '".$year."-03-10 09:27:40', 2, 0, 1, '189.202.38.133'),
    (14, 2, '".$year."-03-10 09:27:41', 2, 0, 2, '189.216.167.60'),
    (14, 3, '".$year."-03-10 09:27:41', 2, 0, 3, '189.59.37.107'),
    (14, 4, '".$year."-03-10 09:27:42', 2, 0, 4, '190.66.220.149'),
    (14, 5, '".$year."-03-10 09:27:42', 2, 0, 4, '191.251.218.125'),
    (14, 6, '".$year."-03-10 09:27:43', 2, 0, 5, '193.146.115.134'),
    (14, 7, '".$year."-03-10 09:27:44', 2, 0, 6, '2.103.8.61'),
    (14, 8, '".$year."-03-10 09:27:44', 2, 0, 7, '2.82.163.144'),
    (14, 9, '".$year."-03-10 09:27:45', 2, 1, 0, '200.69.172.11'),
    (14, 10, '".$year."-03-10 09:27:46', 2, 0, 1, '201.16.183.229'),
    (14, 11, '".$year."-03-10 09:27:46', 3, 0, 1, '201.217.40.128'),
    (14, 12, '".$year."-03-10 09:27:47', 2, 0, 1, '203.106.154.192'),
    (14, 13, '".$year."-03-10 09:27:47', 2, 0, 1, '212.156.147.198'),
    (14, 14, '".$year."-03-10 09:27:48', 2, 0, 1, '212.252.143.202'),
    (14, 15, '".$year."-03-10 09:27:49', 2, 0, 1, '212.252.56.139'),
    (14, 16, '".$year."-01-01 00:00:01', 2, 0, 1, '213.196.219.198'),
    (14, 17, '".$year."-01-01 00:00:01', 0, 0, 0, ''),
    (14, 18, '".$year."-01-01 00:00:01', 3, 0, 0, '217.55.124.26'),
    (14, 19, '".$year."-01-01 00:00:01', 0, 0, 0, '27.99.37.182'),
    (14, 20, '".$year."-01-01 00:00:01', 0, 0, 0, '37.44.85.212'),
    (14, 21, '".$year."-01-01 00:00:01', 2, 0, 0, '41.13.0.11'),
    (14, 22, '".$year."-01-01 00:00:01', 0, 0, 0, '41.145.177.231'),
    (14, 23, '".$year."-01-01 00:00:01', 0, 0, 0, '41.198.202.56'),
    (14, 24, '".$year."-01-01 00:00:01', 2, 0, 1, '41.248.42.254'),
    (14, 25, '".$year."-01-01 00:00:01', 2, 0, 1, '41.249.1.82'),
    (15, 11, '2000-01-01 00:00:01', 0, 0, 0, '42.113.152.172'),
    (15, 12, '2000-01-01 00:00:01', 0, 0, 0, '42.113.17.142'),
    (15, 13, '2000-01-01 00:00:01', 2, 0, 0, '43.242.119.167'),
    (15, 14, '2000-01-01 00:00:01', 0, 0, 0, '46.149.93.179'),
    (15, 15, '2000-01-01 00:00:01', 2, 0, 1, '5.228.11.241');
";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = "
    INSERT INTO ".PREF."_recipient (date_create, date_modify, person, email, comment, txt_only, website, f01, f02, f03) VALUES
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'John Smith', 'user01@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Ben Tresss', 'user02@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Kate Smoth', 'user03@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Greg Salad', 'user04@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Dan Rooter', 'user05@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Marry Pooh', 'user06@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Indi Jones', 'user07@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Robin Hood', 'user08@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Goddy Zeus', 'user09@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Flame Moos', 'user10@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Don Duckys', 'user11@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Big Master', 'user12@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Funny Name', 'user13@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Coile Boys', 'user14@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Gone Horse', 'user15@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Funky Boy', 'user16@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Spider Lig', 'user17@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Michelle Big', 'user18@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Jim Bean', 'user19@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Jonny Good', 'user20@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Smart Saver', 'user21@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Polo Colo', 'user22@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Coca Cola', 'user23@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Scooby Doo', 'user24@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3'),
    ('".$year."-03-10 08:02:00', '2000-01-01 00:00:01', 'Joe Spartan', 'user25@exampledomain.com', 'remarks', 0, 'field0', 'field1', 'field2', 'field3');
";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = "
    INSERT INTO ".PREF."_recipient_tag (id, name, description) VALUES
    (1, 'house', ''),
    (2, 'store', ''),
    (3, 'media', '');
";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = "
    INSERT INTO ".PREF."_recipient_tag_conn (id_recipient, id_tag) VALUES
    (1, 1),
    (1, 2),
    (2, 1),
    (2, 2),
    (3, 1),
    (3, 2),
    (4, 1),
    (4, 3),
    (5, 1),
    (5, 2),
    (6, 1),
    (6, 3),
    (7, 1),
    (7, 3),
    (8, 1),
    (8, 3),
    (9, 1),
    (9, 3),
    (10, 1),
    (10, 3),
    (11, 1),
    (11, 2),
    (12, 1),
    (12, 2),
    (13, 1),
    (13, 3),
    (14, 1),
    (14, 3),
    (15, 1),
    (15, 3);
";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = "
INSERT INTO ".PREF."_geolocation (ip_receiver, user_agent, city, region, country_code, country_name, continent_code, latitude, longitude, region_code, region_name, currency_code) VALUES
('103.192.236.4', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Hanoi', '', 'VN', 'Vietnam', '', '21.0333', '105.85', '64', 'Thanh Pho Ha Noi', ''),
('103.24.22.69', 'Mozilla/5.0 (Windows NT 5.1; rv:48.0) Gecko/20100101 Firefox/48.0', 'Arepalli', '', 'IN', 'India', '', '18.108', '79.0635', 'AP', 'Andhra Pradesh', ''),
('103.47.133.24', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Jakarta', '', 'ID', 'Indonesia', '', '-6.1744', '106.8294', 'JK', 'Jakarta', ''),
('103.59.179.130', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Dhaka', '', 'BD', 'Bangladesh', '', '23.7231', '90.4086', 'C', 'Dhaka Division', ''),
('106.51.173.251', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'IN', 'India', '', '20', '77', '', '', ''),
('107.145.107.96', 'Mozilla/5.0 (X11; CrOS x86_64 8172.56.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Rockledge', '', 'US', 'United States', '', '28.2816', '-80.7645', 'FL', 'Florida', ''),
('108.72.44.140', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'Marietta', '', 'US', 'United States', '', '33.9203', '-84.618', 'GA', 'Georgia', ''),
('109.228.19.161', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'Gloucester', '', 'GB', 'United Kingdom', '', '51.8657', '-2.2431', 'ENG', 'England', ''),
('109.242.0.234', 'Mozilla/5.0 (Linux; Android 4.4.2; Lenovo A5500-H Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Safari/537.36', '', '', 'GR', 'Greece', '', '37.9667', '23.7167', '', '', ''),
('109.242.145.214', 'Mozilla/5.0 (Linux; Android 4.4.2; Lenovo A5500-H Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Safari/537.36', '', '', 'GR', 'Greece', '', '37.9667', '23.7167', '', '', ''),
('112.71.206.6', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'JP', 'Japan', '', '35.69', '139.69', '', '', ''),
('113.190.233.181', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Hanoi', '', 'VN', 'Vietnam', '', '21.0333', '105.85', '64', 'Thanh Pho Ha Noi', ''),
('115.112.129.194', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Mumbai', '', 'IN', 'India', '', '18.975', '72.8258', 'MH', 'Maharashtra', ''),
('117.5.36.25', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Hanoi', '', 'VN', 'Vietnam', '', '21.0333', '105.85', '64', 'Thanh Pho Ha Noi', ''),
('117.6.57.138', 'Mozilla/5.0 (Linux; Android 4.4.2; LGLS990 Build/KVT49L.LS990ZV4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36', 'Hanoi', '', 'VN', 'Vietnam', '', '21.0333', '105.85', '64', 'Thanh Pho Ha Noi', ''),
('118.143.131.27', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'HK', 'Hong Kong', '', '22.25', '114.1667', '', '', ''),
('122.162.152.156', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Delhi', '', 'IN', 'India', '', '28.6667', '77.2167', 'DL', 'National Capital Territory of Delhi', ''),
('123.202.93.195', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Central District', '', 'HK', 'Hong Kong', '', '22.2833', '114.15', '', '', ''),
('125.164.158.221', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'Malang', '', 'ID', 'Indonesia', '', '-7.9797', '112.6304', 'JI', 'East Java', ''),
('125.253.27.102', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Buderim', '', 'AU', 'Australia', '', '-26.6844', '153.0571', 'QLD', 'Queensland', ''),
('129.205.133.74', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.120 Chrome/37.0.2062.120 Safari/537.36', '', '', 'ZA', 'South Africa', '', '-29', '24', '', '', ''),
('14.141.58.140', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Delhi', '', 'IN', 'India', '', '28.6667', '77.2167', 'DL', 'National Capital Territory of Delhi', ''),
('151.16.253.192', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', 'Genoa', '', 'IT', 'Italy', '', '44.4063', '8.9339', '42', 'Liguria', ''),
('154.118.58.81', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'NG', 'Nigeria', '', '10', '8', '', '', ''),
('156.212.219.190', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'EG', 'Egypt', '', '30.0355', '31.223', '', '', ''),
('160.178.240.217', 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) MxNitro/1.0.1.3000 Chrome/35.0.1849.0 Safari/537.36', '', '', 'MA', 'Morocco', '', '32', '-5', '', '', ''),
('166.170.5.88', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'US', 'United States', '', '34.0544', '-118.244', 'CA', 'California', ''),
('169.1.134.164', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0', 'Cape Town', '', 'ZA', 'South Africa', '', '-33.8213', '18.4454', 'WC', 'Province of the Western Cape', ''),
('17.103.78.247', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'Pflugerville', '', 'US', 'United States', '', '30.4416', '-97.5986', 'TX', 'Texas', ''),
('173.78.80.65', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', 'Zephyrhills', '', 'US', 'United States', '', '28.2722', '-82.3322', 'FL', 'Florida', ''),
('176.27.244.30', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9', 'Wednesbury', '', 'GB', 'United Kingdom', '', '52.55', '-2.0167', 'ENG', 'England', ''),
('177.189.114.137', 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0', 'Itaquaquecetuba', '', 'BR', 'Brazil', '', '-23.4833', '-46.35', 'SP', 'Sao Paulo', ''),
('177.205.216.215', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Osasco', '', 'BR', 'Brazil', '', '-23.5667', '-46.7833', 'SP', 'Sao Paulo', ''),
('178.12.60.16', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0', 'Nordhausen', '', 'DE', 'Germany', '', '51.4918', '10.7952', 'TH', 'Thuringia', ''),
('178.4.40.247', 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36 OPR/38.0.2220.31', 'Bochum', '', 'DE', 'Germany', '', '51.4658', '7.1572', 'NW', 'North Rhine-Westphalia', ''),
('179.184.9.53', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', 'Maringá', '', 'BR', 'Brazil', '', '-23.4167', '-51.9167', 'PR', 'Parana', ''),
('179.9.192.65', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Santiago', '', 'CL', 'Chile', '', '-33.45', '-70.6668', 'RM', 'Santiago Metropolitan', ''),
('180.151.75.180', 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0', 'Gurgaon', '', 'IN', 'India', '', '28.4667', '77.0333', 'HR', 'Haryana', ''),
('182.48.89.118', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'BD', 'Bangladesh', '', '23.7', '90.375', '', '', ''),
('183.171.164.243', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Kuala Lumpur', '', 'MY', 'Malaysia', '', '3.1667', '101.7', '14', 'Kuala Lumpur', ''),
('184.94.62.114', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'CA', 'Canada', '', '43.6425', '-79.3873', '', '', ''),
('185.25.232.7', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:46.0) Gecko/20100101 Firefox/46.0', 'Giugliano in Campania', '', 'IT', 'Italy', '', '40.9319', '14.1956', '72', 'Campania', ''),
('185.57.72.161', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'Almaty', '', 'KZ', 'Kazakhstan', '', '43.2565', '76.9285', 'ALA', 'Almaty Qalasy', ''),
('186.213.222.38', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.60 Safari/537.36', 'Brasília', '', 'BR', 'Brazil', '', '-15.7797', '-47.9297', 'DF', 'Federal District', ''),
('186.4.34.131', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'San José', '', 'CR', 'Costa Rica', '', '9.9333', '-84.0833', 'SJ', 'Provincia de San Jose', ''),
('186.81.90.231', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'CO', 'Colombia', '', '4.5981', '-74.0758', '', '', ''),
('187.213.15.134', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36 OPR/38.0.2220.31', '', '', 'MX', 'Mexico', '', '19.43', '-99.13', '', '', ''),
('187.220.46.203', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'MX', 'Mexico', '', '19.43', '-99.13', '', '', ''),
('188.146.66.188', 'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900F/G900FXXS1BPCE Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36', 'Warzachewka Polska', '', 'PL', 'Poland', '', '52.5931', '19.0894', 'KP', 'Kujawsko-Pomorskie', ''),
('188.26.80.151', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Bucharest', '', 'RO', 'Romania', '', '44.4186', '26.0622', 'B', 'Bucuresti', ''),
('188.4.199.39', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'GR', 'Greece', '', '37.9667', '23.7167', '', '', ''),
('189.10.171.11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Porto Alegre', '', 'BR', 'Brazil', '', '-30.0333', '-51.2', 'RS', 'Rio Grande do Sul', ''),
('189.202.38.133', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36', 'Chihuahua City', '', 'MX', 'Mexico', '', '28.6333', '-106.0833', 'CHH', 'Chihuahua', ''),
('189.216.167.60', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Cuauhtemoc', '', 'MX', 'Mexico', '', '28.4167', '-106.8667', 'CHH', 'Chihuahua', ''),
('189.59.37.107', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Cuiabá', '', 'BR', 'Brazil', '', '-15.5833', '-56.0833', 'MT', 'Mato Grosso', ''),
('190.43.122.43', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'PE', 'Peru', '', '-12.0433', '-77.0283', '', '', ''),
('190.47.113.46', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'CL', 'Chile', '', '-33.4378', '-70.6503', '', '', ''),
('190.66.220.149', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Bogotá', '', 'CO', 'Colombia', '', '4.6492', '-74.0628', 'DC', 'Bogota D.C.', ''),
('191.251.218.125', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Salvador', '', 'BR', 'Brazil', '', '-12.9833', '-38.5167', 'BA', 'Bahia', ''),
('193.146.115.134', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'Barcelona', '', 'ES', 'Spain', '', '41.3888', '2.159', 'CT', 'Catalonia', ''),
('194.96.60.212', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'AT', 'Austria', '', '48.2', '16.3667', '', '', ''),
('195.191.142.196', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'DK', 'Denmark', '', '55.6761', '12.5683', '', '', ''),
('197.1.12.164', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'TN', 'Tunisia', '', '34', '9', '', '', ''),
('197.1.129.84', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36', '', '', 'TN', 'Tunisia', '', '34', '9', '', '', ''),
('197.27.93.198', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.9.3.1000 Chrome/39.0.2146.0 Safari/537.36', '', '', 'TN', 'Tunisia', '', '34', '9', '', '', ''),
('2.103.8.61', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586', 'Hook', '', 'GB', 'United Kingdom', '', '51.2667', '-0.95', 'ENG', 'England', ''),
('2.80.45.74', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.41 Safari/537.36', '', '', 'PT', 'Portugal', '', '38.7139', '-9.1394', '', '', ''),
('2.82.163.144', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Aveiro', '', 'PT', 'Portugal', '', '40.6443', '-8.6455', '01', 'Aveiro', ''),
('200.101.57.44', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'BR', 'Brazil', '', '-23.5477', '-46.6359', '', '', ''),
('200.69.172.11', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Quito', '', 'EC', 'Ecuador', '', '-0.2167', '-78.5', 'P', 'Provincia de Pichincha', ''),
('201.14.171.74', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'BR', 'Brazil', '', '-23.5477', '-46.6359', '', '', ''),
('201.16.183.229', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Medeiros Neto', '', 'BR', 'Brazil', '', '-17.3333', '-40.2333', 'BA', 'Bahia', ''),
('201.217.40.128', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Asunción', '', 'PY', 'Paraguay', '', '-25.2939', '-57.6111', 'ASU', 'Asuncion', ''),
('201.28.121.163', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'BR', 'Brazil', '', '-23.5477', '-46.6359', '', '', ''),
('203.106.154.192', 'Mozilla/5.0 (Windows NT 6.1; rv:48.0) Gecko/20100101 Firefox/48.0', 'George Town', '', 'MY', 'Malaysia', '', '5.4112', '100.3354', '07', 'Penang', ''),
('210.56.21.170', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'PK', 'Pakistan', '', '30', '70', '', '', ''),
('212.156.147.198', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Istanbul', '', 'TR', 'Turkey', '', '41.0186', '28.9647', '34', 'Istanbul', ''),
('212.170.218.90', 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'ES', 'Spain', '', '40.4172', '-3.684', '', '', ''),
('212.252.143.202', 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Istanbul', '', 'TR', 'Turkey', '', '41.0186', '28.9647', '34', 'Istanbul', ''),
('212.252.56.139', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Adana', '', 'TR', 'Turkey', '', '37.0017', '35.3289', '01', 'Adana', ''),
('213.196.219.198', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'Kerpen', '', 'DE', 'Germany', '', '50.8748', '6.7435', 'NW', 'North Rhine-Westphalia', ''),
('213.230.76.108', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.21.2704.63 Safari/537.36', 'Tashkent', '', 'UZ', 'Uzbekistan', '', '41.3167', '69.25', 'TK', 'Toshkent Shahri', ''),
('217.233.90.36', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'DE', 'Germany', '', '51', '9', '', '', ''),
('217.55.124.26', 'Mozilla/5.0 (Windows NT 6.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', 'Alexandria', '', 'EG', 'Egypt', '', '31.2156', '29.9553', 'ALX', 'Alexandria', ''),
('27.99.37.182', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Carlingford', '', 'AU', 'Australia', '', '-33.7833', '151.05', 'NSW', 'New South Wales', ''),
('36.83.201.215', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'ID', 'Indonesia', '', '-6.175', '106.8286', '', '', ''),
('37.10.200.31', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'ES', 'Spain', '', '40.4172', '-3.684', '', '', ''),
('37.24.128.3', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'DE', 'Germany', '', '51', '9', '', '', ''),
('37.44.85.212', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.63 Safari/537.36', 'Minsk', '', 'BY', 'Belarus', '', '53.9', '27.5667', 'HM', 'Minsk City', ''),
('41.105.39.158', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'DZ', 'Algeria', '', '28', '3', '', '', ''),
('41.13.0.11', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Johannesburg', '', 'ZA', 'South Africa', '', '-26.1928', '28.0711', 'GP', 'Gauteng', ''),
('41.145.177.231', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Boksburg', '', 'ZA', 'South Africa', '', '-26.2167', '28.25', 'GP', 'Gauteng', ''),
('41.198.202.56', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Lagos', '', 'NG', 'Nigeria', '', '6.4531', '3.3958', 'LA', 'Lagos', ''),
('41.199.16.243', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'EG', 'Egypt', '', '30.0355', '31.223', '', '', ''),
('41.216.161.242', 'Mozilla/5.0 compatible; MSIE 9.0; Windows NT 4.1 Chrome/31.0.1229.79', '', '', 'NG', 'Nigeria', '', '10', '8', '', '', ''),
('41.225.13.190', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'TN', 'Tunisia', '', '34', '9', '', '', ''),
('41.227.56.196', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'TN', 'Tunisia', '', '34', '9', '', '', ''),
('41.248.42.254', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Tangier', '', 'MA', 'Morocco', '', '35.7806', '-5.8136', '01', 'Region de Tanger-Tetouan', ''),
('41.249.1.82', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:47.0) Gecko/20100101 Firefox/47.0', 'Rabat', '', 'MA', 'Morocco', '', '34.0138', '-6.8443', '07', 'Region de Rabat-Sale-Zemmour-Zaer', ''),
('41.37.226.95', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'EG', 'Egypt', '', '30.0355', '31.223', '', '', ''),
('41.66.194.163', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'GH', 'Ghana', '', '8', '-2', '', '', ''),
('42.113.152.172', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36', 'Hanoi', '', 'VN', 'Vietnam', '', '21.0333', '105.85', '64', 'Thanh Pho Ha Noi', ''),
('42.113.17.142', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Hanoi', '', 'VN', 'Vietnam', '', '21.0333', '105.85', '64', 'Thanh Pho Ha Noi', ''),
('43.224.255.213', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'IN', 'India', '', '20', '77', '', '', ''),
('43.242.119.167', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Ahmedabad', '', 'IN', 'India', '', '23.0333', '72.6167', 'GJ', 'Gujarat', ''),
('45.115.226.90', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'BD', 'Bangladesh', '', '23.7', '90.375', '', '', ''),
('46.149.93.179', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Chernihiv', '', 'UA', 'Ukraine', '', '51.5055', '31.2849', '74', 'Chernihiv', ''),
('5.122.123.25', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'IR', 'Iran', '', '35.6961', '51.4231', '', '', ''),
('5.170.108.202', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'IT', 'Italy', '', '43.1479', '12.1097', '', '', ''),
('5.170.111.109', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'IT', 'Italy', '', '43.1479', '12.1097', '', '', ''),
('5.228.11.241', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 YaBrowser/16.6.0.8125 Safari/537.36', 'Moscow', '', 'RU', 'Russia', '', '55.752', '37.615', 'MOW', 'Moscow', ''),
('5.28.144.229', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'IL', 'Israel', '', '31.5', '34.75', '', '', ''),
('5.31.5.144', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'AE', 'United Arab Emirates', '', '24', '54', '', '', ''),
('50.100.120.121', 'Mozilla/5.0 (Linux; Android 5.1.1; SM-G920I Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.93 Mobile Safari/537.36', 'Terrebonne', '', 'CA', 'Canada', '', '45.7275', '-73.7062', 'QC', 'Quebec', ''),
('50.76.59.236', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'San Francisco', '', 'US', 'United States', '', '37.7957', '-122.4209', 'CA', 'California', ''),
('59.127.167.61', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'TW', 'Taiwan', '', '23.5', '121', '', '', ''),
('59.153.29.120', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'BD', 'Bangladesh', '', '23.7', '90.375', '', '', ''),
('59.95.233.20', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Bengaluru', '', 'IN', 'India', '', '12.9833', '77.5833', 'KA', 'Karnataka', ''),
('61.93.82.140', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Central District', '', 'HK', 'Hong Kong', '', '22.2833', '114.15', '', '', ''),
('67.177.249.9', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Englewood', '', 'US', 'United States', '', '39.6478', '-104.9878', 'CO', 'Colorado', ''),
('68.134.9.171', 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13F69 Safari/601.1', 'Columbia', '', 'US', 'United States', '', '39.2043', '-76.8833', 'MD', 'Maryland', ''),
('71.47.31.34', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Orlando', '', 'US', 'United States', '', '28.5106', '-81.1976', 'FL', 'Florida', ''),
('71.80.249.225', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:49.0) Gecko/20100101 Firefox/49.0', 'Watsonville', '', 'US', 'United States', '', '36.9512', '-121.724', 'CA', 'California', ''),
('72.166.33.66', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Santa Monica', '', 'US', 'United States', '', '34.0256', '-118.4716', 'CA', 'California', ''),
('73.226.75.189', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'Margate City', '', 'US', 'United States', '', '39.3304', '-74.5063', 'NJ', 'New Jersey', ''),
('75.180.13.26', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'Columbus', '', 'US', 'United States', '', '39.8928', '-82.9588', 'OH', 'Ohio', ''),
('76.175.66.242', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Los Angeles', '', 'US', 'United States', '', '34.0039', '-118.4338', 'CA', 'California', ''),
('77.117.122.153', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'AT', 'Austria', '', '48.2', '16.3667', '', '', ''),
('77.255.43.117', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.9.2.1000 Chrome/39.0.2146.0 Safari/537.36', '', '', 'PL', 'Poland', '', '52.2333', '21.0167', '', '', ''),
('77.54.20.163', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'PT', 'Portugal', '', '38.7139', '-9.1394', '', '', ''),
('77.58.56.109', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Saint-Blaise', '', 'CH', 'Switzerland', '', '47.0132', '6.9847', 'NE', 'Neuchâtel', ''),
('78.113.17.197', 'Mozilla/5.0 (Windows NT 6.1; rv:47.0) Gecko/20100101 Firefox/47.0', 'Rouen', '', 'FR', 'France', '', '49.4431', '1.0993', '76', 'Seine-Maritime', ''),
('78.178.238.41', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Izmir', '', 'TR', 'Turkey', '', '38.4949', '27.1396', '35', 'Izmir', ''),
('78.178.79.66', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2783.2 Safari/537.36', '', '', 'TR', 'Turkey', '', '41.0136', '28.955', '', '', ''),
('78.187.142.218', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'TR', 'Turkey', '', '41.0136', '28.955', '', '', ''),
('78.31.138.140', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36 OPR/38.0.2220.31', 'Rybnik', '', 'PL', 'Poland', '', '50.0921', '18.5475', 'SL', 'Silesian Voivodeship', ''),
('78.56.117.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', 'Vilnius', '', 'LT', 'Republic of Lithuania', '', '54.6833', '25.3167', 'VL', 'Vilnius County', ''),
('78.56.177.130', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/601.4.4 (KHTML, like Gecko) Version/9.0.3 Safari/601.4.4', '', '', 'LT', 'Republic of Lithuania', '', '56', '24', '', '', ''),
('79.58.13.118', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'IT', 'Italy', '', '43.1479', '12.1097', '', '', ''),
('80.234.49.214', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36 OPR/38.0.2220.31', '', '', 'RU', 'Russia', '', '55.75', '37.6166', '', '', ''),
('81.106.57.182', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'Bracknell', '', 'GB', 'United Kingdom', '', '51.4167', '-0.75', 'ENG', 'England', ''),
('81.172.74.71', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36', 'Salamanca', '', 'ES', 'Spain', '', '40.9688', '-5.6639', 'CL', 'Castille and León', ''),
('81.205.1.155', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36', '', '', 'NL', 'Netherlands', '', '52.3824', '4.8995', '', '', ''),
('81.214.81.253', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36', '', '', 'TR', 'Turkey', '', '41.0136', '28.955', '', '', ''),
('81.82.233.144', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'BE', 'Belgium', '', '50.85', '4.35', '', '', ''),
('82.135.30.164', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36', 'Munich', '', 'DE', 'Germany', '', '48.15', '11.5833', 'BY', 'Bavaria', ''),
('82.214.136.210', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'PL', 'Poland', '', '52.2333', '21.0167', '', '', ''),
('83.11.208.62', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36 OPR/38.0.2220.31', 'Poznan', '', 'PL', 'Poland', '', '52.4167', '16.9667', 'WP', 'Greater Poland Voivodeship', ''),
('83.220.43.122', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Moscow', '', 'RU', 'Russia', '', '55.7522', '37.6156', 'MOW', 'Moscow', ''),
('84.107.105.52', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Hoorn', '', 'NL', 'Netherlands', '', '52.649', '5.0631', 'NH', 'North Holland', ''),
('86.82.60.81', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'NL', 'Netherlands', '', '52.3824', '4.8995', '', '', ''),
('88.149.169.108', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'IT', 'Italy', '', '43.1479', '12.1097', '', '', ''),
('88.178.99.59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'FR', 'France', '', '48.8582', '2.3387', '', '', ''),
('89.152.253.53', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '', '', 'PT', 'Portugal', '', '38.7139', '-9.1394', '', '', ''),
('89.65.35.246', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.4.6.1000 Chrome/30.0.1599.101 Safari/537.36', '', '', 'PL', 'Poland', '', '52.2333', '21.0167', '', '', ''),
('91.195.173.61', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36 OPR/38.0.2220.31', 'Uzhhorod', '', 'UA', 'Ukraine', '', '48.6167', '22.3', '21', 'Zakarpattia Oblast', ''),
('91.208.93.176', 'Mozilla/5.0 (Windows NT 5.1; rv:47.0) Gecko/20100101 Firefox/47.0', 'Warsaw', '', 'PL', 'Poland', '', '52.25', '21', 'MZ', 'Masovian Voivodeship', ''),
('92.96.223.216', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Dubai', '', 'AE', 'United Arab Emirates', '', '25.2582', '55.3047', 'DU', 'Dubai', ''),
('93.143.19.225', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'HR', 'Croatia', '', '45.1667', '15.5', '', '', ''),
('93.46.66.32', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Messina', '', 'IT', 'Italy', '', '38.1866', '15.5478', '82', 'Sicily', ''),
('94.173.53.35', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'GB', 'United Kingdom', '', '51.4964', '-0.1224', '', '', ''),
('94.207.81.136', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/601.6.17 (KHTML, like Gecko) Version/9.1.1 Safari/601.6.17', '', '', 'AE', 'United Arab Emirates', '', '24', '54', '', '', ''),
('94.54.230.220', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', '', '', 'TR', 'Turkey', '', '41.0136', '28.955', '', '', ''),
('99.164.4.142', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36', 'Yorkville', '', 'US', 'United States', '', '41.5996', '-88.4322', 'IL', 'Illinois', '');
";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = "
    INSERT INTO ".PREF."_sender (id, name, email) VALUES
    (1, 'Marketing', 'marketing@exampledomain.ext');
";
$stmt = $db->prepare($sql);
$stmt->execute();

$template = Array(
    'example template', 
    '<div style="width: 600px; margin: auto;">\r\n<div class="banner">\r\n<h1 class="site-title">Dear {RECIPIENT_NAME}</h1>\r\n<p>😀 😃 😄 😁</p><h2 class="claim">This is template email</h2>\r\n</div>\r\n<table class="about" style="height: 54px;" border="0" width="280" cellspacing="0" cellpadding="0" align="center">\r\n<tbody>\r\n<tr style="height: 13px;">\r\n<td style="height: 13px; width: 81.8667px;">Author</td>\r\n<td style="height: 13px; width: 192.133px;">System administrator</td>\r\n</tr>\r\n<tr style="height: 13px;">\r\n<td style="height: 13px; width: 81.8667px;">Released</td>\r\n<td style="height: 13px; width: 192.133px;">October 2014</td>\r\n</tr>\r\n<tr style="height: 13.1667px;">\r\n<td style="height: 13.1667px; width: 81.8667px;">Version</td>\r\n<td style="height: 13.1667px; width: 192.133px;">1.0</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Sample template</p>\r\n<p><a href="{UNSUBSCRIBE}">Unsubscribe me</a></p>\r\n<p><a href="{BROWSER_VIEW}">Browser view</a></p>\r\n</div>'
);
$sql = "
    INSERT INTO ".PREF."_template (id, date_create, date_modify, name, doctype, subject, html_header, body_attribs, content_html, content_txt, thumb_filename) VALUES
    (1, '2000-01-01 00:00:01', '2000-01-01 00:00:01', '".$template[0]."', '!DOCTYPE html', 'Dear {RECIPIENT_NAME} 🦠 😷.... 🔥', '<title>Example template</title>', 'class=\"myClass\"', '".$template[1]."', '', 'example-template.jpg');
";
$stmt = $db->prepare($sql);
$stmt->execute();

$sql = "
    INSERT INTO ".PREF."_template_thumb (filename) VALUES
    ('example-template.jpg')
";
$stmt = $db->prepare($sql);
$stmt->execute();

header("Location: index.php?manage=addons&action=import_sample_data&ok");
