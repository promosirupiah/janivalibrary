<?php

defined('_MAILING') or die('Restricted access');

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SPECIALS;?> <small>(<?php echo MENU_CLEAR_DB;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <?php
    if (isset($_GET['ok'])) {
    ?>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div role="alert" class="alert alert-success alert-dismissible fade in">
                <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
            <?php echo CHANGES_SAVED;?>
            </div>
        </div>
    <?php
    }
    ?>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo ADDONS_DB_TITLE;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <p>&nbsp;</p>
                <h2 class="red"><?php echo ADDONS_BE_CAREFULLY;?></h2>
                <p>&nbsp;</p>
    <table class="table table-striped">
    <tbody>
                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAll"><?php echo ADDONS_D_AL;?></a></td><td><?php echo ADDONS_D_AL_DESC;?></td></tr>
 
                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAllRecipients"><?php echo ADDONS_D_RE;?></a></td><td><?php echo ADDONS_D_RE_DESC;?></td></tr>

                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAllTags"><?php echo ADDONS_D_TG;?></a></td><td><?php echo ADDONS_D_TG_DESC;?></td></tr>

                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAllCampaigns"><?php echo ADDONS_D_CA;?></a></td><td><?php echo ADDONS_D_CA_DESC;?></td></tr>

                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAllTemplates"><?php echo ADDONS_D_TE;?></a></td><td><?php echo ADDONS_D_TE_DESC;?></td></tr>

                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAllAttachments"><?php echo ADDONS_D_AT;?></a></td><td><?php echo ADDONS_D_AT_DESC;?></td></tr>

                <tr><td><a class="btn btn-primary btn-xs" data-toggle="modal" data-target="#deleteAllSenders"><?php echo ADDONS_D_SE;?></a></td><td><?php echo ADDONS_D_SE_DESC;?></td></tr>
    </tbody>
    </table>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<div class="modal fade" id="deleteAllTags" tabindex="-1" role="dialog" aria-labelledby="deleteTags">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteTags"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="tags">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_TG_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteAllSenders" tabindex="-1" role="dialog" aria-labelledby="deleteSenders">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteSenders"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="senders">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_SE_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteAllAttachments" tabindex="-1" role="dialog" aria-labelledby="deleteAttachments">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteAttachments"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="attachments">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_AT_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteAllTemplates" tabindex="-1" role="dialog" aria-labelledby="deleteTemplates">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteTemplates"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="templates">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_TE_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteAllCampaigns" tabindex="-1" role="dialog" aria-labelledby="deleteCampaigns">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteCampaigns"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="campaigns">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_CA_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteAllRecipients" tabindex="-1" role="dialog" aria-labelledby="deleteRecipients">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteRecipients"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="recipients">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_RE_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteAll" tabindex="-1" role="dialog" aria-labelledby="deleteAllLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="deleteAllLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=addons&data=modify&action=clear_database" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="clear" value="all">
                    <div class="form-group">
                        <p><?php echo ADDONS_D_AL_CONF;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>