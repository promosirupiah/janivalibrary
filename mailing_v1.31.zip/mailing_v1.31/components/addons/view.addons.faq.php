<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SPECIALS;?> <small>(<?php echo MENU_FAQ;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo ADDONS_FAQ_TITLE;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content"><?php echo ADDONS_FAQ_DESCRIPTION;?></div>
        </div>
    </div>
</div>
<p>&nbsp;</p>