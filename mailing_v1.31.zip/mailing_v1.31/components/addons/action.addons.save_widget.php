<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=addons&action=subscribe_widget");
    exit();
}

$app->checkToken();

$afterSubscribe = isset($_POST['afterSubscribe']) ? $_POST['afterSubscribe'] : '0';
$afterSubscribeMessage = isset($_POST['afterSubscribeMessage']) ? $_POST['afterSubscribeMessage'] : '';
$afterSubscribeRedirectTo = isset($_POST['afterSubscribeRedirectTo']) ? $_POST['afterSubscribeRedirectTo'] : '';
$afterSubscribeTags = isset($_POST['afterSubscribeTags']) ? $_POST['afterSubscribeTags'] : '';
$afterSubscribeComment = isset($_POST['afterSubscribeComment']) ? $_POST['afterSubscribeComment'] : '';
$SubscriberShowName = isset($_POST['SubscriberShowName']) ? '1' : '0';
$subscribeDblOptIn = isset($_POST['subscribeDblOptIn']) ? '1' : '0';
$subscribeEmailMessage = isset($_POST['subscribeEmailMessage']) ? $_POST['subscribeEmailMessage'] : '';
$subscribeEmailTitle = isset($_POST['subscribeEmailTitle']) ? $_POST['subscribeEmailTitle'] : '';
$subscribeRedirectConfirmedTo = isset($_POST['subscribeRedirectConfirmedTo']) ? $_POST['subscribeRedirectConfirmedTo'] : '';
$subscribeEmailAddressFrom = isset($_POST['subscribeEmailAddressFrom']) ? $_POST['subscribeEmailAddressFrom'] : '';
$subscribeEmailDescriptionFrom = isset($_POST['subscribeEmailDescriptionFrom']) ? $_POST['subscribeEmailDescriptionFrom'] : '';
$adminSubscribtionNotify = isset($_POST['adminSubscribtionNotify']) ? '1' : '0';
$adminEmailMessage = isset($_POST['adminEmailMessage']) ? $_POST['adminEmailMessage'] : '';
$subscribeErrorMessage = isset($_POST['subscribeErrorMessage']) ? $_POST['subscribeErrorMessage'] : '';
$serverEmailSenderID = isset($_POST['serverEmailSenderID']) ? $_POST['serverEmailSenderID'] : '';
$subscriptionFormToken = isset($_POST['subscriptionFormToken']) ? $_POST['subscriptionFormToken'] : '';
$subscriptionEmailToken = isset($_POST['subscriptionEmailToken']) ? $_POST['subscriptionEmailToken'] : '';

$app->changeSetting('afterSubscribe', $afterSubscribe);
$app->changeSetting('afterSubscribeMessage', $afterSubscribeMessage);
$app->changeSetting('afterSubscribeRedirectTo', $afterSubscribeRedirectTo);
$app->changeSetting('afterSubscribeTags', $afterSubscribeTags);
$app->changeSetting('afterSubscribeComment', $afterSubscribeComment);
$app->changeSetting('SubscriberShowName', $SubscriberShowName);
$app->changeSetting('subscribeDblOptIn', $subscribeDblOptIn);
$app->changeSetting('subscribeEmailTitle', $subscribeEmailTitle);
$app->changeSetting('subscribeEmailMessage', base64_encode($subscribeEmailMessage));
$app->changeSetting('subscribeRedirectConfirmedTo', $subscribeRedirectConfirmedTo);
$app->changeSetting('subscribeEmailAddressFrom', $subscribeEmailAddressFrom);
$app->changeSetting('subscribeEmailDescriptionFrom', $subscribeEmailDescriptionFrom);
$app->changeSetting('adminSubscribtionNotify', $adminSubscribtionNotify);
$app->changeSetting('adminEmailMessage', base64_encode($adminEmailMessage));
$app->changeSetting('subscribeErrorMessage', $subscribeErrorMessage);
$app->changeSetting('serverEmailSenderID', $serverEmailSenderID);
$app->changeSetting('subscriptionFormToken', $subscriptionFormToken);
$app->changeSetting('subscriptionEmailToken', $subscriptionEmailToken);

header("Location: index.php?manage=addons&action=subscribe_widget");
