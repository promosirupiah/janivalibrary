<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "clear_database":
        $load = "action.addons.clear_database.php";
        break;
    case "insert_templates":
        $load = "action.addons.insert_templates.php";
        break;
    case "insert_data":
        $load = "action.addons.insert_sample_data.php";
        break;
    case "save_widget":
        $load = "action.addons.save_widget.php";
        break;
    case "clear_db":
        $load = "view.addons.clear_db.php";
        break;
    case "import_templates":
        $load = "view.addons.import_templates.php";
        break;
    case "faq":
        $load = "view.addons.faq.php";
        break;
    case "about":
        $load = "view.addons.about.php";
        break;
    case "import_sample_data":
        $load = "view.addons.import_sample_data.php";
        break;
    case "subscribe_widget":
        $load = "view.addons.subscribe_widget.php";
        break;
    default:
        $load = "view.addons.about.php";
        break;
}

include($load);	
