"use strict";

(function(){
    if ($("input.flat")[0]) {
        $(document).ready(function () {
            $('input.flat').iCheck({
                checkboxClass: 'icheckbox_flat-green',
                radioClass: 'iradio_flat-green'
            });
        });
    }
    
    $(document).ready(function(){

        $('div.checkbox label.mytags , ins').on('click', function() {
           var tags = [];
           $('input.tags:checked').each(function(){
               tags.push($(this).val())
           });
           $('#formTags').html(tags.join(','));
           $('input[name=afterSubscribeTags]').val(tags.join(','));
           if (tags.length > 0){
               $('#formLineTags').show();
           } else {
               $('#formLineTags').hide();
           }
        });

        $('div label.myRedirect , ins').on('click', function() {
           var chk = $('input.myRedirect:checked').val();
           if (chk == 2){
               $('#formLineRedirect').show();
               $('#formRedirectVal').html($('#redirectto').val());
           } else {
               $('#formLineRedirect').hide();
               $('#formRedirectVal').html('');
           }
        });

        $('div label.myName , ins').on('click', function() {
           var chk = ($('input.myName:checked').length > 0) ? 1 : 0;
           if (chk == 1){
               $('#formLineName').show();
           } else {
               $('#formLineName').hide();
           }
        });

        $('div label.myWebsite , ins').on('click', function() {
           var chk = ($('input.myWebsite:checked').length > 0) ? 1 : 0;
           if (chk == 1){
               $('#formLineWebsite').show();
           } else {
               $('#formLineWebsite').hide();
           }
        });

        $('div label.myDblOptIn , ins').on('click', function() {
           var chk = ($('input.myDblOptIn:checked').length > 0) ? 1 : 0;
           if (chk == 1){
               $('#formLineDblOptIn').show();
           } else {
               $('#formLineDblOptIn').hide();
           }
        });

        $('#redirectto').on('keyup', function() {
           $('#formRedirectVal').html($('#redirectto').val());
        });

        $('#recipientcomment').on('keyup', function() {
           var chk = $('#recipientcomment').val().length;
           if (chk > 0){
               $('#formLineComment').show();
           } else {
               $('#formLineComment').hide();
           }
           $('#formCommentVal').html($('#recipientcomment').val());
        });

        $('#subscriptionFormToken').on('keyup change', function() {
           var token = $(this).val();
           $('.formLineSubscriptionFormToken').html(token);
        });
        
    });
})();