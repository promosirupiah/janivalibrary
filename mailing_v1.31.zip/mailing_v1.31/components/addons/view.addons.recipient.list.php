<?php

defined('_MAILING') or die('Restricted access');

?>
<div class="modal fade" id="recipientDelete" tabindex="-1" role="dialog" aria-labelledby="recipienDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="recipienDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=recipient&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="recipientid" class="recipientid" value="">
                    <div class="form-group">
                        <label for="recipientname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control recipientname" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo RECIPIENT_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo RECIPIENT_DB;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="recipients">
                    <thead>
                        <tr><th>id</th><th><?php echo PERSON; ?></th><th><?php echo EMAIL;?></th><th><?php echo TAGS;?></th><th><?php echo RECIPIENT_DESCRIPTION;?></th><th></th></tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <a href="index.php?manage=recipient&action=add" class="btn btn-primary"><?php echo MENU_ADD_RECIPIENT;?></a>
        </div>
    </div>
</div>

<script src="libs/datatable/dataTables-1.10.7.js"></script>
<script src="components/addons/view.addons.recipient.list.js"></script>
