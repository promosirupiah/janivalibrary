<?php

defined('_MAILING') or die('Restricted access');

$subscribelink = HTTP.'://'.$_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'].'?manage=campaign&action=subscribe';

$server_select = '';

$afterSubscribe = Settings::$afterSubscribe;
$afterSubscribeMessage = Settings::$afterSubscribeMessage;
$afterSubscribeRedirectTo = Settings::$afterSubscribeRedirectTo;
$afterSubscribeTags = Settings::$afterSubscribeTags;
$afterSubscribeComment = Settings::$afterSubscribeComment;
$SubscriberShowName = Settings::$SubscriberShowName;
$SubscriberShowWebsite = Settings::$SubscriberShowWebsite;
$subscribeDblOptIn = Settings::$subscribeDblOptIn;
$subscribeEmailMessage = base64_decode(Settings::$subscribeEmailMessage);
$subscribeEmailTitle = Settings::$subscribeEmailTitle;
$subscribeRedirectConfirmedTo = Settings::$subscribeRedirectConfirmedTo;
$subscribeErrorMessage = Settings::$subscribeErrorMessage;
$subscribeEmailAddressFrom = Settings::$subscribeEmailAddressFrom;
$subscribeEmailDescriptionFrom = Settings::$subscribeEmailDescriptionFrom;
$adminSubscribtionNotify = Settings::$adminSubscribtionNotify;
$adminEmailMessage = base64_decode(Settings::$adminEmailMessage);
$serverEmailSenderID = Settings::$serverEmailSenderID;
$subscriptionFormToken = Settings::$subscriptionFormToken;
$subscriptionEmailToken = Settings::$subscriptionEmailToken;

$tags_option = '';

$tags = $db->query(" select * from ".PREF."_recipient_tag order by name asc");
foreach ($tags as $tag) {
    $checked = strpos("___".$afterSubscribeTags, $tag['name']) ? 'checked=\"checked\"' : "";
    $tags_option .= "<div class='checkbox'><label class='mytags'><input class='flat tags' type='checkbox' name='tags[]' value='".$tag['name']."' ".$checked.">&nbsp;".$tag['name']."</label></div>";
}

$styles = '<style>';
    $styles .= $afterSubscribe == '2' ? "#formLineRedirect{display:block;}" : "#formLineRedirect{display:none;}";
    $styles .= $afterSubscribeComment != '' ? "#formLineComment{display:block;}" : "#formLineComment{display:none;}";
    $styles .= $SubscriberShowName == '1' ? "#formLineName{display:block;}" : "#formLineName{display:none;}";
    $styles .= $SubscriberShowWebsite == '1' ? "#formLineWebsite{display:block;}" : "#formLineWebsite{display:none;}";
    $styles .= $afterSubscribeTags != '' ? "#formLineTags{display:block;}" : "#formLineTags{display:none;}";
    $styles .= $subscribeDblOptIn != '0' ? "#formLineDblOptIn{display:block;}" : "#formLineDblOptIn{display:none;}";
    $styles .= "textarea#dbloptinEmail{height:200px !important;}";
$styles .= '</style>';
    
// choose sending server
if ((int)(Settings::$useSMTP)) {
    $selected = $serverEmailSenderID == '0' ? "selected" : "";
    $server_select = "<option value=''> - select smtp server - </option>";
    
    $result = $db->query(" SELECT * FROM ".PREF."_smtp ");
    foreach ($result as $row) {
        $selected = $serverEmailSenderID == $row['id'] ? "selected" : "";
        $server_select .= "<option value='".$row['id']."' ".$selected.">".$row['name']."&nbsp;-&nbsp;".$row['host']."</option>";
    }
} else {
    $server_select = "<option value='0' selected='selected'>PHP mail()</option>";
}
?>
<?php echo $styles; ?>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SUBSCRIBE_WIDGET;?> <small>(<?php echo CONFIG;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo WIDGET_PREPARE;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

<div data-example-id="togglable-tabs" role="tabpanel" class="">
    <ul role="tablist" class="nav nav-tabs bar_tabs" id="myTab">
        <li class="active" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab" role="tab" href="#tab_content2"><?php echo WIDGET_OPTIONS;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab2" role="tab" href="#tab_content3"><?php echo WIDGET_HTML;?></a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">

        <div aria-labelledby="profile-tab" id="tab_content2" class="tab-pane fade active in" role="tabpanel">

            <p><?php echo WIDGET_GENERATE;?>. <?php echo WIDGET_USE_THIS_CODE;?></p>
            <code class="block">&lt;form method="post" action="<?php echo $subscribelink;?>"&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="email" name="recipientmail" placeholder="Enter email" required /&gt;<br>
            <span id="formLineName">&nbsp;&nbsp;&nbsp;&lt;input type="text" name="recipientname" placeholder="Enter Name" /&gt;<br></span>
            <span id="formLineWebsite">&nbsp;&nbsp;&nbsp;&lt;input type="text" name="recipientwebsite" placeholder="Enter url" /&gt;<br></span>
            <span id="formLineTags">&nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="tags" value="<span id="formTags"><?php echo $afterSubscribeTags; ?></span>" /&gt;<br></span>
            <span id="formLineComment">&nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="recipientcomment" value="<span id="formCommentVal"><?php echo $afterSubscribeComment; ?></span>" /&gt;<br></span>
            <span id="formLineRedirect">&nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="redirectto" value="<span id="formRedirectVal"><?php echo $afterSubscribeRedirectTo; ?></span>" /&gt;<br></span>
            <span id="formLineDblOptIn">&nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="dbloptin" value="1" /&gt;<br></span>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="subscriptionFormToken" value="<span class="formLineSubscriptionFormToken"><?php echo $subscriptionFormToken;?></span>" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="submit" value="submit" /&gt;<br>
            &lt;/form&gt;</code>
            <hr>
            <form id="widget_form" class="form-horizontal" method="post" action="index.php?manage=addons&data=modify&action=save_widget">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" name="afterSubscribeTags" value="<?php echo $afterSubscribeTags;?>">
                <input type="hidden" name="adata" value="1">
                
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="recipientcomment"><?php echo WIDGET_COMMENT;?></label>
                    <div class="col-sm-6">
                      <input
                            type="text"
                            class="form-control"
                            id="recipientcomment"
                            name="afterSubscribeComment"
                            value="<?php echo $afterSubscribeComment; ?>"
                            placeholder="<?php echo WIDGET_COMMENT_PLACEHOLDER;?>" 
                            >
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="recipientcomment"><?php echo WIDGET_NAME;?></label>
                    <div class="col-sm-6">
                        <div class='checkbox'>
                            <label class="myName">
                                <input class='flat myName' type='checkbox' name='SubscriberShowName' value='1' <?php echo $SubscriberShowName == '1' ? 'checked="checked"' : "" ;?>>&nbsp;<?php echo WIDGET_NAME_SHOW;?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="recipientwebsite"><?php echo WEBSITE;?></label>
                    <div class="col-sm-6">
                        <div class='checkbox'>
                            <label class="myWebsite">
                                <input class='flat myWebsite' type='checkbox' name='SubscriberShowWebsite' value='1' <?php echo $SubscriberShowWebsite == '1' ? 'checked="checked"' : "" ;?>>&nbsp;<?php echo WIDGET_WEBSITE_SHOW;?>
                            </label>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="afterSubscribe"><?php echo WIDGET_AFTER;?></label>
                    <div class="col-sm-6">
                        <div class="radio">
                            <label class="myRedirect">
                            <div class="iradio_flat-green">
                                <input value="0" type="radio" name="afterSubscribe" class="flat myRedirect" <?php echo $afterSubscribe == '0' ? 'checked="checked"' : ''; ?>>
                                <ins class="iCheck-helper"></ins>
                            </div>&nbsp;<?php echo WIDGET_AFTER_NOTHING;?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="afterSubscribe"></label>
                    <div class="col-sm-4">
                        <div class="radio">
                            <label class="myRedirect">
                            <div class="iradio_flat-green">
                                <input value="1" type="radio" name="afterSubscribe" class="flat myRedirect" <?php echo $afterSubscribe == '1' ? 'checked="checked"' : ''; ?>>
                                <ins class="iCheck-helper"></ins>
                            </div> <?php echo WIDGET_AFTER_TXT;?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="message">&nbsp;</label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="message" 
                            name="afterSubscribeMessage"
                            value="<?php echo $afterSubscribeMessage; ?>"
                            >
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="afterSubscribe"></label>
                    <div class="col-sm-4">
                        <div class="radio">
                            <label class="myRedirect">
                            <div class="iradio_flat-green">
                                <input value="2" type="radio" name="afterSubscribe" class="flat myRedirect" <?php echo $afterSubscribe == '2' ? 'checked="checked"' : ''; ?>>
                                <ins class="iCheck-helper"></ins>
                            </div> <?php echo WIDGET_AFTER_REDIRECT;?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="redirectto">&nbsp;</label>
                    <div class="col-sm-6">
                        <input 
                            type="url" 
                            class="form-control" 
                            id="redirectto" 
                            name="afterSubscribeRedirectTo" 
                            value="<?php echo $afterSubscribeRedirectTo; ?>" 
                            >
                    </div>
                </div>
                <hr>
                <div class="form-group" id="tagi">
                    <label class="col-sm-3 control-label" for="db_name"><?php echo WIDGET_TAGS;?></label>
                    <div class="col-sm-2">
                        <?php echo $tags_option; ?>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="dbloptin"><?php echo WIDGET_DBL_OPT_IN;?></label>
                    <div class="col-sm-6">
                        <div class='checkbox'>
                            <label class='myDblOptIn'>
                                <input class='flat myDblOptIn' type='checkbox' name='subscribeDblOptIn' <?php echo $subscribeDblOptIn == '1' ? 'checked="checked"' : "" ;?>>&nbsp;<?php echo WIDGET_DBL_OPT_LABEL;?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="subscribeEmailAddressFrom"><?php echo WIDGET_DBL_OPT_ADR_EMAIL;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="message_title" 
                            name="subscribeEmailAddressFrom"
                            placeholder="<?php echo WIDGET_DBL_OPT_ADR_PLACEHOLDER;?>"
                            value="<?php echo $subscribeEmailAddressFrom; ?>"
                            >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="subscribeEmailDescriptionFrom"><?php echo WIDGET_DBL_OPT_DESC_EMAIL;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="message_title" 
                            name="subscribeEmailDescriptionFrom"
                            placeholder="<?php echo WIDGET_DBL_OPT_DESC_PLACEHOLDER;?>"
                            value="<?php echo $subscribeEmailDescriptionFrom; ?>"
                            >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="subscribeEmailTitle"><?php echo WIDGET_DBL_OPT_TITLE_EMAIL;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="message_title" 
                            name="subscribeEmailTitle"
                            placeholder="<?php echo WIDGET_DBL_OPT_TITLE_PLACEHOLDER;?>"
                            value="<?php echo $subscribeEmailTitle; ?>"
                            >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="subscribeEmailMessage"><?php echo WIDGET_DBL_OPT_LABEL_EMAIL;?></label>
                    <div class="col-sm-6">
                      <textarea
                            type="text"
                            class="form-control"
                            id="dbloptinEmail"
                            name="subscribeEmailMessage"
                            placeholder="<?php echo WIDGET_DBL_OPT_MESSAGE_PLACEHOLDER;?>"
                            ><?php echo $subscribeEmailMessage; ?></textarea>
                      <span><?php echo WIDGET_DBL_OPT_HELP;?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="subscribeRedirectConfirmedTo"><?php echo WIDGET_DBL_OPT_REDIRECT_TO_LABEL;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="message_title" 
                            name="subscribeRedirectConfirmedTo"
                            placeholder="<?php echo WIDGET_DBL_OPT_REDIRECT_TO_PLACEHOLDER;?>"
                            value="<?php echo $subscribeRedirectConfirmedTo; ?>"
                            >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="subscribeErrorMessage"><?php echo WIDGET_ERROR_MESSAGE_LABEL;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="message_title" 
                            name="subscribeErrorMessage"
                            placeholder=""
                            value="<?php echo $subscribeErrorMessage; ?>"
                            >
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="dbloptin"><?php echo WIDGET_ADMIN_NOTIFY;?></label>
                    <div class="col-sm-6">
                        <div class='checkbox'>
                            <label class=''>
                                <input class='flat ' type='checkbox' name='adminSubscribtionNotify' <?php echo $adminSubscribtionNotify == '1' ? 'checked="checked"' : "" ;?>>&nbsp;<?php echo WIDGET_ADMIN_NOTIFY_LABEL;?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="adminEmailMessage"><?php echo WIDGET_ADMIN_LABEL_EMAIL;?></label>
                    <div class="col-sm-6">
                      <textarea
                            type="text"
                            class="form-control"
                            id="dbloptinEmail"
                            name="adminEmailMessage"
                            ><?php echo $adminEmailMessage; ?></textarea>
                      <span><?php echo WIDGET_ADMIN_HELP;?></span>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <label for="smtpid" class="col-sm-3 control-label"><?php echo WIDGET_SERVERID_LABEL;?></label>
                    <div class="col-sm-6">
                        <select class="form-control" name="serverEmailSenderID" required>
                            <?php echo $server_select; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="subscriptionFormToken" class="col-sm-3 control-label"><?php echo WIDGET_FORM_TOKEN;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="subscriptionFormToken" 
                            name="subscriptionFormToken"
                            placeholder=""
                            value="<?php echo $subscriptionFormToken; ?>"
                            >
                    </div>
                </div>
                <div class="form-group">
                    <label for="subscriptionEmailToken" class="col-sm-3 control-label"><?php echo WIDGET_EMAIL_TOKEN;?></label>
                    <div class="col-sm-6">
                        <input 
                            type="text" 
                            class="form-control" 
                            id="subscriptionEmailToken" 
                            name="subscriptionEmailToken"
                            placeholder=""
                            value="<?php echo $subscriptionEmailToken; ?>"
                            >
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-2">
                      <button type="submit" class="btn btn-primary"><?php echo SAVE; ?></button>
                    </div>
                </div>
            </form>
            <p>&nbsp;</p>

                            

        </div>
        <div aria-labelledby="profile-tab" id="tab_content3" class="tab-pane fade" role="tabpanel">
            <p><?php echo WIDGET_PURE_CODE_TXT;?></p>
            <h2><?php echo WIDGET_FULL_CODE_TXT;?></h2>
            <code class="block">&lt;form method="post" action="<?php echo $subscribelink;?>"&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="email" name="recipientmail" placeholder="Enter email" required /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="text" name="recipientname" placeholder="Enter Name" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="text" name="recipientwebsite" placeholder="Enter url" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="tags" value="" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="recipientcomment" value="" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="redirectto" value="" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="dbloptin" value="1" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="subscriptionFormToken" value="<span class="formLineSubscriptionFormToken"><?php echo $subscriptionFormToken;?></span>" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="submit" value="submit" /&gt;<br>
            &lt;/form&gt;</code>
            <h2><?php echo WIDGET_MIN_CODE_TXT;?></h2>
            <code class="block">&lt;form method="post" action="<?php echo $subscribelink;?>"&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="email" name="recipientmail" placeholder="Enter email" required /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="hidden" name="subscriptionFormToken" value="<span class="formLineSubscriptionFormToken"><?php echo $subscriptionFormToken;?></span>" /&gt;<br>
            &nbsp;&nbsp;&nbsp;&lt;input type="submit" value="submit" /&gt;<br>
            &lt;/form&gt;</code>
            <h2><?php echo WIDGET_CODE_DESC_TXT;?></h2>
            <ul>
                <li>
                    <code>&lt;input type="email" name="recipientmail" placeholder="Enter email" required /&gt;</code>
                    <ul><?php echo WIDGET_MAIL_DESC_TXT;?></ul>
                </li>
                <li>
                    <code>&lt;input type="text" name="recipientname" placeholder="Enter Name" /&gt;</code>
                    <ul><?php echo WIDGET_NAME_DESC_TXT;?></ul>
                </li>
                <li>
                    <code>&lt;input type="hidden" name="tags" value="" /&gt;</code>
                    <ul><?php echo WIDGET_TAGS_DESC_TXT;?></ul>
                </li>
                <li>
                    <code>&lt;input type="hidden" name="recipientcomment" value="" /&gt;</code>
                    <ul><?php echo WIDGET_COMMENT_DESC_TXT;?></ul>
                </li>
                <li>
                    <code>&lt;input type="hidden" name="dbloptin" value="1" /&gt;</code>
                    <ul><?php echo WIDGET_DBL_OPT_IN_DESC_TXT;?></ul>
                </li>
                <li>
                    <code>&lt;input type="hidden" name="redirectto" value="" /&gt;</code>
                    <ul><?php echo WIDGET_REDIRECT_DESC_TXT;?></ul>
                </li>
            </ul>
        </div>
        
        
        
        
    </div>
</div>

            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<script src="components/addons/subscribe_widget.js"></script>                                              


