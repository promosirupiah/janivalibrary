<?php

defined('_MAILING') or die('Restricted access');

$tags = Settings::$afterSubscribeTags;
/*
allow_url_include = 1      
allow_url_fopen = 1 
*/
?><!DOCTYPE html>
<html lang="en">
    <head>
        <link href="production/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <form class="form-horizontal" method="post" action="<?php echo HTTP;?>://localhost/mailing/index.php?manage=campaign&action=subscribe">
<input type="hidden" name="redirectto" value="http://google.pl">
              <div class="col-lg-2">
                <div class="input-group">
                  <input type="email" name="recipientmail" class="form-control" placeholder="me@example.com" required>
                  <span class="input-group-btn">
                    <button class="btn btn-primary" type="submit">Register</button>
                  </span>
                </div>
              </div>

        </form>
    </body>
</html>


<?php
exit();
?>