<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=addons&action=clear_db&ok");
    exit();
}

$app->checkToken();

$clear = $_POST['clear'];

$truncateCamp = false;
$truncateCampRecConn = false;
$truncateRecipient = false;
$truncateTag = false;
$truncateRecTagConn = false;
$truncateSender = false;
$truncateTemp = false;
$truncateTempAttConn = false;
$truncateAtt = false;
$truncateGeolocation = false;
$truncateTempThumbnail = false;
$deleteTemp = false;

switch ($clear) {
    case "senders":
        $truncateSender = true;
        break;
    case "attachments":
        $truncateTempAttConn = true;
        $truncateAtt = true;
        break;
    case "templates":
        $truncateTempAttConn = true;
        $truncateTempThumbnail = true;
        $deleteTemp = true;
        break;
    case "campaigns":
        $truncateCamp = true;
        $truncateCampRecConn = true;
        break;
    case "recipients":
        $truncateRecipient = true;
        $truncateRecTagConn = true;
        break;
    case "tags":
        $truncateTag = true;
        $truncateRecTagConn = true;
        break;
    case "all":
        $truncateCamp = true;
        $truncateCampRecConn = true;
        $truncateRecipient = true;
        $truncateTag = true;
        $truncateRecTagConn = true;
        $truncateSender = true;
        $truncateTemp = true;
        $truncateTempAttConn = true;
        $truncateAtt = true;
        $truncateGeolocation = true;
        $truncateTempThumbnail = true;
        break;
}

// delete campaigns
if ($truncateCamp) {
    $sql = " truncate table ".PREF."_campaign ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete connection between recipients and tags
if ($truncateCampRecConn) {
    $sql = " truncate table ".PREF."_campaign_rec_conn ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete recipients
if ($truncateRecipient) {
    $sql = " truncate table ".PREF."_recipient ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete tags
if ($truncateTag) {
    $sql = " truncate table ".PREF."_recipient_tag ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete connection between recipients and tags
if ($truncateRecTagConn) {
    $sql = " truncate table ".PREF."_recipient_tag_conn ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete senders
if ($truncateSender) {
    $sql = " truncate table ".PREF."_sender ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete templates
if ($truncateTemp) {
    $sql = " truncate table ".PREF."_template ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete template thumbnails
if ($truncateTempThumbnail) {
    $sql = " truncate table ".PREF."_template_thumb ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete templates and keep ID increment value
if ($deleteTemp) {
    $sql = " delete from ".PREF."_template ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete connection between templates and attachments
if ($truncateTempAttConn) {
    $sql = " truncate table ".PREF."_template_att_conn ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete attachments
if ($truncateAtt) {
    $result = $db->query(" select * from ".PREF."_template_att ");
    foreach ($result as $row) {
        unlink($_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).'/uploads/'.$row['filename']);
    }
    $sql = " truncate table ".PREF."_template_att ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

// delete geolocation data
if ($truncateGeolocation) {
    $sql = " truncate table ".PREF."_geolocation ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

header("Location: index.php?manage=addons&action=clear_db&ok");
