<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SPECIALS;?> <small>(<?php echo MENU_ABOUT;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo ADDONS_ABOUT_TITLE;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <p>&nbsp;</p>
                <p>WARRANTY - this software has a full warranty to work carrectly in case of no any changes in the script files.</p>
                <p>FULL SUPPORT - please do not hesitate to ask in case of any problem.</p>
                <p>You are using this software at your own risk. Any liability associated with the misuse of this software is on your side. <br>Please report any bugs to <b>webmaster@pklopotowski.pl</b>.</p>
                <p>For commercial usage:<br>License Type: Free Trial<br>Additional Info: Free trial of software for 15 days<br>The usage of this program for commercial purposes after the trial period is illegal. Please consider to buy full licensed version.</p>
                <p>For personal usage MIT lecense is granted.</p>
                <p>For those who have bought this product GPL license is granted.</p>
                <p>&nbsp;</p>
                <p>Tanks to:</p>
                <p><a href="http://jquery.com" taget="_blank">JQuery</a>, <a href="http://getbootstrap.com" target="_blank">Bootstrap</a>, <a href="http://datatables.net" target="_blank">dataTables</a>, <a href="https://www.tinymce.com/" target="_blank">TinyMCE</a></p>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>