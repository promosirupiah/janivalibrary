<?php

defined('_MAILING') or die('Restricted access');

$stmt = $db->prepare(" select * from ".PREF."_recipient_tag where id=? ");
$id = (int)($_GET['id']);
$stmt->bindParam(1, $id, PDO::PARAM_INT);
$stmt->execute();
$row = $stmt->fetchAll();

// in case you want to edit not existent data
if (! @$data = $row[0]){
    echo DATA_ERROR;
    exit();
}


$tagname = $data['name'];
$description = $data['description'];

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo TAGS_ADD_EDIT;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo TAGS_INFO;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" action="index.php?manage=tags&data=modify&action=update" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <input type="hidden" name="id" value="<?php echo $id;?>">
                    <div class="form-group">
                    <label for="tagname" class="col-sm-2 control-label"><?php echo TAGS_NAME;?>*</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="tagname" 
                                name="tagname" 
                                value="<?php echo $tagname;?>" 
                                placeholder="<?php echo TAGS_NAME_PLACEHOLDER;?>"
                                required>
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="description" class="col-sm-2 control-label"><?php echo TAGS_DESCRIPTION;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="description" 
                                name="description" 
                                value="<?php echo $description;?>" 
                                placeholder="<?php echo TAGS_DESCRIPTION_PLACEHOLDER;?>"
                                >
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <a href="index.php?manage=tags&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-3 col-sm-1">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>
