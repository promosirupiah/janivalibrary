<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=tags&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['tagid'];

$sql = " DELETE FROM ".PREF."_recipient_tag WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

$sql = " DELETE FROM ".PREF."_recipient_tag_conn WHERE id_tag = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

header("Location: index.php?manage=tags&action=list");
