"use strict";

$(document).ready(function () {
    
    $('#tagDelete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var tagname = button.data('tagname');
        var tagid = button.data('tagid');
        var modal = $(this);
        modal.find('.tagid').val(tagid);
        modal.find('.tagname').val(tagname);
    });
        
    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    
    $('#tags').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });

});