<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.tags.add.php";
        break;
    case "edit":
        $load = "view.tags.edit.php";
        break;
    case "list":
        $load = "view.tags.list.php";
        break;
    case "import":
        $load = "action.tags.import.csv.php";
        break;
    case "update":
        $load = "action.tags.update.php";
        break;
    case "insert":
        $load = "action.tags.insert.php";
        break;
    case "delete":
        $load = "action.tags.delete.php";
        break;
    default:
        $load = "view.tags.list.php";
        break;
}

include($load);	
