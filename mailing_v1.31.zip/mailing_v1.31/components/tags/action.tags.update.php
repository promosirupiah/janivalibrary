<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=tags&action=list");
    exit();
}

$app->checkToken();

$date_modify = date("Y-m-d H:i:s", time());
$tagname = $_POST['tagname'];
$description = $_POST['description'];
$id = (int)$_POST['id'];

$sql = "
    UPDATE 
        ".PREF."_recipient_tag
    SET 
        name = :tagname,
        description = :description
    WHERE 
        id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':tagname', $tagname, PDO::PARAM_STR);
$stmt->bindParam(':description', $description, PDO::PARAM_STR);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();

header("Location: index.php?manage=tags&action=list");
