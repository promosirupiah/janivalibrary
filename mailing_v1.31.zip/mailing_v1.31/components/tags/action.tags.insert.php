<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=tags&action=list");
    exit();
}

$app->checkToken();

$tagname = $_POST['tagname'];
$description = $_POST['description'];

$sql = "
    INSERT INTO ".PREF."_recipient_tag (
        name,
        description
    ) VALUES (
        :tagname,
        :description
    )
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':tagname', $tagname, PDO::PARAM_STR);
$stmt->bindParam(':description', $description, PDO::PARAM_STR);
$stmt->execute();

header("Location: index.php?manage=tags&action=list");
