<?php

defined('_MAILING') or die('Restricted access');

$id_campaign = (int)($_GET['c']);
$id_recipient = (int)($_GET['r']);

if ($id_campaign == 0 || $id_recipient == 0) {
    exit();
}

$app->loadLanguage();

$sql = "
    UPDATE ".PREF."_campaign_rec_conn SET 
        status = '3' 
    WHERE 1
        and id_campaign 	= :id_campaign
        and id_recipient 	= :id_recipient
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':id_campaign', $id_campaign, PDO::PARAM_STR);
$stmt->bindParam(':id_recipient', $id_recipient, PDO::PARAM_STR);
$stmt->execute(); 

if (Settings::$deleteUnsubscribed == '1') {
    $sql = " DELETE FROM ".PREF."_recipient WHERE id = :id ";
    $stmt = $db->prepare($sql);              
    $stmt->bindParam(':id', $id_recipient, PDO::PARAM_INT);   
    $stmt->execute(); 
}

echo UNSUBSCRIBE_MESSAGE;


exit();