"use strict";

$(document).ready(function(){

    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    $('#waitingCampaign').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });

    $('#campaignDelete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var campaignname = button.data('campaignname');
        var campaignid = button.data('campaignid');
        var modal = $(this);
        modal.find('.campaignname').val(campaignname);
        modal.find('.campaignid').val(campaignid);
    });
    
    $('a.cron').on('click', function() {
        id_campaign = $(this).attr('data-id');
        $('#cron_id').html(id_campaign);
    });
    
    $('#notify_admin').hide();
    
    $('#cron_admin').on('update keyup', function() {
        var email = $(this).val(),
            notify = email == '' ? 0 : 1;
        $('#cron_email').html(email);
        $('#cron_notify').html(notify);
        if (! notify) {
            $('#notify_admin').hide();
        } else {
            $('#notify_admin').show();
        }
    });
    
    $('#select_smtp').on('click change update', function() {
        var id = $('#select_smtp option:selected').val();
        $('#cron_smtpid').html(id);
    });

});