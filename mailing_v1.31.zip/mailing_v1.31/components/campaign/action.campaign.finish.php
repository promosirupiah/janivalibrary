<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    //header("Location: index.php?manage=campaign&action=waiting");
    exit();
}

$app->checkToken();

$id_campaign = (int)($_POST['id_campaign']);

$sql = " UPDATE ".PREF."_campaign SET status = '2' WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id_campaign, PDO::PARAM_INT);
$stmt->execute(); 
