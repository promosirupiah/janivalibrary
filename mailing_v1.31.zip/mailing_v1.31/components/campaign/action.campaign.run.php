<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    echo "ok";
    exit();
}

// check security
$app->checkToken();

// get main data
$id_campaign    = (int)($_POST['id_campaign']);
$smtpid         = (int)($_POST['smtpid']);
$multi_smtp     = isset($_POST['multi_smtp']) ? true : false;

// just in case
if ($id_campaign == 0) {
    die("Access denied");
}

// update campaign data (1 - during AJAX sending)
$sql = "
    UPDATE ".PREF."_campaign SET
        date_start = '".date("Y-m-d H:i:s", time())."',
        status = '1'
    WHERE id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':id', $id_campaign, PDO::PARAM_INT);
$stmt->execute();

// prepare params
$params['id_campaign'] = $id_campaign;
$params['smtpid'] = $smtpid;
$params['notify_admin'] = '0';
$params['email_admin'] = '';
$params['db'] = $db;
$params['cron'] = false;
$params['cron_token'] = '';
$params['debug'] = DEBUG;
$params['multi_smtp'] = $multi_smtp;

if (! $app->sendEmail($params)) {
    echo "stop";
    exit();
}



