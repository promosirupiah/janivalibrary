"use strict";

$(document).ready(function(){
    
    $('#campaignDelete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var campaignname = button.data('campaignname');
        var campaignid = button.data('campaignid');
        var modal = $(this);
        modal.find('.campaignname').val(campaignname);
        modal.find('.campaignid').val(campaignid);
    })

    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    $('#waitingCampaign').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });

    function checkProgress(){
        $.each(
            $('.camp_progress'),
            function(){
                var id_elem = this.id;
                $.ajax({
                    method : 'POST',
                    url : 'index.php?manage=campaign&data=modify&action=check',
                    data : {
                        id_campaign : id_elem
                    },
                    success: function (data, textStatus, jqXHR) {
                        if (data.substring(0,3) == '100') {
                            $('#td_' + id_elem).html(lang_c_finished);
                            $('#' + id_elem).removeClass('camp_progress');
                        }
                        $('#' + id_elem).html(data);
                    }
                });
            }
        );
        setTimeout(checkProgress, 15000);
    }
    checkProgress();

});