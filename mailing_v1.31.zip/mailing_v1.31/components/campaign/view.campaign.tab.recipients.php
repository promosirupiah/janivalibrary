<?php

defined('_MAILING') or die('Restricted access');

    $tagsList = '';
    $tagsList3 = '';
    $queryLogic = '
    <div class="radio pull-right">
        <label data-toggle="tooltip" data-placement="top" title="" data-original-title="'.REC_QUERY_OR.'">
            <div class="icheckbox_flat pull-left">
                <input id="OR" class="flat qry" type="radio" name="queryLogic" value="OR" checked="checked">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>OR</span> 
        </label>
    </div>
    <div class="radio pull-right">
        <label data-toggle="tooltip" data-placement="top" title="" data-original-title="'.REC_QUERY_AND.'">
            <div class="icheckbox_flat pull-left">
                <input id="AND" class="flat qry"type="radio" name="queryLogic" value="AND">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>AND</span> 
        </label>
    </div>
    ';

$result = $db->query("
    SELECT
        rt.id,
        rt.name,
        rt.description,
        (
            SELECT count(id_tag) FROM ".PREF."_recipient_tag_conn AS rtc where rtc.id_tag = rt.id
        ) AS used
    FROM 
        ".PREF."_recipient_tag AS rt
");
$i = 0;
foreach ($result as $row) {
    $i++;
    $tagToolTip = $row['description'] !== '' ? ' data-toggle="tooltip" data-placement="top" title="" data-original-title="'.$row['description'].'"' : '';
    $tagsList .= '
    <div class="checkbox pull-right">
        <label '.$tagToolTip.'>
            <div class="icheckbox_flat pull-left" data-id="'.$row['id'].'">
                <input id="icheck_'.$row['id'].'" class="flat tagi" type="checkbox" value="'.$row['id'].'">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>'.$row['name'].' ('.$row['used'].')</span> 
        </label>
    </div>
    ';
    $tagsList3 .= '<option value="'.$row['id'].'"><span>'.$row['name'].' ('.$row['used'].')</span> </option>';
}
$showTagsClass = ' hidden ';
$showLogicClass = ' hidden ';

$tagsList3 = '<select class="js-example-basic-single" multiple="multiple" name="newtags" id="newtags">'.$tagsList3.'</select>';

if ($i > 0) {
    $showTagsClass = '';
}
if ($i > 1) {
    $showLogicClass = '';
}

?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo RECIPIENT_DB;?> <span id="recordsTotal">(0/0)</span></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <form id="filterList" class="form-horizontal">
                <input type="hidden" id="mojetagi" name="mojetagi" value="">
                <input type="hidden" id="mojequery" name="mojequery" value="OR">
				<div class="form-group <?php echo $showTagsClass;?>">
                    <span class="pull-right">&nbsp;&nbsp;<a class="btn btn-primary btn-xs resetquery">Reset query</a></span>
                    <?php //echo $tagsList; ?><span class="<?php echo $showLogicClass;?>"><?php echo $queryLogic; ?></span>
                </div>
				<div class="form-group ">
                    <?php echo TAGS_SELECT;?><?php echo $tagsList3; ?>
                </div>
            </form>
                <table class="table table-striped responsive-utilities jambo_table" id="campaign">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th><?php echo PERSON; ?></th>
                            <th><?php echo EMAIL;?></th>
                            <th><?php echo TAGS;?></th>
                            <th><?php echo RECIPIENT_DESCRIPTION;?></th>
                            <th><?php echo WEBSITE;?></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
