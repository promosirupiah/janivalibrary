<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=campaign&action=proceed");
    exit();
}

$id_campaign = (int)$_GET['campaign'];

// update campaign data
$sql = "
    UPDATE ".PREF."_campaign SET
        status = '4'
    WHERE id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':id', $id_campaign, PDO::PARAM_INT);
$stmt->execute();

header("Location: index.php?manage=campaign&action=proceed");

exit();