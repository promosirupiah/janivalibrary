<?php

defined('_MAILING') or die('Restricted access');

$app->checkToken();

$id_campaign = (int)$_POST['id_campaign'];

$stmt = $db->prepare(" select count(id_recipient) as qty from ".PREF."_campaign_rec_conn where id_campaign=? and status = '0' ");
$stmt->bindParam(1, $id_campaign, PDO::PARAM_INT);
$stmt->execute();
$row = $stmt->fetchAll();

echo (int)($row[0]['qty']);


