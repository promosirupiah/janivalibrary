<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=campaign&action=waiting");
    exit();
}

$app->checkToken();

$id_campaign = (int)$_POST['campaignid'];

$sql = " DELETE FROM ".PREF."_campaign WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id_campaign, PDO::PARAM_INT);   
$stmt->execute(); 

$sql = " DELETE FROM ".PREF."_campaign_rec_conn WHERE id_campaign = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id_campaign, PDO::PARAM_INT);   
$stmt->execute(); 

if (isset($_POST['back_to_sent'])) {
    header("Location: index.php?manage=campaign&action=sent");
} else {
    header("Location: index.php?manage=campaign&action=waiting");
}
