"use strict";

$(document).ready(function(){

    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    $('#waitingCampaign').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });
    
    $('#recipientDelete').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var recipientname = button.data('recipientname');
        var recipientid = button.data('recipientid');
        var recipientemail = button.data('recipientemail');
        var modal = $(this);
        modal.find('.recipientname').val(recipientname + ', (' + recipientemail + ')');
        modal.find('.recipientid').val(recipientid);
    });

});