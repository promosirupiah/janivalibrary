<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=campaign&action=waiting");
    exit();
}

$app->checkToken();

$campaign_name = $_POST['campaign_name'];
$id_campaign = $_POST['id_campaign'];
$id_template = $_POST['id_template'];
$id_sender = $_POST['id_sender'];


$sql = "
    UPDATE 
        ".PREF."_campaign
    SET 
        name = :campaign_name,
        id_template = :id_template,
        id_sender = :id_sender
    WHERE 
        id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':campaign_name', $campaign_name, PDO::PARAM_STR);
$stmt->bindParam(':id_template', $id_template, PDO::PARAM_STR);
$stmt->bindParam(':id_sender', $id_sender, PDO::PARAM_STR);
$stmt->bindParam(':id', $id_campaign, PDO::PARAM_INT);
$stmt->execute();


header("Location: index.php?manage=campaign&action=waiting");
