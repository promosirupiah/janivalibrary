<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "unsubscribed":
        $load = "view.campaign.unsubscribed.php";
        break;
    case "prepare":
        $load = "view.campaign.prepare.php";
        break;
    case "waiting":
        $load = "view.campaign.waiting.php";
        break;
    case "sent":
        $load = "view.campaign.sent.php";
        break;
    case "start":
        $load = "view.campaign.start.php";
        break;
    case "proceed":
        $load = "view.campaign.proceed.php";
        break;
    case "modify":
        $load = "view.campaign.modify.php";
        break;
    case "modify.campaign":
        $load = "action.campaign.modify.campaign.php";
        break;
    case "getlist":
        $load = "action.campaign.getlist.php";
        break;
    case "insert":
        $load = "action.campaign.insert.php";
        break;
    case "send":
        $load = "action.campaign.send.php";
        break;
    case "run":
        $load = "action.campaign.run.php";
        break;
    case "run.background":
        $load = "action.campaign.run.background.php";
        break;
    case "stop.background":
        $load = "action.campaign.stop.background.php";
        break;
    case "stop.ajax":
        $load = "action.campaign.stop.ajax.php";
        break;
    case "finish":
        $load = "action.campaign.finish.php";
        break;
    case "check":
        $load = "action.campaign.check.php";
        break;
    case "delete":
        $load = "action.campaign.delete.php";
        break;
    case "track":
        $load = "action.campaign.track.php";
        break;
    case "unsubscribe":
        $load = "action.campaign.unsubscribe.php";
        break;
    case "subscribe":
        $load = "action.campaign.subscribe.php";
        break;
    case "subscribe.confirmed":
        $load = "action.campaign.subscribe.confirmed.php";
        break;
    case "click":
        $load = "action.campaign.click.php";
        break;
    case "recipients":
        $load = "action.campaign.ajax.get.recipients.php";
        break;
    case "unsubscribersdelete":
        $load = "action.campaign.unsubscribersdelete.php";
        break;
    case "browserview":
        $load = "action.campaign.browserview.php";
        break;
    case "checkintegrity":
        $load = "action.campaign.checkintegrity.php";
        break;
    default:
        $load = "view.campaign.prepare.php";
        break;
}

include($load);	
