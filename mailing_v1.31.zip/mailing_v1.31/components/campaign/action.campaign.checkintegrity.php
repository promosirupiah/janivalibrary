<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=campaign&action=sent");
    exit();
}

$app->checkToken();

// get ajax(1) background(3) stopped (4)
$result = $db->query(" SELECT id FROM ".PREF."_campaign WHERE status in (1,3,4) ");

foreach ($result as $row) {
    
    $stmt = $db->prepare(" SELECT count(id_campaign) as qty FROM ".PREF."_campaign_rec_conn WHERE status = 0 and id_campaign=? ");
    $stmt->bindParam(1, $row['id'], PDO::PARAM_INT);
    $stmt->execute();
    $row2 = $stmt->fetchAll();
    $data = $row2[0];
    
    if ($data['qty'] == '0') {
        $sql = "
            UPDATE ".PREF."_campaign SET
                status = '2'
            WHERE 1
                and id = '".$row['id']."'
        ";
        $db->query($sql);
        echo "updated campaign no ".$row['id']."(".$data['qty'].")<hr>";
    }
    
}

header("Location: index.php?manage=campaign&action=sent");

