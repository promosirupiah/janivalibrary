<?php

defined('_MAILING') or die('Restricted access');

?>
<div class="page-title">
  <div class="title_left">
    <h3><?php echo MENU_CAMPAIGNS;?> <small>(<?php echo CAMPAIGN_PREPARE;?>)</small></h3>
  </div>
</div>
<div class="clearfix"></div>

<div data-example-id="togglable-tabs" role="tabpanel" class="">
    <ul role="tablist" class="nav nav-tabs bar_tabs" id="myTab">
        <li class="active" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab" role="tab" href="#tab_content2"><?php echo CAMPAIGN_STEP_1;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab2" role="tab" href="#tab_content3"><?php echo CAMPAIGN_STEP_2;?></a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">

        <div aria-labelledby="profile-tab" id="tab_content2" class="tab-pane fade active in" role="tabpanel">
            <?php include("view.campaign.tab.recipients.php");?>
        </div>
        <div aria-labelledby="profile-tab" id="tab_content3" class="tab-pane fade" role="tabpanel">
            <?php include("view.campaign.tab.confirm.php");?>
        </div>
    </div>
</div>

<script src="components/campaign/campaign.js"></script>
