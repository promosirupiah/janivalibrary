<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=campaign&action=unsubscribed");
    exit();
}

$app->checkToken();

$sql = " SELECT id_recipient FROM ".PREF."_campaign_rec_conn WHERE status = '3' ";
$stmt = $db->prepare($sql);
$stmt->execute(); 
/*
$sql = " DELETE FROM ".PREF."_campaign_rec_conn WHERE status = '3' ";
$stmt = $db->prepare($sql);
$stmt->execute(); 
*/

$result = $db->query($sql);

/**
 * delete recipient by id
 */
foreach ($result as $row) {
    $sql = " DELETE FROM ".PREF."_recipient WHERE id = ". $row['id_recipient'] ;
    $stmt = $db->prepare($sql);
    $stmt->execute();
}

header("Location: index.php?manage=campaign&action=unsubscribed");