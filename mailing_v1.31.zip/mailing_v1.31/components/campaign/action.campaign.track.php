<?php

defined('_MAILING') or die('Restricted access');

$id_campaign = (int)($_GET['c']);
$id_recipient = (int)($_GET['r']);

if ($id_campaign == 0 || $id_recipient == 0) {
    exit();
}

$sql = "
    UPDATE ".PREF."_campaign_rec_conn SET 
        status = '2',
        ip_receiver = '".$_SERVER["REMOTE_ADDR"]."'
    WHERE 1
        and id_campaign = :id_campaign
        and id_recipient = :id_recipient
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':id_campaign', $id_campaign, PDO::PARAM_STR);
$stmt->bindParam(':id_recipient', $id_recipient, PDO::PARAM_STR);
$stmt->execute(); 

// update geodata
include('php/job_geodata.php');


