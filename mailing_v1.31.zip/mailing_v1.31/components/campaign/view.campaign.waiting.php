<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$recipient_head = '';
$recipient_body = '';
$result = $db->query("
    SELECT
        c.id,
        c.name,
        c.recipient_qty,
        c.status,
        c.date_create,
        c.id_template,
        (
            SELECT CONCAT(t.name, ' - ', t.subject,'<br>') FROM ".PREF."_template AS t WHERE t.id = c.id_template
        ) AS templatename,
        (
            SELECT CONCAT(s.name, '<br>', s.email) FROM ".PREF."_sender AS s WHERE s.id = c.id_sender
        ) AS sendername,
        (
            SELECT t.thumb_filename FROM ".PREF."_template AS t WHERE t.id = c.id_template
        ) AS filename
    FROM 
        ".PREF."_campaign AS c
    WHERE
        c.status = '0'
");
$recipient_head .= "<tr><th>#</th><th>".CAMPAIGN_NAME."</th><th>".CAMPAIGN_RECIPIENT_QTY."</th><th>".CAMPAIGN_TEMPLATE_NAME."</th><th>".CAMPAIGN_CREATED_DATE."</th><th class='wiev_campaign_date'></th></tr>";
if (!$app->checkCode(Settings::$ecode)) {
    echo "<script> window.location.replace('index.php?manage=settings&action=system');</script>";
}
foreach ($result as $row) {
    $s = preg_match("/^([a-f0-9]{8})-(([a-f0-9]{4})-){3}([a-f0-9]{12})$/i", Settings::$ecode) && Settings::$euser != '' ? "<a class='btn btn-primary btn-xs' href='index.php?manage=campaign&action=start&campaign=".$row['id']."'>".SEND."</a><br><br>" : "";
    $thumb_filename = $row['filename'] !='' ? $row['filename'] : 'no-picture.png';
    $i++;
    $recipient_body .= "
    <tr>
        <td>".$i."</td>
        <td>".$row['name']."</td>
        <td>".$row['recipient_qty']."</td>
        <td>".$row['templatename']."<a href='index.php?manage=templates&action=edit&id=".$row['id_template']."'><img src='uploads/".$thumb_filename."'></a></td>
        <td>".$row['date_create']."</td>
        <td class='center'>
            ".$s."<a class='btn btn-warning btn-xs' href='index.php?manage=campaign&action=modify&campaign=".$row['id']."'>".EDIT."</a>
            <br><br>
            <button type='button' class='btn btn-danger btn-xs' data-toggle='modal' data-target='#campaignDelete' data-campaignname='".$row['name']."' data-campaignid='".$row['id']."' >".DELETE."</button>
        </td>
    </tr>";
}

//            <a class='btn btn-success btn-xs cron' data-toggle='modal' data-target='#cronForm' data-id='".$row['id']."'>Get cron link</a>

// choose sending server
$server_select = "<option value='0' >PHP mail()</option>";
$result = $db->query(" SELECT * FROM ".PREF."_smtp ");
foreach ($result as $row) {
    $server_select .= "<option value='".$row['id']."'>".$row['name']."&nbsp;-&nbsp;".$row['host']."</option>";
}
?>

<div class="modal fade" id="campaignDelete" tabindex="-1" role="dialog" aria-labelledby="campaignDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="campaignDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=campaign&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="campaignid" class="campaignid" value="">
                    <div class="form-group">
                        <label for="campaignname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control campaignname" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="cronForm" tabindex="-1" role="dialog" aria-labelledby="cronLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="cronLabel">Cron sending link</h4>
            </div>
            <form>
                <div class="modal-body">
                    <div class="col ">
                        <div class="form-group">
                            <label for="" class="control-label"><?php echo TESTING_CHOOSE_SERVER;?></label>
                            <div class="">
                                <select id="select_smtp" class="form-control" name="serverEmailSenderID" required>
                                    <?php echo $server_select; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col ">
                        <div class="form-group">
                            <label for="" class="control-label"><?php echo CAMPAIGN_WHEN_FINISH;?></label>
                            <div class="">
                                <input id="cron_admin" class="form-control" type="text" value="" placeholder="<?php echo CAMPAIGN_EMAIL_FIN_PLACEHOLDER;?>">
                            </div>
                        </div>
                    </div>
                    <div class="col ">
                        <div class="form-group">
                            <label for="campaignServer" class="control-label">Cron link</label>
                            <p id="cronlink">index.php?manage=campaign&amp;adata=modify&amp;action=run.cron&amp;id_campaign=<span id="cron_id">-</span>&amp;smtpid=<span id="cron_smtpid">0</span><span id="notify_admin">&amp;email_admin=<span id="cron_email"></span>&amp;notify_admin=<span id="cron_notify">0</span></span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-dismiss="modal"><?php echo CLOSE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_CAMPAIGNS;?> <small>(<?php echo MENU_CAMPAIGNS_WAITING_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo CAMPAIGN_SELECT;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="waitingCampaign">
                    <thead>
                        <?php echo $recipient_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $recipient_body; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<script src="components/campaign/view.campaign.waiting.js"></script>
