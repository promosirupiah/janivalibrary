<?php

defined('_MAILING') or die('Restricted access');

$tags_option = '';

$tags = $db->query(" select * from ".PREF."_recipient_tag order by name asc");
foreach ($tags as $tag) {
    $tags_option .= "<div class='checkbox'><label><input type='checkbox' name='tags[]' value='".$tag['id']."'>".$tag['name']."</label></div>";
}

?><h1><?php echo RECIPIENT_ADD_NEW;?></h1>
<hr/>
<form class="form-horizontal" action="index.php?manage=recipient&data=modify&action=insert" method="post">
<input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
 <div class="form-group">
  <label for="recipientname" class="col-sm-2 control-label"><?php echo RECIPIENT_NAME;?></label>
   <div class="col-sm-5">
    <input 
     type="text" 
     class="form-control" 
     id="recipientname" 
     name="recipientname" 
     placeholder="<?php echo RECIPIENT_NAME_PLACEHOLDER;?>"
    >
    </div>
  </div>
  <div class="form-group">
   <label for="recipientmail" class="col-sm-2 control-label"><?php echo RECIPIENT_MAIL;?>*</label>
    <div class="col-sm-5">
     <input 
      type="email" 
      class="form-control" 
      id="recipientmail" 
      name="recipientmail" 
      placeholder="<?php echo RECIPIENT_MAIL_PLACEHOLDER;?>" 
      required
     >
    </div>
  </div>
  <div class="form-group">
   <div class="col-sm-offset-2 col-sm-10">
    <div class="checkbox">
     <label>
      <input type="checkbox"> <?php echo RECIPIENT_ONLY_TXT;?>
     </label>
    </div>
   </div>
  </div>
  <div class="form-group">
   <label for="recipientcomment" class="col-sm-2 control-label"><?php echo RECIPIENT_DESCRIPTION;?></label>
    <div class="col-sm-5">
     <input 
      type="text" 
      class="form-control" 
      id="recipientcomment" 
      name="recipientcomment" 
      placeholder="<?php echo RECIPIENT_DESCRIPTION_PLACEHOLDER;?>" 
     >
	</div>
  </div>
  <div class="form-group">
   <label for="tagsname" class="col-sm-2 control-label"><?php echo TAGS;?></label>
	<div class="col-sm-5">
	 <?php echo $tags_option; ?>
    </div>
  </div>
  <div class="form-group">
   <div class="col-sm-offset-2 col-sm-1">
    <button type="submit" class="btn btn-primary"><?php echo SAVE;?></button>
   </div>
   <div class="col-sm-offset-3 col-sm-1">
    <a href="index.php?manage=recipient&action=list" type="button" class="btn btn-default"><?php echo CANCEL;?></a>
   </div>
  </div>
</form>
<p>&nbsp;</p>
