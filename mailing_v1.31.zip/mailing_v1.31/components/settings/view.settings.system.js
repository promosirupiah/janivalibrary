"use strict";

$(document).ready(function () {
    
    if ($('#mode').val() == '1') {
        $('#language').on('change', function() {
            $.ajax({
                method: 'POST',
                url: 'index.php?manage=settings&data=modify&action=language',
                data : {
                    csrf_token: $('input[name=csrf_token]').val(),
                    action: 'language',
                    language: $('#language').val()
                }
            }).done(function(res){
                //alert(res);
                window.location.replace('index.php?manage=settings&action=system')
            });
        });
    }
    
    $('#resetStorage').on('click', function() {
        localStorage.clear();
        $(this).html('cleared');
    });
    
});