<?php

defined('_MAILING') or die('Restricted access');

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SYSTEM_CONFIGURATION;?> <small>(<?php echo MENU_DB;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo SETTINGS_DB_PARAMS;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" method="post" action="index.php?manage=settings&action=db.update">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <?php 
                    if (! $fileSettingsWittable) {
                    ?>
                        <div class="alert alert-danger" role="alert">
                            <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                            <span class="sr-only">Error:</span>
                            <b>WARNING!</b> file '<b>configuration.php</b>' is not writtable. Settings will not be saved. Change file permissions before saving.
                        </div>
                    <?php
                    }
                    ?>
                    <input type="hidden" name="adata" value="1">
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="db_host"><?php echo SETTINGS_DB_HOST;?></label>
                        <div class="col-sm-2">
                          <input 
                                type="text" 
                                class="form-control" 
                                id="db_host" 
                                name="db_host" 
                                placeholder="<?php echo SETTINGS_DB_HOST_PLACEHOLDER;?>" 
                                value="<?php echo DEMO_MODE ? "" : Settings::$dbHost; ?>" 
                                required
                                >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="db_user"><?php echo SETTINGS_DB_USER;?></label>
                        <div class="col-sm-2">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="db_user" 
                                name="db_user" 
                                placeholder="<?php echo SETTINGS_DB_USER_PLACEHOLDER;?>" 
                                value="<?php echo DEMO_MODE ? "" : Settings::$dbUser; ?>"
                                required
                                >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="db_pass"><?php echo SETTINGS_DB_PASSWORD;?></label>
                        <div class="col-sm-2">
                            <input 
                                type="password" 
                                class="form-control" 
                                id="db_pass" 
                                name="db_pass"
                                value="<?php echo DEMO_MODE ? "" : Settings::$dbPassword; ?>"
                                >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="db_name"><?php echo SETTINGS_DB_NAME;?></label>
                        <div class="col-sm-2">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="db_name" 
                                name="db_name" 
                                placeholder="<?php echo SETTINGS_DB_NAME_PLACEHOLDER;?>" 
                                value="<?php echo DEMO_MODE ? "" : Settings::$dbName; ?>"
                                required
                                >
                        </div>
                    </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label" for="tb_pref"><?php echo SETTINGS_TB_PREFIX;?></label>
                            <div class="col-sm-2">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="tb_pref" 
                                    name="tb_pref" 
                                    placeholder="<?php echo SETTINGS_TB_PREFIX_PLACEHOLDER;?>" 
                                    value="<?php echo PREF; ?>"
                                    required
                                >
                            </div>
                        </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-2">
                          <button type="submit" class="btn btn-primary"><?php echo SAVE; ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>