<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=settings&action=credentials&error");
    exit();
}

$app->checkToken();

$login = $_POST['login'];
$current_password = $_POST['current_password'];
$new_password1 = $_POST['new_password1'];
$new_password2 = $_POST['new_password2'];

$system_password = Settings::$loginPassword;

if ( (sha1($current_password) || md5($current_password) || hash('sha256', $current_password) || hash('sha512', $current_password)) != $system_password) {
    header("Location: index.php?manage=settings&action=credentials&error");
    exit();
}

if ($new_password1 != $new_password2) {
    header("Location: index.php?manage=settings&action=credentials&error");
    exit();
}

if ($login != '') {
    $app->changeSetting('loginName', $login, 'hash512');
}

if ($new_password1 != '') {
    $app->changeSetting('loginPassword', $new_password1, 'hash512');
}

header("Location: index.php?manage=settings&action=credentials&ok");
