<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "system.update":
        $load = "action.settings.system.update.php";
        break;
    case "db.update":
        $load = "action.settings.db.update.php";
        break;
    case "credentials.update":
        $load = "action.settings.credentials.update.php";
        break;
    case "language":
        $load = "action.session.language.update.php";
        break;
    case "system":
        $load = "view.settings.system.php";
        break;
    case "db":
        $load = "view.settings.db.php";
        break;
    case "credentials":
        $load = "view.settings.credentials.php";
        break;
    default:
        $load = "view.settings.credentials.php";
        break;
}

$fileSettings = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).DIRECTORY_SEPARATOR.'configuration.php';

if (is_writable($fileSettings)) {
    $fileSettingsWittable = true;
} else {
    $fileSettingsWittable = false;
}

include($load);	
