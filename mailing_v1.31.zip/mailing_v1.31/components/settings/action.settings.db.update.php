<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=settings&action=db");
    exit();
}

$app->checkToken();

$db_host = $_POST['db_host'];
$db_user = $_POST['db_user'];
$db_pass = $_POST['db_pass'];
$db_name = $_POST['db_name'];
$tb_pref = $_POST['tb_pref'];

$app->changeSetting('dbHost', $db_host);
$app->changeSetting('dbUser', $db_user);
$app->changeSetting('dbPassword', $db_pass);
$app->changeSetting('dbName', $db_name);
$app->changeSetting('tbPrefix', $tb_pref);

header("Location: index.php?manage=settings&action=db");
