<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=settings&action=system");
    exit();
}

$app->checkToken();

$language = $_POST['language'];
$limit = (int)$_POST['limit'] != 0 ? (int)$_POST['limit'] : 1000 ;
$tracking = isset($_POST['tracking']) ? 1 : 0 ;
$smtp = $_POST['smtp'] == '1' ? 1 : 0 ;
$delUnsub = isset($_POST['deleteunsubscribed']) ? 1 : 0 ;
$googleMapsApiKey = $_POST['googleMapsApiKey'];
$adminMail = $_POST['adminMail'];
$phpTimeOutLimit = $_POST['phpTimeOutLimit'];
$editor = $_POST['editor'];
$ipstackGeoApiKey = $_POST['ipstackGeoApiKey'];
$useHTTPS = isset($_POST['useHTTPS']) ? 1 : 0;
$thechecker = $_POST['thechecker'];
$charset = $_POST['charset'];
$ecode = $_POST['ecode'];

$app->changeSetting('systemLanguage', $language);
$app->changeSetting('limitPerHour', $limit);
$app->changeSetting('enableTracking', $tracking);
$app->changeSetting('useSMTP', $smtp);
$app->changeSetting('deleteUnsubscribed', $delUnsub);
$app->changeSetting('googleMapsApiKey', $googleMapsApiKey);
$app->changeSetting('adminMail', $adminMail);
$app->changeSetting('phpTimeOutLimit', $phpTimeOutLimit);
$app->changeSetting('systemEditor', $editor);
$app->changeSetting('ipstackGeoApiKey', $ipstackGeoApiKey);
$app->changeSetting('useHTTPS', $useHTTPS);
$app->changeSetting('thechecker', $thechecker);
$app->changeSetting('charset', $charset);
$app->changeSetting('ecode', $ecode);

header("Location: index.php?manage=settings&action=system");
