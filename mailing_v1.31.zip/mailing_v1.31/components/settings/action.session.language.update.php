<?php

defined('_MAILING') or die('Restricted access');

if (! DEMO_MODE) {
    header("Location: index.php?manage=settings&action=credentials&error");
    exit();
}

$app->checkToken();

$_SESSION['language'] = $_POST['language'];
