<?php

defined('_MAILING') or die('Restricted access');

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SYSTEM_CONFIGURATION;?> <small>(<?php echo MENU_LOGIN;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <?php 
    if (isset($_GET['ok'])) {
    ?>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div role="alert" class="alert alert-success alert-dismissible fade in">
                <button aria-label="Close" data-dismiss="alert" class="close" type="button"><span aria-hidden="true">×</span></button>
                <?php echo CHANGES_SAVED;?>
            </div>
        </div>
    <?php
    }
    ?>
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo SETTINGS_LOGIN_TITLE;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" method="post" action="index.php?manage=settings&action=credentials.update">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <?php
                    if (! $fileSettingsWittable) {
                    ?>
                        <div class="alert alert-danger" role="alert">
                            <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                            <span class="sr-only">Error:</span>
                            <b>WARNING!</b> file '<b>configuration.php</b>' is not writtable. Settings will not be saved. Change file permissions before saving.
                        </div>
                    <?php
                    }
                    ?>
                    <input type="hidden" name="adata" value="1">
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="login"><?php echo SETTINGS_LOGIN_LABEL;?></label>
                        <div class="col-sm-2">
                            <input type="text"  class="form-control"  id="loginName" name="login" placeholder="<?php echo SETTINGS_LOGIN_PLACEHOLDER;?>" value="" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="current_password"><?php echo SETTINGS_CURR_PASS;?></label>
                        <div class="col-sm-2">
                            <input type="password" class="form-control" name="current_password" placeholder="<?php echo SETTINGS_CURR_PASS_PLACEHOLDER;?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="new_password1"><?php echo SETTINGS_NEW_PASS;?></label>
                        <div class="col-sm-2">
                            <input type="password" class="form-control" name="new_password1" placeholder="<?php echo SETTINGS_NEW_PASS_PLACEHOLDER1;?>" >
                        </div>
                        <div class="col-sm-2">
                            <input type="password" class="form-control" name="new_password2" placeholder="<?php echo SETTINGS_NEW_PASS_PLACEHOLDER2;?>" >
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-2">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>