<?php

defined('_MAILING') or die('Restricted access');

// to avoid CSRF hacking
$app->checkToken();

/**
 * for example puropses only
 *
 * how to insert data to database
 *
 
$field1 = $_POST['field1'];
$field2 = $_POST['field2']; 

$sql = "
    INSERT INTO ".PREF."_example_table (
        field1,
        field2
    ) VALUES (
        :field1,
        :field2
    )
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':field1', $field1, PDO::PARAM_STR);
$stmt->bindParam(':field2', $field2, PDO::PARAM_STR);
$stmt->execute();
*/
header("Location: index.php?manage=example_component&action=list");
