<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.example_component.add.php";
        break;
    case "edit":
        $load = "view.example_component.edit.php";
        break;
    case "list":
        $load = "view.example_component.list.php";
        break;
    case "update":
        $load = "action.example_component.update.php";
        break;
    case "insert":
        $load = "action.example_component.insert.php";
        break;
    case "delete":
        $load = "action.example_component.delete.php";
        break;
    default:
        $load = "view.example_component.list.php";
        break;
}

include($load);	
