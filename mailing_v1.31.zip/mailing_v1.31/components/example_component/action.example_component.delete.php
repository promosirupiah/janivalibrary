<?php

defined('_MAILING') or die('Restricted access');

// to avoid CSRF hacking
$app->checkToken();

/**
 * for example puropses only
 *
 * how to delete from database
 *
 
$id = (int)$_POST['fieldid'];

$sql = " DELETE FROM ".PREF."_example_table WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 
*/

header("Location: index.php?manage=example_component&action=list");
