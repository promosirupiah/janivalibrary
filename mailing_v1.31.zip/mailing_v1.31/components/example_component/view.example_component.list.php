<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$example_head = '';
$example_body = '';

/**
 * for example purposes only, table ".PREF."_example_table not exist in the system
 * you have to create table if you want use it
 *
 *
 * example code to get data from ".PREF."_example_table table
 *
$result = $db->query(" SELECT * FROM ".PREF."_example_table ");
*/

$example_head .= "<tr><th>#</th><th>Field 1</th><th>Field 2</th><th></th></tr>";

/* for example purposes only */
$result = Array(
    1 => Array(
            "id" => "1",
            "field1" => "green",
            "field2" => "big"
        ),
    2 => Array(
            "id" => "2",
            "field1" => "orange",
            "field2" => "small"
        ),
    3 => Array(
            "id" => "3",
            "field1" => "pink",
            "field2" => "middle"
        ),
    4 => Array(
            "id" => "4",
            "field1" => "black",
            "field2" => "high"
        )
);

foreach ($result as $row) {
    $i++;
    $example_body .= "
        <tr>
            <td>".$i."</td>
            <td>".$row['field1']."</td>
            <td>".$row['field2']."</td>
            <td>
                <button type='button' class='btn btn-danger btn-xs pull-right' data-toggle='modal' data-target='#modalAction' data-fieldname='".$row['field1']." - ".$row['field2']."' data-fieldid='".$row['id']."'>".DELETE."</button>
            </td>
        </tr>
    ";
}

?>

<div class="modal fade" id="modalAction" tabindex="-1" role="dialog" aria-labelledby="myaction">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myaction">My action</h4>
          </div>
            <form action="index.php?manage=example_component&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="fieldid" class="fieldid" value="">
                    <div class="form-group">
                        <label for="fieldname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control fieldname" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3>Example title <small>(example subtitle)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>List of your data</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="fields">
                    <thead>
                        <?php echo $example_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $example_body; ?>
                    </tbody>
                </table>
            </div>
            <a href="index.php?manage=example_component&action=add" class="btn btn-primary">Add custom data</a>
        </div>
    </div>
</div>
<p>&nbsp;</p>
<script src="components/example_component/view.example_component.js"></script>
