"use strict";

$(document).ready(function () {
    
    $('#modalAction').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var fieldname = button.data('fieldname');
        var fieldid = button.data('fieldid');
        var modal = $(this);
        modal.find('.fieldid').val(fieldid);
        modal.find('.fieldname').val(fieldname);
    });
        
    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    
    $('#fields').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });

});