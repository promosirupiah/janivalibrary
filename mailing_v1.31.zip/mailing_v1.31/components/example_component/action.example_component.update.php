<?php

defined('_MAILING') or die('Restricted access');

// to avoid CSRF hacking
$app->checkToken();

/**
 * for example puropses only
 *
 * how to update data in database
 *
 
$field1 = $_POST['field1'];
$field2 = $_POST['field2'];
$id = (int)$_POST['id'];

//antyhaker
if (! $id) {
    die("restricted access");
}

$sql = "
    UPDATE 
        ".PREF."_example_table
    SET 
        field1 = :field1,
        field2 = :field2
    WHERE 
        id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':field1', $field1, PDO::PARAM_STR);
$stmt->bindParam(':field2', $field2, PDO::PARAM_STR);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
*/

header("Location: index.php?manage=example_component&action=list");
