<?php

defined('_MAILING') or die('Restricted access');

// check connection to database
try {
    $db2 = new PDO("mysql:dbname=".$bridge_db_name.";host=".$bridge_db_host.";", $bridge_db_user, $bridge_db_password);
} catch (PDOException $e) {
    echo '<span class="red">'.$e->getMessage().'</span>';
    exit();
}

// check if table exists
$stmt = $db2->query(" show tables like '".$source_table_name."' ");
$stmt->execute();
$row = $stmt->fetchAll();
if (count($row) == 0) {
    echo '<span class="red">'.TABLE.$source_table_name.NOT_IN_DB.$bridge_db_name.'</span>';
    exit();
}

//check if column for email exists
$stmt = $db2->query(" SHOW COLUMNS FROM ".$source_table_name." WHERE Field = '".$source_col_rec_mail."' ");
$stmt->execute();
$row = $stmt->fetchAll();
if (count($row) == 0) {
    echo '<span class="red">'.COLUMN.$source_col_rec_mail.NOT_IN_TABLE.$source_table_name.'</span>';
    exit();
}

// check optional column existence
if ($source_col_rec_name != '') {
    $stmt = $db2->query(" SHOW COLUMNS FROM ".$source_table_name." WHERE Field = '".$source_col_rec_name."' ");
    $stmt->execute();
    $row = $stmt->fetchAll();
    if (count($row) == 0) {
        echo '<span class="red">'.COLUMN.$source_col_rec_name.NOT_IN_TABLE.$source_table_name.'</span>';
        exit();
    }
}

// check optional column existence
if ($source_col_rec_desc != '') {
    $stmt = $db2->query(" SHOW COLUMNS FROM ".$source_table_name." WHERE Field = '".$source_col_rec_desc."' ");
    $stmt->execute();
    $row = $stmt->fetchAll();
    if (count($row) == 0) {
        echo '<span class="red">'.COLUMN.$source_col_rec_desc.NOT_IN_TABLE.$source_table_name.'</span>';
        exit();
    }
}