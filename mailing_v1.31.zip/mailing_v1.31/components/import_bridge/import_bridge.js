"use strict";

$(document).ready(function(){
    
    $('#testConnection').on('click', function() {
        testConection();
    });

});

function testConection() {
    var bridge_db_host = $('input[name="bridge_db_host"]').val(),
        bridge_db_user = $('input[name="bridge_db_user"]').val(),
        bridge_db_password = $('input[name="bridge_db_password"]').val(),
        bridge_db_name = $('input[name="bridge_db_name"]').val(),
        source_table_name = $('input[name="source_table_name"]').val(),
        source_col_rec_name = $('input[name="source_col_rec_name"]').val(),
        source_col_rec_mail = $('input[name="source_col_rec_mail"]').val(),
        source_col_rec_desc = $('input[name="source_col_rec_desc"]').val(),
        csrf_token = $('input[name="csrf_token"]').val()
    ;
        
    showTestLog('test started...');
        
    if (
        bridge_db_host == '' ||
        bridge_db_user == '' ||
        bridge_db_name == '' ||
        source_table_name == '' ||
        source_col_rec_mail == ''
    ) {
        showTestLog('<span class="red">' + lang_bridge_fill_fields + '</span>');
        return;
    }
    
    $.ajax({
        method: 'POST',
        url: 'index.php?manage=import_bridge&data=modify&action=test_connection',
        data : {
            csrf_token : csrf_token,
            bridge_db_host : bridge_db_host,
            bridge_db_user : bridge_db_user,
            bridge_db_password : bridge_db_password,
            bridge_db_name : bridge_db_name,
            source_table_name : source_table_name,
            source_col_rec_name : source_col_rec_name,
            source_col_rec_mail : source_col_rec_mail,
            source_col_rec_desc : source_col_rec_desc
        }
    }).done(function(data){
        showTestLog(data);
    });
    
}

function showTestLog(txt) {
    $('#testLog').html(txt);
}