<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=import_bridge&action=list");
    exit();
}

// to avoid CSRF hacking
$app->checkToken();

$bridge_description = $_POST['bridge_description'];
$bridge_db_host = $_POST['bridge_db_host'];
$bridge_db_user = $_POST['bridge_db_user'];
$bridge_db_password = $_POST['bridge_db_password'];
$bridge_db_name = $_POST['bridge_db_name'];
$source_table_name = $_POST['source_table_name'];
$source_col_rec_name = $_POST['source_col_rec_name'];
$source_col_rec_mail = $_POST['source_col_rec_mail'];
$source_col_rec_desc = $_POST['source_col_rec_desc'];
$source_col_rec_website = $_POST['source_col_rec_website'];
$source_col_rec_f01 = $_POST['source_col_rec_f01'];
$source_col_rec_f02 = $_POST['source_col_rec_f02'];
$source_col_rec_f03 = $_POST['source_col_rec_f03'];
$additional_name = $_POST['additional_name'];
$additional_desc = $_POST['additional_desc'];
$option_override = (int)$_POST['option_override'];
$option_tags = isset($_POST['option_tags']) ? implode(',', $_POST['option_tags']) : '';

$sql = "
    INSERT INTO ".PREF."_recipient_bridge (
        bridge_description, 
        bridge_db_host,  
        bridge_db_user,  
        bridge_db_password,
        bridge_db_name,
        source_table_name,
        source_col_rec_name,
        source_col_rec_mail,
        source_col_rec_desc,
        source_col_rec_website,
        source_col_rec_f01,
        source_col_rec_f02,
        source_col_rec_f03,
        additional_name,
        additional_desc,
        option_override,
        option_tags
    ) VALUES (
        :bridge_description, 
        :bridge_db_host,  
        :bridge_db_user,  
        :bridge_db_password,
        :bridge_db_name,
        :source_table_name,
        :source_col_rec_name,
        :source_col_rec_mail,
        :source_col_rec_desc,
        :source_col_rec_website,
        :source_col_rec_f01,
        :source_col_rec_f02,
        :source_col_rec_f03,
        :additional_name,
        :additional_desc,
        :option_override,
        :option_tags
    )
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':bridge_description', $bridge_description, PDO::PARAM_STR);
$stmt->bindParam(':bridge_db_host', $bridge_db_host, PDO::PARAM_STR);
$stmt->bindParam(':bridge_db_user', $bridge_db_user, PDO::PARAM_STR);
$stmt->bindParam(':bridge_db_password', $bridge_db_password, PDO::PARAM_STR);
$stmt->bindParam(':bridge_db_name', $bridge_db_name, PDO::PARAM_STR);
$stmt->bindParam(':source_table_name', $source_table_name, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_name', $source_col_rec_name, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_mail', $source_col_rec_mail, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_desc', $source_col_rec_desc, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_website', $source_col_rec_website, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_f01', $source_col_rec_f01, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_f02', $source_col_rec_f02, PDO::PARAM_STR);
$stmt->bindParam(':source_col_rec_f03', $source_col_rec_f03, PDO::PARAM_STR);
$stmt->bindParam(':additional_name', $additional_name, PDO::PARAM_STR);
$stmt->bindParam(':additional_desc', $additional_desc, PDO::PARAM_STR);
$stmt->bindParam(':option_override', $option_override, PDO::PARAM_STR);
$stmt->bindParam(':option_tags', $option_tags, PDO::PARAM_STR);
$stmt->execute();


header("Location: index.php?manage=import_bridge&action=list");
