<?php

defined('_MAILING') or die('Restricted access');

// prepare list of bridges
$i = 0;
$example_head = '';
$example_body = '';
$result = $db->query(" SELECT * FROM ".PREF."_recipient_bridge ");
$example_head .= "<tr><th>#</th><th>".IMPORT_BRIDGE_DESC."</th></tr>";
foreach ($result as $row) {
    $i++;
    $example_body .= "
        <tr>
            <td>".$i."</td>
            <td><a href='index.php?manage=import_bridge&action=edit&id=".$row['id']."'>".$row['bridge_description']."</a>
                <button type='button' class='btn btn-danger btn-xs pull-right' data-toggle='modal' data-target='#actionDelete' data-fieldname='".$row['bridge_description']."' data-fieldid='".$row['id']."'>".DELETE."</button>
                <a type='button' class='btn btn-warning btn-xs pull-right' href='index.php?manage=import_bridge&action=edit&id=".$row['id']."'>".EDIT."</a>
                <button type='button' class='btn btn-primary btn-xs pull-right' data-toggle='modal' data-target='#importRecipients' data-fieldname='".$row['bridge_description']."' data-bridge_id='".$row['id']."'>".IMPORT_RECIPIENTS."</button>
            </td>
        </tr>
    ";
}

?>

<div class="modal fade" id="importRecipients" tabindex="-1" role="dialog" aria-labelledby="myaction">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myaction"><?php echo IMPORTING_BRIDGE_REC;?></h4>
          </div>
            <form action="index.php?manage=import_bridge&data=modify&action=import_recipients" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input id="bridge_id" type="hidden" name="bridge_id" class="bridge_id" value="">
                    <div class="form-group">
                        <label for="fieldname" class="control-label"><?php echo CHOOSEN_BRIDGE;?></label>
                        <input type="text" class="form-control fieldname" disabled>
                    </div>
                    <div id="importLog"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button id="startImportRecipients" type="submit" class="btn btn-danger"><?php echo START;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="actionDelete" tabindex="-1" role="dialog" aria-labelledby="myaction">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myaction"><?php echo CONFIRM_BRIDGE_DEL; ?></h4>
          </div>
            <form action="index.php?manage=import_bridge&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="fieldid" class="fieldid" value="">
                    <div class="form-group">
                        <label for="fieldname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control fieldname" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo TITLE_IMPORT;?> <small>(<?php echo SUBTITLE_IMPORT;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo LIST_TITLE_IMPORT;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="fields">
                    <thead>
                        <?php echo $example_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $example_body; ?>
                    </tbody>
                </table>
            </div>
            <a href="index.php?manage=import_bridge&action=add" class="btn btn-primary"><?php echo ADD_NEW_BRIDGE;?></a>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<script src="components/import_bridge/import_recipients.js"></script>
