<?php

defined('_MAILING') or die('Restricted access');

// to avoid CSRF hacking
$app->checkToken();

if (DEMO_MODE) {
    header("Location: index.php?manage=import_bridge&action=list");
    exit();
}

$id = (int)$_POST['fieldid'];

$sql = " DELETE FROM ".PREF."_recipient_bridge WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

header("Location: index.php?manage=import_bridge&action=list");