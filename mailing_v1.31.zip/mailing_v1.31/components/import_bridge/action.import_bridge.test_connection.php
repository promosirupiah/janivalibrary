<?php

defined('_MAILING') or die('Restricted access');

// to avoid CSRF hacking
$app->checkToken();

if (DEMO_MODE) {
    echo '<span class="red">Test not possible in demo mode.</span>';
    exit();
}

$bridge_db_host = $_POST['bridge_db_host'];
$bridge_db_user = $_POST['bridge_db_user'];
$bridge_db_password = $_POST['bridge_db_password'];
$bridge_db_name = $_POST['bridge_db_name'];
$source_table_name = $_POST['source_table_name'];
$source_col_rec_name = $_POST['source_col_rec_name'];
$source_col_rec_mail = $_POST['source_col_rec_mail'];
$source_col_rec_desc = $_POST['source_col_rec_desc'];

include('components/import_bridge/action.import_bridge.check_source.php');

echo '<span class="green">'.BRIDGE_TEST_OK.'</span>';