<?php

defined('_MAILING') or die('Restricted access');

$tags_option = '';

$tags = $db->query(" select * from ".PREF."_recipient_tag order by name asc");
foreach ($tags as $tag) {
    $tags_option .= "<div class='checkbox'><label><input class='flat' type='checkbox' name='option_tags[]' value='".$tag['id']."'>&nbsp;".$tag['name']."</label></div>";
}

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo TITLE_IMPORT;?> <small>(<?php echo SUBTITLE_IMPORT;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo LIST_TITLE_IMPORT;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" action="index.php?manage=import_bridge&data=modify&action=insert" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <input type="hidden" name="adata" value="1">
                    
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="bridge_description"><?php echo FORM_BRIDGE_DESC;?> *</label>
                            <div class="col-sm-8">
                              <input 
                                    type="text" 
                                    class="form-control" 
                                    id="bridge_description" 
                                    name="bridge_description" 
                                    placeholder="ex.: description for database bridge required for import recipients from other database" 
                                    value="" 
                                    required
                                    >
                            </div>
                        </div>
                    
                    
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="bridge_db_host"><?php echo SETTINGS_DB_HOST;?> *</label>
                            <div class="col-sm-4">
                              <input 
                                    type="text" 
                                    class="form-control" 
                                    id="bridge_db_host" 
                                    name="bridge_db_host" 
                                    placeholder="<?php echo SETTINGS_DB_HOST_PLACEHOLDER;?>" 
                                    value="" 
                                    required
                                    >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="bridge_db_user"><?php echo SETTINGS_DB_USER;?> *</label>
                            <div class="col-sm-4">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="bridge_db_user" 
                                    name="bridge_db_user" 
                                    placeholder="<?php echo SETTINGS_DB_USER_PLACEHOLDER;?>" 
                                    value=""
                                    required
                                    >
                            </div>
                        </div>
                    
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="bridge_db_password"><?php echo SETTINGS_DB_PASSWORD;?></label>
                            <div class="col-sm-4">
                                <input 
                                    type="password" 
                                    class="form-control" 
                                    id="bridge_db_password" 
                                    name="bridge_db_password"
                                    value=""
                                    >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label" for="bridge_db_name"><?php echo SETTINGS_DB_NAME;?> *</label>
                            <div class="col-sm-4">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="bridge_db_name" 
                                    name="bridge_db_name" 
                                    placeholder="<?php echo SETTINGS_DB_NAME_PLACEHOLDER;?>" 
                                    value=""
                                    required
                                    >
                            </div>
                        </div>
                    
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_table_name"><?php echo BRIDGE_TABLE;?> *</label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_table_name" 
                                name="source_table_name" 
                                placeholder="" 
                                value=""
                                required
                                >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_name"><?php echo BRIDGE_COL_NAME;?></label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_name" 
                                name="source_col_rec_name" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left"><?php echo BRIDGE_COL_NAME_INFO;?></span></label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_mail"><?php echo BRIDGE_COL_MAIL;?> *</label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_mail" 
                                name="source_col_rec_mail" 
                                placeholder="" 
                                value=""
                                required
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left"><?php echo BRIDGE_COL_MAIL_INFO;?></span></label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_desc"><?php echo BRIDGE_COL_DESC;?></label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_desc" 
                                name="source_col_rec_desc" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left"><?php echo BRIDGE_COL_DESC_INFO;?></span></label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_website">Source for f0</label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_website" 
                                name="source_col_rec_website" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left">import to f0</span></label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_f01">Source for f1</label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_f01" 
                                name="source_col_rec_f01" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left">import to f1</span></label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_f02">Source for f2</label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_f02" 
                                name="source_col_rec_f02" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left">import to f2</span></label>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="source_col_rec_f03">Source for f3</label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="source_col_rec_f03" 
                                name="source_col_rec_f03" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left">import to f3</span></label>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-sm-4 control-label">
                            <button id="testConnection" type="button" class="btn btn-dark "><i class="fa fa-database"></i> <?php echo BRIDGE_CHECK_CON;?></button>
                        </label>
                        <label class="col-sm-7 control-label">
                            <span id="testLog" class="pull-left"><?php echo BRIDGE_WAITING;?></span>
                        </label>
                    </div>
                    
                    <hr>
                    
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="additional_name"><?php echo BRIDGE_ADD_NAME;?></label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="additional_name" 
                                name="additional_name" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left"><?php echo BRIDGE_ADD_NAME_INFO;?></span></label>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="additional_desc"><?php echo BRIDGE_ADD_DESC;?></label>
                        <div class="col-sm-4">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="additional_desc" 
                                name="additional_desc" 
                                placeholder="" 
                                value=""
                                >
                        </div>
                        <label class="col-sm-5 control-label"><span class="pull-left"><?php echo BRIDGE_ADD_DESC_INFO;?></span></label>
                    </div>
                    
                    <div class="form-group">
                        <label for="option_override" class="col-sm-3 control-label"><?php echo BRIDGE_OVERRIDE;?> *</label>
                        <div class="col-sm-5">
                            <div class='checkbox'><label><input class='flat' type='radio' name='option_override' value='1' required>&nbsp;<?php echo BRIDGE_OVERRIDE_O1;?></label></div>
                            <div class='checkbox'><label><input class='flat' type='radio' name='option_override' value='2' required>&nbsp;<?php echo BRIDGE_OVERRIDE_O2;?></label></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="tagsname" class="col-sm-3 control-label"><?php echo BRIDGE_TAGS;?></label>
                        <div class="col-sm-5">
                            <?php echo $tags_option; ?>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="form-group">
                        <div class="col-sm-offset-0 col-sm-1">
                            <a href="index.php?manage=import_bridge&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-6 col-sm-3">
                            <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<script src="components/import_bridge/import_bridge.js"></script>
