<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.import_bridge.add.php";
        break;
    case "edit":
        $load = "view.import_bridge.edit.php";
        break;
    case "list":
        $load = "view.import_bridge.list.php";
        break;
    case "update":
        $load = "action.import_bridge.update.php";
        break;
    case "insert":
        $load = "action.import_bridge.insert.php";
        break;
    case "delete":
        $load = "action.import_bridge.delete.php";
        break;
    case "test_connection":
        $load = "action.import_bridge.test_connection.php";
        break;
    case "import_recipients":
        $load = "action.import_bridge.import_recipients.php";
        break;
    default:
        $load = "view.import_bridge.list.php";
        break;
}

include($load);	
