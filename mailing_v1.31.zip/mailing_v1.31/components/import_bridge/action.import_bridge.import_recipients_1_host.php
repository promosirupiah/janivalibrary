<?php

defined('_MAILING') or die('Restricted access');

$insert_qty = 0;
$update_qty = 0;
$errors_qty = 0;

$additional_name = $additional_name != '' ? ' '.$additional_name : '';
$additional_desc = $additional_desc != '' ? ' '.$additional_desc : '';
$tag_token = count($tagsArr) ? 'bridge_tag_token' : '';
  
// option update enabled
if ($destination_update) {
    $date_modify = date("Y-m-d H:i:s", time());
    $person = $source_col_rec_name != '' ? "db2.".$source_col_rec_name : "''";
    $comment = $source_col_rec_desc != '' ? "db2.".$source_col_rec_desc : "''";
    $website = $source_col_rec_website != '' ? "db2.".$source_col_rec_website : "''";
    $f01 = $source_col_rec_f01 != '' ? "db2.".$source_col_rec_f01 : "''";
    $f02 = $source_col_rec_f02 != '' ? "db2.".$source_col_rec_f02 : "''";
    $f03 = $source_col_rec_f03 != '' ? "db2.".$source_col_rec_f03 : "''";
    $sql = "
        UPDATE  ".Settings::$dbName.".".PREF."_recipient as db1
        LEFT JOIN
                ".$bridge_db_name.".".$source_table_name." as db2
        ON      db1.email = db2.".$source_col_rec_mail."
        SET     db1.person = CONCAT(".$person.", '".$additional_name."'),
                db1.comment = CONCAT(".$comment.", '".$additional_desc."'),
                db1.website = '".$website."',
                db1.f01 = ".$f01."',
                db1.f02 = ".$f02."',
                db1.f03 = ".$f03."',
                db1.tag = '".$tag_token."'
        WHERE   db1.email = db2.".$source_col_rec_mail."
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $update_qty = $stmt->rowCount();
}
 
// direct insert
$sql = "
    INSERT IGNORE INTO ".Settings::$dbName.".".PREF."_recipient (
        person,
        email,
        tag,
        comment,
        website,
        f01,
        f02,
        f03
    )
    SELECT
        ".($source_col_rec_name != '' ? "concat(".$bridge_db_name.".".$source_table_name.".".$source_col_rec_name.",'".$additional_name."')" : "'".$additional_name."'").",
        ".$bridge_db_name.".".$source_table_name.".".$source_col_rec_mail.",
        '".$tag_token."',
        ".($source_col_rec_desc != '' ? "concat(".$bridge_db_name.".".$source_table_name.".".$source_col_rec_desc.",'".$additional_desc."')" : "'".$additional_desc."'").",
        ".($source_col_rec_website != '' ? $bridge_db_name.".".$source_table_name.".".$source_col_rec_website : "''").",
        ".($source_col_rec_f01 != '' ? $bridge_db_name.".".$source_table_name.".".$source_col_rec_f01 : "''").",
        ".($source_col_rec_f02 != '' ? $bridge_db_name.".".$source_table_name.".".$source_col_rec_f02 : "''").",
        ".($source_col_rec_f03 != '' ? $bridge_db_name.".".$source_table_name.".".$source_col_rec_f03 : "''")."
    FROM
        ".$bridge_db_name.".".$source_table_name."
";
$stmt = $db->prepare($sql);
$stmt->execute();
$insert_qty = $stmt->rowCount();
        
// update tags if neccesary
if ($tag_token != '') {
    // insert tags connection
    foreach ($tagsArr as $tagId) {
        $sql = "
            INSERT INTO ".PREF."_recipient_tag_conn (
                id_recipient,
                id_tag
            )
            SELECT
                r.id,
                '".$tagId."'
            FROM
                ".Settings::$dbName.".".PREF."_recipient as r
            WHERE 
                r.tag = '".$tag_token."'
        ";
        $db->query($sql);
        //echo "<hr>".$sql;
    }
    // clear tag token
    $sql = " UPDATE ".PREF."_recipient as r SET r.tag = '' WHERE r.tag = '".$tag_token."' ";
    $db->query($sql);
        //echo "<hr>".$sql;
}


echo '<p class="green">'.BRIDGE_IMPORT_OK1.$update_qty.' '.BRIDGE_IMPORT_OK2.$insert_qty.' '.ERRORS.':'.$errors_qty.'</p>';
