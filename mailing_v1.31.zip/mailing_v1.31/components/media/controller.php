<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "list":
        $load = "view.media.list.php";
        break;
    case "upload":
        $load = "action.media.upload.php";
        break;
    case "delete":
        $load = "action.media.delete.php";
        break;
    case "download":
        $load = "action.media.download.php";
        break;
    default:
        $load = "view.media.list.php";
        break;
}

include($load);	
