<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=media&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['fileid'];
$filename = $_POST['filename'];

$sql = " DELETE FROM ".PREF."_template_att WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

$sql = " DELETE FROM ".PREF."_template_att_conn WHERE id_att = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute();

$dir = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).'/uploads/';
unlink($dir.$filename);

header("Location: index.php?manage=media&action=list");
