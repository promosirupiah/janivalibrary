"use strict";

$(document).ready(function(){
    
    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    $('#sender').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });
    
    $('#senderDelete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var sendername = button.data('sendername');
        var senderemail = button.data('senderemail');
        var senderid = button.data('senderid');
        var modal = $(this);
        modal.find('.sendername').val(sendername + ' (' + senderemail + ') ' );
        modal.find('.senderid').val(senderid);
    });
    
});