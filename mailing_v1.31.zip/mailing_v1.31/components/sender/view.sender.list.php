<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$sender_head = '';
$sender_body = '';

$result = $db->query("
    select * from ".PREF."_sender
");

$sender_head .= "<tr><th>#</th><th>".SENDER_NAME."</th><th>".SENDER_EMAIL."</th><th></th></tr>";

foreach ($result as $row) {
    $i++;
    $sender_body .= "<tr><td>".$i."</td><td><a href='index.php?manage=sender&action=edit&id=".$row['id']."'>".$row['name']."</a></td><td><a href='index.php?manage=sender&action=edit&id=".$row['id']."'>".$row['email']."</a></td><td><button type='button' class='btn btn-danger btn-xs pull-right' data-toggle='modal' data-target='#senderDelete' data-sendername='".$row['name']."' data-senderemail='".$row['email']."' data-senderid='".$row['id']."' >".DELETE."</button><a class='btn btn-warning btn-xs pull-right' href='index.php?manage=sender&action=edit&id=".$row['id']."'>".EDIT."</a></td></tr>";
}

?>

<div class="modal fade" id="senderDelete" tabindex="-1" role="dialog" aria-labelledby="senderDeleteLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="senderDeleteLabel"><?php echo DELETING; ?></h4>
        </div>
        <form action="index.php?manage=sender&data=modify&action=delete" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
            <div class="modal-body">
                <input type="hidden" name="senderid" class="senderid" value="">
                <div class="form-group">
                    <label for="sendername" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                    <input type="text" class="form-control sendername" disabled>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo SENDER_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo SENDER_LIST;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="sender">
                    <thead>
                        <?php echo $sender_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $sender_body; ?>
                    </tbody>
                </table>
            </div>
            <a href="index.php?manage=sender&action=add" class="btn btn-primary"><?php echo MENU_ADD_SENDER;?></a>
        </div>
    </div>
</div>

<p>&nbsp;</p>

<script src="components/sender/view.sender.list.js"></script>
