<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=sender&action=list");
    exit();
}

$app->checkToken();

$name = $_POST['name'];
$email = $_POST['email'];

$sql = "
    INSERT INTO ".PREF."_sender (
        name,
        email
    ) VALUES (
        :name,
        :email
    )
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':name', $name, PDO::PARAM_STR);
$stmt->bindParam(':email', $email, PDO::PARAM_STR);
$stmt->execute();

$id = $db->lastInsertId();

header("Location: index.php?manage=sender&action=list");
