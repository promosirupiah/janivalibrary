<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.sender.add.php";
        break;
    case "edit":
        $load = "view.sender.edit.php";
        break;
    case "list":
        $load = "view.sender.list.php";
        break;
    case "update":
        $load = "action.sender.update.php";
        break;
    case "insert":
        $load = "action.sender.insert.php";
        break;
    case "delete":
        $load = "action.sender.delete.php";
        break;
    default:
        $load = "view.sender.list.php";
        break;
}

include($load);	
