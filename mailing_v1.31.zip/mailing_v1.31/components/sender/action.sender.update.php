<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=sender&action=list");
    exit();
}

$app->checkToken();

$name = $_POST['name'];
$email = $_POST['email'];
$id = (int)$_POST['id'];

$sql = "
    UPDATE ".PREF."_sender SET 
        name = :name,
        email = :email
    WHERE
        id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':name', $name, PDO::PARAM_STR);
$stmt->bindParam(':email', $email, PDO::PARAM_STR);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();

header("Location: index.php?manage=sender&action=list");
