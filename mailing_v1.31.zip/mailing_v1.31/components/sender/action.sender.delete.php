<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=sender&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['senderid'];

$sql = " DELETE FROM ".PREF."_sender WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 
/*
$sql = " DELETE FROM ".PREF."_sender_campaign_conn WHERE id_sender = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 
*/
header("Location: index.php?manage=sender&action=list");
