"use strict";

$(document).ready(function () {
    
    $('#tagDelete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var tagname = button.data('tagname');
        var tagid = button.data('tagid');
        var modal = $(this);
        modal.find('.tagid').val(tagid);
        modal.find('.tagname').val(tagname);
    });
        
    $.fn.dataTableExt.oStdClasses.sPageButton = "btn btn-default";
    
    $('#tags').DataTable({
        stateSave: true,
        language: dataTableTranslation
    });
    
    $('#verifyDelete').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget);
        var verifyname = button.data('verifyname');
        var verifyid = button.data('verifyid');
        var id = button.data('id');
        var modal = $(this);
        modal.find('.verifyname').val(verifyname);
        modal.find('.verifyid').val(verifyid);
        modal.find('.id').val(id);
    });
    
    verifyBulkCheckng();
    verifyDownload();
    
});

function verifyBulkCheckng() {
    $('.verifyStatusChecking').on('click', function() {
        alert('not available in demo mode');
    });
}

function verifyDownload() {
    $('.verifyDownload').on('click', function() {
        alert('not available in demo mode');
    });
}
