<?php

defined('_MAILING') or die('Restricted access');

$tags_option = '';

$tags = $db->query(" select * from ".PREF."_recipient_tag order by name asc");
foreach ($tags as $tag) {
    $tags_option .= "<div class='checkbox'><label><input class='flat' type='checkbox' name='tags[]' value='".$tag['id']."'>&nbsp;".$tag['name']."</label></div>";
}

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo RECIPIENT_ADD_NEW;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo RECIPIENT_DETAILS_ADD;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" action="index.php?manage=recipient&data=modify&action=insert" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <div class="form-group">
                        <label for="recipientname" class="col-sm-2 control-label"><?php echo RECIPIENT_NAME;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipientname" 
                                name="recipientname" 
                                placeholder="<?php echo RECIPIENT_NAME_PLACEHOLDER;?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="recipientmail" class="col-sm-2 control-label"><?php echo RECIPIENT_MAIL;?>*</label>
                        <div class="col-sm-5">
                            <input 
                                type="email" 
                                class="form-control" 
                                id="recipientmail" 
                                name="recipientmail" 
                                placeholder="<?php echo RECIPIENT_MAIL_PLACEHOLDER;?>" 
                                required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" class="flat"> <?php echo RECIPIENT_ONLY_TXT;?>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="recipientcomment" class="col-sm-2 control-label"><?php echo RECIPIENT_DESCRIPTION;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipientcomment" 
                                name="recipientcomment" 
                                placeholder="<?php echo RECIPIENT_DESCRIPTION_PLACEHOLDER;?>" 
                                >
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="recipientwebsite" class="col-sm-2 control-label">f0</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipientwebsite" 
                                name="recipientwebsite"
                                placeholder="field0" 
                                >
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="recipientf01" class="col-sm-2 control-label">f1</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipientf01" 
                                name="recipientf01"
                                placeholder="field1" 
                                >
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="recipientf02" class="col-sm-2 control-label">f2</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipientf02" 
                                name="recipientf02"
                                placeholder="field2" 
                                >
                        </div>
                    </div>
                    <div class="form-group">
                    <label for="recipientf03" class="col-sm-2 control-label">f3</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="recipientf03" 
                                name="recipientf03"
                                placeholder="field3" 
                                >
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tagsname" class="col-sm-2 control-label"><?php echo TAGS;?></label>
                        <div class="col-sm-5">
                            <?php echo $tags_option; ?>
                        </div>
                    </div>
                    <p>&nbsp;</p>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <a href="index.php?manage=recipient&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-3 col-sm-1">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>
