<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$verify_head = '';
$verify_body = '';

$result = $db->query("
    SELECT * FROM ".PREF."_verify_bulk AS vb
");

$verify_head .= "
    <tr>
        <th>#</th>
        <th>".V_ID."</th>
        <th>".V_QTY."</th>
        <th>".V_DATE."</th>
        <th>".V_MESSAGE."</th>
        <th>".V_PERC."</th>
        <th></th>
    </tr>
";

foreach ($result as $row) {
    $i++;
    $disabled1 = $row['percentage'] == '100' ? '' : 'hidden';
    $verify_body .= "
        <tr>
            <td>".$i."</td>
            <td>".$row['verify_id']."</td>
            <td>".$row['verify_qty']."</td>
            <td>".$row['verify_date']."</td>
            <td><span id='m_".$row['id']."'>".$row['verify_message']."</span></td>
            <td><span id='p_".$row['id']."'>".$row['percentage']."</span></td>
            <td>
                <button type='button' class='btn btn-danger btn-xs pull-right verifyStatusDelete' data-id='".$row['id']."' data-toggle='modal' data-target='#verifyDelete' data-verifyname='".$row['verify_id']." ".$row['verify_qty']." ".$row['verify_date']." ".$row['verify_message']."' data-verifyid='".$row['verify_id']."'>".DELETE."</button>
                <button id='vd_".$row['id']."' type='button' class='btn btn-success btn-xs pull-right verifyDownload ".$disabled1."' data-id='".$row['id']."'>".BUTTON_DOWN_UP."</button>
                <button type='button' class='btn btn-info btn-xs pull-right verifyStatusChecking' data-id='".$row['id']."'>".BUTTON_CHECK_STATUS."</button>
            </td>
        </tr>
    ";
}

?>

<input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>"> 

<div class="page-title">
    <div class="title_left">
        <h3><?php echo B_V_TITLE;?> <small>(<?php echo B_V_TITLE2;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>api.thechecker.co -> emailable.com</h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="tags">
                    <thead>
                        <?php echo $verify_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $verify_body; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<div class="modal fade" id="verifyDelete" tabindex="-1" role="dialog" aria-labelledby="verifyDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="verifyDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=recipient&data=modify&action=verify_delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="id" class="id" value="">
                    <input type="hidden" name="verifyid" class="verifyid" value="">
                    <div class="form-group">
                        <label for="verifyname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control verifyname" disabled>
                        <input type="checkbox" class="flat" id="delete" name="delete">&nbsp;<?php echo B_CONFIRM; ?>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-8">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="components/recipient/view.recipient.check_verify_list.<?php if (DEMO_MODE) { ?>demo.<?php } ?>js"></script>
