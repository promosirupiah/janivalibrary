<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=recipient&action=check_verify_list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['id'];

// delete from database
$sql = " DELETE FROM ".PREF."_verify_bulk WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

// delete from thechecker.co
if (isset($_POST['delete'])) {
    $verify_id = $_POST['verifyid'];
    $url = "https://api.thechecker.co/v2/verifications/".$verify_id."?api_key=".Settings::$thechecker;
    $ch=curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $result = curl_exec($ch);
    curl_close($ch);
}
header("Location: index.php?manage=recipient&action=check_verify_list");
