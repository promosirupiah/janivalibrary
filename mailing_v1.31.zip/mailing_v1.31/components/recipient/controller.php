<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.recipient.add.php";
        break;
    case "edit":
        $load = "view.recipient.edit.php";
        break;
    case "list":
        $load = "view.recipient.list.php";
        break;
    case "import":
        $load = "view.recipient.import.csv.php";
        break;
    case "export":
        $load = "view.recipient.export.csv.php";
        break;
    case "bounce":
        $load = "view.recipient.bounce.php";
        break;
    case "bounced":
        $load = "action.recipient.bounced.php";
        break;
    case "getlist":
        $load = "action.recipient.getlist.php";
        break;
    case "update":
        $load = "action.recipient.update.php";
        break;
    case "insert":
        $load = "action.recipient.insert.php";
        break;
    case "delete":
        $load = "action.recipient.delete.php";
        break;
    case "delete_filtered":
        $load = "action.recipient.delete_filtered.php";
        break;
    case "csv_ex":
        $load = "action.recipient.export.php";
        break;
    case "verify":
        $load = "action.recipient.verify.php";
        break;
    case "verify_bulk":
        $load = "action.recipient.verify_bulk.php";
        break;
    case "verify_bulk_status_checking":
        $load = "action.recipient.verify_bulk_status_checking.php";
        break;
    case "verify_download_mails":
        $load = "action.recipient.verify_download_mails.php";
        break;
    case "check_verify_list":
        $load = "view.recipient.check_verify_list.php";
        break;
    case "verify_delete":
        $load = "action.recipient.verify_delete.php";
        break;
    case "tags_manager":
        $load = "action.recipient.tags_manager.php";
        break;
    default:
        $load = "view.recipient.list.php";
        break;
}

include($load);	
