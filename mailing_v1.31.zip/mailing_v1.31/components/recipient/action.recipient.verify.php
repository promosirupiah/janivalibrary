<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=settings&action=system");
    exit();
}

$app->checkToken();

$id = (int)$_POST['id'];

$sql = "
    SELECT email FROM ".PREF."_recipient
    WHERE 
        id = '".$id."'
";
$stmt = $db->prepare($sql);
$stmt->bindParam(1, $id, PDO::PARAM_INT);
$stmt->execute();
$row = $stmt->fetchAll();

if (! @$data = $row[0]){
    echo DATA_ERROR;
    exit();
}

$email = $data['email'];

$url = "https://api.thechecker.co/v2/verify?email=".$email."&api_key=".Settings::$thechecker;



$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL,$url);
$result = curl_exec($ch);
curl_close($ch);

$json = json_decode($result, true);

if (isset($json['result'])) {
$info = $json['result'];
$sql = "
    UPDATE 
        ".PREF."_recipient
    SET 
        verified = :verified
    WHERE 
        id = :id
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':verified', $info, PDO::PARAM_STR);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
} else {
    $info = $json['message'];
}
echo $info;
/*
Array
(
    [email] => user04@exampledomain.com
    [result] => undeliverable
    [reason] => invalid_domain
    [disposable] => 
    [role] => 
    [accept_all] => 
    [free] => 
    [user] => user04
    [domain] => exampledomain.com
    [did_you_mean] => 
    [created_at] => 2019-06-23T08:17:00.202Z
    [id] => 5d0f357ceedb7f5b997f66cf
)
*/



