<?php
	
defined('_MAILING') or die('Restricted access');
	
?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo MENU_CSV_EXPORT;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                    <h2><?php echo RECIPIENT_CSV_EXPORT;?></h2>
                    <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form action="index.php?manage=recipient&action=csv_ex" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <input type="hidden" name="adata" value="1">
                    <p><?php echo RECIPIENT_CSV_EXPORT_CHK;?></p>
                    <p><input type="checkbox" checked="checked" class="flat" disabled> <?php echo RECIPIENT_CSV_EXPORT_CHK_EMAIL;?></p>
                    <p><input type="checkbox" class="flat" name="person" value="1"> <?php echo RECIPIENT_CSV_EXPORT_CHK_PERSO;?></p>
                    <p><input type="checkbox" class="flat" name="tags" value="1"> <?php echo RECIPIENT_CSV_EXPORT_CHK_TAG;?></p>
                    <p><input type="checkbox" class="flat" name="comment" value="1"> <?php echo RECIPIENT_CSV_EXPORT_CHK_COMM;?></p>
                    <p><input type="checkbox" class="flat" name="txt_only" value="1"> <?php echo RECIPIENT_CSV_EXPORT_CHK_TXT;?></p>
                    <p><input type="checkbox" class="flat" name="website" value="1"> f1</p>
                    <p><input type="checkbox" class="flat" name="f01" value="1"> f2</p>
                    <p><input type="checkbox" class="flat" name="f02" value="1"> f3</p>
                    <p><input type="checkbox" class="flat" name="f03" value="1"> f4</p>
                    <p><input type="checkbox" class="flat" name="date_create" value="1"> <?php echo RECIPIENT_CSV_EXPORT_CHK_DINPUT;?></p>
                    <p><input type="checkbox" class="flat" name="date_modify" value="1"> <?php echo RECIPIENT_CSV_EXPORT_CHK_DMODIF;?></p>
                    <input type="submit" value="<?php echo RECIPIENT_CSV_EXPORT_SUBMIT;?>" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>
</div>
