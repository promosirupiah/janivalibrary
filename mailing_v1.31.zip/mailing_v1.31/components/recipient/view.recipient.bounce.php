<?php

defined('_MAILING') or die('Restricted access');

$messageslimit = isset($_POST['messageslimit']) ? (int)($_POST['messageslimit']) : 10;
$messageslimit = $messageslimit != 0 ? $messageslimit : 10;
$deletefromdb = isset($_POST['deletefromdb']) ? true : false;
$deletefromserver = isset($_POST['deletefromserver']) ? true : false;
$smtpid = isset($_POST['smtpid']) ? $_POST['smtpid'] : '';

$result = $db->query(" SELECT * FROM ".PREF."_smtp ");
$smtp_select = "<option>choose your server</option>";
$i = 0;
foreach ($result as $row) {
    if ($row['bmh_server'] !='' && $row['bmh_port'] !='' && $row['bmh_service'] !='' && $row['bmh_soption'] !='' && $row['bmh_folder'] !='') {
        $selected = ($smtpid == $row["id"]) ? "selected='selected'" : "";
        $smtp_select .= "<option value='".$row['id']."' ".$selected.">".$row['name']." - ".$row['host']." - ".$row['username']." - ".$row['bmh_server']." - ".$row['bmh_folder']."</option>";
    }
    $i ++;
}
if ($i == 0) {
    $smtp_select = "<option>fill imap/pop3 section in smtp configuration to see your servers</option>";
}

if (isset($_POST['csrf_token'])) {
    $app->checkToken();
    $stmt = $db->prepare(" select * from ".PREF."_smtp where id=? ");
    $smtpid = (int)($_POST['smtpid']);
    $stmt->bindParam(1, $smtpid, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetchAll();
    $data = $row[0];
}

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo RECIPIENT_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo MENU_BOUNCED;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
<?php
    if (function_exists("imap_open")) {
?>
                <form class="form-horizontal" action="" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <div class="form-group">
                        <label for="smtpid" class="col-sm-2 control-label"><?php echo BOUNCED_CHOOSE_SERVER;?></label>
                        <div class="col-sm-8">
                            <select class="form-control" name="smtpid" required>
                                <?php echo $smtp_select; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <div class="checkbox">
                                <label>
                                    <input 
                                        type="checkbox" 
                                        class="form-control flat" 
                                        id="deletefromdb" 
                                        name="deletefromdb"
                                        value="1"
                                        <?php echo $deletefromdb ? 'checked="checked"' : ''; ?>
                                        >&nbsp;<?php echo BOUNCED_DEL_EMAILS;?>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <div class="checkbox">
                                <label>
                                    <input 
                                        type="checkbox" 
                                        class="form-control flat" 
                                        id="deletefromserver" 
                                        name="deletefromserver"
                                        value="1"
                                        <?php echo $deletefromserver ? 'checked="checked"' : ''; ?>
                                        >&nbsp;<?php echo BOUNCED_DEL_MESSAGES;?>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="messageslimit" class="col-sm-2 control-label"><?php echo BOUNCED_MAX;?></label>
                        <div class="col-sm-2">
                            <input
                                type="number"
                                class="form-control"
                                id="messageslimit"
                                name="messageslimit"
                                value="<?php echo $messageslimit;?>"
                                placeholder="default: 10"><span>&nbsp;<?php echo BOUNCED_AT_TIME;?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <button type="submit" class="btn btn-primary"><?php echo BOUNCED_START;?></button>
                        </div>
                    </div>
                    

                </form>
<?php
    } else {
?>
                <h2>You have to install imap library before usage of this feature.</h2>
                <p>In the php.ini file, uncomment line:</p>
                <p>;extension=php_imap.dll</p>
                <p>And restart your server of course...</p>
<?php
    }
?>
            </div>
                <?php
                    if (isset($_POST['csrf_token'])) {
                        if (DEMO_MODE) {
                            echo "Not available in DEMO mode";
                        } else {
                            include("php/bounced.php");
                        }
                    }
                ?>
        </div>
    </div>
</div>

