<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=recipient&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['recipientid'];

$sql = " DELETE FROM ".PREF."_recipient WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

$sql = " DELETE FROM ".PREF."_recipient_tag_conn WHERE id_recipient = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 


if (isset($_POST['backtounsubscribers'])) {
    header("Location: index.php?manage=campaign&action=unsubscribed");
    exit();
}

header("Location: index.php?manage=recipient&action=list");
