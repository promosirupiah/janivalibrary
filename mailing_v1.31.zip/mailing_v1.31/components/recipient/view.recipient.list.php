<?php

defined('_MAILING') or die('Restricted access');

    $tagsList = '';
    $tagsList2 = '';
    $tagsList3 = '';
    $queryLogic = '
    <div class="radio pull-right">
        <label data-toggle="tooltip" data-placement="top" title="" data-original-title="'.REC_QUERY_OR.'">
            <div class="icheckbox_flat pull-left" style="position: relative;">
                <input id="OR" class="flat qry" style="position: absolute; opacity: 0;" type="radio" name="queryLogic" value="OR" checked="checked">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>OR</span> 
        </label>
    </div>
    <div class="radio pull-right">
        <label data-toggle="tooltip" data-placement="top" title="" data-original-title="'.REC_QUERY_AND.'">
            <div class="icheckbox_flat pull-left" style="position: relative;">
                <input id="AND" class="flat qry" style="position: absolute; opacity: 0;" type="radio" name="queryLogic" value="AND">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>AND</span> 
        </label>
    </div>
    ';

$result = $db->query("
    SELECT
        rt.id,
        rt.name,
        rt.description,
        (
            SELECT count(id_tag) FROM ".PREF."_recipient_tag_conn AS rtc where rtc.id_tag = rt.id
        ) AS used
    FROM 
        ".PREF."_recipient_tag AS rt
");
$i = 0;
foreach ($result as $row) {
    $i++;
    $tagToolTip = $row['description'] !== '' ? ' data-toggle="tooltip" data-placement="top" title="" data-original-title="'.$row['description'].'"' : '';
    $tagsList .= '
    <div class="checkbox pull-right">
        <label '.$tagToolTip.'>
            <div class="icheckbox_flat pull-left" style="position: relative;" data-id="'.$row['id'].'">
                <input id="icheck_'.$row['id'].'" class="flat tagi" type="checkbox" value="'.$row['id'].'">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>'.$row['name'].' ('.$row['used'].')</span> 
        </label>
    </div>
    ';
    $tagsList2 .= '
    <div class="checkbox list">
        <label '.$tagToolTip.'>
            <div class="icheckbox_flat pull-left" style="position: relative;" data-id="'.$row['id'].'">
                <input id="icheck2_'.$row['id'].'" name="newtags[]" class="flat " type="checkbox" value="'.$row['id'].'">
                <ins class="iCheck-helper" ></ins>
            </div>&nbsp;<span>'.$row['name'].' ('.$row['used'].')</span> 
        </label>
    </div>
    ';
    
    $tagsList3 .= '<option value="'.$row['id'].'"><span>'.$row['name'].' ('.$row['used'].')</span> </option>';
}
$showTagsClass = ' hidden ';
$showLogicClass = ' hidden ';

$tagsList3 = '<select class="js-example-basic-single" multiple="multiple" name="newtags" id="newtags" style="width: 100%">'.$tagsList3.'</select>';

if ($i > 0) {
    $showTagsClass = '';
}
if ($i > 1) {
    $showLogicClass = '';
}

?>

<div class="modal fade" id="recipientsTagsManager" tabindex="-1" role="dialog" aria-labelledby="recipientsTagsManagerLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="recipientsTagsManagerLabel"><?php echo TAGS_MANAGER_TITLE;?><span data-table="0" id="qtyToTagsManage">0</span></h4>
            </div>
            <form id="part1" class="hidden" action="index.php?manage=recipient&data=modify&action=tags_manager" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" id="globalSearch" name="globalSearch" value="">
                <input type="hidden" id="globalLogic" name="globalLogic" value="">
                <input type="hidden" id="globalTags" name="globalTags" value="">
                <input type="hidden" id="recipientsArr" name="recipientsArr" class="recipientsArr" value="">
                
                <div class="modal-body">
                    <div class="form-group">
                        <p><?php echo TAGS_SELECT_ACTION;?></p>
                    </div>
                    <div class="radio">
                        <label data-toggle="tooltip" data-placement="top" title="" data-original-title="dodaj tagi">
                            <div class="icheckbox_flat pull-left">
                                <input id="" class="flat qry" type="radio" name="tagsLogic" value="add" checked="checked">
                                <ins class="iCheck-helper" ></ins>
                            </div>&nbsp;<span><?php echo TAGS_MANAGER_ADD;?></span> 
                        </label>
                    </div>
                    <div class="radio">
                        <label data-toggle="tooltip" data-placement="top" title="" data-original-title="usuń tagi">
                            <div class="icheckbox_flat pull-left">
                                <input id="" class="flat qry" type="radio" name="tagsLogic" value="remove" >
                                <ins class="iCheck-helper" ></ins>
                            </div>&nbsp;<span><?php echo TAGS_MANAGER_REMOVE;?></span> 
                        </label>
                    </div>
                    <div class="form-group">
                        <p><?php echo TAGS_SELECT;?></p>
                        <?php echo $tagsList2; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo SAVE_CHANGES;?></button>
                </div>
            </form>
            <form id="part2" class="hidden" action="index.php?manage=recipient&data=modify&action=tags_manager" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <p><?php echo NOT_SELECTED_TAGS;?></p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="recipientDelete" tabindex="-1" role="dialog" aria-labelledby="recipientDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="recipientDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=recipient&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" name="recipientid" class="recipientid" value="">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="recipientname" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control recipientname" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="recipientsDelete" tabindex="-1" role="dialog" aria-labelledby="recipientsDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="recipientsDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
            <form action="index.php?manage=recipient&data=modify&action=delete_filtered" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" id="del_search" name="search" value="">
                <input type="hidden" id="del_tags" name="tags" value="">
                <input type="hidden" id="del_logic" name="logic" value="">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="control-label"><?php echo DELETING_CONFIRM_QUESTION;?> <span id="qtyToDelete">0</span> <?php echo CAMPAIGN_RECIPIENT_QTY;?>?</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button id="delete_recipients" type="submit" class="btn btn-danger" ><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="recipientsVerify" tabindex="-1" role="dialog" aria-labelledby="recipientsVerifyLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="recipientsVerifyLabel"><?php echo B_RV;?></h4>
            </div>
            <form>
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" id="ver_search" name="search" value="">
                <input type="hidden" id="ver_tags" name="tags" value="">
                <input type="hidden" id="ver_logic" name="logic" value="">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="control-label"><?php echo B_SEND1;?> <span id="qtyToVerify">0</span> <?php echo B_SEND2;?>?</label>
                    </div>
                    <p id="verifyInfo"><?php echo WAITING;?> </p>
                </div>
                <div class="modal-footer">
                    <a id="bulk_compare" class="pull-left btn btn-success" href="index.php?manage=recipient&action=check_verify_list"><?php echo B_CHECK_LIST;?></a>
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="button" id="verify_recipients" class="btn btn-info" ><?php echo VERIFY;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo EMAIL_ADRESSES;?> <small>(<?php echo RECIPIENT_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo RECIPIENT_DB;?> <span id="recordsTotal">(0/0)</span></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <form id="filterList" class="form-horizontal">
                <input type="hidden" id="mojetagi" name="mojetagi" value="">
                <input type="hidden" id="mojequery" name="mojequery" value="OR">
				<div class="form-group ">
            <a class="btn btn-primary" href="index.php?manage=recipient&action=add"><?php echo MENU_ADD_RECIPIENT;?></a>
            <a class="btn btn-primary" id="bulkTagsManager" data-toggle='modal' data-target='#recipientsTagsManager'><?php echo TM_BUTTON;?></a>
            <a class="btn btn-info" data-toggle='modal' data-target='#recipientsVerify'><?php echo B_VER;?></a>
                    <span class="pull-right">&nbsp;&nbsp;<a class="btn btn-primary btn-xs resetquery"><?php echo REC_RESET;?></a></span>
                    <?php // echo $tagsList2; ?><span class="<?php echo $showLogicClass;?>"><?php echo $queryLogic; ?></span>
                </div>
				<div class="form-group ">
                    <?php echo TAGS_SELECT;?><?php echo $tagsList3; ?>
                </div>
            </form>
                <table class="table table-striped responsive-utilities jambo_table" id="recipients">
                    <thead>
                        <tr>
                            <th>
                                <label id="global" class="" for="markAll">
                                        <input id="markAll" type="checkbox" value="1" name="markAll" class="flat">
                                        <ins class="iCheck-helper" ></ins>
                                </label>
                            </th>
                            <th><?php echo PERSON; ?></th>
                            <th><?php echo EMAIL;?></th>
                            <th><?php echo TAGS;?></th>
                            <th><?php echo RECIPIENT_DESCRIPTION;?></th>
                            <th>f0</th>
                            <th>f1</th>
                            <th>f2</th>
                            <th>f3</th>
                            <th>emailable.com</th>
                            <th class="buttons"></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <a href="" class="btn btn-danger" data-toggle='modal' data-target='#recipientsDelete'><?php echo REC_BUTTON_DELETE;?></a>
        </div>
    </div>
</div>

<script src="components/recipient/view.recipient.list.<?php if (DEMO_MODE) { ?>demo.<?php } ?>js"></script>

