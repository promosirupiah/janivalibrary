<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=smtp&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['smtpid'];

$sql = " DELETE FROM ".PREF."_smtp WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

header("Location: index.php?manage=smtp&action=list");
