<?php

defined('_MAILING') or die('Restricted access');

$stmt = $db->prepare(" select * from ".PREF."_smtp where id=? ");
$id = (int)($_GET['id']);

if ($id == 0) {
    die("access denied");
}

$stmt->bindParam(1, $id, PDO::PARAM_INT);
$stmt->execute();
$row = $stmt->fetchAll();

// in case you want to edit not existent data
if (! @$data = $row[0]){
    echo DATA_ERROR;
    exit();
}


$smtpid = $data['id'];
$name = $data['name'];
$host = $data['host'];
$forcesmtp = $data['forcesmtp'];
$verifypeer = $data['verifypeer'];
$smtpauth = $data['smtpauth'];
$username = $data['username'];
$login = $data['login'];
$password = $data['password'];
$replytomail = $data['replytomail'];
$replytoname = $data['replytoname'];
$smtpsecure = $data['smtpsecure'];
$port = $data['port'];
$maxlimit = $data['maxlimit'];

$bmh_server = $data['bmh_server'];
$bmh_port = $data['bmh_port'];
$bmh_service = $data['bmh_service'];
$bmh_soption = $data['bmh_soption'];
$bmh_folder = $data['bmh_folder'];

// dkim section
$usedkim = $data['usedkim'];
$DKIM_domain = $data['dkim_domain'];
$DKIM_private = $data['dkim_private'];
$DKIM_selector = $data['dkim_selector'];
$DKIM_passphrase = $data['dkim_passphrase'];
$DKIM_identity = $data['dkim_identity'];

// force sender
$senderforce = $data['senderforce'];
$sendermail = $data['sendermail'];
$senderdescription = $data['senderdescription'];

?>
<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SMTP_PARAMS;?> <small>(<?php echo SMTP_EDIT;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>


<form class="form-horizontal" action="index.php?manage=smtp&data=modify&action=update" method="post">
    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
    <input type="hidden" name="smtpid" value="<?php echo $smtpid;?>">

<div data-example-id="togglable-tabs" role="tabpanel" class="">
    <ul role="tablist" class="nav nav-tabs bar_tabs" id="myTab">
        <li class="active" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab" role="tab" href="#tab_content1"><?php echo SMTP_CONFIG;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab2" role="tab" href="#tab_content2"><?php echo DKIM_SETTINGS;?></a>
        </li>
        <li class="" role="presentation"><a aria-expanded="false" data-toggle="tab" id="profile-tab3" role="tab" href="#tab_content3"><?php echo IMAP_CONFIG;?></a>
    </ul>
    <div class="tab-content" id="myTabContent">

        <div aria-labelledby="profile-tab" id="tab_content1" class="tab-pane fade active in" role="tabpanel">

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo SMTP_INFO_SETUP;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                

                    <div class="form-group">
                    <label for="name" class="col-sm-2 control-label"><?php echo SMTP_NAME;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="name" 
                                name="name" 
                                placeholder="<?php echo SMTP_NAME_PLACEHOLDER;?>"
                                value="<?php echo $name; ?>"
                                >
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="host" class="col-sm-2 control-label"><?php echo SMTP_HOST;?> *</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="host" 
                                name="host" 
                                placeholder="<?php echo SMTP_HOST_PLACEHOLDER;?>"
                                value="<?php echo $host; ?>"
                                required>
                        </div>
                    </div>
                    
                <hr>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="forcesmtp"></label>
                        <div class="col-sm-4">
                          <input 
                            type="checkbox" 
                            class="form-control flat" 
                            id="forcesmtp" 
                            name="forcesmtp"
                            <?php echo $forcesmtp == '1' ? 'checked="checked"' : ''; ?>
                            >&nbsp;<?php echo SMTP_FORCE_SMTP;?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="verifypeer"></label>
                        <div class="col-sm-4">
                          <input 
                            type="checkbox" 
                            class="form-control flat" 
                            id="verifypeer" 
                            name="verifypeer"
                            <?php echo $verifypeer == '1' ? 'checked="checked"' : ''; ?>
                            >&nbsp;<?php echo SMTP_VERIFY_PEER;?>
                        </div>
                    </div>
                    
                <hr>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="smtpauth"></label>
                        <div class="col-sm-4">
                          <input 
                            type="checkbox" 
                            class="form-control flat" 
                            id="smtpauth" 
                            name="smtpauth"
                            <?php echo $smtpauth == '1' ? 'checked="checked"' : ''; ?>
                            >&nbsp;<?php echo SMTP_PAUTH_PLACEHOLDER;?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="login" class="col-sm-2 control-label">SMTP login *</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="smtp_login" 
                                name="login" 
                                placeholder="<?php echo SMTP_LOGIN_PLACEHOLDER;?>"
                                value="<?php echo $login; ?>"
                                required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="password" class="col-sm-2 control-label"><?php echo SMTP_PASSWORD;?> *</label>
                        <div class="col-sm-5">
                            <input 
                                type="password" 
                                class="form-control" 
                                id="password" 
                                name="password" 
                                placeholder="<?php echo SMTP_PASSWORD_PLACEHOLDER;?>"
                                value="<?php echo $password; ?>"
                                required>
                        </div>
                    </div>
                    
                <hr>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="senderforce"></label>
                        <div class="col-sm-4">
                          <input 
                            type="checkbox" 
                            class="form-control flat" 
                            id="senderforce" 
                            name="senderforce"
                            <?php echo $senderforce == '1' ? 'checked="checked"' : ''; ?>
                            >&nbsp;<?php echo SMTP_SENDER_FORCE;?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="sendermail" class="col-sm-2 control-label"><?php echo SMTP_SENDER_MAIL;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="sendermail" 
                                name="sendermail" 
                                placeholder=""
                                value="<?php echo $sendermail; ?>"
                                >
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="senderdescription" class="col-sm-2 control-label"><?php echo SMTP_SENDER_DESCRIPTION;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="senderdescription" 
                                name="senderdescription" 
                                placeholder=""
                                value="<?php echo $senderdescription; ?>"
                                >
                        </div>
                    </div>
                    
                <hr>
                    
                    <div class="form-group">
                    <label for="username" class="col-sm-2 control-label">Bounce to *</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="username" 
                                name="username" 
                                placeholder="<?php echo BOUNCED_INFO;?>"
                                value="<?php echo $username; ?>"
                                required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="replytomail" class="col-sm-2 control-label"><?php echo SMTP_REPLYTO;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="replytomail" 
                                name="replytomail" 
                                placeholder="<?php echo SMTP_REPLYTO_PLACEHOLDER;?>"
                                value="<?php echo $replytomail; ?>"
                                >
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="replytoname" class="col-sm-2 control-label"><?php echo SMTP_REPLYTONAME;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="replytoname" 
                                name="replytoname" 
                                placeholder="<?php echo SMTP_REPLYTONAME_PLACEHOLDER;?>"
                                value="<?php echo $replytoname; ?>"
                                >
                        </div>
                    </div>
                    
                    <hr>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="smtpsecure"><?php echo SMTP_SECURE;?></label>
                        <div class="col-sm-6">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="tls" type="radio" name="smtpsecure" class="flat" <?php echo $smtpsecure == 'tls' ? 'checked="checked"' : ''; ?>><ins class="iCheck-helper"></ins>
                                </div> <?php echo SMTP_SECURE_TLS;?>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="smtpsecure"></label>
                        <div class="col-sm-4">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="ssl" type="radio" name="smtpsecure" class="flat" <?php echo $smtpsecure == 'ssl' ? 'checked="checked"' : ''; ?>><ins class="iCheck-helper"></ins></div> <?php echo SMTP_SECURE_SSL;?>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                    <label for="port" class="col-sm-2 control-label"><?php echo SMTP_PORT;?> *</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="port" 
                                name="port" 
                                placeholder="<?php echo SMTP_PORT_PLACEHOLDER;?>"
                                value="<?php echo $port; ?>"
                                required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="maxlimit" class="col-sm-2 control-label"><?php echo SMTP_LIMIT;?> *</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="maxlimit" 
                                name="maxlimit" 
                                placeholder="<?php echo SMTP_LIMIT_PLACEHOLDER;?>"
                                value="<?php echo $maxlimit; ?>"
                                required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <a href="index.php?manage=smtp&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-3 col-sm-1">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>

            </div>
        </div>
    </div>
</div>

        </div>
        
        <div aria-labelledby="profile-tab" id="tab_content2" class="tab-pane fade" role="tabpane2">
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo DKIM_SETTINGS;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="usedkim"></label>
                        <div class="col-sm-4">
                          <input 
                            type="checkbox" 
                            class="form-control flat" 
                            id="usedkim" 
                            name="usedkim"
                            <?php echo $usedkim == '1' ? 'checked="checked"' : ''; ?>
                            >&nbsp;<?php echo DKIM_USE;?>
                        </div>
                    </div>

                    <hr>
                    
                    <div class="form-group">
                    <label for="DKIM_domain" class="col-sm-2 control-label">DKIM_domain</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="DKIM_domain" 
                                name="DKIM_domain" 
                                placeholder="example.com"
                                value="<?php echo $DKIM_domain; ?>"
                                >
                            <small><?php echo DKIM_DOMAIN;?></small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="DKIM_private" class="col-sm-2 control-label">DKIM_private</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="DKIM_private" 
                                name="DKIM_private" 
                                placeholder="/path/to/my/private.key"
                                value="<?php echo $DKIM_private; ?>"
                                >
                            <small><?php echo DKIM_PRIVATE;?></small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="DKIM_selector" class="col-sm-2 control-label">DKIM_selector</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="DKIM_selector" 
                                name="DKIM_selector" 
                                placeholder="phpmailer"
                                value="<?php echo $DKIM_selector; ?>"
                                >
                            <small><?php echo DKIM_SELECTOR;?></small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="DKIM_passphrase" class="col-sm-2 control-label">DKIM_passphrase</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="DKIM_passphrase" 
                                name="DKIM_passphrase" 
                                placeholder=""
                                value="<?php echo $DKIM_passphrase; ?>"
                                >
                            <small><?php echo DKIM_PASS;?></small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="DKIM_identity" class="col-sm-2 control-label">DKIM_identity</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="DKIM_identity" 
                                name="DKIM_identity" 
                                placeholder="myaddres@example.com"
                                value="<?php echo $DKIM_identity; ?>"
                                >
                            <small><?php echo DKIM_IDENTITY;?></small>
                        </div>
                    </div>
                    


                    <p>&nbsp;</p>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <a href="index.php?manage=smtp&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-3 col-sm-1">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                    
                    
            </div>
        </div>
    </div>
</div>
        </div>
        
        <div aria-labelledby="profile-tab" id="tab_content3" class="tab-pane fade" role="tabpanel">

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo IMAP_INFO_SETUP;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">


                    <div class="form-group">
                        <label for="bmh_server" class="col-sm-2 control-label"><?php echo SMTP_HOST;?></label>
                        <div class="col-sm-5">
                            <input
                                type="text"
                                class="form-control"
                                id="bmh_server"
                                name="bmh_server"
                                placeholder="pop3.domain.ext / imap.domain.ext"
                                value="<?php echo $bmh_server; ?>"
                                >
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="bmh_port" class="col-sm-2 control-label">Port</label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="bmh_port" 
                                name="bmh_port" 
                                placeholder="default: 143"
                                value="<?php echo $bmh_port; ?>"
                                >
                        </div>
                    </div>

                    <hr>
                    
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="bmh_service"><?php echo PROTOCOL;?></label>
                        <div class="col-sm-6">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="imap" type="radio" name="bmh_service" class="flat" <?php echo $bmh_service == 'imap' ? 'checked="checked"' : ''; ?>><ins class="iCheck-helper"></ins>
                                </div> imap
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label" for="bmh_service"></label>
                        <div class="col-sm-4">
                            <div class="radio">
                                <label class="myFlat">
                                <div class="iradio_flat-green">
                                    <input value="pop3" type="radio" name="bmh_service" class="flat" <?php echo $bmh_service == 'pop3' ? 'checked="checked"' : ''; ?>><ins class="iCheck-helper"></ins></div> pop3
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="bmh_soption" class="col-sm-2 control-label"><?php echo SMTP_SECURE;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="bmh_soption" 
                                name="bmh_soption" 
                                placeholder="(none, tls, notls, ssl, etc.), default is 'notls'"
                                value="<?php echo $bmh_soption; ?>"
                                >
                        </div>
                    </div>
                    
                    <div class="form-group">
                    <label for="bmh_folder" class="col-sm-2 control-label"><?php echo FOLDER;?></label>
                        <div class="col-sm-5">
                            <input 
                                type="text" 
                                class="form-control" 
                                id="bmh_folder" 
                                name="bmh_folder" 
                                placeholder="default is 'INBOX'"
                                value="<?php echo $bmh_folder; ?>"
                                >
                        </div>
                    </div>

                    <p>&nbsp;</p>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-1">
                            <a href="index.php?manage=smtp&action=list" type="button" class="btn btn-success"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                        <div class="col-sm-offset-3 col-sm-1">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
</div>

        </div>
    </div>
</div>

</form>


<p>&nbsp;</p>
