<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=smtp&action=list");
    exit();
}

$app->checkToken();

$name = isset($_POST['name']) ? $_POST['name'] : '';
$host = isset($_POST['host']) ? $_POST['host'] : '';
$smtpauth = isset($_POST['smtpauth']) ? 1 : 0 ;
$forcesmtp = isset($_POST['forcesmtp']) ? 1 : 0 ;
$verifypeer = isset($_POST['verifypeer']) ? 1 : 0 ;
$username = isset($_POST['username']) ? $_POST['username'] : '';
$login = isset($_POST['login']) ? $_POST['login'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$replytomail = isset($_POST['replytomail']) ? $_POST['replytomail'] : '';
$replytoname = isset($_POST['replytoname']) ? $_POST['replytoname'] : '';
$smtpsecure = isset($_POST['smtpsecure']) ? $_POST['smtpsecure'] : '';
$port = isset($_POST['port']) ? (int)$_POST['port'] : '587';
$maxlimit = (int)$_POST['maxlimit'] != 0 ? (int)$_POST['maxlimit'] : 1000 ;
$bmh_server = isset($_POST['bmh_server']) ? $_POST['bmh_server'] : '';
$bmh_port = isset($_POST['bmh_port']) ? (int)$_POST['bmh_port'] : '110';
$bmh_service = isset($_POST['bmh_service']) ? $_POST['bmh_service'] : '';
$bmh_soption = isset($_POST['bmh_soption']) ? $_POST['bmh_soption'] : '';
$bmh_folder = isset($_POST['bmh_folder']) ? $_POST['bmh_folder'] : '';

// dkim section
$usedkim = isset($_POST['usedkim']) ? 1 : 0;
$DKIM_domain = isset($_POST['DKIM_domain']) ? $_POST['DKIM_domain'] : '';
$DKIM_private = isset($_POST['DKIM_private']) ? $_POST['DKIM_private'] : '';
$DKIM_selector = isset($_POST['DKIM_selector']) ? $_POST['DKIM_selector'] : '';
$DKIM_passphrase = isset($_POST['DKIM_passphrase']) ? $_POST['DKIM_passphrase'] : '';
$DKIM_identity = isset($_POST['DKIM_identity']) ? $_POST['DKIM_identity'] : '';

// force sender
$senderforce = isset($_POST['senderforce']) ? 1 : 0;
$sendermail = isset($_POST['sendermail']) ? $_POST['sendermail'] : '';
$senderdescription = isset($_POST['senderdescription']) ? $_POST['senderdescription'] : '';


$sql = "
    INSERT INTO ".PREF."_smtp (
        name,
        host,
        smtpauth,
        username,
        login,
        password,
        replytomail,
        replytoname,
        smtpsecure,
        port,
        maxlimit,
        forcesmtp,
        verifypeer,
        bmh_server,
        bmh_port,
        bmh_service,
        bmh_soption,
        bmh_folder,
        usedkim,
        dkim_domain,
        dkim_private,
        dkim_selector,
        dkim_passphrase,
        dkim_identity,
        senderforce,
        sendermail,
        senderdescription
    ) VALUES (
        :name,
        :host,
        :smtpauth,
        :username,
        :login,
        :password,
        :replytomail,
        :replytoname,
        :smtpsecure,
        :port,
        :maxlimit,
        :forcesmtp,
        :verifypeer,
        :bmh_server,
        :bmh_port,
        :bmh_service,
        :bmh_soption,
        :bmh_folder,
        :usedkim,
        :dkim_domain,
        :dkim_private,
        :dkim_selector,
        :dkim_passphrase,
        :dkim_identity,
        :senderforce,
        :sendermail,
        :senderdescription
    )
";
$stmt = $db->prepare($sql);
$stmt->bindParam(':name', $name, PDO::PARAM_STR);
$stmt->bindParam(':host', $host, PDO::PARAM_STR);
$stmt->bindParam(':smtpauth', $smtpauth, PDO::PARAM_STR);
$stmt->bindParam(':username', $username, PDO::PARAM_STR);
$stmt->bindParam(':login', $login, PDO::PARAM_STR);
$stmt->bindParam(':password', $password, PDO::PARAM_STR);
$stmt->bindParam(':replytomail', $replytomail, PDO::PARAM_STR);
$stmt->bindParam(':replytoname', $replytoname, PDO::PARAM_STR);
$stmt->bindParam(':smtpsecure', $smtpsecure, PDO::PARAM_STR);
$stmt->bindParam(':port', $port, PDO::PARAM_STR);
$stmt->bindParam(':maxlimit', $maxlimit, PDO::PARAM_STR);
$stmt->bindParam(':forcesmtp', $forcesmtp, PDO::PARAM_STR);
$stmt->bindParam(':verifypeer', $verifypeer, PDO::PARAM_STR);
$stmt->bindParam(':bmh_server', $bmh_server, PDO::PARAM_STR);
$stmt->bindParam(':bmh_port', $bmh_port, PDO::PARAM_STR);
$stmt->bindParam(':bmh_service', $bmh_service, PDO::PARAM_STR);
$stmt->bindParam(':bmh_soption', $bmh_soption, PDO::PARAM_STR);
$stmt->bindParam(':bmh_folder', $bmh_folder, PDO::PARAM_STR);
$stmt->bindParam(':usedkim', $usedkim, PDO::PARAM_STR);
$stmt->bindParam(':dkim_domain', $DKIM_domain, PDO::PARAM_STR);
$stmt->bindParam(':dkim_private', $DKIM_private, PDO::PARAM_STR);
$stmt->bindParam(':dkim_selector', $DKIM_selector, PDO::PARAM_STR);
$stmt->bindParam(':dkim_passphrase', $DKIM_passphrase, PDO::PARAM_STR);
$stmt->bindParam(':dkim_identity', $DKIM_identity, PDO::PARAM_STR);
$stmt->bindParam(':senderforce', $senderforce, PDO::PARAM_STR);
$stmt->bindParam(':sendermail', $sendermail, PDO::PARAM_STR);
$stmt->bindParam(':senderdescription', $senderdescription, PDO::PARAM_STR);
$stmt->execute();

header("Location: index.php?manage=smtp&action=list");
