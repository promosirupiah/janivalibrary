<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.smtp.add.php";
        break;
    case "edit":
        $load = "view.smtp.edit.php";
        break;
    case "list":
        $load = "view.smtp.list.php";
        break;
    case "import":
        $load = "action.smtp.import.csv.php";
        break;
    case "update":
        $load = "action.smtp.update.php";
        break;
    case "insert":
        $load = "action.smtp.insert.php";
        break;
    case "delete":
        $load = "action.smtp.delete.php";
        break;
    case "test":
        $load = "action.smtp.test.php";
        break;
    default:
        $load = "view.smtp.list.php";
        break;
}

include($load);	
