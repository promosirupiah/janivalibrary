<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$tags_head = '';
$tags_body = '';

$result = $db->query("
    SELECT * FROM ".PREF."_smtp
");

$tags_head .= "
    <tr>
        <th>#</th>
        <th>".SMTP_NAME."</th>
        <th>".SMTP_HOST."</th>
        <th>".SMTP_USERNAME."</th>
        <th>".MENU_SMTP_PARAMS."</th>
        <th></th>
    </tr>
";

foreach ($result as $row) {
    $i++;
    $tags_body .= "
    <tr>
        <td>".$i."</td>
        <td><a href='index.php?manage=smtp&action=edit&id=".$row['id']."'>".$row['name']."</a></td>
        <td><a href='index.php?manage=smtp&action=edit&id=".$row['id']."'>".$row['host']."</a></td>
        <td><a href='index.php?manage=smtp&action=edit&id=".$row['id']."'>".$row['username']."</a></td>
        <td><a href='index.php?manage=smtp&action=edit&id=".$row['id']."'>".$row['smtpsecure']." / ".$row['port']." / ".$row['maxlimit']."</a></td>
        <td>
            <button type='button' class='btn btn-danger btn-xs pull-right' data-toggle='modal' data-target='#smtpDelete' data-smtp='".$row['name']."&nbsp(".$row['host'].")' data-smtpid='".$row['id']."'>".DELETE."</button>
            <a class='btn btn-warning btn-xs pull-right' href='index.php?manage=smtp&action=edit&id=".$row['id']."' >".EDIT."</a>
            <button type='button' class='btn btn-primary btn-xs pull-right' data-toggle='modal' data-target='#smtpTest' data-username='".$row['username']."' data-smtpid='".$row['id']."'>".TEST."</button>
        </td>
    </tr>";
}

?>

<div class="modal fade" id="smtpTest" tabindex="-1" role="dialog" aria-labelledby="tagDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="tagDeleteLabel"><?php echo SMTP_TESTING; ?></h4>
          </div>
            <form action="index.php?manage=smtp&data=modify&action=test" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <input type="hidden" name="smtpid" class="smtpid" value="">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="username" class="control-label"><?php echo SMTP_TESTING_EMAIL; ?></label>
                        <input type="email" class="form-control username" name="username" value="">
                    </div>
                <div class="form-group">
                    <label for="debug_level" class="control-label">SMTP resonse (<?php echo SMTP_LABEL; ?>)</label>
                    <select class="form-control" name="debug_level" id="debug_level" required>
                        <option value="0">SMTP::DEBUG_OFF (0): <?php echo SMTP_0; ?> </option>
                        <option value="1" selected="selected">SMTP::DEBUG_CLIENT (1): <?php echo SMTP_1; ?> </option>
                        <option value="2">SMTP::DEBUG_SERVER (2): <?php echo SMTP_2; ?> </option>
                        <option value="3">SMTP::DEBUG_CONNECTION (3): <?php echo SMTP_3; ?> </option>
                        <option value="4">SMTP::DEBUG_LOWLEVEL (4): <?php echo SMTP_4; ?> </option>
                    </select>
                </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button id="testConnection" type="submit" class="btn btn-primary"><?php echo SMTP_RUN_TEST;?></button>
                </div>
            </form>
                <div id="response" class="modal-body">
                    <div class="form-group">
                        <p></p>
                    </div>
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CLOSE;?></button>
                </div>
        </div>
    </div>
</div>

<div class="modal fade" id="smtpDelete" tabindex="-1" role="dialog" aria-labelledby="tagDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="tagDeleteLabel"><?php echo DELETING; ?></h4>
          </div>
            <form action="index.php?manage=smtp&data=modify&action=delete" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <div class="modal-body">
                    <input type="hidden" name="smtpid" class="smtpid" value="">
                    <div class="form-group">
                        <label for="smtp" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                        <input type="text" class="form-control smtp" disabled>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                    <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="page-title">
    <div class="title_left">
        <h3><?php echo MENU_SMTP_PARAMS;?> <small>(<?php echo SMTP_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo SMTP_INFO;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="tags">
                    <thead>
                        <?php echo $tags_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $tags_body; ?>
                    </tbody>
                </table>
            </div>
            <a href="index.php?manage=smtp&action=add" class="btn btn-primary"><?php echo SMTP_ADD_BUTTON;?></a>
        </div>
    </div>
</div>
<p>&nbsp;</p>

<script src="components/smtp/view.smtp.list.js"></script>
