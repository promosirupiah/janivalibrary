<?php

defined('_MAILING') or die('Restricted access');

$i = 0;
$thumb_head = '';
$thumb_body = '';

$result = $db->query("
    SELECT
        tt.id,
        tt.filename
    FROM 
        ".PREF."_template_thumb AS tt
");

$thumb_head .= "<tr><th>#</th><th>".TEMPLATES_THUMB."</th><th>".MEDIA_FILENAME."</th><th></th></tr>";
foreach ($result as $row) {
    $i++;
    $thumb_body .= "<tr>
        <td>".$i."</td>
        <td><a href='index.php?manage=templates_thumb&data=modify&action=download&id=".$row['id']."'><img src='uploads/".$row['filename']."'></a></td>
        <td><a href='index.php?manage=templates_thumb&data=modify&action=download&id=".$row['id']."'>".$row['filename']."</a></td>
        <td><button type='button' class='btn btn-danger btn-xs pull-right' data-toggle='modal' data-target='#fileDelete' data-filename='".$row['filename']."' data-fileid='".$row['id']."' >".DELETE."</button></td>
    </tr>";
}

?>
<div class="modal fade" id="fileDelete" tabindex="-1" role="dialog" aria-labelledby="fileDeleteLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="fileDeleteLabel"><?php echo DELETING; ?></h4>
            </div>
                <form action="index.php?manage=templates_thumb&data=modify&action=delete" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <div class="modal-body">
                            <input type="hidden" name="fileid" class="fileid" value="">
                            <input type="hidden" name="filename" class="filename" value="">
                            <div class="form-group">
                                <label for="filename" class="control-label"><?php echo DELETING_CONFIRM_QUESTION; ?></label>
                                <input type="text" class="form-control filename" disabled>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo CANCEL;?></button>
                        <button type="submit" class="btn btn-danger"><?php echo DELETE;?></button>
                    </div>
                </form>
        </div>
    </div>
</div>


<div class="page-title">
    <div class="title_left">
        <h3><?php echo TEMPLATES_THUMBNAIL_TITLE_EDIT;?> <small>(<?php echo THUMBNAIL_MEDIA_LIST;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo THUMBNAIL_MEDIA_LIST;?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <table class="table table-striped responsive-utilities jambo_table" id="files">
                    <thead>
                        <?php echo $thumb_head; ?>
                    </thead>
                    <tbody>
                        <?php echo $thumb_body; ?>
                    </tbody>
                </table>
            </div>
            <p>&nbsp;</p>
            <form class="form-inline" method="post" enctype="multipart/form-data" action="index.php?manage=templates_thumb&data=modify&action=upload">
                <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                <label for="upload"><?php echo MEDIA_ADD_FILES;?></label>
                <div class="input-group">
                    <span class="input-group-btn">
                        <span class="btn btn-primary btn-file">
                            <?php echo MEDIA_BROWSE;?> <input id="upload" class="form-control input-sm" name="files[]" type="file" multiple="multiple" size="100" placeholder=""/>
                        </span>
                    </span>
                    <input id="upload_info" type="text" readonly="" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary"><?php echo MEDIA_UPLOAD;?></button>
            </form>
        </div>
    </div>
</div>

<p>&nbsp;</p>

<script src="components/templates_thumb/view.templates_thum.list.js"></script>
