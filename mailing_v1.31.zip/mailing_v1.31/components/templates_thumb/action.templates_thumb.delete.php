<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=templates_thumb&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['fileid'];
$filename = $_POST['filename'];

// delete template thumbnail from db
$sql = " DELETE FROM ".PREF."_template_thumb WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute();

// set thumbnail file to 'no-picture.png' for template
$sql = " UPDATE ".PREF."_template SET thumb_filename = 'no-picture.png' WHERE thumb_filename = :filename ";
$stmt = $db->prepare($sql);
$stmt->bindParam(':filename', $filename, PDO::PARAM_INT);
$stmt->execute();

// delete thumbnail from uploads folder but not for predefined templates
$dir = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).'/uploads/';
$protected_thumb_files = Array('rwd-free-template.jpg', 'tempo-by-kevin.jpg', 'wooshi-by-kevin.jpg', 'simples.jpg', 'underscore.jpg', 'nexit.jpg', 'minty.jpg', 'tubor.jpg', 'kids.jpg', 'tripnews.jpg', 'email.jpg', 'businesstemplate.jpg', 'roselle.jpg', 'cantino.jpg', 'vanessa.jpg', 'suplements.jpg', 'university.jpg', 'perfume.jpg', 'financial.jpg', 'woman.jpg', 'nature.jpg', 'hosting.jpg', 'life.jpg', 'spa.jpg', 'lastminute.jpg', 'office.jpg', 'vipticket.jpg', 'press.jpg', 'cosmetics.jpg', 'christmas.jpg', 'example-template.jpg');

if (! in_array($filename, $protected_thumb_files)) {
    unlink($dir.$filename);
}

header("Location: index.php?manage=templates_thumb&action=list");
