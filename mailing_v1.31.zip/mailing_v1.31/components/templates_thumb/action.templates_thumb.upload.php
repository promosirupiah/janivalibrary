<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=templates_thumb&action=list");
    exit();
}

$app->checkToken();

$dir = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).'/uploads/';
$uploads = count($_FILES['files']['name']);
for ($i = 0; $i < $uploads; $i++) {
    if ($_FILES['files']['name'][$i] !=''){
        $name = $_FILES['files']['name'][$i];
        $type = $_FILES['files']['type'][$i];
        $tmp_name = $_FILES['files']['tmp_name'][$i];
        $error = $_FILES['files']['error'][$i];
        $size = $_FILES['files']['size'][$i];
        move_uploaded_file($tmp_name,$dir.$name);
        $sql = " INSERT INTO ".PREF."_template_thumb ( filename ) VALUES ( :filename ) ";
        $stmt = $db->prepare($sql);              
        $stmt->bindParam(':filename', $name, PDO::PARAM_STR); 
        $stmt->execute(); 
    }
}

header("Location: index.php?manage=templates_thumb&action=list");
