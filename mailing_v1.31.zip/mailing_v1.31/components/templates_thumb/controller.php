<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "list":
        $load = "view.templates_thumb.list.php";
        break;
    case "upload":
        $load = "action.templates_thumb.upload.php";
        break;
    case "delete":
        $load = "action.templates_thumb.delete.php";
        break;
    case "download":
        $load = "action.templates_thumb.download.php";
        break;
    default:
        $load = "view.templates_thumb.list.php";
        break;
}

include($load);	
