<?php

defined('_MAILING') or die('Restricted access');

if (DEMO_MODE) {
    header("Location: index.php?manage=templates&action=list");
    exit();
}

$app->checkToken();

$id = (int)$_POST['templateid'];

// get template thumbnail filename
$stmt = $db->prepare(" SELECT thumb_filename FROM ".PREF."_template WHERE id = ? ");
$stmt->bindParam(1, $id, PDO::PARAM_INT);
$stmt->execute();
$row = $stmt->fetchAll();
$data = $row[0];
$thumb_filename = $data['thumb_filename'];

// delete template
$sql = " DELETE FROM ".PREF."_template WHERE id = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute(); 

// delete template thumbnail
$sql = " DELETE FROM ".PREF."_template_thumb WHERE filename = :filename ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':filename', $thumb_filename, PDO::PARAM_INT);   
$stmt->execute(); 

// delete connected attachments
$sql = " DELETE FROM ".PREF."_template_att_conn WHERE id_template = :id ";
$stmt = $db->prepare($sql);              
$stmt->bindParam(':id', $id, PDO::PARAM_INT);   
$stmt->execute();

header("Location: index.php?manage=templates&action=list");
