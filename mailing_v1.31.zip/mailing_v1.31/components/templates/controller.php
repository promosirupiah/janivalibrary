<?php

defined('_MAILING') or die('Restricted access');

switch ($app->action) {
    case "add":
        $load = "view.templates.add.php";
        break;
    case "edit":
        $load = "view.templates.edit.php";
        break;
    case "list":
        $load = "view.templates.list.php";
        break;
    case "update":
        $load = "action.templates.update.php";
        break;
    case "insert":
        $load = "action.templates.insert.php";
        break;
    case "delete":
        $load = "action.templates.delete.php";
        break;
    case "test":
        $load = "action.templates.test.php";
        break;
    case "copy":
        $load = "action.templates.copy.php";
        break;
    default:
        $load = "view.templates.list.php";
        break;
}

include($load);	
