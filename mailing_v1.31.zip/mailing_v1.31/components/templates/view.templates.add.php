<?php

defined('_MAILING') or die('Restricted access');

$files_option = '';

$files = $db->query(" select * from ".PREF."_template_att order by filename asc ");
foreach ($files as $file) {
    $files_option .= "<div class='checkbox'><label><input class='flat' type='checkbox' name='files[]' value='".$file['id']."'>&nbsp;".$file['filename']."</label></div>";
}

$editor = Settings::$systemEditor;


$stmt = $db->query(" SHOW FIELDS FROM ".PREF."_template ");
$stmt->execute();
$fields = $stmt->fetchAll();
foreach ($fields as $row) {
    //echo "field:".$row['Field']." type:".$row['Type']."<br>";
    if ($row['Field'] == 'content_html') {
        $fieldType = $row['Type'];
    }
}
switch (substr($fieldType, 0 , 4)) {
    case "medi":
        $totalLength = 16777215;
        break;
    case "long":
        $totalLength = 4294967295;
        break;
    case "text":
    case "blob":
        $totalLength = 65535;
        break;
    case "varc":
        $fieldType = str_replace("varchar(", "", $fieldType);
        $fieldType = str_replace(")", "", $fieldType);
        $totalLength = (int) $fieldType;
        break;
    default:
        $totalLength = 0;
}

$x = 0;
$l = $x / $totalLength * 100;

?>
<input type="hidden" id="editor" value="<?php echo $editor;?>">

<div class="page-title">
    <div class="title_left">
        <h3><?php echo TEMPLATES_TITLE_EDIT;?> <small>(<?php echo TEMPLATES_TITLE_ADD;?>)</small></h3>
    </div>
</div>
<div class="clearfix"></div>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                    <h2><?php echo TEMPLATES_TITLE_ADD;?></h2>
                    <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <form class="form-horizontal" action="index.php?manage=templates&data=modify&action=insert" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $app->getToken();?>">
                    <input type="hidden" id="totalLength" value="<?php echo $totalLength;?>">
                    <div class="form-group">
                    <label for="name"><?php echo TEMPLATES_NAME;?>*</label>
                        <input 
                            type="text" 
                            class="form-control" 
                            id="name" 
                            name="name" 
                            placeholder="<?php echo TEMPLATES_NAME;?>"
                            required>
                    </div>
                    <div class="form-group">
                    <label for="subject"><?php echo TEMPLATES_MAIL_TITLE;?>*</label>
                        <input 
                            type="text" 
                            class="form-control" 
                            id="subject" 
                            name="subject" 
                            placeholder="<?php echo TEMPLATES_MAIL_TITLE_PLACEHOLDER;?>"
                            required>
                    </div>
                    <div class="form-group email_header_div">
                        <label for="content_txt" >HTML header <code>&lt;<input id="doctype" type="text" name="doctype" placeholder="!DOCTYPE here..." value='' pattern="[^']*$">&gt;&lt;heaad&gt;...&lt;/head&gt;</code></label>
                        <textarea id="header_html" name="html_header" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="content_html" ><?php echo TMPLATES_HTML;?><code>&lt;body <input id="body_attribs" type="text" name="body_attribs" placeholder="attribs here..." value='' pattern="[^']*$">&gt;...&lt;/body&gt;</code></label>
                        <?php if ($editor == 'tinymce') { ?>
                            <a id="disable_editor" class="btn btn-primary btn-xs pull-right hidden"><?php echo DISABLE_EDITOR;?></a>
                            <a id="enable_editor" class="btn btn-primary btn-xs pull-right hidden"><?php echo ENABLE_EDITOR;?></a>
                        <?php } ?>
                        <div id="percentageWrapper">
                            <p><?php echo TEMPLATE_STATISTICS;?> <?php echo TEMPLATE_CHARS;?>
                                <span id="chars"><?php echo $x;?></span> / <?php echo TEMPLATE_USAGE;?>
                                <span id="usage"><?php echo number_format($l, 2, ".", ".");?></span>%
                            </p>
                            <div style="width:<?php echo $l; ?>%;">
                            </div>
                        </div>
                        <textarea id="mailhtml" name="content_html" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="content_html" ><?php echo TMPLATES_VARIABLES;?></label>
                        <p>{RECIPIENT_NAME}, {RECIPIENT_NAME_1}, {RECIPIENT_NAME_2}, {RECIPIENT_NAME_3}, {RECIPIENT_EMAIL}, {RECIPIENT_DESCRIPTION}, {UNSUBSCRIBE}, {BROWSER_VIEW}, {CAMPAIGN_NAME}, {SENDER_NAME}, {SENDER_EMAIL}, {CURRENT_YEAR}, {CURRENT_MONTH}, {CURRENT_DAY}, {F0}, {F1}, {F2}, {F3}</p>
                    </div>
                    <div class="form-group">
                        <label for="content_txt" ><?php echo TMPLATES_TXT;?></label>
                        <textarea id="mailtxt" name="content_txt" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="tagsname" class="col-sm-2 control-label"><?php echo MEDIA_MANAGER;?></label>
                        <div class="col-sm-5">
                            <?php echo $files_option; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div>
                            <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-download"></i> <?php echo SAVE;?></button>
                            <span class="pull-right">&nbsp;</span>
                            <span class="pull-right">&nbsp;</span>
                            <span class="pull-right">&nbsp;</span>
                            <a class="btn btn-success pull-right" href="index.php?manage=templates&action=list"><i class="fa fa-frown-o"></i> <?php echo CANCEL;?></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<link href="libs/codemirror/codemirror.css" rel="stylesheet">
<script src="libs/codemirror/codemirror.js"></script>
<script src="libs/codemirror/xml.js"></script>
<script src="libs/tinymce/tinymce.min.js"></script>
<script src="components/templates/view.templates.js"></script>
