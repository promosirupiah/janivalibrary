/**
 * Set inline styles.
 *
 * @return {Object} The inline text color CSS.
 */
function TypographyStyles() {
	return {};
}

export default TypographyStyles;
