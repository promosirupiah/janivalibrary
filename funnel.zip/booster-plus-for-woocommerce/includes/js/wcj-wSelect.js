/**
 * wcj-wSelect.
 *
 * version 2.5.4
 * since   2.5.4
 */
jQuery('select#wcj-country').wSelect();
