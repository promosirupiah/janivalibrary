/**
 * wcj-fbt-script.
 *
 * @version 1.0.0
 */

//jQuery(document.body).on('change','.variations select',change_price);
//jQuery(document.body).on('change','input[name="wcj_variations"]',change_price);