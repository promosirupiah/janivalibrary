<?php
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_web_api.'&sources=web&Web.Count=6&query=' .urlencode($termstring); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Web->Results as $value) 
{ ?>
<div class ="post">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($value->Title)).'">'.CleanFileNameBan($value->Title).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=6&query=' .urlencode($value->Title); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>

<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($content->Title));?>"><img alt="<?php echo CleanFileNameBan($content->Title) ?>" src="<?php echo $content->MediaUrl; ?>"></a>


<?php } ?>
<br style="clear:both">
<?php echo $value->Description; ?>
<br style="clear:both">
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$value->Url ?>">read more</a>
</div> <?php //end div post class ?>
<?php } ?>