<div id="sidebar">
<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 160;
google_ad_height = 600;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php foreach ($categories as $category) { ?>
<li><a href="http://<?php echo $_SERVER["SERVER_NAME"] ?>/<?php echo ubah_tanda($category) ?>"><?php echo $category ?></a></li>
<?php } ?>
</div>
<div id="footer">
Powered by BING
</div>