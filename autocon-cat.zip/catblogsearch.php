
<?php define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');
require_once './magpie/rss_fetch.inc';

$url = 'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.urlencode($termstring).'&ie=utf-8&num=20&output=rss';
$rss = fetch_rss($url);
foreach ( $rss->items as $item ) { ?>
<div class="post">
<?php
echo '<h2><a href="http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($item['title'])).'">'.CleanFileNameBan($item['title']).'</a></h2>';
$request = 'http://api.search.live.net/json.aspx?Appid='.$bing_image_api.'&sources=image&Image.Count=4&query=' .urlencode($item['title']); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->SearchResponse->Image->Results as $content) 
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($content->Title));?>"><img alt="<?php echo CleanFileNameBan($content->Title);?>"src="<?php echo $content->MediaUrl; ?>"></a>

<?php } ?>
<?php
$request = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0&rsz=4&key='.$google_image_api.'&q=' .urlencode($item['title']); 
$response = pete_curl_get($request, array());
$jsonobj  = json_decode($response);
foreach((array)$jsonobj->responseData->results as $content)
{ ?>
<a href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/'.CleanFileNameBan(ubah_tanda($content->titleNoFormatting));?>"><img alt="<?php echo CleanFileNameBan($content->titleNoFormatting);?>"src="<?php echo $content->unescapedUrl; ?>"></a>

<?php } ?>
<?php
echo '<br style="clear:both"><p>'.$item['description'].'</p><br style="clear:both">';
?>
<a target=_blank rel="nofollow" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/goto.php?'.$item['link'] ?>">read more</a>
</div>
<?php } ?>


