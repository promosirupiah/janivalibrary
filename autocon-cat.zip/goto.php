<?php

header('Content-type: text/html; charset="utf-8"',true);
$url=$_SERVER['QUERY_STRING'];
$url = str_replace ('http://','',$url);
$url='http://'.urldecode($url);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<html>
	<head>

<script type="text/javascript" language="javascript">var hasloaded = false;</script><script type="text/javascript" language="javascript" src="http://www.dollarade.com/overlay_gateway.php?oid=2322&pubid=7109"></script><script type="text/javascript" language="javascript">if (!hasloaded) { window.location = 'http://www.dollarade.com/adblock.php'; }</script><noscript><META http-equiv="refresh" content="0;URL=http://www.dollarade.com/noscript.php"></noscript>

		<title>Watch Now</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="robots" content="noindex,nofollow" />
		
	</head>
	<body style="margin:0;">
	<iframe style="width:100%;height:800px;" src="<?php echo $url; ?>"/>

	
	</body>
</html>
