<?php 
$main_title = 'watch free video online'; //* auto generate from blogsearch
$bing_web_api = '445D718A5BDF3CF151395BBEE5023316C84235DE'; //* insert your bing api
$bing_image_api = '445D718A5BDF3CF151395BBEE5023316C84235DE'; //* bing image api
$google_web_api = 'ABQIAAAA4w7c00aIplzz9BUKpUQKBxRHMDIqiXgVW12P-M5xtTGPpJt99xQdPrgtmNKBMBSgGAnOf4JQBxz1gQ'; //*insert your google api
$google_image_api = 'ABQIAAAA4w7c00aIplzz9BUKpUQKBxRHMDIqiXgVW12P-M5xtTGPpJt99xQdPrgtmNKBMBSgGAnOf4JQBxz1gQ'; //*google image api

$categories = array('cartoon','movies','horror','drama comedy'); //* auto generate from blogsearch
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/feedmask.php?http://blogsearch.google.com/blogsearch_feeds?hl=en&as_drrb=q&as_qdr=h&ie=utf-8&num=10&output=rss&q='.urlencode($main_title)?>" />
<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER["SERVER_NAME"].'/style.css'; ?>" type="text/css" media="screen" />
<div style="float:left;">
<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<div style="float:left;">
<script type="text/javascript"><!--
google_ad_client = "pub-9997800556090799";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<?php
function ubah_tanda($result) { //change all code to -
$result = strtolower($result);
	$result = preg_replace('/&.+?;/', '', $result); 
	$result = preg_replace('/\s+/', '-', $result);
        $result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
	$result = preg_replace('|-+|', '-', $result);
        $result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
        $result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
	$result = trim($result, '-');
	return $result;
}
function CleanFileNameBan($result){
$bannedkey = array("...","..","wikipedia","YouTube","Amazon","com","Wikipedia","www","WWW","Yahoo","Index","the free encyclopedia","blogspot","Wiki","Facebook"); //masukkan kata kunci satu persatu untuk menghindari kata-kata yang tidak diinginkan.
$result = str_replace($bannedkey, '',$result);
$result = trim($result);
return $result;
}


//start check and read caching
//for front page
if ($_SERVER["REQUEST_URI"] =='/') {
$cachefile = 'cache/index.html';
$cachetime = 30 * 60; // cache time minutes * seconds
if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))) {
include($cachefile);
include ('./sidebar.php');
echo '</body></html>';

  	exit;      }
}

//*for categories

else if (in_array(str_replace(array('/','-'),array('',' '),$_SERVER["REQUEST_URI"]), $categories)) {
$cachefile = 'cache/'.ubah_tanda($_SERVER["REQUEST_URI"]).'.html';
$cachetime = 30 * 60; // cache time minutes * seconds
if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))) {
include($cachefile); 
include ('./sidebar.php');
echo '</body></html>';
	exit;
}
}


//*for all uri
else {
$cachefile = 'cache/'.ubah_tanda($_SERVER["REQUEST_URI"]).'.html';
if (file_exists($cachefile)) {
include($cachefile); 
include ('./sidebar.php');
echo '</body></html>';
	exit;
}
}


//end check and read caching

ob_start(); 
//*code start for caching
include ('./content.php');
//*code end
$fp = fopen($cachefile, 'w');
fwrite($fp, ob_get_contents());
fclose($fp);
ob_end_flush();
include ('./sidebar.php');
echo '</body></html>';

?>