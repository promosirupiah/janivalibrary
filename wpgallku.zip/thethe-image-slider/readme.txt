=== TheThe Image Slider ===
Contributors: thethefly
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=U2DR7CUBZLPFG
Tags: Gallery, Images, Pictures, Slider, Slideshow, jQuery, JavaScript
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.0.1

TheThe Image Slider WP plugin provides you with powerful, creative and versatile jQuery based image slider.

== Description ==

***TheThe Image Slider*** is a WordPress plug-in that provides you with one of the most powerful, the most creative and the most versatile of image sliders built using jQuery. This sleek Image Slider plug-in is great for all those who are looking for a quick and easy way to get their portfolio online. This rich yet simple to use plug-in can be implemented fast and looks amazing on any kind of WordPress website.

Today, image galleries, sliders and slideshows have become very popular within all kinds of websites - portfolio sites, business websites, game sites, etc. With jQuery and WordPress becoming increasingly popular among web developers, more and more website are using these amazing powerful, versatile and sleek tools to enhance the user experience, making viewing images more pleasant and intuitive.

**Benefits of TheThe Image Slider**

* **Enhanced User Experience**: With this JQuery based Image Slider plug-in, you can improve the quality of your image galleries and slideshows dramatically. The engaging top header image slider can not only attract your customers but can be used to keep your customers informed of the new offers and latest products and services.

* **Flexible Display and Pagination**: *TheThe Image Slider* has very flexible configuration including image resizing. It gives you the flexibility to put pagination of four styles into five pagination places, a full-fledged HTML based customizable image gallery with jQuery slideshow, transition, CSS skinning and fast image browsing options. You can even use HTML tags in the Caption area.

* **SEO Friendly Image Header**: Flash headers are not SEO friendly. Utilizing the power of jQuery, this *TheThe Image Slider* is meant to feature your products without harming the SEO of your website. Now you do not have to worry about getting a flash based header instead use *TheThe Image Slider* to feature your products right at the top of your website.

* **Quick Activation &amp; Ready to Use**: *TheThe Image Slider* plug-in can be installed and activated in seconds. With its quick shortcode and simple HTML mark up, you can configure *TheThe Image Slider* without any hassles. Its easy customization allows you to create a gallery style, just the way you want.

* **Pre-loaded Image Browsing**: *TheThe Image Slider* makes image browsing super fast and easy, supports image preloading with image cycling with transitioning effect. You can navigate the slides with multiple quick buttons like pause, play, back and forward.

* **Multiple Animation Options**: Now you can add effects to your image gallery with tens animation effects including Slide, Fade and Flip. It has directional, keyboard, and touch swipe navigation which is extremely useful and makes your website even more user-friendly.

* **Highly Compatible**: *TheThe Image Slider* supports all kinds of browsers including Safari 4+, Chrome 4+, Firefox 3.6+, Opera 10+, and IE7+. It also supports mobile devices like iOS and Android phones. It does offer graceful degradation in case JavaScript is not available.

*TheThe Image Slider* is an awesome, lightweight and easy-to-use jQuery plug-in for creating attractive image sliders and displaying photos as a slideshow with fancy transition effects on your website.

Install this WordPress plug-in today for a matchless user experience on your website with a wonderful image gallery right at the top!


**Features**

  	* Activation with shortcode.
  	* Simple, semantic HTML markup.
  	* Goes with multiple pre-designed CSS skins.
  	* Easy style customization – create your own gallery style.
  	* Very flexible configuration including image resizing.
  	* Super fast image browsing since the images are preloaded one at a time in the background.
  	* Slide navigation controls allow for pause/play and forward/back.
  	* 4 pagination styles: dots, numbers, thumbs, slide names.
  	* 5 pagination places: top right, top left, bottom right, bottom left, underneath.
  	* Tens animation effects including Slide, Fade, Flip.
  	* Support for multiple galleries per page.
  	* Supported in Safari 4+, Chrome 4+, Firefox 3.6+, Opera 10+, and IE7+.
  	* Supported on mobile devices ( iOS and Android ).
  	* You can use many HTML tags in the Caption area.
  	* Graceful degradation when Javascript is not available.
  	* Free to use under the GNU GPL license.

== Installation ==

1. Download the zip file containing the plugin using the 'Download' link on this page.
2. Extract the contents of the zip file and upload them into the wp-content/plugins directory of your WordPress installation.
3. Activate the 'TheThe Image Slider' plugin via the 'Plugins' page of your WordPress Admin Dashboard.
4. Open the plugin configuration page, which is located under TheThe Fly -> Image Slider and manage your panels.

== Frequently Asked Questions ==


== Screenshots ==

1. Image Slider Screenshot 1
2. Image Slider Screenshot 2
3. Image Slider Screenshot 3
4. Image Slider Screenshot 4	
5. Image Slider Screenshot 5
6. Image Slider Admin Panel Screenshot - Sliders and Slides Page
7. Image Slider Admin Panel Screenshot - Edit Slide Page 
8. Image Slider Admin Panel Screenshot - Edit Slider Page

== Changelog ==

= 1.0.1 =
* TimThumb library update.