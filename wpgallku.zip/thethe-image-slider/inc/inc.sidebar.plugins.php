<?php /** @version $Id: inc.sidebar.plugins.php 943 2011-08-17 14:00:17Z lexx-ua $ */ ?>
<div class="help-res postbox">
  <div class="handlediv" title="<?php _e( 'Click to toggle' ); ?>"><br />
  </div>
  <h3 class="hndle"> <span>WP Plugins by TheThe Fly</span> </h3>
  <div class="inside">
    <ul class="cols-2">
      <li><a href="http://thethefly.com/wp-plugins/affiliate-unique-article-feeder/" target="_blank">AUA Feeder</a></li>
      <li><a href="http://thethefly.com/wp-plugins/thethe-tabs-and-accordions/" target="_blank"><strong>Tabs &amp; Accordions</strong></a></li>
      <li><a href="http://thethefly.com/wp-plugins/thethe-site-exit-manager/" target="_blank">Site Exit Manager</a></li>
      <li><a href="http://thethefly.com/wp-plugins/thethe-sliding-panels/" target="_blank"><strong>Sliding Panels</strong></a></li>
      <li><a href="http://thethefly.com/wp-plugins/thethe-image-slider/" target="_blank"><strong>Image Slider</strong></a></li>
      <li><a href="http://thethefly.com/wp-plugins/thethe-carousel/" target="_blank">Carousel</a></li>
      <li><a href="http://thethefly.com/wp-plugins/thethe-marquee/" target="_blank">Marquee</a></li>
    </ul>
  </div>
</div>
