<?php /** @version $Id: inc.sidebar.thethe-help.php 943 2011-08-17 14:00:17Z lexx-ua $ */ ?>
<div class="help-res postbox">
  <div class="handlediv" title="<?php _e( 'Click to toggle' ); ?>"><br />
  </div>
  <h3 class="hndle"> <span>Help by TheThe Fly</span> </h3>
  <div class="inside">
    <ul class="cols-2">
      <li><a href="http://thethefly.com/documents/" target="_blank" >Documentations</a></li>
      <li><a href='http://thethefly.com/support/forum/' target="_blank" >Support Forum</a></li>
    </ul>
  </div>
</div>