<?php /** @version $Id: inc.sidebar.donate.php 943 2011-08-17 14:00:17Z lexx-ua $ */ ?>
<div class="postbox">
  <div class="handlediv" title="<?php _e( 'Click to toggle' ); ?>"><br /></div>
  <h3 class="hndle"> <span>Like this FREE plugin?</span> </h3>
  <div class="inside">
    <p>Please support its further development:</p>
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
      <input type="hidden" name="cmd" value="_s-xclick" />
      <input type="hidden" name="hosted_button_id" value="U2DR7CUBZLPFG" />
      <p align="right"><input type="submit" value="Donate" name="submit" class="button-primary" /></p>
      <img alt="" border="0" src="https://www.paypalobjects.com/WEBSCR-640-20110401-1/en_US/i/scr/pixel.gif" width="1" height="1" />
    </form>
  </div>
</div>