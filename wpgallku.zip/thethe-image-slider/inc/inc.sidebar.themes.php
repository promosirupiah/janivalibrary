<?php /** @version $Id: inc.sidebar.themes.php 972 2011-08-25 18:31:32Z lexx-ua $ */ ?>

<div class="thethe-themes postbox">
  <div class="handlediv" title="<?php _e( 'Click to toggle' ); ?>"><br />
  </div>
  <h3 class="hndle"> <span>WP Themes by TheThe Fly</span> </h3>
  <div class="inside">
    <p align="center"><a href="http://demo.thethefly.com?theme=elegance"  target="_blank" title="Click here to view TheThe Elegance theme live demo!"><img style="border: 1px solid #666; padding:2px;" width="120" border="1" height="" src="http://elegance.demo.thethefly.com/wp-content/themes/thethe-elegance/screenshot.png" alt="TheThe Elegance" title="Click here to view TheThe Elegance theme live demo!" /></a> <a href="http://demo.thethefly.com?theme=marketing"target="_blank" title="Click here to view TheThe Marketing theme live demo!"><img style="border: 1px solid #666; padding:2px;" width="120" border="1" height="" src="http://marketing.demo.thethefly.com/wp-content/themes/thethe-marketing/screenshot.png" alt="TheThe Marketing" title="Click here to view TheThe Marketing theme live demo!" /></a> <a href="http://demo.thethefly.com?theme=portfolio"target="_blank" title="Click here to view TheThe Portfolio theme live demo!"><img style="border: 1px solid #666; padding:2px;" width="120" border="1" height="" src="http://portfolio.demo.thethefly.com/wp-content/themes/thethe-portfolio-child/screenshot.png" alt="TheThe Portfolio" title="Click here to view TheThe Portfolio theme live demo!" /></a> <a href="http://demo.thethefly.com?theme=mini"target="_blank" title="Click here to view TheThe Mini theme live demo!"><img style="border: 1px solid #666; padding:2px;" width="120" border="1" height="" src="http://mini.demo.thethefly.com/wp-content/themes/thethe-mini/screenshot.png" alt="TheThe Mini" title="Click here to view TheThe Mini theme live demo!" /></a> </p>
    <p> <a href="http://demo.thethefly.com/" target="_blank">Themes Live Demo</a> </p>
  </div>
</div>
