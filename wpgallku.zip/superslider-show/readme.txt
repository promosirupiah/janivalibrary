=== SuperSlider-Show ===
Contributors: Daiv Mowbray
Plugin URI: http://wp-superslider.com/
Tags:animation, animated, gallery, slideshow, mootools 1.2, mootools, slider, superslider, slideshow2
Requires at least: 2.6
Tested up to: 2.8.2
Stable tag: 2.0

Animated Gallery slideshow uses Mootools 1.2 javascript replaces wordpress gallery with a slideshow. 


== Description ==

SuperSlider-Show is your Animated show plugin that uses [Mootools](http://mootools.net/ "Your favorite javascript framework") 1.2 javascript to replace your gallery with a Slideshow. Highly configurable, theme based design, css based animations, auto minithumbnail creation. Shortcode system on post and page screens to make each slideshow unique. Built upon [Slideshow2](http://www.electricprism.com/aeron/slideshow/ "Your favorite slideshow"). Degrades gracefully with javascript turned off, or plugin removed / disabled.
Compatible with WordPress system default gallery shows. New Features v1.8: improved lightbox actions, pull images from folder. 

**credits:**

* mootools - [Mootools](http://mootools.net/ "Your favorite javascript framework")
* slideshow2 - [Slideshow2](http://www.electricprism.com/aeron/slideshow/ "Your favorite slideshow")
* squeezebox - Harald Kirschner [digitarald.de](http://www.digitarald.de "digitarald.de")
* slimbox - Christophe Beyls [digitarald.de](http://www.digitarald.de "digitarald.de")


**Support**

If you have any problems or suggestions regarding this plugin [please speak up](http://support.wp-superslider.com/forum/superslider-show "support forum")

**Other Plugins**
Download These SuperSlider Plugins here:

* [SuperSlider](http://wordpress.org/extend/plugins/superslider/ "SuperSlider")
* [Superslider-PostsinCat](http://wordpress.org/extend/plugins/superslider-postsincat/ "Superslider-PostsinCat")
* [SuperSlider-MooFlow](http://wordpress.org/extend/plugins/superslider-mooflow/ "SuperSlider-MooFlow")
* [SuperSlider-Menu](http://wordpress.org/extend/plugins/superslider-menu/ "SuperSlider-Menu")

**NOTICE**

* The downloaded folder's name should be superslider-show
* Also available for [download from here](http://wp-superslider.com/downloadsuperslider/superslider-show-download "superslider-show plugin home page").
* Probably not compatible with plugins which use jquery. (not tested)


**Features**

* complete global control from options page
* full short code over ride per show
* pull images from any post/page to any post/page
* Endless image animation/transition possibilities
* Control transition time, image display time.
* Animated controller
* Animated captions
* Link each image to lightbox or attachment or parent
* Link whole show to any destination
* Uses WordPress native media / images

**Demos**

This plugin can be seen in use here:

* [Demo 1](http://wp-superslider.com/wp-plugins/superslider-show/slideshow-demo-1 "Demo")
* [Demo 2](http://wp-superslider.com/wp-plugins/superslider-show/slideshow-demo-2 "Demo")
* [Demo 3](http://wp-superslider.com/wp-plugins/superslider-show/slideshow-demo-3 "Demo")
* [Demo 4](http://wp-superslider.com/wp-plugins/superslider-show/slideshow-demo-4 "Demo")

== Screenshots ==

1. ![SlideShow sample](screenshot-1.png "SlideShow sample")
2. ![SuperSlider-Show options screen](screenshot-2.png "SuperSlider-Show options screen")
3. ![SuperSlider-Show MetaBox on post screen](screenshot-3.png "SuperSlider-Show MetaBox screen")

== Installation ==

* Unpack contents to wp-content/plugins/ into a **superslider-show** directory
* Activate the plugin,
* Configure global settings for plugin under > settings > SuperSlider-Show
* Create post/page ,Add WordPress gallery shortcode, or slideshow shortcode.
* (optional) move SuperSlider-Show plugin sub folder plugin-data to your wp-content folder,
	under  > settings > SuperSlider-Show > option group, File Storage - Loading Options
	select "Load css from plugin-data folder, see side note. (Recommended)". This will
	prevent plugin uploads from over writing any css changes you may have made.

== USAGE ==

If you are not sure how this plugin works you may want to read the following.

* First ensure that you have uploaded all of the plugin files into wp-content/plugins/superslider-show folder.
* Go to your WordPress admin panel and stop in to the plugins control page. Activate the SuperSlider-Show plugin.
* Create a new post, use the WordPress built in media uploader, (upload some images).
* Click on insert gallery from the media uploader popover panel.
* you should now have the shortcode [gallery] in your post.
* Publish your new post

You should be able to view your new slide show in the new post.
You can adjust how the slide show looks and works by making adjustments in the plugin settings page. (SuperSlider-Show).

== OPTIONS AND CONFIGURATIONS ==

Available under > settings > SuperSlider-Show

* theme css files to use
* shortcode tag to use (gallery or slideshow)
* post id to pull images from (if not actual post)
* transition type
* transition speed
* display time
* lightbox on images on or off
* to load or not Mootools.js
* css files storage loaction
* **many more Advanced options**

----------
Available in the shortcode tag:

* id ="any comma separated list of post ids"
* show_class="family"
* first_slide="0"
* href="www.yourcooldoiman.com"
* show_type="kenburns/push/fold/default"
* height="400"
* width="200"
* transition="elastic:In:Out"
* thumbnails="true"
* image_size="thumbnail/medium/large/full"
* delay="milliseconds"
* duration="milliseconds"
* center="true"
* resize="true"
* overlap="true"
* random="true"
* loop="true"
* linked="true"
* fast="true"
* captions="true"
* controller="true"
* paused ="true"
* exclude = "any comma separated list of images"


== Themes ==

Create your own graphic and animation theme based on one of these provided.

**Available themes**

* default (Thumbs set to 150px x 150px)
* blue (Thumbs set to 50px x 50px)
* black (Thumbs set to 150px x 150px)
* custom (Thumbs set to 150px x 150px vertical right side )

== To Do ==

* Fix multi item popover lightbox
				

== Report Bugs Request / Options / Functions ==

* Please use the support system at http://support.wp-superslider.com
* Or post to the wordpress forums

== Frequently Asked Questions ==	

**Why isn't my slideshow working?**

>*You first need to check that your web site page isn't loading more than 1 copy of mootools javascript into the head of your file.
>*While reading the source code of your website files header look to see if another plugin is using jquery. This will cause a javascript conflict. Jquery and mootools are not compatible.

**How do I change the style of the slideshow?**
  
>I recommend that you move the folder plugin-data to your wp-content folder if you already have a plugin-data folder there, just move the superslider folder. Remember to change the css location option in the settings page for this plugin. Or edit directly: **wp-content/plugins/superslider-show/plugin-data/superslider/ssshow/custom.css** Alternatively, you can copy those rules into your WordPress themes, style file. Then remember to change the css location option in the settings page for this plugin.
  

**The stylesheet doesn't seem to be having any effect? **
 
>Check this url in your browser:
>http://yourblogaddress/wp-content/plugins/superslider-show/plugin-data/superslider/ssShow/custom.css
>If you don't see a plaintext file with css style rules, there may be something wrong with your .htaccess file (mod_rewrite). If you don't know how to fix this, you can copy the style rules there into your themes style file.

**How do I use different graphics and symbols for collapsing and expanding? **

>You can upload your own images to
>http://yourblogaddress/wp-content/plugins/superslider-show/plugin-data/superslider/ssShow/img_custom


== CAVEAT ==

Currently this plugin relies on Javascript to create the slide show.
If a user's browser doesn't support javascript the gallery will display normally.

== HISTORY ==

* 2.0 (2009/07/15)

  * Added custom thumb extension option for the fromfolder option
  * Added option to change controller activation keys
  * Added option for properties list, ie: 'href', 'rel', 'rev', 'title'
  * Updated mootools to 1.2.3 

* 1.9 (2009/07/25)
    
  * Upgraded to slideshow2!r147

* 1.8 (2009/06/05)

  * Added the From Folder option - pulls all images from a defined folder.
  * Added caption, close button to base lightbox popover.
  * Fixed minithumb creation options, size and crop now work.
  * Added Custom Slideshow image creation and options for WP-system image upload.
  * Major organization changes to the options page.(added tabs)
  * Minor organization changes to the options page.
  * Squeezebox popover now stops and starts slideshow when opened/closed.
  * Slimbox pop over now requires the SuperSlider-slimbox plugin.
  * Slimbox popover, next and previous image links now work - sort of.
  * upgraded the slideshow2 script to Slideshow2r147

* 1.7 (2009/02/14)
	
  * Added Thumbnail creation 
  * Added Thumbnail use which size option

* 1.6 (2009/02/10) no public launch
	
  * Added popover image size option
  * Added slimbox popover module
  * Added squeezebox popover module
  * Fixed the script enqueue 
  * Removed the milkbox module
	
* 1.5 (2009/02/03)
	
  * Added insert at cursor for the shortcode metabox
	
* 1.4 (2009/01/15)
	
  * fixed shortcode array issue
	
* 1.3 (2009/01/15)
	
  * added thumbnail frame option
  * integrated with SuperSlider-Base
  * fixed 50+ php warnings

* 1.2 (2008/12/19)
	
  * added link each image to lightbox or attachment or parent
  * added Link whole show to any destination
  * added exclude images option
  * made script php4 compatible
  * improved the metabox layout (insert shortcode)
  * added shortcode option, color list for flash transition
		(comma separated list of hex colors)

* 1.1 (2008/12/11)
	
  * added meta box to post and page screens for easy shortcode entry
  * improved php coding
	
* 1.0 rc (2008/12/04)
	
  * fixed shortcode transition type
  * fixed no thumbs option

* 0.7.0_beta (2008/12/01)
	
  * fixed lightbox pop over (works with built in lightbox)
  * changed the theme structure to be easier to grow.
  * added more options to the image resize option

* 0.6.0_beta (2008/12/01)
	
  * added full short code support
  * added multiple shows per page/post
  * more code refinement

* 0.3.0_beta (2008/11/15)
	
  * reduced database calls
  * cleaned code

* 0.1.0_beta (2008/10/26)

    * first public launch

---------------------------------------------------------------------------