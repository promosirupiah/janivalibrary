<?php
/*
Plugin Name: SuperSlider-Show
Plugin URI: http://wp-superslider.com/superslider-show
Description: Animated Gallery slideshow uses Mootools 1.2 javascript and Slideshow2 to replace wordpress gallery with a slideshow. 
Author: Daiv Mowbray
Version: 2.0
Author URI: http://wp-superslider.com
Tags: animation, animated, gallery, slideshow, mootools 1.2, mootools, slider, superslider

credits:
squeezebox - Harald Kirschner <http://www.digitarald.de>
slimbox - Christophe Beyls <http://www.digitalia.be>

Copyright 2008
       SuperSlider-Show is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as published by 
    the Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    SuperSlider-show is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Collapsing Categories; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

if (!class_exists("ssShow")) {
	class ssShow {
		
		/**
		* @var names used in this class.
		*/
	var $js_path;
	var $kenburns_js = '';
	var $push_js = '';
	var $flash_js = '';
	var $fold_js = '';	
	var $shrink_js = '';
	var $Slim_over_ride ;
	var $shortcode_showtype;
	var $ssShowOpOut;	
	var $defaultAdminOptions;
	var $AdminOptionsName = 'ssShow_options';
	var $ssBaseOpOut;
	var $ssShow_domain = 'superslider-show';

	// get a number to make the slideshow unique
	var $show_id;

		/**
		* PHP 4 Compatible Constructor
		*/
	function ssShow() {	//$this->__construct();
			
		ssShow::superslider_show();

		}
				
		/**
		* PHP 5 Constructor
		*/		
	function __construct(){
		
		self::superslider_show();
	
	}
	
		/**
		*	Pre-2.6 compatibility
		*/
	function set_show_paths()
	{
		if ( !defined( 'WP_CONTENT_URL' ) )
			define( 'WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );
		if ( !defined( 'WP_CONTENT_DIR' ) )
			define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
		if ( !defined( 'WP_PLUGIN_URL' ) )
			define( 'WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );
		if ( !defined( 'WP_PLUGIN_DIR' ) )
			define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );
		if ( !defined( 'WP_LANG_DIR') )
			define( 'WP_LANG_DIR', WP_CONTENT_DIR . '/languages' );
	}
	
		/**
		 * language switcher
		 */
	function language_switcher(){
		global $ssShow_domain, $ssShow_is_setup;

  				if ( $ssShow_is_setup) {
     				return;
  				} 
  			// define some language related variables
		$ssShow_domain = 'superslider-show';
  		$ss_show_locale = get_locale();
		$ss_show_mofile = WP_LANG_DIR."/superslider_show-".$ss_show_locale.".mo";
  				//load the language
  			load_plugin_textdomain($ssShow_domain, $ss_show_mofile);
  			$plugin_text_loaded = true; // language is loaded
	}
	
			/**
		* Retrieves the options from the database.
		* @return array
		*/			
	function set_default_admin_options() {
		global $defaultAdminOptions; 
		
		$defaultAdminOptions = array(
				'ss_shortcode' => "gallery",
				'show_shortcode' => "true",	
				'id' => "",
				'load_moo' => "on",
				'css_load' => "default",		
				'css_theme' => "default",
				'show_class' => "",
				'href'	=>	"",
				'show_type' => "default",
				'image_size' => "medium",
				'pop_size'	=>	"large",
				'first_slide' => "0",
				'zoom' => "25",
				'pan' => "25, 75",
				'color' => "#fff",
				'height' => "400",
				'width' => "450",
				'clear'	=>	"both",
				'center' => "true",
				'resize' => "true",
				'linked' => "lightbox",
				'fast' => "false",
				'captions' => "true",
				'overlap' => "true",
				'thumbnails' => "true",
				'thumbframe' => "on",
				'mouseover'	=> "false",
				'mythumbon' => "on",
				'thumbsize' => "thumbnail",
				'mythumb_height' => "80",
				'mythumb_width' => "80",
				'thumbcrop' => "on",
				'myslide_height' => "360",
				'myslide_width' => "480",
				'myslide_crop' => "off",
				'paused' => "false",
				'random' => "false",
				'loop' => "true",
				'loader' => "true",
				'delay' => "4000",
				'controller' => "true",
				'exclude'	=> "",
				'duration' => "1200",
				'trans_type' => "sine",
				'trans_inout' => "out",
				
				'accesskeys'=> "",//'first': 'shift + left', 'prev': 'left', 'pause': 'p', 'next': 'right', 'last': 'shift + right' 
				'properties' => "",//'href', 'rel', 'rev', 'title'
				'preload' => 'false',
				'replace' => "",
				
				'tool_tips' => "true",
				'lightbox_add' => "on",
				'squeeze_width' => "600",
				'squeeze_height' => "450",
				'lightbox_type' => "Lightbox");
		
		$defaultOptions = get_option($this->AdminOptionsName);
		if (!empty($defaultOptions)) {
			foreach ($defaultOptions as $key => $option) {
				$defaultAdminOptions[$key] = $option;
			}
		}
		update_option($this->AdminOptionsName, $defaultAdminOptions);
		return $defaultAdminOptions;
		
	}

		/**
		* Saves the admin options to the database.
		*/
	function save_default_show_options(){
		update_option($this->AdminOptionsName, $this->defaultAdminOptions);
	}
		
		/**
		* load default options into data base
		*/		
	function ssShow_init() {

		$this->set_show_paths();
		$this->defaultAdminOptions = $this->set_default_admin_options();			
		
		// lets see if the base plugin is here and get its options
		if (class_exists('ssBase')) {
				$this->ssBaseOpOut = get_option('ssBase_options');
				extract($this->ssBaseOpOut);
				$this->base_over_ride = $ss_global_over_ride;
			}else{
			$this->base_over_ride = 'false';
			}
			
			if (class_exists('ssSlim')) {
				$this->Slim_over_ride = 'true';
			}else{
				$this->Slim_over_ride = 'false';
			}
			
		$this->js_path = WP_CONTENT_URL . '/plugins/'. plugin_basename(dirname(__FILE__)) . '/js/';
  			
  			wp_register_script(
			'moocore',
			$this->js_path.'mootools-1.2.3-core-yc.js',
			NULL, '1.2.3');
			
			wp_register_script(
			'moomore',
			$this->js_path. 'mootools-1.2.3.1-more.js',
			array( 'moocore' ), '1.2.3');
					
			wp_register_script(
			'slideshow',
			$this->js_path. 'slideshow.js',
			array( 'moocore' ), '2');
			
			wp_register_script(
			'squeezebox',
			$this->js_path.'squeezebox.js',
			array( 'moocore' ), '2');
			
			wp_register_script(
			'slimbox',
			$this->js_path.'slimbox.js',
			array( 'moocore' ), '2');
			
			wp_register_script(
			'lightbox',
			$this->js_path.'lightbox.js',
			array( 'moocore' ), '2');
	
	}		
		/**
		* Load admin options page
		*/
	function ssShow_ui() {		
		global $base_over_ride;
		global $ssShow_domain;
		
		include_once 'admin/superslider-show-ui.php';
		
	}

		/**
		* Initialize the admin panel, Add the plugin options page, loading it in from superslider-show-ui.php
		*/
	function ssShow_setup_optionspage() {
		if (  function_exists('add_options_page') ) {
			if (  current_user_can('manage_options') ) {
				$plugin_page = add_options_page(__('SuperSlider Show'),__('SuperSlider-Show'), 8, 'superslider-show', array(&$this, 'ssShow_ui'));
				add_filter('plugin_action_links', array(&$this, 'filter_plugin_show'), 10, 2 );
				
				add_action('admin_print_styles', array(&$this,'ssShow_admin_style'));

				add_action('admin_print_scripts-'.$plugin_page, array(&$this,'ssshow_admin_script'));
			}					
		}
	}
		/**
		* Add link to options page from plugin list WP 2.6.
		*/
	function filter_plugin_show($links, $file) {
		 static $this_plugin;
			if (  ! $this_plugin ) $this_plugin = plugin_basename(__FILE__);

		if (  $file == $this_plugin )
			$settings_link = '<a href="options-general.php?page=superslider-show">'.__('Settings').'</a>';
			array_unshift( $links, $settings_link ); //  before other links
			return $links;
	}
	
		/**
		* Removes user set options from data base upon deactivation
		*/
		
	function options_deactivation(){
		delete_option($this->AdminOptionsName);
	}

	function ssShow_add_javascript(){
	
		extract($this->ssShowOpOut);

		$lightbox_type = strtolower($lightbox_type);
		
		$this->kenburns_js = "\t".'<script src="'.$this->js_path.'slideshow.kenburns.js" type="text/javascript"></script> '."\n";
		$this->push_js = "\t".'<script src="'.$this->js_path.'slideshow.push.js" type="text/javascript"></script> '."\n";
		$this->fold_js = "\t".'<script src="'.$this->js_path.'slideshow.fold.js" type="text/javascript"></script> '."\n";
		$this->flash_js = "\t".'<script src="'.$this->js_path.'slideshow.flash.js" type="text/javascript"></script> '."\n";
		$this->shrink_js = "\t".'<script src="'.$this->js_path.'slideshow.shrink.js" type="text/javascript"></script> '."\n";
		$this->lightbox_js = "\t".'<script src="'.$this->js_path.''.$lightbox_type.'.js" type="text/javascript"></script> '."\n";
		wp_register_script('kenburns', $this->js_path.'slideshow.kenburns.js', array( 'slideshow' ), '2');
		wp_register_script('push', $this->js_path.'slideshow.push.js', array( 'slideshow' ), '2');
		wp_register_script('fold', $this->js_path.'slideshow.fold.js', array( 'slideshow' ), '2');
		wp_register_script('flash', $this->js_path.'slideshow.flash.js', array( 'slideshow' ), '2');
		wp_register_script('shrink', $this->js_path.'slideshow.shrink.js', array( 'slideshow' ), '2');
		
		wp_register_script('lightbox', $this->js_path.$lightbox_type.'.js', array( 'moocore' ), '2');
		
		if (!is_admin()) {				
			if (function_exists('wp_enqueue_script')) {
				if ($this->base_over_ride != "on") {
					if ($load_moo == 'on'){
						wp_enqueue_script('moocore');		
						wp_enqueue_script('moomore');	
					}
				}
			}
				
		wp_enqueue_script('slideshow');	
		
		if ($show_type == 'kenburns')	wp_enqueue_script('kenburns');	//echo $kenburns_js;	
		elseif ($show_type == 'push')	wp_enqueue_script('push');	//echo $push_js;
		elseif ($show_type == 'fold')	wp_enqueue_script('fold');	//echo $fold_js;	
		elseif ($show_type == 'flash') 	wp_enqueue_script('flash');	//echo $flash_js;		
		elseif ($show_type == 'shrink') wp_enqueue_script('slideshow');	//echo $shrink_js;
		
		// add the lightbox if needed
		if ($lightbox_add == 'on')	wp_enqueue_script(strtolower($lightbox_type));				
					
		}// is not admin
	}
		/**
		* register and Add css script into head 
		*/
	function ssShow_add_css(){
		
		// $css_transition = "echo_zoom_in"; 
		extract($this->ssShowOpOut);

		if (class_exists('ssBase')) { extract($this->ssBaseOpOut); }	
		
		/* Need to confirm that over ride in base is true 
		if $this->ssBaseOpOut[override] == true , then extract
		apply to other plugins*/
		
		$lightbox_type = strtolower($lightbox_type);
		//$url = get_option('siteurl');

   		if ($css_load == 'default'){
    			$cssPath = WP_PLUGIN_URL.'/superslider-show/plugin-data/superslider/ssShow/'.$css_theme.'/'.$css_theme.'.css';
    		//	$cssTrans = WP_PLUGIN_URL.'/superslider-show/plugin-data/superslider/ssShow/transitions/slideshow_'.$css_transition.'.css';
    			$lightPath = WP_PLUGIN_URL.'/superslider-show/plugin-data/superslider/ssShow/'.$lightbox_type.'/'.$lightbox_type.'.css';

    	}elseif ($css_load == 'pluginData') {
    			$cssPath = WP_CONTENT_URL.'/plugin-data/superslider/ssShow/'.$css_theme.'/'.$css_theme.'.css';
    			$lightPath = WP_CONTENT_URL.'/plugin-data/superslider/ssShow/'.$lightbox_type.'/'.$lightbox_type.'.css';

    	}elseif ($css_load == 'off') {
    			$cssPath = '';
    	}   
    	if ($css_load !== 'off'){
			echo "\t"."<link type='text/css' rel='stylesheet' rev='stylesheet' href='".$cssPath."' media='screen' />\n";
			if ( $show_type =="default" )
			echo "\t"."<link type='text/css' rel='stylesheet' rev='stylesheet' href='".$cssTrans."' media='screen' />\n";
			
			if ($this->Slim_over_ride != "true") {
				if ($lightbox_add == 'on'){					
					echo "\t"."<link type='text/css' rel='stylesheet' rev='stylesheet' href='".$lightPath."' media='screen' />\n";	
				}
			}
		}
	}
	
		/**
		* Write the slideshow code 
		*/
	function ssShow_set_show($atts,$id) {
		
		extract($this->ssShowOpOut);
		
			if (array_key_exists('transition', $atts) && ( $atts['transition'] != '')) {
				$transition = $atts['transition'];
				} else {
				$transition = $trans_type.':'.$trans_inout;	
			}

		//set the path for the loader graphics
		if ($css_load == 'default' || $css_load == 'off') {
			$loaderPath = WP_PLUGIN_URL.'/superslider-show/plugin-data/superslider/ssShow/loader/loader-#.png';
		}elseif ($css_load == 'pluginData') {
			$loaderPath = WP_CONTENT_URL.'/plugin-data/superslider/ssShow/loader/loader-#.png';
		}
		
		// give the show a name and number
		$showName = "this.el = $('slide_gallery".$this->show_id."');";
		
		if ( $accesskeys !== '' ) $myaccesskeys = "accesskeys: {".stripslashes($accesskeys)." },";
		if ( $properties !== '' ) $myproperties = "properties: [".stripslashes($properties)."],";
		$mypreload = "preload:".$preload.",";
		if ( $replace !== '' ) $myreplace = "replace:[/(\.[^\.]+)$/, '".$replace."$1'],";
		
		// Create the lightbox binders
		if ($linked == 'lightbox') {
				if ($lightbox_type == 'SqueezeBox') {
					$mylightbox = 'SqueezeBox.initialize({
									size: {x: '.$squeeze_width.', y: '.$squeeze_height.'},
									sizeLoading: {x: 150, y: 150},
									marginInner: {x: 18, y: 18},
									closeBtn: true,
									overlayOpacity: 0.6,
									resizeFx: {transition: Fx.Transitions.Sine.easeIn},
									contentFx: {transition: Fx.Transitions.Sine.easeOut},
									onOpen: function(){ ssShow'.$this->show_id.'.pause(1); }.bind(window.ssShow'.$this->show_id.'), 
						  			onClose: function(){ ssShow'.$this->show_id.'.pause(0); }.bind(window.ssShow'.$this->show_id.')						
									});
									SqueezeBox.assign($$(\'a[rel=squeezebox:ssShow'.$id.']\'));
									';				
				} else if ($lightbox_type == 'Slimbox'){
				
				add_action ( "wp_footer", array(&$this,"slimbox_linker"));
					$mylightbox = '';
								
				} else {
					$mylightbox = 'var popbox = new '.$lightbox_type.'({ 

						   	onOpen : function(){ this.pause(1); }.bind(ssShow'.$this->show_id.'), 
						  	onClose : function(){ this.pause(0); }.bind(ssShow'.$this->show_id.'),
						  	initialWidth : 50,
							initialHeight : 50,
							showControls : true,
							showNumbers : true,
							descriptions : true
						});';
				}
		}else { $mylightbox = '';
		}
			
		// Add mouseover image stop function
		if ($mouseover == 'true') {
			$mymouse = '
			ssShow'.$this->show_id.'.slideshow.retrieve(\'images\').addEvents({
			  \'mouseenter\': function(){ this.pause(1); }.bind(ssShow'.$this->show_id.'),
			  \'mouseleave\': function() { this.pause(0); }.bind(ssShow'.$this->show_id.')			
			});
			';
		}else { $mymouse = '';}

		// transfer options into objects before constructing the slideshow js call.
		
		if ($thumbnails == 'true') {
			$mythumb = 'fast: '.$fast.',
			thumbnails: { scroll: \'x\', duration: 700, transition: Fx.Transitions.Circ.easeOut},';
				if ( $thumbframe == 'on') {
					$mythumb .= 'thumbframe: true,';
				}else { $mythumb .= 'thumbframe: false,'; }
			$mythumbcover = "['a', 'b'].each(function(p){ 
						  new Element('div', { 'class': 'overlay ' + p }).inject(ssShow".$this->show_id.".slideshow.retrieve('thumbnails'));
				  		}, this);";
			} else{
			$mythumb = 'fast: false,
			thumbnails: false, 
			thumbframe: false,';
			}
		if ($controller == 'true') {
			$mycontroller = 'controller: {duration: 1300, transition: Fx.Transitions.Sine.easeOut},';
			}
		if ($loader == 'true') {
			$myloader = 'loader: { duration: 700, transition: Fx.Transitions.Sine.easeOut, \'animate\': [\''.$loaderPath.'\', 12] },';
			}
		if ($captions == 'true') {
			$mycaptions = 'captions: {duration: 700, transition: Fx.Transitions.Sine.easeOut},';
			}
		
		if (!$height == '') $myheight = 'height:'.$height.',';
		if (!$width == '') $mywidth = 'width:'.$width.',';
		
		if ($linked !== 'false') $mylinked = 'true'; else $mylinked = 'false' ;
		
		if ($show_type == 'kenburns'){
			$mynewjs = $this->kenburns_js;
			$new_type = 'Slideshow.KenBurns';			
			if (strpos($zoom, ',')) $zoom = ('['.$zoom.']');
			if (strpos($pan, ',')) $pan = '['.$pan.']';
			$type_ops = 'zoom: '.$zoom.', pan: '.$pan;			
			}
		elseif ($show_type == 'push'){
			$mynewjs = $this->push_js;
			$new_type = 'Slideshow.Push';
			$type_ops = "transition: '".$transition."'";
			}
		elseif ($show_type == 'fold'){
			$mynewjs = $this->fold_js;
			$new_type = 'Slideshow.Fold';
			$type_ops = "transition: '".$transition."'";
			}
		elseif ($show_type == 'flash'){
			$mynewjs = $this->flash_js;
			$new_type = 'Slideshow.Flash';
			if (strpos($color, ',') !== false) {
  				 $color = "['".implode("', '",explode(', ',$color))."']";
			}else{$color = "'".$color."'";}
			$type_ops = "color: ".$color."";
			}
		elseif ($show_type == 'shrink'){
			$mynewjs = $this->shrink_js;
			$new_type = 'Slideshow.Shrink';
			$type_ops = "transition: '".$transition."'";
			}
		elseif ($show_type == 'default'){
			$mynewjs = '';
			$new_type = 'Slideshow';
			$type_ops = "transition: '".$transition."'";
			}
		
		/* This needs to be developed for future version
		if ($ani_class != '') {
			//$thumbsup = 'thumbsup'; // to be flushed out
			$myclass = "classes: ['', '', '', '', '', '', '', '".$ani_class."', '', '', '".$thumbsup."', '', '', '', '', ''],";
		}else { $myclass = '';}
		*/
		$myclass = '';
		// var keys = ['slideshow', 'first', 'prev', 'play', 'pause', 'next', 'last', 'images', 'captions', 'controller', 'thumbnails', 'hidden', 'visible', 'inactive', 'active', 'loader']
				
		// if shortcode has set a new show type we need to load the required javascript		
		if ($this->shortcode_showtype == 'true') echo $mynewjs;
			
		// set an href if there is one
		if ( $href != '') { $myhref = 'href: "'.$href.'", linked: false,';}else{ $myhref = 'linked: '.$mylinked.',';}
		
		// onEnd handler to act at end of non looping show
		// something like this: function(){ window.location.href = 'http://some.url'; }
		// onStart, onComplete, onEnd
		//match: /\?slide=(\d+)$/,
		//replace: [/(\.[^\.]+)$/, 't$1'],
		
		if ( $fromfolder != '' ) { 
			$minwidth = "200";
			$linkpath= WP_CONTENT_URL."/".$fromfolder;
			$imagepath = WP_CONTENT_DIR."/".$fromfolder;
			$getfolder = "\n\t"."<script src=\"".WP_PLUGIN_URL."/superslider-show/superslider-getfolder.php?folder=".$imagepath."&amp;linkpath=".$linkpath."&amp;showid=".$this->show_id."&amp;min_width=".$minwidth."\"></script>";
			$data = 'showdata'.$this->show_id; 
			$hu = "'".WP_CONTENT_URL."/".$fromfolder."'";
			echo "$getfolder";
			} else { $data = 'null'; $hu = '\'\''; $getfolder = ''; }

		$initshow = "".$showName."
			var ssShow".$this->show_id." = new ".$new_type."(this.el, ".$data.",{
						center: ".$center.",
						delay: ".$delay.",
						duration: ".$duration.",
						hu: ".$hu.",
						resize: ".$resize.",
						overlap: ".$overlap.",
						paused: ".$paused.",
						random: ".$random.",
						loop: ".$loop.",
						slide: ".$first_slide.",
						".$myaccesskeys."
						".$myproperties."
						".$myreplace."
						".$mypreload."
						".$myclass."
						".$mycaptions."
						".$mycontroller."
						".$myheight."
						".$mywidth."
						".$mythumb."
						".$myhref."
						".$myloader."
						".$type_ops."
						});";
				
				
				
				$headoutput = "\n\t"."<!-- superslider-show -->\n";								
				$headoutput .= "\n"."<script type=\"text/javascript\">\n";
				$headoutput .= "\t"."// <![CDATA[\n";		
				$headoutput .= "window.addEvent('domready', function() {
						".$initshow."
						".$mylightbox."
						".$mymouse."
						".$mythumbcover."						
						});\n";
				$headoutput .= "\t".'// ]]>';
				$headoutput .= "\n".'</script>'."\n";
							
		echo $headoutput;
		}
	function slimbox_linker() {
		
		$slimlink ='
		<script type=\"text/javascript\">
		window.addEvent(\'domready\', function() {
			/*
			Slimbox.onOpen : function(){ 
				console.log(  "is onOpen" );
				ssShow'.$this->show_id.'.pause(1).bind(ssShow'.$this->show_id.'); },
			Slimbox.onClose : function(){ ssShow'.$this->show_id.'.pause(0).bind(ssShow'.$this->show_id.'); }*/
		)};
		</script>	';
	echo $slimlink;
	}
	function ss_change_options( $atts ){
		global $post;
			
			$this->ssShowOpOut = array_merge($this->ssShowOpOut, array_filter($atts)); 
  				
  			return $this->ssShowOpOut;
	}
	/**
	* transform the var exclude into an array, remove its contents from all_attachments
	*/
	/*	*/
	function PHP4_array_diff_key(&$all_attachments, &$exclude){
			$arrs = func_get_args();
				$new_att = array_shift($arrs);
				foreach ($arrs as $array) {
					foreach ($new_att as $key => $v) {
						if (array_key_exists($key, $array)) {
						unset($new_att[$key]);
					}
				}
				}
			return $new_att;
	}	
		/**
		* Write the Slideshow html structure.
		*/	
	function slideshow_shortcode_out ( $atts ) {				
		global $post;

		srand((double)microtime()*1000000); 
		$this->show_id = rand(0,1000); 
		
		if ( isset( $atts['orderby'] ) ) {
			$atts['orderby'] = sanitize_sql_orderby( $atts['orderby'] );
			if ( !$atts['orderby'] )
				unset( $atts['orderby'] );
		}

		$atts = shortcode_atts(array(
			'order'      => 'ASC',
			'orderby'    => 'menu_order ID',
			'id' => $post->ID,
			'show_class' => '',
			'href' => '',
			'show_type' => '',
			'image_size' => '',
			'pop_size'	=>	'',
			'first_slide' => '',
			'zoom' => '',
			'pan' => '',
			'color' => '',
			'height' => '',
			'width' => '',
			'center' => '', 
			'resize' => '', 
			'linked' => '', 
			'fast' => '', 
			'captions' => '',
			'overlap' => '', 
			'thumbnails' => '',
			'thumbsize' => '',
			'mouseover' => '',
			'paused' => '', 
			'random' => '', 
			'loop' => '', 
			'loader' => '', 
			'delay' => '',
			'duration' => '',
			'controller' => '', 
			'exclude' => '',
			'clear' =>	'',
			'fromfolder' => '',
			'transition' => ''), $atts);

		// opdate options if any changes with shortcode
		if ($atts !='') $this->ss_change_options($atts);
		
		// this is giving error for some (Fixed). load the new show type javascript
		if ( array_key_exists('show_type', $atts) && ($atts['show_type'] != '')) $this->shortcode_showtype = 'true';
	

		// lets get the updated options
		extract($this->ssShowOpOut);

		if ( strpos($id, ',')  ) {	
			$idz = explode(', ', $id); // turns the variable string $id into an array $idz
			$all_attachments = array();	// pre define the master array

				foreach ($idz as $id) {		//loop through the array of posts and get their attachments		
					$id = intval($id);
					// for 2.7
					//$attachments = get_children("post_parent=$id&post_type=attachment&post_mime_type=image&orderby={$orderby}");
					$attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
				
				$all_attachments += $attachments;
				}

			} else {
				if (array_key_exists('id', $atts) && ( $atts['id'] !== '')) {
					$myid = $atts['id'];
					} else{
					$myid = '';
				}
				if ($myid =='') $id = $post->ID; 
				
				$all_attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );			
			}

		if ( empty($all_attachments))
			return '';
	
		if ( is_feed() ) {
			$output = "\n";
			foreach ( $all_attachments as $id => $attachment )
				$output .= wp_get_attachment_link($id, $size = 'thumbnail', true) . "\n";
			return $output;
		}

		/**
		* transform the var exclude into an array, remove its contents from all_attachments
		*/
		if($exclude !== '') {

				$exclude = array_flip(array_map('trim', explode(',', $exclude)));
				$b = $this->PHP4_array_diff_key($all_attachments, $exclude);
				$all_attachments = $b;
		}

	// Open gallery
		$output = apply_filters('show_style', "<div id='slide_gallery".$this->show_id."' class='slideshow ".$show_class."'><div class='slideshow-images show-$post->ID'>");
		
		foreach ( $all_attachments as $id => $attachment ) {

			$my_parent = ($attachment->post_parent);
			$parent_link = get_permalink($my_parent);
			$att_page = get_attachment_link($id, NULL , true);
			$image = wp_get_attachment_image_src($id, $size = $image_size);// $image_size, $pop_size
			$att_image = wp_get_attachment_image_src($id, $size = $pop_size);
		
		// If using Lightbox, set the link to the img URL
		// Else, set the link to the attachment URL, or parent post
		
		$lightbox_type = strtolower($lightbox_type);
			if ( $linked == 'lightbox') {
				$linkto = 'href="'.$att_image[0].'"';
				if ($lightbox_type == 'slimbox') {
					$a_rel = 'rel="lightbox-ssShow'.$post->ID.'"';
					}else{
					$a_rel = 'rel="'.$lightbox_type.':ssShow'.$post->ID.'"';
				}
				$a_class = $lightbox_type.' tool';
			}
			elseif ($linked == 'parent') { 
				$linkto = 'href="'.$parent_link.'"';
				$a_rel = '';
				$a_class = ' ';
			}
			elseif ($linked == 'attach') {
				$linkto = 'href="'.$att_page.'"';
				$a_rel = '';
				$a_class = ' ';			
			}
			
		// Do we link the image 
			if ($linked !== 'false') $output .= "\n\t"."<a $linkto $a_rel class=\"$a_class\" title=\"{$attachment->post_excerpt} :: {$attachment->post_content}\" >"."\n";
			
		// output the main images
			$output .= "<img id=\"slide-$id\" src=\"$image[0]\" alt=\"{$attachment->post_excerpt}\" width=\"$image[1]\" height=\"$image[2]\" style=\"visibility: hidden; opacity: 0;\" />";		
			
			if ($linked !== 'false') $output .= "</a>"."\n";
			
			
		} // end foreach
	
		// Add the caption
			if ( $captions == 'true') $output .= "\n<div class='slideshow-captions'></div>";
					
		// Add loader
			if ( $loader == 'true')	$output .= "\n<div class='slideshow-loader'></div>";
					
	// CLose the Images div
		$output .= '</div>';		
	
	// Add description // we may want to pull meta for the post here.
		/* 
		if ( $ss_description == 'true')	{
				$output .= '<div class="tool_description" style="">';
				
				foreach ( $attachments as $id => $attachment ) {							
					$output .= "<span>{$attachment->post_content}</span>";							
					}		
				$output .= '</div >';
		}*/
		
	// Add controller
		if ( $controller == 'true')	{
			$output .= '<div class="slideshow-controller" style="visibility: hidden; opacity: 0;">
					 <ul>
						<li class="first"><a></a></li>
						<li class="prev"><a></a></li>
						<li class="pause play"><a></a></li>
						<li class="next"><a></a></li>
						<li class="last"><a></a></li>
					</ul>
				</div>';
		}

		if ( $thumbnails == 'true')	{
		
			$output .= '<div class="slideshow-thumbnails"><ul>';			
			foreach ( $all_attachments as $id => $attachment ) {
				$image = wp_get_attachment_image_src($id, $size= $thumbsize, $myicon = false);
				$output .= "<li><a href=\"#\" title=\"view Image\">";
				$output .= "<img src=\"$image[0]\" alt=\"show Thumbnail\" width=\"$image[1]\" height=\"$image[2]\" />";
				$output .= "<span class='thumbframe'>&nbsp;</span></a></li>";
				}			
			$output .= '</ul></div><br style="clear:both;" />';			
		}
	if ( $clear !== '') $myclear = '<div style="clear:'.$clear.';height:0px;width:0px;" />&nbsp;</div>'; 
	// Close slideshow
	$output .= '</div>'.$myclear;
	
	// Add invisible imagelist
	if ( $linked == 'lightbox') {
		$output .= '<div id="hidenlinks" >';
		
		foreach ( $all_attachments as $id => $attachment ) {
				$att_image = wp_get_attachment_image_src($id, $size = $pop_size);
				$linkto = 'href="'.$att_image[0].'"';
				if ($linked !== 'false') $output .= "\n\t"."<a $linkto $a_rel style=\"display:none;\" title=\"{$attachment->post_excerpt} :: {$attachment->post_content}\" ></a>";			
		}
		$output .= '</div>';
	}
	
	// get the domready js
	$output .= $this-> ssShow_set_show($atts,$id);

	return $output;	
	
	}
	/**
	*	Add the [gallery / slideshow] shortcode
	*/
	function ssShow_add_shortcode(){
		
		$this->ssShowOpOut = get_option($this->AdminOptionsName);
		$ss_shortcode = $this->ssShowOpOut['ss_shortcode'];

		if ($ss_shortcode == 'gallery'){
				remove_shortcode ( 'gallery' );	// Remove included WordPress [gallery] shortcode function
				add_shortcode ( 'gallery' , array(&$this, 'slideshow_shortcode_out') );	// Add [gallery] shortcode function
			} else {
				add_shortcode ( 'slideshow' , array(&$this, 'slideshow_shortcode_out') );	// Add [slideshow] shortcode function
			}
	
	}
	/**
	*	Look ahead to check if any posts contain the [gallery / slideshow] shortcode
	*/
	function ssShow_slide_scan () { 
			$this->set_show_paths();
			$this->ssShowOpOut = get_option($this->AdminOptionsName);
			$ss_shortcode = $this->ssShowOpOut['ss_shortcode'];
			
			global $posts; 
			
			if ( !is_array ( $posts ) ) 
					return; 	 
			foreach ( $posts as $mypost ) { 
					if ( false !== strpos ( $mypost->post_content, '[gallery' ) ) { 
							
							add_action('wp_head', array(&$this,'ssShow_add_css'));
							add_action('wp_print_scripts', array(&$this,'ssShow_add_javascript')); //this loads the mootools scripts.
							
							break; 
					} 
					elseif ( false !== strpos ( $mypost->post_content,'[slideshow' ) ) { 
							
							add_action('wp_head', array(&$this,'ssShow_add_css'));
							add_action('wp_print_scripts', array(&$this,'ssShow_add_javascript')); //this loads the mootools scripts.
							
							break; 
					}
			} 
	} 
		/**
		*	called by superslider_show add_action upload_files_(tab)
		*	creates slideshow options tab in media window
		*/	
	function ss_print_box() {
		global $ssShow_domain;
		$this->ssShowOpOut = get_option($this->AdminOptionsName);
		extract($this->ssShowOpOut);

		if	($show_shortcode == 'true')	{
			if (is_admin ()) {			
				if( function_exists( 'add_meta_box' )) {
					add_meta_box( 'ss_show', __( 'SuperSlider-Show', $ssShow_domain ), array(&$this,'ss_writebox'), 'post', 'advanced', 'high');
					add_meta_box( 'ss_show', __( 'SuperSlider-Show', $ssShow_domain ), array(&$this,'ss_writebox'), 'page', 'advanced', 'high' );
				}
			}
   		}
	}
	function ssShow_admin_style(){
		if ($this->base_over_ride != "on") {
			$cssAdminFile = WP_PLUGIN_URL.'/superslider-show/admin/ss_admin_style.css';    			
    		
    		wp_register_style('superslider_admin', $cssAdminFile);
        	wp_enqueue_style( 'superslider_admin');
			
    	}
    	
	}
	
	function ssshow_admin_script(){
		wp_enqueue_script('jquery-ui-tabs');	// this should load the jquery tabs script into head
		
	}
	function ss_writebox() {
  		$this->ssShowOpOut = get_option($this->AdminOptionsName);
		$ss_shortcode = $this->ssShowOpOut['ss_shortcode'];
		
		include_once 'admin/superslider-show-box.php';
		echo $box;		
		include_once 'admin/js/superslider-show-box.js';
	}
	
	/**
	*	This is the function called from the template file to load js/css into head.
	* 	still in development 
	*	this probably isn't needed, seems it already loaded into head.
		
	
	function ss_archive_head(){
	
		add_action ( 'wp_head', 'ssShow::ssShow_add_css' );		// Add look ahead for [slideshow] shortcode
		add_action ( 'wp_head', 'ssShow::ssShow_add_javascript' );
		
	}*/
	/**
	*	This is the function called from the template file to write the slideshow.
	* 	still in development
	* 
	*	if(class_exists('ssShow')) ssShow::ss_archive_show($posts,'420','360');
	*	$hold_height, $hold_width should be taken from slideshow size options.
	*	if we can.
	*/
	function ss_archive_show($posts, $hold_height, $hold_width	){ //$posts, $hold_height, $hold_width	
		
		$ssShowOpOut = get_option('ssShow_options');

		extract($ssShowOpOut);
		
		include_once 'superslider-archive-button.php';		
		
		//add_action ( "template_redirect" , array(&$this,"ss_archive_head") );	
		
	
		
	}
	function getshow($id){
		global $ssShowOpOut;
var_dump($ssShowOpOut);	
		$atts[id] = $id;
		//return '[slideshow id="'.$id.'"]';
		//return '<div id="showme"><img src="http://localhost/wordpress_2.7/wp-content/uploads/2009/04/mountain_river-480x360.jpg" alt="image to test " width="480" height="360" />this is the get show function'.$id.'</div>';
		//return ssShow::slideshow_shortcode_out($atts,$id);
		//return ssShow::ssShow_set_show($atts,$id);
		//$myssShow = new ssShow();
		//return '<img src="http://localhost/wordpress_2.7/wp-content/uploads/2009/04/mountain_river-480x360.jpg" alt="image to test " width="480" height="360" />this is the get show function'.$id;
		
		
		//var_dump($atts); //returns list of posts by id

		
		//ssShow::slideshow_shortcode_out($atts);
	
	}

	/**
	*	This is the function that sets up all the actions.
	*/
	function superslider_show() {
		
		register_activation_hook(__FILE__, array(&$this,'ssShow_init') );
		register_deactivation_hook( __FILE__, array(&$this,'options_deactivation') );
		
		add_action ( "init", array(&$this,"ssShow_init" ) );
		add_action ( "admin_menu", array(&$this,"ssShow_setup_optionspage" ) ); // start the backside options page		
		add_action ( "template_redirect" , array(&$this,"ssShow_slide_scan") );	// Add look ahead for [slideshow] shortcode
		add_action ( "admin_menu", array(&$this,"ss_print_box" ) ); 			// adds the shortcode meta box
		
		add_action ( "init", array(&$this,"ssShow_add_shortcode" ) );
		
		add_action ( "init", array(&$this,"create_thumbs" ) );
		
		$ssShow_is_setup = 'true';
	
	}	
	
	function create_thumbs(){

			$this->listnewimages();
			add_filter( 'intermediate_image_sizes',  array(&$this, 'additional_thumb_sizes') );	
	}
	
	function additional_thumb_sizes( $sizes ) {
			$sizes[] = "slideshow";
			$sizes[] = "minithumb";
			return $sizes;
	}

	function listnewimages() { 
		
		if( FALSE === get_option('minithumb_size_w') )
			{
				add_option('slideshow_size_w', '480' );
				add_option('slideshow_size_h', '480');
				add_option('slideshow_crop', '0');
				
				add_option('minithumb_size_w', '80' );
				add_option('minithumb_size_h', '80');
				add_option('minithumb_crop', '1');
			}
			else
			{
				add_option('slideshow_size_w', '480');
				add_option('slideshow_size_h', '480');
				add_option('slideshow_crop', '0');
				
				add_option('minithumb_size_w', '80');
				add_option('minithumb_size_h', '80');
				add_option('minithumb_crop', '1');
			}
				
	}

}	//end class
} //End if Class ssShow

/**
*instantiate the class
*/	
//if (class_exists('ssShow')) {
	$myssShow = new ssShow();
//}
?>