<?php
$box = '
<form id="showshort" name="showshort"  action="">
			<input name="ss_shortcode" id="ss_shortcode" type="hidden" value="'.$ss_shortcode.'" />
			<label class ="ss_label" for="myid">id : <input tabindex="8" type="text" style="width:70%;" class="ss_input" name="myid" id="myid"  maxlength="100" value="" /></label> 
			<label class ="ss_label" for="fromfolder">folder : <input tabindex="9" type="text" style="width:70%;" class="ss_input" name="fromfolder" id="fromfolder"  maxlength="100" value="" /></label> 
			<label class ="ss_label" for="show_class">class : <input tabindex="10" type="text" style="width:70%;"  class="ss_input" name="show_class" id="show_class"  maxlength="20" value="" /></label>
			<label class ="ss_label" for="href">href : <input tabindex="11" type="text" style="width:70%;"  class="ss_input" name="href" id="href"  maxlength="100" value="" /></label>
			
			<label class ="ss_label" for="show_type">Transition style
					<select name="show_type" id="show_type" tabindex="12" >
						<option id="op_show_type" value=\'\'> select</option>
						 <option id="op_show_type1" value=\'default\'> default</option>
						 <option id="op_show_type2" value=\'kenburns\'> kenburns</option>
						 <option id="op_show_type3" value=\'push\'> push</option>
						 <option id="op_show_type4" value=\'fold\'> fold</option>
						 <option id="op_show_type5" value=\'flash\'> flash</option>
						 <!--<option id="op_show_type6" value=\'shrink\'> shrink</option>-->
					</select></label>
			<label class ="ss_label" for="image_size">Image size
					<select name="image_size" id="image_size" tabindex="13" >
						<option id="image_size0" value=\'\'> select</option>
						 <option id="image_size1" value=\'thumbnail\'> thumbnail</option>
						 <option id="image_size2" value=\'medium\'> medium</option>
						 <option id="image_size3" value=\'slideshow\'> custom slideshow</option>
						 <option id="image_size4" value=\'large\'> large</option>
						 <option id="image_size5" value=\'full\'> full</option>
					</select></label>
			<label class ="ss_label" for="pop_size">Pop size
					<select name="pop_size" id="pop_size" tabindex="14" >
						<option id="pop_size0" value=\'\'> select</option>
						 <option id="pop_size1" value=\'thumbnail\'> thumbnail</option>
						 <option id="pop_size2" value=\'medium\'> medium</option>
						 <option id="pop_size3" value=\'slideshow\'> custom slideshow</option>
						 <option id="pop_size4" value=\'large\'> large</option>
						 <option id="pop_size5" value=\'full\'> full</option>
					</select></label>
			<label class ="ss_label" for="linkedto">Linked to
					<select name="linkedto" id="linkedto" tabindex="15" >
						<option id="linkedto_0" value=\'\'> select</option>
						 <option id="linkedto_1" value=\'attach\'> attach</option>
						 <option id="linkedto_2" value=\'parent\'> parent</option>
						 <option id="linkedto_3" value=\'lightbox\'> lightbox</option>
					</select></label>
			<label class ="ss_label" for="first">first slide : <input tabindex="16" type="text" class="ss_input" name="first" id="first" size="3" maxlength="3" value="" /></label> 
			<label class ="ss_label" for="height">show height : <input tabindex="17" type="text" class="ss_input" name="height" id="height" size="4" maxlength="4" value="" /></label> 
			<label class ="ss_label" for="width">show width : <input tabindex="18" type="text" class="ss_input" name="width" id="width" size="4" maxlength="4" value="" /></label>
			
			<label class ="ss_label" for="zoom">burns zoom : <input tabindex="19" type="text" class="ss_input" name="zoom" id="zoom" size="4" maxlength="100" value="" /></label> 
			<label class ="ss_label" for="pan">burns pan : <input tabindex="20" type="text" class="ss_input" name="pan" id="pan" size="4" maxlength="100" value="" /></label> 
			<label class ="ss_label" for="color">flash color : <input tabindex="21" type="text" class="ss_input" name="color" id="color" size="4" maxlength="100" value="" /></label> 
			<label class ="ss_label" for="delay">slide delay : <input tabindex="22" type="text" class="ss_input" name="delay" id="delay" size="4" maxlength="6" value="" /></label> 
			<label class ="ss_label" for="duration">Trans time : <input tabindex="23" type="text" class="ss_input" name="duration" id="duration" size="4" maxlength="6" value="" /></label> 				
			<label class ="ss_label" for="fast"><input tabindex="24" name="fast" id="fast" type="checkbox" value="true" />thumb click fast change</label>	
			<label class ="ss_label" for="captions"><input tabindex="25" name="captions" id="captions" type="checkbox" value="true" />show captions</label>
			<label class ="ss_label" for="overlap"><input tabindex="26" name="overlap" id="overlap" type="checkbox" value="true" />overlap images</label>
			<label class ="ss_label" for="thumbnails"><input tabindex="27" name="thumbnails" id="thumbnails" type="checkbox" value="true" />show thumbnails</label>		
			<label class ="ss_label" for="mythumbsize">Thumb size
					<select name="mythumbsize" id="mythumbsize" tabindex="28" >
						<option id="mythumbsize0" value=\'\'> select</option>
						 <option id="mythumbsize1" value=\'thumbnail\'> default</option>
						 <option id="mythumbsize3" value=\'minithumb\'> minithumb</option>
					</select></label>
			<label class ="ss_label" for="mouseover"><input tabindex="29" name="mouseover" id="mouseover" type="checkbox" value="true" />mouseover start-stop</label>
			<label class ="ss_label" for="paused"><input tabindex="30" name="paused" id="paused" type="checkbox" value="true" />paused at start</label>
			<label class ="ss_label" for="random"><input tabindex="31" name="random" id="random" type="checkbox" value="true" />random image order</label>	
			<label class ="ss_label" for="loop"><input tabindex="32" name="loop" id="loop" type="checkbox" value="true" />loop back to start</label>
			<label class ="ss_label" for="loader"><input tabindex="33" name="loader" id="loader" type="checkbox" value="true" />show image loader</label>
			<label class ="ss_label" for="controller"><input tabindex="34" name="controller" id="controller" type="checkbox" value="true" />show controller</label>
			<label class ="ss_label" for="center"><input tabindex="35" name="center" id="center" type="checkbox" value="true" />center image to show area</label>	
			<label class ="ss_label" for="resize"><input tabindex="36" name="resize" id="resize" type="checkbox" value="true" />resize image to fit</label>
			<label class ="ss_label" for="exclude">exclude : <input tabindex="37" type="text" size="8" class="ss_input" name="exclude" id="exclude"  maxlength="100" value="" /></label>
			<label class ="ss_label" for="clear">Clear after show
					<select name="clear" id="clear" tabindex="38" >
						<option id="clear0" value=\'\'> none</option>
						 <option id="clear1" value=\'left\'> left</option>
						 <option id="clear2" value=\'right\'> right</option>
						 <option id="clea3" value=\'both\'> both</option>
					</select></label>
			<input type="button" tabindex="39" value="Add Show" name="sendtotextfield" id="sendtotextfield" class="button-primary action" style="margin:10px 40px 0 10px; float: right;" onclick="addshow(); return false;" />
</form>
<br style="clear:both;" /><p>This shortcode helper presently only works for the Html view, it does not work for the Visual view. Selecting any of the above options will add that option to the shortcode. If you want to then set an option to false, just change the property of the option in your shortcode inside of your post window.</p>

';
?>