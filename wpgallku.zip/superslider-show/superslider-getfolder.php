<?
/* PHP SCRIPT: getfolder.php
part of the SUperSlider-Show wordpress Plugin
Copyright 2009
       SuperSlider-Show is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License as published by 
    the Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    SuperSlider-show is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Collapsing Categories; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

// get the folder name
$folder = $_GET['folder'];

// get the min_width for the images
$min_width = $_GET['min_width'];

// get the path to link the image
$linkpath = $_GET['linkpath'];

// get the showid
$showid = $_GET['showid'];

Header("content-type: application/x-javascript");

//This function gets the file names of all images in the current directory
//and ouputs them as a JavaScript array
function returnimages($dirname) {
    global $folder, $min_width, $linkpath, $showid;
    $pattern="(\.jpg$)|(\.png$)|(\.jpeg$)|(\.gif$)"; //valid image extensions
    $files = array();
    $curimage=0;
   
    if($handle = opendir($dirname)) { // if folder is found
        while(false !== ($file = readdir($handle))){ // loop through the images
                
        if(eregi($pattern, $file)){ //if this file is a valid image
           
           $path_file = $folder.'/'.$file;
           $link_file = $linkpath.'/'.$file;
           $size = getimagesize($path_file); // lets get the image size
           $width = $size[0];
           
               if($width > $min_width){ // if this image is larger than min_width
               $caption = substr($file, 0, -4); // make a caption from the image name

                 $file = "'".$file ."': { caption: '".$caption."', href: '".$link_file."'}";

                 array_push($files, $file);
                 
                $curimage++;
                }
            }
        }
        $files = join(", ", $files); // seperate the file list with commas
        echo $files;
        closedir($handle); // close the folder
        
    }
   return;
}

echo 'var showdata'.$showid.'={'; // write the javascript image list

returnimages($folder);//Output the image file names

echo '}';

?>
