===   &#9733; Slider 3D, banner, menu and images gallery plugin or widget.   &#9733;===
  Contributors: pluginswp.com
  Donate link: http://www.pluginswp.com
  Tags: slider3d, admin, easy, javascript, jquery, marquee, module, sidebar, simple, widget, flash, nextgen, image, picture, photo, widgets, pictures, photo albums, Post, admin, media, gallery, images, slideshow, flash, photos, lightbox, AJAX, presentation, portfolio, album, posts, plugin, flip, page, book, flipping, page flip, pictures, ads, buttons, carousel photos, carousel gallery, cms, effects, embed, free flash, gallery, iphone, ipod, javascript,  media library, menu, menus, MU, photo, rotate, smooth gallery, swf, widget, wordpress,
Requires at least: 2.0.2
  Tested up to: 3.0.1
  Stable tag: 4.3
 &#9733;&#9733;&#9733; slider3d GALLERY is a flash real 3D with an expectacular desing.
slider3d Gallery is perfect to create:
<ul>
  <li>  3D photo galleries, </li>
  <li>3D portfolios</li>
  <li>3D menus</li>
  <li>3D slideshow</li>
  <li>3D headers</li>
  <li>3D banners</li>
  <li>3D catalogs for your products</li>
  <li>All that you can imagine </li>
</ul>
 <a href="http://www.pluginswp.com/slider3d-images/">Plugin DEMO</a>. slider3d Gallery can be used  like module or widget in your wordpress sites. 
In this plugin, you can configure a lot of params like size, colors, background, links to your post or external sites, photos, number of columns or images tittles. 
Very easy to use, create a gallery is easier than never. You only have to write your image folder and automaticaly slider3d show all your photos.
Additional Plugin Information:
<ul>
  <li><a href="http://www.pluginswp.com/slider3d-images/" target="_blank">DEMO Manual and config examples </a></li>
  <li><a href="http://www.pluginswp.com/" target="_blank">Download more wordpress plugins</a> 
  </li>
</ul>
== Description ==
 &#9733; slider3d GALLERY is a flash real 3D module with an expectacular desing. 
Slider3d Gallery is perfect to create:
<ul>
  <li> 3D photo galleries, </li>
  <li>3D portfolios</li>
  <li>3D menus</li>
  <li>3D slideshow</li>
  <li>3D headers</li>
  <li>3D banners</li>
  <li>3D catalogs for your products</li>
  <li>All that you can imagine </li>
</ul>
slider3d Gallery can be used  like module or widget in your wordpress sites. 
In this plugin, you can configure a lot of params like size, colors, background, links to your post or external sites, photos (if you want use like ajax gallery), number of rows or images tittles. 
Very easy to use, create a gallery is easier than never. You only have to write your image folder and automaticaly slider3d show all your photos.
Additional Plugin Information:
<ul>
  <li><a href="http://www.pluginswp.com/slider3d-images/">Manual and config examples </a></li>
  <li><a href="http://www.pluginswp.com/">Download more wordpress plugins</a>
</li>
</ul>
== Installation ==
<ol>
  <li>Upload `slider3d-gallery` folder to the `/wp-content/plugins/` directory. (You can install using wordpress administration too)</li>
  <li>Activate the plugin through the 'Plugins' menu in your wordpress administration.</li>
  <li>Create and configure a new gallery in your Wordpress admin. A new button is created in your wordpress admin: slider3d (see admin params to configure it)</li>
  <li>To add a new item of slider3d you only have to write  [`slider3d-gallery` ID] in your post or pages, where ID is the gallery ID. (you can add several items in your wordpress) </li>
  <li>Enjoy it!!</li>
</ol>
 &#9733;&#9733;&#9733; Main admin params   &#9733;&#9733;&#9733;
<ul>
  <li>Images Folder .- Your images folder. Upload images in this folder and automatically are shown in your slider3d. This images can be jpg, png or gif. VERY IMPORTANT: when you write your folder you don't forget last /. Example: images1/. Default folder is wp-content/plugins/slider3d-gallery/images/</li>
  <li>Speed.- Speed of the movement of gallery.</li>
  <li>Effect columns.Columns of the images effect.
  <li>Flash Width.- Width size of the slider3d (flash object). You can use pixels or percentage. For example: 100% or 400px.</li>
  <li>Flash Height.- Height sixe of the slider3d (flash object). Here, you only can use a value in pixels. For example 400px.</li>
  <li>Image Links.- Links for each image. Write each link in one line. (backspace) </li>
  <li> Image titles.- Titles for each image. Write each image in one link. (backspace) </li>
  <li>Link target.- Target of image links.  
  </li>
</ul>

== Frequently Asked Questions ==
  = What parameters should I set up to look good to me the carousel? =
  Once installed and activated, and the default plugin works correctly. The parameters are common to change the folder where you write the server folder containing the images. After adjusting the parameter row, zoom speed and get to the carousel is good. These parameters are often required to configure either because the carousel is different depending on the images you upload.

== Screenshots ==

1. Sample.
2. Sample.
3. Configuration.

== Changelog ==

= 1.2 =

register_sidebar_widget is deprecated - fixed
wp_register_widget_control - fixed

= 1.1 =