<?php
/**
 * @package Schema madx - Class Schema LocalBusiness
 * @category Core
 * @author madxartwork Zebida
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_WP_LocalBusiness') ) :
	/**
	 * Class
	 *
	 * @since 1.0.0
	 */
	class Schema_WP_LocalBusiness extends Schema_WP_Organization {
		
		/** @var string Currenct Type */
    	protected $type = 'LocalBusiness';
		
		/** @var string Current Parent Type */
		protected $parent_type = 'Organization';

		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			$this->init();
		}
	
		/**
		* Init
		*
		* @since 1.0.0
	 	*/
		public function init() {
		
			add_filter( 'schema_wp_get_default_schemas', array( $this, 'schema_type' ) );
			add_filter( 'schema_wp_types', array( $this, 'schema_type_extend' ) );
			add_filter( 'schema_madx_meta_is_opennings', array( $this, 'support_opennings' ) );
		}
		
		/**
		* Get schema type 
		*
		* @since 1.2
		* @return string
		*/
		public function type() {
			
			return 'LocalBusiness';
		}

		/**
		* Get schema type label
		*
		* @since 1.0.0
		* @return array
		*/
		public function label() {
			
			return __('Local Business', 'schema-madx');
		}
		
		/**
		* Get schema type comment
		*
		* @since 1.0.0
		* @return array
		*/
		public function comment() {
			
			return __('A particular physical business or branch of an organization. Examples of LocalBusiness include a restaurant, a particular branch of a restaurant chain, a branch of a bank, a medical practice, a club, a bowling alley, etc.', 'schema-madx');
		}
		
		/**
		* Extend schema types
		*
		* @since 1.0.0
		* @return array
		*/
		public function schema_type_extend( $schema_types ) {
			
			$schema_types[$this->type] = array 
				(
					'label' => $this->label(),
					'value'	=> $this->type
				);
			
			return $schema_types;
		}
		
		/**
		* Add support for openning hours post meta, by fileting is_opennings array
		*
		* @since 1.0.0
		* @return array
		*/
		public function support_opennings( $is_opennings ) {
			
			$supported_types 	= array($this->type);
			$sub_types 			= $this->subtypes();

			if ( is_array( $sub_types ) && ! empty( $sub_types ) ) {
				foreach ( $sub_types as $sub_types_key => $sub_typs ) {
					foreach ( $sub_typs as $sub_type_key => $subtype_data ) {
						$supported_types[] = $sub_type_key;
					}
				}
			}
			
			if ( empty ( $is_opennings ) ) {
				return $supported_types;
			} else {
				return array_merge( $is_opennings,  $supported_types );
			}
		}
		
		/**
		* Get schema type
		*
		* @since 1.0.0
		* @return array
		*/
		public function schema_type( $schema ) {
			
			$schema[$this->type] = array (
    			'id' 			=> $this->type,
    			'lable' 		=> $this->label(),
				'comment' 		=> $this->comment(),
    			'properties'	=> $this->properties(),
    			'subtypes' 		=> $this->subtypes(),
			);
			
			return apply_filters( 'schema_wp_LocalBusiness', $schema );
		}
		
		/**
		* Get sub types
		*
		* @since 1.0.0
		* @return array
		*/
		public function subtypes() {
			
			$subtypes = array
			(	
				'Local Business' => array
				(
            		'AnimalShelter' 				=> __('Animal Shelter', 'schema-madx'),
					'AutomotiveBusiness' 			=> __('Automotive Business', 'schema-madx'),
					'ChildCare'						=> __('Child Care', 'schema-madx'),
					'Dentist' 						=> __('Dentist', 'schema-madx'),
					'DryCleaningOrLaundry' 			=> __('Dry Cleaning or Laundry', 'schema-madx'),
					'EmergencyService'				=> __('Emergency Service', 'schema-madx'),
					'EmploymentAgency' 				=> __('Employment Agency', 'schema-madx'),
					'EntertainmentBusiness' 		=> __('Entertainment Business', 'schema-madx'),
					'FinancialService' 				=> __('Financial Service', 'schema-madx'),
					'FoodEstablishment' 			=> __('Food Establishment', 'schema-madx'),
					'GovernmentOffice' 				=> __('Government Office', 'schema-madx'),
					'HealthAndBeautyBusiness' 		=> __('Health and Beauty Business', 'schema-madx'),
					'HomeAndConstructionBusiness' 	=> __('Home and Construction Business', 'schema-madx'),
					'InternetCafe' 					=> __('Internet Cafe', 'schema-madx'),
					'LegalService' 					=> __('Legal Service', 'schema-madx'),
					'Library' 						=> __('Library', 'schema-madx'),
					'LodgingBusiness' 				=> __('Lodging Business', 'schema-madx'),
					'MedicalBusiness' 				=> __('Medical Business', 'schema-madx'), // More specific Types available in extensions
					'ProfessionalService' 			=> __('Professional Service', 'schema-madx'),
					'RadioStation' 					=> __('Radio Station', 'schema-madx'),
					'RealEstateAgent' 				=> __('Real Estate Agent', 'schema-madx'),
					'RecyclingCenter' 				=> __('Recycling Center', 'schema-madx'),
					'SelfStorage' 					=> __('Self Storage', 'schema-madx'),
					'ShoppingCenter' 				=> __('Shopping Center', 'schema-madx'),
					'SportsActivityLocation' 		=> __('Sports Activity Location', 'schema-madx'),
					'Store' 						=> __('Store', 'schema-madx'),
					'TelevisionStation' 			=> __('Television Station', 'schema-madx'),
					'TouristInformationCenter' 		=> __('Tourist Information Center', 'schema-madx'),
					'TravelAgency' 					=> __('Travel Agency', 'schema-madx')
				),
				'Automotive Business' => array
				(
            		'AutoBodyShop' 		=> __('Auto Body Shop', 'schema-madx'),
					'AutoDealer' 		=> __('Auto Dealer', 'schema-madx'),
					'AutoPartsStore'	=> __('Auto Parts Store', 'schema-madx'),
					'AutoRental' 		=> __('Auto Rental', 'schema-madx'),
					'AutoRepair' 		=> __('Auto Repair', 'schema-madx'),
					'AutoWash' 			=> __('Auto Wash', 'schema-madx'),
					'GasStation' 		=> __('Gas Station', 'schema-madx'),
					'MotorcycleDealer' 	=> __('Motorcycle Dealer', 'schema-madx'),
					'MotorcycleRepair' 	=> __('Motorcycle Repair', 'schema-madx')
				),
				'Emergency Service' => array
				(
            		'FireStation' 		=> __('Fire Station', 'schema-madx'),
					'Hospital' 			=> __('Hospital', 'schema-madx'),
					'PoliceStation'		=> __('Police Station', 'schema-madx')
				),
				'Entertainment Business' => array
				(
            		'AdultEntertainment'	=> __('Adult Entertainment', 'schema-madx'),
					'AmusementPark' 		=> __('Amusement Park', 'schema-madx'),
					'ArtGallery'			=> __('Art Gallery', 'schema-madx'),
					'Casino' 				=> __('Casino', 'schema-madx'),
					'ComedyClub' 			=> __('Comedy Club', 'schema-madx'),
					'MovieTheater' 			=> __('Movie Theater', 'schema-madx'),
					'NightClub' 			=> __('Night Club', 'schema-madx')
				),	
				'Financial Service' => array
				(
            		'AccountingService'	=> __('Accounting Service', 'schema-madx'),
					'AutomatedTeller' 	=> __('Automated Teller', 'schema-madx'),
					'BankOrCreditUnion'	=> __('Bank or CreditUnion', 'schema-madx'),
					'InsuranceAgency' 	=> __('Insurance Agency', 'schema-madx')
				),	
				'Food Establishment' => array
				(
            		'Bakery'				=> __('Bakery', 'schema-madx'),
					'BarOrPub' 				=> __('Bar or Pub', 'schema-madx'),
					'Brewery'				=> __('Brewery', 'schema-madx'),
					'CafeOrCoffeeShop' 		=> __('Cafe or Coffee Shop', 'schema-madx'),
					'FastFoodRestaurant'	=> __('Fast Food Restaurant', 'schema-madx'),
					'IceCreamShop'			=> __('Ice Cream Shop', 'schema-madx'),
					'Restaurant'			=> __('Restaurant', 'schema-madx'),
					'Winery'				=> __('Winery', 'schema-madx'),
					// More specific Types available in extensions
					'Distillery'			=> __('Distillery', 'schema-madx'),
				),
				'Government Office' => array
				(
            		'PostOffice' => __('Post Office', 'schema-madx')
				),	
				'Health and Beauty Business' => array
				(
            		'BeautySalon'	=> __('Beauty Salon', 'schema-madx'),
					'DaySpa' 		=> __('Day Spa', 'schema-madx'),
					'HairSalon'		=> __('Hair Salon', 'schema-madx'),
					'HealthClub' 	=> __('Health Club', 'schema-madx'),
					'NailSalon' 	=> __('Nail Salon', 'schema-madx'),
					'TattooParlor' 	=> __('Tattoo Parlor', 'schema-madx')
				),	
				'Home and Construction Business' => array
				(
            		'Electrician'		=> __('Electrician', 'schema-madx'),
					'GeneralContractor' => __('General Contractor', 'schema-madx'),
					'HVACBusiness'		=> __('HVAC Business', 'schema-madx'),
					'HousePainter' 		=> __('House Painter', 'schema-madx'),
					'Locksmith'			=> __('Locksmith', 'schema-madx'),
					'MovingCompany'		=> __('Moving Company', 'schema-madx'),
					'Plumber'			=> __('Plumber', 'schema-madx'),
					'RoofingContractor'	=> __('Roofing Contractor', 'schema-madx')
				),
				'Legal Service' => array
				(
            		'Attorney' 	=> __('Attorney', 'schema-madx'),
					'Notary' 	=> __('Notary', 'schema-madx')
				),
				'Lodging Business' => array
				(
            		'BedAndBreakfast'	=> __('Bed and Breakfast', 'schema-madx'),
					'Campground'		=> __('Campground', 'schema-madx'),
					'Hostel'			=> __('Hostel', 'schema-madx'),
					'Hotel' 			=> __('Hotel', 'schema-madx'),
					'Motel'				=> __('Motel', 'schema-madx'),
					'Resort'			=> __('Resort', 'schema-madx')
				),
				'Medical Business' => array
				(
					'CommunityHealth'	=> __('Community Health', 'schema-madx'),
					'Dentist'			=> __('Dentist', 'schema-madx'),
					'Dermatology'		=> __('Dermatology', 'schema-madx'),
					'DietNutrition'		=> __('Diet Nutrition', 'schema-madx'),
					'Emergency'			=> __('Emergency', 'schema-madx'),
					'Geriatric'			=> __('Geriatric', 'schema-madx'),
					'Gynecologic'		=> __('Gynecologic', 'schema-madx'),
					'MedicalClinic'		=> __('Medical Clinic', 'schema-madx'),
					'Midwifery'			=> __('Midwifery', 'schema-madx'),
					'Nursing'			=> __('Nursing', 'schema-madx'),
					'Obstetric'			=> __('Obstetric', 'schema-madx'),
					'Oncologic'			=> __('Oncologic', 'schema-madx'),
					'Optician'			=> __('Optician', 'schema-madx'),
					'Optometric'		=> __('Optometric', 'schema-madx'),
					'Otolaryngologic'	=> __('Otolaryngologic', 'schema-madx'),
					'Pediatric'			=> __('Pediatric', 'schema-madx'),
					'Pharmacy'			=> __('Pharmacy', 'schema-madx'),
					'Physician'			=> __('Physician', 'schema-madx'),
					'Physiotherapy'		=> __('Physiotherapy', 'schema-madx'),
					'PlasticSurgery'	=> __('Plastic Surgery', 'schema-madx'),
					'Podiatric'			=> __('Podiatric', 'schema-madx'),
					'PrimaryCare'		=> __('Primary Care', 'schema-madx'),
					'Psychiatric'		=> __('Psychiatric', 'schema-madx'),
					'PublicHealth'		=> __('Public Health', 'schema-madx'),
				),
				'Sports Activity Location' => array
				(
            		'BowlingAlley'			=> __('Bowling Alleyt', 'schema-madx'),
					'ExerciseGym'			=> __('Exercise Gym', 'schema-madx'),
					'GolfCourse'			=> __('Golf Course', 'schema-madx'),
					'HealthClub' 			=> __('Health Club', 'schema-madx'),
					'PublicSwimmingPool'	=> __('Public Swimming Pool', 'schema-madx'),
					'SkiResort'				=> __('Ski Resort', 'schema-madx'),
					'SportsClub'			=> __('Sports Club', 'schema-madx'),
					'StadiumOrArena'		=> __('Stadium or Arena', 'schema-madx'),
					'TennisComplex'			=> __('Tennis Complex', 'schema-madx')
				),	
				'Store' => array
				(
            		'AutoPartsStore'		=> __('Auto Parts Store', 'schema-madx'),
					'BikeStore'				=> __('Bike Store', 'schema-madx'),
					'BookStore'				=> __('Book Store', 'schema-madx'),
					'ClothingStore' 		=> __('Clothing Store', 'schema-madx'),
					'ComputerStore'			=> __('Computer Store', 'schema-madx'),
					'ConvenienceStore'		=> __('Convenience Store', 'schema-madx'),
					'DepartmentStore'		=> __('Department Store', 'schema-madx'),
					'ElectronicsStore'		=> __('Electronics Store', 'schema-madx'),
					'Florist'				=> __('Florist', 'schema-madx'),
					'FurnitureStore'		=> __('Furniture Store', 'schema-madx'),
					'GardenStore'			=> __('Garden Store', 'schema-madx'),
					'GroceryStore'			=> __('Grocery Store', 'schema-madx'),
					'HardwareStore'			=> __('Hardware Store', 'schema-madx'),
					'HobbyShop'				=> __('Hobby Shop', 'schema-madx'),
					'HomeGoodsStore'		=> __('Home Goods Store', 'schema-madx'),
					'JewelryStore'			=> __('Jewelry Store', 'schema-madx'),
					'LiquorStore'			=> __('Liquor Store', 'schema-madx'),
					'MensClothingStore'		=> __('Mens Clothing Store', 'schema-madx'),
					'MobilePhoneStore'		=> __('Mobile Phone Store', 'schema-madx'),
					'MovieRentalStore'		=> __('Movie Rental Store', 'schema-madx'),
					'MusicStore'			=> __('Music Store', 'schema-madx'),
					'OfficeEquipmentStore'	=> __('Office Equipment Store', 'schema-madx'),
					'OutletStore'			=> __('Outlet Store', 'schema-madx'),
					'PawnShop'				=> __('Pawn Shop', 'schema-madx'),
					'PetStore'				=> __('Pet Store', 'schema-madx'),
					'ShoeStore'				=> __('Shoe Store', 'schema-madx'),
					'SportingGoodsStore'	=> __('Sporting Goods Store', 'schema-madx'),
					'TireShop'				=> __('Tire Shop', 'schema-madx'),
					'ToyStore'				=> __('Toy Store', 'schema-madx'),
					'WholesaleStore'		=> __('Wholesale Store', 'schema-madx')
				),				
        	);
				
			return apply_filters( 'schema_wp_subtypes_LocalBusiness', $subtypes );
		}
		
		/**
		* Get properties
		*
		* @since 1.0.0
		* @return array
		*/
		public function properties() {
			
			$properties = array (
				
				'currenciesAccepted' => array(
					'label' 		=> __('Currencies Accepted', 'schema-madx'),
					'rangeIncludes' => array('Text'),
					'field_type' 	=> 'select',
					'markup_value' => 'disabled',
					'choices' 		=> schema_wp_get_currencies(),
					'instructions' 	=> __('The currency accepted.', 'schema-madx'),
					'allow_null'	=> true,
					'multiple' 		=> 1,
					'ui' 			=> 1,
				),
				'paymentAccepted' => array(
					'label' 		=> __('Payment Accepted', 'schema-madx'),
					'rangeIncludes' => array('Text'),
					'field_type' 	=> 'text',
					'markup_value'  => 'disabled',
					'instructions' 	=> __('Cash, Credit Card, Cryptocurrency, Local Exchange Tradings System, etc.', 'schema-madx'),
				),
				'priceRange' => array(
					'label' 		=> __('Price Range', 'schema-madx'),
					'rangeIncludes' => array('Text'),
					'field_type' 	=> 'text',
					'markup_value' => 'disabled',
					'instructions' 	=> __('The relative price range of a business, commonly specified by either a numerical range (for example, $10-15) or a normalized number of currency signs (for example, $$$).', 'schema-madx'),
				)
			);
			
			// Wrap properties in tabs 
			//
			$properties = schema_properties_wrap_in_tabs( $properties, self::type(), self::label(), self::comment(), 20 );
			
			// Merge parent properties 
			//
			$properties = array_merge( parent::properties(), $properties );

			return apply_filters( 'schema_properties_LocalBusiness', $properties );	
		}
		
		/**
		* Schema output
		*
		* @since 1.0.0
		* @return array
		*/
		public function schema_output( $post_id = null ) {
			
			if ( isset($post_id) ) {
				$post = get_post( $post_id );
			} else {
				global $post;
			}
			
			$schema	= array();
			
			// Putting all together
			//
			//$schema['@context'] =  'https://schema.org';
			//$schema['@type'] 	=  $this->type;
			/*
			$schema['mainEntityOfPage'] = array
			(
				'@type' => 'WebPage',
				'@id' => get_permalink( $post->ID )
			);
			*/
			
			
			// Get properties
			//
			$properties = schema_wp_get_properties_markup_output( $post->ID, $this->properties(), $this->type );
			
			// Merge parent schema 
			//
			$schema = array_merge( parent::schema_output($post->ID), $schema );

			// debug
			//echo '<pre>'; print_r($schema); echo '</pre>';

			return $this->schema_output_filter($schema);
		}

		/**
		* Apply filters to markup output
		*
		* @since 1.1.2.8
		* @return array
		*/
		public function schema_output_filter( $schema ) {

			// Unset auto generated properties
			//

			//unset($schema['review']);
			//unset($schema['review_author']);

			unset($schema['streetAddress']);
			unset($schema['addressLocality']);
			unset($schema['addressRegion']);
			unset($schema['postalCode']);
			unset($schema['addressCountry']);
			unset($schema['geo_latitude']);
			unset($schema['geo_longitude']);
			
			return apply_filters( 'schema_output_LocalBusiness', $schema );
		}
	}
	
	new Schema_WP_LocalBusiness();
	
endif;
