<?php
/**
 * @package Schema madx - Class Schema GardenStore
 * @category Core
 * @author madxartwork Zebida
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_WP_GardenStore') ) :
	/**
	 * Schema GardenStore
	 *
	 * @since 1.0.0
	 */
	class Schema_WP_GardenStore extends Schema_WP_Store {
		
		/** @var string Currenct Type */
    	protected $type = 'GardenStore';
			
		/** @var string Current Parent Type */
		protected $parent_type = 'Store';

		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			// emty __construct
		}
		
		/**
		* Get schema type 
		*
		* @since 1.2
		* @return string
		*/
		public function type() {
			
			return 'GardenStore';
		}

		/**
		* Get schema type label
		*
		* @since 1.0.0
		* @return array
		*/
		public function label() {
			
			return __('Garden Store', 'schema-madx');
		}
		
		/**
		* Get schema type comment
		*
		* @since 1.0.0
		* @return array
		*/
		public function comment() {
			
			return __('A garden store.', 'schema-madx');
		}
	}
	
endif;
