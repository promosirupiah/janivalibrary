<?php
/**
 * @package Schema madx - Class Schema Attorney
 * @category Core
 * @author madxartwork Zebida
 * @version 1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists('Schema_WP_Attorney') ) :
	/**
	 * Schema Attorney
	 *
	 * @since 1.0.0
	 */
	class Schema_WP_Attorney extends Schema_WP_LegalService {
		
		/** @var string Currenct Type */
    	protected $type = 'Attorney';
		
		/** @var string Current Parent Type */
		protected $parent_type = 'LegalService';

		/**
	 	* Constructor
	 	*
	 	* @since 1.0.0
	 	*/
		public function __construct () {
		
			// emty __construct
		}
		
		/**
		* Get schema type 
		*
		* @since 1.2
		* @return string
		*/
		public function type() {
			
			return 'Attorney';
		}

		/**
		* Get schema type label
		*
		* @since 1.0.0
		* @return array
		*/
		public function label() {
			
			return __('Attorney', 'schema-madx');
		}
		
		/**
		* Get schema type comment
		*
		* @since 1.0.0
		* @return array
		*/
		public function comment() {
			
			return __('Professional service: Attorney.', 'schema-madx');
		}
	}
	
	//new Schema_WP_Attorney();
	
endif;
