=== Enhanced Categories ===
Contributors: vprat
Donate link: http://enhanced-categories.vincentprat.info
Tags: categories, sidebar, navigation
Requires at least: 2.5
Tested up to: 2.6
Stable tag: 2.2.0

A plugin for wordpress which allows you to list your categories in a sexier way. Very useful when you have a great number of categories.

== Description ==

This plugin allows you to get better control on how your categories are listed. It provides a widget which lets you get more options than the default WordPress category widget (show RSS, hide empty categories, etc.). Furthermore, it allows to hide the children categories and use clickable buttons to expand them. The plugin requires jQuery to be included in your theme. It degrades nicely when javascript is not available to the usual WordPress category list. 

All the instructions for installation, the support forums, a FAQ, etc. can be found on the [plugin home page](http://enhanced-categories.vincentprat.info).

This plugin is available under the GPL license, which means that it's free. If you use it for a commercial web site, if you appreciate my efforts or if you want to encourage me to develop and maintain it, please consider making a donation using Paypal, a secured payment solution. You just need to click the button on the [plugin home page](http://enhanced-categories.vincentprat.info) and follow the instructions.