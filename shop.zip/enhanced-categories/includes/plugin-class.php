<?php
/*  Copyright 2006 Vincent Prat  (email : vpratfr@yahoo.fr)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


//#################################################################
// Stop direct call
if(preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF'])) { 
	die('You are not allowed to call this page directly.'); 
}
//#################################################################

//#################################################################
// Some constants 
//#################################################################

//#################################################################
// The Widget class
if (!class_exists("EnhancedCategoriesPlugin")) {

class EnhancedCategoriesPlugin {
	var $current_version = '2.2.0';
	var $options;
	var $ul_index = 0;
	
	/**
	* Constructor
	*/
	function EnhancedCategoriesPlugin() {
		$this->load_options();
	}
	
	/**
	* Function to be called when the plugin is activated
	*/
	function activate() {
		global $enh_cats_widget;
		
		$active_version = $this->options['active_version'];
		if (!isset($active_version) || $active_version=='') {
			$active_version = get_option('enh_cats_version');
		}
		
		if ($active_version==$this->current_version) {
			// do nothing
		} else {
			if ($active_version=='') {			
				add_option(ENHANCED_CATEGORIES_PLUGIN_OPTIONS, 
					$this->options, 
					'Enhanced Categories plugin options');
				add_option(ENHANCED_CATEGORIES_WIDGET_OPTIONS, 
					$enh_cats_widget->options, 
					'Enhanced Categories widget options');
			} else {			
				if ($active_version<'2.1.0') {
					delete_option('enh_cats_version');
					delete_option('enh_cats_show_symbol');
					delete_option('enh_cats_hide_symbol');
					delete_option('enh_cats_no_child_symbol');
					delete_option('enh_cats_effect');
					delete_option('enh_cats_show_count');
					delete_option('enh_cats_show_rss');
					delete_option('enh_cats_hide_empty');	
					delete_option('enh_cats_button_before_link');
					
					add_option(ENHANCED_CATEGORIES_PLUGIN_OPTIONS, 
						$this->options, 
						'Enhanced Categories plugin options');
					add_option(ENHANCED_CATEGORIES_WIDGET_OPTIONS, 
						$enh_cats_widget->options, 
						'Enhanced Categories widget options');
				} else if ($active_version<'2.2.0') {
					$enh_cats_widget->options['orderby'] = 'name';
					$enh_cats_widget->options['order'] = 'ASC';
					$enh_cats_widget->save_options();
				}
			}
		}
		
		// Update version number & save new options
		$this->options['active_version'] = $this->current_version;
		$this->save_options();
	}
	
	/**
	* Enqueue the necessary javascript
	*/
	function add_javascript() {	
		wp_enqueue_script('jquery');
	}
	
	/**
	* Function to render the plugin's HEAD elements in a blog page
	*/
	function render_page_head() {
	?>
	<script src="<?php echo WP_PLUGIN_URL; ?>/enhanced-categories/js/enhanced-categories.js" type="text/javascript" ></script>
	<?php
	}
	
	/**
	* Function that echoes the links in the form of a list
	*/
	function list_categories($args = '') {	
		$this->ul_index++;
		
		$defaults = array(
			// Options of the plugin
			'hide_empty' 	=> 1, 
			'show_count' 	=> 0,
			'show_rss' 		=> '0',
			'exclude' 		=> '',
			'button_color' 	=> '#AA0000',
			'expand_text' 	=> '&raquo;',
			'contract_text' => '&laquo;',
			'leaf_text' 	=> '-',
			'expand_image'	=> '',
			'contract_image'=> '',
			'leaf_image'	=> '',
			'contract_children'	=> 1,
			'is_button_after' 	=> 0,
			'orderby' 		=> 'name',
			'order' 		=> 'ASC', 

			// Those are not set by the options
			'show_last_update' => 0,
			'show_option_all' => '', 
			'use_desc_for_title' => 1,
			'child_of' => 0, 
			'hierarchical' => 1,
			'title_li' => ''
		);
		
		$r = wp_parse_args( $args, $defaults );
		
		// Additional parameters computed for RSS display
		if ($r['show_rss']!=0) {
			$r['feed'] = 'RSS';
			$r['feed_image'] = WP_PLUGIN_URL . '/enhanced-categories/images/rss.png';
		} else {
			$r['feed'] = '';
			$r['feed_image'] = '';
		}
		
		// Include javascript
		if (ENHANCED_CATEGORIES_USE_JAVASCRIPT) {
?>
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('ul.enhanced-categories-<?php echo $this->ul_index; ?>').enhancedCategories({
			// Override here the default settings for the plugin
			expandText		: '<?php echo str_replace("'", "\\'", $r['expand_text']); ?>',
			contractText	: '<?php echo str_replace("'", "\\'", $r['contract_text']); ?>',
			leafText		: '<?php echo str_replace("'", "\\'", $r['leaf_text']); ?>',
			expandImage		: '<?php echo $r['expand_image']; ?>',
			contractImage	: '<?php echo $r['contract_image']; ?>',
			leafImage		: '<?php echo $r['leaf_image']; ?>',
			isButtonAfter	: <?php echo $r['is_button_after']; ?>,
			buttonColor		: '<?php echo $r['button_color']; ?>',
			contractChildren: <?php echo $r['contract_children']; ?>
		});
	});
</script>
<?php	
		}

		echo '<ul class="enhanced-categories-' . $this->ul_index . '">';
		wp_list_categories($r);
		echo '</ul>';
	}
	
	/**
	* Load the options from database (set default values in case options are not set)
	*/
	function load_options() {
		$this->options = get_option(ENHANCED_CATEGORIES_PLUGIN_OPTIONS);
		
		if ( !is_array($this->options) ) {
			$this->options = array(
				'active_version'		=> ''
			);
		}
	}
	
	/**
	* Save options to database
	*/
	function save_options() {
		update_option(ENHANCED_CATEGORIES_PLUGIN_OPTIONS, $this->options);
	}
	
} // class EnhancedCategoriesPlugin
} // if (!class_exists("EnhancedCategoriesPlugin"))
	
?>