<?php
/*  Copyright 2006 Vincent Prat  (email : vpratfr@yahoo.fr)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


//#################################################################
// Stop direct call
if(preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF'])) { 
	die('You are not allowed to call this page directly.'); 
}
//#################################################################

//#################################################################
// Some constants 
//#################################################################

//#################################################################
// The Widget class
if (!class_exists("EnhancedCategoriesWidget")) {

class EnhancedCategoriesWidget {
	var $options;
	
	/**
	* Constructor
	*/
	function EnhancedCategoriesWidget() {
		$this->load_options();
	}
		
	/**
	* Function to register the Widget functions
	*/
	function register_widget() {
		register_sidebar_widget(
			__('Enhanced Categories', ENHANCED_CATEGORIES_I18N_DOMAIN), 
			array(&$this, 'render_widget'));
		
		if (is_admin()) {
			register_widget_control(
				__('Enhanced Categories', ENHANCED_CATEGORIES_I18N_DOMAIN), 
				array(&$this, 'render_control_panel'), 
				400, 250);
		}
	}
	
	/**
	* Function to render the widget control panel
	*/
	function render_control_panel() {
		// See if we're handling a form submission
		//--
		if ( $_POST['enh_cats-submit'] ) {
			$this->options['widget_title'] 		= strip_tags(stripslashes($_POST['enh_cats-widget_title']));
			$this->options['hide_empty'] 		= $_POST['enh_cats-hide_empty'] ? 1 : 0;
			$this->options['show_rss'] 			= $_POST['enh_cats-show_rss'] 	? 1 : 0;
			$this->options['show_count'] 		= $_POST['enh_cats-show_count'] ? 1 : 0;
			$this->options['exclude']			= $_POST['enh_cats-exclude'];
			$this->options['contract_children']	= $_POST['enh_cats-contract_children'] ? 1 : 0;
			$this->options['is_button_after']	= $_POST['enh_cats-is_button_after'] ? 1 : 0;
			$this->options['button_color']		= stripslashes($_POST['enh_cats-button_color']);
			$this->options['expand_text']		= stripslashes($_POST['enh_cats-expand_text']);
			$this->options['contract_text']		= stripslashes($_POST['enh_cats-contract_text']);
			$this->options['leaf_text']			= stripslashes($_POST['enh_cats-leaf_text']);
			$this->options['expand_image']		= $_POST['enh_cats-expand_image'];
			$this->options['contract_image']	= $_POST['enh_cats-contract_image'];
			$this->options['leaf_image']		= $_POST['enh_cats-leaf_image'];
			$this->options['orderby']			= $_POST['enh_cats-orderby'];
			$this->options['order']				= $_POST['enh_cats-order'];
						
			$this->save_options();
		}

		// The widget control
		//--
		$widget_title = htmlspecialchars($this->options['widget_title'], ENT_QUOTES);
	?>
	
	<input type="hidden" id="enh_cats-submit" name="enh_cats-submit" value="1" />
	
	<p>
		<label><?php _e('Title:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-widget_title" name="enh_cats-widget_title" type="text" value="<?php echo $widget_title; ?>" /></label>
	</p>
	
	<br/>
	<p><strong>&raquo; <?php _e('Category listing options', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></strong></p>
	<p>
		<label><input class="checkbox" <?php $this->render_checked($this->options['hide_empty']); ?> id="enh_cats-hide_empty" name="enh_cats-hide_empty" type="checkbox"> 
		<?php _e('Hide empty categories', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></label>
	</p>
	<p>
		<label><input class="checkbox" <?php $this->render_checked($this->options['show_rss']); ?> id="enh_cats-show_rss" name="enh_cats-show_rss" type="checkbox"> 
		<?php _e('Show RSS', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></label>
	</p>
	<p>
		<label><input class="checkbox" <?php $this->render_checked($this->options['show_count']); ?> id="enh_cats-show_count" name="enh_cats-show_count" type="checkbox"> 
		<?php _e('Show post count', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></label>
	</p>
	<p>
		<label><?php _e('Exclude categories (comma-separated IDs):', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-exclude" name="enh_cats-exclude" type="text" value="<?php echo $this->options['exclude']; ?>" /></label>
	</p>
	<p>
		<label><?php _e('Order by:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<select style="width: 250px;" id="enh_cats-orderby" name="enh_cats-orderby">
			<option value="ID" <?php $this->render_selected($this->options['orderby']=='ID'); ?> ><?php _e("ID", ENHANCED_CATEGORIES_I18N_DOMAIN); ?></option>
			<option value="name" <?php $this->render_selected($this->options['orderby']=='name'); ?> ><?php _e("Name", ENHANCED_CATEGORIES_I18N_DOMAIN); ?></option>
			<?php if (function_exists('mycategoryorder_init')) { ?>
			<option value="order" <?php $this->render_selected($this->options['orderby']=='order'); ?> ><?php _e("My Category Order", ENHANCED_CATEGORIES_I18N_DOMAIN); ?></option>
			<?php } ?>
		</select>
		</label>
	</p>
	<p>
		<label><?php _e('Order:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<select style="width: 250px;" id="enh_cats-order" name="enh_cats-order">
			<option value="ASC" <?php $this->render_selected($this->options['order']=='ASC'); ?> ><?php _e("Increasing", ENHANCED_CATEGORIES_I18N_DOMAIN); ?></option>
			<option value="DESC" <?php $this->render_selected($this->options['order']=='DESC'); ?> ><?php _e("Decreasing", ENHANCED_CATEGORIES_I18N_DOMAIN); ?></option>
		</select>
		</label>
	</p>
	
<?php 	if (ENHANCED_CATEGORIES_USE_JAVASCRIPT) { ?>
	<br/>
	<p><strong>&raquo; <?php _e('Javascript options', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></strong></p>
	<p>
		<label><input class="checkbox" <?php $this->render_checked($this->options['contract_children']); ?> id="enh_cats-contract_children" name="enh_cats-contract_children" type="checkbox"> 
		<?php _e('Contract children categories', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></label>
	</p>
	<p>
		<label><input class="checkbox" <?php $this->render_checked($this->options['is_button_after']); ?> id="enh_cats-is_button_after" name="enh_cats-is_button_after" type="checkbox"> 
		<?php _e('Place expand/contract button after the category', ENHANCED_CATEGORIES_I18N_DOMAIN); ?></label>
	</p>
	<p>
		<label><?php _e('Button color:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-button_color" name="enh_cats-button_color" type="text" value="<?php echo format_to_edit($this->options['button_color']); ?>" /></label>
	</p>
	<p>
		<label><?php _e('Expand button text:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/> 
		<input style="width: 250px;" id="enh_cats-expand_text" name="enh_cats-expand_text" type="text" value="<?php echo format_to_edit($this->options['expand_text']); ?>" /></label>
	</p>
	<p>
		<label><?php _e('Contract button text:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-contract_text" name="enh_cats-contract_text" type="text" value="<?php echo format_to_edit($this->options['contract_text']); ?>" /></label>
	</p>
	<p>
		<label><?php _e('Text when category has no child:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-leaf_text" name="enh_cats-leaf_text" type="text" value="<?php echo format_to_edit($this->options['leaf_text']); ?>" /></label>
	</p>
	<p>
		<label><?php _e('Expand button image:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/> 
		<input style="width: 250px;" id="enh_cats-expand_image" name="enh_cats-expand_image" type="text" value="<?php echo $this->options['expand_image']; ?>" /></label>
	</p>
	<p>
		<label><?php _e('Contract button image:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-contract_image" name="enh_cats-contract_image" type="text" value="<?php echo $this->options['contract_image']; ?>" /></label>
	</p>
	<p>
		<label><?php _e('Image when category has no child:', ENHANCED_CATEGORIES_I18N_DOMAIN); ?><br/>
		<input style="width: 250px;" id="enh_cats-leaf_image" name="enh_cats-leaf_image" type="text" value="<?php echo $this->options['leaf_image']; ?>" /></label>
	</p>
<?php 	
		} // if (ENHANCED_CATEGORIES_USE_JAVASCRIPT)
	}
	
	/**
	* Function to render the widget
	*/
	function render_widget($args) {
		global $enh_cats_plugin;
		
		extract($args, EXTR_SKIP);
		$title = empty($this->options['widget_title']) ? __('Categories', ENHANCED_CATEGORIES_I18N_DOMAIN) : $this->options['widget_title'];

		echo '<!-- Enhanced Categories ' . $enh_cats_plugin->options['active_version'] . ' -->';	
		
		echo $before_widget; 
			echo $before_title . $title . $after_title;
			$enh_cats_plugin->list_categories($this->options); 
		echo $after_widget;
		
		echo '<!-- Enhanced Categories ' . $enh_cats_plugin->current_version . ' -->';
	}
	
	/**
	* Load the options from database (set default values in case options are not set)
	*/
	function load_options() {
		$this->options = get_option(ENHANCED_CATEGORIES_WIDGET_OPTIONS);
		
		if ( !is_array($this->options) ) {
			$this->options = array(
				'widget_title'	=> '', 
				'show_rss'		=> 0, 
				'hide_empty' 	=> 1, 
				'show_count' 	=> 0,
				'exclude' 		=> '',
				'contract_children' => 1,
				'button_color' 	=> '#AA0000',
				'expand_text' 	=> '&raquo;',
				'contract_text' => '&laquo;',
				'leaf_text' 	=> '-',
				'orderby'	 	=> 'name',
				'order'	 		=> 'ASC',
				'expand_image'	=> get_bloginfo('url') . '/wp-content/plugins/enhanced-categories/images/expand.gif',
				'contract_image'=> get_bloginfo('url') . '/wp-content/plugins/enhanced-categories/images/contract.gif',
				'leaf_image'	=> get_bloginfo('url') . '/wp-content/plugins/enhanced-categories/images/leaf.gif',
				'is_button_after' 	=> 0
			);
		}
	}
	
	/**
	* Save options to database
	*/
	function save_options() {
		delete_option(ENHANCED_CATEGORIES_WIDGET_OPTIONS);
		add_option(ENHANCED_CATEGORIES_WIDGET_OPTIONS, $this->options);
	}
	
	/**
	* Helper function to output the checked attribute of a checkbox
	*/
	function render_checked($var) {
		if ($var==1 || $var==true) {
			echo 'checked="checked"';
		}
	}
	
	/**
	* Helper function to output the selected attribute of an option
	*/
	function render_selected($var) {
		if ($var==1 || $var==true) {
			echo 'selected="selected"';
		}
	}
} // class EnhancedCategoriesWidget

} // if (!class_exists("EnhancedCategoriesWidget"))
//#################################################################
?>