<?php
/*
Plugin Name: Enhanced Categories
Version: 2.2.0
Plugin URI: http://enhanced-categories.vincentprat.info
Description: Allows to get better control over the category listing. Also provides a widget view of the categories. Please make a donation if you are satisfied.
Author: Vincent Prat
Author URI: http://www.vincentprat.info
*/

/*  Copyright 2006 Vincent Prat  (email : vpratfr@yahoo.fr)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


//############################################################################
// Stop direct call
if(preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF'])) { 
	die('You are not allowed to call this page directly.'); 
}
//############################################################################

//############################################################################
// you can deactivate the javascript effect by setting the next variable to false
define('ENHANCED_CATEGORIES_USE_JAVASCRIPT', true);					
//############################################################################

//############################################################################
// plugin directory
define('ENHANCED_CATEGORIES_DIR', dirname (__FILE__));	

// i18n plugin domain 
define('ENHANCED_CATEGORIES_I18N_DOMAIN', 'enhanced-categories');

// The options of the plugin
define('ENHANCED_CATEGORIES_PLUGIN_OPTIONS', 'enh_cats_plugin_options');	
define('ENHANCED_CATEGORIES_WIDGET_OPTIONS', 'enh_cats_widget_options');	

// For WordPress 2.5 compatibility
if (!defined('WP_PLUGIN_URL')) {
	define(WP_PLUGIN_URL, get_option('siteurl') . '/wp-content/plugins');
}
//############################################################################

//############################################################################
// Include the plugin files
require_once(ENHANCED_CATEGORIES_DIR . '/includes/plugin-class.php');
require_once(ENHANCED_CATEGORIES_DIR . '/includes/widget-class.php');
//############################################################################

//############################################################################
// Init the plugin classes
global $enh_cats_plugin, $enh_cats_widget;

$enh_cats_plugin = new EnhancedCategoriesPlugin();
$enh_cats_widget = new EnhancedCategoriesWidget();
//############################################################################

//############################################################################
// Load the plugin text domain for internationalisation
if (!function_exists('enh_cats_init_i18n')) {
	function enh_cats_init_i18n() {
		load_plugin_textdomain(ENHANCED_CATEGORIES_I18N_DOMAIN, 'wp-content/plugins/enhanced-categories');
	} // function enh_cats_init_i18n()

	enh_cats_init_i18n();
} // if (!function_exists('enh_cats_init_i18n'))
//############################################################################

//############################################################################
// Add filters and actions
add_action('widgets_init', array(&$enh_cats_widget, 'register_widget'));

if (is_admin()) {
	add_action(
		'activate_enhanced-categories/enhanced-categories.php',
		array(&$enh_cats_plugin, 'activate'));
		
	add_action(
		'admin_menu', 
		array(&$enh_cats_plugin, 'add_javascript'), 1);
} else {
	if (ENHANCED_CATEGORIES_USE_JAVASCRIPT) {
		add_action(
			'wp_head', 
			array(&$enh_cats_plugin, 'add_javascript'), 1);
			
		add_action(
			'wp_head', 
			array(&$enh_cats_plugin, 'render_page_head'));
	}
}
//############################################################################

//############################################################################
// Template functions for direct use in themes
if (!function_exists('enh_cats_list_categories')) {
function enh_cats_list_categories($args = '') {
	global $enh_cats_plugin;
	$enh_cats_plugin->list_categories($args);
} // function enh_cats_list_categories
} // if (!function_exists('enh_cats_list_categories'))
//############################################################################
?>