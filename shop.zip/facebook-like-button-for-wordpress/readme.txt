=== Facebook Like Button For Wordpress===
Contributors: willfults
Tags: facebook like, facebook, like, share, button, facebook like button, social media, widget, plugin
Requires at least: 2.7.2
Tested up to: 2.9.2
Stable tag: 1.0.2

== Description ==


The facebook like button is the newest standard in facebook blog promotion - within 24 hours of its launch this feature was including on articles from Techcrunch.com, Washington Post, PC World, Huffington Post and hundreds of other major sites.

Easily allows your blog post or page to be shared on facebook.  The Like button enables users to make connections to your pages and share content back to their friends on Facebook with one click.  Also shows logged in users which friends have already 'liked' this page.


= Features =

* Uses the new Facebook 'like' button just launched (see screenshots)
* Shows logged in facebook users which friends have already 'liked' your page, increasing the probabily that they also will share your page.
* Quick load time - no bulky javascript or images used
* Easy installation and customisation
* Settings allows for the button to be placed on pages, posts, on the top or bottom or both locations on a page
* Also allows user to enter custom style for the button and css

== Installation ==

Follow the steps below to install the plugin.

1. Upload the Facebook Like directory to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings/Facebook Like to configure the button

== Screenshots ==

1. Facebook Like Settings Page
2. Facebook Like Button

== Help ==

For help and support please drop me an email at my site <a href="http://willfults.com/">http://willfults.com/</a>.

A kind user notified me that if you are using the TweetMeme button the installation of the Facebook Like Button will cause all of the options in the TweetMeme button to blank out. 

Redoing the TweetMeme button options using their settings page solves the problem.

Blog Articles
<a href="http://willfults.com/happens-when-you-die/">What happens when we die?</a>.




== Changelog ==

= 1.0 =

* Initial launch 


