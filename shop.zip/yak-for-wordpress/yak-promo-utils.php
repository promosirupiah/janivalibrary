<?php
if (!function_exists('yak_calc_discount_price')) {
    /**
     * Calculate a price discount, or return 0 if not a pricing promotion
     */
    function yak_calc_price_discount($price, $total_items, $promo=null) {
        if ($promo != null) {
            if ($promo->promo_type == 'pricing_perc' || $promo->promo_type == 'pricing_perc_threshold') {
                return ($promo->value / 100.0) * $price;
            }
            else if ($promo->promo_type == 'pricing_val') {
                return $promo->value / $total_items;
            }
            else if ($promo->promo_type == 'pricing_val_threshold') {
                return $promo->value;
            }
        }
        
        return 0;
    }
}

if (!function_exists('yak_calc_discount_shipping')) {
    /**
     * Calcualte a shipping discount, or return 0 if not a shipping discount
     */
    function yak_calc_shipping_discount($shipping_cost, $promo=null) {
        if ($promo != null) {
            if ($promo->promo_type == 'shipping_perc'  || $promo->promo_type == 'shipping_perc_threshold') {
                return ($promo->value / 100.0) * $shipping_cost;
            }
            else if ($promo->promo_type == 'shipping_val' || $promo->promo_type == 'shipping_val_threshold') {
                return $promo->value;
            }
        }
        
        return 0;
    }
}


if (!function_exists('yak_get_promotion')) {
    function yak_get_promotion($code) {
        $promos = yak_get_promotions($code, true);
        if (sizeof($promos) >= 1) {
            return $promos[0];
        }
        else {
            return new YakPromotion('', null, null, null, 0, '', '', null);
        }
    }
}


if (!function_exists('yak_get_promotion_by_threshold')) {
    function yak_get_promotion_by_threshold($threshold) {
        $promos = yak_get_promotions(null, true, $threshold);
        if (sizeof($promos) >= 1) {
            return $promos[0];
        }
        else {
            return null;
        }
    }
}


if (!function_exists('yak_get_promotions')) {
    function yak_get_promotions($code = null, $valid = false, $threshold = null) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $promo_table =& $registry->get('promo_table');
        $promo_users_table =& $registry->get('promo_users_table');
        
        $sql = "select promo_id, code, promo_type, description, threshold, value, expiry_date
                from $promo_table 
                where 1 = 1 ";
        
        // search by code        
        if (!empty($code)) {
            $sql .= "and code = '$code' ";
            $sql .= "and promo_type in ('shipping_perc', 'shipping_val', 'pricing_perc', 'pricing_val') ";
        }
        // or search by threshold
        else if (!empty($threshold)) {
            $sql .= "and $threshold > threshold ";
            $sql .= "and promo_type in ('shipping_perc_threshold', 'shipping_val_threshold', 'pricing_perc_threshold', 'pricing_val_threshold') ";
        }
        
        // check for validity
        if ($valid) {
            $sql .= "and (expiry_date is null or expiry_date >= current_date) ";
        }
        
        // final sql
        if (!empty($threshold)) {
            $sql .= "order by threshold desc limit 1";
        }
        else {
            $sql .= "order by promo_id asc";
        }
        
        $results = $wpdb->get_results($sql);
        
        $promos = array();
        foreach ($results as $result) {
            $rows = $wpdb->get_results("select user_nicename
                                        from $wpdb->users u
                                        where exists (select 1
                                                       from $promo_users_table pu 
                                                       where pu.promo_id = $result->promo_id
                                                       and pu.user_id = u.ID)");
            $users = array();
            foreach ($rows as $row) {
                $users[] = $row->user_nicename;
            }
            $promo = new YakPromotion($result->promo_id, $result->code, $result->promo_type, $result->threshold, $result->value, 
                                    $result->description, $result->expiry_date, $users);
            $promos[] = $promo;
        }
        
        return $promos;
    }
}
?>