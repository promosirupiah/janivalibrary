<?php
/*
See yak-for-wordpress.php for information and license terms
*/
global $model;

$dir = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress';
$openflashchart = '/resources/openflashchart/';
include_once(dirname(__FILE__) . $openflashchart . 'ofc-library/open-flash-chart.php');
?>

<div class="wrap">
<form method="post" action="#">
<h2>Reports</h2>

<div class="tablenav">
<div class="alignleft">
Sales for: <?php echo yak_html_select(null, 'year', $model['year'], $model['years'], false, null, true) ?>
<input type="submit" value="Requery" class="button" />
</div><br class="clear" />
</div><br class="clear" />

<?php
$data = array();
$labels = array();

foreach ($model['monthly_totals'] as $mt) {
    $labels[] = $mt->desc;
    $data[] = $mt->total;
}

if (count($data) > 0) {
    $max = round(max($data) * 1.1, yak_get_option(ROUNDING, 0));
}

$g = new graph();
$g->js_path = $dir . $openflashchart . 'js/';
$g->swf_path = $dir . $openflashchart;

$g->set_tool_tip(__('Total #val#', 'yak-admin'));

// set the X axis labels
$g->set_x_labels($labels);

//$g->data_sets[] = $bar;
$g->set_data($data);
$g->line_hollow(2, 4, '0x80a033', __('Monthly Sales Figures', 'yak-admin'), 10);

$g->set_bg_colour('#FFFFFF');
$g->set_x_label_style(10, '#A0A0A0', 0, 1);
$g->set_y_label_style(10, '#A0A0A0');
$g->x_axis_colour('#A0A0A0', '#FFFFFF');
$g->set_x_legend('Months (' . $model['year'] . ')', 12, '#A0A0A0');

$g->y_axis_colour('#A0A0A0', '#FFFFFF');

$g->set_y_min(0);
$g->set_y_max($max);
$g->y_label_steps(2);

$g->set_width(700);
$g->set_height(300);

$g->set_output_type('js');
echo $g->render();

?>

<table class="widefat">
<thead>
        <tr>
        <th><?php _e('Month', 'yak-admin') ?></th>
        <th><?php _e('Total', 'yak-admin') ?>: <?php echo yak_format_money($model['year_total'], true) ?></th>
        </tr>
</thead>
<tbody>
<?php foreach ($model['monthly_totals'] as $mt) { ?>
        <tr>
        <td><?php echo $mt->desc ?></td>
        <td><?php echo yak_format_money($mt->total) ?></td>
        </tr>
<?php } ?>
</tbody>
</table>
    
<h3><?php _ye('Best sellers for %s', 'yak-admin', $model['year']) ?></h3>
<table class="widefat">
<thead>
        <tr>
        <th><?php _e('Product Title', 'yak-admin') ?></th>
        <th><?php _e('Total Sales', 'yak-admin') ?></th>
        <th><?php _e('Total Value', 'yak-admin') ?></th>
        </tr>
</thead>
<tbody>
<?php foreach ($model['year_best'] as $total) { ?>
        <tr>
        <td><?php echo $total->desc ?></td>
        <td><?php echo $total->total ?></td>
        <td><?php echo yak_format_money($total->secondary_total) ?></td>
        </tr>
<?php } ?>
</tbody>
</table>

    
<h3><?php _ye('Best sellers by month in %s', 'yak-admin', $model['year']) ?></h3>
<table class="widefat">
<thead>
        <tr>
        <th><?php _e('Product Title', 'yak-admin') ?></th>
        <th><?php _e('Total Sales', 'yak-admin') ?></th>
        <th><?php _e('Total Value', 'yak-admin') ?></th>
        </tr>
</thead>
<tbody>
<?php   
foreach ($model['month_best'] as $totals) { 
$month = $totals[0]->desc;
?>
        <tr>
        <th colspan="3"><?php echo $month ?></th>
        </tr>
<?php foreach ($totals as $total) { ?>
        <tr>    
        <td><?php echo $total->secondary_desc ?></td>
        <td><?php echo $total->total ?></td>
        <td><?php echo yak_format_money($total->secondary_total) ?></td>
        </tr>
<?php } } ?>
</tbody>
</table>
</form>

</div>
