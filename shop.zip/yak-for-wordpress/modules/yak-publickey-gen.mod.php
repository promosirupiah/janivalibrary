<?php

/*
if (isset($_SERVER['HTTPS']) )
{
    echo "SECURE: This page is being accessed through a secure connection.<br><br>";
}
else
{
    echo "UNSECURE: This page is being access through an unsecure connection.<br><br>";
}

// Create the keypair
$res=openssl_pkey_new();

// Get private key
openssl_pkey_export($res, $privatekey);

// Get public key
$publickey=openssl_pkey_get_details($res);
$publickey=$publickey["key"];

echo "Private Key:<BR>$privatekey<br><br>Public Key:<BR>$publickey<BR><BR>";*/

class YakPublicKeyGen extends YakSettingsPanel {
    function get_id() {
        return 'publickeygen';
    }
    
    function get_title() {
        return __('PublicKey Gen', 'yak-admin');
    }
    
    function get_content($model) {
?>
        <h2><?php _e('Key Generator', 'yak-admin') ?></h2>

        <p><?php _e('Use this page if you want to generate a public key to use with manual credit card processing.', 'yak-admin') ?><br />
            <?php _e('(So that you don\'t store plain text credit cards in a potentially insecure database -- particularly important in shared hosting environments)', 'yak-admin') ?></p>

        <table class="form-table">
            <?php if (!empty($_REQUEST['private_key'])) { ?>
            <tr valign="top">
                <th scope="row"><?php _e('Private Key', 'yak-admin') ?></th>
                <td><textarea id="private_key" cols="80" rows="10"><?php echo $_REQUEST['private_key'] ?></textarea><br />
                <i><?php _e('Store this key in a secure location.  You\'ll use it to decrypt credit card details, so it is essential you don\'t lose it', 'yak-admin') ?><br />
                    <?php _e('(Recommendation: at the very least, save the key in a file, add the file to an encrypted zip, then store on your local machine with a second copy on a USB key)', 'yak-admin') ?></i></td>
            </tr>
            <?php } ?>
        
            <?php if (!empty($_REQUEST['public_key'])) { ?>
            <tr valign="top">
                <th scope="row"><?php _e('Public Key', 'yak-admin') ?></th>
                <td><textarea id="public_key" cols="80" rows="10"><?php echo $_REQUEST['public_key'] ?></textarea><br />
                <i><?php _e('The public key will be used for encrypting important data (i.e. credit card numbers) - so you\'ll use this in YAK itself (see the payments tab)', 'yak-admin') ?></i></td>
            </tr>
            <?php } ?>
        </table>
<?php
    }
    
    function apply_options() {
        $res = openssl_pkey_new();
        
        openssl_pkey_export($res, $privatekey);
        $publickey = openssl_pkey_get_details($res);
        $publickey = $publickey["key"];
        
        $_REQUEST['public_key'] = $publickey;
        $_REQUEST['private_key'] = $privatekey;
    }
}

$registry =& Registry::getInstance();
$settings_panels =& $registry->get('settings-panels');
$settings_panels[] = new YakPublicKeyGen();
?>