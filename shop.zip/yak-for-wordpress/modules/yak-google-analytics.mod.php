<?php

class YakGoogleAnalytics extends YakSettingsPanel {
    function get_id() {
        return 'analytics';
    }
    
    function get_title() {
        return __('Analytics', 'yak-admin');
    }
    
    function get_content($model) {
?>
        <h2><?php _e('Google Analytics', 'yak-admin') ?></h2>

        <table class="form-table">
            <tr valign="top">
                <th scope="row"><strong><?php _e('Analytics Profile ID', 'yak-admin') ?></strong></th>
                <td><input type="text" name="<?php echo GOOGLE_ANALYTICS_ID ?>" value="<?php echo yak_get_option(GOOGLE_ANALYTICS_ID, '') ?>" size="20" /><br />
                <i><?php _e('Google Analytics Profile ID. Make sure that you include the tracker code for this ID in your theme.', 'yak-admin') ?></i></td>
            </tr>

            <tr>
                <th scope="row"><strong><?php _e('Tax Calc', 'yak-admin') ?></strong></th>
                <td><input type="text" name="<?php echo GOOGLE_ANALYTICS_TAX_CALC ?>" value="<?php echo yak_get_option(GOOGLE_ANALYTICS_TAX_CALC, '') ?>" size="5" /><br />
                    <i><?php _e('Enter the fraction (i.e. 0.1) to use for tax calculation', 'yak-admin') ?> (this assumes a global tax rate... which is suboptimal and will need to be fixed
                        in a future release)</i></td>
            </tr>

            <tr>
                <th scope="row"><strong><?php _e('Affiliation', 'yak-admin') ?></strong></th>
                <td><input type="text" name="<?php echo GOOGLE_ANALYTICS_AFFILIATION ?>" value="<?php echo yak_get_option(GOOGLE_ANALYTICS_AFFILIATION, '') ?>" size="30" /><br />
                    <i><?php _e('Enter the affiliation (i.e. if you want to separate orders from your YAK store from orders through another mechanism)', 'yak-admin') ?></i></td>
            </tr>

        </table>
<?php
    }
    
    function apply_options() {
        yak_admin_options_set(GOOGLE_ANALYTICS_ID);
        yak_admin_options_set(GOOGLE_ANALYTICS_TAX_CALC);
        yak_admin_options_set(GOOGLE_ANALYTICS_AFFILIATION);
    }
}

function yak_google_analytics_tag($attrs) {
    $profile_id = yak_get_option(GOOGLE_ANALYTICS_ID, '');
    
    if (!empty($profile_id)) {
        $order_num = yak_order_id_tag(array());
        $affiliation = yak_get_option(GOOGLE_ANALYTICS_AFFILIATION, '');
        $tax_calc = yak_get_option(GOOGLE_ANALYTICS_TAX_CALC, 0);

        $region = $addr->region;
        if (empty($region)) {
            $region = $addr->state;
        }
        
        $orders = yak_get_orders(null, $order_num, null, null, false, false);
        $order = $orders[0];
        $addr = yak_get_address('shipping');
        
        $tax = $orders->total * $tax_calc;
        
        $content = "
        <script type=\"text/javascript\">
            pageTracker._addTrans(\"$order_num\", \"$affiliation\", \"$order->total\", \"$tax\", \"$order->shipping_cost\", \"$addr->city\", \"$region\", \"$addr->country\");";

        foreach ($order->items as $item) {
            // this bit of naffness is so I don't have to do another query
            // to get the product name and category
            if (yak_str_contains($item->itemname, '(')) {
                $category = yak_get_tag_value($item->itemname, '(', ')');
                $prodname = substr($item->itemname, 0, strpos($item->itemname, '('));
            }
            else {
                $category = '';
                $prodname = $item->itemname;
            }
            
            $sku = yak_get_sku($item->post_id, $item->cat_id, $item->sku);
            
            $content .= "
            pageTracker._addItem(\"$order_num\", \"$sku\", \"$prodname\", \"$category\", \"$item->price\", \"$item->quantity\");";
        }
          
        $content .= "
            pageTracker._trackTrans();
        </script>";
    }
    else {
        $content = '';
    }
    return $content;
}

$registry =& Registry::getInstance();
$settings_panels =& $registry->get('settings-panels');
$settings_panels[] = new YakGoogleAnalytics();

add_shortcode('yak_google_analytics', 'yak_google_analytics_tag');
?>