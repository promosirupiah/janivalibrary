<?php
/*
See yak-for-wordpress.php for information and license terms
*/
global $model, $countries, $states, $canada_states;

$imgbase = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/images';

wp_nonce_field('update-options');

$registry =& Registry::getInstance();
?>
<div class="wrap">
    <input type="hidden" name="section" value="options" />

<div id="tabs">
    <ul class="tabs-nav">
        <li><a id="basic-tab" href="#fragment-1"><span><?php _e('Basic', 'yak-admin') ?></span></a></li>
        <li><a id="cty-tax-tab" href="#fragment-2"><span><?php _e('Country Tax', 'yak-admin') ?></span></a></li>
        <li><a id="us-tax-tab" href="#fragment-3"><span><?php _e('US State Tax', 'yak-admin') ?></span></a></li>
        <li><a id="ca-tax-tab" href="#fragment-4"><span><?php _e('CA State Tax', 'yak-admin') ?></span></a></li>
    </ul>    

    <div class="clear"></div>

    <div id="fragment-1" class="tabs-container">
        <h2><?php _e('Basic Sales Tax Settings', 'yak-admin') ?></h2>
        
        <form name="settingsFrm1" method="post" action="#fragment-1">

            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Enable sales tax', 'yak-admin') ?></th>
                    <td><input type="checkbox" name="<?php echo ENABLE_SALES_TAX ?>" <?php yak_html_checkbox(yak_get_option(ENABLE_SALES_TAX, 'off')) ?> /><br />
                    <i><?php _e('Should sales tax be calculated?', 'yak-admin') ?></i></td>
                </tr>
                
                <tr valign="top">
                    <th scope="row"><?php _e('Display zero tax', 'yak-admin') ?></th>
                    <td><input type="checkbox" name="<?php echo DISPLAY_ZERO_TAX_CALC ?>" <?php yak_html_checkbox(yak_get_option(DISPLAY_ZERO_TAX_CALC, 'off')) ?> /><br />
                    <i><?php _e('Should sales tax be displayed if the calculation came to zero?', 'yak-admin') ?></i></td>
                </tr>
            </table>
            
            <div class="submit">
                <input type="submit" id="options_update1" name="options_update1" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm1', 'fragment-1')" />
            </div>
        </form>
    </div>
    
    <div id="fragment-2" class="tabs-container">
        <h2><?php _e('Country Taxes', 'yak-admin') ?></h2>
        
        <form id="settingsFrm2" name="settingsFrm2" method="post" action="#fragment-2">
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('Country', 'yak-admin') ?></th>
                        <th><?php _e('Tax Calc', 'yak-admin') ?> <button type="button" onclick="clearInputs('settingsFrm2')"><?php _e('Clear', 'yak-admin') ?></button></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($countries as $country=>$ignore) { 
                    $ctyname = $countries[$country];    
                ?>
                    <tr>
                        <td><?php echo $ctyname ?></td>
                        <td><input type="text" size="2" name="<?php echo 'yak_cty_tax_' . $country ?>" value="<?php echo yak_get_option('yak_cty_tax_' . $country) ?>" /></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            
            <div class="submit">
                <input type="submit" name="options_update2" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm2', 'fragment-2')" />
            </div>
        </form>
    </div>
    
    <div id="fragment-3" class="tabs-container">
        <h2><?php _e('US State Taxes', 'yak-admin') ?></h2>
        
        <form id="settingsFrm2" name="settingsFrm3" method="post" action="#fragment-3">
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('State', 'yak-admin') ?></th>
                        <th><?php _e('Tax Calc', 'yak-admin') ?> <button type="button" onclick="clearInputs('settingsFrm3')"><?php _e('Clear', 'yak-admin') ?></button></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($states as $state=>$ignore) { 
                    $statename = $states[$state];    
                ?>
                    <tr>
                        <td><?php echo $statename ?></td>
                        <td><input type="text" size="2" name="<?php echo 'yak_us_tax_' . $state ?>" value="<?php echo yak_get_option('yak_us_tax_' . $state) ?>" /></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            
            <div class="submit">
                <input type="submit" name="options_update3" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm3', 'fragment-3')" />
            </div>
        </form>
    </div>
    
    <div id="fragment-4" class="tabs-container">
        <h2><?php _e('Canada State Taxes', 'yak-admin') ?></h2>
        
        <form id="settingsFrm4" name="settingsFrm4" method="post" action="#fragment-4">
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('State', 'yak-admin') ?></th>
                        <th><?php _e('Tax Calc', 'yak-admin') ?> <button type="button" onclick="clearInputs('settingsFrm4')"><?php _e('Clear', 'yak-admin') ?></button></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($canada_states as $state=>$ignore) { 
                    $statename = $canada_states[$state];    
                ?>
                    <tr>
                        <td><?php echo $statename ?></td>
                        <td><input type="text" size="2" name="<?php echo 'yak_ca_tax_' . $state ?>" value="<?php echo yak_get_option('yak_ca_tax_' . $state) ?>" /></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            
            <div class="submit">
                <input type="submit" name="options_update4" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm4', 'fragment-4')" />
            </div>
        </form>
    </div>

</div>