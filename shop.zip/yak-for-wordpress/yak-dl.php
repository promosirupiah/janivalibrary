<?php
/*
See yak-for-wordpress.php for information and license terms
*/
define("YAK_WPABSPATH", dirname(__FILE__) . '/../../../');

require_once(YAK_WPABSPATH . 'wp-config.php');
require_once(YAK_WPABSPATH . 'wp-includes/functions.php');
if (file_exists(YAK_WPABSPATH . 'wp-includes/pluggable.php')) {
    require_once(YAK_WPABSPATH . 'wp-includes/pluggable.php');
}
else {
    require_once(YAK_WPABSPATH . 'wp-includes/pluggable-functions.php');
}
require_once(YAK_WPABSPATH . 'wp-admin/upgrade-functions.php');

global $wpdb, $order_dl_table;

$uid = $_GET['uid'];

$order_dl = $wpdb->get_row("select * from $order_dl_table where uid = '$uid'");

$addr = $_SERVER[REMOTE_ADDR];

if (isset($order_dl->download_address) && $order_dl->download_address != '' && $order_dl->download_address != $addr) {
    die('Unable to download, there was a previous download attempt from another ip address');
}

$filename = $order_dl->dl_file;

if (strstr($_SERVER['HTTP_USER_AGENT'], "Opera")) {
    $browser = "Opera";
}
else if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE")) {
    $browser = "IE";
}
else {
    $browser = '';
}

$sfilename = basename($filename);
if ($browser == 'IE') {
    $sfilename = preg_replace('/\./', '%2e', $sfilename, substr_count($sfilename, '.') - 1);
}

$mime_type = ($browser == 'IE' || $browser == 'Opera') ? 'application/octetstream' : 'application/octet-stream';
$disposition = $browser == 'IE' ? 'inline' : 'attachment';

// make sure the file exists before sending headers
if (!$fdl = @fopen($filename, 'r')) {
    die("Sorry, an error occurred, unable to open the file");
}
else {
    header("Pragma: ");
    header("Cache-Control: ");
    header("Expires: 0");
    header("Content-Type: $mime_type");
    header("Content-Disposition: $disposition; filename=" . $sfilename);
    header("Content-Transfer-Encoding: 8-bit");
    header("Content-Length:" . (string)(filesize($filename)) . "\n");
    sleep(1);
    fpassthru($fdl);
}
fclose($fdl);

$wpdb->query("update $order_dl_table set download_address = '$addr', download_attempts = download_attempts + 1 where uid = '$uid'");
yak_insert_orderlog($order_dl->order_id, "Download from ip address $addr");
?>