=== Plugin Name ===
Contributors: jasonrbriggs
Donate link: http://www.briggs.net.nz/log/projects/yak-for-wordpress/#donations
Tags: shop, e-commerce, shopping, cart, commerce, selling, paypal, shopping cart
Requires at least: 2.5
Tested up to: 2.9
Stable tag: v1.8.7

YAK is a shopping cart plugin for WordPress which associates products with weblog entries.

== Description ==

YAK is an open source shopping cart plugin for WordPress. It associates products with weblog entries, so the post ID also becomes the product code. It supports both pages and posts as products, handles different types of product through categories, and provides customisable purchase options (cheque or deposit, basic credit card form, basic Google Checkout integration, standard PayPal integration, PayPal Payments Pro, and Authorize.net).

**If you're looking for a hosted, managed solution, using YAK, please get in [contact](http://www.briggs.net.nz/log/contact/)**

Detailed installation and configuration instructions can be found by purchasing the YAK [Handbook](http://www.briggs.net.nz/log/projects/yak-for-wordpress/handbook), but basic installation instructions can be found [here](http://wordpress.org/extend/plugins/yak-for-wordpress/installation/).  If you want to do something more advanced, post a message in the discussion group, or consider buying the Handbook.

Further discussion can be found in the [discussion group](http://groups.google.com/group/yak-discuss) (please post bugs or problems you find there).  To keep up-to-date with releases, subscribe to the [feed](http://www.briggs.net.nz/log/projects/yak-for-wordpress/feed "feed"), or check the [changelog](http://svn.wp-plugins.org/yak-for-wordpress/trunk/changelog.txt).


YAK includes the following features:

* Create products from either posts or pages
* Downloadable products
* Multiple product types -- price per type (i.e. small, medium, large) and quantity per type
* Order administration -- filtering by date, status and order number
* Products page with paging (simple alternative to viewing by category)
* Configurable shipping (either flat rate or by weight unit)
* Configurable shipping address
* Configurable countries list
* Promotions -- percentage or fixed discounts, on shipping or order value
* Sales Reports (basic flash charts showing sales, best sellers, etc)
* Support for https (SSL)
* Tags for configurable emails
* Basic XML feed
* Support for multiple shops (function to retrieve product details from another shop)
* Customer interface has been translated into a number of languages: Japanese, Chinese, Taiwan Chinese, Thai, Slovakian, Czech, German, French, Italian, Spanish, Norwegian, Swedish
* Support for WordPress MU (*new*, but beta)

The following Payment Options are supported:

* Plain page -- custom payment such as providing information for your customers to pay by cheque, or direct deposit/debit
* PayPal Standard -- customers are redirected to PayPal for payments
* Google Checkout -- customers are redirected to Google for payments (note: Checkout is not fully integrated)
* Authorize.net -- Authorize's payments gateway is used to charge credit cards
* PayPal Payments Pro -- PayPal's payments gateway is used to charge credit cards
* Accounts Receivable


== Installation ==

For full installation details, covering all the flexible options YAK has to offer (external payments gateway, such as PayPal, 
Authorize.net, etc), consider purchasing the [YAK Installation Handbook](http://www.briggs.net.nz/log/projects/yak-for-wordpress/handbook).

1. Download the zip distribution and unzip into your wp-content/plugins directory, or alternatively, in the WP dashboard, under plugins, select "Add New", and enter YAK as the term to search for.

2. Activate the plugin.  You'll now find a few additional menu options, "Yak" beneath Settings, and "Orders", "Products" and "Sales Reports", beneath Tools.  A new checkout page will have been automatically created (if not already present).  You will also find two new categories have been created:  one called "products", and another subcategory, labelled "default".  This is like a marker for YAK products (mainly used for products of only one type).  If you have products with different types (for example, you're selling T-shirts in sizes large, medium and small), you'll also need to create them as child categories of "products".  At the end of this process, you might have the sub-categories: "default" (automatically created for you), "large", "medium", "small".

3. Create a new landing page for a type of payment you wish to accept.  There are a number of ways you can accept payment (including PayPal), but for the purposes of this basic introduction, we'll stick with Deposit. Click "Add New", in WordPress's "Pages" section.  Give the landing page a title, such as "Deposit".  For the content of the page, you should provide instructions on how a customer is to pay by deposit.  For example:

    >   Thanks for your order. Your order number is [yak\_order\_id]
    >
    >   You should receive a confirmation message shortly.
    >
    >   Please deposit the amount of <strong>[yak\_order\_value]</strong>
    >   into the following bank account:
    >
    >   Bank: SomeBank
    >
    >   Branch: Some Branch
    >
    >   Address:  blah blah blah blah
    >
    >   Account Number: 00-0000-000-000
    >
    >   SWIFT CODE: 00000

4. Another example of a landing page might be paying by cheque.  Create another page in the same way as you created the Deposit page using the text:

    >   Please a cheque in the amount of &#x005b;yak\_order\_value&#x005d; to:
    >
    >   12 Vulcan Lane
    >
    >   Auckland City
    >
    >   Auckland
    >
    >   Please note reference number [yak\_order\_id] on the back of the cheque.

    Save this new page as before. Note that you'll probably want to exclude these pages from the main menu -- which you can do using the plugin [Exclude-Pages](http://wordpress.org/extend/plugins/exclude-pages/).

5. Configure how you want YAK to function, by clicking on the "Yak" link in the Settings menu. On the "Basic" tab:
        
    a. Select a default country.
    
    b. Enter a confirmation email address, if you want to send order confirmations (if so, you'll also need to enter a confirmation message).
    
    c. If you want to display the checkout immediately when a customer clicks the Buy button, select your Checkout page from the drop down list for the option "Redirect on buy to".
    
    d. Most importantly: select the "products" category from the dropdown "Product category name", if it is not already selected.
    
    e. Click the Update Options button to save the changes.

6. On the Products price/quantity tab:
        
    a. Set an automatic discount for your online products (if you don't want to discount your products, set the fraction to 1).
    
    b. Enter a currency symbol ($, £, ¥, etc).
    
    c. Select the number of decimal places for displaying amounts.
    
    d. Select the currency format.
    
    e. If you want all new posts to be setup as products, you can enter an automatic quantity to use.
    
7. On the Payments tab:

    a. Next to "Redirect URLs for Payment", in the box labeled "Type Name", enter the text "Deposit".
    
    b. For the "Redirect To" select the page you created earlier.
    
    c. Click the plus (+) button and do the same for the Cheque landing page you also created.
    
8. Create a new product by performing the following steps:
        
    a. Write a new post (Click on "Add New" in the Posts section).
    
    b. Give your product a meaningful title.
    
    c. Enter details about the product.  Add the price to the post using the tag [yak\_price], and add a buy button using the tag [yak\_buy]. For example:

    >   Here's a description of my product, which you should buy. No really, you should.
    >
    >   Price: [yak\_price]
    >
    >   [yak_buy]
	
<?php if (function_exists('yak_buy')) { yak_buy(); } ?>
<?php if (function_exists('yak_get_product')) {$prod = yak_get_product($post_id);$price = $prod->price;if ($price > 0) { echo 'Price: '; yak_price($post_id, 'post'); }}  ?>

9. In the "YAK Product Details" tab below the post, give your product a price, and if necessary an alternative (display) title.

10. Also in that section, click the plus button to add a product type.  In the dropdown, select the "default" category you created earlier. Set the quantity of this product that you have available.

11. Publish the post.



== Frequently Asked Questions ==

**Why is the cart not working? Things don't update properly, or certain features don't work.**

First thing is disable all other plugins. Occasionally problems can be related to incompatibilities.  If you still have errors after that
post a message to the discussion group.

NOTE: There is an incompatibility with the WP Automatic Update plugin (to do with sessions).  YAK will not work with this plugin enabled.


**Why has the cart stopped working?**

Have you installed a new plugin lately?  Or have you updated other plugins?  If so, try disabling (see previous answer).


**I'd like to get help installing/configuring YAK, add a new feature, and/or modify the functionality**

Please get in [contact](http://www.briggs.net.nz/log/contact/).


**Why doesn't my post show up properly as a product?**

Have you setup your categories correctly?  At the very least you should have a "Products" category, with a "Default" child category.  The child category should be selected on your post.


**Why don't my confirmation emails arrive?**

Usually mailing problems can be traced to hosting issues.  Try installing something like WP-Mail-SMTP, so that WP mail goes via SMTP.


**Why doesn't YAK have its own top-level menu (why do I have to hunt through the WP menus)?**

Earlier versions of YAK did have a top-level menu. This was back when WordPress had a horizontal menu at the top of the page. There were some complaints about the use of screen real-estate, particularly when you had a lot of plugins installed.  One of the suggestions was to integrate more tightly with WordPress, hence the YAK menus were moved into Tools (where you'll find Products, Orders and Sales Reports), and Settings (where you'll find the YAK settings page).


**What tags can I use in my posts or pages?**

The following tags are available:

* _[yak\_checkout]_ - display the yak checkout in the page.

* _[yak\_order\_id]_ - display the customers order id/number
        
* _[yak\_order\_value]_ - display the total value of the current order

* _[yak\_price]_ - display the price of the product (including discount if set)
        
* _[yak\_price\_std]_ - display the price of the product without discount

* _[yak\_buy]_ - display the buy button

* _[yak\_buy\_begin]_ - include the 'html form' part of the buy button (use if you want to split up the button code)

* _[yak\_buy\_content]_ - include the 'html input' part of the buy button

* _[yak\_buy\_end]_ - include the end of the html form of the buy button

* _[yak\_cleanup]_ - cleanup order details (i.e. remove order details)

* _[yak\_paypal\_pdt\_success]_ and _[yak\_paypal\_pdt\_failure]_ - handler for PayPal's PDT (Payment Data Transfer) response. Text after the first tag is displayed on a successful purchase, text after the second tag is displayed on an unsuccessful purchase

* _[yak\_product\_page]_ - display a full list of products (with paging if necessary)

* _[yak\_get\_remote\_n]_ - retrieve the contents of a product (where 'n' is the post id) from a remote YAK server



== Changelog ==

**Version 1.8.7**

* Add unique url (stage=[xxxxx]) for each step in the checkout -- useful for various analytics packages.

* Fix a problem with setting quantity and other data when first creating a *page* product.

* Add facility for present "Terms & Conditions" text to a customer, which they have to tick before finally confirming the order.


**Version 1.8.6**

* Update rounding to fix euro currency problem (patch provided by Enrico Battocchi)
* Fix issue with discounted values sent to PayPal - note there is currently a rounding issue with these discounted values


**Version 1.8.5**

* Add facility for manual credit card payments to immediately send email confirmation/notification, or wait until the CC has actually been processed.


**Version 1.8.4**

* Fix problem with manual credit card processing not sending confirmation email


**Version 1.8.3**

* Updates to Thai translation
* Add multi-type selections to confirmation email


**Version 1.8.2**

* Possible fix for a problem with PayPal Std and 0-value orders (which shouldn't get submitted)
* Fix minor bug with promo function usage in order confirmation


**Version 1.8.1**

* Update language files
* Add TIS-620 version of Thai language file
* Fix a problem with HTML email received by Gmail.


**Version 1.8.0**

* Add discount override, to allow for a discount on a per-product basis (useful to get rid of old stock, for example)
* Add option-selection to products.  This differs from the categorisation-method of specifying different types of a product, and allows you to setup a selectable range of options (multi-select).  Thus you might have a mix-and-match product, where a customer can select 3 out of 10 options, and so on.
* Split installation code into separate file
* Fix problem with exclude-pages
* Add more logging to product update
* Add threshold based promotions -- promotions which are triggered by the value of the order, rather than by a promotion code/voucher.


**Version 1.7.7**

* Hopefully fix a problem with glob (on some PHP installs)
* Move order widget into separate file
* Change "Espana" into "Spain"
* Fix problem with country missing from shipping address in confirmation email and in order screen
* Add a new tag [phone] to confirmation email
* Fix a problem with address in order export
* Add message to Credit Card entry notifying the customer that they have a final chance to confirm/cancel the order
* Updated German translation, provided by Joern


**Version 1.7.6**

* Fix problem with data export in Safari
* Add address to order export
* Update to Japanese lang files, provided by Soichi
* Fix for PayPal PDT
* Add missing internationalised text in Order Widget
* Update Swedish trans, provided by Marco


**Version 1.7.5**

* Fix incompatibility problem with Contact Form 7.
* Fix a problem with Google Analytics tag ([yak_google_analytics]).


**Version 1.7.4**

* Fix a problem with Wordpress MU not saving options correctly.  Split options out into multiple values, rather than a single array of options.
* Add test for downloadable products
* Add a test to initialise paypal sandbox (for quicker testing)
* Fix problem with widget not clearing order details after successful purchase


**Version 1.7.3**

* Fix problem with paypal ipn


**Version 1.7.2**

* Fix problem with Accounts Receivable payment
* Fix problem with Credit Card payment
* Reduce memory usage
* Add instant update of pricing promotions in the first page of the cart (after hitting update)

Files changed: yak-for-wordpress.php, yak-static.php, yak-utils.php, yak-google-analytics.php, yak-view-cart.php, yak-view-confirm.php, yak-view-settings.php, yak-view-accrecv.php, payments/yak-paypal-pro.class.php, payments/yak-paypal.class.php, payments/yak-manual-credit-card.class.php, payments/yak-accounts-receivable.class.php, payments/yak-demo-payment.class.php, yak-promo-utils.php, yak-view-acc-recv.php, yak-model.php, yak-creditcard.php


**Version 1.7.1**

* Problem with Authorize.net url
* Separate PayPal Pro return url
* Finish moving code into separated payment classes
* Minor change to ipaddress sent to PayPal (only affects internal testing)

Files changed: yak-view-settings.php, yak-for-wordpress.php, yak-static.php, payments/yak-paypal-pro.class.php, payments/yak-paypal.class.php, payments/yak-google.class.php, payments/yak-manual-credit-card.class.php, payments/yak-accounts-receivable.class.php, payments/yak-demo-payment.class.php


**Version 1.7.0**

* Refactor payment types into separate classes to allow for easier extensibility
* Add 'demo' payment gateway
* Fix promo date saving problem
* Fix promo price calculation (causing problems in PayPal)
* Automatically create the Checkout page on activation
* Automatically create the "products" and "default" categories on activation
* Fix (hopefully) odd error\_log problem in certain environments


**Version 1.6.1**

* Change third party integration script from yak\_third\_party.php to yak-third-party.php.
* Add total cost (without shipping) to interface for third party func.  The function signature is now: yak\_check\_order\_3p($order\_id, $email, $recipient, $total\_cost).  Also added automated test.
* Plugin links were being added to every plugin row -- fixed so they're only added to the Yak row.


**Version 1.6.0**

* Remove auto\_set\_quantity -- doesn't make sense since you can now perform all product setup from the edit post page. 
* Remove link back to project page.
* Add custom "Out of Stock" message
* Changes required so that YAK will work with WordPress MU
* Move language files into "lang" subdirectory

Files changed: yak-paypal-ipn.php, yak-view-products.php, yak-for-wordpress.php, yak-static.php, yak-view-cart.php, yak-view-settings.php, yak-dl.php


**Version 1.5.2**

* Remove help from YAK settings page.  Moved to the WordPress Extend page: http://wordpress.org/extend/plugins/yak-for-wordpress/installation/
* Add links to the plugin details on the Plugins page
* Fix bug in orders screen (hitting update wasn't requerying)
* Set the priority of YAK's post processing (can be changed by modifying the DEFINE in yak-static.php)

Files changed: yak-view-settings.php, yak-static.php, yak-payments.php, yak-view-reports.php


**Version 1.5.1**

* Fix bug in sales report screen

Files changed: yak-view-reports.php


**Version 1.5.0**

* Fix shipping address in confirmation email, so that email and phone aren't included
* Add translation hooks for admin interface.  There are now two base translation files: yak-XX.po and yak-admin-XX.po. Most translators will probably only want to translate the customer interface (yak).  Those who want to translate the entire interface can also translate the admin interface as well (yak-admin).
* Fix confirmation email for credit card orders and accounts receivable
* Change accounts receivable button to "Next" rather than "Confirm", since it isn't the last page in the flow.
* Fix translation bug in address screen
* Add placeholder for third party integration (see changelog, or the handbook, for more info)
* Change the order screen so that it doesn't display orders without clicking the query button

Files changed: yak-for-wordpress.php, yak-model.php, yak-payments.php, yak-utils.php, yak-view-settings.php, ui.css, yak-static.php, yak-view-acc-recv.php, yak-view-address.php, yak-view-cart.php, yak-view-cc.php, yak-view-confirm.php, yak-view-orders.php, yak-promo-utils.php, yak-XX.po, yak-view-products.php, yak-view-reports.php


**Version 1.4.6**

* Add override for the shipping weight calculator value -- you can specify the value that is used for the first X grams in shipping calculation, and then the subsequent X grams.

Files changed: yak-for-wordpress.php, yak-view-confirm.php, yak-static.php, yak-view-settings.php, yak-promo-utils.php
   

**Version 1.4.5.1**

* Missed a Git collision marker in yak-settings.php


**Version 1.4.5**

* Localisation fix for the product page (patch provided by DjZoNe)
* Fix a minor problem with the tests
* Add facility to set session.cache_limiter to private for specific pages (such as checkout). This stops the "webpage has expired" messages in Internet Explorer. 
* Add promotion code access (specify a comma-separated list of user[name]s who are allowed to access a promotion)

Files changed: yak-for-wordpress.php, yak-model.php, resources/ui.css, yak-static.php, yak-view-settings.php,
yak-view-acc-recv.php, yak-view-address.php, yak-view-cart.php, yak-view-cc.php, yak-view-confirm.php, yak-view-orders.php,


**Version 1.4.4**

* [html\_shipping\_address] no longer includes email address
* billing address is now passed to PayPal Standard (shipping address was being sent through before)
* add Portuguese translation provided by Álvaro

Files changed: yak-for-wordpress.php, yak-utils.php, yak-payments.php, yak-view-settings.php, yak-model.php


**Version 1.4.3**

* wrong order for product type columns


== Prospective Feature List ==

* Affiliate program
* Customer access to order details (i.e. basic order tracking)
* More validation on address, so it's not so easy to put in duff address info
* More payment gateways!
* Product templates, "Add new product" menu option
* Low stock notifications
* Use WP shortcode API
* Fix rounding issue in discounted values sent to PayPal
* Add more detail (order details) to the excel export
* Add a function to test the order email