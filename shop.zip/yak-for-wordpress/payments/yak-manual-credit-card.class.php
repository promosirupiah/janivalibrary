<?php
/*
See yak-for-wordpress.php for information and license terms
*/

define("CREDIT_CARD", "Credit Card");
define("CC_LANDING_PAGE", "yak_cc_landing_page");
define("CC_IMMEDIATE_CONFIRMATION", "yak_cc_immediate_confirm");

class ManualCreditCardPayment extends Payment {
    
    function ManualCreditCardPayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[CREDIT_CARD] = 'SPECIAL: ' . CREDIT_CARD;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[CREDIT_CARD] = $this;
    }
    
    function get_name() {
        return "manual_credit_card";
    }
    
    function get_view_settings($model) {
        $model[CC_LANDING_PAGE] = yak_get_option(CC_LANDING_PAGE, '');
        $model[CC_IMMEDIATE_CONFIRMATION] = yak_get_option(CC_IMMEDIATE_CONFIRMATION, '');
        ?>
        <h3><?php _e('Manual Credit Card settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('Landing Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, CC_LANDING_PAGE, $model[CC_LANDING_PAGE], $model[PAGES]) ?><br />
                <i><?php _e('Final page for a successful credit card order.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Immediate confirmation', 'yak-admin') ?></th>
                <td><input type="checkbox" name="<?php echo CC_IMMEDIATE_CONFIRMATION ?>" <?php yak_html_checkbox($model[CC_IMMEDIATE_CONFIRMATION]) ?> /><br />
                <i><?php _e('Send email confirmation immediately, or once the credit card has been processed.', 'yak-admin') ?></i></td>
            </tr>
        </table>
        <?php
    }
    
    function apply_options() {
        yak_admin_options_set(CC_LANDING_PAGE);
        yak_admin_options_set(CC_IMMEDIATE_CONFIRMATION, 'off');
    }
    
    function get_next_action() {
        return 'cc';
    }
    
    function confirm_order($order_id, $items) {
        global $wpdb;
        
        if (isset($_SESSION['cc'])) {
            $registry =& Registry::getInstance();
            $order_meta_table =& $registry->get('order_meta_table');            
            
            $cc = $_SESSION['cc'];
            $cc_type = $cc['type'];
            $cc_security_code = $cc['security_code'];
            $cc_number = $cc['number'];
            $cc_name = $cc['name'];
            $cc_expiry = $cc['expiry'];
            $wpdb->query("insert into $order_meta_table (order_id, name, value) 
                          values ($order_id, 'CC type', '$cc_type')");
                          
            $wpdb->query("insert into $order_meta_table (order_id, name, value) 
                          values ($order_id, 'CC number', '$cc_number')");

            $wpdb->query("insert into $order_meta_table (order_id, name, value) 
                          values ($order_id, 'CC security code', '$cc_security_code')");
                          
            $wpdb->query("insert into $order_meta_table (order_id, name, value)
                          values ($order_id, 'CC name', '$cc_name')");
                          
            $wpdb->query("insert into $order_meta_table (order_id, name, value)
                          values ($order_id, 'CC expiry', '$cc_expiry')");
        }
        
    }
    
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        $uri = yak_get_option(CC_LANDING_PAGE, '');
        
        if (yak_get_option(CC_IMMEDIATE_CONFIRMATION, '') == 'on') {
            $send_conf = true;
        }
        else {
            $send_conf = false;            
        }
        
        return yak_redirect_page($order_id, $items, $shippingcost, $send_conf, $uri);
    }
    
    function finalise_order($order_id) {
        if (yak_get_option(CC_IMMEDIATE_CONFIRMATION, '') != 'on') {
            yak_send_confirmation_email($order_id);
        }
    }
}

new ManualCreditCardPayment();
?>