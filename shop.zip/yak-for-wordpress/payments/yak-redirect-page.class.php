<?php
/*
See yak-for-wordpress.php for information and license terms
*/

class RedirectPagePayment extends Payment {
    
    function RedirectPagePayment() {
        if (function_exists('pause_exclude_pages')) {
            pause_exclude_pages();
        }
        $pages = get_pages();
        if (function_exists('resume_exclude_pages')) {
            resume_exclude_pages();
        }
        
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        $payment_options =& $registry->get('payment_options');
        
        foreach ($pages as $page) {
            $p = '?page_id=' . $page->ID;
            $payment_pages[$p] = 'PAGE: ' . $page->post_title;
            $payment_options[$p] = $this;
        }
    }
    
    function get_name() {
        return "redirect";
    }
        
    /**
     * Redirect to a specific page to provide instructions for payment.
     */
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        
        $uri = $payment_types[$payment_type];
        return yak_redirect_page($order_id, $items, $shippingcost, true, $uri);
    }
    
}

new RedirectPagePayment();
?>