<?php
/*
See yak-for-wordpress.php for information and license terms
*/
require_once(YAK_ROOT_DIR . 'yak-creditcard.php');

define("DEMO_PAYMENT", "Demo Payment Gateway");
define("DEMO_CREDIT_CARDS", "yak_demo_credit_cards");
define("DEMO_RETURN_URL", "yak_demo_return");
define("DEMO_ERROR_URL", "yak_demo_error");

class DemoPayment extends Payment {
    
    function DemoPayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[DEMO_PAYMENT] = 'SPECIAL: ' . DEMO_PAYMENT;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[DEMO_PAYMENT] = $this;
    }
    
    function get_name() {
        return "demo_pro";
    }
    
    function get_view_settings($model) {
        $cc = yak_get_option(DEMO_CREDIT_CARDS);
        if (isset($cc) && $cc != null) {
            $cards = implode("\n", $cc);
        }
        else {
            $cards = '';
        }
        
        ?>
        <h3><?php _e('Demo Payments Gateway settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('Valid Credit Card Numbers', 'yak-admin') ?></th>
                <td><textarea name="<?php echo DEMO_CREDIT_CARDS ?>" cols="50" rows="5"><?php echo $cards ?></textarea><br />
                <i><?php _e('A list of credit card numbers that will result in a successful payment. Separate each with a new line', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Return Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, DEMO_RETURN_URL, yak_get_option(DEMO_RETURN_URL), $model[PAGES]) ?><br />
                <i><?php _e('The page to return to on a successful purchase.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Error Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, DEMO_ERROR_URL, yak_get_option(DEMO_ERROR_URL), $model[PAGES]) ?><br />
                <i><?php _e('The page to return to if an error occurs during payments processing.', 'yak-admin') ?></i></td>
            </tr>
        </table>
        
        <?php
    }
    
    function apply_options() {
        $cards = explode("\n", $_POST[DEMO_CREDIT_CARDS]);
        
        update_option(DEMO_CREDIT_CARDS, $cards);
        yak_admin_options_set(DEMO_RETURN_URL);
        yak_admin_options_set(DEMO_ERROR_URL);
    }
    
    function get_next_action() {
        return 'cc';
    }
    
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        global $wpdb, $cards;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        
        $cards = yak_get_option(DEMO_CREDIT_CARDS, array());
        
        $cc = $_SESSION['cc'];
        
        $value = yak_order_value(false, $order_id);
        
        $redirect_uri = yak_get_option(DEMO_RETURN_URL, '');
        
        if ($value > 0.0) {
            
            if (in_array($cc['number'], $cards)) {
                $wpdb->query("update $order_table set funds_received = $value where id = $order_id");
             
                yak_insert_orderlog($order_id, 'Demo Payment Gateway - transaction was approved');
                
                $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);   
            }
            else {
                $_SESSION['error_message'] = 'Payment was rejected by the demo payment gateway';
            
                yak_insert_orderlog($order_id, 'Demo Payment Gateway - transaction has failed');
                
                $wpdb->query("update $order_table set status = '" . ERROR . "' where id = $order_id");
            
                $rtn = yak_get_option(DEMO_ERROR_URL, '');
            }
        }
        else {
            // no order value -- just redirect to the success page
            $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);
            yak_insert_orderlog($order_id, "Total order cost is 0, not 'submitting' to Demo Payment Gateway");
        }
        
        yak_check_order($order_id);
        
        return $rtn;
    }
}

new DemoPayment();
?>