<?php
/*
See yak-for-wordpress.php for information and license terms
*/

define("PAYPAL_SANDBOX", "PayPal (Sandbox)");
define("PAYPAL_LIVE", "PayPal (Live)");
define("PAYPAL_SANDBOX_URL", "https://www.sandbox.paypal.com/cgi-bin/webscr");
define("PAYPAL_URL", "https://www.paypal.com/cgi-bin/webscr");

define("PAYPAL_ACCOUNT", "yak_paypal_account");
define("PAYPAL_RETURN_URL", "yak_paypal_return_url");
define("PAYPAL_CANCEL_RETURN_URL", "yak_paypal_cancel_return_url");
define("PAYPAL_IDENTITY_TOKEN", "yak_paypal_identity_token");
define("PAYPAL_PAYMENT_NOTIFICATION", "yak_paypal_payment_notification");
define("PAYPAL_INCLUDE_SHIPPING_ADDRESS", "yak_paypal_include_shipping");
define("PAYPAL_PDT", "pdt");
define("PAYPAL_PDT_TEXT", "Payment Data Transfer");
define("PAYPAL_IPN", "ipn");
define("PAYPAL_IPN_TEXT", "Instant Payment Notification");
define("PAYPAL_PAGES", "yak_paypal_pages");

class PaypalPayment extends Payment {
    
    function PaypalPayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[PAYPAL_SANDBOX] = 'SPECIAL: ' . PAYPAL_SANDBOX;
        $payment_pages[PAYPAL_LIVE] = 'SPECIAL: ' . PAYPAL_LIVE;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[PAYPAL_SANDBOX] = $this;
        $payment_options[PAYPAL_LIVE] = $this;
    }
    
    function get_name() {
        return "paypal";
    }
    
    function get_view_settings($model) {
        $model[PAYPAL_ACCOUNT] = yak_get_option(PAYPAL_ACCOUNT, '');
        $model[PAYPAL_RETURN_URL] = yak_get_option(PAYPAL_RETURN_URL, '');
        $model[PAYPAL_CANCEL_RETURN_URL] = yak_get_option(PAYPAL_CANCEL_RETURN_URL, '');
        $model[PAYPAL_IDENTITY_TOKEN] = yak_get_option(PAYPAL_IDENTITY_TOKEN, '');
        $model[PAYPAL_PAYMENT_NOTIFICATION] = yak_get_option(PAYPAL_PAYMENT_NOTIFICATION, '');
        $model[PAYPAL_INCLUDE_SHIPPING_ADDRESS] = yak_get_option(PAYPAL_INCLUDE_SHIPPING_ADDRESS, '');
           
        ?>
        <h3><?php _e('PayPal settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('Account', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo PAYPAL_ACCOUNT ?>" value="<?php echo $model[PAYPAL_ACCOUNT] ?>" /><br />
                <i><?php _e('Your account name is usually your email address.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Return Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, PAYPAL_RETURN_URL, $model[PAYPAL_RETURN_URL], $model[PAGES]) ?><br />
                <i><?php _e('The page to return to on a successful purchase.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Cancel return Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, PAYPAL_CANCEL_RETURN_URL, $model[PAYPAL_CANCEL_RETURN_URL], $model[PAGES]) ?><br />
                <i><?php _e('The page to return to if the customer cancels their purchase.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Identity token', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo PAYPAL_IDENTITY_TOKEN ?>" value="<?php echo $model[PAYPAL_IDENTITY_TOKEN] ?>" size="70" /><br />
                <i><?php _e('Used if you select PDT.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Use PDT or IPN', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, PAYPAL_PAYMENT_NOTIFICATION, $model[PAYPAL_PAYMENT_NOTIFICATION], array(PAYPAL_IPN=>PAYPAL_IPN_TEXT, PAYPAL_PDT=>PAYPAL_PDT_TEXT)); ?></td>
            </tr>
            <tr>
                <th><?php _e('Send shipping address?', 'yak-admin') ?></th>
                <td><input type="checkbox" name="<?php echo PAYPAL_INCLUDE_SHIPPING_ADDRESS ?>" <?php yak_html_checkbox($model[PAYPAL_INCLUDE_SHIPPING_ADDRESS]) ?> /></td>
            </tr>
        </table>
        <?php
    }
    
    function apply_options() {
        yak_admin_options_set(PAYPAL_ACCOUNT, null, false, true);
        yak_admin_options_set(PAYPAL_RETURN_URL);
        yak_admin_options_set(PAYPAL_CANCEL_RETURN_URL);
        yak_admin_options_set(PAYPAL_IDENTITY_TOKEN);
        yak_admin_options_set(PAYPAL_PAYMENT_NOTIFICATION);
        yak_admin_options_set(PAYPAL_INCLUDE_SHIPPING_ADDRESS, 'off');
    }
    
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        $cc = yak_get_option(CURRENCY_CODE, '');
        if (isset($cc) && $cc != '') {
            $cc = '&currency_code=' . $cc;	
        }
        else {
            $cc = '';	
        }
        
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        $ptypeval = $payment_types[$payment_type];
        
        if ($ptypeval == PAYPAL_SANDBOX) {
            $pp_url = PAYPAL_SANDBOX_URL;   
        }
        else {
            $pp_url = PAYPAL_URL;
        }
        
        $url = yak_get_url($pp_url . '?cmd=_cart&upload=1&submit=PayPal' . 
                '&business=' . urlencode(yak_get_option(PAYPAL_ACCOUNT, '')) . $cc . 
                '&return=' . urlencode(yak_get_url(yak_get_option(PAYPAL_RETURN_URL, ''), true) . '&order_id=' . $order_id) . 
                '&cancel_return=' . urlencode(yak_get_url(yak_get_option(PAYPAL_CANCEL_RETURN_URL, ''), true)) . '&no_note=1');
          
        if (yak_get_option(PAYPAL_INCLUDE_SHIPPING_ADDRESS, '') == 'on') {
            $caddress = yak_get_address('billing', false);
        
            if (!empty($caddress->addr1)) {
                $url .= '&first_name=' . urlencode($caddress->get_first_name())
                     .  '&last_name=' . urlencode($caddress->get_last_name()) 
                     .  '&address1=' . urlencode($caddress->addr1)
                     .  '&city=' . urlencode($caddress->city)
                     .  '&country=' . urlencode($caddress->country)
                     .  '&address_override=1';
                     
                if (!empty($caddress->addr2)) {
                    $url .= '&address2=' . urlencode($caddress->addr2);
                }
                if (!empty($caddress->state)) {
                    $url .= '&state=' . urlencode($caddress->state);
                }
                if (!empty($caddress->postcode)) {
                    $url .= '&zip=' . urlencode($caddress->postcode);
                }
            }
        }
        
        $total_items = 0.0;
        foreach ($items as $key => $item) {
            $total_items += $item->quantity;
        }
        
        $total_price = 0.0;
        $count = 1;
        foreach ($items as $key => $item) {
            $itemname = urlencode(yak_get_title($item->id, $item->cat_id));
            
            $total_price += $item->get_discount_total();
            
            $price = number_format($item->get_discount_price(), 2, '.', '');
            
            if ($item->quantity > 0) {
                $url = $url . '&item_name_' . $count . '=' . urlencode($item->name) . '&amount_' . $count . '=' . 
                        $price . '&quantity_' . $count . '=' . $item->quantity; 
                $count += 1;
            }
        }
        
        $total_price += $shippingcost;
        
        $price_rounding = yak_get_option(PRICE_ROUNDING, 0);
        
        if (yak_bccomp($total_price, 0.0, $price_rounding) == 0) {
            $url = yak_get_url(yak_get_option(PAYPAL_RETURN_URL, ''), true) . '&order_id=' . $order_id;
            yak_insert_orderlog($order_id, "Total order cost is $total_price (don't need to submit zero-value orders to PayPal)");
            yak_check_order($order_id);
        }
        else {
            $url = $url . '&custom=' . $order_id . '&handling_cart=' . $shippingcost;
            yak_log("paypal redirect url = $url");
        }
        return $url;
    }
    
    function post_processing($the_content) {
        //
        // PayPal Payment Data Transfer
        //
        if (yak_str_contains($the_content, '[yak_paypal_pdt_success]')) {
            $pdt = yak_paypal_pdt();
            
            if ($pdt) {
                $the_content = str_replace('[yak_paypal_pdt_success]', '', $the_content);
                $pos = strpos($the_content, '[yak_paypal_pdt_failure]');
                if ($pos >= 0) {
                    $the_content = substr($the_content, 0, $pos);
                }
            }
            else {
                $pos1 = strpos($the_content, '[yak_paypal_pdt_success]');
                $pos2 = strpos($the_content, '[yak_paypal_pdt_failure]');
                if ($pos >= 0) {
                    $the_content = substr($the_content, 0, $pos1) . substr($the_content, $pos2+29); 
                }
            }
        }
        
        return $the_content;
    }
}


if (!function_exists('yak_paypal_ipn')) {
    /**
     * Function to handle a PayPal Instant Payment Notification.
     */
    function yak_paypal_ipn() {
        global $order_table, $order_log_table, $wpdb;
        
        $order_id = $_REQUEST['custom'];
        
        if (empty($order_id)) {
            echo "ERROR: Missing parameter 'custom'";
            return;
        }
        
        // paypal requires all parameters to be sent back for verification
        $params = 'cmd=_notify-validate';
        $msg = '';
        foreach ( $_REQUEST as $key => $value ) {
            $params = $params . '&' . $key . '=' . urlencode(yak_fix_escaping($value));
            if ($msg != '') {
                $msg = $msg . ', ';   
            }
            $msg = $msg . $key . '=' . $value;
        }
        
        $payment_gross = $_REQUEST['mc_gross'];
        if (!isset($payment_gross) || $payment_gross == '') {
            $payment_gross = $_REQUEST['payment_gross'];	
        }
        
        $row = $wpdb->get_row("select funds_received from $order_table where id = $order_id");
        if ($row->funds_received > 0) {
            // we've already processed this
            return;   
        }
        
        $business = $_REQUEST['business'];
        if ($business != yak_get_option(PAYPAL_ACCOUNT, '')) {
            echo "ERROR: paypal business mismatch: $business doesn't match expected value";
            yak_log("paypal business mismatch: $business doesn't match $msg");
            yak_insert_orderlog($order_id, "business '$business' does not match [ $msg ]");
            return;
        }
        
        $payment_types = yak_get_option(PAYMENT_TYPES_CASE_INSENSITIVE, null);
        
        // choose the right paypal url based on what's set in the payment types array
        if (in_array(PAYPAL_SANDBOX, $payment_types)) {
            $url = parse_url(PAYPAL_SANDBOX_URL);
        }
        else {
            $url = parse_url(PAYPAL_URL);
        }
        
        // call paypal to verify
        $response = yak_do_http($url['scheme'] . '://' . $url['host'], $url['path'], $params);
        yak_log("IPN order_id=$order_id payment_gross=$payment_gross -- params=$params -- response=$response");
        
        if (!(strpos($response, 'VERIFIED') === false)) {        
            $wpdb->query("update $order_table set funds_received = $payment_gross where id = $order_id");
            
            yak_send_confirmation_email($order_id);
            
            yak_insert_orderlog($order_id, "PayPal verified order $order_id. response: [$response]");
        }
        else {
            yak_insert_orderlog($order_id, "PayPal response *NOT* verified for order $order_id. response: [$response] data: [ $msg ]");
        }
        
        yak_check_order($order_id);
    }
}
    

if (!function_exists('yak_paypal_pdt')) {
    /**
     * Function to handle a PayPal Payment Data Transfer
     */
    function yak_paypal_pdt() {
        global $order_table, $order_log_table, $wpdb;
        
        // only process if payment notification is set to PDT (otherwise just return true)
        // this means the pdt function can be used on the success page whether or not pdt is actually
        // used for payment notification
        if (yak_get_option(PAYPAL_PAYMENT_NOTIFICATION, '') == PAYPAL_PDT) {    
            $params = 'cmd=_notify-synch&tx=' . $_GET['tx'] . '&at=' . yak_get_option(PAYPAL_IDENTITY_TOKEN, '');
            
            $payment_types = yak_get_option(PAYMENT_TYPES_CASE_INSENSITIVE, null);
            
            // choose the right paypal url based on what's set in the payment types array
            if (in_array(PAYPAL_SANDBOX, $payment_types)) {
                $url = parse_url(PAYPAL_SANDBOX_URL);
            }
            else {
                $url = parse_url(PAYPAL_URL);
            }

            yak_log("YAK PDT url " . $url);
            yak_log("YAK PARAMS " . $params);
                        
            $response = yak_do_http($url['scheme'] . '://' . $url['host'], $url['path'], $params, null, 'GET');
            
            if (!(strpos($response, 'SUCCESS') === false)) {
                $payment_gross = yak_get_tag_value($response, 'mc_gross=', "\n");            
                $order_id = yak_get_tag_value($response, 'custom=', "\n");
                
                yak_cleanup_after_order();
                
                $wpdb->query("update $order_table set funds_received = $payment_gross where id = $order_id");
                
                yak_check_order($order_id);
                
                yak_send_confirmation_email($order_id);
                
                yak_insert_orderlog($order_id, "PayPal response successful for id $order_id [ $response ]");
                return true;
            }
            else {
                $order_id = null;
                if (isset($_GET['order_id'])) {
                    $order_id = $_GET['order_id'];
                }
                else if (isset($_GET['cm'])) {
                    $order_id = $_GET['cm'];
                }
                yak_insert_orderlog($order_id, "PayPal response not successful for id $order_id [ $response ]");
                return false;
            }
        }
        else {
            return true;
        }
    }
}


new PaypalPayment(); 
?>
