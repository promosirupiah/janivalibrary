<?php
/*
See yak-for-wordpress.php for information and license terms
*/
require_once(YAK_ROOT_DIR . 'yak-creditcard.php');

define("PAYPAL_PRO_SANDBOX", "PayPal Payments Pro (Sandbox)");
define("PAYPAL_PRO_LIVE", "PayPal Payments Pro (Live)");
define("PAYPAL_PRO_SANDBOX_URL", "https://api-3t.sandbox.paypal.com/nvp");
define("PAYPAL_PRO_URL", "https://api-3t.paypal.com/nvp");

define("PAYPAL_API_USERNAME", "yak_paypal_api_username");
define("PAYPAL_API_PASSWORD", "yak_paypal_api_password");
define("PAYPAL_API_SIGNATURE", "yak_paypal_api_signature");
define("PAYPAL_PRO_RETURN_URL", "yak_paypal_pro_return_url");
define("PAYPAL_PRO_ERROR_URL", "yak_paypal_pro_error_url");

class PaypalProPayment extends Payment {
    
    function PaypalProPayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[PAYPAL_PRO_SANDBOX] = 'SPECIAL: ' . PAYPAL_PRO_SANDBOX;
        $payment_pages[PAYPAL_PRO_LIVE] = 'SPECIAL: ' . PAYPAL_PRO_LIVE;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[PAYPAL_PRO_SANDBOX] = $this;
        $payment_options[PAYPAL_PRO_LIVE] = $this;
    }
    
    function get_name() {
        return "paypal_pro";
    }
    
    function get_view_settings($model) {
        $model[PAYPAL_API_USERNAME] = yak_get_option(PAYPAL_API_USERNAME, '');
        $model[PAYPAL_API_PASSWORD] = yak_get_option(PAYPAL_API_PASSWORD, '');
        $model[PAYPAL_API_SIGNATURE] = yak_get_option(PAYPAL_API_SIGNATURE, '');
        $model[PAYPAL_PRO_RETURN_URL] = yak_get_option(PAYPAL_PRO_RETURN_URL, '');
        $model[PAYPAL_PRO_ERROR_URL] = yak_get_option(PAYPAL_PRO_ERROR_URL, '');
        ?>
        <h3><?php _e('PayPal Pro settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('API Username', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo PAYPAL_API_USERNAME ?>" value="<?php echo $model[PAYPAL_API_USERNAME] ?>" /><br />
                <i><?php _e('The API username if you\'re using PayPal Payments Pro.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('API Password', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo PAYPAL_API_PASSWORD ?>" value="<?php echo $model[PAYPAL_API_PASSWORD] ?>" /><br />
                <i><?php _e('The PayPal Pro API Password.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('API Signature', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo PAYPAL_API_SIGNATURE ?>" value="<?php echo $model[PAYPAL_API_SIGNATURE] ?>" size="70" /><br />
                <i><?php _e('The PayPal Pro API Signature.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Return Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, PAYPAL_PRO_RETURN_URL, $model[PAYPAL_PRO_RETURN_URL], $model[PAGES]) ?><br />
                <i><?php _e('The page to return to after a successful order.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Error Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, PAYPAL_PRO_ERROR_URL, $model[PAYPAL_PRO_ERROR_URL], $model[PAGES]) ?><br />
                <i><?php _e('The page to return to if an error occurs during payments processing.', 'yak-admin') ?></i></td>
            </tr>
        </table>
        
        <?php
    }
    
    function apply_options() {
        yak_admin_options_set(PAYPAL_API_USERNAME);
        yak_admin_options_set(PAYPAL_API_PASSWORD);
        yak_admin_options_set(PAYPAL_API_SIGNATURE);
        yak_admin_options_set(PAYPAL_PRO_RETURN_URL);
        yak_admin_options_set(PAYPAL_PRO_ERROR_URL);
    }
    
    function get_next_action() {
        return 'cc';
    }
    
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        global $wpdb, $cards;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        
        $cc = $_SESSION['cc'];
        
        $value = yak_order_value(false, $order_id);
        
        $caddress = yak_get_address('billing', false);
        
        $arr = split("[\n\r\t ]+", $caddress->recipient);
        $firstname = $arr[0];
        $lastname = $arr[1];
        
        $card_detail = $cards[strtolower($cc['type'])];
        
        $params_array = array(
            'USER'              => yak_get_option(PAYPAL_API_USERNAME, ''),
            'PWD'               => yak_get_option(PAYPAL_API_PASSWORD, ''),
            'SIGNATURE'         => yak_get_option(PAYPAL_API_SIGNATURE, ''),
            'VERSION'           => '3.2',
            'METHOD'            => 'DoDirectPayment',
            'PAYMENTACTION'     => 'Sale',
            'IPADDRESS'         => yak_get_ip(),
            'CREDITCARDTYPE'    => $card_detail['paypal-name'],
            'ACCT'              => $cc['number'],
            'EXPDATE'           => str_replace('/', '', $cc['expiry']),
            'CVV2'              => $cc['security_code'],
            'AMT'               => $value,
            'INVNUM'            => $order_id,
            'STREET'            => $caddress->addr1,
            'CITY'              => $caddress->city,
            'STATE'             => $caddress->get_state_or_region(),
            'COUNTRYCODE'       => $caddress->country,
            'ZIP'               => $caddress->postcode,
            'FIRSTNAME'         => $firstname,
            'LASTNAME'          => $lastname
        );
        
        $params = yak_encode_params($params_array);
        
        if ($payment_type == PAYPAL_PRO_LIVE) {
            $url = PAYPAL_PRO_URL;
        }
        else {
            $url = PAYPAL_PRO_SANDBOX_URL;
        }
        
        $redirect_uri = yak_get_option(PAYPAL_PRO_RETURN_URL, '');
        
        if ($value > 0.0) {
            $response = yak_do_http($url, '', $params);
            $param_array = yak_decode_params($response);
        
            $rtn = '';
            if ($param_array['ACK'] == 'Success' || $param_array['ACK'] == 'SuccessWithWarning') {
                $wpdb->query("update $order_table set funds_received = $value where id = $order_id");
             
                if ($param_array['ACK']) {     
                    yak_insert_orderlog($order_id, 'PayPal Pro transaction was approved');
                
                    $wpdb->query("update $order_table set funds_received = $value where id = $order_id");
                }
                else {
                    yak_insert_orderlog($order_id, 'PayPal Pro transaction was approved with warning(s) -- please check your PayPal account (manual intervention will be required)');
                }

                $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);   
            }
            else {
                $_SESSION['error_message'] = $param_array['L_LONGMESSAGE0'];
            
                yak_insert_orderlog($order_id, 'PayPal Pro transaction has failed');
                
                $wpdb->query("update $order_table set status = '" . ERROR . "' where id = $order_id");
            
                $rtn = yak_get_option(PAYPAL_PRO_ERROR_URL, '');
            }
        
            $response = '';
            foreach ($param_array as $key=>$value) {
                $response .= "$key = $value ";
            }
        
            yak_insert_orderlog($order_id, 'response received from PayPal Pro was: ' . $response);
        }
        else {
            // no order value -- just redirect to the success page
            $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);
            yak_insert_orderlog($order_id, 'Total order cost is 0, not submitting to PayPal Payments Pro');
        }
        
        yak_check_order($order_id);
        
        return $rtn;
    }
}

new PaypalProPayment();
?>