<?php
/*
See yak-for-wordpress.php for information and license terms
*/

class Payment {
    function get_name() {
        return "";
    }
    
    function get_view_settings($model) {
    }
    
    function apply_options() {
    }
    
    function get_next_action() {
        return null;
    }
    
    function confirm_order($order_id, $items) {
    }
    
    function finalise_order($order_id) {
    }
    
    function post_processing($the_content) {
        return $the_content;
    }
    
    /**
     * Redirect to a specific page to provide instructions or to finalise payment.
     *
     * @param $payment_type the string name for the payment (Deposit, Cheque, etc)
     * @param $order_id the id of the order
     * @param $items an array of items
     * @param $shipping_cost total cost of shipping the order
     */
    function redirect($payment_type, $order_id, $items, $shipping_cost) {
        return "";
    }
}

if (!function_exists('yak_redirect_page')) {
    function yak_redirect_page($order_id, $items, $shippingcost, $send_conf_email, $page_uri) {
        yak_cleanup_after_order();
        
        if ($send_conf_email) {
            yak_send_confirmation_email($order_id);
        }
        
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        
        $order_num = yak_get_order_num($order_id);
        
        return yak_get_url($page_uri, true) . 'order_id=' . $order_num;
    }
}

if (!function_exists('yak_get_payment')) {
    function yak_get_payment($payment_key) {
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        foreach ($payment_types as $key=>$val) {
            if ($key == $payment_key) {
                $payment_options =& yak_get_payment_options();
                return $payment_options[$val];
            }
        }
        return null;
    }
}

if (!function_exists('yak_confirmation_detail')) {
    /**
     * Create the order detail section of a confirmation message
     *
     * @param $order_id the id of the order
     * @param $detail template for each line of the detail message
     * @param $results an array of sql results for the order detail
     * @param $pre_delim the delimiter to use at the beginning of multi-select-option details
     * @param $delim the delimiter to use at the end of multi-select-option details
     */
    function yak_confirmation_detail($order_id, $detail, $results, $pre_delim = '     ', $delim = "\n") {
        global $wpdb, $order_meta_table;
        
        $totalprice = 0;
        $totalquantity = 0;
        $detailmsg = '';
        foreach ($results as $result) {
            $price = $result->price;
            $qty = $result->quantity;
            $totalprice += ($price * $qty);
            $itemprice = $price * $qty;
            $totalquantity += $qty;
            $itemname = $result->itemname;
            
            $multi_select_options = '';
            if ($result->multi_select_count > 0) {
                $options = $wpdb->get_results("select value 
                                               from $order_meta_table
                                               where order_id = $order_id 
                                               and name like concat('$itemname', '%')");
                foreach ($options as $opt) {
                    $multi_select_options .= $pre_delim . $opt->value . $delim;
                }
            }
            
            $detailmsg = $detailmsg . sprintf($detail, $itemname, $multi_select_options, $qty, yak_format_money($price, false), yak_format_money($itemprice, false));
        }
        return array($detailmsg, $totalprice, $totalquantity);
    }
}

if (!function_exists('yak_send_confirmation_email')) {
    /**
     * Send a confirmation email for an order.
     *
     * @param $order_id the id of the order
     */
    function yak_send_confirmation_email($order_id) {
        global $wpdb, $order_table, $order_detail_table, $order_meta_table, $countries;
        
        $conf_email = yak_get_option(CONFIRMATION_EMAIL_ADDRESS, '');
        
        if (!isset($conf_email) || $conf_email == '') {
            return;
        }
        
        $mail = yak_get_option(CONFIRMATION_MESSAGE, '');
        $subject = yak_get_option(CONFIRMATION_SUBJECT, __('Order Confirmation', 'yak'));
        
        $result = $wpdb->get_row("select * from $order_table where id = $order_id");
        
        $payment_type = $result->payment_type;
        
        $address = $result->address;
        $split = split("\n", $address);
        $email = $split[0];
        $name = $split[1];
        $phone = $split[2];
        $address = $name . "\n" . implode("\n", array_slice($split, 3)) . $countries[$result->country_code];

        $shipping = $result->shipping_cost;
        
        $results = $wpdb->get_results("select od.id, od.itemname, od.price, od.quantity, od.post_id, od.cat_id, 
                                            (select count(*) 
                                             from $order_meta_table m 
                                             where m.order_id = od.id 
                                             and m.name like concat(od.itemname, '%')) as multi_select_count
                                        from $order_detail_table od 
                                        where od.id =  $order_id");
        
        $totalprice = 0;
        $totalquantity = 0;
 
        if (yak_str_contains($mail, '[order_detail]')) {
            $detail = __('Title', 'yak') . ": %s\n" .
                      "%s" .
                      __('Quantity', 'yak') . ": %d\n" .
                      __('Price', 'yak') . ": %s\n" .
                      __('Total' , 'yak') . ": %s\n\n";
        
            $confdet = yak_confirmation_detail($order_id, $detail, $results);
            $detailmsg = $confdet[0];
            $totalprice += $confdet[1];
            $totalquantity += $confdet[2];
            $detailmsg = $detailmsg . __('Shipping costs', 'yak') . ' ' . yak_format_money($shipping, true) . "\n";
            
            $mail = str_replace('[order_detail]', $detailmsg, $mail);
        }
        
        if (yak_str_contains($mail, '[html_order_detail]')) {
            $detail = "<tr>\n"
                    . "  <td>%s%s</td>\n"
                    . "  <td>%s</td>\n"
                    . "  <td>%s</td>\n"
                    . "  <td>%s</td>\n"
                    . "</tr>\n";
        
            $detailmsg = "<table width=\"40%\" border=\"1\">\n"
                       . "  <tr>\n"
                       . "    <th>" . __('Title', 'yak') . "</th>\n"
                       . "    <th>" . __('Quantity', 'yak') . "</th>\n"
                       . "    <th>" . __('Price', 'yak') . "</th>\n"
                       . "    <th>" . __('Total', 'yak') . "</th>\n"
                       . "  </tr>\n";
            
            $confdet = yak_confirmation_detail($order_id, $detail, $results, '<br />  ', '');
            
            $detailmsg .= $confdet[0];
            $totalprice += $confdet[1];
            $totalquantity += $confdet[2];

            $detailmsg .= "</table>\n"
                       .  "<p>" . __('Shipping costs', 'yak') . ' ' . yak_format_money($shipping, true) . "</p>\n";
            
            $mail = str_replace('[html_order_detail]', $detailmsg, $mail);
        }
        
        $totalprice += $shipping;
        
        $order_num = yak_get_order_num($order_id);
        
        $mail = str_replace('[order_id]', $order_num, $mail);
        $mail = str_replace('[order_cost]', yak_format_money($totalprice, true), $mail);
        $mail = str_replace('[payment_type]', $payment_type, $mail);
        $mail = str_replace('[shipping_address]', $address, $mail);
        $mail = str_replace('[html_shipping_address]', str_replace("\n", "<br />", $address), $mail);
        $mail = str_replace('[name]', $name, $mail);
        $mail = str_replace('[phone]', $phone, $mail);
        
        if (empty($mail)) {
            yak_log("WARNING: no confirmation message has been set");
            return;
        }
        
        //yak_log("mail is \n" . $mail);
        
        yak_sendmail($conf_email, $email, $subject, $mail); 
        yak_sendmail($conf_email, $conf_email, $subject . ' - ' . __('the following email has been sent to ', 'yak') . $email, $mail);
        yak_insert_orderlog($order_id, "Sent order confirmation to: $email, notification to: $conf_email)");
    }
}
?>