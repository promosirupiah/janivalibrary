<?php
/*
See yak-for-wordpress.php for information and license terms
*/
require_once(YAK_ROOT_DIR . 'resources/google/googlecart.php');
require_once(YAK_ROOT_DIR . 'resources/google/googleitem.php');
require_once(YAK_ROOT_DIR . 'resources/google/googleshipping.php');

define("GOOGLE_MERCHANT_ID", "yak_google_merchant_id");
define("GOOGLE_MERCHANT_KEY", "yak_google_merchant_key");
define("GOOGLE_SHIPPING_METHOD", "yak_google_shipping_method");
define("GOOGLE_EDIT_CART_URL", "yak_google_edit_cart_url");
define("GOOGLE_CONTINUE_URL", "yak_google_continue_url");

define("GOOGLE_SANDBOX", "Google (Sandbox)");
define("GOOGLE_LIVE", "Google (Live)");
define("GOOGLE_SANDBOX_URL", "https://sandbox.google.com/checkout/api/checkout/v2/checkout/Merchant/");
define("GOOGLE_URL", "https://checkout.google.com/api/checkout/v2/checkout/Merchant/");

class GooglePayment extends Payment {
    
    function GooglePayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[GOOGLE_SANDBOX] = 'SPECIAL: ' . GOOGLE_SANDBOX;
        $payment_pages[GOOGLE_LIVE] = 'SPECIAL: ' . GOOGLE_LIVE;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[GOOGLE_SANDBOX] = $this;
        $payment_options[GOOGLE_LIVE] = $this;
    }
    
    function get_name() {
        return "google";
    }
    
    function get_view_settings($model) {
        $model[GOOGLE_MERCHANT_ID] = yak_get_option(GOOGLE_MERCHANT_ID, '');
        $model[GOOGLE_MERCHANT_KEY] = yak_get_option(GOOGLE_MERCHANT_KEY, '');
        $model[GOOGLE_SHIPPING_METHOD] = yak_get_option(GOOGLE_SHIPPING_METHOD, '');
        $model[GOOGLE_EDIT_CART_URL] = yak_get_option(GOOGLE_EDIT_CART_URL, '');
        $model[GOOGLE_CONTINUE_URL] = yak_get_option(GOOGLE_CONTINUE_URL, '');
        
        ?>
        <h3><?php _e('Google settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('Merchant ID', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo GOOGLE_MERCHANT_ID ?>" value="<?php echo $model[GOOGLE_MERCHANT_ID] ?>" /></td>
            </tr>
            <tr>
                <th><?php _e('Merchant Key', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo GOOGLE_MERCHANT_KEY ?>" value="<?php echo $model[GOOGLE_MERCHANT_KEY] ?>" /></td>
            </tr>
            <tr>
                <th><?php _e('Shipping Method', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo GOOGLE_SHIPPING_METHOD ?>" value="<?php echo $model[GOOGLE_SHIPPING_METHOD] ?>" /><br />
                <i><?php _e('For example: Royal Mail Ground, UPS Air, etc', 'yak-admin') ?></i></td>
            </tr>
        </table>
        <?php
    }
    
    function apply_options() {
        yak_admin_options_set(GOOGLE_MERCHANT_ID);
        yak_admin_options_set(GOOGLE_MERCHANT_KEY);
        yak_admin_options_set(GOOGLE_SHIPPING_METHOD);
        yak_admin_options_set(GOOGLE_EDIT_CART_URL);
        yak_admin_options_set(GOOGLE_CONTINUE_URL);
    }
    
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        $ptypeval = $payment_types[$payment_type];
        
        $merchant_id = yak_get_option(GOOGLE_MERCHANT_ID);
        $merchant_key = yak_get_option(GOOGLE_MERCHANT_KEY);
        $ccy = yak_get_option(CURRENCY_CODE, 'USD');
        
        if ($ptypeval == GOOGLE_SANDBOX) {
            $server_type = 'sandbox';   
        }
        else {
            $server_type = 'production';
        }
        
        $cart = new GoogleCart($merchant_id, $merchant_key, $server_type, $ccy);
        
        $shipping_method = yak_get_option(GOOGLE_SHIPPING_METHOD, null);
        
        $total_items = 0.0;
        foreach ($items as $key => $item) {
            $total_items += $item->quantity;
        }        
        
        foreach ($items as $key => $item) {            
            $item = new GoogleItem(yak_get_title($item->id, $item->cat_id), null, $item->quantity, $item->get_discount_price());
            $cart->AddItem($item);
        }
        
        $shipping = new GoogleFlatRateShipping($shipping_method, $shippingcost);
        $shippingfilter = new GoogleShippingFilters();
        $shippingfilter->SetAllowedWorldArea(true);
        
        $shipping->AddShippingRestrictions($shippingfilter);
        $cart->AddShipping($shipping);
        
        $order_num = yak_get_order_num($order_id);
        
        $prvdata = new MerchantPrivateData(array('order-id' => $order_id, 'order-num' => $order_num));
        $cart->SetMerchantPrivateData($prvdata);
        
        //$cart->SetEditCartUrl(yak_get_url(yak_get_option(GOOGLE_EDIT_CART_URL, '')));
        //$cart->SetContinueShoppingUrl(yak_get_url(yak_get_option(GOOGLE_CONTINUE_URL, '')));
        
        yak_log("xml is " . $cart->GetXml());
        
        yak_cleanup_after_order();
        list($status, $error) = $cart->CheckoutServer2Server();
        yak_log("status=$status error=$error");
        echo $error;
    }
}

new GooglePayment();
?>