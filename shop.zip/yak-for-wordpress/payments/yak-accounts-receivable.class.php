<?php
/*
See yak-for-wordpress.php for information and license terms
*/

define("ACCOUNTS_RECEIVABLE", "Accounts Receivable");
define("ACC_RECV_LANDING_PAGE", "yak_accrecv_landing_page");
define("ACC_RECV_LABEL", "yak_accrecv_label");

class AccountsReceivablePayment extends Payment {
    
    function AccountsReceivablePayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[ACCOUNTS_RECEIVABLE] = 'SPECIAL: ' . ACCOUNTS_RECEIVABLE;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[ACCOUNTS_RECEIVABLE] = $this;
    }
    
    function get_name() {
        return "accounts_receivable";
    }
    
    function get_view_settings($model) {
        $model[ACC_RECV_LANDING_PAGE] = yak_get_option(ACC_RECV_LANDING_PAGE, '');
        $model[ACC_RECV_LABEL] = yak_get_option(ACC_RECV_LABEL, '');
        ?>
        <h3><?php _e('Accounts Receivable settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('Landing Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, ACC_RECV_LANDING_PAGE, $model[ACC_RECV_LANDING_PAGE], $model[PAGES]) ?><br />
                <i><?php _e('Final page for a successful Accounts Receivable order.', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Label', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo ACC_RECV_LABEL ?>" value="<?php echo $model[ACC_RECV_LABEL] ?>" /><br />
                <i><?php _e('Label to use on the accounts receivable form (for example, IMS, Premium account, etc)', 'yak-admin') ?></i></td>
            </tr>
        </table>
        <?php
    }
    
    function apply_options() {
        yak_admin_options_set(ACC_RECV_LANDING_PAGE);
        yak_admin_options_set(ACC_RECV_LABEL);
    }
    
    function get_next_action() {
        return 'accrecv';
    }
    
    function confirm_order($order_id, $items) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_meta_table =& $registry->get('order_meta_table');
        
        $accrecv = $_SESSION['accrecv'];
        $accrecv_number = $accrecv['number'];
        $accrecv_name = $accrecv['name'];
        
        $label = yak_get_option(ACC_RECV_LABEL);
        
        $wpdb->query("insert into $order_meta_table (order_id, name, value) 
                      values ($order_id, '$label number', '$accrecv_number')");
                      
        $wpdb->query("insert into $order_meta_table (order_id, name, value) 
                      values ($order_id, '$label name', '$accrecv_name')");
    }
    
    function redirect($payment_type, $order_id, $items, $shippingcost) {   
        $uri = yak_get_option(ACC_RECV_LANDING_PAGE, '');

        return yak_redirect_page($order_id, $items, $shippingcost, true, $uri);
    }
    
}

new AccountsReceivablePayment();
?>