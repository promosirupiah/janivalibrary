<?php
/*
See yak-for-wordpress.php for information and license terms
*/

define("AUTHORIZE_NET_TEST", "Authorize.net (Test)");
define("AUTHORIZE_NET", "Authorize.net");
define("AUTHORIZE_NET_TEST_URL", "https://test.authorize.net/gateway/transact.dll");
define("AUTHORIZE_NET_URL", "https://secure.authorize.net/gateway/transact.dll");

define("AUTHORIZE_NET_LOGIN_ID", "yak_authorize_login_id");
define("AUTHORIZE_NET_TRANS_KEY", "yak_authorize_trans_key");
define("AUTHORIZE_NET_LANDING_PAGE", "yak_authorize_landing_page");
define("AUTHORIZE_NET_ERROR_PAGE", "yak_authorize_error_page");
define("AUTHORIZE_NET_TEST_MODE", "yak_authorize_test_mode");

class AuthorizeNetPayment extends Payment {
    
    function AuthorizeNetPayment() {
        $registry =& Registry::getInstance();
        $payment_pages =& $registry->get('payment_pages');
        
        $payment_pages[AUTHORIZE_NET_TEST] = 'SPECIAL: ' . AUTHORIZE_NET_TEST;
        $payment_pages[AUTHORIZE_NET] = 'SPECIAL: ' . AUTHORIZE_NET;
        
        $payment_options =& $registry->get('payment_options');
        $payment_options[AUTHORIZE_NET_TEST] = $this;
        $payment_options[AUTHORIZE_NET] = $this;
    }
    
    function get_name() {
        return "authorize.net";
    }
    
    function get_view_settings($model) {
        $model[AUTHORIZE_NET_LOGIN_ID] = yak_get_option(AUTHORIZE_NET_LOGIN_ID, '');
        $model[AUTHORIZE_NET_TRANS_KEY] = yak_get_option(AUTHORIZE_NET_TRANS_KEY, '');
        $model[AUTHORIZE_NET_LANDING_PAGE] = yak_get_option(AUTHORIZE_NET_LANDING_PAGE, '');
        $model[AUTHORIZE_NET_ERROR_PAGE] = yak_get_option(AUTHORIZE_NET_ERROR_PAGE, '');
        $model[AUTHORIZE_NET_TEST_MODE] = yak_get_option(AUTHORIZE_NET_TEST_MODE, '');
        
        ?>
        <h3><?php _e('Authorize.net settings', 'yak-admin') ?></h3>

        <table class="form-table">
            <tr>
                <th><?php _e('API Login ID', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo AUTHORIZE_NET_LOGIN_ID ?>" value="<?php echo $model[AUTHORIZE_NET_LOGIN_ID] ?>" /></td>
            </tr>
            <tr>
                <th><?php _e('Transaction Key', 'yak-admin') ?></th>
                <td><input type="text" name="<?php echo AUTHORIZE_NET_TRANS_KEY ?>" value="<?php echo $model[AUTHORIZE_NET_TRANS_KEY] ?>" /></td>
            </tr>
            <tr>
                <th><?php _e('Landing Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, AUTHORIZE_NET_LANDING_PAGE, $model[AUTHORIZE_NET_LANDING_PAGE], $model[PAGES]) ?><br />
                <i><?php _e('Final page for a successful credit card order through authorize.net', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Error Page', 'yak-admin') ?></th>
                <td><?php echo yak_html_select(null, AUTHORIZE_NET_ERROR_PAGE, $model[AUTHORIZE_NET_ERROR_PAGE], $model[PAGES]) ?><br />
                <i><?php _e('Final page for an unsuccessful credit card order through authorize.net', 'yak-admin') ?></i></td>
            </tr>
            <tr>
                <th><?php _e('Test Mode', 'yak-admin') ?></th>
                <td><input type="checkbox" name="<?php echo AUTHORIZE_NET_TEST_MODE ?>" <?php yak_html_checkbox($model[AUTHORIZE_NET_TEST_MODE]) ?> /><br />
                <i><?php _e('Set the test mode flag on', 'yak-admin') ?></i></td>
            </tr>
        </table>
        <?php
    }
    
    function apply_options() {
        yak_admin_options_set(AUTHORIZE_NET_LOGIN_ID);
        yak_admin_options_set(AUTHORIZE_NET_TRANS_KEY);
        yak_admin_options_set(AUTHORIZE_NET_LANDING_PAGE);
        yak_admin_options_set(AUTHORIZE_NET_ERROR_PAGE);
        yak_admin_options_set(AUTHORIZE_NET_TEST_MODE, 'off');
    }
    
    function get_next_action() {
        return 'cc';
    }
    
    /**
     * Use Authorize.net to submit credit card transaction details.  Pass result to redirect page if successful.
     */
    function redirect($payment_type, $order_id, $items, $shippingcost) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        
        $cc = $_SESSION['cc'];
        
        $value = yak_order_value(false, $order_id);
        
        // Get Billing Address
        $baddress = yak_get_address('billing', false);

        // Get First and Last name
        $arr = split("[\n\r\t ]+", $baddress->recipient);
        $firstname = $arr[0];
        $lastname = $arr[1];

        // Get Shipping Address
        $saddress = yak_get_address('shipping', false);  

        // Get First and Last name for shipping address
        $arr2 = split("[\n\r\t ]+", $saddress->recipient);
        $s_firstname = $arr2[0];
        $s_lastname = $arr2[1];
                
        // Create Customer ID
        $cust_id = rand(1000000000, 9999999999);
        
        $params_array = array(
            'x_login'              => yak_get_option(AUTHORIZE_NET_LOGIN_ID),
            'x_tran_key'           => yak_get_option(AUTHORIZE_NET_TRANS_KEY),
            'x_version'            => '3.1',
            'x_delim_char'         => '|',
            'x_delim_data'         => 'TRUE',
            'x_method'             => 'CC',
            'x_relay_response'     => 'FALSE',
            'x_type'               => 'AUTH_CAPTURE',
            'x_amount'             => number_format($value, 2, '.', ''),
            'x_card_num'           => $cc['number'],
            'x_exp_date'           => $cc['expiry'],
            'x_card_code'          => $cc['security_code'],
            'x_trans_id'           => $order_id,
            'x_description'        => get_bloginfo('description') . ' Products',
            'c_cust_id'            => $cust_id,
            'x_country'            => $baddress->country,
            'x_zip'                => $baddress->postcode,
            'x_city'               => $baddress->city,
            'x_phone'              => $baddress->phone,
            'x_address'            => $baddress->addr1,
            'x_state'              => $baddress->get_state_or_region(),
            'x_email'              => $baddress->email,
            'x_first_name'         => $firstname,
            'x_last_name'          => $lastname,
            'x_ship_to_country'    => $saddress->country,
            'x_ship_to_zip'        => $saddress->postcode,
            'x_ship_to_city'       => $saddress->city,
            'x_ship_to_phone'      => $saddress->phone,
            'x_ship_to_address'    => $saddress->addr1,
            'x_ship_to_state'      => $saddress->get_state_or_region(),
            'x_ship_to_first_name' => $s_firstname,
            'x_ship_to_last_name'  => $s_lastname
        );
        
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        if ($payment_types[$payment_type] == AUTHORIZE_NET) {
            $url = AUTHORIZE_NET_URL;
        }
        else {
            $url = AUTHORIZE_NET_TEST_URL;
        }
        
        if (yak_get_option(AUTHORIZE_NET_TEST_MODE, 'off') == 'on') {
            $params_array['x_test_request'] = 'TRUE';
        }
        
        $params = yak_encode_params($params_array);
        
        yak_log("Using URL: " . $url);

        $redirect_uri = yak_get_option(AUTHORIZE_NET_LANDING_PAGE, '');
        
        if ($value > 0.0) {
            $response = yak_do_http($url, '', $params);

            $split = explode('|', $response);
        
            $rtn = "";
            if ($split[0] == 1) {
                $wpdb->query("update $order_table set funds_received = $value where id = $order_id");
                  
                yak_insert_orderlog($order_id, 'Authorize.net transaction was approved');
                  
                $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);
            }
            else if ($split[0] == 2) {
                $_SESSION['error_message'] = __('The transaction has been declined', 'yak');
            
                $wpdb->query("update $order_table set status = '" . ERROR . "' where id = $order_id");

                yak_insert_orderlog($order_id, 'Authorize.net transaction was declined');
            
                $rtn = yak_get_option(AUTHORIZE_NET_ERROR_PAGE, '');
            }
            else if ($split[0] == 3) {
                $err = $split[3];
            
                $wpdb->query("update $order_table set status = '" . ERROR . "' where id = $order_id");
            
                yak_insert_orderlog($order_id, 'An error occurred processing the Authorize.net transaction: ' . $err);
                $_SESSION['error_message'] = $err;
            
                $rtn = yak_get_option(AUTHORIZE_NET_ERROR_PAGE, '');
            }
            else {
                yak_insert_orderlog($order_id, 'Authorize.net transaction is held for review -- please resolve manually');
        
                $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);
            }
        
            yak_insert_orderlog($order_id, 'response received from Authorize.net was: ' . $response);
        }
        else {
            // no order value -- just redirect to the success page
            $rtn = yak_redirect_page($order_id, $items, $shippingcost, true, $redirect_uri);
            yak_insert_orderlog($order_id, 'Total order cost is 0, not submitting to Authorize.net');
        }
        
        yak_check_order($order_id);
    
        return $rtn;
    }
}

new AuthorizeNetPayment();
?>