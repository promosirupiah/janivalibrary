<?php
/*
See yak-for-wordpress.php for information and license terms
*/
if (file_exists(ABSPATH . 'wp-includes/l10n.php')) {
    require_once(ABSPATH . 'wp-includes/l10n.php');
}
else {
    require_once(ABSPATH . 'wp-includes/wp-l10n.php');
}

global $model;

global $sep_billing;
$sep_billing = (yak_get_option(ADDRESS_SEPARATE_BILLING, '') == 'on');

global $state_text, $region_text;
$state_text = __('State', 'yak') . '&nbsp;:';
$region_text = __('Region', 'yak') . '&nbsp;:';

function address_entry($prefix) {
    global $countries, $sep_billing, $states, $canada_states, $state_text, $region_text;

    $enabled_countries = yak_get_option(ENABLED_COUNTRIES, $countries);    
?>

    <table class="yak_left">
        <col width="30%" />
        <col width="70%" />
        <tr>
            <th colspan="2">
                <?php 
                    if ($prefix == 'shipping') {
                        _e("Enter a new shipping address", 'yak');
                    }
                    else {
                        _e("Enter a new billing address", 'yak');                        
                    }
                ?>
            </th>
        </tr>
<?php
        if (yak_get_option(ADDRESS_NAME, '') == 'on') {
?>
        <tr>
            <td><?php echo _e('Name', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_recipient" value="<?php echo $_POST[$prefix . '_recipient'] ?>" size="40" maxlength="60" /></td>
        </tr>
<?php
        }
?>        
        <tr>
            <td><?php echo _e('Email', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_email" value="<?php echo $_POST[$prefix . '_email'] ?>" size="40" maxlength="80" /></td>
        </tr>
<?php
        
        if (yak_get_option(ADDRESS_PHONE, '') == 'on') {
?>
        <tr>
            <td><?php echo _e('Phone Number', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_phone" value="<?php echo $_POST[$prefix . '_phone'] ?>" size="15" maxlength="15" /></td>
        </tr>
<?php
        }
        
        if (yak_get_option(ADDRESS, '') == 'on') {
?>
        <tr>
            <td><?php echo _e('Address Line 1', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_addr1" value="<?php echo $_POST[$prefix . '_addr1'] ?>" size="40" maxlength="60"  /></td>
        </tr>
        <tr>
            <td><?php echo _e('Address Line 2', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_addr2" value="<?php echo $_POST[$prefix . '_addr2'] ?>" size="40" maxlength="60" /></td>
        </tr>
        <tr>
            <td><?php echo _e('Suburb', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_suburb" value="<?php echo $_POST[$prefix . '_suburb'] ?>" size="20" maxlength="40"  /></td>
        </tr>
        <tr>
            <td><?php echo _e('City', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_city" value="<?php echo $_POST[$prefix . '_city'] ?>" size="20" maxlength="40" /></td>
        </tr>
        <tr>
            <td id="<?php echo $prefix . '_region_label' ?>"><?php echo _e('Region', 'yak') ?>&nbsp;: </td>
            <td><input id="<?php echo $prefix . '_region_input' ?>" type="text" name="<?php echo $prefix ?>_region" value="<?php echo $_POST[$prefix . '_region'] ?>" size="20" maxlength="20" />
                <?php echo yak_html_select($prefix . '_state_input', $prefix . '_state', yak_default($_POST[$prefix . '_state'], ''), $states, false, null, false) ?>
                <?php echo yak_html_select($prefix . '_ca_state_input', $prefix . '_state', yak_default($_POST[$prefix . '_ca_state'], ''), $canada_states, false, null, false) ?></td>
        </tr>
        <tr>
            <td><?php echo _e('Zip/Postcode', 'yak') ?>&nbsp;: </td>
            <td><input type="text" name="<?php echo $prefix ?>_postcode" value="<?php echo $_POST[$prefix . '_postcode'] ?>" size="10" maxlength="20" /></td>
        </tr>
        <tr>
            <td><?php echo _e('Country', 'yak') ?>&nbsp;: </td>
            <td><?php echo yak_html_select($prefix . '_country_input', $prefix . '_country', yak_default($_POST[$prefix . '_country'], yak_get_option(DEFAULT_COUNTRY, '')), $enabled_countries, false, null, false, null, "changeRegion('$prefix', '$state_text', '$region_text')") ?></td>
        </tr>
<?php
        }

        if ($prefix == 'shipping' && $sep_billing) {
?>
        <tr>
            <td><?php echo _e('Use shipping address as billing address', 'yak') ?></td>
            <td><input type="checkbox" name="shipping_is_billing" checked="checked" onclick="javascript:billing()" /></td>
        </tr>
<?php
        }
?>
    </table>
<?php
}

if (isset($model['error_message'])) {
?>
<div class="yak_error"><?php echo $model['error_message'] ?></div>
<?php
}

if (isset($model['shipping_address']) && $model['shipping_address'] != null) {
?>

<form id="oldaddress" name="oldaddress" method="post" action="<?php echo get_bloginfo('wpurl') ?>/?stage=address">

<?php
    include 'yak-view-address-snippet.php';
    
    yak_address_hidden_input($model['shipping_address'], 'shipping');
    yak_address_hidden_input($model['billing_address'], 'billing');
?>

    <p class="yak_left">
        <button id="shippingbutton" class="yak_button" type="submit"><?php _e('Use this address', 'yak') ?></button>
        <button id="editaddress" class="yak_button" type="button" onclick="editAddress('<?php echo $state_text ?>', '<?php echo $region_text ?>')"><?php _e('Edit this address', 'yak') ?></button></td>
    </p>

    <input type="hidden" name="action" value="confirm" />
    <input type="hidden" name="<?php echo $model['param_name'] ?>" value="<?php echo $model['post_id'] ?>" />
</form>
        
<?php
}
?>

<form id="address" name="address" method="post" action="<?php echo get_bloginfo('wpurl') ?>/?stage=address">    
<?php
    address_entry('shipping');

    if ($sep_billing) {
?>
    <div id="billing" style="visibility: hidden; display: none">
<?php    
        address_entry('billing');
?>
    </div>
<?php
    }
?>
    <p class="yak_left">
        <button id="billingbutton" class="yak_button" type="submit"><?php _e('Use this address', 'yak') ?></button>
    </p>        
    <input type="hidden" name="action" value="confirm" />
    <input type="hidden" name="<?php echo $model['param_name'] ?>" value="<?php echo $model['post_id'] ?>" />
</form>
<script type="text/javascript">
<!--
changeRegion('shipping', '<?php global $state_text; echo $state_text ?>', '<?php global $region_text; echo $region_text ?>');
changeRegion('billing', '<?php global $state_text; echo $state_text ?>', '<?php global $region_text; echo $region_text ?>');
-->
</script>