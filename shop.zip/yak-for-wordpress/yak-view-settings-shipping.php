<?php
/*
See yak-for-wordpress.php for information and license terms
*/
require_once('yak-utils.php');

global $model, $countries;

$imgbase = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/images';

wp_nonce_field('update-options');

$registry =& Registry::getInstance();

$weight_val = $model[SHIPPING_WEIGHT_CALC];
if (empty($weight_val)) {
    $weight_val = DEFAULT_SHIPPING_WEIGHT_CALC;
}
?>

<div class="wrap">
    <input type="hidden" name="section" value="options" />

<div id="tabs">
    <ul class="tabs-nav">
        <li><a id="basic-tab" href="#fragment-1"><span><?php _e('Basic', 'yak-admin') ?></span></a></li>
        <li><a id="zones-tab" href="#fragment-2"><span><?php _e('Zones', 'yak-admin') ?></span></a></li>
        <li><a id="options-tab" href="#fragment-3"><span><?php _e('Options', 'yak-admin') ?></span></a></li>
    </ul>    

    <div class="clear"></div>

    <div id="fragment-1" class="tabs-container">
        <h2><?php _e('Basic Shipping Settings', 'yak-admin') ?></h2>
        
        <form name="settingsFrm1" method="post" action="#fragment-1">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Include Shipping Costs', 'yak-admin') ?></th>
                    <td><?php echo yak_html_select(null, INCLUDE_SHIPPING_COSTS, $model[INCLUDE_SHIPPING_COSTS], array("yes"=>"yes", "no"=>"no")) ?><br />
                    <i><?php _e('Include shipping costs in order totals?', 'yak-admin') ?></i></td>
                </tr>
                
                <tr valign="top">
                    <th scope="row"><?php _e('Cookie Lifetime (days)', 'yak-admin') ?></th>
                    <td><input type="text" name="<?php echo COOKIE_LIFETIME ?>" value="<?php echo $model[COOKIE_LIFETIME] ?>" /><br />
                    <i><?php _e('How long should the customer\'s address cookie be stored on their machine?', 'yak-admin') ?></i></td>
                </tr>
                
                <tr valign="top">
                    <th scope="row"><?php _e('Default Country', 'yak-admin') ?></th>
                    <td><?php echo yak_html_select(null, DEFAULT_COUNTRY, $model[DEFAULT_COUNTRY], $countries) ?><br />
                    <i><?php _e('What country should be preselected in the dropdown?', 'yak-admin') ?></i></td>
                </tr>
                
                <tr valign="top">
                    <th scope="row"><?php _e('Shipping Address', 'yak-admin') ?></th>
                    <td>
                    <label for="<?php echo ADDRESS_NAME ?>"> <input type="checkbox" id="<?php echo ADDRESS_NAME ?>" name="<?php echo ADDRESS_NAME ?>" <?php yak_html_checkbox($model[ADDRESS_NAME]) ?> /><?php _e('Include Name', 'yak-admin') ?></label><br />
                    <label for="<?php echo ADDRESS_PHONE ?>"> <input type="checkbox" id="<?php echo ADDRESS_PHONE ?>" name="<?php echo ADDRESS_PHONE ?>" <?php yak_html_checkbox($model[ADDRESS_PHONE]) ?> /><?php _e('Include Phone', 'yak-admin') ?></label><br />
                    <label for="<?php echo ADDRESS ?>"> <input type="checkbox" id="<?php echo ADDRESS ?>" name="<?php echo ADDRESS ?>" <?php yak_html_checkbox($model[ADDRESS]) ?> /><?php _e('Include Address', 'yak-admin') ?></label><br />
                    <label for="<?php echo ADDRESS_SEPARATE_BILLING ?>"> <input type="checkbox" id="<?php echo ADDRESS_SEPARATE_BILLING ?>" name="<?php echo ADDRESS_SEPARATE_BILLING ?>" <?php yak_html_checkbox($model[ADDRESS_SEPARATE_BILLING]) ?> /> <?php _e('Separate Billing Address', 'yak-admin') ?></label><br />
                    <i><?php _e('What fields are required for shipping address (email is required by default).', 'yak-admin') ?></i>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('Shipping Notes', 'yak-admin') ?></th>
                    <td><textarea cols="40" rows="2" name="<?php echo SHIPPING_NOTES ?>"><?php echo $model[SHIPPING_NOTES] ?></textarea><br />
                    <i><?php _e('Notes about shipping to add to the bottom of the confirmation screen.', 'yak-admin') ?></i></td>
                </tr>

                <tr valign="top">
                    <th scope="row"><?php _e('Shipping weight calculation value', 'yak-admin') ?></th>
                    <td><input type="text" id="<?php echo SHIPPING_WEIGHT_CALC ?>" name="<?php echo SHIPPING_WEIGHT_CALC ?>" value="<?php echo $model[SHIPPING_WEIGHT_CALC] ?>" /><br />
                        <i><?php _e('The weight value, in grams, that should be used for calculating shipping cost. This defaults to 100gms if not set and is used for the "shipping first" calculation and then the subsequent "per x grams" calculation.', 'yak-admin') ?></i></td>
                </tr>
                
                <tr valign="top">
                    <th scope="row"><?php _e('Shipping options', 'yak-admin') ?></th>
                    <td><textarea id="<?php echo SHIPPING_OPTION_NAMES ?>" name="<?php echo SHIPPING_OPTION_NAMES ?>"><?php echo $model[SHIPPING_OPTION_NAMES] ?></textarea><br />
                        <i><?php _e('A list of shipping options (separated by newlines). These will be displayed in a dropdown from which the customer can select.', 'yak-admin') ?></i></td>
                </tr>
            </table>
            
            <div class="submit">
                <input type="submit" name="options_update1" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm1', 'fragment-1')" />
            </div>
        </form>
    </div>

    <div id="fragment-2" class="tabs-container">
        <h2><?php _e('Shipping Zones', 'yak-admin') ?></h2>
        
        <form id="settingsFrm2" name="settingsFrm2" method="post" action="#fragment-2">
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php _e('Country', 'yak-admin') ?></th>
                    <th><?php _e('Zone', 'yak-admin') ?> <button id="clear_zones" type="button" onclick="clearInputs('settingsFrm2')"><?php _e('Clear zones', 'yak-admin') ?></button></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($countries as $country=>$ignore) { 
                $ctyname = $countries[$country];    
            ?>
                <tr>
                    <td><?php echo $ctyname ?></td>
                    <td><input type="text" size="2" name="<?php echo 'yak_' . $country . '_zone' ?>" value="<?php echo $model['yak_' . $country . '_zone'] ?>" /></td>
                </tr>
            <?php } ?>
                </tbody>
            </table>
            
            <div class="submit">
                <input type="submit" name="options_update2" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm2', 'fragment-2')" />
            </div>
        </form>
    </div>
    
    <div id="fragment-3" class="tabs-container">
        <h2><?php _e('Shipping Options', 'yak-admin') ?></h2>
        
        <form name="settingsFrm3" method="post" action="#fragment-3">
        <?php foreach ($model[SHIPPING_OPTIONS] as $shipping_option) { ?>
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php _e('Option:', 'yak-admin') ?> <?php echo $shipping_option->name ?></th>
                    <th colspan="3"></th>
                </tr>
                <tr>
                    <th><?php _e('Zone', 'yak-admin') ?></th>
                    <th><?php _e('Fixed Total Cost', 'yak-admin') ?></th>
                    <th><?php _e('Fixed Cost per item', 'yak-admin') ?><br />
                        <?php _e('(First/Subsequent)', 'yak-admin') ?></th>
                    <th><?php _ye('Cost per %s gm', 'yak-admin', $weight_val) ?><br />
                        <?php _ye('(First %s gm/Subsequent)', 'yak-admin', $weight_val) ?></th>
                </tr>
                <?php foreach ($shipping_option->zones as $zone) { 
                    $prefix = 'yak_' . $shipping_option->code . '_' . $zone->zone;
                ?>
                <tr>
                    <th><?php _e('Zone', 'yak-admin') ?> <?php echo $zone->zone ?> <span style="font-size: xx-small">(<?php echo $zone->get_countries_list() ?>)</span></th>
                    <td><input type="text" size="5" name="<?php echo $prefix . '_shp_fixed' ?>" value="<?php echo $zone->fixed ?>" /></td>
                    <td><input type="text" size="5" name="<?php echo $prefix . '_shp_fixeditemfirst' ?>" value="<?php echo $zone->fixeditemfirst ?>" />
                        <input type="text" size="5" name="<?php echo $prefix . '_shp_fixeditem' ?>" value="<?php echo $zone->fixeditem ?>" /></td>
                    <td><input type="text" size="5" name="<?php echo $prefix . '_shp_weightfirst' ?>" value="<?php echo $zone->weightfirst ?>" />
                        <input type="text" size="5" name="<?php echo $prefix . '_shp_weight' ?>" value="<?php echo $zone->weight ?>" /></td>
                </tr>
                <?php } ?>
            </thead>
            <tbody>
        </table>
        <br />
        <?php } ?>
            
        <div class="submit">
            <input type="submit" name="options_update3" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm3', 'fragment-3')" />
        </div>
        
        </form>
        
    </div>
    
</div>