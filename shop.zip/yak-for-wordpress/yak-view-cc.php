<?php
/*
See yak-for-wordpress.php for information and license terms
*/
if (file_exists(ABSPATH . 'wp-includes/l10n.php')) {
    require_once(ABSPATH . 'wp-includes/l10n.php');
}
else {
    require_once(ABSPATH . 'wp-includes/wp-l10n.php');
}

global $model;

if (isset($model['error_message'])) {
?>

<div class="yak_error"><?php echo $model['error_message'] ?></div>

<?php
}
?>

<form name="cc" method="post" action="<?php echo get_bloginfo('wpurl') ?>/?stage=cc">
    <table class="yak_left">
        <tr>
            <td colspan="2"><?php _e('Please enter your credit card details', 'yak') ?></td>
        </tr>
        <tr>
            <td><?php echo _e('Card Type', 'yak') ?> : </td>
            <td><?php echo yak_html_select(null, 'cc_type', yak_default($_POST['cc_type'], ''), $model['cc_types']) ?></td>
        </tr>
        <tr>
            <td><?php echo _e('Credit Card No.', 'yak') ?> : </td>
            <td><input type="text" name="cc_number" value="<?php echo $_POST['cc_number'] ?>" size="20" /></td>
        </tr>
        <tr>
            <td><?php echo _e('Security Code', 'yak') ?>
                <a style="font-size: x-small" href="http://en.wikipedia.org/wiki/Card_Security_Code" target="_BLANK">[?]</a> : </td>
            <td><input type="text" name="cc_security_code" value="<?php echo $_POST['cc_security_code'] ?>" size="6" maxlength="4" /></td>
        </tr>
        <tr>
            <td><?php echo _e('Cardholder\'s Name', 'yak') ?> : </td>
            <td><input type="text" name="cc_name" value="<?php echo $_POST['cc_name'] ?>" size="20" maxlength="40" /></td>
        </tr>
        <tr>
            <td><?php echo _e('Expiry Date', 'yak') ?> : </td>
            <td><?php echo yak_html_select(null, 'cc_expiry_month', yak_default($_POST['cc_expiry_month'], ''), $model['cc_expiry_months']) ?> <?php echo yak_html_select(null, 'cc_expiry_year', yak_default($_POST['cc_expiry_year'], ''), $model['cc_expiry_years']) ?></td>
        </tr>
        <tr>
            <td colspan="2"><button id="confirmbutton" class="yak_medium_button" type="submit"><?php _e('Next', 'yak') ?></button><br />
                <span class="yak_small"><?php echo _e('Note: You have a final chance to confirm/cancel the order on the following screen.', 'yak')?></span></td>
        </tr>
    </table>        
    <input type="hidden" name="action" value="confirm_cc" />
    <input type="hidden" name="<?php echo $model['param_name'] ?>" value="<?php echo $model['post_id'] ?>" />
    <input type="hidden" name="shipping_country" value="<?php echo $_POST['shipping_country'] ?>" />
</form>
