<?php
class YakOrderWidget {    
    function widget($args) {
        if (isset($_SESSION['current_order_value'])) {
            echo $args['before_widget'];
            echo $args['before_title'] . __('Your Shopping Basket', 'yak') . $args['after_title'];
            echo __('Items in basket', 'yak') . ': ' . $_SESSION['current_order_items'] . '<br />';
            echo __('Subtotal', 'yak') . ': ' . yak_format_money($_SESSION['current_order_value'], true);
            echo $args['after_widget'];
        }
    }
    
    function register() {
        register_sidebar_widget('Yak Order Panel', array('YakOrderWidget', 'widget'));
    }
}
?>