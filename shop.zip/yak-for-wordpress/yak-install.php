<?php
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

global $wpdb;

if ($wpdb->has_cap('collation')) {
	if (!empty($wpdb->charset)) {
		$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		$convert_charset_collate = "CHARACTER SET $wpdb->charset";
	}
	if (!empty($wpdb->collate)) {
		$charset_collate .= " COLLATE $wpdb->collate";
		$convert_charset_collate .= " COLLATE $wpdb->collate";
	}
}

$current_version = get_option(YAK_VERSION);

// installation defaults        
if (yak_get_option(ADDRESS_NAME, '') == '') {
    update_option(ADDRESS_NAME, 'on');
}

if (yak_get_option(ADDRESS_PHONE, '') == '') {
    update_option(ADDRESS_PHONE, 'on');
}

if (yak_get_option(ADDRESS, '') == '') {
    update_option(ADDRESS, 'on');
}

if (yak_get_option(ADDRESS_SEPARATE_BILLING, '') == '') {
    update_option(ADDRESS_SEPARATE_BILLING, 'on');
}

$registry =& Registry::getInstance();
$order_table =& $registry->get('order_table');
$order_num_index =& $registry->get('order_num_index');
$order_log_table =& $registry->get('order_log_table');
$order_meta_table =& $registry->get('order_meta_table');
$order_meta_index =& $registry->get('order_meta_index');
$order_detail_table =& $registry->get('order_detail_table');
$order_detail_index =& $registry->get('order_detail_index');
$order_dl_table =& $registry->get('order_dl_table');
$product_table =& $registry->get('product_table');
$product_detail_table =& $registry->get('product_detail_table');
$token_table =& $registry->get('token_table');
$promo_table =& $registry->get('promo_table');
$promo_index =& $registry->get('promo_index');
$promo_users_table =& $registry->get('promo_users_table');

// Order table        
if ($wpdb->get_var("show tables like '$order_table'") != $order_table) {
    $sql = "create table " . $order_table . " (
            id mediumint(9) primary key not null auto_increment,
            time timestamp not null,
            user_id bigint(20) unsigned,
            recipient_name varchar(200),
            address text not null,
            country_code varchar(3),
            funds_received float default '0.0',
            shipping_cost float default '0.0',
            payment_type varchar(30),
            status varchar(10) default '' not null,
            billing_address text,
            billing_country_code varchar(3),
            order_num varchar(32),
            index $order_num_index (order_num)
            ) $charset_collate;";
    yak_log("creating table $order_table");
    $wpdb->query($sql);
}

// Order Meta table
if ($wpdb->get_var("show tables like '$order_meta_table'") != $order_meta_table) {
    $sql = "create table $order_meta_table (
            id mediumint(9) primary key not null auto_increment,
            order_id mediumint(9) not null,
            name varchar(100) not null,
            value varchar(255),
            index $order_meta_index (order_id, name)
            ) $charset_collate;";
    yak_log("creating table $order_meta_table");
    $wpdb->query($sql);
}

// Order Detail table
if ($wpdb->get_var("show tables like '$order_detail_table'") != $order_detail_table) {
    $sql = "create table $order_detail_table (
            id mediumint(9) not null,
            itemname text not null,
            price float not null,
            quantity smallint default '1' not null,
            post_id bigint(20) unsigned,
            cat_id bigint(20),
            index $order_detail_index (id)
            ) $charset_collate;";
    yak_log("creating table $order_detail_table");
    $wpdb->query($sql);
}
        
// Order Log table
if ($wpdb->get_var("show tables like '$order_log_table'") != $order_log_table) {
    $sql = "create table $order_log_table (
            time timestamp not null,
            message text not null,
            order_id mediumint(9)
            ) $charset_collate;";
    yak_log("creating table $order_log_table");
    $wpdb->query($sql);
} 

// Order Download table
if ($wpdb->get_var("show tables like '$order_dl_table'") != $order_dl_table) {
    $sql = "create table $order_dl_table (
            id mediumint(9) primary key not null auto_increment,
            order_id mediumint(9) not null,
            uid text,
            dl_file text not null,
            download_attempts smallint,
            download_address text
            ) $charset_collate;";
    yak_log("creating table $order_dl_table");
    $wpdb->query($sql);  
}

// Product table
if ($wpdb->get_var("show tables like '$product_table'") != $product_table) {
    $sql = "create table $product_table (
            post_id mediumint(9) not null,
            product_code varchar(30),
            price float not null,
            alt_title varchar(255),
            primary key (post_id)
            ) $charset_collate;";
    yak_log("creating table $product_table");
    $wpdb->query($sql);
}

// Product Detail table
if ($wpdb->get_var("show tables like '$product_detail_table'") != $product_detail_table) {
    $sql = "create table $product_detail_table (
            post_id mediumint(9) not null,
            cat_id bigint(20) not null,
            quantity mediumint,
            dl_file varchar(255),
            weight int,
            primary key (post_id, cat_id)
            ) $charset_collate;";
    yak_log("creating table $product_detail_table");
    $wpdb->query($sql);
}

// Token table
if ($wpdb->get_var("show tables like '$token_table'") != $token_table) {
    $sql = "create table $token_table (
            name varchar(10) not null,
            token varchar(30) not null,
            order_id mediumint(9)
            ) $charset_collate;";
    yak_log("creating table $token_table");
    $wpdb->query($sql);
}

// Promotions table
if ($wpdb->get_var("show tables like '$promo_table'") != $promo_table) {
    $sql = "create table $promo_table (
            promo_id mediumint(9) primary key not null auto_increment,
            code varchar(20) not null,
            promo_type varchar(20) not null,
            description varchar(250),
            value float not null,
            expiry_date date
            ) $charset_collate;";
    yak_log("creating table $promo_table");
    $wpdb->query($sql);
    
    $wpdb->query("alter table $promo_table add unique index $promo_index (code)");
}

if ($wpdb->get_var("show tables like '$promo_users_table'") != $promo_users_table) {
    $sql = "create table $promo_users_table (
            promo_id mediumint(9) not null,
            user_id bigint(20) unsigned not null
            ) $charset_collate";
    yak_log("creating table $promo_users_table");
    $wpdb->query($sql);
    
    $wpdb->query("alter table $promo_users_table add foreign key (promo_id) references $promo_table (promo_id)");
}

// automatically add the Checkout page if it hasn't been created
$chk_count = @$wpdb->get_var("select count(*) from " . $wpdb->posts . " 
                              where post_content like '[yak_checkout]' 
                              and post_type = 'page'");
if (isset($chk_count) && $chk_count != '1') {
    wp_insert_post(array('post_status'=>'publish', 
                         'post_type'=>'page',
                         'post_title'=>__('Checkout', 'yak'),
                         'post_content'=>'[yak_checkout]'));
}

$options = get_option(YAK_OPTIONS);
if (isset($options)) {
    foreach ($options as $name=>$value) {
        update_option($name, $value);
    }
    delete_option(YAK_OPTIONS);
}

// automatically setup the default category, if it hasn't been created
if (yak_get_option(PRODUCT_CATEGORY_NAME, '') == '') {
    $cat_id = wp_insert_category(array('cat_name'=>'products', 'category_description'=>'root category for YAK products'));
    wp_insert_category(array('cat_name'=>'default', 'category_description'=>'default category for YAK products', 'category_parent'=>$cat_id));
    update_option(PRODUCT_CATEGORY_NAME, 'products');
}

// upgrade for previous versions of yak
if (empty($current_version)) {
    $result = $wpdb->get_results("show columns from $order_table where field = 'order_num'");
    if (sizeof($result) == 0) {
        $wpdb->query("alter table $order_table add column order_num varchar(32)");
        $wpdb->query("alter table $order_table add index $order_num_index (order_num)");
    }
    $wpdb->query("alter table $order_table modify recipient_name varchar(200) null");
}

// calculate a version 'number'
$ver = ereg_replace("[^0-9.]", "", $current_version);
$arr = split('\.', $ver);
$size = count($arr);
for ($x = 0; $x < $size; $x++) {
    $arr[$x] = str_pad($arr[$x], 3, '0', STR_PAD_LEFT);
}
$ver = join("", $arr);

if ($ver < 1001002) {
    $wpdb->query("alter table $product_detail_table add column override_price float null");
}

if ($ver < 1002001) {
    $wpdb->query("alter table $order_table add column country_code varchar(3)");
    $wpdb->query("alter table $order_table add column billing_country_code varchar(3)");
}

if ($ver < 1002007) {
    if (!empty($convert_charset_collate)) {
        $wpdb->query("alter table $order_table convert to $convert_charset_collate");
        $wpdb->query("alter table $order_log_table convert to $convert_charset_collate");
        $wpdb->query("alter table $order_meta_table convert to $convert_charset_collate");
        $wpdb->query("alter table $order_detail_table convert to $convert_charset_collate");
        $wpdb->query("alter table $order_dl_table convert to $convert_charset_collate");
        $wpdb->query("alter table $product_table convert to $convert_charset_collate");
        $wpdb->query("alter table $product_detail_table convert to $convert_charset_collate");
        $wpdb->query("alter table $token_table convert to $convert_charset_collate");
        $wpdb->query("alter table $promo_table convert to $convert_charset_collate");
    }
}

if ($ver < 1003001) {
    $wpdb->query("alter table $order_table add column user_id bigint(20) unsigned");
}

if ($ver < 1003009) {
    $wpdb->query("alter table $product_detail_table add column sku varchar(13)");
}

if ($ver < 1008000) {
    $wpdb->query("alter table $product_table add column multi_select_options text");
    $wpdb->query("alter table $product_table add column multi_select_min int");
    $wpdb->query("alter table $product_table add column multi_select_max int");
    $wpdb->query("alter table $product_table add column discount_override float");
    
    $wpdb->query("alter table $promo_table add column threshold float");
    $wpdb->query("alter table $promo_table modify column promo_type varchar(30) not null");
}

if (!isset($current_version)) {
    add_option(YAK_VERSION, YAK_VERSION_NUMBER);    
}
else {
    update_option(YAK_VERSION, YAK_VERSION_NUMBER);   
}

?>