<?php
/*
See yak-for-wordpress.php for information and license terms
*/
require_once('yak-utils.php');
require_once('yak-google-analytics.php');

global $model, $payment_url_examples, $countries, $promo_types, $currency_format, $money_format, $order_number_types;

$imgbase = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/images';

wp_nonce_field('update-options');

$registry =& Registry::getInstance();
$payment_pages =& $registry->get('payment_pages');
$payment_options =& yak_get_payment_options($registry);

$used_options = array();
?>

<div class="wrap">
    <input type="hidden" name="section" value="options" />

<div id="tabs">
    <ul class="tabs-nav">
        <li><a href="#fragment-1"><span><?php _e('About', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-2"><span><?php _e('Basic', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-3"><span><?php _e('Products price/quantity', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-4"><span><?php _e('Download', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-5"><span><?php _e('Payments', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-6"><span><?php _e('Special', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-7"><span><?php _e('Advanced', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-8"><span><?php _e('Shipping', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-9"><span><?php _e('Promotions', 'yak-admin') ?></span></a></li>
        <li><a href="#fragment-10"><span><?php _e('Analytics', 'yak-admin') ?></span></a></li>
    </ul>
        
<div class="clear"></div>

<div id="fragment-1" class="tabs-container">
<h2><?php _e('About YAK for WordPress', 'yak-admin') ?></h2>

<?php
    if (ini_get('session.auto_start') == '1') {
?>

    <p style="color: red; font-weight: bold">
        WARNING: session.auto_start is turned on in your php.ini file. YAK <i>may</i> not function correctly with this setting.<br />
        If you experience problems and don't have access to your php.ini, you may be able to resolve it by adding a <code>.htaccess</code>
        file in the WordPress root directory and adding: <code>php_value session.auto_start 0</code>
    </p>

<?php
    }
?>

    <p>YAK (Yet Another Kart) is a simple shopping cart plugin for WordPress, allowing a product to be associated
       with a post or a page, and provides support for online payment (such as PayPal), and downloadable content.<br />
       Basic step-by-step installation instructions can be found <a href="http://wordpress.org/extend/plugins/yak-for-wordpress/installation/" target="_BLANK">here</a>.
       For detailed instructions, including how to setup external payments gateways (such as Authorize.net, PayPal, etc), 
       consider purchasing the YAK <a href="http://www.briggs.net.nz/log/projects/yak-for-wordpress/handbook">Handbook</a>.</p>

    <h3>Coding</h3>
    
    <p><a href="http://www.briggs.net.nz/log">Jason R Briggs</a></p>

    <h3>Design</h3>
    
    <p><a href="http://vizualbod.com/">František Malina</a></p>
    
    <h3>Additional Libraries/Resources</h3>
    
    <p><a href="http://teethgrinder.co.uk/open-flash-chart/index.php">Open Flash Chart</a></p>
    
    <h3>International Team</h3>
    
    <p><a href="http://www.mobitemple.net">Ronny</a> (JA, TW, ZH), Soichi Yokoyama (JA), AB (TH), František Malina (SK, CS), MK (DE), 
    Romaric Drigon (FR), Roberto Mogliotti (IT), Josep Jordana (ES), Tom Boersma (NO), Marco Izzo (SE),
    Maciej Wolfart (PL), Álvaro Góis Santos (PT)</p>
    
    <h3>Testing, Ideas, Contributors, Investors, Generally-Helpful-People</h3>
    
    <p>AB, Lance Hodges, Luke Chao, František Malina, Ari Kontiainen, Chris Guthrie, Thomas Herold</p>

</div>

<div id="fragment-2" class="tabs-container">
<h2><?php _e('Basic Settings', 'yak-admin') ?></h2>
<form name="settingsFrm2" method="post" action="#fragment-2">

    <table class="form-table">
        <tr valign="top">
            <th scope="row"><?php _e('Quantity Input Size', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo QUANTITY_INPUT_SIZE ?>" value="<?php echo $model[QUANTITY_INPUT_SIZE] ?>" /><br />
            <i><?php _e('How many digits are allowed in a quantity input box?', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Cookie Lifetime (days)', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo COOKIE_LIFETIME ?>" value="<?php echo $model[COOKIE_LIFETIME] ?>" /><br />
            <i><?php _e('How long should the customer\'s address cookie be stored on their machine?', 'yak-admin') ?></i></td>
        </tr>
    
        <tr valign="top">
            <th scope="row"><?php _e('Include Shipping Costs', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, INCLUDE_SHIPPING_COSTS, $model[INCLUDE_SHIPPING_COSTS], array("yes"=>"yes", "no"=>"no")) ?><br />
            <i><?php _e('Include shipping costs in order totals?', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Default Country', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, DEFAULT_COUNTRY, $model[DEFAULT_COUNTRY], $countries) ?><br />
            <i><?php _e('What country should be preselected in the dropdown?', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Show "Out of Stock" message', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, SHOW_OUT_OF_STOCK_MSG, $model[SHOW_OUT_OF_STOCK_MSG], array("yes"=>"yes", "no"=>"no")) ?><br />
            <i><?php _e('Should a message be shown if a product is out of stock?', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Custom "Out of Stock" message', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo CUSTOM_OUT_OF_STOCK_MSG ?>" value="<?php echo $model[CUSTOM_OUT_OF_STOCK_MSG] ?>" /><br />
            <i><?php _e('An alternate out of stock message. Leave blank to use the default.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Confirmation Email', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo CONFIRMATION_EMAIL_ADDRESS ?>" value="<?php echo $model[CONFIRMATION_EMAIL_ADDRESS] ?>" /><br />
            <i><?php _e('Leave this blank if you don\'t want to send a confirmation message. If you want to use a name as well
                as an email address use the format: Name &lt;email&gt;, for example Sales &lt;sales@yourdomain.com&gt;.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Confirmation Subject', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo CONFIRMATION_SUBJECT ?>" value="<?php echo $model[CONFIRMATION_SUBJECT] ?>" size="60" /><br />
            <i><?php _e('Leave this blank to use the default (localised) subject "Order Confirmation".', 'yak-admin') ?></i></td>
        </tr>
    
        <tr valign="top">
            <th scope="row"><?php _e('Confirmation Message', 'yak-admin') ?></th>
            <td><textarea cols="60" rows="8" name="<?php echo CONFIRMATION_MESSAGE ?>"><?php echo $model[CONFIRMATION_MESSAGE] ?></textarea><br />
            <i><?php _e('Either plain text or html. If the &lt;html&gt; tag is found YAK will automatically send the message as
                html.', 'yak-admin') ?><br />
                <?php _e('Note, the following tags can be used in the message', 'yak-admin') ?>:<br />
            <?php _e('[order_id] for the order number', 'yak-admin') ?>,<br />
            <?php _e('[order_detail] for the order detail', 'yak-admin') ?>,<br />
            <?php _e('[html_order_detail] for the order detail in html table format', 'yak-admin') ?>,<br />
            <?php _e('[order_cost] for the total order cost', 'yak-admin') ?>,<br />
            <?php _e('[payment_type] for the payment type', 'yak-admin') ?>,<br />
            <?php _e('[shipping_address] for the shipping address', 'yak-admin') ?>,<br />
            <?php _e('[html_shipping_address] for the shipping address in html format', 'yak-admin') ?>,<br />
            <?php _e('[name] for the recipient name', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Default special instructions', 'yak-admin') ?></th>
            <td><textarea cols="40" rows="4" name="<?php echo DEFAULT_SPECIAL_INSTRUCTIONS ?>"><?php echo $model[DEFAULT_SPECIAL_INSTRUCTIONS] ?></textarea></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Terms &amp; conditions', 'yak-admin') ?></th>
            <td><textarea cols="40" rows="4" name="<?php echo TERMS_AND_CONDITIONS ?>"><?php echo $model[TERMS_AND_CONDITIONS] ?></textarea><br />
                <i><?php _e('Leave blank if you don\'t need to include a T&amp;C\'s checkbox', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Empty basket message', 'yak-admin') ?></th>
            <td><textarea cols="40" rows="4" name="<?php echo EMPTY_BASKET_MESSAGE ?>"><?php echo $model[EMPTY_BASKET_MESSAGE] ?></textarea><br />
                <i><?php _e('An alternative message to be displayed if the customer selects checkout without having added anything to their basket.
                   Leave blank to use the default message.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Redirect on buy to', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, REDIRECT_ON_BUY_TO, $model[REDIRECT_ON_BUY_TO], $model[PAGE_IDS]) ?><br />
            <i><?php _e('Select the shopping cart page to redirect to when the customer clicks on the buy button (leave blank to
            disable redirection)', 'yak-admin') ?></i></td>
        </tr>
                
        <tr valign="top">
            <th scope="row"><?php _e('Display product options', 'yak-admin') ?></th>
            <td><input type="checkbox" name="<?php echo DISPLAY_PRODUCT_OPTIONS ?>" <?php yak_html_checkbox($model[DISPLAY_PRODUCT_OPTIONS]) ?> /><br />
            <i><?php _e('Display product options drop-down if there is only a single option?', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Product category name', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, PRODUCT_CATEGORY_NAME, $model[PRODUCT_CATEGORY_NAME], $model[CATEGORIES]) ?><br />
            <i><?php _e('The name of the category used for product posts (e.g. "products").  If you want a post to appear as a product you must use this category or a sub-category.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Product page size', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo PRODUCT_PAGE_SIZE ?>" value="<?php echo $model[PRODUCT_PAGE_SIZE] ?>" /><br />
            <i><?php _e('The number of products that should appear on the product page before we start "paging" (i.e. add previous/next links).', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Order number type', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, ORDER_NUMBER_TYPE, $model[ORDER_NUMBER_TYPE], $order_number_types) ?><br />
            <i><?php _e('Order numbers can be a basic sequence, or a randomised unique number.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Use SSL checkout', 'yak-admin') ?></th>
            <td><input type="checkbox" name="<?php echo USE_SSL ?>" <?php yak_html_checkbox($model[USE_SSL]) ?> /><br />
            <i><?php _e('Use SSL during the checkout process (this will be automatically switched on if you choose credit card payment).', 'yak-admin') ?></i></td>
        </tr>
    </table>
    
    <div class="submit">
        <input type="submit" name="options_update2" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm2', 'fragment-2')" />
    </div>
</form>

</div>
 
<div id="fragment-3" class="tabs-container">
<h2><?php _e('Products price/quantity', 'yak-admin') ?></h2>
<form name="settingsFrm3" method="post" action="#fragment-3">
    
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><?php _e('Auto discount', 'yak-admin') ?></th><!--/label-->
            <td><input type="text" name="<?php echo AUTO_DISCOUNT ?>" value="<?php echo $model[AUTO_DISCOUNT] ?>" /><br />
            <i><?php _e('Enter a fraction, or 1 for no discount', 'yak-admin') ?></i></td>
        </tr>

        <tr valign="top">
            <th scope="row"><?php _e('Currency Symbol', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo CURRENCY_SYMBOL ?>" value="<?php echo $model[CURRENCY_SYMBOL] ?>" /><br />
            <i><?php _e('What currency symbol should be used in prices?  e.g. $, baht, £, €, etc', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Money Format', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, MONEY_FORMAT, $model[MONEY_FORMAT], $money_format); ?></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Currency Format', 'yak-admin') ?></th>
            <td><?php echo yak_html_select(null, CURRENCY_FORMAT, $model[CURRENCY_FORMAT], $currency_format); ?></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Decimal point', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo DECIMAL_POINT ?>" value="<?php echo $model[DECIMAL_POINT] ?>" size="1" /><br />
            <i><?php _e('What symbol to use for the decimal point (if not entered, defaults to '.')', 'yak-admin') ?></i></td>
        </tr>

        <tr valign="top">
            <th scope="row"><?php _e('Thousands separator', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo THOUSANDS_SEPARATOR ?>" value="<?php echo $model[THOUSANDS_SEPARATOR] ?>" size="1" /><br />
            <i><?php _e('What symbol to use for the thousands separator (if not entered, defaults to \',\')', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Price rounding', 'yak-admin') ?></th><!--/label-->
            <td><input type="text" name="<?php echo PRICE_ROUNDING ?>" value="<?php echo $model[PRICE_ROUNDING] ?>" /><br />
            <i><?php _e('Enter the number of decimal places to round to (e.g. 2 decimal places, or 0 for currencies that don\'t typically use smaller units -- thai baht being an example)', 'yak-admin') ?></i></td>
        </tr>

    </table>

    <div class="submit">
        <input type="submit" name="options_update3" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm3', 'fragment-3')" />
    </div>
</form>
</div>

<div id="fragment-4" class="tabs-container">   
<h2><?php _e('Download settings', 'yak-admin') ?></h2>
<form name="settingsFrm4" method="post" action="#fragment-4">
    <table class="form-table">    
        <tr valign="top">
            <th scope="row"><?php _e('Download uri', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo DOWNLOAD_URI; ?>" value="<?php echo $model[DOWNLOAD_URI] ?>" size="60" /><br />
            <i><?php _e('Enter an override uri for the yak-dl.php file which will be sent to the customer. You only need to enter this if you use mod_rewrite (or equivalent) to change the actual path to the script. If that doesn\'t make sense to you, leave this blank.', 'yak-admin') ?></i></td>
        </tr>

        <tr valign="top">
            <th scope="row"><?php _e('Download Email', 'yak-admin') ?></th>
            <td><textarea cols="40" rows="4" name="<?php echo DOWNLOAD_EMAIL; ?>"><?php echo $model[DOWNLOAD_EMAIL] ?></textarea><br />
            <i><?php _e('A message containing a list of download URIs for purchased products ([downloads] is replaced with the URI list)', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Download Email address', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo DOWNLOAD_EMAIL_ADDRESS ?>" value="<?php echo $model[DOWNLOAD_EMAIL_ADDRESS] ?>" size="30" /><br />
            <i><?php _e('Email address from which download messages are sent', 'yak-admin') ?></i></td>
        </tr>
    </table>

    <div class="submit">
        <input type="submit" name="options_update4" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm4', 'fragment-4')" />
    </div>
</form>
</div>

<div id="fragment-5" class="tabs-container">      
<h2><?php _e('Payment Settings', 'yak-admin') ?></h2>
<form name="settingsFrm5" method="post" action="#fragment-5">
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><strong><?php _e('Redirects for Payment', 'yak-admin') ?></strong></th>
            <td>
                <table id="payment_types" class="form-table">
                    <tr>
                        <th><?php _e('Type Name', 'yak-admin') ?> <button class="image-button" type="button" onclick="javascript:copyRow('payment_types')"><img src="<?php echo $imgbase ?>/add.gif" alt="flip" border="0" /></button></th>
                        <th><?php _e('Redirect To', 'yak-admin') ?></th>
                    </tr>
<?php
if (isset($model[PAYMENT_TYPES])) {
    foreach ($model[PAYMENT_TYPES] as $key=>$value) { 
?>
                    <tr>
                        <td><input type="text" name="payment_type_names[]" value="<?php echo $key ?>" /></td>
                        <td><?php echo yak_html_select(null, 'payment_type_redirects[]', $value, $payment_pages) ?></td>
                        <td></td>
                    </tr>
<?php 
    }
} 
?>
                    <tr>
                        <td><input type="text" name="payment_type_names[]" value="" /></td>
                        <td><?php echo yak_html_select(null, 'payment_type_redirects[]', null, $payment_pages) ?></td>
                        <td></td>
                    </tr>
                </table>
                <br />
                <i><?php _e('PayPal, Google, and Credit Card payment options, all require further configuration below.', 'yak-admin') ?></i>
            </td>
        </tr>
    </table>
    
           
    <h3><?php _e('General settings', 'yak-admin') ?></h3>
    
    <table class="form-table">
        <tr>
            <th><?php _e('External Currency code', 'yak-admin') ?></th>
            <td><input type="text" name="<?php echo CURRENCY_CODE ?>" value="<?php echo $model[CURRENCY_CODE] ?>" /><br />
            <i><?php _e('Currency codes are: AUD, NZD, CAD, EUR, GBP, JPY or USD.  Enter a currency code that is valid for your payment provider, be it Google Checkout or PayPal', 'yak-admin') ?></i></td>
        </tr>
    </table>

    <?php
    foreach ($payment_options as $key=>$payment_option) {
        if (in_array($payment_option->get_name(), $used_options)) {
            continue;
        }
        $used_options[] = $payment_option->get_name();
        $payment_option->get_view_settings($model);
    }
    ?>
    
    <div class="submit">
        <input type="submit" name="options_update5" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm5', 'fragment-5')" />
    </div>
</form>
</div>

<div id="fragment-6" class="tabs-container"> 
<h2><?php _e('Special Options', 'yak-admin') ?></h2>
<form name="settingsFrm6" method="post" action="#fragment-6">
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><strong><?php _e('Special options text', 'yak-admin') ?></strong></th>
            <td><input type="text" name="<?php echo SPECIAL_OPTIONS_TEXT ?>" value="<?php echo $model[SPECIAL_OPTIONS_TEXT] ?>" /><br />
            <i><?php _e('Use special options text if you want to offer free gifts with a product (the text to use as a label next to the special options dropdown box). Add a custom field "yak_special_options" to the product with values separated by new lines.', 'yak-admin') ?>
                <?php _e('These values will be split and used in a drop down box for the customer to select.', 'yak-admin') ?> 
                <?php _e('When a customer selects a special option it is added to the meta data for the order.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><strong><?php _e('No caching', 'yak-admin') ?></strong></th>
            <td><?php echo yak_html_select(null, NO_CACHE_PAGES . '[]', $model[NO_CACHE_PAGES], $model[PAGE_IDS], false, null, false, '" style="height: 10em', null, 5) ?><br />
            <i><?php _e('What pages should caching be turned off (in other words the checkout page or pages)?', 'yak-admin') ?>
                <?php _e('Use this to stop Internet Explorer displaying the message "webpage is expired".', 'yak-admin') ?><i></td>
        </tr>
    </table>
    
    <div class="submit">
        <input type="submit" name="options_update6" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm6', 'fragment-6')" />
    </div>
</form>
</div>

<div id="fragment-7" class="tabs-container">     
<h2><?php _e('Advanced Options', 'yak-admin') ?></h2>
<form name="settingsFrm7" method="post" action="#fragment-7"> 
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><strong><?php _e('HTTP Proxy Address', 'yak-admin') ?></strong></th>
            <td><input type="text" name="<?php echo HTTP_PROXY_URL ?>" value="<?php echo $model[HTTP_PROXY_URL] ?>" size="60" /><br />
            <i><?php _e('The url to use on hosts which require http proxying of remote requests (note: currently only setup to work with <a href="http://curl.haxx.se/">curl</a> (if your server doesn\'t have <a href="http://www.php.net/curl">php-curl</a> installed this won\'t work at the moment).', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><strong><?php _e('Remote Grab Server', 'yak-admin') ?></strong></th>
            <td><input type="text" name="<?php echo REMOTE_GRAB_SERVER ?>" value="<?php echo $model[REMOTE_GRAB_SERVER] ?>" size="60" /><br />
            <i><?php _e('The remote server to use in association with the [yak_get_remote...] tag.', 'yak-admin') ?>  <?php _e('Include protocol, domain and port (e.g. http://www.myserver.com:8080)', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><strong>Remote Grab Path</strong></th>
            <td><input type="text" name="<?php echo REMOTE_GRAB_PATH ?>" value="<?php echo $model[REMOTE_GRAB_PATH] ?>" /><br />
            <i><?php _e('The remote path to use in association with the [yak_get_remote...] tag. For example:  /wordpress or /mysite', 'yak-admin') ?></i></td>
        </tr>
        
    </table>
    
    <div class="submit">
        <input type="submit" name="options_update7" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm7', 'fragment-7')" />
    </div>
</form>    
</div>

<div id="fragment-8" class="tabs-container">    
<h2><?php _e('Shipping Options', 'yak-admin') ?></h2>
<form name="settingsFrm8" method="post" action="#fragment-8">
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><?php _e('Shipping Address', 'yak-admin') ?></th>
            <td>
            <label for="<?php echo ADDRESS_NAME ?>"> <input type="checkbox" id="<?php echo ADDRESS_NAME ?>" name="<?php echo ADDRESS_NAME ?>" <?php yak_html_checkbox($model[ADDRESS_NAME]) ?> /><?php _e('Include Name', 'yak-admin') ?></label><br />
            <label for="<?php echo ADDRESS_PHONE ?>"> <input type="checkbox" id="<?php echo ADDRESS_PHONE ?>" name="<?php echo ADDRESS_PHONE ?>" <?php yak_html_checkbox($model[ADDRESS_PHONE]) ?> /><?php _e('Include Phone', 'yak-admin') ?></label><br />
            <label for="<?php echo ADDRESS ?>"> <input type="checkbox" id="<?php echo ADDRESS ?>" name="<?php echo ADDRESS ?>" <?php yak_html_checkbox($model[ADDRESS]) ?> /><?php _e('Include Address', 'yak-admin') ?></label><br />
            <label for="<?php echo ADDRESS_SEPARATE_BILLING ?>"> <input type="checkbox" id="<?php echo ADDRESS_SEPARATE_BILLING ?>" name="<?php echo ADDRESS_SEPARATE_BILLING ?>" <?php yak_html_checkbox($model[ADDRESS_SEPARATE_BILLING]) ?> /> <?php _e('Separate Billing Address', 'yak-admin') ?></label><br />
            <i><?php _e('What fields are required for shipping address (email is required by default).', 'yak-admin') ?></i>
            </td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Shipping Notes', 'yak-admin') ?></th>
            <td><textarea cols="40" rows="2" name="<?php echo SHIPPING_NOTES ?>"><?php echo $model[SHIPPING_NOTES] ?></textarea><br />
            <i><?php _e('Notes about shipping to add to the bottom of the confirmation screen.', 'yak-admin') ?></i></td>
        </tr>
        
        <tr valign="top">
            <th scope="row"><?php _e('Shipping weight calculation value', 'yak-admin') ?></th>
            <td><input type="text" id="<?php echo SHIPPING_WEIGHT_CALC ?>" name="<?php echo SHIPPING_WEIGHT_CALC ?>" value="<?php echo $model[SHIPPING_WEIGHT_CALC] ?>" /><br />
                <i><?php _e('The weight value, in grams, that should be used for calculating shipping cost. This defaults to 100gms if not set and is used for the "shipping first" calculation and then the subsequent "per x grams" calculation.', 'yak-admin') ?></i></td>
        </tr>
    </table>
    
    <h3><?php _e('Default shipping', 'yak-admin') ?></h3>

    <?php
    $weight_val = $model[SHIPPING_WEIGHT_CALC];
    if (empty($weight_val)) {
        $weight_val = DEFAULT_SHIPPING_WEIGHT_CALC;
    }
    ?>

    <p><?php _e('If you have a fixed price per order, use the first input box.', 'yak-admin') ?>
        <?php _ye('For fixed price based on the number of items being shipped, use the second 2 boxes (representing the first item and subsequent items), and for price by weight (price per %s gms) use the last 2 boxes.', 'yak-admin', $weight_val) ?></p>
    
    <table class="widefat">
        <thead>
            <tr>
                <th></th>
                <th><?php _e('Fixed Total Cost', 'yak-admin') ?></th>
                <th><?php _e('Fixed Cost per item', 'yak-admin') ?><br />
                    <?php _e('(First/Subsequent)', 'yak-admin') ?></th>
                <th><?php _ye('Cost per %s gm', 'yak-admin', $weight_val) ?><br />
                    <?php _ye('(First %s gm/Subsequent)', 'yak-admin', $weight_val) ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th></th>
                <td><input type="text" size="5" name="<?php echo DEFAULT_SHIPPING ?>" value="<?php echo $model[DEFAULT_SHIPPING] ?>" /></td>
                <td><input type="text" size="5" name="<?php echo DEFAULT_SHIPPING_FIXED_ITEM_FIRST ?>" value="<?php echo $model[DEFAULT_SHIPPING_FIXED_ITEM_FIRST] ?>" />
                    <input type="text" size="5" name="<?php echo DEFAULT_SHIPPING_FIXED_ITEM ?>" value="<?php echo $model[DEFAULT_SHIPPING_FIXED_ITEM] ?>" /></td>
                <td><input type="text" size="5" name="<?php echo DEFAULT_SHIPPING_WEIGHT_FIRST ?>" value="<?php echo $model[DEFAULT_SHIPPING_WEIGHT_FIRST] ?>" />
                    <input type="text" size="5" name="<?php echo DEFAULT_SHIPPING_WEIGHT ?>" value="<?php echo $model[DEFAULT_SHIPPING_WEIGHT] ?>" /></td>
            </tr>
        </tbody>
    </table>
        
    <h3><?php _e('Shipping by country', 'yak-admin') ?></h3>

    <p><?php _e('If you have a fixed price for all orders to a particular country, use the first input box.', 'yak-admin') ?>
        <?php _ye('For fixed price based on the number of items being shipped, use the second 2 boxes (representing the first item and subsequent items), and for price by weight (price per %s gms) use the last 2 boxes.', 'yak-admin', $weight_val) ?></p>
           
    <table class="widefat">
        <thead>
            <tr>
                <th><input type="checkbox" onclick="selectAllCheckboxes('settingsFrm8', this, 'yak_cty_')" /> <?php _e('Select All Countries', 'yak-admin') ?></th>
                <th><?php _e('Fixed Total Cost', 'yak-admin') ?></th>
                <th><?php _e('Fixed Cost per item', 'yak-admin') ?><br />
                    (First/Subsequent)</th>
                <th><?php _ye('Cost per %s gm', 'yak-admin', $weight_val) ?><br />
                    <?php _ye('(First %s gm/Subsequent)', 'yak-admin', $weight_val) ?></th>
            </tr>
        </thead>
        <tbody>
<?php foreach ($countries as $country=>$ignore) { 
          $ctyname = $countries[$country];    
?>
            <tr>
                <th><input type="checkbox" id="<?php echo 'yak_cty_' . $country . '_enabled' ?>" name="<?php echo 'yak_cty_' . $country . '_enabled' ?>" <?php yak_html_checkbox($model['yak_cty_' . $country . '_enabled']) ?> /> <?php echo $ignore; ?></th>
                <td><input type="text" size="5" name="<?php echo 'yak_' . $country . '_shipping_fixed' ?>" value="<?php echo $model['yak_' . $country . '_shipping_fixed'] ?>" /></td>
                <td><input type="text" size="5" name="<?php echo 'yak_' . $country . '_shipping_fixeditemfirst' ?>" value="<?php echo $model['yak_' . $country . '_shipping_fixeditemfirst'] ?>" />
                    <input type="text" size="5" name="<?php echo 'yak_' . $country . '_shipping_fixeditem' ?>" value="<?php echo $model['yak_' . $country . '_shipping_fixeditem'] ?>" /></td>
                <td><input type="text" size="5" name="<?php echo 'yak_' . $country . '_shipping_weightfirst' ?>" value="<?php echo $model['yak_' . $country . '_shipping_weightfirst'] ?>" />
                    <input type="text" size="5" name="<?php echo 'yak_' . $country . '_shipping_weight' ?>" value="<?php echo $model['yak_' . $country . '_shipping_weight'] ?>" /></td>
            </tr>
<?php } ?>
        </tbody>
    </table>

    <div class="submit">
        <input type="submit" name="options_update8" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm8', 'fragment-8')" />
    </div>
</form>
</div>

<div id="fragment-9" class="tabs-container">    
<h2><?php _e('Promotions', 'yak-admin') ?></h2>
<form name="settingsFrm9" method="post" action="#fragment-9">
    <table id="promotions" class="form-table">
        <tr>
            <th><?php _e('Code / Threshold', 'yak-admin') ?> <button class="image-button" type="button" onclick="javascript:copyRow('promotions')"><img src="<?php echo $imgbase ?>/add.gif" alt="flip" border="0" /></button></th>
            <th><?php _e('Description', 'yak-admin') ?></th>
            <th><?php _e('Type', 'yak-admin') ?></th>
            <th><?php _e('Value', 'yak-admin') ?></th>
            <th><?php _e('Expiry', 'yak-admin') ?><br /><span style="font-size: x-small"><?php _e('Month/Day/Year', 'yak-admin') ?></span></th>
            <th></th>
        </tr>
        <?php
        if (isset($model[PROMOTIONS])) {
            foreach ($model[PROMOTIONS] as $promo) {
                $expiry_year = substr($promo->expiry_date, 0, 4);
                $expiry_month = substr($promo->expiry_date, 5, 2);
                $expiry_day = substr($promo->expiry_date, 8, 2);
        ?>
        <tr>
            <td><input type="text" name="promo_code[]" value="<?php echo $promo->code ?>" /><input type="hidden" name="promo_id[]" value="<?php echo $promo->promo_id ?>" /><br />
                <input type="text" name="promo_users[]" value="<?php echo $promo->get_users_string() ?>" /></td>
            <td><input type="text" name="promo_description[]" value="<?php echo $promo->description ?>" maxlength="250" /></td>
            <td><?php echo yak_html_select(null, 'promo_type[]', $promo->promo_type, $promo_types) ?></td>
            <td><input type="text" name="promo_value[]" value="<?php echo $promo->value ?>" /></td>
                <td><?php yak_date_control('promo_expiry[]', $expiry_year, $expiry_month, $expiry_day) ?></td>
            <td><button class="image-button" type="button" onclick="javascript:removePromotion(this)"><img src="<?php echo $imgbase ?>/delete.gif" alt="flip" border="0" /></button></td>
        </tr>
        <?php 
            }
        } 
        ?>
        <tr>
            <td><input type="text" name="promo_code[]" value="" /><input type="hidden" name="promo_id[]" value="">
                <input type="text" name="promo_users[]" value="" /></td>
            <td><input type="text" name="promo_description[]" value="" maxlength="250" /></td>
            <td><?php echo yak_html_select(null, 'promo_type[]', null, $promo_types) ?></td>
            <td><input type="text" name="promo_value[]" value="" /></td>
            <td><?php yak_date_control('promo_expiry[]', '', '', '') ?></td>
            <td><button class="image-button" type="button" onclick="javascript:removePromotion(this)"><img src="<?php echo $imgbase ?>/delete.gif" alt="flip" border="0" /></button></td>
        </tr>
        
    </table>
    
    <div class="submit">
        <input type="submit" name="options_update9" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm9', 'fragment-9')" />
    </div>
</form>
</div>

<div id="fragment-10" class="tabs-container">    
<form name="settingsFrm10" method="post" action="#fragment-10">
<?php
$google_analytics = new YakGoogleAnalytics();
$google_analytics->get_view_settings($model);
?>
</form>
</div>

</div><!--/tabs-container-->

</div><!--/wrap-->

</form>