<?php
/*
See yak-for-wordpress.php for information and license terms
*/
$pid = $_GET['post'];
if (get_post_type($pid) == 'page' || yak_str_contains($_SERVER['PHP_SELF'], 'page')) {
    $page = true;
}
else {
    $page = false;
}

$price = '';
$title = '';

if (isset($pid) && $pid != null) {
    $product = yak_get_product($pid);
    $price = $product->price;
    $title = $product->title;
    $product->types = yak_get_product_categories($pid, $product->status);
}
else {
    $product = new YakProduct('', '', '', '', '');
    $product->types = array();
}

if ($page && count($product->types) == 0) {
    $product->types[] = new YakProductType($pid, -1, 'default', '', 0, null, null, '');
}
?>
<div id="tagsdiv" class="postbox">
    <h3><a class="togbox">+</a> <?php _e('YAK Product Details', 'yak-admin') ?></h3>
    <div class="inside">
        <input type="hidden" name="yak_action" value="Update-Product" />
        <p><?php _e('Set the price of your product', 'yak-admin') ?>: <input type="text" name="yak_price" value="<?php echo $price ?>" size="10" /></p>
        <p><?php _e('Set the display title', 'yak-admin') ?>: <input type="text" name="yak_title" value="<?php echo $title ?>" size="50" /></p>
        <p><?php _e('Set an override discount', 'yak-admin') ?>: <input type="text" name="yak_discount_override" value="<?php echo $product->discount_override ?>" size="10" /> <?php _e('Note: enter a fraction (e.g. 0.75 for 25% discount)', 'yak-admin') ?></p>
        <p><?php _e('Add multiselect options', 'yak-admin') ?>:<br />
            <textarea name="yak_multi_select" cols="80" rows="3"><?php echo $product->multi_select_options ?></textarea>
        </p>
        <p><?php _e('Set the minimum and maximum number of multi-select options', 'yak-admin') ?>:
            <input type="text" name="yak_multi_select_min" value="<?php echo $product->multi_select_min ?>" size="5" /> - <input type="text" name="yak_multi_select_max" value="<?php echo $product->multi_select_max ?>" size="5" /></p>
        
        <?php
            $pid = $_GET['post'];
            include 'yak-view-product-snippet.php';
        ?>
    </div>
    
</div>
