<?php
/*
See yak-for-wordpress.php for information and license terms
*/

/**
 * A singleton registry to store app-wide data 
 */
class Registry {
    var $_objects = array();

    function &getInstance() {
        static $self;

        if (is_object($self) == true) {
            return $self;
        }

        $self = new Registry;
        return $self;
    }
    
    function set($name, &$object) {
        $this->_objects[$name] =& $object;
    }

    function &get($name) {
        return $this->_objects[$name];
    }
}


function yak_bccomp($f1, $f2, $scale) {
    if (function_exists('bccomp')) {
        return bccomp($f1, $f2, $scale);
    }
    else if ($f1 == $f2) {
        return 0;
    }
    else if ($f1 > $f2) {
        return 1;
    }
    else {
        return -1;
    }
}	


/**
 * Return a default if the specified value is not set
 *
 * @param $val the value to return a default if empty
 * @param $def the default value to use if $val is not set
 */
function yak_default($val, $def = '') {
    if (empty($val)) {
        return $def;   
    }
    else {
        return $val;   
    }
}


if (!function_exists('yak_escape_string')) {
    /**
     * Properly escape a string so it can be used in a SQL statement 
     */
    function yak_escape_string($string) {
        if (version_compare(phpversion(),"4.3.0") == "-1") {
            return mysql_escape_string($string);
        }
        else {
            return mysql_real_escape_string($string);
        }
    }
}


if (!function_exists('yak_fix_escaping')) {
    /**
     * Fix escaping of single-quotes
     */
    function yak_fix_escaping($s) {
        $s = str_replace("\\'", "'", $s);
        $s = str_replace("\\\\", "\\", $s);
        return $s;
    }
}

if (!function_exists('yak_sql_escape')) {
    function yak_sql_escape($s) {
        $s = str_replace("\'", "''", $s);
        return $s;
    }
}


if (!function_exists('yak_get_country')) {
    /**
     * Return the name of a country by the country code
     */
    function yak_get_country($country_code) {
        global $countries;
        return $countries[$country_code];
    }
}


if (!function_exists('yak_get_country_by_name')) {
    /**
     * Return a country code by the country name (if not found, return null)
     */
    function yak_get_country_by_name($ctyname) {
        global $countries;
        
        foreach ($countries as $code=>$name) {
            if ($name == $ctyname) {
                return $code;   
            }
        }
        
        return null;
    }
}


if (!function_exists('yak_overlap')) {
    /**
     * Append 2 strings, removing any overlap between the two
     */
    function yak_overlap($s1, $s2) {
        for ($x = strlen($s1)-1; $x >= 0; $x--) {
            $end = substr($s1, $x);
            $start = substr($s2, 0, strlen($end));
            if ($start == $end) {
                return substr($s1, 0, $x) . $s2;
            }
        }
        return $s1 . $s2;
    }
}

/**
 * Convert a memory value as a number of bytes.
 */
function yak_return_bytes($val) {
    $val = trim($val);
    $last = strtolower($val{strlen($val)-1});
    switch($last) {
        // The 'G' modifier is available since PHP 5.1.0
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }

    return $val;
}


if (!function_exists('yak_str_contains')) {
    /**
     * Return true if one string can be found in another
     *
     * @param $haystack the string to search *in*
     * @param $needle the string to search *for*
     */
    function yak_str_contains($haystack, $needle) {
        $pos = strpos($haystack, $needle);
        
        if ($pos === false) {
            return false;
        }
        else {
            return true;
        }
    }   
}


if (!function_exists('yak_do_http')) {
    /**
     * Execute an HTTP method.  If curl is available, use curl, otherwise pfsockopen.
     *
     * @param $host the server name/ip
     * @param $uri the uri to invoke
     * @param $params the parameters to use in the execution
     * @param $headers the HTTP headers
     * @param $method the HTTP method
     */
    if (function_exists('curl_init')) {
        function yak_do_http($host, $uri, $params, $headers = null, $method = 'POST') {
            $ch = curl_init();
              
            if ($method == 'POST') {
                curl_setopt($ch, CURLOPT_URL, $host . $uri);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
            }
            else {
                curl_setopt($ch, CURLOPT_URL, $host . $uri . '?' . $params);
                curl_setopt($ch, CURLOPT_GET, 1);
            }
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
            
            $proxy_url = yak_get_option(HTTP_PROXY_URL, '');
            if ($proxy_url != '') {
                curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
                curl_setopt($ch, CURLOPT_PROXY, $proxy_url);    
            }
            
            $response = curl_exec($ch);
            
            if (curl_errno($ch)) {
                return curl_error($ch);
            }
            else {
                return $response;
            }
        }
    }
    else {
        function yak_do_http($host, $uri, $params, $headers = null, $method = 'POST') {
            $parsed = parse_url($host);
            $hostname = $parsed['host'];
            $port = 80;
            if ($parsed['scheme'] == 'https') {
                $host = 'ssl://' . $hostname;
                $port = 443;
            }
            
            $header = "Host: $hostname\r\n";
            $header .= "Accept-Encoding: identity\r\n";
            
            # compose HTTP request header
            if ($method == 'POST') {
                $header .= "User-Agent: PHP Script\r\n";
                $header .= "Content-Type: application/x-www-form-urlencoded\r\n";
                $header .= "Content-Length: " . strlen($params) . "\r\n";
            }
            else {
                $uri .= '?' . $params;
                $params = '';
            }
            
            if ($headers != null) {
                foreach ($headers as $key=>$val) {
                    $header .= $key . ": " . $val . "\r\n";       
                }
            }
            
            $header .= "Connection: close\r\n\r\n";

            $fp = pfsockopen($host, $port, $errno, $errstr);
            if (!$fp) {
                yak_log("comms error $errstr ($errno)");
                return "ERROR: $errstr ($errno)";
            }
            else { 
                fputs($fp, "$method $uri HTTP/1.1\r\n");
                fputs($fp, $header . $params);
                fwrite($fp, $out);
                
                $response = '';
                while (!feof($fp)) {
                    $response .= fgets($fp, 128);
                }
                fclose($fp);
                
                $response = split("\r\n\r\n", $response);
                $header = $response[0];
                $responsecontent = $response[1];
                if (!(strpos($header, "Transfer-Encoding: chunked") === false)) {
                    $aux = split("\r\n", $responsecontent);
                    $size = count($aux);
                    for ($i = 0; $i < $size; $i++) {
                        if ($i == 0 || ($i % 2 == 0)) {
                            $aux[$i] = "";
                        }
                    }
                    $responsecontent = implode("", $aux);
                }
                
                $rtn = chop($responsecontent);
                
                yak_log($rtn);
                
                return $rtn;
            }   
        }
    }
}


if (!function_exists('yak_get_tag_params')) {
    function yak_get_tag_params($the_content, $tag, $pos = 0, $defaults = null) {
        $taglen = strlen($tag) + 1;

        // find the start of the tag
        $pos = strpos($the_content, '[' . $tag, $pos);

        if ($pos === false) {
            return null;
        }

        // find the end of the tag
        $pos2 = strpos($the_content, ']', $pos);

        $yp = new YakParams($pos, $pos2);
        // use defaults if there are no params in the tag
        if ($pos2 == $pos + $taglen) {
            $yp->params = $defaults;
        }
        else {
            $params = substr($the_content, $pos + $taglen + 1, $pos2 - ($pos + $taglen + 1));
            $params = explode(' ', $params);
            
            if (isset($defaults)) {
                $yp->params = $params + $defaults;
            }
            else {
                $yp->params = $params;
            }
        }
        
        return $yp;
    }
}


if (!function_exists('yak_get_tag_value')) {
    function yak_get_tag_value($content, $tag_start, $tag_end = null, $start_from = 0) {
        if (!isset($tag_end) || $tag_end == '') {
            $endtag = "\n";
        }
        $tag_start_len = strlen($tag_start);
        $pos = strpos($content, $tag_start, $start_from);
        if ($pos >= 0) {
            $pos2 = strpos($content, $tag_end, $pos + $tag_start_len);
            return substr($content, $pos + $tag_start_len, $pos2 - ($pos + $tag_start_len));
        }
        else {
            return null;
        }
    }
}


if (!function_exists('yak_get_url')) {
    /**
     * Process a url to make sure we handle it intelligently.
     *     1. if there is no protocol, then assume this is a url for the local site.
     *     2. if we're going to append to the url, add either ? or & to the end depending upon
     *        what's already in the url
     *
     * @param $url the initial url to use
     * @param $safe_append are we going to append parameters to the url?
     */
    function yak_get_url($url, $safe_append = false) {
        if (strpos($url, 'http://') === false && strpos($url, 'https://') === false) {
            $rtn = get_bloginfo('wpurl') . $url;
        }
        else {
            $rtn = $url;
        }
        
        if ($safe_append == true) {
            if (strpos($rtn, '?') === false) {
                $rtn = $rtn . '?';
            }
            else {
                $rtn = $rtn . '&';
            }
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_encode_params')) {
    /**
     * Encode a param array as a url-encoded string
     */
    function yak_encode_params($param_array) {
        $params = "";
        foreach( $param_array as $key => $value ) {
            $params .= "$key=" . urlencode( $value ) . "&";
        }
        return $params;
    }
}

if (!function_exists('yak_decode_params')) {
    /**
     * Decode a param string into an array -- note: ignores duplicates (http params can have
     * dups, so this isn't correct behaviour, but works for YAK's purposes... for the moment)
     */
    function yak_decode_params($params) {
        $rtn = array();
        foreach (explode('&', $params) as $keyval) {
            $kv = explode('=', $keyval);
            $rtn[$kv[0]] = urldecode($kv[1]);
        }
        return $rtn;
    }
}


if (!function_exists('yak_date_control')) {
    function yak_date_control($name, $year, $month, $day, $include_day = true) {
        global $months;

    	echo yak_html_select('month_' . $name, 'month_' . $name, $month, $months);
    	if ($include_day) {
    	    echo '<input type="text" id="day_' . $name . '" name="day_' . $name . '" value="' . $day . '" maxlength="2" size="4" />, ';
	    }
    	echo '<input type="text" id="year_' . $name . '" name="year_' . $name . '" value="' . $year . '" maxlength="4" size="6" />';
    }
}


if (!function_exists('yak_address_hidden_input')) {
    function yak_address_hidden_input($address, $type) {
        if ($address != null) {
            foreach ($address->get_members() as $key=>$value) {
                echo '<input type="hidden" name="' . $type . '_' . $key . '" value="' . $value . '" />';
            }
        }
    }
}


if (!function_exists('yak_admin_options_set')) {
    /**
     * utility function to set an admin option -- looks for the option in the POST, if found checks for an array
     * otherwise sets a default value if present.
     */
    function yak_admin_options_set($name, $default = null, $array = false, $strip_spaces = false) {
        if (isset($_POST[$name])) {
            $val = $_POST[$name];
            if ($strip_spaces) {
                $val = str_replace(' ', '', $val);
            }
            
            if ($array) {
                update_option($name, $val);
            }
            else {
                update_option($name, stripslashes($val));
            }
        }
        else if (!empty($default)) {
            update_option($name, $default);
        }
    }
}


if (!function_exists('yak_count_digits')) {
    /**
     * return the number of digits in a string
     */
    function yak_count_digits($str) {
        $digits = split("[0-9]", $str);
        return count($digits);
    }
}


if (!function_exists('yak_get_ip')) {
    function yak_get_ip() {
        $ip = $_SERVER['REMOTE_ADDR'];
        if ($ip == '::1') {
            return '127.0.0.1';
        }
        else {
            return $ip;
        }
    }
}

if (!function_exists('yak_glob')) {
    /**
     * Some installs of PHP don't include the glob function, so this should hopefully fix this problem.
     */
    function yak_glob($path) {
        // use the standard glob if it exists
        if (function_exists('glob')) {
            return glob($path);
        }
        else {
            // otherwise, roll our own
            $dir = dirname($path);
            $pattern = basename($path);
            $files = array();
            if (is_dir($dir)) {
                if ($dh = opendir($dir)) {
                    while (($file = readdir($dh)) !== false) {
                        if (fnmatch($pattern, $file)) {
                            $files[] = $dir . '/' . $file;
                        }
                    }
                }
            }
            return $files;
        }
    }
}


if (!function_exists('yak_html_checkbox')) {
    /**
     * Echo the correct checked option for an HTML checkbox
     *
     * @param $value if 'on' output CHECKED, otherwise nothing
     */
    function yak_html_checkbox($value) {
        if ($value == 'on') { 
            echo 'CHECKED';
        }   
    }
}


if (!function_exists('yak_html_select')) {
    /**
     * Output an HTML select (drop down) element.
     *
     * @param $name the name to use in the select
     * @param $selected the selected option
     * @param $values a key->value array of the options to use in the select
     * @param $reverse_key_value the value in the array contains the key of the option (defaults to false)
     * @param $match_values an array of values to check when building the select.  If a value isn't in this array
     *                      then it won't be included in the select (defaults to null, and thus ignored)
     * @param $nokey if true, then the array is idx->value not key->value, so use the value for the option key
     */
    function yak_html_select($id, $name, $selected, $values, $reverse_key_value = false, $match_values = null, $nokey = false, $class = null, $onchange = null, $multiple = 1) {
        $rtn = "<select name=\"$name\"";
        
        if (!empty($id)) {
            $rtn .= " id=\"$id\"";
        }
        
        if (!empty($onchange)) {
            $rtn .= " onchange=\"$onchange\"";
        }
        
        if (!empty($class)) {
            $rtn .= " class=\"$class\"";
        }
        
        if ($multiple > 1) {
            $rtn .= " multiple=\"multiple\"";
            $rtn .= " size=\"$multiple\"";
        }
        
        $rtn .= ">\n";
        
        if (isset($values)) {
            foreach ($values as $key=>$value) {
                if ($match_values != null && !in_array($value, $match_values)) {
                    continue;
                }
                
                if ($reverse_key_value) {
                    $k = $value;
                    if ($nokey == true) {
                        $v = $value;
                    }
                    else {
                        $v = $key;   
                    }
                }
                else {
                    if ($nokey == true) {
                        $k = $value;   
                    }
                    else {
                        $k = $key;
                    }
                    $v = $value;
                }
                
                // set the option value (I'm also referring to this as the key)
                $rtn .= "  <option value=\"$k\"";
                
                if ((is_array($selected) && in_array($k, $selected)) || $selected == $k) {
                    $rtn .= " SELECTED";
                }
                $rtn .= ">$v</option>\n";
            }
        }
        
        $rtn .= "</select>";
        
        return $rtn;
    }
}


if (!function_exists('yak_in_list')) {
    function yak_in_list($name, $typeList) {
        foreach ($typeList as $type) {
            if ($name == $type->name) {
                return true;
            }
        }
        return false;
    }
}


function yak_log($msg) {
    @error_log(preg_replace("/\n+\s*/", " ", $msg));
}


if (!function_exists("yak_sendmail")) {
    function yak_sendmail($from, $to, $subject, $message) {
        yak_log("Sending mail from $from to $to with subject $subject");
        if (yak_str_contains($message, '<html')) {
            yak_sendhtml($from, $to, $subject, $message);
        }
        else {
            yak_mail($from, $to, $subject, $message);
        }
    }
}

if (!function_exists("yak_sendhtml")) {
    function yak_sendhtml($from, $to, $subject, $message) {
        yak_mail($from, $to, $subject, $message, true);
    }
}

if (!function_exists('yak_mail')) {
    /**
     * Savagely hacked out wp_mail from the Wordpress codebase and modified for my purposes...
     */
    function yak_mail($from, $to, $subject, $message, $html = false) {
    	global $phpmailer;

    	// (Re)create it, if it's gone missing
    	if (!is_object($phpmailer) || !is_a($phpmailer, 'PHPMailer')) {
    		require_once ABSPATH . WPINC . '/class-phpmailer.php';
    		require_once ABSPATH . WPINC . '/class-smtp.php';
    		$phpmailer = new PHPMailer();
    	}

    	// Empty out the values that may be set
    	$phpmailer->ClearAddresses();
    	$phpmailer->ClearAllRecipients();
    	$phpmailer->ClearAttachments();
    	$phpmailer->ClearBCCs();
    	$phpmailer->ClearCCs();
    	$phpmailer->ClearCustomHeaders();
    	$phpmailer->ClearReplyTos();
    	
    	if (strpos($from, '<') !== false) {
			$from_name = substr($from, 0, strpos($from, '<') - 1);
			$from_name = str_replace('"', '', $from_name);
			$from_name = trim($from_name);

			$from_email = substr($from, strpos( $from, '<' ) + 1);
			$from_email = str_replace('>', '', $from_email);
			$from_email = trim($from_email);
		}
		else {
			$from_email = trim($from);
		}

    	$phpmailer->From = $from_email;
    	$phpmailer->FromName = $from_name;

    	// Set destination address
    	$phpmailer->AddAddress($to);

    	// Set mail's subject and body
    	$phpmailer->Subject = $subject;
    	
    	if ($html) {
    	    $phpmailer->IsHTML(true);
    	    $phpmailer->Body = $message;
            $phpmailer->AltBody= strip_tags($message);
    	}
    	else {
    	    $phpmailer->Body = $message;
	    }

    	// Set to use PHP's mail()
    	$phpmailer->IsMail();

    	// Set the content-type and charset
    	$phpmailer->CharSet = get_bloginfo('charset');

        do_action_ref_array('phpmailer_init', array(&$phpmailer));

    	return @$phpmailer->Send();
    }
}

if (!function_exists("_ye")) {
    function _ye($msg, $pot) {
        $msg = __($msg, $pot);

        $msg_array = array(__($msg, $pot));
        $arg_array = array_slice(func_get_args(), 2);
                
        call_user_func_array('printf', array_merge($msg_array, $arg_array));
    }
}
?>
