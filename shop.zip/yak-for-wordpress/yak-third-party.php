<?php
function yak_check_order_3p($order_id, $email, $recipient, $total_cost) {
    if (yak_str_contains($_SERVER['PHP_SELF'], 'tools')) {
        echo "<table id=\"third-party\" style=\"visibility:hidden; display: none\">
            <tr>
                <td id=\"third-party-id\">$order_id</td>
                <td id=\"third-party-email\">$email</td>
                <td id=\"third-party-recipient\">$recipient</td>
                <td id=\"third-party-cost\">$total_cost</td>
            </tr>
        </table>";
    }
}
?>