<?php
/*
See yak-for-wordpress.php for information and license terms
*/
global $model, $countries;

if (empty($_POST['orders_query']) && empty($_POST['year_order_date'])) {
    $year_order_date = date('Y');
}
else {
    $year_order_date = $_POST['year_order_date'];
}
?>

<div class="wrap">
<form method="post" action="#">
<h2>Orders</h2>
  
<div class="tablenav">
<div class="alignleft">
<table>
    <tr>
        <td><?php _e('Type of order', 'yak-admin') ?></td>
        <td><?php echo yak_html_select('status', 'status', yak_default($_POST['status'], ''), array(STOCK_SENT=>'show fulfilled orders', ''=>'show unfulfilled orders', CANCELLED=>'show cancelled orders', ERROR=>'show error orders')) ?></td>
    </tr>
    <tr>
        <td><?php _e('Date', 'yak-admin') ?></td>
        <td><?php yak_date_control('order_date', $year_order_date, $_POST['month_order_date'], '', false) ?></td>
    </tr>
    <tr>
        <td><?php _e('Order #', 'yak-admin') ?></td>
        <td><input type="text" id="order_num" name="order_num" value="<?php echo $_POST['order_num'] ?>" /></td>
    </tr>
</table>
<input type="submit" name="orders_query" value="<?php _e('Find orders', 'yak-admin') ?>" class="button-secondary" />
</div>

<div class="alignright">
<input type="submit" name="orders_update" value="<?php _e('Update orders', 'yak-admin') ?>" class="button" />
</div>
<br class="clear" />
</div>

<p class="clear">&nbsp;</p>

<?php if ($orders) { ?>  
  <table class="widefat collapsible">
  <thead>
    <tr>
      <th scope="col"><?php _e('Order #', 'yak-admin') ?></th>
      <th scope="col"><?php _e('Date', 'yak-admin') ?></th>
      <th scope="col"><?php _e('Order Value', 'yak-admin') ?></th>
      <th scope="col"><?php _e('Payment Type', 'yak-admin') ?></th>
      <th scope="col"><?php _e('Funds Received', 'yak-admin') ?></th>
      <th scope="col"><?php _e('Status', 'yak-admin') ?></th>
      <th scope="col"><?php _e('Action', 'yak-admin') ?></th>
      <th scope="col"></th>
    </tr>
    </thead>
    <tbody>
<?php foreach ($orders as $order) {
$class = 'even' == $class ? '' : 'even';
?>
    <tr class="<?php echo $class ?>">
      <td><?php echo $order->num ?><input type="hidden" name="id[]" value="<?php echo $order->id ?>" /></td>
      <td><?php echo $order->time ?></td>
      <td class="yak_right"><?php echo yak_format_money($order->total + $order->shipping_cost, 2) ?></td>
      <td><?php echo $order->payment_type ?></td>
      <td><input class="yak_right" type="text" name="funds_received[]" value="<?php echo $order->funds_received ?>" /></td>
      <td><?php echo $order->status ?></td>
      <td><?php echo yak_html_select(null, 'action[]', '', array( ''=>'', 'send_stock'=>'Send Stock', 'cancel_order'=>'Cancel Order', 'reset'=>'Reset')) ?></td>
      <td class="collapsible"></td>
    </tr>
    <tr class="expand-child <?php echo $class ?>">
      <td colspan="8">
        <table class="lowlight">
          <tr>
          <td width="25%">
              <h4><?php _e('Shipping Address', 'yak-admin') ?></h4>
              <pre><?php echo $order->address ?><?php echo $countries[$order->country_code] ?></pre>
          </td>
          <td width="25%">
              <h4><?php _e('Billing Address', 'yak-admin') ?></h4>
              <pre><?php echo $order->billing_address ?><?php echo $countries[$order->billing_country_code] ?></pre>
          </td>
          <td width="50%">   
              <h4><?php _e('Order Details', 'yak-admin') ?></h4>
              <table class="widefat">
                <thead>              
                <tr>
                  <th><?php _e('Title', 'yak-admin') ?></th>
                  <th><?php _e('Qty', 'yak-admin') ?></th>
                  <th><?php _e('Price', 'yak-admin') ?></th>
                  <th><?php _e('Subtotal', 'yak-admin') ?></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($order->items as $item) {
                $classy = 'even' == $classy ? '' : 'even';?>
                <tr class="<?php echo $classy ?>">
                  <td><?php echo $item->itemname ?></td>
                  <td><?php echo $item->quantity ?></td>
                  <td class="yak_numeric"><?php echo yak_format_money($item->price) ?></td>
                  <td class="yak_numeric"><?php echo yak_format_money($item->total) ?></td>
                </tr>
                <?php } ?>
                </tbody>
              </table>
              <p><strong><?php _e('Shipping costs', 'yak-admin') ?>:</strong> <?php echo yak_format_money($order->shipping_cost) ?><br />
              <strong><?php _e('Total', 'yak-admin') ?>:</strong> <?php echo yak_format_money($order->total + $order->shipping_cost) ?></p>       
          </td>      
          </tr>      
          </table>

        <?php if (isset($order->meta) && count($order->meta) > 0) { ?>
        <h4><?php _e('Additional Information', 'yak-admin') ?></h4>
        <table width="100%" class="lowlight">
          <?php foreach ($order->meta as $meta) { ?>
          <tr>
            <td width="25%"><?php echo $meta->name ?></td>
            <td width="75%"><?php echo $meta->value ?></td>
          </tr>
          <?php } ?>
        </table>
        <?php } ?>
        
        <?php if (isset($order->log) && count($order->log) > 0) { ?>
        <h4><?php _e('Order Log', 'yak-admin') ?></h4>

        <table width="100%" class="lowlight">
          <?php foreach ($order->log as $log) { ?>
          <tr>
            <td width="25%"><?php echo $log->time ?></td>
            <td width="75%"><?php echo $log->message ?></td>
          </tr>
          <?php } ?>
        </table>
        <?php } ?>

        <p><strong>Add Note:</strong> <input type="text" name="note[]" value="" size="120" /></p>
       
      </td>
    </tr>
    <?php } ?>
  </tbody>
  </table>
<?php } ?>
  <p><a id="export-data-link" href="#" onclick="return exportData('<?php echo get_bloginfo('wpurl') . '?feed=yak-orders&type=excel&n=' . rand(1, 1000000) ?>')">Export data</a></p>
</form>
</div>