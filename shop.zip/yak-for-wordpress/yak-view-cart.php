<?php
/*
See yak-for-wordpress.php for information and license terms
*/
if (file_exists(ABSPATH . 'wp-includes/l10n.php')) {
    require_once(ABSPATH . 'wp-includes/l10n.php');
}
else {
    require_once(ABSPATH . 'wp-includes/wp-l10n.php');
}

require_once('yak-promo-utils.php');

global $model;

$payment_types = yak_get_option(PAYMENT_TYPES, array());
$total_price = 0.0;

$has_promos = sizeof(yak_get_promotions(null, true)) > 0;

$referrer = yak_get_referrer();
?>

<form name="cart" method="post" action="<?php echo get_bloginfo('wpurl') ?>/?stage=cart">

<?php    
    if (isset($model['error_message'])) {
?>
    <div class="yak_error"><?php echo $model['error_message'] ?></div>
<?php
    }
?>
    
    <table id="shoppinglist1" class="yak_order">
        <col width="55%" />
        <col width="15%" />
        <col width="10%" />
        <col width="10%" />
        <col width="10%" />
        
        <tr>
            <th><?php _e('Title', 'yak') ?></th>
            <th class="yak_numeric"><?php _e('Price', 'yak') ?></th>
            <th class="yak_numeric"><?php _e('Qty', 'yak') ?></th>
            <th class="yak_numeric"><?php _e('Subtotal', 'yak') ?></th>
            <th></th>
        </tr>
<?php
    $total_price = 0;
    $total_quantity = 0;
    $total_weight = 0;
    $total_discount = 0;
    
    if (!empty($_SESSION['promo_code'])) {
        $promo = yak_get_promotion($_SESSION['promo_code']);
    }
    else {
        $promo = null;
    }
    
    $total_items = yak_get_total_items($_SESSION[ITEMS_NAME]);

    foreach ($_SESSION[ITEMS_NAME] as $key => $item) {
        $item->price = yak_calc_price($item->id, $item->cat_id);
        $item->discount = yak_calc_price_discount($item->price, $total_items, $promo);
        $total_discount += ($item->discount * $item->quantity);
        
        $total_price += $item->get_discount_total();
        $total_quantity += $item->quantity;
        
        $qtyid = 'item_' . $item->id . '_' . $item->cat_id;
?>
        <tr>
            <td class="yak_left"><a href="<?php echo get_bloginfo('wpurl') . '?' . $item->id_type . '=' . $item->id ?>"><?php echo $item->name ?></a></td>
            <td class="yak_numeric"><?php echo yak_format_money($item->price); ?></td>
            <td class="yak_center"><input id="<?php echo $qtyid ?>" name="<?php echo $qtyid ?>" type="text" style="text-align: right" value="<?php echo $item->quantity ?>" size="<?php echo yak_get_option(QUANTITY_INPUT_SIZE, 3) ?>" maxlength="<?php echo yak_get_option(QUANTITY_INPUT_SIZE, 3) ?>" /></td>
            <td class="yak_numeric"><?php echo yak_format_money($item->get_total()) ?></td>
            <td><button id="deletebutton" class="yak_button" type="submit" onclick="return deleteProduct('<?php echo $qtyid ?>')"><?php _e(' - ', 'yak') ?></button></td>
        </tr>
<?php
        if (isset($item->selected_options)) {
?>
        <tr>
            <td class="yak_left" colspan="5">
<?php
            foreach ($item->selected_options as $mitem) {
                echo "&nbsp;&nbsp;$mitem <br />";
            }
?>          
            </td>
        </tr>
<?php
        }
    }
    
    $auto_discount = false;
    if ($promo == null) {
        $promo = yak_get_promotion_by_threshold($total_price);
        if ($promo != null) {
            $price_discount = yak_calc_price_discount($total_price, $total_items, $promo);
            if ($price_discount > 0) {
                $total_price -= $price_discount;
                $total_discount = $price_discount;
                $auto_discount = true;
            }
        }
    }

    if ($promo != null && $total_discount > 0) {
?>
        <tr>
            <td class="yak_left">Total Discount (<?php echo $promo->description ?>)</td>
            <td></td>
            <td></td>
            <td class="yak_numeric">-<?php echo yak_format_money($total_discount) ?></td>
        </tr>
<?php
    }
?>
        <tr>
            <td colspan="3" class="yak_total"><?php _e('Total', 'yak') ?></td>
            <td class="yak_total"><?php echo yak_format_money($total_price, true) ?></td>
            <td></td>
        </tr>
        
        <tr>
            <td colspan="5">&nbsp;</td>
        </tr>
        
<?php
        if ($has_promos && !$auto_discount) {
?>
        <tr>
            <td colspan="3"><?php _e('Enter a promotion code, if you have one:', 'yak') ?></td>
            <td class="yak_right"><input type="text" name="promo_code" maxlength="20" size="10" value="<?php echo $_SESSION["promo_code"] ?>" /></td>
            <td></td>
        </tr>
<?php
        }
?>
        <tr>
            <td colspan="3"></td>
            <td class="yak_right"><button id="updatebutton" class="yak_medium_button" type="submit" onclick="return updateQuantities()"><?php _e('Update', 'yak') ?></button></td>
            <td></td>
        </tr>

        <tr>
            <td class="yak_right"><?php if (count($payment_types) > 1) { _e('How would you like to pay?', 'yak'); } ?></td>
            <td class="yak_right" colspan="2">
<?php       if (count($payment_types) > 1) { 
                echo yak_html_select(null, 'payment_type', '', array_keys($payment_types), false, null, true); 
            } 
            else {
                foreach ($payment_types as $key=>$value) {
?>
        <input type="hidden" name="payment_type" value="<?php echo $key ?>" />
<?php           
                }
            }
?></td> 
            <td class="yak_right"><button id="buybutton" class="yak_medium_button" type="submit" onclick="javascript:document.forms['cart'].action.value = 'address'"><?php _e('Buy', 'yak') ?></button></td>
            <td></td>
        </tr>

        <?php
                if (!empty($referrer)) {
        ?>
        <tr>
            <td class="yak_left" colspan="5"><br /><?php echo $referrer ?></td>
        </tr>
        <?php          
                }
        ?>
    </table>
        
    <input type="hidden" name="action" value="" />
    <input type="hidden" name="<?php echo $model['param_name'] ?>" value="<?php echo $model['post_id'] ?>" />
</form>
