<?php
/*
Plugin Name: YAK for WordPress
Plugin URI: http://www.wordpress.org/extend/plugins/yak-for-wordpress/
Description: A shopping cart plugin for WordPress
Version: 1.8.7
Author: Jason R Briggs
Author URI: http://www.briggs.net.nz/log

    Copyright 2006-2012  JASON R BRIGGS  (email : jasonrbriggs 'at' gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

define('YAK_VERSION_NUMBER', '1.8.7');

require_once('yak-model.php');
require_once('yak-utils.php');
require_once('yak-static.php');
require_once('yak-creditcard.php');
require_once('yak-view-order-widget.php');

if (in_array($_REQUEST['page_id'], yak_get_option(NO_CACHE_PAGES, array()))) {
    ini_set('session.cache_limiter', 'private');
}

if (yak_return_bytes(ini_get('memory_limit')) < 15728640) {
    ini_set("memory_limit", "15M");
}

if (file_exists(ABSPATH . 'wp-includes/pluggable.php')) {
    require_once(ABSPATH . 'wp-includes/pluggable.php');
}
else {
    require_once(ABSPATH . 'wp-includes/pluggable-functions.php');
}

load_plugin_textdomain('yak', 'wp-content/plugins/yak-for-wordpress/lang');

if (!function_exists('yak_add_meta')) {
    /**
     * add a custom field if it doesn't already exist, otherwise update
     */
    function yak_add_meta($post_id, $name, $value) {
        $curr = get_post_meta($post_id, $name, true);
        
        if (empty($curr)) {
            add_post_meta($post_id, $name, $value);   
        }
        else {
            update_post_meta($post_id, $name, $value);
        }
    }
}


if (!function_exists('yak_add_rewrite_rules')) {
    /**
     * add rewrite rules for the product feed.
     */
    function yak_add_rewrite_rules($wp_rewrite) {
        $new_rules = array(
            'feed/(.+)' => 'index.php?feed=' . $wp_rewrite->preg_index(1)
        );
        $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
    }
}


function yak_register_plugin_links($links, $file) {
    if (yak_str_contains($file, 'yak-for-wordpress')) {
        $links[] = '<a href="options-general.php?page=yak-for-wordpress.php">' . __('Settings') . '</a>';
        $links[] = '<a href="http://wordpress.org/extend/plugins/yak-for-wordpress/installation/" target="_BLANK">' . __('Installation') . '</a>';
        $links[] = '<a href="http://wordpress.org/extend/plugins/yak-for-wordpress/faq/" target="_BLANK">' . __('FAQ') . '</a>';
        $links[] = '<a href="http://www.briggs.net.nz/log/projects/yak-for-wordpress/handbook" target="_BLANK">' . __('Handbook') . '</a>';
    }
    return $links;
}


if (!function_exists('yak_create_orders_feed')) {
    /**
     * 
     */
    function yak_create_orders_feed() {
        global $post, $wpdb, $user_level, $countries;

        if ($user_level < 10) {
            die ("No access allowed");
        }

        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        
        if ($_GET['type'] == 'excel') {
            header("Content-Type: application/ms-excel");
            header("Content-Disposition: attachment; filename=orders.xls");
            $delim = "\t";
        }
        else {
            header("Content-Type: text/plain");
            $delim = ",";
        }
        $order_year = $_GET['year'];
        $order_month = $_GET['month'];
        $status = $_GET['status'];
        
        echo "order id" . $delim . "order number" . $delim . "order date" . $delim . "order value" . $delim . "recipient" . $delim . "email" . $delim . "address\n";
        $orders = yak_get_orders($status, null, $order_year, $order_month);
        foreach ($orders as $order) {
            $split = split("\n", $order->address);
            $email = $split[0];
            $recipient = $split[1];
            
            // this is a hack -- I don't store the address as separate fields, so to identify whether or not the
            // phone number is included in the address data, take a look and see if the 3rd line contains 6 digits or more
            if (yak_count_digits($split[2]) >= 6) {
                $addr = array_slice($split, 3);
            }
            else {
                $addr = array_slice($split, 2);
            }
            
            echo $order->id . $delim . $order->num . $delim . $order->time . $delim . number_format($order->total + $order->shipping_cost, 2, '.', '') . $delim
                . $recipient . $delim . $email . $delim . implode(',', $addr) . $countries[$order->country_code] . "\n";
        }
    }
}

if (!function_exists('yak_create_product_feed')) {
    /**
     * create a xml product feed (this is used for installations which need remote
     * products -- i.e. 2 yaks which share product info)
     */
    function yak_create_product_feed() {
        global $post;
        header("Content-Type: text/xml");
        $reqid = $_REQUEST['p'];
        echo "
<inventory>
";

        while (have_posts()) {
            the_post();
            $url = get_bloginfo('wpurl');
            $content = get_the_content($more_link_text, $stripteaser, $more_file);
        	$content = apply_filters('the_content', $content);
        	$content = str_replace(']]>', ']]&gt;', $content);

            $action = yak_get_tag_value($content, 'action="', '"');
            if ($action != null) {
                $new_action = yak_overlap($url, $action);
                $content = str_replace($action, $new_action, $content);
            }
    
            $content = str_replace('<button id="addbutton"', '<input type="hidden" name="check_referrer" value="true" /><button id="addbutton"', $content);
    
            echo "
<item id=\"$post->ID\">
<title>$post->post_title</title>
<content><![CDATA[";

echo $content;

echo "]]></content>
<test></test>
</item>
";
        }

        echo "</inventory>";
    }
}


if (!function_exists('yak_add_feeds')) {
    /**
     * hooks into WP to add the product feed and the rewrite rules to support it.
     */
    function yak_add_feeds() {
        global $wp_rewrite;
        add_feed('yak-products', 'yak_create_product_feed');
        add_feed('yak-orders', 'yak_create_orders_feed');
        add_action('generate_rewrite_rules', 'yak_add_rewrite_rules');
        $wp_rewrite->flush_rules();
    }
}

if (!function_exists('yak_admin')) {
    /**
     * used by the admin panel hook
     */
    function yak_admin() {    
        if (function_exists('add_management_page')) {
            $nonce = wp_create_nonce();
            add_management_page('Orders', 'Orders', 10, 'view-orders?_nonce=' . $nonce, 'yak_admin_orders');
            add_management_page('Products', 'Products', 10, 'view-products?_nonce=' . $nonce, 'yak_admin_products');
            add_management_page('Sales Reports', 'Sales Reports', 10, 'view-reports?_nonce=' . $nonce, 'yak_admin_reports');
        }
        
        if (function_exists('add_options_page')) {
            add_options_page('Yak Settings', 'Yak', 10, basename(__FILE__), 'yak_admin_options');
        }
    }
}


if (!function_exists('yak_admin_options')) {
    /**
     * Update options, and load the data for presenting the options screen.
     */
    function yak_admin_options() {
        global $countries, $wpdb;
        
        require_once('yak-promo-utils.php');
        require_once('yak-google-analytics.php');
        
        $google_analytics = new YakGoogleAnalytics();
        
        $registry =& Registry::getInstance();
        $promo_table =& $registry->get('promo_table');
        $promo_users_table =& $registry->get('promo_users_table');
        
        // update basic settings
        if (isset($_POST['options_update2'])) {            
            yak_admin_options_set(QUANTITY_INPUT_SIZE);
            if (isset($_POST[COOKIE_LIFETIME])) {
                update_option(COOKIE_LIFETIME, $_POST[COOKIE_LIFETIME] * 24 * 60 * 60);
            }
            yak_admin_options_set(INCLUDE_SHIPPING_COSTS);
            yak_admin_options_set(DEFAULT_COUNTRY);
            yak_admin_options_set(SHOW_OUT_OF_STOCK_MSG);
            yak_admin_options_set(CUSTOM_OUT_OF_STOCK_MSG);
            yak_admin_options_set(CONFIRMATION_EMAIL_ADDRESS);
            yak_admin_options_set(CONFIRMATION_SUBJECT);
            yak_admin_options_set(CONFIRMATION_MESSAGE);
            yak_admin_options_set(DEFAULT_SPECIAL_INSTRUCTIONS);
            yak_admin_options_set(TERMS_AND_CONDITIONS);
            yak_admin_options_set(EMPTY_BASKET_MESSAGE);
            yak_admin_options_set(REDIRECT_ON_BUY_TO);            
            yak_admin_options_set(DISPLAY_PRODUCT_OPTIONS, 'off');
            yak_admin_options_set(PRODUCT_CATEGORY_NAME);
            yak_admin_options_set(PRODUCT_PAGE_SIZE);
            yak_admin_options_set(ORDER_NUMBER_TYPE);
            yak_admin_options_set(USE_SSL, 'off');
            yak_admin_options_set(HIDDEN_LINK, 'off');
        }
         
        // update price & quantity settings if necessary
        if (isset($_POST['options_update3'])) {
            yak_admin_options_set(AUTO_DISCOUNT);            
            yak_admin_options_set(CURRENCY_SYMBOL);
            yak_admin_options_set(MONEY_FORMAT);
            yak_admin_options_set(CURRENCY_FORMAT);
            yak_admin_options_set(DECIMAL_POINT);
            yak_admin_options_set(THOUSANDS_SEPARATOR);
            yak_admin_options_set(PRICE_ROUNDING);
        }
        
        // update download settings if necessary
        if (isset($_POST['options_update4'])) {
            yak_admin_options_set(DOWNLOAD_URI);
            yak_admin_options_set(DOWNLOAD_EMAIL);
            yak_admin_options_set(DOWNLOAD_EMAIL_ADDRESS);
        }
         
        // update payment types
        if (isset($_POST['options_update5'])) {
            $payments = array();
            $payments_ci = array();
            $size = count($_POST['payment_type_names']);
            for ($i = 0; $i < $size; $i++) {
                $name = $_POST['payment_type_names'][$i];
                $redirect = $_POST['payment_type_redirects'][$i];
            
                // if we're using manual credit card payment, force SSL on
                // but allow no SSL for localhost (i.e. testing)
                if ($redirect == CREDIT_CARD && $_SERVER['SERVER_NAME'] != 'localhost' && $_SERVER['SERVER_NAME'] != 'localhost.localdomain') {
                    update_option(USE_SSL, 'on');
                }
            
                if (isset($name) && $name != '') {
                    $payments[$name] = $redirect;
                    $payments_ci[strtolower($name)] = $redirect;
                }
            }
        
            update_option(PAYMENT_TYPES, $payments);
            update_option(PAYMENT_TYPES_CASE_INSENSITIVE, $payments_ci);
            
            yak_admin_options_set(CURRENCY_CODE);

            $payment_options =& yak_get_payment_options();
            $used_options = array();
            foreach ($payment_options as $name=>$payment_option) {
                if (in_array($payment_option->get_name(), $used_options)) {
                    continue;
                }
                $payment_option->apply_options();
                $used_options[] = $payment_option->get_name();
            }
        }
        
        // special options
        if (isset($_POST['options_update6'])) {
            yak_admin_options_set(SPECIAL_OPTIONS_TEXT);
            yak_admin_options_set(NO_CACHE_PAGES, null, true);
        }
        
        // advanced options
        if (isset($_POST['options_update7'])) {
            yak_admin_options_set(HTTP_PROXY_URL);
            yak_admin_options_set(REMOTE_GRAB_SERVER);
            yak_admin_options_set(REMOTE_GRAB_PATH);
        }
        
        // shipping options
        if (isset($_POST['options_update8'])) {
            yak_admin_options_set(ADDRESS_NAME, 'off', 'options_update8');
            yak_admin_options_set(ADDRESS_PHONE, 'off', 'options_update8');
            yak_admin_options_set(ADDRESS, 'off', 'options_update8');
            yak_admin_options_set(ADDRESS_SEPARATE_BILLING, 'off', 'options_update8');
            yak_admin_options_set(SHIPPING_NOTES);
            
            yak_admin_options_set(SHIPPING_WEIGHT_CALC);
                        
            yak_admin_options_set(DEFAULT_SHIPPING);
            yak_admin_options_set(DEFAULT_SHIPPING_FIXED_ITEM);
            yak_admin_options_set(DEFAULT_SHIPPING_FIXED_ITEM_FIRST);
            yak_admin_options_set(DEFAULT_SHIPPING_WEIGHT);
            yak_admin_options_set(DEFAULT_SHIPPING_WEIGHT_FIRST);
            
            $enabled_countries = array();
            foreach ($countries as $country=>$name) {
                $key1 = 'yak_' . $country . '_shipping_fixed';
                $key2 = 'yak_' . $country . '_shipping_fixeditem';
                $key3 = 'yak_' . $country . '_shipping_fixeditemfirst';
                $key4 = 'yak_' . $country . '_shipping_weight';
                $key5 = 'yak_' . $country . '_shipping_weightfirst';
                $key6 = 'yak_cty_' . $country . '_enabled';

                update_option($key1, $_POST[$key1]);
                update_option($key2, $_POST[$key2]);
                update_option($key3, $_POST[$key3]);
                update_option($key4, $_POST[$key4]);
                update_option($key5, $_POST[$key5]);
                update_option($key6, yak_default($_POST[$key6], 'off'));
                
                if (get_option($key6) == 'on') {
                    $enabled_countries[$country] = $name;   
                }
            }
            update_option(ENABLED_COUNTRIES, $enabled_countries);
        }
        
        // update the promotions (if any)
        if (isset($_POST['options_update9'])) {
            $size = sizeof($_POST['promo_code']);
            for ($i = 0; $i < $size; $i++) {
                $promo_id = $_POST['promo_id'][$i];
                $promo_code = $_POST['promo_code'][$i];
                
                if (empty($promo_id) && empty($promo_code)) {
                    continue;
                }
                
                $promo_description = $_POST['promo_description'][$i];
                $promo_type = $_POST['promo_type'][$i];
                $promo_value = $_POST['promo_value'][$i];
                $day_promo_expiry = $_POST['day_promo_expiry'][$i];
                $month_promo_expiry = $_POST['month_promo_expiry'][$i];
                $year_promo_expiry = $_POST['year_promo_expiry'][$i];
                $promo_users = $_POST['promo_users'][$i];
            
                if (empty($day_promo_expiry) && empty($year_promo_expiry)) {
                    $promo_expiry = 'null';
                }
                else {
                    $promo_expiry = "'" . $year_promo_expiry . '-' . $month_promo_expiry . '-' . $day_promo_expiry . "'";
                }
                
                if (yak_str_contains($promo_type, 'threshold')) {
                    $threshold = $promo_code;
                }
                else {
                    $threshold = 'null';
                }
                
                $apply_users = false;
                
                if (!empty($promo_id) && empty($promo_code)) {
                    $wpdb->query("delete from $promo_users_table where promo_id = $promo_id");
                    $wpdb->query("delete from $promo_table where promo_id = $promo_id");
                }
                else if (!empty($promo_id)) {
                    $wpdb->query("update $promo_table
                                  set code = '$promo_code', promo_type = '$promo_type', description = '$promo_description',
                                  threshold = $threshold, value = '$promo_value', expiry_date = $promo_expiry
                                  where promo_id = $promo_id");
                    $apply_users = true;
                }
                else if (!empty($promo_code)) {
                    $wpdb->query("insert into $promo_table (code, promo_type, description, threshold, value, expiry_date)
                                  values ('$promo_code', '$promo_type', '$promo_description', $threshold, '$promo_value', $promo_expiry)");
                    $promo_id = $wpdb->insert_id;
                    $apply_users = true;
                }
            
                // specific users can be allowed access to a particular code
                // in this case, split the comma separated list of usernames
                // then look up via the user_nicename in WP_users    
                if ($apply_users) {
                    $wpdb->query("delete from $promo_users_table where promo_id = $promo_id");
                    if (!empty($promo_users)) {
                        $users = explode(',', $promo_users);
                        $users_size = count($users);
                        for ($j = 0; $j < $users_size; $j++) {
                            if (empty($users[$j])) {
                                continue;
                            }
                            $wpdb->query("insert into $promo_users_table (promo_id, user_id)
                                          select $promo_id, ID
                                          from $wpdb->users u
                                          where u.user_nicename = lower('" . $users[$j] . "')");
                        }
                    }
                }
            }
        }
        
        // Google analytics options
        if (isset($_POST['options_update10'])) {
            $google_analytics->apply_options();
        }
        
        // list of pages for some dropdowns
        $pages = get_pages();
        
        // load data for display
        global $model;
        $model[QUANTITY_INPUT_SIZE] = yak_get_option(QUANTITY_INPUT_SIZE, '3');
        $model[INCLUDE_SHIPPING_COSTS] = yak_get_option(INCLUDE_SHIPPING_COSTS, 'yes');
        $model[CURRENCY_SYMBOL] = yak_get_option(CURRENCY_SYMBOL, __('baht', 'yak'));
        $model[MONEY_FORMAT] = yak_get_option(MONEY_FORMAT, '%d');
        $model[CURRENCY_FORMAT] = yak_get_option(CURRENCY_FORMAT, '%1$s %2$s');
        $model[DECIMAL_POINT] = yak_get_option(DECIMAL_POINT, '.');
        $model[THOUSANDS_SEPARATOR] = yak_get_option(THOUSANDS_SEPARATOR, ',');
        $model[DEFAULT_COUNTRY] = yak_get_option(DEFAULT_COUNTRY, 'thailand');
        $model[SHOW_OUT_OF_STOCK_MSG] = yak_get_option(SHOW_OUT_OF_STOCK_MSG, 'yes');
        $model[CUSTOM_OUT_OF_STOCK_MSG] = yak_get_option(CUSTOM_OUT_OF_STOCK_MSG, '');
        $model[CONFIRMATION_EMAIL_ADDRESS] = yak_get_option(CONFIRMATION_EMAIL_ADDRESS, '');
        $model[CONFIRMATION_SUBJECT] = yak_get_option(CONFIRMATION_SUBJECT, '');
        $model[CONFIRMATION_MESSAGE] = stripslashes(yak_get_option(CONFIRMATION_MESSAGE, ''));
        $model[ORDER_NUMBER_TYPE] = yak_get_option(ORDER_NUMBER_TYPE, GENERATED);
        $model[COOKIE_LIFETIME] = yak_get_option(COOKIE_LIFETIME, '2592000') / (24*60*60);
        $model[REDIRECT_ON_BUY_TO] = yak_get_option(REDIRECT_ON_BUY_TO, '');
        $model[AUTO_DISCOUNT] = yak_get_option(AUTO_DISCOUNT, '0.9');
        $model[PRICE_ROUNDING] = yak_get_option(PRICE_ROUNDING, '0');
        $model[DISPLAY_PRODUCT_OPTIONS] = yak_get_option(DISPLAY_PRODUCT_OPTIONS, 'off');
        $model[PRODUCT_CATEGORY_NAME] = yak_get_option(PRODUCT_CATEGORY_NAME, 'products');
        $model[PRODUCT_PAGE_SIZE] = yak_get_option(PRODUCT_PAGE_SIZE, '10');
        $model[USE_SSL] = yak_get_option(USE_SSL, 'off');
        $model[HIDDEN_LINK] = yak_get_option(HIDDEN_LINK, 'on');
        $model[DEFAULT_SPECIAL_INSTRUCTIONS] = stripslashes(yak_get_option(DEFAULT_SPECIAL_INSTRUCTIONS, ''));
        $model[TERMS_AND_CONDITIONS] = stripslashes(yak_get_option(TERMS_AND_CONDITIONS, ''));
        $model[EMPTY_BASKET_MESSAGE] = stripslashes(yak_get_option(EMPTY_BASKET_MESSAGE, ''));
        
        $model[DOWNLOAD_URI] = yak_get_option(DOWNLOAD_URI, '');
        $model[DOWNLOAD_EMAIL] = stripslashes(yak_get_option(DOWNLOAD_EMAIL, ''));
        $model[DOWNLOAD_EMAIL_ADDRESS] = yak_get_option(DOWNLOAD_EMAIL_ADDRESS, '');
        
        $model[PAYMENT_TYPES] = yak_get_option(PAYMENT_TYPES, null);
    
        $model[CURRENCY_CODE] = yak_get_option(CURRENCY_CODE, '');
                
        $model[SPECIAL_OPTIONS_TEXT] = yak_get_option(SPECIAL_OPTIONS_TEXT, '');
        $model[NO_CACHE_PAGES] = yak_get_option(NO_CACHE_PAGES, array());
        $model[HTTP_PROXY_URL] = yak_get_option(HTTP_PROXY_URL, '');
        
        $model[ADDRESS_NAME] = yak_get_option(ADDRESS_NAME, 'on');
        $model[ADDRESS_PHONE] = yak_get_option(ADDRESS_PHONE, 'on');
        $model[ADDRESS] = yak_get_option(ADDRESS, 'on');
        $model[ADDRESS_SEPARATE_BILLING] = yak_get_option(ADDRESS_SEPARATE_BILLING, 'on');
        
        $model[SHIPPING_NOTES] = yak_get_option(SHIPPING_NOTES, '');
        
        $model[REMOTE_GRAB_SERVER] = yak_get_option(REMOTE_GRAB_SERVER, '');
        $model[REMOTE_GRAB_PATH] = yak_get_option(REMOTE_GRAB_PATH, '');
        
        $model[SHIPPING_WEIGHT_CALC] = yak_get_option(SHIPPING_WEIGHT_CALC, '');
        $model[DEFAULT_SHIPPING] = yak_get_option(DEFAULT_SHIPPING, '');
        $model[DEFAULT_SHIPPING_FIXED_ITEM] = yak_get_option(DEFAULT_SHIPPING_FIXED_ITEM, '');
        $model[DEFAULT_SHIPPING_FIXED_ITEM_FIRST] = yak_get_option(DEFAULT_SHIPPING_FIXED_ITEM_FIRST, '');
        $model[DEFAULT_SHIPPING_WEIGHT] = yak_get_option(DEFAULT_SHIPPING_WEIGHT, '');
        $model[DEFAULT_SHIPPING_WEIGHT_FIRST] = yak_get_option(DEFAULT_SHIPPING_WEIGHT_FIRST, '');
        
        foreach ($countries as $country=>$ignore) {
            $key1 = 'yak_' . $country . '_shipping_fixed';
            $key2 = 'yak_' . $country . '_shipping_fixeditem';
            $key3 = 'yak_' . $country . '_shipping_fixeditemfirst';
            $key4 = 'yak_' . $country . '_shipping_weight';
            $key5 = 'yak_' . $country . '_shipping_weightfirst';
            $key6 = 'yak_cty_' . $country . '_enabled';
            $model[$key1] = yak_get_option($key1, '');
            $model[$key2] = yak_get_option($key2, '');
            $model[$key3] = yak_get_option($key3, '');
            $model[$key4] = yak_get_option($key4, '');
            $model[$key5] = yak_get_option($key5, '');
            $model[$key6] = yak_get_option($key6, 'on');
        }
        
        $model[CATEGORIES] = array(); 
        foreach (get_categories('hide_empty=0') as $cat) {
            $model[CATEGORIES][$cat->category_nicename] = $cat->cat_name;
        }
        
        $model[PAGE_IDS] = array();
        $model[PAGES] = array();
        $model[PAGE_IDS][''] = '';
        $model[PAGES][''] = '';
        foreach ($pages as $page) {
            $model[PAGE_IDS][$page->ID] = $page->post_title;
            $model[PAGES]['?page_id=' . $page->ID] = $page->post_title;
        }
        
        $model[PROMOTIONS] = yak_get_promotions();
        
        // redirect to the settings screen
        include 'yak-view-settings.php';
    }
}


if (!function_exists('yak_admin_orders')) {
    /**
     * Display the orders-admin panel for this plugin - and update orders accordingly when an admin makes changes
     */
    function yak_admin_orders() {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        $order_log_table =& $registry->get('order_log_table');
        $order_meta_table =& $registry->get('order_meta_table');
        $order_detail_table =& $registry->get('order_detail_table');
        $product_detail_table =& $registry->get('product_detail_table');
        
        // do the update of order details
        if (isset($_POST['orders_update'])) {
            $size = count($_POST['id']);
            for ($i = 0; $i < $size; $i++) {            
                $id = $_POST['id'][$i];
                $funds = $_POST['funds_received'][$i];
                $action = yak_default($_POST['action'][$i], '');
                $note = $_POST['note'][$i];
                
                if (yak_str_contains($funds, ',')) {
                    $funds = str_replace(',', '.', $funds);
                }
                
                $status = '';
                
                $check_order = false;
                if ($action == 'send_stock') {
                    $status = ", status = '" . STOCK_SENT . "'";
                    
                    yak_insert_orderlog($id, 'Stock sent');
                    $wpdb->query("update $order_meta_table set value = '****************' where order_id = $id and name = 'CC number'");
                    
                    $check_order = true;
                }
                else if ($action == 'cancel_order') {
                    $status = ", status = '" . CANCELLED . "'";
                    
                    yak_insert_orderlog($id, 'Order cancelled');
                    $wpdb->query("update $order_meta_table set value = '****************' where order_id = $id and name = 'CC number'"); 
                    
                    $results = $wpdb->get_results("select post_id, cat_id, quantity from $order_detail_table where id = $id");
                    
                    foreach ($results as $result) {
                        $pid  = $result->post_id;
                        $cid = $result->cat_id;
                        $oqty = $result->quantity;
                        $wpdb->query("update $product_detail_table set quantity = quantity + $oqty where post_id = $pid and cat_id = $cid");
                    }
                }
                else if ($action == 'reset') {
                    $status = ", status = ''";
                    
                    yak_insert_orderlog($id, 'Order reset to unfulfilled');
                } 
                
                $wpdb->query("update $order_table set funds_received = $funds $status where id = $id");
                
                if (isset($note) && $note != '') {
                    yak_insert_orderlog($id, $note);   
                }
                
                if ($check_order) {
                    yak_check_order($id);   
                }
                
            }
        }
        
        // load data for display       
        $status = $_POST['status'];
        $order_year = $_POST['year_order_date'];
        $order_month = $_POST['month_order_date'];
        $order_num = $_POST['order_num'];
        
        if (isset($_POST['orders_query']) || isset($_POST['orders_update'])) {
            $orders = yak_get_orders($status, $order_num, $order_year, $order_month);
            global $model;
            $model['orders'] = $orders;
            $model['order_year'] = $order_year;
            $model['order_month'] = $order_month;
        }
        
        include 'yak-view-orders.php';
    }
}


if (!function_exists('yak_admin_products')) {
    /**
     * Display the products-admin panel for this plugin - and update products accordingly when an admin makes changes
     */
    function yak_admin_products() {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');
        
        $upd = isset($_POST['products_update']);
        
        $products = yak_get_products();
        
        reset($products);
        while (list($key, $value) = each($products)) {       
            $product =& $products[$key];
        
            $types = yak_get_product_categories($product->id, $product->status);
        
            if ($upd) {
                $title = $_POST['title_' . $product->id];
                $price = $_POST['price_' . $product->id];
                $discount_override = $_POST['discount_override_' . $product->id];
                $multi_select_options = $_POST['multi_select_' . $product->id];
                $multi_select_min = $_POST['multi_select_min_' . $product->id];
                $multi_select_max = $_POST['multi_select_max_' . $product->id];
                
                $product->title = $title;
                $product->price = $price;
                $product->discount_override = $discount_override;
                $product->multi_select_options = $multi_select_options;
                $product->multi_select_min = $multi_select_min;
                $product->multi_select_max = $multi_select_max;
                
                yak_update_product($product->id, $price, $title, $discount_override, $multi_select_options, $multi_select_min, $multi_select_max);
                
                $types = yak_update_product_types($product->id, $types);
            }
            
            $product->types = $types;
        }
        
        unset($product);
        
        global $model;
        $model['products'] = $products;
        
        include 'yak-view-products.php';
    }
}


if (!function_exists('yak_admin_reports')) {
    /**
     * Display the reports admin panel
     */
    function yak_admin_reports() {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        $order_detail_table =& $registry->get('order_detail_table');
                
        global $model;
        $model = array();

        $year = $_REQUEST['year'];
        
        if (!isset($year) || $year == '') {
            $year = date('Y');   
        }
        $model['year'] = $year;
        
        // query for yearly total
        $row = $wpdb->get_row("select sum(o.shipping_cost + (od.price * od.quantity)) as total 
                               from $order_table o, $order_detail_table od 
                               where o.id = od.id 
                               and o.time >= '$year-01-01' 
                               and o.time <= '$year-12-31'
                               and o.status = 'STOCK SENT'");        
        $model['year_total'] = $row->total;
        
        $rows = $wpdb->get_results("select distinct year(time) as yr from $order_table order by time desc");
        $years = array();
        foreach ($rows as $row) {
            $years[] = $row->yr;
        }
        $model['years'] = $years;
        
        // query for monthly totals
        $rows = $wpdb->get_results("select monthname(time) as mth, sum(o.shipping_cost + (od.price * od.quantity)) as total 
                                    from $order_table o, $order_detail_table od 
                                    where o.id = od.id 
                                    and o.time >= '$year-01-01' 
                                    and o.time <= '$year-12-31'
                                    and o.status = 'STOCK SENT'
                                    group by month(time) 
                                    order by month(time)");
        $monthly_totals = array();
        foreach ($rows as $row) {
            $mt = new YakTotal($row->mth, $row->total);
            $monthly_totals[] = $mt;
        }
        $model['monthly_totals'] = $monthly_totals;

        // query for top sellers for the year
        $rows = $wpdb->get_results("select od.post_id, od.cat_id, count(*) as total_sold, sum(o.shipping_cost + (od.price * od.quantity)) as total_value
                                    from $order_detail_table od, $order_table o 
                                    where od.id = o.id
                                    and o.time >= '$year-01-01' 
                                    and o.time <= '$year-12-31'
                                    and o.status = 'STOCK SENT'
                                    group by post_id, cat_id 
                                    order by total_sold desc, total_value desc
                                    limit 5");
                                    
        $year_best = array();
        foreach ($rows as $row) {
            $total = new YakTotal(yak_get_title($row->post_id, $row->cat_id), $row->total_sold, $row->total_value);
            $year_best[] = $total;
        }
        $model['year_best'] = $year_best;
        
        // query for top sellers for the month
        $rows = $wpdb->get_results("select month(o.time) as mth, monthname(o.time) as mthname, od.post_id, od.cat_id, count(*) as total_sold, sum(o.shipping_cost + (od.price * od.quantity)) as total_value
                                    from $order_detail_table od, $order_table o 
                                    where od.id = o.id
                                    and o.time >= '$year-01-01' 
                                    and o.time <= '$year-12-31'
                                    and o.status = 'STOCK SENT'
                                    group by mth, post_id, cat_id 
                                    order by mth asc, total_sold desc, total_value desc");
                                    
        $month_best = array();
        foreach ($rows as $row) {
            if (!array_key_exists($row->mth, $month_best)) {
                $month_best['' . $row->mth] = array();
            }
             
            if (count($month_best['' . $row->mth]) >= 5) {
                continue;   
            }
            
            $total = new YakTotal($row->mthname, $row->total_sold, $row->total_value, yak_get_title($row->post_id, $row->cat_id));
            
            $month_best['' . $row->mth][] = $total;
        }
        $model['month_best'] = $month_best;
        
        include 'yak-view-reports.php';
    }
}


if (!function_exists('yak_allowed_promo')) {
    /**
     * return true if the current user is allowed access to a promo.
     * Note: defaults to true if the promo has no users assigned.
     */
    function yak_allowed_promo($promo) {
        global $wpdb, $user_ID;
        
        if (count($promo->users) > 0) {
            if (!isset($user_ID) || $user_ID == null) {
                return false;
            }
            $sql = "select user_nicename
                    from $wpdb->users
                    where ID = $user_ID";
            $row = $wpdb->get_row($sql);
            if (!in_array($row->user_nicename, $promo->users)) {
                return false;
            }
        }
        
        return true;
    }
}


if (!function_exists('yak_buy')) {
    /**
     * Output the buy button to the page
     */
    function yak_buy($echo = true) {
        $begin = yak_buy_begin($echo);
        $content = yak_buy_content($echo);
        $end = yak_buy_end($echo);
        
        return $begin . "\n" . $content . "\n" . $end;
    }
}


if (!function_exists('yak_buy_begin')) {
    /**
     * Begin the output of the buy button html (output the form element)
     */
    function yak_buy_begin($echo = true) {
        if (yak_get_option(USE_SSL, 'off') == 'on') {
            $srv = str_replace('http:', 'https:', get_bloginfo('wpurl') . '/index.php');
        }
        else {
            $srv = get_bloginfo('wpurl') . '/index.php';
        }
        
        $rtn = '<form name="buynow" action="' . $srv . '#buynow_button" method="post">';
        
        if ($echo == true) {
            echo $rtn; 
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_buy_content')) {
    /**
     * Output the content of the buy button (drop down box for the types, the image of the buy button, etc).
     */
    function yak_buy_content($echo = true) {
        global $wpdb, $post, $wp_query;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        $order_detail_table =& $registry->get('order_detail_table');
        
        $yak_post =& $registry->get('yak_post');
        
        $rtn = '';
        
        // yak_post can be used to override 'the_loop' post
        if (isset($yak_post)) {
            $productpost = $yak_post;
        }
        else {
            $productpost = $post; 
        }
        
        // data we'll use for submitting the form (do we redirect to another page,
        // or direct back to this page or post?)
        $redirect = yak_get_option(REDIRECT_ON_BUY_TO, '');
        if ($redirect != '') {
            $param_name = 'page_id';
            $id = $redirect;
        }
        else if (!$wp_query->is_page) {
            $param_name = 'p';
            $id = $productpost->ID;
        }
        else {
            $param_name = 'page_id';
            $id = $productpost->ID;
        }
        
        // the product being bought is either a post, or a page
        if (strtolower($productpost->post_type) == 'page') {
            $productpost_param_name = 'page_id';
        }
        else {
            $productpost_param_name = 'p';   
        }
        
        // if price isn't set then don't bother displaying the button, nor the out of stock
        // message -- this is so you can add all the functions in your post but have nothing
        // displayed until you set the yak_* fields
        $prod = yak_get_product($productpost->ID);
        
        if (!empty($prod) && !empty($prod->price)) {
            $categories = yak_get_product_categories($productpost->ID, $productpost->post_type, false);
            if (sizeof($categories)) {
                $rtn = '<a name="buynow_button"></a>';
                
                if (!empty($prod->multi_select_options)) {
                    $rtn .= '<table class="yak-multi">';
                    $count = 0;
                    $options = $prod->get_multi_select_options();
                    foreach ($options as $val) {
                        if ($count % 2 == 0) {
                            $rtn .= '<tr>';
                        }
                        if (yak_str_contains($val, ',')) {
                            $v = explode(',', $val);
                            $name = $v[0];
                            $img = "<img src=\"" . $v[1] . "\" alt=\"$name\" /><br />";
                        }
                        else {
                            $name = $val;
                            $img = '';
                        }
                        $rtn .= "<td class=\"yak-multi\">$img $name <input name=\"multiselect[]\" type=\"checkbox\" value=\"$name\" /></td>";

                        if ($count % 2 == 1 || $count + 1 == count($options)) {
                            $rtn .= '</tr>';                            
                        }
                        $count++;
                    }
                    $rtn .= '</table>';
                }
                
                $rtn .= '<table class="buybutton"><tr>';
    
                $special_options = get_post_meta($productpost->ID, 'yak_special_options', true);
                if (isset($special_options) && $special_options != '') {
                    $rtn .= '    <td>' . yak_get_option(SPECIAL_OPTIONS_TEXT, '') . '</td>
                                 <td>' . yak_html_select(null, 'special_option', '', split("\n", $special_options), false, null, true) . '</td>
                             </tr>
                             <tr>';
                }
                
                $arr = array();
                foreach ($categories as $cat) {
                    $last = $cat->cat_id;
                    if ($cat->name == 'default') {
                        continue;   
                    }
                    else {
                        $arr[$cat->cat_id] = $cat->name;
                    }
                }
                
                $catsize = sizeof($arr);
                
                if ($catsize > 0 && (yak_get_option(DISPLAY_PRODUCT_OPTIONS, 'off') == 'on' || $catsize > 1)) {
                    $rtn .= '<td>' . yak_html_select(null, 'category', '', $arr, false) . "</td>\n<td>";
                }
                else {
                    $rtn .= '<td><input type="hidden" name="category" value="' . $last . '" />';   
                }
                                            
                $rtn .= '<input type="hidden" name="buynow" value="' . $productpost->ID . '" />' .
                        '<input type="hidden" name="buynow_param" value="' . $productpost_param_name . '" />' .
                        '<input type="hidden" name="' . $param_name . '" value="' . $id .'" />' .
                        '<button id="addbutton" class="yak_button" type="submit" onclick="return validateBuy(this, ' . $prod->multi_select_min . ',' . $prod->multi_select_max . ')"><span>' . __('Add to cart', 'yak') . '</span></button>' . 
                        '</td>';
                
                $rtn .= '</tr></table>';
                
                // were there any messages when the button was pressed (set in yak_init)?
                $buynow_error_message = $GLOBALS['buynow_error_message_' . $productpost->ID];
                if (isset($buynow_error_message) && $buynow_error_message != '') {
                    $rtn .= '&nbsp;' . $buynow_error_message;   
                }
            }
            else if (yak_get_option(SHOW_OUT_OF_STOCK_MSG, 'no') == 'yes') {
                $rtn .= '<br />(' . yak_get_option(CUSTOM_OUT_OF_STOCK_MSG, __('Currently out of online stock', 'yak')) . ')';
            }
        }
        
        if ($echo == true) {
            echo $rtn;   
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_buy_end')) {
    /**
     * Output the the end of the buy button (close the form).
     */
    function yak_buy_end($echo = true) {
        $rtn = '</form>';
        
        if ($echo == true) {
            echo $rtn;   
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_calc_price')) {
    /**
     * Calculate price of a product taking into account any automatic discount
     */
    function yak_calc_price($id, $cat_id = null) {
        $discount = yak_get_option(AUTO_DISCOUNT, 1);
        $price_rounding = yak_get_option(PRICE_ROUNDING, 0);
        $prod = yak_get_product($id);
        if (!empty($prod->discount_override)) {
            $discount = $prod->discount_override;
        }
        $price = $prod->price;
        
        if ($cat_id != null) {
            $prod_type = yak_get_product_type($id, $cat_id);
            $override_price = $prod_type->override_price;
            if (isset($override_price) && $override_price > 0) {
                $price = $prod_type->override_price;
            }
        }

        $rtn = number_format(0.0 + ($price * $discount), $price_rounding, '.', '');

        return $rtn;
    }
}


if (!function_exists('yak_calc_shipping')) {
    /**
     * calculate the shipping cost by weight and country
     */
    function yak_calc_shipping($total_weight, $total_items, $shipping_country) {
        $shipping = yak_get_option('yak_' . $shipping_country . '_shipping_fixed', '');
        $shipping_fixed_first = yak_get_option('yak_' . $shipping_country . '_shipping_fixeditemfirst', 0);
        $shipping_fixed = yak_get_option('yak_' . $shipping_country . '_shipping_fixeditem', '');
        $shipping_weight_first = yak_get_option('yak_' . $shipping_country . '_shipping_weightfirst', '');
        $shipping_weight = yak_get_option('yak_' . $shipping_country . '_shipping_weight', '');
        
        $act_shipping_cost = yak_calc_shipping_internal($total_items, $total_weight, $shipping, $shipping_fixed, $shipping_fixed_first, $shipping_weight, $shipping_weight_first);
        if ($act_shipping_cost == null) {
            $def_shipping = yak_get_option(DEFAULT_SHIPPING, '');
            $def_shipping_fixed_first = yak_get_option(DEFAULT_SHIPPING_FIXED_ITEM_FIRST, 0);
            $def_shipping_fixed = yak_get_option(DEFAULT_SHIPPING_FIXED_ITEM, '');
            $def_shipping_weight_first = yak_get_option(DEFAULT_SHIPPING_WEIGHT_FIRST, '');
            $def_shipping_weight = yak_get_option(DEFAULT_SHIPPING_WEIGHT, '');

            $act_shipping_cost = yak_calc_shipping_internal($total_items, $total_weight, $def_shipping, $def_shipping_fixed, $def_shipping_fixed_first, $def_shipping_weight, $def_shipping_weight_first);
            
            if ($act_shipping_cost == null) {
                $act_shipping_cost = 0.0;
            }
        }
        
        return $act_shipping_cost;
    }
}


if (!function_exists('yak_calc_shipping_internal')) {
    /**
     * The 'internals' of shipping calculation
     *
     * @param total_items the total number of items
     * @param total_weight the total weight of all items
     * @param shipping the default shipping value (returned first if present)
     * @param shipping_fixed fixed shipping value (per item calc)
     * @param shipping_fixed_first fixed shipping value for the first item
     * @param shipping_weight weight-based shipping value (calculated by weight)
     * @param shipping_weight_first weight-based shipping value for the first 100gms
     */
    function yak_calc_shipping_internal($total_items, $total_weight, $shipping, $shipping_fixed, $shipping_fixed_first, $shipping_weight, $shipping_weight_first) {
        if (!empty($shipping)) {
            return $shipping;
        }
        else if (!empty($shipping_fixed)) {
            $act_shipping_cost = 0.0;
            if ($total_items >= 1) {
                $act_shipping_cost += $shipping_fixed_first;
            }
            if ($total_items > 1) {
                $act_shipping_cost += (($total_items - 1) * $shipping_fixed);
            }
            return $act_shipping_cost;
        }
        else if (!empty($shipping_weight) && $total_weight > 0) {
            $weight_calc = yak_get_option(SHIPPING_WEIGHT_CALC, DEFAULT_SHIPPING_WEIGHT_CALC);
            $act_shipping_cost = 0.0;
            if (!empty($shipping_weight_first)) {
                $act_shipping_cost += $shipping_weight_first;
                $total_weight -= $weight_calc;
            }
            if ($total_weight > 0) {
                $act_shipping_cost += ($shipping_weight * ceil($total_weight / $weight_calc));
            }
            return $act_shipping_cost;
        }
        else {
            return null;
        }
    }
}


if (!function_exists('yak_checkout')) {
    /**
     * Display the checkout page.
     */
    function yak_checkout() {
        global $post, $model, $credit_card_payments; 
        
        $param_name = yak_get_post_param();
        
        // get the payment type if set
        if (isset($_POST['payment_type'])) {
            $_SESSION['payment_type'] = $_POST['payment_type'];   
        }
        
        $payment_types = yak_get_option(PAYMENT_TYPES, null);
        $ptype = $_SESSION['payment_type'];
        $ptypeval = $payment_types[$ptype];
        
        $items = $_SESSION[ITEMS_NAME];
        
        $_SESSION['checkout_param'] = $param_name;
        $_SESSION['checkout_param_val'] = $_REQUEST[$param_name];
        
        $action = $_REQUEST['action'];

        // update button was hit, or address confirmation        
        if ($action == 'update' || $action == 'address') {        
            $order_value = 0.0;
            $order_items = 0;
            foreach ($items as $key => $item) {
                $itemkey = 'item_' . $key;
                $_POST[$itemkey] = round($_POST[$itemkey]);
                 
                if (!isset($_POST[$itemkey]) || empty($_POST[$itemkey]) || $_POST[$itemkey] == 0) {
                    $items[$key] = NULL;
                    unset($items[$key]);
                }
                else {
                    $qty = $_POST[$itemkey];
                    $order_items += $qty;
                    $items[$key]->quantity = $qty;
                    $items[$key]->item_weight = yak_get_product_weight($items[$key]->id, $items[$key]->cat_id);
                    $order_value += (yak_calc_price($items[$key]->id, $items[$key]->cat_id) * $qty);
                }
                if ($order_items == 0) {
                    unset($_SESSION['current_order_items']);
                    unset($_SESSION['current_order_value']);
                }
                else {
                    $_SESSION['current_order_items'] = $order_items;
                    $_SESSION['current_order_value'] = $order_value;
                }
            }
        }
    
        // reset the items in the session
        $_SESSION[ITEMS_NAME] = $items;
        
        // start building the 'model' (data used in the next screenflow)
        $model = array('items' => $items, 'param_name' => $param_name, 'post_id' => $post->ID);
        
        // drop out if no items found in the session
        if (!isset($_SESSION[ITEMS_NAME]) || sizeof($items) < 1) {
            $msg = stripslashes(yak_get_option(EMPTY_BASKET_MESSAGE, ''));
            
            if (empty($msg)) {
                return __('You have no items in your shopping basket', 'yak');
            }
            else {
                return $msg;
            }
        }
    
        if ($action == 'update' || $action == 'address') {
            require_once('yak-promo-utils.php');
            
            if (!empty($_POST['promo_code'])) {
                $promo_code = $_POST['promo_code'];
                $promos = yak_get_promotions($promo_code, true);
                if (sizeof($promos) > 0) {
                    if (!yak_allowed_promo($promos[0])) {
                        $model['error_message'] = '<p>' . __("You don't have access to this promotion code", 'yak') . '</p>';
                        $action = 'cart';
                    }
                    else {
                        $_SESSION['promo_code'] = $promo_code;
                    }
                }
                else {
                    $model['error_message'] = '<p>' . __('Invalid promotion code', 'yak') . '</p>';
                    $action = 'cart';
                }
            }
            else {
                unset($_SESSION['promo_code']);
            }
        }
    
        // default to displaying the first cart screen
        if ($action == 'update' || empty($action)) {
            $action = 'cart';            
        }
        
        // store the address data in the model
        if ($action == 'address' || $action == 'jump-to-address') {
            $model['shipping_address'] = yak_get_address('shipping');
            $model['billing_address'] = yak_get_address('billing');
            $action = 'address';
        }
        
        if ($action == 'confirm') {
            $errors = yak_validate_address('shipping');
            
            if (yak_checkout_error($model, __('Error(s) have occurred validating the shipping address information you provided', 'yak'), $errors)) {
                // drop back to display the address
                $action = 'address';
            }
            else {
                $model['shipping_address'] = yak_get_address('shipping');
                $model['billing_address'] = yak_get_address('billing');
                
                $payment_options =& yak_get_payment_options();
                $next_action = $payment_options[$ptypeval]->get_next_action();
                if ($next_action != null) {
                    $action = $next_action;
                }                
            }
        }
        else if ($action == 'confirm_cc') {            
            // we've come from credit card form, so process accordingly
            
            $errors = array();
            
            if (!check_credit_card($_POST['cc_number'], $_POST['cc_type'], $errornumber, $errortext)) {
                $errors[] = $errortext;
            }
            
            if (mktime(0, 0, 0, $_POST['cc_expiry_month'], date('d'), $_POST['cc_expiry_year']) < mktime()) {
                $errors[] = __('Credit card has already expired', 'yak');   
            }
            
            if (empty($_POST['cc_name'])) {
                $errors[] = __('No cardholder name provided', 'yak');
            }
            
            if (empty($_POST['cc_security_code'])) {
                $errors[] = __('No security code provided', 'yak');
            }
            
            if (yak_checkout_error($model, __('Error(s) in your credit card details', 'yak'), $errors)) {
                $action = 'cc';
            }
            else {
                $model['shipping_address'] = yak_get_address('shipping');
                $model['billing_address'] = yak_get_address('billing');
                
                $_SESSION['cc'] = array('number' => $_POST['cc_number'],
                                        'security_code' => $_POST['cc_security_code'],
                                        'type' => $_POST['cc_type'],
                                        'name' => $_POST['cc_name'],
                                        'expiry' => $_POST['cc_expiry_month'] . '/' . $_POST['cc_expiry_year']);

                $action = 'confirm';
            }
        }
        else if ($action == 'confirm_accrecv') {
            // we've come from the accounts receivable form, so process accordingly
            
            $errors = array();
            
            if (empty($_POST['accrecv_number'])) {
                $errors[] = __('No account number provided', 'yak');
            }
            
            if (empty($_POST['accrecv_name'])) {
                $errors[] = __('No account name provided', 'yak');
            }
            
            if (yak_checkout_error($model, __('Error(s) in your account details', 'yak'), $errors)) {
                $action = 'accrecv';
            }
            else {
                $model['shipping_address'] = yak_get_address('shipping');
                $model['billing_address'] = yak_get_address('billing');
                
                $_SESSION['accrecv'] = array('number' => $_POST['accrecv_number'],
                                             'name' => $_POST['accrecv_name']);

                $action = 'confirm';
            }

        }
        else if ($action == 'confirm2') {
            // final confirmation caused an error, so redisplay confirmation screen
            // with the error message
            
            $model['error_message'] = '<p>' . $_POST['error_message'] . '</p>';
            
            $model['shipping_address'] = yak_get_address('shipping');
            $model['billing_address'] = yak_get_address('billing');
            
            $action = 'confirm';   
        }
        
        // if payment type is credit card, redirect to credit card input form
        if ($action == 'cc' || $action == 'jump-to-cc') {
            global $cards;

            $model['cc_types'] = array();
            foreach ($cards as $card) {
                $model['cc_types'][$card['name']] = $card['name'];            
            }
            
            $model['cc_expiry_months'] = array();
            for ($i = 1; $i <= 12; $i++) {
                $model['cc_expiry_months'][str_pad("$i", 2, "0", STR_PAD_LEFT)] = "$i";   
            }
            
            $model['cc_expiry_years'] = array();
            $year = 0 + date("Y");
            for ($i = $year; $i < $year + 20; $i++) {
                $model['cc_expiry_years']["$i"] = "$i";   
            }
            
            $action = 'cc';
        }
        
        if (!empty($_SESSION['promo_code'])) {
            $model['promo_code'] = $_SESSION['promo_code'];
        }
        
        ob_start();
        include 'yak-view-' . $action . '.php';
        $rtn = ob_get_contents();
        ob_end_clean();
    
        return $rtn;
    }
}


if (!function_exists('yak_checkout_error')) {
    /**
     * Handle an error in the checkout process.
     *
     * @param $model the array containing content
     * @param $prompt initial error message
     * @param $errors an array of error messages
     */    
    function yak_checkout_error(&$model, $prompt, $errors) {
        if (sizeof($errors) > 0) {
            $model['error_message'] = "<p>$prompt</p><ul>";
                
            foreach ($errors as $err) {
                $model['error_message'] = $model['error_message'] . "<li>$err</li>"; 
            }
                
            $model['error_message'] = $model['error_message'] . '</ul>';
            
            return true;
        }
        else {
            return false;
        }
    }
}


if (!function_exists('yak_check_order')) {
    /**
     * If all funds have been received for an order, and there is downloadable content,
     * send an email containing the link for the dl.
     *
     * @param $order_id the id of the order to check
     */
    function yak_check_order($order_id) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        $order_dl_table =& $registry->get('order_dl_table');
        $order_detail_table =& $registry->get('order_detail_table');
        $product_detail_table =& $registry->get('product_detail_table');
        
        $order = $wpdb->get_row("select o.order_num, o.payment_type, o.funds_received, o.shipping_cost, sum(od.price * od.quantity) as total_cost,
                                 o.address, o.country_code
                                 from $order_table o, $order_detail_table od 
                                 where o.id = $order_id 
                                 and o.id = od.id 
                                 group by o.id");
        
        $dl = $wpdb->get_row("select count(*) as total 
                              from $order_dl_table 
                              where order_id = $order_id 
                              and uid is not null");
        
        $order_num = $order->order_num;
        $rounding = yak_get_option(PRICE_ROUNDING, 2);
        $funds_received = round($order->funds_received, $rounding);
        $total_cost = round($order->total_cost + $order->shipping_cost, $rounding);

        if ($funds_received >= $total_cost) {
            require_once('payments/yak-payment-utils.php');
            $payment_type = yak_get_payment($order->payment_type);

            if ($payment_type != null) {
                $payment_type->finalise_order($order_id);
            }

            // 3rd party integration
            if (file_exists(YAK_ROOT_DIR . 'yak-third-party.php')) {
                require_once(YAK_ROOT_DIR . 'yak-third-party.php');
            
                if (function_exists('yak_check_order_3p')) {
                    $split = split("\n", $order->address);
                    $email = $split[0];
                    $recipient = $split[1];
                
                    yak_check_order_3p($order_id, $email, $recipient, $order->total_cost);
                }
            }
        
            if ($dl->total < 1) {
                $a1 = $order->funds_received;
                $a2 = $order->total_cost;
                $results = $wpdb->get_results("select * 
                                               from $order_dl_table 
                                               where order_id = $order_id"); 
            
                $dl_uri = yak_get_option(DOWNLOAD_URI, get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/yak-dl.php');
                $msg = yak_get_option(DOWNLOAD_EMAIL, '');
            
                if ($msg == '') {
                    yak_log("WARNING: No message set for the download email.  Unable to send");
                    return;
                }
                    
                $uris = '';
                if ($results) {
                    foreach ($results as $result) {
                        $id = $result->id;
                        $uid = md5(uniqid(rand(), true));
                    
                        $wpdb->query("update $order_dl_table set uid = '$uid' 
                                      where id = $id");
                    
                        $uris = $uris . "$dl_uri?uid=$uid\n"; 
                    }
                
                    // send email with download links
                    if ($uris != '') {
                        $fromEmail = yak_get_option(DOWNLOAD_EMAIL_ADDRESS, '');
                    
                        $split = split("\n", $order->address);
                        $email = $split[0];
                    
                        if (yak_str_contains($msg, '<html')) {
                            $uris = str_replace("\n", "<br />", $uris);
                        }

                        $mail = str_replace('[downloads]', $uris, $msg);
                        yak_sendmail($fromEmail, $email, __('Your purchased downloads', 'yak'), $mail); 
                    
                        $mail = __('The following email has been sent to', 'yak') . ' ' . $email . " :\r\n" . $mail;
                        yak_sendmail($fromEmail, $fromEmail, __('Purchased downloads', 'yak'), $mail); 
                    
                        yak_insert_orderlog($order_id, "Sent download email for order $order_num to email address: $email");
                        yak_log("Sent download email for order $order_num");
                    }
                }
            }
            
            // how many items in this order are not downloadable (i.e. physical product)
            $row = $wpdb->get_row("select count(*) as non_dl_count 
                                   from $order_detail_table od, $product_detail_table pd 
                                   where od.id = $order_id 
                                   and od.post_id = pd.post_id 
                                   and od.cat_id = pd.cat_id 
                                   and (pd.dl_file is null or pd.dl_file = '')");

            if ($row->non_dl_count < 1) {
                $wpdb->query("update $order_table set status = '" . STOCK_SENT . "'
                              where id = $order_id");
            }
            
        }
    }
}


if (!function_exists('yak_cleanup_after_order')) {
    /**
     * Remove any order data from the session.
     */
    function yak_cleanup_after_order() {
        unset($_SESSION[ITEMS_NAME]);
        unset($_SESSION['cc']);
        unset($_SESSION['accrecv']);
        unset($_SESSION['promo_code']);
        unset($_SESSION['current_order_items']);
        unset($_SESSION['current_order_value']);
    }
}


if (!function_exists('yak_editproduct')) {
    /**
     * Display the product edit tab when editing a post/page.
     */
    function yak_editproduct() {
        include 'yak-view-edit-product.php';
    }
}


if (!function_exists('yak_format_money')) {
    /**
     * Return a monetary value properly formatted using the current currency settings.
     *
     * @param $money the money value
     * @param $include_symbol include the symbol in the formatted value
     */
    function yak_format_money($money, $include_symbol = false) {        
        $sym = yak_get_option(CURRENCY_SYMBOL, '$');
        $cformat = yak_get_option(CURRENCY_FORMAT, '%2$s%1$s');
        $dec_point = yak_get_option(DECIMAL_POINT, '.');
        $thousands_sep = yak_get_option(THOUSANDS_SEPARATOR, ',');
        $dec_places = yak_get_option(MONEY_FORMAT, '0');
        $money = number_format($money, $dec_places, $dec_point, $thousands_sep);
        if ($include_symbol) {
            return sprintf($cformat, $money, $sym);
        }
        else {
            return $money;
        }
    }
}


/**
 * Return a YAK option by its name.
 *
 * @param $name the name of the parameter to return
 * @param $default the default value to return if no parameter is found
 */
function yak_get_option($name, $default='') {
    $value = get_option($name);
    
    return yak_default($value, $default);
}


if (!function_exists('yak_get_payment_options')) {
    /**
     *
     */
    function yak_get_payment_options($registry = null) {
        require_once(YAK_ROOT_DIR . 'payments/yak-payment-utils.php');
        array_walk(yak_glob(YAK_ROOT_DIR . 'payments/*.class.php'), create_function('$v,$i', 'return require_once($v);'));
        
        if ($registry == null) {
            $registry =& Registry::getInstance();
        }
        
        return $registry->get('payment_options');
    }
}


if (!function_exists('yak_order_id')) {
    /**
     * Get the id from the GET or POST request data
     */
    function yak_order_id() {
		// special case on PayPal return.  Lookup the order number based on the order id
		// we sent to PayPal
		if (isset($_GET['cm'])) {
			$order_id = yak_get_order_num($_GET['cm']);
		}
		else {
			// otherwise, default processing to display the order id in the GET or POST request.
        	$order_id = $_GET['order_id'];
        	if (empty($order_id)) {
            	$order_id = $_POST['order_id'];
        	}
        }
        return $order_id;
    }
}


if (!function_exists('yak_gen_order_num')) {
    function yak_gen_order_num($order_id) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        
        if (yak_get_option(ORDER_NUMBER_TYPE, GENERATED) == GENERATED) {
    		$yr = date('Y') - 1970;
    		$dy = (date('m') * 31) + date('d');
    		$r1 = str_pad(rand(0,99999), 5, '0');
    		$r2 = str_pad(rand(0,99999), 5, '0');
    		$num = $yr . str_pad($dy, 3, '0') . '-' . $r1 . '-' . $r2;

            $row = $wpdb->get_row("select count(*) as total from $order_table where order_num = '$num'");
            if ($row->total > 0) {
                return yak_gen_order_num();   
            }
            else {
                return $num;   
            }
        }
        else {
            return $order_id;
        }
    }
}


if (!function_exists('yak_get_order_num')) {
    function yak_get_order_num($order_id) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        
        $row = $wpdb->get_row("select order_num from $order_table where id = $order_id");
        
        return $row->order_num;
    }
}


if (!function_exists('yak_order_value')) {
    /**
     * Return or output the value of an order in the session.
     *
     * @param $echo echo the link to the page or return it
     */
    function yak_order_value($echo = true, $order_id=null) {
        global $wpdb;
        
        if ($order_id == null) {
            $rtn = $_SESSION['order_value'];
        }
        else {
            $registry =& Registry::getInstance();
            $order_table =& $registry->get('order_table');
            $order_detail_table =& $registry->get('order_detail_table');

            $row = $wpdb->get_row("select shipping_cost + sum(od.price * od.quantity) as total
                                   from $order_table o, $order_detail_table od
                                   where o.id = $order_id and od.id = o.id");
            $rtn = $row->total;
        }
        
        if ($echo == true) {
            echo $rtn;   
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_get_referrer')) {
    function yak_get_referrer() {
        $check_referrer = $_POST['check_referrer'];
        if (isset($check_referrer) && $check_referrer == 'true' && isset($_SERVER['HTTP_REFERER'])) {
            $referrer = $_SERVER['HTTP_REFERER'];
            $response = yak_do_http($referrer, '', '', null, 'GET');
            $title = yak_get_tag_value($response, '<title>', '</title>');
            return '<a href="' . $referrer . '">' . __('Return to ', 'yak') . $title . '</a>';
        }
        else {
            return null;
        }
    }
}


if (!function_exists('yak_get_quantity')) {
    /**
     * Return the quantity available for a particular product.
     *
     * @param $post_id the post to lookup
     * @param $type the type of post (default to the value 'default')
     */
    function yak_get_quantity($post_id, $type) {
        global $wpdb;
        
        if (empty($type)) {
            $type = 'default';
        }
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');
        
        $qty = $wpdb->get_var("select quantity from $product_detail_table pd 
                               where pd.post_id = $post_id 
                               and exists (select 1 from $wpdb->terms t 
                                           where t.term_id = pd.cat_id and t.name = '$type')");
        
        if (isset($qty)) {
            return 0 + $qty;
        }
        else {
            return 0;
        }
    }
}


if (!function_exists('yak_get_sku')) {
    function yak_get_sku($post_id, $cat_id, $sku) {
        if (!empty($sku)) {
            return $sku;
        }
        else {
            return str_pad($post_id, 8, '0', STR_PAD_LEFT) . str_pad($cat_id, 4, '0', STR_PAD_LEFT);
        }
    }
}


if (!function_exists('yak_get_orders')) {
    function yak_get_orders($status = '', $order_num = null, $year = null, $month = null, $include_log = true, $include_meta = true) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        $order_log_table =& $registry->get('order_log_table');
        $order_meta_table =& $registry->get('order_meta_table');
        $order_detail_table =& $registry->get('order_detail_table');
        $product_detail_table =& $registry->get('product_detail_table');
        
        $sql = "select o.id, o.order_num, o.time, o.address, o.country_code, o.billing_address, o.billing_country_code,
                      o.payment_type, o.funds_received, o.shipping_cost, sum(od.price * od.quantity) as total, o.status
                from $order_table o, $order_detail_table od
                where o.id = od.id ";
                
        if ($status == '') {
            $sql .= "and (status is null or status = '')";
        }
        else {
            $sql .= "and status = '" . $status . "'";
        }
                
        if (!empty($year)) {
            $sql .= "and year(o.time) = $year ";
        }
        
        if (!empty($month) && $month != '00') {
            $sql .= "and month(o.time) = $month ";
        }
        
        if (!empty($order_num)) {
            $sql .= "and o.order_num = '$order_num' ";
        }
        
        $sql .= "group by o.id
                 order by o.id desc";
        
        // query for orders and order detail (summary data)
        $results = $wpdb->get_results($sql);
        
        // loop through the results and build more detail
        $orders = array();
        if ($results) {
            foreach ($results as $result) {                
                $order = new YakOrder($result->id, $result->order_num, $result->time, $result->address, $result->country_code, 
                                      $result->billing_address, $result->billing_country_code, $result->payment_type, 
                                      $result->funds_received, $result->shipping_cost, $result->total, $result->status);
                
                $order->items = $wpdb->get_results("select od.itemname, od.price, od.quantity, (od.price * od.quantity) as total,
                                                            od.post_id, od.cat_id, pd.sku
                                                    from $order_detail_table od 
                                                    left outer join $product_detail_table pd 
                                                            on od.post_id = pd.post_id 
                                                            and od.cat_id = pd.cat_id
                                                    where id = $result->id");
                
                if ($include_log) {
                    $order->log = $wpdb->get_results("select time, message 
                                                      from $order_log_table
                                                      where order_id = " . $result->id);
                }
  
                if ($include_meta) {
                    $order->meta = $wpdb->get_results("select name, value 
                                                       from $order_meta_table
                                                       where order_id = " . $result->id . " order by id");
                }
                
                $orders[] = $order;
            }
        }
        
        return $orders;
    }
}


if (!function_exists('yak_get_post_param')) {
    /**
     * Get the name of the post parameter depending upon whether we're displaying a post
     * or a page.
     */
    function yak_get_post_param() {
        global $wp_query;
        
        if (!$wp_query->is_page) {
            // if it's not a return 'p'
            return 'p';
        }
        else {
            // otherwise we're on a page
            return 'page_id';   
        }
    }
}


if (!function_exists('yak_get_product_categories')) {
    /**
     * Return an array of product categories for a post.
     *
     * @param $post_id the post to lookup
     * @param $post_type the type of the post (from post->post_type)
     * @param $include_zero include categories with no available quantity (defaults to true)
     */
    function yak_get_product_categories($post_id, $post_type=null, $include_zero=true) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');

        if (!isset($post_type) || $post_type == null) {
            $row = $wpdb->get_row("select post_type 
                                   from $wpdb->posts p
                                   where p.ID = $post_id");
            $post_type = $row->post_type;
        }
        
        $rtn = array();

        $prod_cat_name = yak_get_option(PRODUCT_CATEGORY_NAME, 'products');
        
        if ($post_type != 'page') {
            $sql = "select t.term_id as cat_id, t.name as cat_name, t2.name as parent_name, p.sku, p.quantity, p.override_price, p.weight, p.dl_file
                    from $wpdb->term_relationships tr,
                    $wpdb->term_taxonomy tt,
                    $wpdb->terms t
                    left join $product_detail_table p on p.cat_id = t.term_id and p.post_id = $post_id,
                    $wpdb->terms t2
                    where tr.object_id = $post_id
                    and tr.term_taxonomy_id = tt.term_taxonomy_id
                    and tt.taxonomy = 'category'
                    and tt.term_id = t.term_id
                    and tt.parent = t2.term_id
                    and t2.slug = '$prod_cat_name'";
                
            if ($include_zero != true) {
                $sql .= ' and p.quantity > 0';
            }
            
            $results = $wpdb->get_results($sql);
        }
        else {
            $sql = "select p.cat_id, 'default' as cat_name, '' as parent_name, p.sku, p.quantity, p.override_price, p.weight, p.dl_file
                    from $product_detail_table p
                    where p.post_id = $post_id
                    and p.cat_id = -1";
            
            if ($include_zero != true) {
                $sql .= ' and p.quantity > 0';
            }
                    
            $results = $wpdb->get_results($sql); 

            if (sizeof($results) == 0 && $include_zero) {
                $results = $wpdb->get_results("select -1 as cat_id, 'default' as cat_name, '' as parent_name, 
                                               '' as sku, null as override_price, 0 as quantity, '' as weight, '' as dl_file");
            }
        }
        
        if (sizeof($results) > 0) {
            foreach ($results as $row) {
                if (!empty($row->parent_name) && strtolower($row->parent_name) != strtolower($prod_cat_name)) {
                    $name = $row->parent_name . ' ' . $row->cat_name;
                }
                else {
                    $name = $row->cat_name;
                }
                $rtn[] = new YakProductType($post_id, $row->cat_id, $name, $row->sku, $row->quantity, $row->override_price, $row->weight, $row->dl_file);
            }
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_load_product')) {
    /**
     * Create a Product object with the specified row data
     *
     * @param $row a table row containing product data
     */
    function yak_load_product($row) {
        $title = yak_fix_escaping($row->alt_title);
        $pp = new YakProduct($row->id, $row->post_title, $row->post_type, $title, $row->price);
        $pp->discount_override = $row->discount_override;
        $pp->multi_select_options = $row->multi_select_options;
        $pp->multi_select_min = $row->multi_select_min;
        $pp->multi_select_max = $row->multi_select_max;
        return $pp;
    }
}


if (!function_exists('yak_get_product')) {
    /**
     * Return a product by id, or by using the WP 'loop' post, or overridden with a global variable $yak_post
     *
     * @param $post_id the id of the post
     */
    function yak_get_product($post_id = null) {
        global $wpdb, $post;
        
        $registry =& Registry::getInstance();
        $product_table =& $registry->get('product_table');        
        
        if (empty($post_id)) {
            // yak_post can be used to override `the_loop` post
            $yak_post =& $registry->get('yak_post');
            
            if (isset($yak_post)) {
                $pp = $yak_post;
                $post_id = $pp->ID;
            }
            else {
                $pp = $post;
                $post_id = $pp->ID;
            }
        }
        
        $row = $wpdb->get_row("select p.ID as id, p.post_title, p.post_type, pt.alt_title, pt.price, p.post_content,
                                    pt.discount_override, pt.multi_select_options, pt.multi_select_min, pt.multi_select_max
                               from $wpdb->posts p left join $product_table pt on p.id = pt.post_id 
                               where p.id = $post_id");
        
        return yak_load_product($row);
    }
}


if (!function_exists('yak_get_products')) {
    /**
     * Return an array of products
     *
     * @param $order if 'title' order the array by title, otherwise order by post date
     * @param $offset the starting position for the query
     * @param $number the number of products (from the starting position) to return
     */
    function yak_get_products($order='title', $offset=0, $number=99999999) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_table =& $registry->get('product_table');
        
        $products = array();

        $sql = "select distinct p.ID as id, p.ID, p.post_title, p.post_type, pt.price, pt.alt_title, p.post_content,
                    pt.multi_select_options, pt.multi_select_max
                from $wpdb->posts p, $product_table pt
                where p.post_type in ('page', 'post')
                and p.post_status = 'publish'
                and p.id = pt.post_id";
        
        if ($order == 'title') {
            $sql .= " order by p.post_title asc ";
        }
        else {
            $sql .= " order by p.post_date desc ";
        }
        
        $sql .= " limit $offset, $number";
        
        $ar = $wpdb->get_results($sql);
        
        foreach ($ar as $post) {
            $title = yak_fix_escaping($post->alt_title);
            
            $product = yak_load_product($post);
            $product->content = $post;
            
            $products[] = $product;
        }
        
        return $products;
    }
}
    
 
if (!function_exists('yak_get_product_count')) {
    /**
     * Return a count of products.
     */
    function yak_get_product_count() {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_table =& $registry->get('product_table');

        $row = $wpdb->get_row("select count(distinct p.id) as total
                               from $wpdb->posts p, $product_table pt
                               where p.post_type in ('page', 'post')
                               and p.post_status = 'publish'
                               and p.id = pt.post_id");
        return $row->total;
    }
}

if (!function_exists('yak_get_product_type')) {
    /**
     *
     */
    function yak_get_product_type($post_id, $cat_id) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');
        
        $row = $wpdb->get_row("select pd.post_id, pd.cat_id, ifnull(t.name, 'default') as name, pd.sku, pd.quantity, pd.dl_file, pd.weight, pd.override_price
                               from $product_detail_table pd left outer join $wpdb->terms t 
                                    on t.term_id = pd.cat_id
                               where pd.post_id = $post_id 
                               and pd.cat_id = $cat_id");
        return new YakProductType($post_id, $row->cat_id, $row->name, $row->sku, $row->quantity, $row->override_price, $row->weight, $row->dl_file);
    }
}


if (!function_exists('yak_get_product_types')) {
    function yak_get_product_types($first_empty=true, $exclusions = null) {
        global $wpdb;

        $prod_cat_name = yak_get_option(PRODUCT_CATEGORY_NAME, 'products');
        
        $results = $wpdb->get_results("select t.term_id, t.name 
                                       from $wpdb->terms t, $wpdb->term_taxonomy tt 
                                       where t.term_id = tt.term_id 
                                       and tt.parent = (select t2.term_id 
                                                    from $wpdb->term_taxonomy tt2, $wpdb->terms t2 
                                                    where tt2.term_id = t2.term_id and t2.name = '$prod_cat_name')");
        $types = array();
        if ($first_empty) {
            $types[''] = '';
        }

        foreach ($results as $row) {
            if ($exclusions != null && yak_in_list($row->name, array_values($exclusions))) {
                continue;
            }
            $types["$row->term_id"] = $row->name;
        }
        return $types;
    }
}


if (!function_exists('yak_get_address')) {
    /**
     * Return the customer address from either the $_SESSION or the $_COOKIE.
     *
     * @param $type the type of address (shipping or billing)
     */
    function yak_get_address($type) {
        if (isset($_SESSION[$type . '_address'])) {
            $addr = $_SESSION[$type . '_address'];
        }
        else {
            $addr = stripslashes($_COOKIE[$type . '_address3']);
        }
        $uaddr = unserialize($addr);
        return $uaddr;
    }
}


if (!function_exists('yak_get_product_weight')) {
    /**
     * Return the weight of a product and type (category)
     *
     * @param $post_id the product post
     * @param $cat_id the category describing the type of the product (small, med, large, etc)
     */
    function yak_get_product_weight($post_id, $cat_id) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');
        
        $row = $wpdb->get_row("select weight from $product_detail_table where post_id = $post_id and cat_id = $cat_id"); 

        return $row->weight;        
    }
}


if (!function_exists('yak_get_title')) {
    /**
     * Return the title of a product.
     *
     * @param $post_id the product post
     * @param $cat_id the category describing the type of the product (small, med, large, etc)
     */    
    function yak_get_title($post_id, $cat_id) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_table =& $registry->get('product_table');
        $product_detail_table =& $registry->get('product_detail_table');
        
        $posts = $wpdb->posts;
        $terms = $wpdb->terms;
        
        $sql = "select p.post_title, pt.alt_title, t1.name as cat_name  
                from $posts p left join $product_table pt on p.ID = pt.post_id,
                $product_detail_table pd left join $terms t1 on pd.cat_id = t1.term_id
                where p.ID = $post_id
                and p.ID = pd.post_id 
                and pd.cat_id = $cat_id";
        
        $row = $wpdb->get_row($sql);
                
        if (!isset($row)) {
            return '[DELETED PRODUCT]';   
        }
        else if (isset($row->alt_title) && $row->alt_title != null) {
            $title = $row->alt_title;
        }
        else {
            $title = $row->post_title;   
        }
                   
        if (isset($row->cat_name) && $row->cat_name != 'default') {
            $title = $title . ' (' . $row->cat_name . ')';
        }

        return yak_fix_escaping($title);   
    }
}


if (!function_exists('yak_get_total_items')) {
    function yak_get_total_items($items) {
        $total = 0;
        foreach ($items as $key=>$item) {
            $total += $item->quantity;
        }
        return $total;
    }
}


if (!function_exists('yak_head_admin')) {
    /**
     * Javascript functions & stylesheet to be included in the Admin head
     */
    function yak_head_admin() {
        $yakurl = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/resources';
        echo <<<EOD
<link rel="stylesheet" type="text/css" href="$yakurl/ui.css" type="text/css" media="screen" />
<script type="text/javascript" src="$yakurl/ui.js"></script>
<script type="text/javascript" src="$yakurl/ui-admin.js"></script>
EOD;
    }
}


if (!function_exists('yak_head_wp')) {
    /**
     * Javascript functions & stylesheet to be included in the WP head
     */
    function yak_head_wp() {
        $yakurl = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/resources';
        echo <<<EOD
<link rel="stylesheet" href="$yakurl/ui.css" type="text/css" media="screen" />
<script type="text/javascript" src="$yakurl/ui.js"></script>
EOD;

        // Fix a problem with Paypal landing back at the root page of the blog, rather
        // than the proper page -- so cleanup the order if we find some common
        // paypal params in the POST
        if (!empty($_GET['custom']) && !empty($_GET['txn_id'])) {
            yak_paypal_ipn();
            yak_cleanup_after_order();
        }
        
        if (!empty($_GET['merchant_return_link'])) {
            yak_cleanup_after_order();
        }

    }
}


if (!function_exists('yak_init')) {
    /**
     * Initialisation functions (executed before the rest of the page is rendered)
     */
    function yak_init() {
        global $wpdb, $user_ID;
        
        // load up the table names
        $registry =& Registry::getInstance();
        $order_table =& $registry->get('order_table');
        $order_dl_table =& $registry->get('order_dl_table');
        $order_meta_table =& $registry->get('order_meta_table');
        $order_detail_table =& $registry->get('order_detail_table');
        $product_detail_table =& $registry->get('product_detail_table');
        
        if (session_id() == "") {
            @session_start();
        }
        
        // confirm2 is the second (final) confirmation screen
        if ($_POST['action'] == 'confirm2') {    
            $addr = yak_get_address('shipping');
            $baddr = yak_get_address('billing');
            
            $items = $_SESSION[ITEMS_NAME];
            $total_qty = 0;
            
            // if T&C's are enabled, check that the customer has agreed to them
            if (yak_get_option(TERMS_AND_CONDITIONS, '') != '' && $_POST['tandcConfirmation'] != 'on') {
                $_POST['action'] = 'confirm2';
                $_POST['error_message'] = yak_get_option(TERMS_AND_CONDITIONS, '');
                return;
            }
            
            // check if we've got enough stock for the purchases
            $not_enough_stock = false;
            $total_weight = 0;         
            foreach ($items as $i => $item) {
                $qty = $wpdb->get_var("select ifnull(quantity, 0)
                                       from $product_detail_table
                                       where post_id = " . $item->id . "
                                       and cat_id = " . $item->cat_id);
                if ($qty < $item->quantity) {
                    $item->quantity = $qty;
                    if ($item->quantity < 1) {
                        unset($items[$i]);   
                    }
                    $not_enough_stock = true;
                }
                $total_qty = $total_qty + $item->quantity;
                $total_weight += $item->get_total_weight();
            }
            $items = array_values($items);
            
            if ($not_enough_stock) {
                $_POST['action'] = 'confirm2';
                $_POST['error_message'] = __('We have a shortage of stock for one (or more) of your selections. The quantities in your basket have been altered accordingly.', 'yak');
                return;
            }
            else if ($total_qty < 1) {
                $_POST['action'] = 'confirm2';
                $_POST['error_message'] = __('Sorry, but you do not have any items in your order.', 'yak');
                return;
            }

            // now write the order to the database
            
            $cty = str_replace(' ', '_', $_POST['shipping_country']);
            $shipping_cost = yak_calc_shipping($total_weight, $total_qty, $cty);
            
            $shipping_address = yak_escape_string($addr->as_string('country'));
            $shipping_cc = $addr->country;
            $billing_address = yak_escape_string($baddr->as_string('country'));
            $billing_cc = $baddr->country;
            
            if (isset($user_ID)) {
                $user = $user_ID;
            }
            else {
                $user = 'null';
            } 
            
            $wpdb->query("insert into $order_table (time, user_id, address, country_code, shipping_cost, payment_type, status, billing_address, billing_country_code)
                          values (current_timestamp(), $user, '$shipping_address', '$shipping_cc', $shipping_cost, '" . 
                          $_SESSION['payment_type'] . "', '', '$billing_address', '$billing_cc')");
            $order_id = $wpdb->insert_id;
            
            // order number can either be a sequence or generated, so we need to
            // update after the initial insert
            $order_num = yak_gen_order_num($order_id);
            $wpdb->query("update $order_table set order_num = '$order_num' 
                          where id = $order_id");
            
            $order_value = 0;
            $total_discount = 0;

            // import the promo utils now
            require_once('yak-promo-utils.php');
            
            // get the promo, if a code is set
            if (isset($_SESSION['promo_code'])) {
                $code = $_SESSION['promo_code'];
                $promo = yak_get_promotion($code);
            }
            else {
                $promo = null;
            }
            
            $total_items = yak_get_total_items($items);
            
            // iterate through the items and add to the order detail table
            // plus decrement the quantity from the product detail table
            foreach ($items as $key => $item) {
                if ($item->quantity < 1) {
                    continue;   
                }
                $item_name = yak_escape_string(yak_get_title($item->id, $item->cat_id));
                $item->price = yak_calc_price($item->id, $item->cat_id);
                $item->discount = yak_calc_price_discount($item->price, $total_items, $promo);
                $total_discount += ($item->discount * $item->quantity);
                $order_value += $item->get_discount_total();
                
                $wpdb->query("insert into $order_detail_table (id, itemname, price, quantity, post_id, cat_id) 
                              values ($order_id, '$item_name', $item->price, " . $item->quantity . "," . $item->id . "," . $item->cat_id . ")");
                              
                $wpdb->query("update $product_detail_table
                              set quantity = quantity - " . $item->quantity . "
                              where post_id = " . $item->id . "
                              and cat_id = " . $item->cat_id);
                
                // add the selected options to order meta (don't really have a better place for them)              
                if (isset($item->selected_options)) {
                    $i = 1;
                    foreach ($item->selected_options as $msi) {
                        $wpdb->query("insert into $order_meta_table (order_id, name, value)
                                      values ($order_id, '$item_name item$i', '$msi')");
                        $i += 1;
                    }
                }
                
                // if this is a downloadable product, create an order_dl record
                $dl_file = $wpdb->get_var("select dl_file
                                from $product_detail_table
                                where post_id = " . $item->id . "
                                and cat_id = " . $item->cat_id);
  
                if (isset($dl_file) && $dl_file != '') {
                    $wpdb->query("insert into $order_dl_table (order_id, uid, dl_file, download_attempts) 
                                  values ($order_id, null, '$dl_file', 0)");
                }
                
                if (isset($item->special_option) && $item->special_option != '') {
                    $sopt = $item->special_option;
                    $wpdb->query("insert into $order_meta_table (order_id, name, value)
                                  values ($order_id, 'special option for $item_name', '$sopt')");
                }
            }
            
            // threshold promo calculations
            if ($promo == null) {
                $promo = yak_get_promotion_by_threshold($order_value);
                if ($promo != null) {
                    $price_discount = yak_calc_price_discount($order_value, $total_items, $promo);
                    if ($price_discount > 0) {
                        $order_value -= $price_discount;
                        $total_discount = $price_discount;
                    }
                    else {
                        $shipping_discount = yak_calc_shipping_discount($shipping_cost, $promo);
                        $order_value -= $shipping_discount;
                        $total_discount = $shipping_discount;
                    }

                    foreach ($items as $key => $item) {
                        if ($item->quantity < 1) {
                            continue;   
                        }
                        $item->discount = yak_calc_price_discount($item->price, $total_items, $promo);
                    }
                }
            }
            
            // add the promotion total discount to the order detail
            if ($promo != null) {
                $wpdb->query("insert into $order_detail_table (id, itemname, price, quantity) 
                              values ($order_id, 'promo " . $promo->code . " discount', -$total_discount, 1)");
            }
            
            if (isset($_POST['special_instructions']) && !empty($_POST['special_instructions'])) {
                $note = $_POST['special_instructions'];
                $default_instructions = stripslashes(yak_get_option(DEFAULT_SPECIAL_INSTRUCTIONS,''));
                if ($note != $default_instructions) {
                    $wpdb->query("insert into $order_meta_table (order_id, name, value)
                                  values ($order_id, 'Special Instructions', '$note')");
                }
            }
            
            // finally add the shipping cost onto the order value
            $order_value += $shipping_cost;
            
            // find the payment option
            $payment_types = yak_get_option(PAYMENT_TYPES, null);
            $ptype = $_SESSION['payment_type'];
            $ptypeval = $payment_types[$ptype];
            
            $payment_options =& yak_get_payment_options();
            $payment_option = $payment_options[$ptypeval];
            
            // do any payment-specific order confirmation
            $payment_option->confirm_order($order_id, $items);
            
            // call the payment option to find where we need to redirect to complete
            $url = $payment_option->redirect($_SESSION['payment_type'], $order_id, $items, $shipping_cost);
            
            $_SESSION['order_value'] = yak_format_money($order_value, true);
            
            // redirect to final page (perhaps external, such as PayPal)
            header("Location: $url");
            
            // drop out
            exit;
        }
        else if ($_POST['action'] == 'confirm' && count(yak_validate_address('shipping')) == 0) {
            yak_process_address('shipping', 'shipping');
            
            if (isset($_POST['shipping_is_billing']) && $_POST['shipping_is_billing'] == 'on') {
                yak_process_address('shipping', 'billing');
            }
            else {
                yak_process_address('billing', 'billing');   
            }
        }
        else if (isset($_POST['buynow'])) {
            // the buy button has been hit
            $items = NULL;
            if (isset($_SESSION[ITEMS_NAME])) {
                $items = $_SESSION[ITEMS_NAME];
            }
            else {
                $items = array();
                $_SESSION[ITEMS_NAME] = $items;
            }
            
            $p = $_POST['buynow'];
            $param_name = $_POST['buynow_param'];
            $cat_id = $_POST['category'];
            $special_option = $_POST['special_option'];
            
            $key = $p . '_' . $cat_id;
            
            $pp = yak_get_product($p);
            $multi_select_count = count($_POST['multiselect']);
            
            if (!empty($pp->multi_select_options) && $multi_select_count == 0) {
                $error_message = '<span class="yak_buyerror">' . __('You haven\'t selected any items', 'yak') . '</span>';
            }
            else if (!empty($pp->multi_select_options) && $multi_select_count < $pp->multi_select_min) {
                $msg = __('You can select a minimum of %1 items', 'yak');
                $error_message = '<span class="yak_buyerror">' . str_replace('%1', $pp->multi_select_min, $msg) . '</span>';
            }
            else if (!empty($pp->multi_select_options) && $multi_select_count > $pp->multi_select_max) {
                $msg = __('You can select a maximum of %1 items', 'yak');
                $error_message = '<span class="yak_buyerror">' . str_replace('%1', $pp->multi_select_max, $msg) . '</span>';
            }
            else if (!isset($items[$key]) || empty($items[$key])) {
                $items[$key] = new YakItem($param_name, $p, $cat_id, 1);
                $items[$key]->name = yak_get_title($p, $cat_id);
                $items[$key]->weight = yak_get_product_weight($p, $cat_id);
                $items[$key]->special_option = $special_option;
                
                if (!empty($pp->multi_select_options) && isset($_POST['multiselect'])) {
                    $items[$key]->selected_options = $_POST['multiselect'];
                }
                
                $_SESSION[ITEMS_NAME] = $items;  // probably not needed, but I had some weird problems at one point

                $price = yak_calc_price($p, $cat_id);
                if (!isset($_SESSION['current_order_value'])) {
                    $_SESSION['current_order_value'] = $price;
                    $_SESSION['current_order_items'] = 1;
                }
                else {
                    $_SESSION['current_order_value'] = $_SESSION['current_order_value'] + $price;
                    $_SESSION['current_order_items'] += 1;
                }

                $error_message = '<span class="yak_buyerror">' . __('This item has been added to your shopping cart', 'yak') . '</span>';
            }
            else {
                $error_message = '<span class="yak_buyerror">' . __('This item is already in your shopping cart', 'yak') . '</span>';
            }
            
            $referrer = yak_get_referrer();
            if ($referrer != null) {
                $error_message .= '<br />' . $referrer;
            }
            $GLOBALS['buynow_error_message_' . $p] = $error_message;
        }
    }
}


if (!function_exists('yak_insert_orderlog')) {
    /**
     * Insert into the yak order log table.
     *
     * @param $order_id the reference id of the order
     * @param $msg the message to insert
     */
    function yak_insert_orderlog($order_id, $msg) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $order_log_table =& $registry->get('order_log_table');
        
        if (!isset($order_id)) {
            $order_id = 'null';   
        }
        
        $msg = yak_escape_string($msg);
        $wpdb->query("insert into $order_log_table values (current_timestamp(), '$msg', $order_id)");
    }
}


if (!function_exists('yak_install')) {
    /**
     * Installation routine to set up tables
     */
    function yak_install() {
        require_once('yak-install.php');        
    }
}


if (!function_exists('yak_process_address')) {
    /**
     * Retrieve an address from the _POST, and store in both COOKIE and SESSION.
     *
     * @param $type the type of address (shipping or billing)
     * @param $name the name to use in both cookie and session
     */
    function yak_process_address($type, $name) {
        global $countries;
        
        $address = new YakAddress($_POST[$type . '_email'],
                                  $_POST[$type . '_recipient'],
                                  $_POST[$type . '_phone'],
                                  $_POST[$type . '_addr1'],
                                  $_POST[$type . '_addr2'],
                                  $_POST[$type . '_suburb'],
                                  $_POST[$type . '_city'],
                                  $_POST[$type . '_region'],
                                  $_POST[$type . '_state'],
                                  $_POST[$type . '_postcode'],
                                  $_POST[$type . '_country']);
                                  
        if ($address->country == 'US' || $address->country == 'CA') {
            $address->region = null;
        }
        else {
            $address->state = null;
        }
                                  
        $saddr = serialize($address);
        setcookie($name . '_address3', $saddr, time() + yak_get_option(COOKIE_LIFETIME, 2592000));
        $_SESSION[$name . '_address'] = $saddr;
    }
}

if (!function_exists('yak_post_processing')) {
    /**
     * Main processing for content to be used in posts.
     * 
     * @param $the_content the WP content to parse
     */
    function yak_post_processing($the_content) {
        global $countries;
        
        $registry =& Registry::getInstance();
        
        $pp = yak_get_product();
        
        //
        // cleanup after successful order
        //        
        if (yak_str_contains($the_content, '[yak_cleanup]')) {
            yak_cleanup_after_order();
            $the_content = str_replace('[yak_cleanup]', '', $the_content);
        }
        
        //
        // embed the product price, with no discount calculation applied
        //
        if (yak_str_contains($the_content, '[yak_std_price')) {
            $pos = 0;
            
            while (true) {
                $yp = yak_get_tag_params($the_content, 'yak_std_price', $pos, array(null, $pp->ID));
                
                if ($yp == null) {
                    break;
                }

                $type = $yp->params[0];                
                $id = $yp->params[1];
                
                // replace tag with actual price
                $the_content = substr($the_content, 0, $yp->pos1) .
                               '<span class="yak_price">' . yak_price($id, $type, false, false) . '</span>' .
                               substr($the_content, $yp->pos2 + 1);
            }
        }
        
        //
        // embed the product price, with discount if applicable
        //
        if (yak_str_contains($the_content, '[yak_price')) {
            $pos = 0;
            
            while (true) {
                $yp = yak_get_tag_params($the_content, 'yak_price', $pos, array(null, $pp->ID));
                
                if ($yp == null) {
                    break;
                }
                
                $type = $yp->params[0];                
                $id = $yp->params[1];
                
                // replace tag with actual price
                $the_content = substr($the_content, 0, $yp->pos1) .
                               '<span class="yak_price">' . yak_price($id, $type, true, false) . '</span>' .
                               substr($the_content, $yp->pos2 + 1);
            }
        }        

        //
        // embed the quantity of a product
        // the tag can be [yak_quantity] or [yak_quantity_<type>] (where <type> is a product category)
        //
        if (yak_str_contains($the_content, '[yak_quantity')) {
            $pos = 0;
            
            while (true) {
                $yp = yak_get_tag_params($the_content, 'yak_quantity', $pos, array(null, $pp->ID));
                
                if ($yp == null) {
                    break;
                }
                
                $type = $yp->params[0];                
                $id = $yp->params[1];

                // replace tag with actual quantity
                $the_content = substr($the_content, 0, $yp->pos1) .
                               yak_get_quantity($id, $type) .
                               substr($the_content, $yp->pos2 + 1);
            }
        }

        
        //
        // display the checkout pages
        //
        if (yak_str_contains($the_content, '[yak_checkout]')) {
            $the_content = str_replace('[yak_checkout]', yak_checkout(), $the_content);   
        }
        
        //
        // order id
        //
        if (yak_str_contains($the_content, '[yak_order_id]')) {
            $the_content = str_replace('[yak_order_id]', yak_order_id(), $the_content);   
        }
        
        //
        // order value
        //
        if (yak_str_contains($the_content, '[yak_order_value]')) {
            $the_content = str_replace('[yak_order_value]', yak_order_value(false), $the_content);
        }

        //
        // display the buy button
        //
        if (yak_str_contains($the_content, '[yak_buy')) {
            $pos = 0;
            
            while (true) {
                $yp = yak_get_tag_params($the_content, 'yak_buy', $pos, array($pp->ID));
                
                if ($yp == null) {
                    break;
                }
                
                $id = $yp->params[0];
                
                if ($id != $pp->ID) {
                    $registry->set('yak_post', yak_get_product($id));
                }

                // replace tag with actual quantity
                $the_content = substr($the_content, 0, $yp->pos1) .
                               yak_buy(false) .
                               substr($the_content, $yp->pos2 + 1);
            }
        }
        
        //
        // display the beginning of the buy button code (form begin)
        //
        if (yak_str_contains($the_content, '[yak_sbuy_begin]')) {
            $the_content = str_replace('[yak_sbuy_begin]', yak_buy_begin(false), $the_content);   
        }
        
        //
        // display the buy button content
        //
        if (yak_str_contains($the_content, '[yak_sbuy_content]')) {
            $the_content = str_replace('[yak_sbuy_content]', yak_buy_content(false), $the_content);
        }
        
        //
        // display the end of the buy button (close the form)
        //
        if (yak_str_contains($the_content, '[yak_sbuy_end]')) {
            $the_content = str_replace('[yak_sbuy_end]', yak_buy_end(false), $the_content);
        }

        //
        // display the product page
        //
        if (!$product_page && yak_str_contains($the_content, '[yak_product_page]')) {
            $the_content = yak_view_product_page($the_content);
        }
        
        if (yak_str_contains($the_content, '[yak_get_remote_')) {
            $remote_server = yak_get_option(REMOTE_GRAB_SERVER);
            $remote_path = yak_get_option(REMOTE_GRAB_PATH);
            
            while (true) {
                // find the start of the tag
                $pos = strpos($the_content, '[yak_get_remote_', $pos);
        
                if ($pos === false) {
                    break;
                }
                
                // find the end of the tag
                $pos2 = strpos($the_content, ']', $pos);

                // default if there is no type in the tag           
                if ($pos2 <= $pos + 16) {
                    $remote_content = "REMOTE CONTENT NOT FOUND";
                }
                else if (empty($remote_server)) {
                    $remote_content = "REMOTE SERVER NOT SET";
                }
                else {
                    // 16 chars is "[yak_get_remote_"
                    $post_id = substr($the_content, $pos + 16, $pos2 - ($pos + 16));
                    $response = yak_do_http($remote_server, $remote_path, 'p='. $post_id . '&feed=yak-products', null, 'GET');
                    
                    $start_tag = '<content><![CDATA[';
                    $end_tag = ']]></content>';
                    $rpos = strpos($response, $start_tag);
                    $rpos2 = strpos($response, $end_tag, $rpos);
                    
                    $remote_content = substr($response, $rpos + strlen($start_tag), $rpos2 - ($rpos + strlen($start_tag)));
                }
                
                // replace tag with actual content
                $the_content = substr($the_content, 0, $pos) .
                               $remote_content .
                               substr($the_content, $pos2 + 1);
            }
        }
        
        //
        // Display an error message from remote processing (such as Authorize.net)
        //
        if (yak_str_contains($the_content, '[error_message]')) {
            $the_content = str_replace('[error_message]', $_SESSION['error_message'], $the_content);
        }
        
        //
        // Include the current customer name
        //
        if (yak_str_contains($the_content, '[yak_customer_name]')) {
            $addr = yak_get_address('shipping');
            
            $the_content = str_replace('[yak_customer_name]', $addr->recipient, $the_content);
        }
        
        //
        // Include the current customer shipping address
        //
        if (yak_str_contains($the_content, '[yak_customer_address]')) {
            $addr = yak_get_address('shipping');
            
            if (isset($addr) && !empty($addr)) {
                $saddr = $addr->as_string('recipient', 'country', 'email', 'phone');
                $saddr = str_replace("\n", "\n<br />", $saddr . $countries[$addr->country]);
            
                $the_content = str_replace('[yak_customer_address]', $saddr, $the_content);
            }
        }
        
        //
        // Include the current customer phone number
        //
        if (yak_str_contains($the_content, '[yak_customer_phone]')) {
            $addr = yak_get_address('shipping');
            
            $the_content = str_replace('[yak_customer_phone]', $addr->phone, $the_content);
        }
        
        //
        // Button to jump back to address input in the case of an error
        //
        if (yak_str_contains($the_content, '[yak_back_to_address]')) {
            $checkout_param = $_SESSION['checkout_param'];
            $checkout_param_val = $_SESSION['checkout_param_val'];
            
            $back = yak_buy_begin(false) 
                  . '<button id="back_to_address" class="yak_large_button" type="submit">Back to address</button>'
                  . '<input type="hidden" name="action" value="jump-to-address" />'
                  . '<input type="hidden" name="' . $checkout_param . '" value="' . $checkout_param_val . '" />'
                  . yak_buy_end(false);
                 
            $the_content = str_replace('[yak_back_to_address]', $back, $the_content);
        }
        
        //
        // Button to jump back to credit card input in the case of an error
        //
        if (yak_str_contains($the_content, '[yak_back_to_cc]')) {
            $checkout_param = $_SESSION['checkout_param'];
            $checkout_param_val = $_SESSION['checkout_param_val'];
            
            $back = yak_buy_begin(false) 
                  . '<button id="back_to_address" class="yak_large_button" type="submit">Back to credit card</button>'
                  . '<input type="hidden" name="action" value="jump-to-cc" />'
                  . '<input type="hidden" name="' . $checkout_param . '" value="' . $checkout_param_val . '" />'
                  . yak_buy_end(false);
                 
            $the_content = str_replace('[yak_back_to_cc]', $back, $the_content);
        }
        
        if (yak_str_contains($the_content, '[yak_google_analytics]')) {
            require_once('yak-google-analytics.php');
            $google_analytics = new YakGoogleAnalytics();
            $the_content = $google_analytics->process($the_content);
        }
        
        $payment_types = yak_get_option(PAYMENT_TYPES, array());
        $payment_options =& yak_get_payment_options();
        foreach ($payment_types as $key=>$val) {
            if (array_key_exists($val, $payment_options)) {
                $the_content = $payment_options[$val]->post_processing($the_content);
            }
        }
        
        return $the_content;
    }
}


if (!function_exists('yak_price')) {
    /**
     * Return or output the price of the current product.
     *
     * @param $discount whether or not to discount the price (defaults to true)
     * @param $echo output this price
     * @param $type the type of product (for products with multiple types)
     */
    function yak_price($post_id, $type, $discount = true, $echo = true, $format = true) {
        if ($type == 'page') {
            $cat_id = -1;
        }        
        else if ($type != null) {
            $cat_id = get_cat_ID($type);
        }
        else {
            $cat_id = null;
        }
        
        if ($discount) {
            $price = yak_calc_price($post_id, $cat_id);
        }
        else {
            $prod = yak_get_product($post_id);
            $price = $prod->price;

            if ($cat_id != null) {
                $prod_type = yak_get_product_type($post_id, $cat_id);

                if (isset($prod_type->override_price)) {
                    $price = $prod_type->override_price;
                }
            }
        }
        
        if ($format) {
            $rtn = yak_format_money($price, true);
        }
        else {
            $rtn = $price;
        }
        
        if ($echo) {
            echo $rtn;
        }
        
        return $rtn;
    }
}


if (!function_exists('yak_set_product_detail')) {
    /**
     * Insert or update product details
     *
     * @param $post_id the post to set product data for
     * @param $cat_id the category to set product data for
     * @param $qty the quantity of the product available
     * @param $price_override the override price for the product type
     * @param $dlfile the download file, if this is a downloadable product
     * @param $weight the weight of the product
     */
    function yak_set_product_detail($post_id, $cat_id, $sku, $qty, $override_price, $dlfile, $weight) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');
        
        $row = $wpdb->get_row("select * 
                               from $product_detail_table
                               where post_id = $post_id and cat_id = $cat_id");
        
        if (!isset($override_price) || $override_price == '') {
            $override_price_fixed = 'null';
        }
        else {
            $override_price_fixed = $override_price;
        }
        
        if (empty($weight) || $weight == 0) {
            $weight_fixed = 'null';
            $weight = null;
        }
        else {
            $weight_fixed = $weight;
        }
        
        if (empty($sku)) {
            $sku = '';
        }
        
        if (empty($qty)) {
            $qty = 0;
        }
        
        if (!isset($row)) {
            $sql = "insert into $product_detail_table (post_id, cat_id, sku, quantity, override_price, weight, dl_file)
                    values ($post_id, $cat_id, '$sku', $qty, $override_price_fixed, $weight_fixed, '$dlfile')";
            $wpdb->query($sql);
            yak_log("Adding product type ($sql)");
        }
        else if ($row->quantity != $qty || $row->override_price != $override_price || $row->dl_file != $dlfile
                || $row->weight != $weight || $row->sku != $sku) {
            $sql = "update $product_detail_table 
                   set quantity = $qty,
                   override_price = $override_price_fixed, 
                   dl_file = '$dlfile',
                   weight = $weight_fixed,
                   sku = '$sku'
                   where post_id = $post_id and cat_id = $cat_id";
            $wpdb->query($sql);
            yak_log("Updating product type ($sql)");
        }
    }
}


if (!function_exists('yak_updproduct')) {
    /**
     * Called when a product or post is saved to set the price and title.
     *
     * @param $post_id the post or page id
     */
    function yak_updproduct($post_id) {
        if (!isset($_POST['yak_action'])) {
            return;   
        }

        // updproduct can be called twice, once from publish_post event and also from
        // edit_post. This could be changed so that only edit_post calls this event (I think),
        // so should come back and re-visit this code.
        if (isset($_POST['yak_updproduct_' . $post_id])) {
            return;
        }
        else {
            $_POST['yak_updproduct_' . $post_id] = $post_id;
        }
         
        $price = $_POST['yak_price'];
        $alt_title = $_POST['yak_title'];
        $discount_override = $_POST['yak_discount_override'];
        $multi_select = $_POST['yak_multi_select'];
        $multi_select_min = $_POST['yak_multi_select_min'];
        $multi_select_max = $_POST['yak_multi_select_max'];
        
        yak_update_product($post_id, $price, $alt_title, $discount_override, $multi_select, $multi_select_min, $multi_select_max);
        
        $product = yak_get_product($post_id);
        $types = yak_get_product_categories($product->id, $product->status);
        
        yak_update_product_types($product->id, $types);
    }
}


if (!function_exists('yak_update_product')) {
    /**
     * Insert, update, or delete product details (price and alternate title)
     *
     * @param $post_id the id of the post/page
     * @param $price the price of the product
     * @param $alt_title the alternate title
     */
    function yak_update_product($post_id, $price, $alt_title, $discount_override, $multi_select_options, $multi_select_min, $multi_select_max) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_table =& $registry->get('product_table');
 
        $row = $wpdb->get_row("select price, alt_title, discount_override, multi_select_options, multi_select_min, multi_select_max 
                               from $product_table
                               where post_id = $post_id");

        $defprice = yak_default($price, '0');
        $alt_title = yak_sql_escape($alt_title);
        $discount_override_fix = yak_default($discount_override, 'null');
        $multi_select_min_fix = yak_default($multi_select_min, 'null');
        $multi_select_max_fix = yak_default($multi_select_max, 'null');
        
        if ((!empty($price) || !empty($alt_title)) && (!isset($row) || $row == null)) {
            $sql = "insert into $product_table (post_id, price, alt_title, discount_override, multi_select_options, multi_select_min, multi_select_max)
                          values ($post_id, $defprice, '$alt_title', $discount_override_fix, '$multi_select_options', 
                          $multi_select_min_fix, $multi_select_max_fix)";
            $wpdb->query($sql);
            yak_log("Added product ($sql)");
        }
        else if ($row->price != $price || $row->alt_title != $alt_title || $row->discount_override != $discount_override 
                || $row->multi_select_options != $multi_select_options || $row->multi_select_min != $multi_select_min
                || $row->multi_select_max != $multi_select_max) {
            $sql = "update $product_table
                    set price = $defprice,
                    alt_title = '$alt_title',
                    discount_override = $discount_override_fix,
                    multi_select_options = '$multi_select_options',
                    multi_select_min = $multi_select_min_fix,
                    multi_select_max = $multi_select_max_fix
                    where post_id = $post_id";
            $rows = $wpdb->query($sql);
            yak_log("Updated product ($sql)");
        }
    }
}


if (!function_exists('yak_update_product_types')) {
    function yak_update_product_types($product_id, $types) {
        global $wpdb;
        
        $registry =& Registry::getInstance();
        $product_detail_table =& $registry->get('product_detail_table');
        
        $return_types = array();
        foreach ($types as $type) {
            if ($type->name == 'default' && isset($_POST['qty__-1'])) {
                $name_suffix = '_-1';
            }
            else {
                $name_suffix = $product_id . '_' . $type->cat_id;
            }
            $sku = $_POST['sku_' . $name_suffix];
            $qty = $_POST['qty_' . $name_suffix];
            $override_price = $_POST['price_' . $name_suffix];
            $oldqty = $_POST['oldqty_' . $name_suffix];
            $dlfile = $_POST['dl_file_' . $name_suffix];
            $weight = $_POST['weight_' . $name_suffix];
            $delete = $_POST['delete_' . $name_suffix];
            
            // if the delete flag is set, remove row and continue
            if (!empty($delete) && $delete == 'true') {
                $wpdb->query("delete from $product_detail_table
                              where post_id = $product_id
                              and cat_id = $type->cat_id");
                $wpdb->query("delete from $wpdb->term_relationships
                              where object_id = $product_id 
                              and term_taxonomy_id = $type->cat_id");
                continue;
            }
            
            // set default weight
            if (!isset($weight) || $weight == '') {
                $weight = 0;
            }
        
            // calc quantity -- need to take into account the current quantity in the db (in case
            // someone has ordered in the meantime)
            $row = $wpdb->get_row("select quantity from $product_detail_table 
                                   where post_id = $product_id 
                                   and cat_id = $type->cat_id");
                                  
            $diff = $oldqty - $row->quantity;
            
            $qty = $qty - $diff;
            if ($qty < 0) {
                $qty = 0;   
            }
            
            yak_set_product_detail($product_id, $type->cat_id, $sku, $qty, $override_price, $dlfile, $weight);
                      
            $type->qty = $qty;
            $type->price_override = $price_override;
            $type->dl_file = $dlfile;
            $type->weight = $weight;
            
            $return_types[] = $type;
        }
    
        $prod_cat_name = yak_get_option(PRODUCT_CATEGORY_NAME, 'products');
        $row = $wpdb->get_row("select term_id 
                               from $wpdb->terms
                               where slug = '$prod_cat_name'");
        $parent_id = $row->term_id;
        
        $pid = $product_id;
        if (count($_POST['newtype_'])) {
            $pid = "";
        }
        $newtypes = $_POST['newtype_' . $pid];
        $newtype_sku = $_POST['newtype_sku_' . $pid];
        $newtype_names = $_POST['newtype_name_' . $pid];
        $newtype_qty = $_POST['newtype_qty_' . $pid];
        $newtype_price = $_POST['newtype_price_' . $pid];
        $newtype_weight = $_POST['newtype_weight_' . $pid];
        $newtype_dl = $_POST['newtype_dl_file_' . $pid];
        $size = count($newtypes);
        for ($i = 0; $i < $size; $i++) {
            if (!empty($newtype_names[$i])) {
                $name = $newtype_names[$i];
                $cat_id = wp_create_category($name, $parent_id);
            }
            else if (!empty($newtypes[$i])) {
                $cat_id = $newtypes[$i];
                $name = get_the_category_by_ID(intval($cat_id));
            }
            else {
                continue;
            }
        
            $row = $wpdb->get_row("select count(*) as total 
                                   from $wpdb->term_relationships
                                   where object_id = $product_id and term_taxonomy_id = $cat_id");

            if ($row->total < 1) {                            
                $wpdb->query("insert into $wpdb->term_relationships (object_id, term_taxonomy_id)
                              values ($product_id, $cat_id)");
            }
                 
            yak_set_product_detail($product_id, $cat_id, $newtype_sku[$i], $newtype_qty[$i], $newtype_price[$i], $newtype_dl[$i], $newtype_weight[$i]);
        
            $type = new YakProductType($product_id, $cat_id, $name, $newtype_sku[$i], $newtype_qty[$i], $newtype_price[$i], $newtype_weight[$i], $newtype_dl[$i]);
            $return_types[] = $type;
        }
    
        return $return_types;
    }
}


if (!function_exists('yak_validate_address')) {
    /**
     * Validate the address in a post.
     *
     * @param $type the type of address (shipping or billing)
     */
    function yak_validate_address($type) {
        global $required_address_fields;
        
        $missing = array();
        foreach ($required_address_fields as $field => $message) {
            if (empty($_POST[$type . '_' . $field])) {
                $missing[] = __($message, 'yak');
            }
        }

        return $missing;
    }
}


if (!function_exists('yak_view_product_page')) {
    /**
     * Create a page of all products.
     *
     * @param $the_content WP 'the_content' for adding the page content to
     */
    function yak_view_product_page($the_content) {
        global $product_page, $post;
        
        $registry =& Registry::getInstance();
        
        $id = $post->ID;
        
        $pagesize = yak_get_option(PRODUCT_PAGE_SIZE, 10);
        
        if (isset($_GET['offset'])) {
            $offset = $_GET['offset'];   
        }
        else {
            $offset = 0;
        }
        
        $product_page = true;
        $products = yak_get_products('date', $offset, $pagesize + 1);
    
        $s = '';
        
        $count = 0;
        foreach ($products as $ppost) {
            $count += 1;

            if ($count > $pagesize) {
                break;
            }           
            
            $registry->set('yak_post', $ppost);
            
            $s .= '<div class="yak_product"><h3><a href="' . apply_filters('the_permalink', get_permalink($ppost->id)) . '">' . apply_filters('the_title', $ppost->post_title) . '</a></h3>';
            
            if (yak_str_contains($ppost->content->post_content, '<!--more-->')) {
                $content = explode('<!--more-->', $ppost->content->post_content, 2);
                $content = $content[0];
            }
            else {
                $content = $ppost->content->post_content;   
            }
            
            $ppostc = $ppost->content;
            $registry->set('yak_post', $ppostc);
            $s .= apply_filters('the_content', $content);
            
            $s .= '</div>';
        }
        
        $s .= '<br />';
        
        $url = get_bloginfo('wpurl') . '?' . yak_get_post_param() . '=' . $id;
        
        $off1 = $offset - $pagesize;
        $off2 = $offset + $pagesize;
        
        $s .= "<center>";
        
        if ($offset > 0) {
            $s .= '<a href="' . $url . '&offset=' . $off1 . '">' . __('&lt;&lt; Previous', 'yak') . '</a>';   
        }
        
        $total_products = yak_get_product_count();
        $pages = $total_products / $pagesize;
        
        if ($pages > 0) {
            if ($offset > 0) {
                $s .= ' | ';   
            }
            for ($p = 0; $p < $pages; $p++) {
                $page_offset = $p * $pagesize;
                if ($page_offset != $offset) {
                    $s .= '<a href="' . $url . '&offset=' . $page_offset . '">' . ($p + 1) . '</a>';
                }
                else {
                    $s .= ($p + 1);   
                }
                if ($p < $pages - 1) {
                    $s .= ' | ';   
                }
            }
        }
        
        if ($count > $pagesize) {
            if ($offset > 0 || $pages > 0) {
                $s .= ' | ';   
            }
            $s .= '<a href="' . $url . '&offset=' . $off2 . '">' . __('Next &gt;&gt;', 'yak') . '</a>';
        }
        
        $s .= "</center>";
        
        $the_content = str_replace('[yak_product_page]', $s, $the_content);
        
        $product_page = false;
        
        return $the_content;
    }
}

/**
 * WordPress actions
 */
add_action('init', 'yak_init');
add_action('admin_head', 'yak_head_admin');
add_action('wp_head', 'yak_head_wp');
add_action('activate_yak-for-wordpress/yak-for-wordpress.php', 'yak_install');
add_action('admin_menu', 'yak_admin');
add_action('publish_post', 'yak_updproduct');
add_action('publish_page', 'yak_updproduct');

add_action('the_content', 'yak_post_processing', YAK_PRIORITY);

add_action('edit_form_advanced', 'yak_editproduct');
add_action('edit_page_form', 'yak_editproduct');
add_action('edit_post', 'yak_updproduct');

add_action('init', 'yak_add_feeds');

add_action("widgets_init", array('YakOrderWidget', 'register'));

add_filter('plugin_row_meta', 'yak_register_plugin_links', 10, 2);
?>
