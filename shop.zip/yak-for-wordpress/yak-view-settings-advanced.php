<?php
/*
See yak-for-wordpress.php for information and license terms
*/
require_once('yak-utils.php');

global $model;

$imgbase = get_bloginfo('wpurl') . '/wp-content/plugins/yak-for-wordpress/images';

wp_nonce_field('update-options');

$registry =& Registry::getInstance();
$settings_panels =& $registry->get('settings-panels');

?>

<div class="wrap">
    <input type="hidden" name="section" value="options" />

<div id="tabs">
    <ul class="tabs-nav">
        <?php 
            if (isset($settings_panels)) {
                foreach ($settings_panels as $panel) { 
        ?>
        <li><a id="<?php echo $panel->get_id() ?>-tab" href="#<?php echo $panel->get_id() ?>"><span><?php echo $panel->get_title() ?></span></a></li>
        <?php   
                }
            }
        ?>
    </ul>
        
<div class="clear"></div>

<?php 
    if (isset($settings_panels)) {
        foreach ($settings_panels as $panel) { 
?>
<div id="<?php echo $panel->get_id() ?>" class="tabs-container">    
<form name="settingsFrm<?php echo $panel->get_id() ?>" method="post" action="#<?php echo $panel->get_id() ?>">
    <?php echo $panel->get_content($model); ?>

    <div class="submit">
        <input type="submit" name="options_update_<?php echo $panel->get_id() ?>" value="<?php _e('Update options', 'yak-admin') ?>" onclick="return submitSettingsForm('settingsFrm<?php echo $panel->get_id() ?>', '<?php echo $panel->get_id() ?>')" />
    </div>
</form>
</div>
<?php
        }
    }
?>

</div><!--/tabs-container-->

</div><!--/wrap-->

</form>