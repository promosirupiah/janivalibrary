<?php
/*
See yak-for-wordpress.php for information and license terms
*/
if (file_exists(ABSPATH . 'wp-includes/l10n.php')) {
    require_once(ABSPATH . 'wp-includes/l10n.php');
}
else {
    require_once(ABSPATH . 'wp-includes/wp-l10n.php');
}

require_once('yak-promo-utils.php');

global $model;

$shipping_notes = yak_get_option(SHIPPING_NOTES, '');

$default_special_instructions = stripslashes(yak_get_option(DEFAULT_SPECIAL_INSTRUCTIONS, ''));

$terms_and_conditions = stripslashes(yak_get_option(TERMS_AND_CONDITIONS, ''));
if ($terms_and_conditions == '') {
    $include_tandc = 'false';
}
else {
    $include_tandc = 'true';
}

$sep_billing = (yak_get_option(ADDRESS_SEPARATE_BILLING, '') == 'on');

$ptype = $_SESSION['payment_type'];

if (isset($model['error_message'])) {
?>

<div class="yak_error"><?php echo $model['error_message'] ?></div>

<?php
}
?>

<h3><?php _e('Confirm your order', 'yak'); ?></h3>

<?php 
include 'yak-view-address-snippet.php'; 
?>
        
<p>&nbsp;</p>

<h3><?php _e('Order Detail', 'yak'); ?></h3>

<form name="confirm2" method="post" action="<?php echo get_bloginfo('wpurl') ?>/?stage=confirm">
    <table class="yak_order">
        <tr>
            <th><?php _e('Title', 'yak'); ?></th>
            <th class="yak_numeric"><?php _e('Price', 'yak') ?></th>
            <th class="yak_numeric"><?php _e('Qty', 'yak') ?></th>
            <th class="yak_numeric"><?php _e('Subtotal', 'yak') ?></th>
        </tr>
        
<?php
    $total_price = 0;
    $total_quantity = 0;
    $total_weight = 0;
    $total_discount = 0;
    
    if (!empty($model['promo_code'])) {
        $promo = yak_get_promotion($model['promo_code']);
    }
    else {
        $promo = null;
    }
    
    $total_items = yak_get_total_items($model['items']);
    
    foreach ($model['items'] as $key => $item) {
        $item->price = yak_calc_price($item->id, $item->cat_id);
        $item->discount = yak_calc_price_discount($item->price, $total_items, $promo);
        $total_discount += ($item->discount * $item->quantity);
        
        $total_price += $item->get_discount_total();
        $total_quantity += $item->quantity;
        
        $total_weight += $item->get_total_weight();
        
        $act_shipping_cost = 0;
?>
        <tr>
            <td class="yak_left"><?php echo $item->name ?></td>
            <td class="yak_numeric"><?php echo yak_format_money($item->price) ?></td>
            <td class="yak_numeric"><?php echo $item->quantity ?></td>
            <td class="yak_numeric"><?php echo yak_format_money($item->get_total()) ?></td>
        </tr>
<?php
        if (isset($item->selected_options)) {
?>
        <tr>
            <td class="yak_left" colspan="4">
<?php
            foreach ($item->selected_options as $mitem) {
                echo "&nbsp;&nbsp;$mitem <br />";
            }
?>          
            </td>
        </tr>
<?php
        }
    }
    
    if ($promo == null) {
        $promo = yak_get_promotion_by_threshold($total_price);
        if ($promo != null) {
            $price_discount = yak_calc_price_discount($total_price, $total_items, $promo);
            if ($price_discount > 0) {
                $total_price -= $price_discount;
                $total_discount = $price_discount;
            }
        }
    }
    
    $grand_total = $total_price;
    
    // calculate shipping
    if (yak_get_option(INCLUDE_SHIPPING_COSTS, 'no') == 'yes') {
        global $shipping_costs;
        
        $cty = str_replace(' ', '_', $_POST['shipping_country']);
        $act_shipping_cost = yak_calc_shipping($total_weight, $total_items, $cty);
        $grand_total += $act_shipping_cost;
        
        if ($promo != null) {
            $shipping_discount = yak_calc_shipping_discount($act_shipping_cost, $promo);
            
            if ($shipping_discount > 0) {
                $grand_total -= $shipping_discount;
                $total_discount = $shipping_discount;
            }
        }
?>
        <tr id="yak_shipping">
            <td class="yak_left"><?php _e('Shipping costs', 'yak') ?></td>
            <td></td>
            <td></td>
            <td class="yak_numeric"><?php echo yak_format_money($act_shipping_cost) ?></td>
        </tr>
<?php
        if ($shipping_notes != '') {
?>
        <tr>
            <td class="yak_small"><?php echo $shipping_notes ?></td>
            <td colspan="3"></td>
        </tr>
<?php
        }
    }
?>
<?php
        if ($promo != null) {
?>
        <tr>
            <td class="yak_left">Total Discount (<?php echo $promo->description ?>)</td>
            <td></td>
            <td></td>
            <td class="yak_numeric">-<?php echo yak_format_money($total_discount) ?></td>
        </tr>
<?php
        }
?>
        <tr>
            <td class="yak_total" colspan="3"><?php _e('Total', 'yak') ?></td>
            <td class="yak_total"><?php echo yak_format_money($grand_total, true) ?></td>
        </tr>
        
        <tr>
            <td class="yak_small" colspan="4"><?php _e('Payment method', 'yak') ?>: <strong><?php echo $ptype ?></strong></td>
        </tr>
        
<?php
        if (!empty($default_special_instructions)) {
?>
        <tr>
            <td class="yak_small" valign="top"><?php echo _e('Special Instructions', 'yak') ?> : </td>
            <td colspan="3" align="right"><textarea class="yak_small" name="special_instructions" cols="32" rows="4" onclick="this.focus(); this.select()" onKeyUp="limitTextArea(this, 250)"><?php echo $default_special_instructions ?></textarea></td>
        </tr>
<?php
        }
?>

<?php
        if (!empty($terms_and_conditions)) {
?>
        <tr>
            <td colspan="4" align="left"><?php echo $terms_and_conditions ?> <input type="checkbox" name="tandcConfirmation" /></td>
        </tr>
<?php
        }
?>
        <tr>
            <td class="yak_left" colspan="4"><button id="confirmorderbutton" class="yak_button" onclick="return yakConfirmOrder(this, <?php echo $include_tandc ?>)" type="submit"><?php _e('Confirm order', 'yak') ?></button></td>
        </tr>

    </table>
    <input type="hidden" name="totalprice" value="<?php echo $grand_total ?>" />
    <input type="hidden" name="action" value="confirm2" />
    <input type="hidden" name="<?php echo $model['param_name'] ?>" value="<?php echo $model['post_id'] ?>" />
    <input type="hidden" name="shipping_country" value="<?php echo $_POST['shipping_country'] ?>" />

<?php
    if (count($selected_payment_options) == 1) {        
?>
    <input type="hidden" name="payment_type" value="<?php echo $selected_payment_options[0] ?>" />

<?php
    }
?>

</form>