/**
 * Good old Javascript
 */

function copyRow(tableName) {
	table = getElement(tableName);
	cells = table.rows[table.rows.length-1].cells;
	tbody = table.getElementsByTagName('tbody');
	if (tbody.length > 0) {
	    table = tbody[0];
	}
	var newrow = document.createElement('tr');
	for (var i = 0; i < cells.length; i++) {
		cell = document.createElement('td');
		cell.innerHTML = cells[i].innerHTML;
		cell.style.display = 'table-cell';
		newrow.appendChild(cell);
	}
	table.appendChild(newrow);
}

function findInput(cell, name) {
    row = cell.parentNode;
    for (var i = cell.cellIndex-1; i >= 0; i--) {
        var sibling = row.cells[i];
        if (sibling.firstChild.nodeName.toLowerCase() == 'input') {
            if (name == null || name == sibling.firstChild.name) {
                return sibling.firstChild;
            }
        }
    }
    return null;
}

function find(elem, tag, name) {
    if (elem == null) {
        return null;
    }
    else if (elem.nodeName.toLowerCase() == tag.toLowerCase()) {
        if (name == null || name == undefined || elem.name == name) {
            return elem;
        }
    }
    for (var i = 0; i < elem.childNodes.length; i++) {
        var found = find(elem.childNodes[i], tag, name);
        if (found != null) {
            return found;
        }
    }
    return null;
}

function removePromotion(input) {
    cell = input.parentNode;
    code_input = findInput(cell, 'promo_code[]');
    code_input.value = '';
    row = cell.parentNode;
    row.style.visibility = 'hidden';
    row.style.display = 'none';
}

function startsWith(str, prefix) {
    return str.substring(0, prefix.length) == prefix;
}

function selectAllCheckboxes(form, checkbox, prefix) {
    var checked = false;
    if (checkbox.checked) {
        checked = true;
    }
    
    var inputs = document.forms[form].getElementsByTagName('input');
    
    for (i = 0; i < inputs.length; i++) {
        if (inputs[i].type == 'checkbox' && startsWith(inputs[i].name, prefix)) {
            inputs[i].checked = checked;
        }
    }
}

function submitSettingsForm(form, anchor) {
    document.forms[form].action = '#' + anchor;
    return true;
}

function addProductRow(tableId) {
    table = getElement(tableId);
    lastrow = table.rows[table.rows.length-1];
    if (lastrow.style.visibility == 'hidden') {
        lastrow.style.visibility = 'visible';
    }
    else {
        copyRow(tableId);
    }
}

function newProductToggle(tableId) {
    table = getElement(tableId);
    firstCell = table.rows[table.rows.length - 1].cells[0];
    for (i = 0; i < firstCell.childNodes.length; i++) {
        n = firstCell.childNodes[i];
        if (n.tagName == null || n.tagName == 'button' || n.tagName == 'BUTTON' || n.tagName == 'undefined') {
            continue;
        }
        else if (n.style.visibility == 'hidden') {
            n.style.visibility = 'visible';
            n.style.display = 'block';
        }
        else {
            n.style.visibility = 'hidden';
            n.style.display = 'none';
        }
    }
}

function removeExistingProductType(elem, deleteInputName) {
    tr = findParent(elem, 'TR');
    input = find(tr, 'INPUT', deleteInputName);
    input.value = 'true';
    tr.style.visibility = 'hidden';
    tr.style.display = 'none';
}

/**
 * Inobtrusive robust collapsible table
 */
(function($){var defaults={classCollapse:"collapsible",classExpand:"expand-child",classAnchor:["collapsed","expanded"]},bHideParentRow=!!$.browser.msie;$.fn.collapsible=function(options){var self=this,settings=$.extend({},defaults,options);return this.each(function(){var $td=$("td."+settings.classCollapse,this).append('<a href="#" class="button-secondary '+settings.classAnchor[0]+'">Details</a>').find('a').bind("click",function(){var $a=$(this),$tr=$a.parent().parent(),$trc=$tr.next(),bIsCollapsed=$a.hasClass(settings.classAnchor[1]);$a[bIsCollapsed?"removeClass":"addClass"](settings.classAnchor[1])[!bIsCollapsed?"removeClass":"addClass"](settings.classAnchor[0]);while($trc.hasClass(settings.classExpand)){if(bHideParentRow){var ts_config=$.data(self[0],"tablesorter");$trc[bIsCollapsed?"hide":"show"]();if(!bIsCollapsed&&ts_config){if($tr.hasClass(ts_config.widgetZebra.css[0]))$trc.addClass(ts_config.widgetZebra.css[0]).removeClass(ts_config.widgetZebra.css[1]);else if($tr.hasClass(ts_config.widgetZebra.css[1]))$trc.addClass(ts_config.widgetZebra.css[1]).removeClass(ts_config.widgetZebra.css[0]);}}
$("td",$trc)[bIsCollapsed?"hide":"show"]();$trc=$trc.next();}
return false;}).end();if(bHideParentRow){$td.parent().each(function(){var $tr=$(this).next();while($tr.hasClass(settings.classExpand)){$tr=$tr.hide().next();}});}});}})(jQuery);


/** 
 * Initialize tables 
 */
jQuery(function() {
    jQuery('.collapsible').collapsible()
});


/**
 * Tabs
 */
(function($){$.extend({tabs:{remoteCount:0}});$.fn.tabs=function(initial,settings){if(typeof initial=='object')settings=initial;settings=$.extend({initial:(initial&&typeof initial=='number'&&initial>0)?--initial:0,disabled:null,bookmarkable:$.ajaxHistory?true:false,remote:false,spinner:'Loading&#8230;',hashPrefix:'remote-tab-',fxFade:null,fxSlide:null,fxShow:null,fxHide:null,fxSpeed:'normal',fxShowSpeed:null,fxHideSpeed:null,fxAutoHeight:false,onClick:null,onHide:null,onShow:null,navClass:'tabs-nav',selectedClass:'tabs-selected',disabledClass:'tabs-disabled',containerClass:'tabs-container',hideClass:'tabs-hide',loadingClass:'tabs-loading',tabStruct:'div'},settings||{});$.browser.msie6=$.browser.msie&&($.browser.version&&$.browser.version<7||/6.0/.test(navigator.userAgent));function unFocus(){scrollTo(0,0);}return this.each(function(){var container=this;var nav=$('ul.'+settings.navClass,container);nav=nav.size()&&nav||$('>ul:eq(0)',container);var tabs=$('a',nav);if(settings.remote){tabs.each(function(){var id=settings.hashPrefix+(++$.tabs.remoteCount),hash='#'+id,url=this.href;this.href=hash;$('<div id="'+id+'" class="'+settings.containerClass+'"></div>').appendTo(container);$(this).bind('loadRemoteTab',function(e,callback){var $$=$(this).addClass(settings.loadingClass),span=$('span',this)[0],tabTitle=span.innerHTML;if(settings.spinner){span.innerHTML='<em>'+settings.spinner+'</em>';}setTimeout(function(){$(hash).load(url,function(){if(settings.spinner){span.innerHTML=tabTitle;}$$.removeClass(settings.loadingClass);callback&&callback();});},0);});});}var containers=$('div.'+settings.containerClass,container);containers=containers.size()&&containers||$('>'+settings.tabStruct,container);nav.is('.'+settings.navClass)||nav.addClass(settings.navClass);containers.each(function(){var $$=$(this);$$.is('.'+settings.containerClass)||$$.addClass(settings.containerClass);});var hasSelectedClass=$('li',nav).index($('li.'+settings.selectedClass,nav)[0]);if(hasSelectedClass>=0){settings.initial=hasSelectedClass;}if(location.hash){tabs.each(function(i){if(this.hash==location.hash){settings.initial=i;if(($.browser.msie||$.browser.opera)&&!settings.remote){var toShow=$(location.hash);var toShowId=toShow.attr('id');toShow.attr('id','');setTimeout(function(){toShow.attr('id',toShowId);},500);}unFocus();return false;}});}if($.browser.msie){unFocus();}containers.filter(':eq('+settings.initial+')').show().end().not(':eq('+settings.initial+')').addClass(settings.hideClass);$('li',nav).removeClass(settings.selectedClass).eq(settings.initial).addClass(settings.selectedClass);tabs.eq(settings.initial).trigger('loadRemoteTab').end();if(settings.fxAutoHeight){var _setAutoHeight=function(reset){var heights=$.map(containers.get(),function(el){var h,jq=$(el);if(reset){if($.browser.msie6){el.style.removeExpression('behaviour');el.style.height='';el.minHeight=null;}h=jq.css({'min-height':''}).height();}else{h=jq.height();}return h;}).sort(function(a,b){return b-a;});if($.browser.msie6){containers.each(function(){this.minHeight=heights[0]+'px';this.style.setExpression('behaviour','this.style.height = this.minHeight ? this.minHeight : "1px"');});}else{containers.css({'min-height':heights[0]+'px'});}};_setAutoHeight();var cachedWidth=container.offsetWidth;var cachedHeight=container.offsetHeight;var watchFontSize=$('#tabs-watch-font-size').get(0)||$('<span id="tabs-watch-font-size">M</span>').css({display:'block',position:'absolute',visibility:'hidden'}).appendTo(document.body).get(0);var cachedFontSize=watchFontSize.offsetHeight;setInterval(function(){var currentWidth=container.offsetWidth;var currentHeight=container.offsetHeight;var currentFontSize=watchFontSize.offsetHeight;if(currentHeight>cachedHeight||currentWidth!=cachedWidth||currentFontSize!=cachedFontSize){_setAutoHeight((currentWidth>cachedWidth||currentFontSize<cachedFontSize));cachedWidth=currentWidth;cachedHeight=currentHeight;cachedFontSize=currentFontSize;}},50);}var showAnim={},hideAnim={},showSpeed=settings.fxShowSpeed||settings.fxSpeed,hideSpeed=settings.fxHideSpeed||settings.fxSpeed;if(settings.fxSlide||settings.fxFade){if(settings.fxSlide){showAnim['height']='show';hideAnim['height']='hide';}if(settings.fxFade){showAnim['opacity']='show';hideAnim['opacity']='hide';}}else{if(settings.fxShow){showAnim=settings.fxShow;}else{showAnim['min-width']=0;showSpeed=1;}if(settings.fxHide){hideAnim=settings.fxHide;}else{hideAnim['min-width']=0;hideSpeed=1;}}var onClick=settings.onClick,onHide=settings.onHide,onShow=settings.onShow;tabs.bind('triggerTab',function(){var li=$(this).parents('li:eq(0)');if(container.locked||li.is('.'+settings.selectedClass)||li.is('.'+settings.disabledClass)){return false;}var hash=this.hash;if($.browser.msie){$(this).trigger('click');if(settings.bookmarkable){$.ajaxHistory.update(hash);location.hash=hash.replace('#','');}}else if($.browser.safari){var tempForm=$('<form action="'+hash+'"><div><input type="submit" value="h" /></div></form>').get(0);tempForm.submit();$(this).trigger('click');if(settings.bookmarkable){$.ajaxHistory.update(hash);}}else{if(settings.bookmarkable){location.hash=hash.replace('#','');}else{$(this).trigger('click');}}});tabs.bind('disableTab',function(){var li=$(this).parents('li:eq(0)');if($.browser.safari){li.animate({opacity:0},1,function(){li.css({opacity:''});});}li.addClass(settings.disabledClass);});if(settings.disabled&&settings.disabled.length){for(var i=0,k=settings.disabled.length;i<k;i++){tabs.eq(--settings.disabled[i]).trigger('disableTab').end();}};tabs.bind('enableTab',function(){var li=$(this).parents('li:eq(0)');li.removeClass(settings.disabledClass);if($.browser.safari){li.animate({opacity:1},1,function(){li.css({opacity:''});});}});tabs.bind('click',function(e){var trueClick=e.clientX;var clicked=this,li=$(this).parents('li:eq(0)'),toShow=$(this.hash),toHide=containers.filter(':visible');if(container['locked']||li.is('.'+settings.selectedClass)||li.is('.'+settings.disabledClass)||typeof onClick=='function'&&onClick(this,toShow[0],toHide[0])===false){this.blur();return false;}container['locked']=true;if(toShow.size()){if($.browser.msie&&settings.bookmarkable){var toShowId=this.hash.replace('#','');toShow.attr('id','');setTimeout(function(){toShow.attr('id',toShowId);},0);}var resetCSS={display:'',overflow:'',height:''};if(!$.browser.msie){resetCSS['opacity']='';}function switchTab(){if(settings.bookmarkable&&trueClick){$.ajaxHistory.update(clicked.hash);}toHide.animate(hideAnim,hideSpeed,function(){$(clicked).parents('li:eq(0)').addClass(settings.selectedClass).siblings().removeClass(settings.selectedClass);toHide.addClass(settings.hideClass).css(resetCSS);if(typeof onHide=='function'){onHide(clicked,toShow[0],toHide[0]);}if(!(settings.fxSlide||settings.fxFade||settings.fxShow)){toShow.css('display','block');}toShow.animate(showAnim,showSpeed,function(){toShow.removeClass(settings.hideClass).css(resetCSS);if($.browser.msie){toHide[0].style.filter='';toShow[0].style.filter='';}if(typeof onShow=='function'){onShow(clicked,toShow[0],toHide[0]);}container['locked']=null;});});}if(!settings.remote){switchTab();}else{$(clicked).trigger('loadRemoteTab',[switchTab]);}}else{alert('There is no such container.');}var scrollX=window.pageXOffset||document.documentElement&&document.documentElement.scrollLeft||document.body.scrollLeft||0;var scrollY=window.pageYOffset||document.documentElement&&document.documentElement.scrollTop||document.body.scrollTop||0;setTimeout(function(){window.scrollTo(scrollX,scrollY);},0);this.blur();return settings.bookmarkable&&!!trueClick;});if(settings.bookmarkable){$.ajaxHistory.initialize(function(){tabs.eq(settings.initial).trigger('click').end();});}});};var tabEvents=['triggerTab','disableTab','enableTab'];for(var i=0;i<tabEvents.length;i++){$.fn[tabEvents[i]]=(function(tabEvent){return function(tab){return this.each(function(){var nav=$('ul.tabs-nav',this);nav=nav.size()&&nav||$('>ul:eq(0)',this);var a;if(!tab||typeof tab=='number'){a=$('li a',nav).eq((tab&&tab>0&&tab-1||0));}else if(typeof tab=='string'){a=$('li a[@href$="#'+tab+'"]',nav);}a.trigger(tabEvent);});};})(tabEvents[i]);}$.fn.activeTab=function(){var selectedTabs=[];this.each(function(){var nav=$('ul.tabs-nav',this);nav=nav.size()&&nav||$('>ul:eq(0)',this);var lis=$('li',nav);selectedTabs.push(lis.index(lis.filter('.tabs-selected')[0])+1);});return selectedTabs[0];};})(jQuery);

/**
 * History/Remote - Works with the tabs plugin for enabling history support and bookmarking
 */
(function($){$.ajaxHistory=new function(){var RESET_EVENT='historyReset';var _currentHash=location.hash;var _intervalId=null;var _observeHistory;this.update=function(){};var _defaultReset=function(){$('.remote-output').empty();};$(document).bind(RESET_EVENT,_defaultReset);if($.browser.msie){var _historyIframe,initialized=false;$(function(){_historyIframe=$('<iframe style="display: none;"></iframe>').appendTo(document.body).get(0);var iframe=_historyIframe.contentWindow.document;iframe.open();iframe.close();if(_currentHash&&_currentHash!='#'){iframe.location.hash=_currentHash.replace('#','');}});this.update=function(hash){_currentHash=hash;var iframe=_historyIframe.contentWindow.document;iframe.open();iframe.close();iframe.location.hash=hash.replace('#','');};_observeHistory=function(){var iframe=_historyIframe.contentWindow.document;var iframeHash=iframe.location.hash;if(iframeHash!=_currentHash){_currentHash=iframeHash;if(iframeHash&&iframeHash!='#'){$('a[@href$="'+iframeHash+'"]').click();location.hash=iframeHash;}else if(initialized){location.hash='';$(document).trigger(RESET_EVENT);}}initialized=true;};}else if($.browser.mozilla||$.browser.opera){this.update=function(hash){_currentHash=hash;};_observeHistory=function(){if(location.hash){if(_currentHash!=location.hash){_currentHash=location.hash;$('a[@href$="'+_currentHash+'"]').click();}}else if(_currentHash){_currentHash='';$(document).trigger(RESET_EVENT);}};}else if($.browser.safari){var _backStack,_forwardStack,_addHistory;$(function(){_backStack=[];_backStack.length=history.length;_forwardStack=[];});var isFirst=false,initialized=false;_addHistory=function(hash){_backStack.push(hash);_forwardStack.length=0;isFirst=false;};this.update=function(hash){_currentHash=hash;_addHistory(_currentHash);};_observeHistory=function(){var historyDelta=history.length-_backStack.length;if(historyDelta){isFirst=false;if(historyDelta<0){for(var i=0;i<Math.abs(historyDelta);i++)_forwardStack.unshift(_backStack.pop());}else{for(var i=0;i<historyDelta;i++)_backStack.push(_forwardStack.shift());}var cachedHash=_backStack[_backStack.length-1];$('a[@href$="'+cachedHash+'"]').click();_currentHash=location.hash;}else if(_backStack[_backStack.length-1]==undefined&&!isFirst){if(document.URL.indexOf('#')>=0){$('a[@href$="'+'#'+document.URL.split('#')[1]+'"]').click();}else if(initialized){$(document).trigger(RESET_EVENT);}isFirst=true;}initialized=true;};}this.initialize=function(callback){if(typeof callback=='function'){$(document).unbind(RESET_EVENT,_defaultReset).bind(RESET_EVENT,callback);}if(location.hash&&typeof _addHistory=='undefined'){$('a[@href$="'+location.hash+'"]').trigger('click');}if(_observeHistory&&_intervalId==null){_intervalId=setInterval(_observeHistory,200);}};};$.fn.remote=function(output,settings,callback){callback=callback||function(){};if(typeof settings=='function'){callback=settings;}settings=$.extend({hashPrefix:'remote-'},settings||{});var target=$(output).size()&&$(output)||$('<div></div>').appendTo('body');target.addClass('remote-output');return this.each(function(i){var href=this.href,hash='#'+(this.title&&this.title.replace(/\s/g,'_')||settings.hashPrefix+(i+1)),a=this;this.href=hash;$(this).click(function(e){if(!target['locked']){if(e.clientX){$.ajaxHistory.update(hash);}target.load(href,function(){target['locked']=null;callback.apply(a);});}});});};$.fn.history=function(callback){return this.click(function(e){if(e.clientX){$.ajaxHistory.update(this.hash);}typeof callback=='function'&&callback();});};})(jQuery);


/**
 * Initialize tabs 
 */
jQuery(function(){
jQuery('#tabs').tabs({
fxSlide: false,
fxFade: false,
fxSpeed: 'slow'
});
});