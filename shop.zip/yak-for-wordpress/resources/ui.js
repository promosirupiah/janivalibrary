/**
 * Good old Javascript
 */

function findParent(elem, nodeName) {
    if (elem == null || elem == undefined) {
        return null;
    }
    else if (elem.parentNode != null && elem.parentNode.nodeName != null 
            && elem.parentNode.nodeName.toLowerCase() == nodeName.toLowerCase()) {
        return elem.parentNode;
    }
    else {
        return findParent(elem.parentNode, nodeName);
    }
}

function getElement(id) {
    if (document.getElementById) {
        var returnVar = document.getElementById(id); 
    }
    else if (document.all) {
        var returnVar = document.all[id];
    }
    else if (document.layers) {
        var returnVar = document.layers[id];
    }
    return returnVar; 
}

function findFormElement(frm, elementName) {
    for (var i = 0; i < frm.elements.length; i++) {
        if (frm.elements[i].name == elementName) {
            return frm.elements[i];
        }
    }
    return null;
}

function getFormElement(formId, elementName) {
    frm = getElement(formId);
    return findFormElement(frm, elementName);
}

function isEmpty(s) {
    if (s == undefined || s == null) {
        return true;
    }
    
    if (typeof(s) == 'object' && eval('typeof(s.value)') != 'undefined') {
        s = s.value;
    }
    
    return s == undefined || s == null || s == '';
}

function updateQuantities() {
    document.forms['cart'].action.value = 'update';
    return true;
}

function deleteProduct(id) {
    getElement(id).value = 0;
    return updateQuantities();
}

function billing() {
    elem = getElement('billing')
    if (elem.style.visibility == 'hidden') {
        elem.style.visibility = 'visible';
        elem.style.display = 'block';
    }
    else {
        elem.style.visibility = 'hidden';
        elem.style.display = 'none';
    }
}

function setDisplay(elementId, display) {
    if (document.layers) {
    	document.layers[elementId].display = display;
    }
    else if (document.all && document.all[elementId] && document.all[elementId].style) {
    	document.all[elementId].style.display = display;
    }
    else if (document.getElementById) {
    	document.getElementById(elementId).style.display = display;
    }    
}

function changeRegion(prefix, stateText, regionText) {
    country = getElement(prefix + '_country_input');
    regionLabel = getElement(prefix + '_region_label');

    if (country.value == 'US') {
        regionLabel.innerHTML = stateText;
        setDisplay(prefix + '_state_input', '');
        getElement(prefix + '_state_input').disabled = false;
        setDisplay(prefix + '_ca_state_input', 'none');
        getElement(prefix + '_ca_state_input').disabled = true;
        setDisplay(prefix + '_region_input', 'none');
        getElement(prefix + '_region_input').value = '';
    }
    else if (country.value == 'CA') {
        regionLabel.innerHTML = stateText;
        setDisplay(prefix + '_ca_state_input', '');
        getElement(prefix + '_ca_state_input').disabled = false;
        setDisplay(prefix + '_state_input', 'none');
        getElement(prefix + '_state_input').disabled = true;
        setDisplay(prefix + '_region_input', 'none');
        getElement(prefix + '_region_input').value = '';
    }
    else {
        regionLabel.innerHTML = regionText;
        setDisplay(prefix + '_state_input', 'none');
        setDisplay(prefix + '_ca_state_input', 'none');
        setDisplay(prefix + '_region_input', '');
    }
}

function editAddress(stateText, regionText) {
    copyAddress('shipping', stateText, regionText);
    copyAddress('billing', stateText, regionText);
    return false;
}

function copyAddress(type, stateText, regionText) {
    old_email = getFormElement('oldaddress', type + '_email');
    old_recip = getFormElement('oldaddress', type + '_recipient');
    old_phone = getFormElement('oldaddress', type + '_phone');
    old_addr1 = getFormElement('oldaddress', type + '_addr1');
    old_addr2 = getFormElement('oldaddress', type + '_addr2');
    old_suburb = getFormElement('oldaddress', type + '_suburb');
    old_city = getFormElement('oldaddress', type + '_city');
    old_region = getFormElement('oldaddress', type + '_region');
    old_state = getFormElement('oldaddress', type + '_state');
    old_postcode = getFormElement('oldaddress', type + '_postcode');
    old_country = getFormElement('oldaddress', type + '_country');
    
    new_email = getFormElement('address', type + '_email');
    new_recip = getFormElement('address', type + '_recipient');
    new_phone = getFormElement('address', type + '_phone');
    new_addr1 = getFormElement('address', type + '_addr1');
    new_addr2 = getFormElement('address', type + '_addr2');
    new_suburb = getFormElement('address', type + '_suburb');
    new_city = getFormElement('address', type + '_city');
    new_region = getFormElement('address', type + '_region');
    new_state = getFormElement('address', type + '_state');
    new_postcode = getFormElement('address', type + '_postcode');
    new_country = getFormElement('address', type + '_country');

    copyInputValue(new_email, old_email);
    copyInputValue(new_recip, old_recip);
    copyInputValue(new_phone, old_phone);
    copyInputValue(new_addr1, old_addr1);
    copyInputValue(new_addr2, old_addr2);
    copyInputValue(new_suburb, old_suburb);
    copyInputValue(new_city, old_city);
    copyInputValue(new_region, old_region);
    if (old_state != null) {
        setSelectByValue(new_state, old_state.value);
    }
    copyInputValue(new_postcode, old_postcode);
    if (old_country != null) {
        setSelectByValue(new_country, old_country.value);
    }
    
    changeRegion(type, stateText, regionText);
}

function copyInputValue(destInput, srcInput) {
    if (destInput != null && srcInput != null) {
        destInput.value = srcInput.value;
    }
}

function setSelectByValue(destSelect, value) {
    if (destSelect != null) {
        for (i = 0; i < destSelect.options.length; i++) {
            if (destSelect.options[i].value == value) {
                destSelect.selectedIndex = i;
                return;
            }
        }
    }
}

function exportData(baseUrl) {
    var link = getElement('export-data-link');
    
    var href = baseUrl;
    
    var status = getElement('status');
    var year = getElement('year_order_date');
    var month = getElement('month_order_date');
    
    href += "&status=" + status.options[status.selectedIndex].value.replace(' ', '+');
    
    if (!isEmpty(year)) {
        href += "&year=" + year.value;
        
        if (!isEmpty(month)) {
            href += "&month=" + month.value;
        }
    }
    
    link.href = href;
    
    return true;
}

function limitTextArea(limitField, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    }
}

function validateBuy(button, multiSelectMin, multiSelectMax) {
    frm = findParent(button, 'FORM');
    ms = frm.elements['multiselect[]'];
    count = 0;
    for (i = 0; i < ms.length; i++) {
        if (ms[i].checked) {
            count++;
        }
    }
    if (count < multiSelectMin || count > multiSelectMax) {
        return false;
    }
    else {
        return true;
    }
}

function yakConfirmOrder(button, incTandC) {
    if (incTandC) {
        frm = findParent(button, 'FORM');
        checkbox = findFormElement(frm, 'tandcConfirmation');
        if (!checkbox.checked) {
            return false;
        }
    }
    return true;
}