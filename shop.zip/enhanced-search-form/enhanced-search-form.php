<?php
/*
Plugin Name: Enhanced Search Form
Plugin URI: http://oogami.name/
Description: Enhance wordpress search form to allow searching posts in certain category, month archive or tag.
Version: 0.2
Author: Ono Oogami
Author URI: http://oogami.name/
*/

/*
Copyright (C) 2009 Ono Oogami, http://oogami.name/ (ono@oogami.name)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

//by default if you pass cat[] / tag[] as a Array GET/POST variable to server, WP convert it to string "Array", this function fixs it.
add_filter('request', 'esf_set_array_var');
function esf_set_array_var($vars) {
	if( empty($vars['s']) ) return $vars;

	if( isset($vars['cat']) && strtolower($vars['cat']) == "array" ) unset($vars['cat']);
	if( isset($vars['tag']) && strtolower($vars['tag']) == "array" ) unset($vars['tag']);

	$cat = false;
	if( is_array($_POST['cat']) )
		$cat = array_map('intval', $_POST['cat']);
	elseif( is_array($_GET['cat']) )
		$cat = array_map('intval', $_GET['cat']);
	if( $cat && !in_array(0, $cat) ) // o means all categories
		$vars['cat'] = implode(',', $cat);

	$tag = false;
	//var_dump($_GET['tag']);die();
	if( is_array($_POST['tag']) )
		$tag = $_POST['tag'];
	elseif( is_array($_GET['tag']) )
		$tag = $_GET['tag'];
	if( $tag && !in_array("", $tag) )
		$vars['tag'] = implode(',', $tag);
	return $vars;
}


add_filter('get_search_form', 'esf_search_form');
function esf_search_form($form) {
	return preg_replace('/((<\/div\s*>\s*)?<\/form\s*>)/', esf_add_form_field(true) . '\\1', $form, 1);
}

function esf_add_form_field($return = false) {
	$show_advanced_options_when_loading = is_search() //&& ( get_query_var('cat') || get_query_var('m') || get_query_var('tag') )
		;
	$dom_id = 'enhanced_search_options';

	global $wpdb, $wp_locale;
	$r = '';
	$r .= '<input type="button" class="enhanced_search_options_advanced_button" value="Advanced" onclick="esf_div=document.getElementById(\'' . $dom_id . '\');if(esf_div.style.display==\'none\') esf_div.style.display=\'block\';else esf_div.style.display=\'none\';document.getElementById(\'' . $dom_id . '_cat\').disabled=!document.getElementById(\'' . $dom_id . '_cat\').disabled;document.getElementById(\'' . $dom_id . '_m\').disabled=!document.getElementById(\'' . $dom_id . '_m\').disabled;esf_tag=document.getElementById(\'' . $dom_id . '_tag\');if(esf_tag) esf_tag.disabled=!esf_tag.disabled;return false;" />';
	$r .= '<div class="enhanced_search_options" id="' . $dom_id . '" style="display:' . ( $show_advanced_options_when_loading ? 'block' : 'none' ) . ';">';
	
	//categories
	/*
	$cats = wp_dropdown_categories('hierarchical=1&echo=0&show_option_all=ALL');
	if( !empty($cats) ) {
		$r .= '<label for="' . $dom_id . '_cat">Search In Category: </label>';
		$r .= str_replace("<select name='cat' id='cat'", "<select name='cat' id='" . $dom_id . "_cat'", $cats);
		$r .= '<br />';
	}
	*/
	$current_cats = (array) preg_split('/[,\s]+/', get_query_var('cat'));
	$r .= '<label for="' . $dom_id . '_cat">Search In Category(s): </label>';
	$r .= '<select id="' . $dom_id . '_cat" name="cat[]" value="" multiple="multiple" size="5"' . ( $show_advanced_options_when_loading ? '' : ' disabled="disabled"' ) . '>';
	$cats = get_categories();
	$r .= '<option value=""' . ( get_query_var('cat') ? '' : ' selected="selected"' ) . '>ALL</option>';
	foreach($cats as $cat)
		$r .=  '<option value="' . $cat->term_id . '"' . ( in_array($cat->term_id, $current_cats) ? ' selected="selected"' : '' ) . '>' . $cat->name . '</option>';
	$r .= '</select><br />';
	
	

	
	//tags
	$tags = get_terms('post_tag', array( 'number' => 45, 'orderby' => 'count', 'order' => 'DESC' ) ); 
	$current_tags = (array) preg_split('/[,\s]+/', get_query_var('tag'));
	if ( !empty( $tags ) ) {
		$r .= '<label for="' . $dom_id . '_tag">Search In Tag(s): </label>';
		$r .=  '<select multiple="multiple" size="5" id="' . $dom_id . '_tag" name="tag[]" value=""' . ( $show_advanced_options_when_loading ? '' : ' disabled="disabled"' ) . '>';
		$r .= '<option value=""' . ( get_query_var('tag') ? '' : ' selected="selected"' ) . '>ALL</option>';
		$tags_slugs = array();
		foreach ( $tags as $tag ) {
			$r .= '<option value="' . urldecode($tag->slug) . '"' . ( in_array($tag->slug, $current_tags) ? ' selected="selected"' : '' ) . '>' . $tag->name . '</option>';
			$tags_slugs[] = $tag->slug;
		}
		if( $current_tags ) { // current tag(s) should always be in search form tags list.
			$tt = array();
			foreach($current_tags as $ct)
				if( $ct && !in_array($ct, $tags_slugs) )
					$tt[] = $ct;
			if( !empty($tt) )
				foreach($tt as $key=>$t) {
					$tx = get_term_by('slug', $t, 'post_tag');
					$r .= '<option value="' . urldecode($tx->slug) . '" selected="selected">' . $tx->name . '</option>';
				}
		}
		$r .=  '</select>';
	}

	$r .= '</div>';

	if($return)
		return $r;
	echo $r;
}

?>