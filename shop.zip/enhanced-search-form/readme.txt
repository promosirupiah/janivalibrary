=== Enhanced Search Form ===
Contributors: Ono Oogami
Donate link: http://oogami.name/donate/
Tags: widget, sidebar, search, form
Requires at least: 2.7
Tested up to: 2.8.4
Stable tag: 0.2

Enhance wordpress search form to allow searching posts in certain category(s), month archive(s) or tag(s).

== Description ==

Wordpress has a build-in search system which actually allow searching posts in certain one or mutiple category(s), month archive(s) and tag(s). However, by default you must manually add extra GET/ POST parameter to search query to enable these features.

This plugin enhanced the wordpress search form so visitors can submit a more advanced search query via XHTML visual Form, allowing seting conditions that posts should be in some category(s), publish in which month, having some tag(s) and other conditions. Mutiple conditions are allowed and connected by AND Boolean operation.

Goto "Installation" tab to see how to install and use this plugin. Goto "Screenshots" tab to see what enhanced search form likes.

== Changelog ==
= 0.2 =
* 2009.09.18 Bugs fix

= 0.1 =
* 2009.07.12 first release.

== Installation ==

1. Upload this plugin to your Wordpress plugin directory( generally wp-content/plugins/ ).
2. Activate it in admin area.
3. Your theme should have a hardcoded search form or you should add a "Search" widget to sidebar to allow visitors searching.
4. Check whether or not there is a "searchform.php" file in your current theme directory, if not, you don't need do anything; If yes, edit this "searchform.php" following the below instructions:

Your theme's "searchform.php" file may looks like below, with some other codes:

<code>
....
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>">
	<input type="text" id="s" name="s" value="<?php the_search_query(); ?>"  />
	<input type="submit" id="searchsubmit" value="Search" />
</form>
...
</code>

add the <code><?php if(function_exists('esf_add_form_field')) esf_add_form_field(); ?></code> code to proper place inside <code><form></code> element, in most cases you can put it just after <code><input type="submit" value="Search" /></code> button and before <code></form></code> close tag.


That's all. You may want to add css styles to make search form nicer.

== Screenshots ==

1. Search Form, the "Advanced" button is added by this plugin
2. When clicking "Advanced", visitors can set more search conditions...

== Frequently Asked Questions ==

= Known problems =
It's tested that some feature(s) of "search everything" plugin is not compatible with this plugin, which will cause this plugin's "search in month" feature not working, the problem may be because of the unmatched quote in SQL sentence processed by "search everything" and this plugin. Currently no way to fix it as further troubleshoting is difficulty.