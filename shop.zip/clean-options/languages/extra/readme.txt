This folder contains an additional Serbian Translation in Latinica.
The cleanoptions-sr_RS.po and cleanoptions-sr_RS.mo files in this plugin's languages folder are Cyrillic.
If you are not using a Cyrillic to Latinica conversion plugin and want to have the Clean Options plugin's pages in Latinica you can replace the Cyrillic translation with Latinica by:

1: Renaming the primary Serbian translation files located in this plugin's languages folder to something like cleanoptions-sr_RS@Cyrl.po and cleanoptions-sr_RS@Cyrl.mo
2: moving those files to this folder
3: copying or moving these files to this plugin's languages folder
