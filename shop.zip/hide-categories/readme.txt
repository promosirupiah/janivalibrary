=== Hide Categories ===
Author: Eduardo Chiaro
Contributors: theDI
Tags: hide categories, category, hide
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: trunk

Hide one or more categories when you use the_category tag. No exclude post, but only hide a category name in template view.

== Description ==
Hide one or more categories when you use the_category tag. No exclude post, but only hide a category name in template view.
Example?
You use a category called "featured" in your template but you don't want it see? Use Hide Categories

Thanks to <a href="http://www.infocube.it" title="sviluppo software">infocube</a> for the plugin's idea

== Frequently Asked Questions ==

== Screenshots == 
1. administration
2. in action

== Installation ==
* install plugin
* go to Hide Categories configuration
* choose a categories to exclude

== Changelog ==

= 1.0.1 =
* bugfix

= 1.0.0 =
* first release