<?php
/*************************************************************************

Plugin Name:  Hide Categories
Plugin URI:	  http://www.thedeveloperinside.com/resources/hide-categories/
Description:  Hide one o more categories when you use the_category tag. No exclude post, but only hide a category name in template view.
Version:      1.0.1
Author:       Eduardo Chiaro
Author URI:   http://www.eduardochiaro.it/

**************************************************************************/


require_once('hide-categories.admin.php');

function HideCategories(){
	add_filter('the_category','hide_categories_filter',10,2);
}
	
function hide_categories_filter($thelist, $separator=' ', $parents='') {

	$options = get_option('HideCategories');
	$exclude = $options['excludeCategories'];
	
	if(!is_array($exclude)){
		$exclude=array($options['excludeCategories']);
	}
	
	foreach($exclude as $ex){
		$newext=@explode(',',get_category_children($ex,","));
		foreach($newext as $n){
			$exclude[]=$n;
		}
	}
	
	if(!is_admin()){
		$categories=get_the_category();
		foreach($categories as $key => $category){
			if(in_array($category -> term_id,$exclude)){
				unset($categories[$key]);
			}
		}
		$thelist = '';
		if ( '' == $separator ) {
			$thelist .= '<ul class="post-categories">';
			foreach ( $categories as $category ) {
				$thelist .= "\n\t<li>";
				switch ( strtolower( $parents ) ) {
					case 'multiple':
						if ( $category->parent )
							$thelist .= get_category_parents( $category->parent, true, $separator );
						$thelist .= '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . $rel . '>' . $category->name.'</a></li>';
						break;
					case 'single':
						$thelist .= '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . $rel . '>';
						if ( $category->parent )
							$thelist .= get_category_parents( $category->parent, false, $separator );
						$thelist .= $category->name.'</a></li>';
						break;
					case '':
					default:
						$thelist .= '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . $rel . '>' . $category->cat_name.'</a></li>';
				}
			}
			$thelist .= '</ul>';
		} else {
			$i = 0;
			foreach ( $categories as $category ) {
				if ( 0 < $i )
					$thelist .= $separator . ' ';
				switch ( strtolower( $parents ) ) {
					case 'multiple':
						if ( $category->parent )
							$thelist .= get_category_parents( $category->parent, true, $separator );
						$thelist .= '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . $rel . '>' . $category->cat_name.'</a>';
						break;
					case 'single':
						$thelist .= '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . $rel . '>';
						if ( $category->parent )
							$thelist .= get_category_parents( $category->parent, false, $separator );
						$thelist .= "$category->cat_name</a>";
						break;
					case '':
					default:
						$thelist .= '<a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . $rel . '>' . $category->name.'</a>';
				}
				++$i;
			}
		}

		return $thelist;
	}else{
		return $thelist;
	}
	
	
}

function HideCategories_admin_menu() {
	if ( function_exists('add_submenu_page') ){
		add_submenu_page('plugins.php', __('Hide Categories Configuration'), __('Hide Categories Configuration'), 10, 'HideCategories-config', 'HideCategories_config');
	}

}

function HideCategories_plugin_actions( $links, $file ){
	$this_plugin = plugin_basename(__FILE__);
	
	if ( $file == $this_plugin ){
		$settings_link = '<a href="plugins.php?page=HideCategories-config">' . __('Settings') . '</a>';
		array_unshift( $links, $settings_link );
	}
	return $links;
}


add_action('plugin_action_links','HideCategories_plugin_actions',10, 2);
add_action('admin_menu', 'HideCategories_admin_menu');


add_action( 'init', 'HideCategories' );
?>