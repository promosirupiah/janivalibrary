<?php
namespace madxartwork\App\Modules\SiteEditor;

use madxartwork\Core\Base\Module as BaseModule;
use madxartwork\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Site Editor Module
 *
 * Responsible for initializing madxartwork App functionality
 */
class Module extends BaseModule {
	/**
	 * Get name.
	 *
	 * @access public
	 *
	 * @return string
	 */
	public function get_name() {
		return 'site-editor';
	}

	public function add_menu_in_admin_bar( $admin_bar_config ) {
		$admin_bar_config['madxartwork_edit_page']['children'][] = [
			'id' => 'madxartwork_app_site_editor',
			'title' => esc_html__( 'Theme Builder', 'madxartwork' ),
			'sub_title' => esc_html__( 'Site', 'madxartwork' ),
			'href' => Plugin::$instance->app->get_settings( 'menu_url' ),
			'class' => 'madxartwork-app-link',
			'parent_class' => 'madxartwork-second-section',
		];

		return $admin_bar_config;
	}

	public function __construct() {
		add_filter( 'madxartwork/frontend/admin_bar/settings', [ $this, 'add_menu_in_admin_bar' ] ); // After kit (Site settings)
	}
}
