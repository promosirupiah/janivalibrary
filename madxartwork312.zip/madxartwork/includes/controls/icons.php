<?php
namespace madxartwork;

use madxartwork\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * madxartwork Icons control.
 *
 * A base control for creating a Icons chooser control.
 * Used to select an Icon.
 *
 * Usage: @see https://developers.madxartwork.com/madxartwork-controls/icons-control
 *
 * @since 2.6.0
 */
class Control_Icons extends Control_Base_Multiple {

	/**
	 * Get media control type.
	 *
	 * Retrieve the control type, in this case `media`.
	 *
	 * @access public
	 * @since 2.6.0
	 * @return string Control type.
	 */
	public function get_type() {
		return 'icons';
	}

	/**
	 * Get Icons control default values.
	 *
	 * Retrieve the default value of the Icons control. Used to return the default
	 * values while initializing the Icons control.
	 *
	 * @access public
	 * @since 2.6.0
	 * @return array Control default value.
	 */
	public function get_default_value() {
		return [
			'value'   => '',
			'library' => '',
		];
	}

	/**
	 * Render Icons control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @since 2.6.0
	 * @access public
	 */
	public function content_template() {
		?>
		<# if ( 'inline' === data.skin ) { #>
			<?php $this->render_inline_skin(); ?>
		<# } else { #>
			<?php $this->render_media_skin(); ?>
		<# } #>
		<?php
	}

	public function render_media_skin() {
		?>
		<div class="madxartwork-control-field madxartwork-control-media">
			<label class="madxartwork-control-title">{{{ data.label }}}</label>
			<div class="madxartwork-control-input-wrapper">
				<div class="madxartwork-control-media__content madxartwork-control-tag-area madxartwork-control-preview-area">
					<div class="madxartwork-control-media-upload-button madxartwork-control-media__content__upload-button">
						<i class="eicon-plus-circle" aria-hidden="true"></i>
					</div>
					<div class="madxartwork-control-media-area">
						<div class="madxartwork-control-media__remove madxartwork-control-media__content__remove" title="<?php echo esc_html__( 'Remove', 'madxartwork' ); ?>">
							<i class="eicon-trash-o"></i>
						</div>
						<div class="madxartwork-control-media__preview"></div>
					</div>
					<div class="madxartwork-control-media__tools madxartwork-control-dynamic-switcher-wrapper">
						<div class="madxartwork-control-icon-picker madxartwork-control-media__tool"><?php echo esc_html__( 'Icon Library', 'madxartwork' ); ?></div>
						<div class="madxartwork-control-svg-uploader madxartwork-control-media__tool"><?php echo esc_html__( 'Upload SVG', 'madxartwork' ); ?></div>
					</div>
				</div>
			</div>
			<# if ( data.description ) { #>
			<div class="madxartwork-control-field-description">{{{ data.description }}}</div>
			<# } #>
			<input type="hidden" data-setting="{{ data.name }}"/>
		</div>
		<?php
	}

	public function render_inline_skin() {
		?>
		<#
			const defaultSkinSettings = {
				none: {
					label: '<?php echo esc_html__( 'None', 'madxartwork' ); ?>',
					icon: 'eicon-ban',
				},
				svg: {
					label: '<?php echo esc_html__( 'Upload SVG', 'madxartwork' ); ?>',
					icon: 'eicon-upload',
				},
				icon: {
					label: '<?php echo esc_html__( 'Icon Library', 'madxartwork' ); ?>',
					icon: 'eicon-circle',
				}
			};

			const skinSettings = data.skin_settings.inline;

			const get = ( type, key ) => {
				if ( skinSettings[ type ] ) {
					return skinSettings[ type ]?.[ key ] || defaultSkinSettings[ type ][ key ];
				}

				return defaultSkinSettings[ type ][ key ];
			}
		#>
		<div class="madxartwork-control-field madxartwork-control-inline-icon">
			<label class="madxartwork-control-title">{{{ data.label }}}</label>
			<div class="madxartwork-control-input-wrapper">
				<div class="madxartwork-choices">
					<input id="<?php $this->print_control_uid(); ?>-none" type="radio" value="none">
					<label class="madxartwork-choices-label madxartwork-control-unit-1 tooltip-target madxartwork-control-icons--inline__none" for="<?php $this->print_control_uid(); ?>-none" data-tooltip="{{ get( 'none', 'label' ) }}" title="{{ get( 'none', 'label' ) }}">
						<i class="{{ get( 'none', 'icon' ) }}" aria-hidden="true"></i>
						<span class="madxartwork-screen-only">{{ get( 'none', 'label' ) }}</span>
					</label>
					<# if ( ! data.exclude_inline_options.includes( 'svg' ) ) { #>
						<input id="<?php $this->print_control_uid(); ?>-svg" type="radio" value="svg">
						<label class="madxartwork-choices-label madxartwork-control-unit-1 tooltip-target madxartwork-control-icons--inline__svg" for="<?php $this->print_control_uid(); ?>-svg" data-tooltip="{{ get( 'svg', 'label' ) }}" title="{{ get( 'svg', 'label' ) }}">
							<i class="{{ get( 'svg', 'icon' ) }}" aria-hidden="true"></i>
							<span class="madxartwork-screen-only">{{ get( 'svg', 'label' ) }}</span>
						</label>
					<# }
					if ( ! data.exclude_inline_options.includes( 'icon' ) ) { #>
						<input id="<?php $this->print_control_uid(); ?>-icon" type="radio" value="icon">
						<label class="madxartwork-choices-label madxartwork-control-unit-1 tooltip-target madxartwork-control-icons--inline__icon" for="<?php $this->print_control_uid(); ?>-icon" data-tooltip="{{ get( 'icon', 'label' ) }}" title="{{ get( 'icon', 'label' ) }}">
							<span class="madxartwork-control-icons--inline__displayed-icon">
								<i class="{{ get( 'icon', 'icon' ) }}" aria-hidden="true"></i>
							</span>
							<span class="madxartwork-screen-only">{{ get( 'icon', 'label' ) }}</span>
						</label>
					<# } #>
				</div>
			</div>
		</div>

		<# if ( data.description ) { #>
		<div class="madxartwork-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}

	/**
	 * Get Icons control default settings.
	 *
	 * Retrieve the default settings of the Icons control. Used to return the default
	 * settings while initializing the Icons control.
	 *
	 * @since 2.6.0
	 * @access protected
	 *
	 * @return array Control default settings.
	 */
	protected function get_default_settings() {
		return [
			'label_block' => true,
			'dynamic' => [
				'categories' => [ TagsModule::IMAGE_CATEGORY ],
				'returnType' => 'object',
			],
			'search_bar' => true,
			'recommended' => false,
			'skin' => 'media',
			'exclude_inline_options' => [],
			'disable_initial_active_state' => false,
			'skin_settings' => [
				'inline' => [
					'none' => [
						'label' => esc_html__( 'None', 'madxartwork' ),
						'icon' => 'eicon-ban',
					],
					'svg' => [
						'label' => esc_html__( 'Upload SVG', 'madxartwork' ),
						'icon' => 'eicon-upload',
					],
					'icon' => [
						'label' => esc_html__( 'Icon Library', 'madxartwork' ),
						'icon' => 'eicon-circle',
					],
				],
			],
		];
	}

	/**
	 * Support SVG Import
	 *
	 * @deprecated 3.5.0
	 *
	 * @param $mimes
	 * @return mixed
	 */
	public function support_svg_import( $mimes ) {
		Plugin::$instance->modules_manager->get_modules( 'dev-tools' )->deprecation->deprecated_function( __METHOD__, '3.5.0' );

		$mimes['svg'] = 'image/svg+xml';
		return $mimes;
	}

	public function on_import( $settings ) {
		if ( empty( $settings['library'] ) || 'svg' !== $settings['library'] || empty( $settings['value']['url'] ) ) {
			return $settings;
		}

		$imported = Plugin::$instance->templates_manager->get_import_images_instance()->import( $settings['value'] );

		if ( ! $imported ) {
			$settings['value'] = '';
			$settings['library'] = '';
		} else {
			$settings['value'] = $imported;
		}
		return $settings;
	}
}
