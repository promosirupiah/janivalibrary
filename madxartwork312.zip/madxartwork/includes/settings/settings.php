<?php
namespace madxartwork;

use madxartwork\Core\Admin\Menu\Admin_Menu_Manager;
use madxartwork\Includes\Settings\AdminMenuItems\Admin_Menu_Item;
use madxartwork\Includes\Settings\AdminMenuItems\Get_Help_Menu_Item;
use madxartwork\Includes\Settings\AdminMenuItems\Getting_Started_Menu_Item;
use madxartwork\Modules\Promotions\Module as Promotions_Module;
use madxartwork\TemplateLibrary\Source_Local;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * madxartwork "Settings" page in WordPress Dashboard.
 *
 * madxartwork settings page handler class responsible for creating and displaying
 * madxartwork "Settings" page in WordPress dashboard.
 *
 * @since 1.0.0
 */
class Settings extends Settings_Page {

	/**
	 * Settings page ID for madxartwork settings.
	 */
	const PAGE_ID = 'madxartwork';

	/**
	 * Upgrade menu priority.
	 */
	const MENU_PRIORITY_GO_PRO = 502;

	/**
	 * Settings page field for update time.
	 */
	const UPDATE_TIME_FIELD = '_madxartwork_settings_update_time';

	/**
	 * Settings page general tab slug.
	 */
	const TAB_GENERAL = 'general';

	/**
	 * Settings page style tab slug.
	 */
	const TAB_STYLE = 'style';

	/**
	 * Settings page integrations tab slug.
	 */
	const TAB_INTEGRATIONS = 'integrations';

	/**
	 * Settings page advanced tab slug.
	 */
	const TAB_ADVANCED = 'advanced';

	const ADMIN_MENU_PRIORITY = 10;

	/**
	 * Register admin menu.
	 *
	 * Add new madxartwork Settings admin menu.
	 *
	 * Fired by `admin_menu` action.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function register_admin_menu() {
		global $menu;

		$menu[] = [ '', 'read', 'separator-madxartwork', '', 'wp-menu-separator madxartwork' ]; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		add_menu_page(
			esc_html__( 'madxartwork', 'madxartwork' ),
			esc_html__( 'madxartwork', 'madxartwork' ),
			'manage_options',
			self::PAGE_ID,
			[ $this, 'display_settings_page' ],
			'',
			'58.5'
		);
	}

	/**
	 * Reorder the madxartwork menu items in admin.
	 * Based on WC.
	 *
	 * @since 2.4.0
	 *
	 * @param array $menu_order Menu order.
	 * @return array
	 */
	public function menu_order( $menu_order ) {
		// Initialize our custom order array.
		$madxartwork_menu_order = [];

		// Get the index of our custom separator.
		$madxartwork_separator = array_search( 'separator-madxartwork', $menu_order, true );

		// Get index of library menu.
		$madxartwork_library = array_search( Source_Local::ADMIN_MENU_SLUG, $menu_order, true );

		// Loop through menu order and do some rearranging.
		foreach ( $menu_order as $index => $item ) {
			if ( 'madxartwork' === $item ) {
				$madxartwork_menu_order[] = 'separator-madxartwork';
				$madxartwork_menu_order[] = $item;
				$madxartwork_menu_order[] = Source_Local::ADMIN_MENU_SLUG;

				unset( $menu_order[ $madxartwork_separator ] );
				unset( $menu_order[ $madxartwork_library ] );
			} elseif ( ! in_array( $item, [ 'separator-madxartwork' ], true ) ) {
				$madxartwork_menu_order[] = $item;
			}
		}

		// Return order.
		return $madxartwork_menu_order;
	}

	/**
	 * Register madxartwork knowledge base sub-menu.
	 *
	 * Add new madxartwork knowledge base sub-menu under the main madxartwork menu.
	 *
	 * Fired by `admin_menu` action.
	 *
	 * @since 2.0.3
	 * @access private
	 */
	private function register_knowledge_base_menu( Admin_Menu_Manager $admin_menu ) {
		$admin_menu->register( 'madxartwork-getting-started', new Getting_Started_Menu_Item() );
		$admin_menu->register( 'go_knowledge_base_site', new Get_Help_Menu_Item() );
	}

	/**
	 * Go madxartwork Pro.
	 *
	 * Redirect the madxartwork Pro page the clicking the madxartwork Pro menu link.
	 *
	 * Fired by `admin_init` action.
	 *
	 * @since 2.0.3
	 * @access public
	 */
	public function handle_external_redirects() {
		if ( empty( $_GET['page'] ) ) {
			return;
		}

		if ( 'go_knowledge_base_site' === $_GET['page'] ) {
			wp_redirect( Get_Help_Menu_Item::URL );
			die;
		}
	}

	/**
	 * On admin init.
	 *
	 * Preform actions on WordPress admin initialization.
	 *
	 * Fired by `admin_init` action.
	 *
	 * @since 2.0.0
	 * @access public
	 */
	public function on_admin_init() {
		$this->handle_external_redirects();

		$this->maybe_remove_all_admin_notices();
	}

	/**
	 * Change "Settings" menu name.
	 *
	 * Update the name of the Settings admin menu from "madxartwork" to "Settings".
	 *
	 * Fired by `admin_menu` action.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_menu_change_name() {
		Utils::change_submenu_first_item_label( 'madxartwork', esc_html__( 'Settings', 'madxartwork' ) );
	}

	/**
	 * Update CSS print method.
	 *
	 * Clear post CSS cache.
	 *
	 * Fired by `add_option_madxartwork_css_print_method` and
	 * `update_option_madxartwork_css_print_method` actions.
	 *
	 * @since 1.7.5
	 * @access public
	 * @deprecated 3.0.0
	 */
	public function update_css_print_method() {
		Plugin::$instance->files_manager->clear_cache();
	}

	/**
	 * Create tabs.
	 *
	 * Return the settings page tabs, sections and fields.
	 *
	 * @since 1.5.0
	 * @access protected
	 *
	 * @return array An array with the settings page tabs, sections and fields.
	 */
	protected function create_tabs() {
		$validations_class_name = __NAMESPACE__ . '\Settings_Validations';

		return [
			self::TAB_GENERAL => [
				'label' => esc_html__( 'General', 'madxartwork' ),
				'sections' => [
					'general' => [
						'fields' => [
							self::UPDATE_TIME_FIELD => [
								'full_field_id' => self::UPDATE_TIME_FIELD,
								'field_args' => [
									'type' => 'hidden',
								],
								'setting_args' => [ $validations_class_name, 'current_time' ],
							],
							'cpt_support' => [
								'label' => esc_html__( 'Post Types', 'madxartwork' ),
								'field_args' => [
									'type' => 'checkbox_list_cpt',
									'std' => [ 'page', 'post' ],
									'exclude' => [ 'attachment', 'madxartwork_library' ],
								],
								'setting_args' => [ $validations_class_name, 'checkbox_list' ],
							],
							'disable_color_schemes' => [
								'label' => esc_html__( 'Disable Default Colors', 'madxartwork' ),
								'field_args' => [
									'type' => 'checkbox',
									'value' => 'yes',
									'sub_desc' => esc_html__( 'Checking this box will disable madxartwork\'s Default Colors, and make madxartwork inherit the colors from your theme.', 'madxartwork' ),
								],
							],
							'disable_typography_schemes' => [
								'label' => esc_html__( 'Disable Default Fonts', 'madxartwork' ),
								'field_args' => [
									'type' => 'checkbox',
									'value' => 'yes',
									'sub_desc' => esc_html__( 'Checking this box will disable madxartwork\'s Default Fonts, and make madxartwork inherit the fonts from your theme.', 'madxartwork' ),
								],
							],
						],
					],
					'usage' => [
						'label' => esc_html__( 'Improve madxartwork', 'madxartwork' ),
						'fields' => $this->get_usage_fields(),
					],
				],
			],
			self::TAB_INTEGRATIONS => [
				'label' => esc_html__( 'Integrations', 'madxartwork' ),
				'sections' => [
					'google_maps' => [
						'label' => esc_html__( 'Google Maps Embed API', 'madxartwork' ),
						'callback' => function() {
							printf(
								/* translators: 1: Link open tag, 2: Link close tag */
								esc_html__( 'Google Maps Embed API is a free service by Google that allows embedding Google Maps in your site. For more details, visit Google Maps\' %1$sUsing API Keys%2$s page.', 'madxartwork' ),
								'<a target="_blank" href="https://developers.google.com/maps/documentation/embed/get-api-key">',
								'</a>'
							);
						},
						'fields' => [
							'google_maps_api_key' => [
								'label' => esc_html__( 'API Key', 'madxartwork' ),
								'field_args' => [
									'class' => 'madxartwork_google_maps_api_key',
									'type' => 'text',
								],
							],
						],
					],
				],
			],
			self::TAB_ADVANCED => [
				'label' => esc_html__( 'Advanced', 'madxartwork' ),
				'sections' => [
					'advanced' => [
						'fields' => [
							'css_print_method' => [
								'label' => esc_html__( 'CSS Print Method', 'madxartwork' ),
								'field_args' => [
									'class' => 'madxartwork_css_print_method',
									'type' => 'select',
									'std' => 'external',
									'options' => [
										'external' => esc_html__( 'External File', 'madxartwork' ),
										'internal' => esc_html__( 'Internal Embedding', 'madxartwork' ),
									],
									'desc' => '<div class="madxartwork-css-print-method-description" data-value="external" style="display: none">' . esc_html__( 'Use external CSS files for all generated stylesheets. Choose this setting for better performance (recommended).', 'madxartwork' ) . '</div><div class="madxartwork-css-print-method-description" data-value="internal" style="display: none">' . esc_html__( 'Use internal CSS that is embedded in the head of the page. For troubleshooting server configuration conflicts and managing development environments.', 'madxartwork' ) . '</div>',
								],
							],
							'editor_break_lines' => [
								'label' => esc_html__( 'Switch Editor Loader Method', 'madxartwork' ),
								'field_args' => [
									'type' => 'select',
									'std' => '',
									'options' => [
										'' => esc_html__( 'Disable', 'madxartwork' ),
										'1' => esc_html__( 'Enable', 'madxartwork' ),
									],
									'desc' => esc_html__( 'For troubleshooting server configuration conflicts.', 'madxartwork' ),
								],
							],
							'unfiltered_files_upload' => [
								'label' => esc_html__( 'Enable Unfiltered File Uploads', 'madxartwork' ),
								'field_args' => [
									'type' => 'select',
									'std' => '',
									'options' => [
										'' => esc_html__( 'Disable', 'madxartwork' ),
										'1' => esc_html__( 'Enable', 'madxartwork' ),
									],
									'desc' => esc_html__( 'Please note! Allowing uploads of any files (SVG & JSON included) is a potential security risk.', 'madxartwork' ) . '<br>' . esc_html__( 'madxartwork will try to sanitize the unfiltered files, removing potential malicious code and scripts.', 'madxartwork' ) . '<br>' . esc_html__( 'We recommend you only enable this feature if you understand the security risks involved.', 'madxartwork' ),
								],
							],
							'google_font' => [
								'label' => esc_html__( 'Google Fonts', 'madxartwork' ),
								'field_args' => [
									'type' => 'select',
									'std' => '1',
									'options' => [
										'1' => esc_html__( 'Enable', 'madxartwork' ),
										'0' => esc_html__( 'Disable', 'madxartwork' ),
									],
									'desc' => sprintf(
										esc_html__( 'Disable this option if you want to prevent Google Fonts from being loaded. This setting is recommended when loading fonts from a different source (plugin, theme or %1$scustom fonts%2$s).', 'madxartwork' ),
										'<a href="' . admin_url( 'admin.php?page=madxartwork_custom_fonts' ) . '">',
										'</a>'
									),
								],
							],
							'font_display' => [
								'label' => esc_html__( 'Google Fonts Load', 'madxartwork' ),
								'field_args' => [
									'type' => 'select',
									'std' => 'auto',
									'options' => [
										'auto' => esc_html__( 'Default', 'madxartwork' ),
										'block' => esc_html__( 'Blocking', 'madxartwork' ),
										'swap' => esc_html__( 'Swap', 'madxartwork' ),
										'fallback' => esc_html__( 'Fallback', 'madxartwork' ),
										'optional' => esc_html__( 'Optional', 'madxartwork' ),
									],
									'desc' => esc_html__( 'Font-display property defines how font files are loaded and displayed by the browser.', 'madxartwork' ) . '<br>' . esc_html__( 'Set the way Google Fonts are being loaded by selecting the font-display property (Default: Auto).', 'madxartwork' ),
								],
							],
						],
					],
				],
			],
		];
	}

	/**
	 * Get settings page title.
	 *
	 * Retrieve the title for the settings page.
	 *
	 * @since 1.5.0
	 * @access protected
	 *
	 * @return string Settings page title.
	 */
	protected function get_page_title() {
		if ( Plugin::$instance->experiments->is_feature_active( 'admin_menu_rearrangement' ) ) {
			return esc_html__( 'Settings', 'madxartwork' );
		}

		return esc_html__( 'madxartwork', 'madxartwork' );
	}

	/**
	 * @since 2.2.0
	 * @access private
	 */
	private function maybe_remove_all_admin_notices() {
		$madxartwork_pages = [
			'madxartwork-getting-started',
			'madxartwork_custom_fonts',
			'madxartwork_custom_icons',
			'madxartwork-license',
			'madxartwork_custom_custom_code',
			'popup_templates',
		];

		if ( empty( $_GET['page'] ) || ! in_array( $_GET['page'], $madxartwork_pages, true ) ) {
			return;
		}

		remove_all_actions( 'admin_notices' );
	}

	public function add_generator_tag_settings( $settings ) {
		$css_print_method = get_option( 'madxartwork_css_print_method', 'external' );
		$settings[] = 'css_print_method-' . $css_print_method;

		$google_font = Fonts::is_google_fonts_enabled() ? 'enabled' : 'disabled';
		$settings[] = 'google_font-' . $google_font;

		$font_display = Fonts::get_font_display_setting();
		$settings[] = 'font_display-' . $font_display;

		return $settings;
	}

	/**
	 * Settings page constructor.
	 *
	 * Initializing madxartwork "Settings" page.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		parent::__construct();

		add_action( 'admin_init', [ $this, 'on_admin_init' ] );
		add_filter( 'madxartwork/generator_tag/settings', [ $this, 'add_generator_tag_settings' ] );

		if ( ! Plugin::$instance->experiments->is_feature_active( 'admin_menu_rearrangement' ) ) {
			add_action( 'admin_menu', [ $this, 'register_admin_menu' ], 20 );

			add_action( 'madxartwork/admin/menu/register', function ( Admin_Menu_Manager $admin_menu ) {
				$this->register_knowledge_base_menu( $admin_menu );
			}, Promotions_Module::ADMIN_MENU_PRIORITY - 1 );

			add_action( 'admin_menu', [ $this, 'admin_menu_change_name' ], 200 );

			add_filter( 'custom_menu_order', '__return_true' );
			add_filter( 'menu_order', [ $this, 'menu_order' ] );
		}

		$clear_cache_callback = [ Plugin::$instance->files_manager, 'clear_cache' ];

		// Clear CSS Meta after change css related methods.
		$css_settings = [
			'madxartwork_disable_color_schemes',
			'madxartwork_disable_typography_schemes',
			'madxartwork_css_print_method',
		];

		foreach ( $css_settings as $option_name ) {
			add_action( "add_option_{$option_name}", $clear_cache_callback );
			add_action( "update_option_{$option_name}", $clear_cache_callback );
		}
	}
}
