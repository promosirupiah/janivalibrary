<?php
namespace madxartwork\TemplateLibrary\Forms;

use madxartwork\Controls_Manager;
use madxartwork\Controls_Stack;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class New_Template_Form extends Controls_Stack {

	public function get_name() {
		return 'add-template-form';
	}

	/**
	 * @throws \Exception
	 */
	public function render() {
		foreach ( $this->get_controls() as $control ) {
			switch ( $control['type'] ) {
				case Controls_Manager::SELECT:
					$this->render_select( $control );
					break;
				default:
					throw new \Exception( "'{$control['type']}' control type is not supported." );
			}
		}
	}

	private function render_select( $control_settings ) {
		$control_id = "madxartwork-new-template__form__{$control_settings['name']}";
		$wrapper_class = isset( $control_settings['wrapper_class'] ) ? $control_settings['wrapper_class'] : '';
		?>
		<div id="<?php echo esc_attr( $control_id ); ?>__wrapper" class="madxartwork-form-field <?php echo esc_attr( $wrapper_class ); ?>">
			<label for="<?php echo esc_html( $control_id ); ?>" class="madxartwork-form-field__label">
				<?php echo esc_html( $control_settings['label'] ); ?>
			</label>
			<div class="madxartwork-form-field__select__wrapper">
				<select id="<?php echo esc_html( $control_id ); ?>" class="madxartwork-form-field__select" name="meta[<?php echo esc_html( $control_settings['name'] ); ?>]">
					<?php
					foreach ( $control_settings['options'] as $key => $value ) {
						echo sprintf( '<option value="%1$s">%2$s</option>', esc_html( $key ), esc_html( $value ) );
					}
					?>
				</select>
			</div>
		</div>
		<?php
	}
}
