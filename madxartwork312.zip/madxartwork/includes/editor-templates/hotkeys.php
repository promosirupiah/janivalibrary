<?php
namespace madxartwork;

use madxartwork\Core\Editor\Editor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$is_editor_v2_active = Plugin::$instance->experiments->is_feature_active( Editor::EDITOR_V2_EXPERIMENT_NAME );
?>
<script type="text/template" id="tmpl-madxartwork-hotkeys">
	<# var ctrlLabel = environment.mac ? '&#8984;' : 'Ctrl'; #>
	<div id="madxartwork-hotkeys__content">
		<div id="madxartwork-hotkeys__actions" class="madxartwork-hotkeys__col">

			<div class="madxartwork-hotkeys__header">
				<h3><?php echo esc_html__( 'Actions', 'madxartwork' ); ?></h3>
			</div>
			<div class="madxartwork-hotkeys__list">
				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Undo', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>Z</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Redo', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>Shift</span>
						<span>Z</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Copy', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>C</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Paste', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>V</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Paste Style', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>Shift</span>
						<span>V</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Delete', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>Delete</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Duplicate', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>D</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Save', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>S</span>
					</div>
				</div>

			</div>
		</div>

		<div id="madxartwork-hotkeys__navigation" class="madxartwork-hotkeys__col">

			<div class="madxartwork-hotkeys__header">
				<h3><?php echo esc_html__( 'Go To', 'madxartwork' ); ?></h3>
			</div>
			<div class="madxartwork-hotkeys__list">
				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Finder', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>E</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Show / Hide Panel', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>P</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Responsive Mode', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>Shift</span>
						<span>M</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'History', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>Shift</span>
						<span>H</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php
						echo $is_editor_v2_active
							? esc_html__( 'Structure', 'madxartwork' )
							: esc_html__( 'Navigator', 'madxartwork' );
					?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>I</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Template Library', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>{{{ ctrlLabel }}}</span>
						<span>Shift</span>
						<span>L</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Keyboard Shortcuts', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>Shift</span>
						<span>?</span>
					</div>
				</div>

				<div class="madxartwork-hotkeys__item">
					<div class="madxartwork-hotkeys__item--label"><?php echo esc_html__( 'Quit', 'madxartwork' ); ?></div>
					<div class="madxartwork-hotkeys__item--shortcut">
						<span>Esc</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</script>
