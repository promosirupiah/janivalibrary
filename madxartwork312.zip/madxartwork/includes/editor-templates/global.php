<?php
namespace madxartwork;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<script type="text/template" id="tmpl-madxartwork-empty-preview">
	<div class="madxartwork-first-add">
		<div class="madxartwork-icon eicon-plus"></div>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-add-section">
	<div class="madxartwork-add-section-inner">
		<div class="madxartwork-add-section-close">
			<i class="eicon-close" aria-hidden="true"></i>
			<span class="madxartwork-screen-only"><?php echo esc_html__( 'Close', 'madxartwork' ); ?></span>
		</div>
		<div class="e-view madxartwork-add-new-section">
			<?php
				$experiments_manager = Plugin::$instance->experiments;
				$add_container_title = esc_html__( 'Add New Container', 'madxartwork' );
				$add_section_title = esc_html__( 'Add New Section', 'madxartwork' );

				$button_title = ( $experiments_manager->is_feature_active( 'container' ) ) ? $add_container_title : $add_section_title;
			?>
			<div class="madxartwork-add-section-area-button madxartwork-add-section-button" title="<?php echo esc_attr( $button_title ); ?>">
				<i class="eicon-plus"></i>
			</div>
			<# if ( 'loop-item' !== madxartwork.documents.getCurrent()?.config?.type || madxartworkCommon.config.experimentalFeatures[ 'container' ] ) { #>
			<div class="madxartwork-add-section-area-button madxartwork-add-template-button" title="<?php echo esc_attr__( 'Add Template', 'madxartwork' ); ?>">
				<i class="eicon-folder"></i>
			</div>
			<# } #>
			<div class="madxartwork-add-section-drag-title"><?php echo esc_html__( 'Drag widget here', 'madxartwork' ); ?></div>
		</div>
		<div class="e-view madxartwork-select-preset">
			<div class="madxartwork-select-preset-title"><?php echo esc_html__( 'Select your Structure', 'madxartwork' ); ?></div>
			<ul class="madxartwork-select-preset-list">
				<#
					const structures = [ 10, 20, 30, 40, 21, 22, 31, 32, 33, 50, 34, 60 ];

					structures.forEach( ( structure ) => {
						const preset = madxartwork.presetsFactory.getPresetByStructure( structure ); #>

						<li class="madxartwork-preset madxartwork-column madxartwork-col-16" data-structure="{{ structure }}">
							{{{ madxartwork.presetsFactory.getPresetSVG( preset.preset ).outerHTML }}}
						</li>
					<# } ); #>
			</ul>
		</div>
		<div class="e-view e-con-select-preset">
			<div class="e-con-select-preset__title"><?php echo esc_html__( 'Select your Structure', 'madxartwork' ); ?></div>
			<div class="e-con-select-preset__list">
				<#
					madxartwork.presetsFactory.getContainerPresets().forEach( ( preset ) => {
					#>
					<div class="e-con-preset" data-preset="{{ preset }}">
						{{{ madxartwork.presetsFactory.generateContainerPreset( preset ) }}}
					</div>
					<#
				} );
				#>
			</div>
		</div>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-tag-controls-stack-empty">
	<?php echo esc_html__( 'This tag has no settings.', 'madxartwork' ); ?>
</script>
