<?php
namespace madxartwork;

use madxartwork\Core\Editor\Editor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$document = Plugin::$instance->documents->get( Plugin::$instance->editor->get_post_id() );
$is_editor_v2_active = Plugin::$instance->experiments->is_feature_active( Editor::EDITOR_V2_EXPERIMENT_NAME );
?>
<script type="text/template" id="tmpl-madxartwork-panel">
	<div id="madxartwork-mode-switcher"></div>
	<div id="madxartwork-panel-state-loading">
		<i class="eicon-loading eicon-animation-spin"></i>
	</div>
	<header id="madxartwork-panel-header-wrapper"></header>
	<main id="madxartwork-panel-content-wrapper"></main>
	<footer id="madxartwork-panel-footer">
		<div class="madxartwork-panel-container"></div>
	</footer>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-menu">
	<div id="madxartwork-panel-page-menu-content"></div>
	<# if ( madxartwork.config.document.panel.needHelpUrl ) { #>
	<div id="madxartwork-panel__editor__help">
		<a id="madxartwork-panel__editor__help__link" href="{{{ madxartwork.config.document.panel.needHelpUrl }}}" target="_blank">
			<?php echo esc_html__( 'Need Help', 'madxartwork' ); ?>
			<i class="eicon-help-o"></i>
		</a>
	</div>
	<# } #>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-menu-group">
	<div class="madxartwork-panel-menu-group-title">{{{ title }}}</div>
	<div class="madxartwork-panel-menu-items"></div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-menu-item">
	<div class="madxartwork-panel-menu-item-icon">
		<i class="{{ icon }}"></i>
	</div>
	<# if ( 'undefined' === typeof type || 'link' !== type ) { #>
		<div class="madxartwork-panel-menu-item-title">{{{ title }}}</div>
	<# } else {
		let target = ( 'undefined' !== typeof newTab && newTab ) ? '_blank' : '_self';
	#>
		<a href="{{ link }}" target="{{ target }}"><div class="madxartwork-panel-menu-item-title">{{{ title }}}</div></a>
	<# } #>
</script>

<script type="text/template" id="tmpl-madxartwork-exit-dialog">
	<div><?php echo esc_html__( 'Now you can choose where you want to go on the site from the following options', 'madxartwork' ); ?></div>
	<div>
		<!-- translators: 1: Opening HTML <a> tag, 2: closing HTML <a> tag. -->
		<?php echo sprintf(
			esc_html__( 'Any time you can change the settings in %1$sUser Preferences%2$s', 'madxartwork' ),
			'<a id="user-preferences">',
			'</a>'
		); ?>
	</div>
	<select id="exit-to-preferences"></select> <!--  Adding options by JS  -->
</script>

<script type="text/template" id="tmpl-madxartwork-panel-header">
	<div id="madxartwork-panel-header-menu-button" class="madxartwork-header-button">
		<i class="madxartwork-icon eicon-menu-bar tooltip-target" aria-hidden="true" data-tooltip="<?php esc_attr_e( 'Menu', 'madxartwork' ); ?>"></i>
		<span class="madxartwork-screen-only"><?php echo esc_html__( 'Menu', 'madxartwork' ); ?></span>
	</div>
	<div id="madxartwork-panel-header-title"></div>
	<div id="madxartwork-panel-header-add-button" class="madxartwork-header-button">
		<i class="madxartwork-icon eicon-apps tooltip-target" aria-hidden="true" data-tooltip="<?php esc_attr_e( 'Widgets Panel', 'madxartwork' ); ?>"></i>
		<span class="madxartwork-screen-only"><?php echo esc_html__( 'Widgets Panel', 'madxartwork' ); ?></span>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-footer-content">
	<div id="madxartwork-panel-footer-settings" class="madxartwork-panel-footer-tool madxartwork-leave-open tooltip-target" data-tooltip="<?php esc_attr_e( 'Settings', 'madxartwork' ); ?>">
		<i class="eicon-cog" aria-hidden="true"></i>
		<span class="madxartwork-screen-only"><?php printf( esc_html__( '%s Settings', 'madxartwork' ), esc_html( $document::get_title() ) ); ?></span>
	</div>
	<div id="madxartwork-panel-footer-navigator" class="madxartwork-panel-footer-tool tooltip-target" data-tooltip="<?php
		echo $is_editor_v2_active
			? esc_attr__( 'Structure', 'madxartwork' )
			: esc_attr__( 'Navigator', 'madxartwork' );
	?>">
		<i class="eicon-navigator" aria-hidden="true"></i>
		<span class="madxartwork-screen-only"><?php
			echo $is_editor_v2_active
				? esc_html__( 'Structure', 'madxartwork' )
				: esc_html__( 'Navigator', 'madxartwork' );
		?></span>
	</div>
	<div id="madxartwork-panel-footer-history" class="madxartwork-panel-footer-tool madxartwork-leave-open tooltip-target" data-tooltip="<?php esc_attr_e( 'History', 'madxartwork' ); ?>">
		<i class="eicon-history" aria-hidden="true"></i>
		<span class="madxartwork-screen-only"><?php echo esc_html__( 'History', 'madxartwork' ); ?></span>
	</div>
	<div id="madxartwork-panel-footer-responsive" class="madxartwork-panel-footer-tool madxartwork-toggle-state tooltip-target" data-tooltip="<?php esc_attr_e( 'Responsive Mode', 'madxartwork' ); ?>">
		<i class="eicon-device-responsive" aria-hidden="true"></i>
		<span class="madxartwork-screen-only">
			<?php echo esc_html__( 'Responsive Mode', 'madxartwork' ); ?>
		</span>
	</div>
	<div id="madxartwork-panel-footer-saver-preview" class="madxartwork-panel-footer-tool tooltip-target" data-tooltip="<?php esc_attr_e( 'Preview Changes', 'madxartwork' ); ?>">
		<span id="madxartwork-panel-footer-saver-preview-label">
			<i class="eicon-preview-medium" aria-hidden="true"></i>
			<span class="madxartwork-screen-only"><?php echo esc_html__( 'Preview Changes', 'madxartwork' ); ?></span>
		</span>
	</div>
	<div id="madxartwork-panel-footer-saver-publish" class="madxartwork-panel-footer-tool">
		<button id="madxartwork-panel-saver-button-publish" class="madxartwork-button e-primary madxartwork-disabled">
			<span class="madxartwork-state-icon">
				<i class="eicon-loading eicon-animation-spin" aria-hidden="true"></i>
			</span>
			<span id="madxartwork-panel-saver-button-publish-label">
				<?php echo esc_html__( 'Publish', 'madxartwork' ); ?>
			</span>
		</button>
	</div>
	<div id="madxartwork-panel-footer-saver-options" class="madxartwork-panel-footer-tool madxartwork-toggle-state">
		<button id="madxartwork-panel-saver-button-save-options" class="madxartwork-button e-primary tooltip-target madxartwork-disabled" data-tooltip="<?php esc_attr_e( 'Save Options', 'madxartwork' ); ?>" data-tooltip-offset="7">
			<i class="eicon-chevron-right" aria-hidden="true"></i>
			<span class="madxartwork-screen-only"><?php echo esc_html__( 'Save Options', 'madxartwork' ); ?></span>
		</button>
		<div class="madxartwork-panel-footer-sub-menu-wrapper">
			<p class="madxartwork-last-edited-wrapper">
				<span class="madxartwork-state-icon">
					<i class="eicon-loading eicon-animation-spin" aria-hidden="true"></i>
				</span>
				<span class="madxartwork-last-edited">
				</span>
			</p>
			<div class="madxartwork-panel-footer-sub-menu">
				<div id="madxartwork-panel-footer-sub-menu-item-save-draft" class="madxartwork-panel-footer-sub-menu-item madxartwork-disabled">
					<i class="madxartwork-icon eicon-save" aria-hidden="true"></i>
					<span class="madxartwork-title"><?php echo esc_html__( 'Save Draft', 'madxartwork' ); ?></span>
				</div>
				<div id="madxartwork-panel-footer-sub-menu-item-save-template" class="madxartwork-panel-footer-sub-menu-item">
					<i class="madxartwork-icon eicon-folder" aria-hidden="true"></i>
					<span class="madxartwork-title"><?php echo esc_html__( 'Save as Template', 'madxartwork' ); ?></span>
				</div>
			</div>
		</div>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-mode-switcher-content">
	<input id="madxartwork-mode-switcher-preview-input" type="checkbox">
	<label for="madxartwork-mode-switcher-preview-input" id="madxartwork-mode-switcher-preview">
		<i class="eicon" aria-hidden="true" title="<?php esc_attr_e( 'Hide Panel', 'madxartwork' ); ?>"></i>
		<span class="madxartwork-screen-only"><?php echo esc_html__( 'Hide Panel', 'madxartwork' ); ?></span>
	</label>
</script>

<script type="text/template" id="tmpl-editor-content">
	<div class="madxartwork-panel-navigation">
		<# _.each( elementData.tabs_controls, function( tabTitle, tabSlug ) {
			if ( 'content' !== tabSlug && ! madxartwork.userCan( 'design' ) ) {
				return;
			}
			$e.bc.ensureTab( 'panel/editor', tabSlug );
			#>
			<div class="madxartwork-component-tab madxartwork-panel-navigation-tab madxartwork-tab-control-{{ tabSlug }}" data-tab="{{ tabSlug }}">
				<a href="#">{{{ tabTitle }}}</a>
			</div>
		<# } ); #>
	</div>
	<# if ( elementData.reload_preview ) { #>
		<div class="madxartwork-update-preview">
			<div class="madxartwork-update-preview-title"><?php echo esc_html__( 'Update changes to page', 'madxartwork' ); ?></div>
			<div class="madxartwork-update-preview-button-wrapper">
				<button class="madxartwork-update-preview-button madxartwork-button"><?php echo esc_html__( 'Apply', 'madxartwork' ); ?></button>
			</div>
		</div>
	<# } #>
	<div id="madxartwork-controls"></div>
	<# if ( elementData.help_url ) { #>
		<div id="madxartwork-panel__editor__help">
			<a id="madxartwork-panel__editor__help__link" href="{{ elementData.help_url }}" target="_blank">
				<?php echo esc_html__( 'Need Help', 'madxartwork' ); ?>
				<i class="eicon-help-o"></i>
			</a>
		</div>
	<# } #>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-schemes-disabled">
	<img class="madxartwork-nerd-box-icon" src="<?php Utils::print_unescaped_internal_string( madxartwork_ASSETS_URL . 'images/information.svg' ); ?>" />
	<div class="madxartwork-nerd-box-title">{{{ '<?php echo esc_html__( '%s are disabled', 'madxartwork' ); // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment ?>'.replace( '%s', disabledTitle ) }}}</div>
	<div class="madxartwork-nerd-box-message"><?php
		printf(
			/* translators: %1$s Link open tag, %2$s: Link close tag. */
			esc_html__( 'You can enable it from the %1$smadxartwork settings page%2$s.', 'madxartwork' ),
			'<a href="' . esc_url( Settings::get_url() ) . '" target="_blank">',
			'</a>'
		);
		?></div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-scheme-color-item">
	<div class="madxartwork-panel-scheme-color-picker-placeholder"></div>
	<div class="madxartwork-panel-scheme-color-title">{{{ title }}}</div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-scheme-typography-item">
	<div class="madxartwork-panel-heading">
		<div class="madxartwork-panel-heading-toggle">
			<i class="eicon" aria-hidden="true"></i>
		</div>
		<div class="madxartwork-panel-heading-title">{{{ title }}}</div>
	</div>
	<div class="madxartwork-panel-scheme-typography-items madxartwork-panel-box-content">
		<?php
		$scheme_fields_keys = Group_Control_Typography::get_scheme_fields_keys();

		$typography_group = Plugin::$instance->controls_manager->get_control_groups( 'typography' );
		$typography_fields = $typography_group->get_fields();

		$scheme_fields = array_intersect_key( $typography_fields, array_flip( $scheme_fields_keys ) );

		foreach ( $scheme_fields as $option_name => $option ) :
			?>
			<div class="madxartwork-panel-scheme-typography-item madxartwork-control madxartwork-control-type-select">
				<div class="madxartwork-panel-scheme-item-title madxartwork-control-title"><?php echo esc_html( $option['label'] ); ?></div>
				<div class="madxartwork-panel-scheme-typography-item-value madxartwork-control-input-wrapper">
					<?php if ( 'select' === $option['type'] ) : ?>
						<select name="<?php echo esc_attr( $option_name ); ?>" class="madxartwork-panel-scheme-typography-item-field">
							<?php foreach ( $option['options'] as $field_key => $field_value ) : ?>
								<option value="<?php echo esc_attr( $field_key ); ?>"><?php echo esc_html( $field_value ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'font' === $option['type'] ) : ?>
						<select name="<?php echo esc_attr( $option_name ); ?>" class="madxartwork-panel-scheme-typography-item-field">
							<option value=""><?php echo esc_html__( 'Default', 'madxartwork' ); ?></option>
							<?php foreach ( Fonts::get_font_groups() as $group_type => $group_label ) : ?>
								<optgroup label="<?php echo esc_attr( $group_label ); ?>">
									<?php foreach ( Fonts::get_fonts_by_groups( [ $group_type ] ) as $font_title => $font_type ) : ?>
										<option value="<?php echo esc_attr( $font_title ); ?>"><?php echo esc_html( $font_title ); ?></option>
									<?php endforeach; ?>
								</optgroup>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'text' === $option['type'] ) : ?>
						<input name="<?php echo esc_attr( $option_name ); ?>" class="madxartwork-panel-scheme-typography-item-field" />
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-control-responsive-switchers">
	<div class="madxartwork-control-responsive-switchers">
		<div class="madxartwork-control-responsive-switchers__holder">
		<#
			const activeBreakpoints = madxartwork.config.responsive.activeBreakpoints,
				devicesForDisplay = madxartwork.breakpoints.getActiveBreakpointsList( { largeToSmall: true, withDesktop: true } );

			var devices = responsive.devices || devicesForDisplay;

			_.each( devices, function( device ) {
				// The 'Desktop' label is made accessible via the global config because it needs to be translated.
				var deviceLabel = 'desktop' === device ? '<?php esc_html_e( 'Desktop', 'madxartwork' ); ?>' : activeBreakpoints[ device ].label,
					tooltipDir = "<?php echo is_rtl() ? 'e' : 'w'; ?>";
			#>
				<button class="madxartwork-responsive-switcher tooltip-target madxartwork-responsive-switcher-{{ device }}" data-device="{{ device }}" data-tooltip="{{ deviceLabel }}" data-tooltip-pos="{{ tooltipDir }}">
					<i class="{{ madxartwork.config.responsive.icons_map[ device ] }}" aria-hidden="true"></i>
					<span class="madxartwork-screen-only">{{ deviceLabel }}</span>
				</button>
			<# } );
		#>
		</div>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-control-dynamic-switcher">
	<div class="madxartwork-control-dynamic-switcher madxartwork-control-unit-1" data-tooltip="<?php echo esc_html__( 'Dynamic Tags', 'madxartwork' ); ?>">
		<i class="eicon-database"></i>
	</div>
</script>
<script type="text/template" id="tmpl-madxartwork-control-element-color-picker">
	<div class="madxartwork-control-element-color-picker e-control-tool" data-tooltip="<?php echo esc_attr__( 'Color Sampler', 'madxartwork' ); ?>">
		<i class="eicon-eyedropper"></i>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-control-dynamic-cover">
	<div class="madxartwork-dynamic-cover__settings">
		<i class="eicon-{{ hasSettings ? 'wrench' : 'database' }}"></i>
	</div>
	<div class="madxartwork-dynamic-cover__title" title="{{{ title + ' ' + content }}}">{{{ title + ' ' + content }}}</div>
	<# if ( isRemovable ) { #>
		<div class="madxartwork-dynamic-cover__remove">
			<i class="eicon-close-circle"></i>
		</div>
	<# } #>
</script>

<script type="text/template" id="tmpl-madxartwork-dynamic-tags-promo">
	<div class="madxartwork-tags-list__teaser">
		<div class="madxartwork-tags-list__group-title madxartwork-tags-list__teaser-title">
			<i class="eicon-info-circle"></i><?php echo esc_html__( 'madxartwork Dynamic Content', 'madxartwork' ); ?>
		</div>
		<div class="madxartwork-tags-list__teaser-text">
			<?php echo esc_html__( 'You’re missing out!', 'madxartwork' ); ?><br />
			<?php echo esc_html__( 'Get more dynamic capabilities by incorporating dozens of madxartwork\'s native dynamic tags.', 'madxartwork' ); ?>
			<a href="{{{ promotionUrl }}}" class="madxartwork-tags-list__teaser-link" target="_blank">
				<?php echo esc_html__( 'Upgrade', 'madxartwork' ); ?>
			</a>
		</div>
	</div>
</script>
