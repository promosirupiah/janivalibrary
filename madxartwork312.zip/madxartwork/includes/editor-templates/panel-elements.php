<?php
namespace madxartwork;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<script type="text/template" id="tmpl-madxartwork-panel-elements">
	<div id="madxartwork-panel-elements-navigation" class="madxartwork-panel-navigation">
		<div class="madxartwork-component-tab madxartwork-panel-navigation-tab" data-tab="categories"><?php echo esc_html__( 'Elements', 'madxartwork' ); ?></div>
		<div class="madxartwork-component-tab madxartwork-panel-navigation-tab" data-tab="global"><?php echo esc_html__( 'Global', 'madxartwork' ); ?></div>
	</div>
	<div id="madxartwork-panel-elements-search-area"></div>
	<div id="madxartwork-panel-elements-wrapper"></div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-categories">
	<div id="madxartwork-panel-categories"></div>

	<div id="madxartwork-panel-get-pro-elements" class="madxartwork-nerd-box">
		<img class="madxartwork-nerd-box-icon" src="<?php echo madxartwork_ASSETS_URL . 'images/go-pro.svg'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" />
		<div class="madxartwork-nerd-box-message"><?php echo esc_html__( 'Get more with madxartwork Pro', 'madxartwork' ); ?></div>
		<a class="madxartwork-button go-pro" target="_blank" href="https://go.madxartwork.com/pro-widgets/"><?php echo esc_html__( 'Upgrade Now', 'madxartwork' ); ?></a>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-elements-category">
	<div class="madxartwork-panel-heading madxartwork-panel-category-title">
		<div class="madxartwork-panel-heading-toggle">
			<i class="eicon" aria-hidden="true"></i>
		</div>
		<div class="madxartwork-panel-heading-title">{{{ title }}}</div>
	</div>
	<div class="madxartwork-panel-category-items madxartwork-responsive-panel"></div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-elements-category-empty">
	<div class="madxartwork-panel-category-items-empty madxartwork-panel-alert madxartwork-panel-alert-info">
		<?php echo esc_html__( 'For easy access, favorite the widgets you use most often by right clicking > Add to Favorites.', 'madxartwork' ); ?>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-element-search">
	<label for="madxartwork-panel-elements-search-input" class="screen-reader-text"><?php echo esc_html__( 'Search Widget:', 'madxartwork' ); ?></label>
	<input type="search" id="madxartwork-panel-elements-search-input" placeholder="<?php esc_attr_e( 'Search Widget...', 'madxartwork' ); ?>" autocomplete="off"/>
	<i class="eicon-search-bold" aria-hidden="true"></i>
</script>

<script type="text/template" id="tmpl-madxartwork-element-library-element">
	<div class="madxartwork-element">
		<# if ( false === obj.editable ) { #>
			<i class="eicon-lock"></i>
		<# } #>
		<div class="icon">
			<i class="{{ icon }}" aria-hidden="true"></i>
		</div>
		<div class="title-wrapper">
			<div class="title">{{{ title }}}</div>
		</div>
	</div>
</script>

<script type="text/template" id="tmpl-madxartwork-panel-global">
	<div class="madxartwork-nerd-box">
		<img class="madxartwork-nerd-box-icon" src="<?php echo madxartwork_ASSETS_URL . 'images/information.svg'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>" />
		<div class="madxartwork-nerd-box-title"><?php echo esc_html__( 'Meet Our Global Widget', 'madxartwork' ); ?></div>
		<div class="madxartwork-nerd-box-message"><?php echo esc_html__( 'With this feature, you can save a widget as global, then add it to multiple areas. All areas will be editable from one single place.', 'madxartwork' ); ?></div>
		<a class="madxartwork-button go-pro" target="_blank" href="https://go.madxartwork.com/pro-global/"><?php echo esc_html__( 'Upgrade Now', 'madxartwork' ); ?></a>
	</div>
</script>
