<?php
namespace madxartwork;

use madxartwork\Core\Kits\Manager;
use madxartwork\Core\Upgrade\Manager as Upgrade_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * madxartwork maintenance.
 *
 * madxartwork maintenance handler class is responsible for setting up madxartwork
 * activation and uninstallation hooks.
 *
 * @since 1.0.0
 */
class Maintenance {

	/**
	 * Activate madxartwork.
	 *
	 * Set madxartwork activation hook.
	 *
	 * Fired by `register_activation_hook` when the plugin is activated.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 */
	public static function activation( $network_wide ) {
		wp_clear_scheduled_hook( 'madxartwork/tracker/send_event' );

		wp_schedule_event( time(), 'daily', 'madxartwork/tracker/send_event' );
		flush_rewrite_rules();

		if ( is_multisite() && $network_wide ) {
			static::create_default_kit(
				get_sites( [
					'fields' => 'ids',
				] )
			);

			return;
		}

		static::create_default_kit();
		static::insert_defaults_options();

		set_transient( 'madxartwork_activation_redirect', true, MINUTE_IN_SECONDS );
	}

	public static function insert_defaults_options() {
		$history = Upgrade_Manager::get_installs_history();
		if ( empty( $history ) ) {
			$default_options = [
				'madxartwork_font_display' => 'swap',
			];
			foreach ( $default_options as $option_name => $option_value ) {
				if ( \madxartwork\Utils::is_empty( get_option( $option_name ) ) ) {
					add_option( $option_name, $option_value );
				}
			}
		}
	}

	/**
	 * Uninstall madxartwork.
	 *
	 * Set madxartwork uninstallation hook.
	 *
	 * Fired by `register_uninstall_hook` when the plugin is uninstalled.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 */
	public static function uninstall() {
		wp_clear_scheduled_hook( 'madxartwork/tracker/send_event' );
	}

	/**
	 * Init.
	 *
	 * Initialize madxartwork Maintenance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 */
	public static function init() {
		register_activation_hook( madxartwork_PLUGIN_BASE, [ __CLASS__, 'activation' ] );
		register_uninstall_hook( madxartwork_PLUGIN_BASE, [ __CLASS__, 'uninstall' ] );

		add_action( 'wpmu_new_blog', function ( $site_id ) {
			if ( ! is_plugin_active_for_network( madxartwork_PLUGIN_BASE ) ) {
				return;
			}

			static::create_default_kit( [ $site_id ] );
		} );
	}

	/**
	 * @param array $site_ids
	 */
	private static function create_default_kit( array $site_ids = [] ) {
		if ( ! empty( $site_ids ) ) {
			foreach ( $site_ids as $site_id ) {
				switch_to_blog( $site_id );

				Manager::create_default_kit();

				restore_current_blog();
			};

			return;
		}

		Manager::create_default_kit();
	}
}
