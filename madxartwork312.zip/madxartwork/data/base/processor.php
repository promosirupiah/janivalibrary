<?php
namespace madxartwork\Data\Base;

abstract class Processor {

	/**
	 * Controller.
	 *
	 * @var \madxartwork\Data\Base\Controller
	 */
	private $controller;

	/**
	 * Processor constructor.
	 *
	 * @param \madxartwork\Data\Base\Controller $controller
	 */
	public function __construct( $controller ) {
		$this->controller = $controller;
	}

	/**
	 * Get processor command.
	 *
	 * @return string
	 */
	abstract public function get_command();
}
