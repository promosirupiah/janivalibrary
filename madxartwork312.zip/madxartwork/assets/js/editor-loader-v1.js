/*! madxartwork - v3.12.1 - 02-04-2023 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!****************************************************!*\
  !*** ../core/editor/assets/js/editor-loader-v1.js ***!
  \****************************************************/


window.madxartwork.start();
/******/ })()
;
//# sourceMappingURL=editor-loader-v1.js.map