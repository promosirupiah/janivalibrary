__('Switch Device', 'madxartwork');
__('Desktop', 'madxartwork');
// translators: %s: Breakpoint label, %d: Breakpoint size.
__('%s (%dpx and up)', 'madxartwork');
// translators: %s: Breakpoint label, %d: Breakpoint size.
__('%s (up to %dpx)', 'madxartwork');