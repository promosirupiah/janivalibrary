<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-v1-adapters','deps'=>['react',],];