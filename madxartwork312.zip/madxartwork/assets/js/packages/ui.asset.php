<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-ui','deps'=>['react','react-dom',],];