<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-store','deps'=>['react','react-dom',],];