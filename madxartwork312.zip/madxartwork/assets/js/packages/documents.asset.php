<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-documents','deps'=>['madxartwork-packages-store','madxartwork-packages-v1-adapters','react',],];