__('Manage Website', 'madxartwork');
__('More', 'madxartwork');
__('madxartwork Logo', 'madxartwork');