__('Save as Template', 'madxartwork');
__('Preview Changes', 'madxartwork');
/* translators: %s: Post type label. */
__('Save Draft', 'madxartwork');
__('%s Settings', 'madxartwork');
__('Save Options', 'madxartwork');
__('Publish', 'madxartwork');
__('Submit', 'madxartwork');