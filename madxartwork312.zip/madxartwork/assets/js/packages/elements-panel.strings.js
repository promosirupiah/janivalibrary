__('Elements', 'madxartwork');
__('Add Element', 'madxartwork');