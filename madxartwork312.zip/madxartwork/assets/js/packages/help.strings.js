__('Keyboard Shortcuts', 'madxartwork');
__('Help', 'madxartwork');