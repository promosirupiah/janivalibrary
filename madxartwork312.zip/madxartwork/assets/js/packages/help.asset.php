<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-help','deps'=>['madxartwork-packages-icons','madxartwork-packages-top-bar','madxartwork-packages-v1-adapters','wp-i18n',],];