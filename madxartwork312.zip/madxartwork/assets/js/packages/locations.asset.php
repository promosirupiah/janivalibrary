<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-locations','deps'=>['react',],];