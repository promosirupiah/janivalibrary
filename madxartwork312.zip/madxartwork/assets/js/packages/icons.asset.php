<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'madxartwork-packages-icons','deps'=>['madxartwork-packages-ui','react',],];