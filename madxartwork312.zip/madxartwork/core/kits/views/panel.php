<script type="text/template" id="tmpl-madxartwork-kit-panel">
	<main id="madxartwork-kit__panel-content__wrapper" class="madxartwork-panel-content-wrapper"></main>
</script>

<script type="text/template" id="tmpl-madxartwork-kit-panel-content">
	<div id="madxartwork-kit-panel-content-controls"></div>
	<#
	const tabConfig = $e.components.get( 'panel/global' ).getActiveTabConfig();
	if ( tabConfig.helpUrl ) { #>
	<div id="madxartwork-panel__editor__help">
		<a id="madxartwork-panel__editor__help__link" href="{{ tabConfig.helpUrl }}" target="_blank">
			<?php echo esc_html__( 'Need Help', 'madxartwork' ); ?>
			<i class="eicon-help-o"></i>
		</a>
	</div>
	<#
	}

	if ( tabConfig.additionalContent ) {
		#> {{{ tabConfig.additionalContent }}} <#
	}
	#>
</script>

<script type="text/template" id="tmpl-madxartwork-global-style-repeater-row">
	<# let removeClass = 'remove',
			removeIcon = 'eicon-trash-o';

	if ( ! itemActions.remove ) {
		removeClass += '--disabled';

		removeIcon = 'eicon-disable-trash-o'
	}
	#>
	<# if ( itemActions.sort ) { #>
	<div class="madxartwork-repeater-row-tool madxartwork-repeater-row-tools madxartwork-repeater-tool-sort">
		<i class="eicon-cursor-move"></i>
		<span class="madxartwork-screen-only"><?php echo esc_html__( 'Reorder', 'madxartwork' ); ?></span>
	</div>
	<# } #>
	<div class="madxartwork-repeater-row-tool madxartwork-repeater-tool-{{{ removeClass }}}">
		<i class="{{{ removeIcon }}}" aria-hidden="true"></i>
		<# if ( itemActions.remove ) { #>
			<span class="madxartwork-screen-only"><?php echo esc_html__( 'Remove', 'madxartwork' ); ?></span>
		<# } #>
	</div>
	<div class="madxartwork-repeater-row-controls"></div>
</script>
