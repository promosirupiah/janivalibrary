<?php

namespace madxartwork\Core\Common\Modules\Finder\Categories;

use madxartwork\Core\Common\Modules\Finder\Base_Category;
use madxartwork\Tools as madxartworkTools;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Tools Category
 *
 * Provides items related to madxartwork's tools.
 */
class Tools extends Base_Category {

	/**
	 * Get title.
	 *
	 * @since 2.3.0
	 * @access public
	 *
	 * @return string
	 */
	public function get_title() {
		return esc_html__( 'Tools', 'madxartwork' );
	}

	public function get_id() {
		return 'tools';
	}

	/**
	 * Get category items.
	 *
	 * @since 2.3.0
	 * @access public
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	public function get_category_items( array $options = [] ) {
		$tools_url = madxartworkTools::get_url();

		$items = [
			'tools' => [
				'title' => esc_html__( 'Tools', 'madxartwork' ),
				'icon' => 'tools',
				'url' => $tools_url,
				'keywords' => [ 'tools', 'regenerate css', 'safe mode', 'debug bar', 'sync library', 'madxartwork' ],
			],
			'replace-url' => [
				'title' => esc_html__( 'Replace URL', 'madxartwork' ),
				'icon' => 'tools',
				'url' => $tools_url . '#tab-replace_url',
				'keywords' => [ 'tools', 'replace url', 'domain', 'madxartwork' ],
			],
			'maintenance-mode' => [
				'title' => esc_html__( 'Maintenance Mode', 'madxartwork' ),
				'icon' => 'tools',
				'url' => $tools_url . '#tab-maintenance_mode',
				'keywords' => [ 'tools', 'maintenance', 'coming soon', 'madxartwork' ],
			],
			'import-export' => [
				'title' => esc_html__( 'Import Export', 'madxartwork' ),
				'icon' => 'import-export',
				'url' => $tools_url . '#tab-import-export-kit',
				'keywords' => [ 'tools', 'import export', 'import', 'export', 'kit' ],
			],
		];

		if ( madxartworkTools::can_user_rollback_versions() ) {
			$items['version-control'] = [
				'title' => esc_html__( 'Version Control', 'madxartwork' ),
				'icon' => 'time-line',
				'url' => $tools_url . '#tab-versions',
				'keywords' => [ 'tools', 'version', 'control', 'rollback', 'beta', 'madxartwork' ],
			];
		}

		return $items;
	}
}
