<?php
namespace madxartwork\Core\DynamicTags;

use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * madxartwork tag.
 *
 * An abstract class to register new madxartwork tag.
 *
 * @since 2.0.0
 * @abstract
 */
abstract class Tag extends Base_Tag {

	const WRAPPED_TAG = false;

	/**
	 * @since 2.0.0
	 * @access public
	 *
	 * @param array $options
	 *
	 * @return string
	 */
	public function get_content( array $options = [] ) {
		$settings = $this->get_settings();

		ob_start();

		$this->render();

		$value = ob_get_clean();

		if ( ! Utils::is_empty( $value ) ) {
			// TODO: fix spaces in `before`/`after` if WRAPPED_TAG ( conflicted with .madxartwork-tag { display: inline-flex; } );
			if ( ! Utils::is_empty( $settings, 'before' ) ) {
				$value = wp_kses_post( $settings['before'] ) . $value;
			}

			if ( ! Utils::is_empty( $settings, 'after' ) ) {
				$value .= wp_kses_post( $settings['after'] );
			}

			if ( static::WRAPPED_TAG ) :
				$value = '<span id="madxartwork-tag-' . esc_attr( $this->get_id() ) . '" class="madxartwork-tag">' . $value . '</span>';
			endif;

		} elseif ( ! Utils::is_empty( $settings, 'fallback' ) ) {
			$value = $settings['fallback'];
		}

		return $value;
	}

	/**
	 * @since 2.0.0
	 * @access public
	 */
	final public function get_content_type() {
		return 'ui';
	}

	/**
	 * @since 2.0.9
	 * @access public
	 */
	public function get_editor_config() {
		$config = parent::get_editor_config();

		$config['wrapped_tag'] = $this::WRAPPED_TAG;

		return $config;
	}

	/**
	 * @since 2.0.0
	 * @access protected
	 */
	protected function register_advanced_section() {
		$this->start_controls_section(
			'advanced',
			[
				'label' => esc_html__( 'Advanced', 'madxartwork' ),
			]
		);

		$this->add_control(
			'before',
			[
				'label' => esc_html__( 'Before', 'madxartwork' ),
			]
		);

		$this->add_control(
			'after',
			[
				'label' => esc_html__( 'After', 'madxartwork' ),
			]
		);

		$this->add_control(
			'fallback',
			[
				'label' => esc_html__( 'Fallback', 'madxartwork' ),
			]
		);

		$this->end_controls_section();
	}
}
