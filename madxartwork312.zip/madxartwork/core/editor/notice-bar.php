<?php
namespace madxartwork\Core\Editor;

use madxartwork\Core\Base\Base_Object;
use madxartwork\Core\Common\Modules\Ajax\Module as Ajax;
use madxartwork\Plugin;
use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Notice_Bar extends Base_Object {

	protected function get_init_settings() {
		if ( Plugin::$instance->get_install_time() > strtotime( '-1 days' ) ) {
			return [];
		}

		return [
			'muted_period' => 14,
			'option_key' => '_madxartwork_editor_upgrade_notice_dismissed',
			'message' => esc_html__( 'Unleash the full power of madxartwork\'s features and web creation tools.', 'madxartwork' ),
			'action_title' => esc_html__( 'Upgrade Now', 'madxartwork' ),
			'action_url' => 'https://go.madxartwork.com/go-pro-editor-notice-bar/',
		];
	}

	final public function get_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return null;
		}

		$settings = $this->get_settings();

		if ( empty( $settings['option_key'] ) ) {
			return null;
		}

		$dismissed_time = get_option( $settings['option_key'] );

		if ( $dismissed_time ) {
			if ( $dismissed_time > strtotime( '-' . $settings['muted_period'] . ' days' ) ) {
				return null;
			}

			$this->set_notice_dismissed();
		}

		return $this;
	}

	protected function render_action( $type ) {
		$settings = $this->get_settings();

		// TODO: Make the API better. The bad naming is because of BC.
		$prefix_map = [
			'primary' => '',
			'secondary' => 'secondary_',
		];

		$prefix = $prefix_map[ $type ];

		$action_title = "{$prefix}action_title";
		$action_url = "{$prefix}action_url";
		$action_message = "{$prefix}message";
		$action_target = "{$prefix}action_target";

		if ( empty( $settings[ $action_title ] ) || empty( $settings[ $action_url ] ) || empty( $settings[ $action_message ] ) ) {
			return;

		}

		?>
		<div class="e-notice-bar__message <?php echo esc_attr( "e-notice-bar__{$type}_message" ); ?>">
			<?php Utils::print_unescaped_internal_string( sprintf( $settings[ $action_message ], $settings[ $action_url ] ) ); ?>
		</div>

		<div class="e-notice-bar__action <?php echo esc_attr( "e-notice-bar__{$type}_action" ); ?>">
			<a href="<?php Utils::print_unescaped_internal_string( $settings[ $action_url ] ); ?>"
				target="<?php echo empty( $settings[ $action_target ] ) ? '_blank' : esc_attr( $settings[ $action_target ] ); ?>"
			>
				<?php Utils::print_unescaped_internal_string( $settings[ $action_title ] ); ?>
			</a>
		</div>
		<?php
	}

	public function render() {
		$settings = $this->get_settings();

		$icon = empty( $settings['icon'] )
			? 'eicon-madxartwork-square'
			: esc_attr( $settings['icon'] );

		?>
		<div id="e-notice-bar" class="e-notice-bar">
			<i class="e-notice-bar__icon <?php echo esc_attr( $icon ); ?>"></i>

			<?php
			$this->render_action( 'primary' );
			$this->render_action( 'secondary' );
			?>

			<i id="e-notice-bar__close" class="e-notice-bar__close eicon-close"></i>
		</div>
		<?php
	}

	public function __construct() {
		add_action( 'madxartwork/ajax/register_actions', [ $this, 'register_ajax_actions' ] );
	}

	public function set_notice_dismissed() {
		update_option( $this->get_settings( 'option_key' ), time() );
	}

	public function register_ajax_actions( Ajax $ajax ) {
		$ajax->register_ajax_action( 'notice_bar_dismiss', [ $this, 'set_notice_dismissed' ] );
	}
}
