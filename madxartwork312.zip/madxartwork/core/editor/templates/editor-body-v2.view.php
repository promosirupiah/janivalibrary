<?php
namespace madxartwork\Core\Editor\Templates;

use madxartwork\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$notice = Plugin::$instance->editor->notice_bar->get_notice();
?>

<div id="madxartwork-editor-wrapper-v2"></div>

<div id="madxartwork-editor-wrapper">
	<div id="madxartwork-panel" class="madxartwork-panel"></div>
	<div id="madxartwork-preview">
		<div id="madxartwork-loading">
			<div class="madxartwork-loader-wrapper">
				<div class="madxartwork-loader">
					<div class="madxartwork-loader-boxes">
						<div class="madxartwork-loader-box"></div>
						<div class="madxartwork-loader-box"></div>
						<div class="madxartwork-loader-box"></div>
						<div class="madxartwork-loader-box"></div>
					</div>
				</div>
				<div class="madxartwork-loading-title"><?php echo esc_html__( 'Loading', 'madxartwork' ); ?></div>
			</div>
		</div>
		<div id="madxartwork-preview-responsive-wrapper" class="madxartwork-device-desktop madxartwork-device-rotate-portrait">
			<div id="madxartwork-preview-loading">
				<i class="eicon-loading eicon-animation-spin" aria-hidden="true"></i>
			</div>
			<?php if ( $notice ) {
				$notice->render();
			} // IFrame will be created here by the Javascript later. ?>
		</div>
	</div>
	<div id="madxartwork-navigator"></div>
</div>
