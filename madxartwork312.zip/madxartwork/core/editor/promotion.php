<?php
namespace madxartwork\Core\Editor;

use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Promotion {
	public function get_elements_promotion() {
		// For BC
		$has_pro = Utils::has_pro();

		return [
			/* translators: %s: Widget title. */
			'title' => __( '%s Widget', 'madxartwork' ),
			/* translators: %s: Widget title. */
			'content' => __(
				'Use %s widget and dozens more pro features to extend your toolbox and build sites faster and better.',
				'madxartwork'
			),
			'action_button' => [
				'text' => $has_pro ?
					__( 'Connect & Activate', 'madxartwork' ) :
					__( 'Upgrade Now', 'madxartwork' ),
				'url' => $has_pro ?
					admin_url( 'admin.php?page=madxartwork-license' ) :
					'https://go.madxartwork.com/go-pro-%s',
			],
		];
	}
}
