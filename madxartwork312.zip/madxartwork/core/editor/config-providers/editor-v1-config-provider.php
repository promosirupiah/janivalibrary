<?php
namespace madxartwork\Core\Editor\Config_Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Editor_V1_Config_Provider implements Config_Provider_Interface {
	public function get_script_configs() {
		return array_merge(
			Editor_Common_Configs::get_script_configs(),
			[
				[
					'handle' => 'madxartwork-responsive-bar',
					'src' => '{{madxartwork_ASSETS_URL}}js/responsive-bar{{MIN_SUFFIX}}.js',
					'deps' => [ 'madxartwork-editor' ],
					'i18n' => [
						'domain' => 'madxartwork',
					],
				],
				// Loader script
				[
					'handle' => 'madxartwork-editor-loader-v1',
					'src' => '{{madxartwork_ASSETS_URL}}js/editor-loader-v1{{MIN_SUFFIX}}.js',
					'deps' => [ 'madxartwork-editor' ],
				],
			]
		);
	}

	public function get_script_handles_to_enqueue() {
		return [
			'madxartwork-responsive-bar',

			// Must be last.
			'madxartwork-editor-loader-v1',
		];
	}

	public function get_client_settings() {
		return Editor_Common_Configs::get_client_settings();
	}

	public function get_style_configs() {
		return array_merge(
			Editor_Common_Configs::get_style_configs(),
			[
				[
					'handle' => 'madxartwork-responsive-bar',
					'src' => '{{madxartwork_ASSETS_URL}}css/responsive-bar{{MIN_SUFFIX}}.css',
				],
			]
		);
	}

	public function get_style_handles_to_enqueue() {
		return [
			'madxartwork-editor',
			'madxartwork-responsive-bar',
		];
	}

	public function get_template_body_file_path() {
		return __DIR__ . '/../templates/editor-body-v1.view.php';
	}

	public function get_additional_template_paths() {
		return array_merge(
			Editor_Common_Configs::get_additional_template_paths(),
			[ madxartwork_PATH . 'includes/editor-templates/responsive-bar.php' ]
		);
	}
}
