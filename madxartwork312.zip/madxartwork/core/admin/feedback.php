<?php
namespace madxartwork\Core\Admin;

use madxartwork\Api;
use madxartwork\Core\Base\Module;
use madxartwork\Plugin;
use madxartwork\Tracker;
use madxartwork\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Feedback extends Module {

	/**
	 * @since 2.2.0
	 * @access public
	 */
	public function __construct() {
		add_action( 'current_screen', function () {
			if ( ! $this->is_plugins_screen() ) {
				return;
			}

			add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_feedback_dialog_scripts' ] );
		} );

		// Ajax.
		add_action( 'wp_ajax_madxartwork_deactivate_feedback', [ $this, 'ajax_madxartwork_deactivate_feedback' ] );
	}

	/**
	 * Get module name.
	 *
	 * Retrieve the module name.
	 *
	 * @since  1.7.0
	 * @access public
	 *
	 * @return string Module name.
	 */
	public function get_name() {
		return 'feedback';
	}

	/**
	 * Enqueue feedback dialog scripts.
	 *
	 * Registers the feedback dialog scripts and enqueues them.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function enqueue_feedback_dialog_scripts() {
		add_action( 'admin_footer', [ $this, 'print_deactivate_feedback_dialog' ] );

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_register_script(
			'madxartwork-admin-feedback',
			madxartwork_ASSETS_URL . 'js/admin-feedback' . $suffix . '.js',
			[
				'madxartwork-common',
			],
			madxartwork_VERSION,
			true
		);

		wp_enqueue_script( 'madxartwork-admin-feedback' );
	}

	/**
	 * @since 2.3.0
	 * @deprecated 3.1.0
	 */
	public function localize_feedback_dialog_settings() {
		Plugin::$instance->modules_manager->get_modules( 'dev-tools' )->deprecation->deprecated_function( __METHOD__, '3.1.0' );

		return [];
	}

	/**
	 * Print deactivate feedback dialog.
	 *
	 * Display a dialog box to ask the user why he deactivated madxartwork.
	 *
	 * Fired by `admin_footer` filter.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function print_deactivate_feedback_dialog() {
		$deactivate_reasons = [
			'no_longer_needed' => [
				'title' => esc_html__( 'I no longer need the plugin', 'madxartwork' ),
				'input_placeholder' => '',
			],
			'found_a_better_plugin' => [
				'title' => esc_html__( 'I found a better plugin', 'madxartwork' ),
				'input_placeholder' => esc_html__( 'Please share which plugin', 'madxartwork' ),
			],
			'couldnt_get_the_plugin_to_work' => [
				'title' => esc_html__( 'I couldn\'t get the plugin to work', 'madxartwork' ),
				'input_placeholder' => '',
			],
			'temporary_deactivation' => [
				'title' => esc_html__( 'It\'s a temporary deactivation', 'madxartwork' ),
				'input_placeholder' => '',
			],
			'madxartwork_pro' => [
				'title' => esc_html__( 'I have madxartwork Pro', 'madxartwork' ),
				'input_placeholder' => '',
				'alert' => esc_html__( 'Wait! Don\'t deactivate madxartwork. You have to activate both madxartwork and madxartwork Pro in order for the plugin to work.', 'madxartwork' ),
			],
			'other' => [
				'title' => esc_html__( 'Other', 'madxartwork' ),
				'input_placeholder' => esc_html__( 'Please share the reason', 'madxartwork' ),
			],
		];

		?>
		<div id="madxartwork-deactivate-feedback-dialog-wrapper">
			<div id="madxartwork-deactivate-feedback-dialog-header">
				<i class="eicon-madxartwork-square" aria-hidden="true"></i>
				<span id="madxartwork-deactivate-feedback-dialog-header-title"><?php echo esc_html__( 'Quick Feedback', 'madxartwork' ); ?></span>
			</div>
			<form id="madxartwork-deactivate-feedback-dialog-form" method="post">
				<?php
				wp_nonce_field( '_madxartwork_deactivate_feedback_nonce' );
				?>
				<input type="hidden" name="action" value="madxartwork_deactivate_feedback" />

				<div id="madxartwork-deactivate-feedback-dialog-form-caption"><?php echo esc_html__( 'If you have a moment, please share why you are deactivating madxartwork:', 'madxartwork' ); ?></div>
				<div id="madxartwork-deactivate-feedback-dialog-form-body">
					<?php foreach ( $deactivate_reasons as $reason_key => $reason ) : ?>
						<div class="madxartwork-deactivate-feedback-dialog-input-wrapper">
							<input id="madxartwork-deactivate-feedback-<?php echo esc_attr( $reason_key ); ?>" class="madxartwork-deactivate-feedback-dialog-input" type="radio" name="reason_key" value="<?php echo esc_attr( $reason_key ); ?>" />
							<label for="madxartwork-deactivate-feedback-<?php echo esc_attr( $reason_key ); ?>" class="madxartwork-deactivate-feedback-dialog-label"><?php echo esc_html( $reason['title'] ); ?></label>
							<?php if ( ! empty( $reason['input_placeholder'] ) ) : ?>
								<input class="madxartwork-feedback-text" type="text" name="reason_<?php echo esc_attr( $reason_key ); ?>" placeholder="<?php echo esc_attr( $reason['input_placeholder'] ); ?>" />
							<?php endif; ?>
							<?php if ( ! empty( $reason['alert'] ) ) : ?>
								<div class="madxartwork-feedback-text"><?php echo esc_html( $reason['alert'] ); ?></div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * Ajax madxartwork deactivate feedback.
	 *
	 * Send the user feedback when madxartwork is deactivated.
	 *
	 * Fired by `wp_ajax_madxartwork_deactivate_feedback` action.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function ajax_madxartwork_deactivate_feedback() {
		$wpnonce = Utils::get_super_global_value( $_POST, '_wpnonce' ); // phpcs:ignore -- Nonce verification is made in `wp_verify_nonce()`.
		if ( ! wp_verify_nonce( $wpnonce, '_madxartwork_deactivate_feedback_nonce' ) ) {
			wp_send_json_error();
		}

		$reason_key = Utils::get_super_global_value( $_POST, 'reason_key' ) ?? '';
		$reason_text = Utils::get_super_global_value( $_POST, "reason_{$reason_key}" ) ?? '';

		Api::send_feedback( $reason_key, $reason_text );

		wp_send_json_success();
	}

	/**
	 * @since 2.3.0
	 * @access private
	 */
	private function is_plugins_screen() {
		return in_array( get_current_screen()->id, [ 'plugins', 'plugins-network' ] );
	}
}
