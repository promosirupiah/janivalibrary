var piereg = jQuery.noConflict();
piereg(document).ready(function($) {
    piereg( document ).on( 'click', '.element-item', function(e) {
        var template  = piereg(this).data('template');

        if ( template == "Default Form" )
        {
            location.href = "?page=pr_new_registration_form";
        } else {
            $.confirm({
                title: 'Create Form',
                boxWidth: '500px',
                useBootstrap: false,
                content: '' +
                '<form action="post" class="pie-reg-form-addnew">' +
                  '<div class="form-group">' +
                  '<input type="text" placeholder="Enter a form name" class="name form-control" required />' +
                  '</div>' +
                '</form>',
                buttons: {
                    formSubmit: {
                        text: 'Submit',
                        btnClass: 'btn-blue',
                        action: function () {
                            var name = this.$content.find('.name').val();
                            if(!name){
                                $.alert('Please provide a valid form name.');
                                return false;
                            }
                            $.ajax({
                              type : "POST",
                              url : pr_data.ajax_url,
                              data : {action: "pie_register_create_template_ajax",form_name: name,form_template:template},
                              dataType : "json",
                              success: function ( form_id ) {  
                                location.href = "?page=pr_new_registration_form&form_id="+form_id;
                              }
                           });
        
                        }
                    },
                    cancel: function () {
                        //close
                    },
                },
                onContentReady: function () {
                    // bind to events
                    var jc = this;
                    this.$content.find('form').on('submit', function (e) {
                        // if the user submits the form by pressing enter in the field.
                        e.preventDefault();
                        jc.$$formSubmit.trigger('click'); // reference the button and click it
                    });
                }
            });
        }
    });
});

// Declare jQuery Object to $.
$ = jQuery;

