jQuery(document).ready(function() {
    // from ver 3.6.15 due to conflict with the WP post editor
    // Conflict with WP Customer Area
    /* jQuery(document).tooltip({
        track: true,
        items: ':not(#content_ifr)'
    }); */
    jQuery(".tabsSetting .tabLayer1 > li").hover(
        function() {
            jQuery('ul.tabLayer2').each(function() {
                jQuery(this).css('display', 'none');
            })
            jQuery(this).children('ul.tabLayer2').css('display', 'block');
        },
        function() {
            jQuery('ul.tabLayer2').each(function() {
                jQuery(this).css('display', '');
            });
        }
    );
    jQuery(".piereg_restriction_type").on("click", function() {
        if (jQuery(".piereg_input #redirect").is(":checked")) {
            jQuery(".pieregister_block_content_area").hide();
            jQuery("#pieregister_restriction_url_area").show();
        } else if (jQuery(".piereg_input #block_content").is(":checked")) {
            jQuery("#pieregister_restriction_url_area").hide();
            jQuery(".pieregister_block_content_area").show();
        }
    });
    /**
     * Global Visibility Restrictions
     * Start
     */
     jQuery(".piereg_input_radio a.global_restriction_posts").on("click", function() {
        jQuery("#restrict_post_area").show();
        jQuery("#restrict_page_area").hide();
        jQuery("#restrict_category_area").hide();
        jQuery("#global_restriction_posts").addClass('active-global-restriction-tab');
        jQuery("#global_restriction_pages").removeClass('active-global-restriction-tab');
        jQuery("#global_restriction_categories").removeClass('active-global-restriction-tab');
    });
    jQuery(".piereg_input_radio a.global_restriction_pages").on("click", function() {
        jQuery("#restrict_post_area").hide();
        jQuery("#restrict_page_area").show();
        jQuery("#restrict_category_area").hide();
        jQuery("#global_restriction_posts").removeClass('active-global-restriction-tab');
        jQuery("#global_restriction_pages").addClass('active-global-restriction-tab');
        jQuery("#global_restriction_categories").removeClass('active-global-restriction-tab');
    });
    jQuery(".piereg_input_radio a.global_restriction_categories").on("click", function() {
        jQuery("#restrict_post_area").hide();
        jQuery("#restrict_page_area").hide();
        jQuery("#restrict_category_area").show();
        jQuery("#global_restriction_posts").removeClass('active-global-restriction-tab');
        jQuery("#global_restriction_pages").removeClass('active-global-restriction-tab');
        jQuery("#global_restriction_categories").addClass('active-global-restriction-tab');
    });
    jQuery("#piereg_restrict_all_post_visibility_globally").on("click", function() {
        if (jQuery(this).is(":checked")) {
            jQuery("#exclude_post").each(function(i,obj){
                jQuery(obj).prop('hidden',false);
            });
        }else{
            jQuery("#exclude_post").each(function(i,obj){
                jQuery(obj).prop('hidden',true);
            })
        }
    });
    jQuery("#piereg_restrict_all_page_visibility_globally").on("click", function() {
        if (jQuery(this).is(":checked")) {
            jQuery("#exclude_page").each(function(i,obj){
                jQuery(obj).prop('hidden',false);
            });
        }else{
            jQuery("#exclude_page").each(function(i,obj){
                jQuery(obj).prop('hidden',true);
            })
        }
    });
    jQuery("#piereg_restrict_all_category_visibility_globally").on("click", function() {
        if (jQuery(this).is(":checked")) {
            jQuery("#exclude_category").each(function(i,obj){
                jQuery(obj).prop('hidden',false);
            });
        }else{
            jQuery("#exclude_category").each(function(i,obj){
                jQuery(obj).prop('hidden',true);
            })
        }
    });
    jQuery("#select_all_post").on("click",function(){
		jQuery("#piereg_all_post .pie_register_rw_checkboxs").each(function(i,obj){
			jQuery(obj).prop('checked',true);
		});
	});
	jQuery("#unselect_all_post").on("click",function(){
		jQuery("#piereg_all_post .pie_register_rw_checkboxs").each(function(i,obj){
			jQuery(obj).prop('checked',false);
		});
	});
    jQuery("#select_all_page").on("click",function(){
		jQuery("#piereg_all_page .pie_register_rw_checkboxs").each(function(i,obj){
			jQuery(obj).prop('checked',true);
		});
	});
	jQuery("#unselect_all_page").on("click",function(){
		jQuery("#piereg_all_page .pie_register_rw_checkboxs").each(function(i,obj){
			jQuery(obj).prop('checked',false);
		});
	});
    jQuery("#select_all_category").on("click",function(){
		jQuery("#piereg_all_category .pie_register_rw_checkboxs").each(function(i,obj){
			jQuery(obj).prop('checked',true);
		});
	});
	jQuery("#unselect_all_category").on("click",function(){
		jQuery("#piereg_all_category .pie_register_rw_checkboxs").each(function(i,obj){
			jQuery(obj).prop('checked',false);
		});
	});
    jQuery(".piereg_restrict_post_type_global").on("click", function() {
        if (jQuery(".piereg_input_for_post #redirect").is(":checked")) {
            jQuery(".pieregister_block_content_area_for_post").hide();
            jQuery("#pieregister_restriction_url_area_for_post").show();
        } else if (jQuery(".piereg_input_for_post #block_content").is(":checked")) {
            jQuery("#pieregister_restriction_url_area_for_post").hide();
            jQuery(".pieregister_block_content_area_for_post").show();
        }
    });
    jQuery(".piereg_restrict_page_type_global").on("click", function() {
        if (jQuery(".piereg_input_for_page #redirect").is(":checked")) {
            jQuery(".pieregister_block_content_area_for_page").hide();
            jQuery("#pieregister_restriction_url_area_for_page").show();
        } else if (jQuery(".piereg_input_for_page #block_content").is(":checked")) {
            jQuery("#pieregister_restriction_url_area_for_page").hide();
            jQuery(".pieregister_block_content_area_for_page").show();
        }
    });
    jQuery(".piereg_restrict_category_type_global").on("click", function() {
        if (jQuery(".piereg_input_for_category #redirect").is(":checked")) {
            jQuery(".pieregister_block_content_area_for_category").hide();
            jQuery("#pieregister_restriction_url_area_for_category").show();
        } else if (jQuery(".piereg_input_for_category #block_content").is(":checked")) {
            jQuery("#pieregister_restriction_url_area_for_category").hide();
            jQuery(".pieregister_block_content_area_for_category").show();
        }
    });
    /**
     * Global Visibility Restrictions
     * End
     */

    /**
     * Individual Visibility Restrictions
    */
     jQuery(".piereg_restriction_type").on("click",function()
     {
         checkRestrictionFields();
     });
     jQuery("#piereg_redirect_url, #piereg_redirect_page, #piereg_block_content").on("blur",function()
     {
         checkRestrictionFields();
     });
    jQuery("form#post").submit(function() {
        if (jQuery('#piereg_post_visibility').length > 1) {
            if (jQuery("#piereg_post_visibility").val().trim() != "default") {
                //	Set Defaule Color
                jQuery(".pieregister_restriction_type_area").removeAttr("style");

                var piereg_validate_fields = false;
                //	Validate Restriction Type	
                var restriction_type = false;
                var restriction_value = 0;
                jQuery(".piereg_restriction_type").each(function(i, obj) {
                    var check_local = jQuery(obj).is(":checked");
                    if (check_local) {
                        restriction_type = check_local;
                        restriction_value = jQuery(obj).val();
                    }
                });
                if (!restriction_type) {
                    jQuery(".pieregister_restriction_type_area").css({
                        "color": "rgb(250, 0, 0)"
                    });
                    piereg_validate_fields = true;
                }

                //	Validate Redirect
                var piereg_redirect_url = "";
                var piereg_redirect_page = "";
                if (restriction_value == 0) {
                    piereg_redirect_url = jQuery("#piereg_redirect_url").val();
                    piereg_redirect_page = jQuery("#piereg_redirect_page").val();
                }
                if (piereg_redirect_url != "" || piereg_redirect_page != -1) {

                } else {
                    jQuery(".pieregister_restriction_url_area").css({
                        "color": "rgb(250, 0, 0)"
                    });
                    piereg_validate_fields = true;
                }

                //	Validate Block Content	
                if (jQuery("#piereg_block_content").val().trim() == "" && jQuery(".piereg_input #block_content").is(":checked")) {
                    jQuery(".pieregister_block_content_area").css({
                        "color": "rgb(250, 0, 0)"
                    });
                    piereg_validate_fields = true;
                }

                //	Show Validation Message	
                if (piereg_validate_fields) {

                    var piereg_container = jQuery('html,body'),
                        piereg_scrollTo = jQuery('.pie_register-admin-meta');

                    piereg_container.animate({
                        scrollTop: piereg_scrollTo.offset().top - piereg_container.offset().top + piereg_container.scrollTop()
                    });
                    alert(pie_pr_backend_dec_vars.inValidFields);
                    return false;
                }
            }
        }
	});
	
    var $toplevel_page_pie_register, $toplevel_page_pie_register;
    $toplevel_page_pie_register = document.getElementById('toplevel_page_pie-register');
    $toplevel_page_pie_register = document.getElementsByClassName('toplevel_page_pie-register');
    if ($toplevel_page_pie_register != null && $toplevel_page_pie_register.length != 0 && pie_pr_backend_dec_vars.isPRFormEditor) {
        jQuery("#toplevel_page_pie-register, .toplevel_page_pie-register").removeClass("wp-not-current-submenu").addClass("wp-has-current-submenu wp-menu-open");
        jQuery("#toplevel_page_pie-register li.wp-first-item, #toplevel_page_pie-register a.wp-first-item").addClass("current");
        window.dispatchEvent(new Event('resize'));
    }

    jQuery("#payment_gateway_tabs").tabs();
    jQuery("#notifications_tabs, #blacklisted_tabs, #bulkemails_tabs").tabs();

    // Attachments
    if (jQuery(".attachment").length) {
        jQuery('select[name=form_id]').change(function() {
            window.location = updateQueryStringParameter(location.href, 'form_id', jQuery(this).val());
        })

        jQuery('select[name=pie_attachment_per_page_items]').change(function() {
            jQuery('#attachment_form').submit();
        });

        jQuery('a.pie-btn-download-all-user-documents').click(function() {
            var context = jQuery(this).data("context");

            jQuery('body').Wload({
                text: ' Loading'
            });

            jQuery.ajax({
                url: ajaxurl,
                type: 'post',
                data: {
                    action: 'pie_download_user_files',
                    context: context
                },
                success: function(response) {
                    jQuery('body').Wload('hide', {
                        time: 1000
                    });

                    if (response.status == 0) {
                        alert(response.message);
                    } else {
                        open_tab(response.url);
                    }
                }
            });

            return false;
        });

        jQuery('a.pie-btn-download-current-user-documents').click(function() {
            var context = jQuery(this).data("context");
            var id = jQuery(this).data("id");

            jQuery('body').Wload({
                text: ' Loading'
            });

            jQuery.ajax({
                url: ajaxurl,
                type: 'post',
                data: {
                    action: 'pie_download_user_files',
                    context: context,
                    id: id
                },
                success: function(response) {
                    jQuery('body').Wload('hide', {
                        time: 1000
                    });

                    if (response.status == 0) {
                        alert(response.message);
                    } else {
                        open_tab(response.url);
                    }
                }
            });

            return false;
        });

        // Delete single attachment
        jQuery('a.delete-single-attachment').click(function(e) {
            e.preventDefault();

            var element = jQuery(this);
            var file_to_delete = jQuery(this).prev().attr('href');
            var id     = jQuery(this).data("id");
            var to_del = 'user';
            jQuery.ajax({
                url: ajaxurl,
                type: 'post',
                data: {
                    action: 'pie_del_single_attachment',
                    file_to_delete: file_to_delete,
                    to_del: to_del,
                    id: id
                },
                success: function(response){
                    
                    if(response.status == 1){
                        parent = element.parent().parent();
                        element.parent().remove();
                        if(parent.find('span').length == 1){
                            text = parent.find('span').html();
                            broken_text = text.split(" | ");
                            parent.find('span').html(broken_text[0] + ')');
                            parent.find('a.pie-btn-download-current-user-documents').remove();
                        }
                    }
                }
            });
        });
    }


});

function get_attachment_user_ids() {
    var checked_id = "";
    jQuery(".attachment_users").each(function(i, obj) {
        if ((jQuery(obj).prop('checked')) == true) {
            checked_id = checked_id + jQuery(obj).attr("value") + ",";
        }

    });
    if (checked_id.trim() != "" && jQuery("#attachment_bulk_option").val().trim() != "" && jQuery("#attachment_bulk_option").val() != "0") {
        var status_str = jQuery("#attachment_bulk_option").val();

        if (confirm("Are you sure you want to " + status_str + " selected attachments?") == true) {
            checked_id = checked_id.slice(0, -1);
            jQuery("#select_attachment_bulk_option").val(checked_id);
            return true;
        } else {
            return false;
        }
    } else {
        jQuery("#attachment_error").css("display", "block");
        return false;
    }
}

function addForm() {
    var form_id = jQuery("#pie_forms").val();
    if (form_id == null || form_id == "") {
        alert(pie_pr_backend_dec_vars.plsSelectForm);
        return;
    }
    window.send_to_editor(form_id);
}
// RegFormEdit
var hintNum = 0;
jQuery(document).ready(function(e) {

    var displayhints = pie_pr_backend_dec_vars.display_hints;

    if (displayhints == "1") {
        if (sessionStorage.getItem("hint") != "abc") {
            jQuery("#hint_" + hintNum).delay(500).fadeIn();
        }
        jQuery(".thanks").click(function() {
            jQuery(this).parents(".fields_hint").delay(100).fadeOut();
            hintNum++;
            jQuery("#hint_" + hintNum).delay(500).fadeIn();
            sessionStorage.setItem("hint", "abc");
        });
    } else {
        jQuery(".fields_hint").remove();
    }
});
var defaultMeta = Array();
defaultMeta = pie_pr_backend_dec_vars.defaultMeta;

var append_form_conditionals_fields_start = pie_pr_backend_dec_vars.appFormCondFldsStart;
var append_form_conditionals_fields_end = pie_pr_backend_dec_vars.appFormCondFldsEnd;

jQuery(document).ready(function() {

    /*Append Fields*/
    jQuery(".add_conditional_value_fields").on("click", function() {
        var cl_fields = "";
        var fields_name_and_value_dropdown = "";
        fields_name_and_value_dropdown = get_fields_name_and_value_dropdown(); // if conditional logics enable yes and add more conditions in form settings. 
        cl_fields = append_form_conditionals_fields_start + fields_name_and_value_dropdown + append_form_conditionals_fields_end;
        jQuery(".pie_wrap #form_conditional_area").append(cl_fields);
    });

    /*Delete Fields*/
    jQuery(document).on("click", ".delete_conditional_value_fields", function() {
        jQuery(this).closest(".advance_fields").remove();
    });
});

function get_fields_name_and_value_dropdown() {
    var $option = "";
    jQuery(".fields_position").each(function(i, obj) {
        $fieldName = "";
        $fieldValue = "";
        if (jQuery(obj).children().attr("data-field-post-name"))
            $fieldName = jQuery(obj).children().attr("data-field-post-name");

        if (jQuery(obj).prev(".label_position").children("label").html()) {
            $fieldValue = jQuery(obj).prev(".label_position").children("label").html();
        } else {
            $id_arr = jQuery(obj).attr("id").split("_");
            $fieldValue = jQuery("#field_label_" + $id_arr[2]).children("label").html();
        }
        if ($fieldName != "" && $fieldValue != "") {
            $selected_opt = "";
            if (jQuery("#form_selected_field_value").val() != "" && jQuery("#form_selected_field_value").val() == $fieldName) {
                $selected_opt = 'selected="selected"';
            }
            $option = $option + '<option value="' + $fieldName + '" ' + $selected_opt + '>' + $fieldValue + '</option>';
        }
    });


    return $option;
}
var $fillvalNum = 0;
$fillvalNum = pie_pr_backend_dec_vars.fillvalNum;
if ($fillvalNum > 0) {
    for (i = 0; i < $fillvalNum; i++) {
        fillValues(pie_pr_backend_dec_vars.fillvalValue[i], pie_pr_backend_dec_vars.fillvalKey[i]);
    }
    no = pie_pr_backend_dec_vars.fillvalNo;
}
//////////////////////////////////////////////
jQuery(document).ready(function() {
    var $num, $option;

    if (jQuery(".strength_meter").val() == "1") {
        jQuery(".strength_labels_div").fadeIn();
    } else {
        jQuery(".strength_labels_div").fadeOut();
    }

    jQuery(".strength_meter").on("change", function() {
        if (jQuery(this).val() == "1") {
            jQuery(".strength_labels_div").fadeIn();
        } else {
            jQuery(".strength_labels_div").fadeOut();
        }
    });

    $num = $option = "";

    jQuery(".piereg_registration_form_fields .fields_optionsbg .label_position").each(function(i, obj) {
        $num = jQuery(obj).attr("data-field_id");
        if (piereg.isNumeric($num)) {
            $id = jQuery(obj).attr("id");
            $value = (jQuery("#" + $id + " label").html());
            $option = $option + '<option value="' + $num + '">' + $value + '</option>';
        }


        jQuery("select.selected_field").html($option);
    });

    // conditional logic update - multiple option
    jQuery(".piereg_registration_form_fields").on("change", ".selected_field", function(e) {
        jQuery("#" + jQuery(this).attr("data-selected_field")).val(jQuery(this).val());
    });

    jQuery(".piereg_registration_form_fields .enabel_conditional_logic").on("change", function() {
        if (jQuery(this).val() == "1") {
            var val_conditional_logic_selected_field = jQuery(this).parent().parent().find("select.selected_field").val();
            jQuery("#" + jQuery(this).parent().parent().find("select.selected_field").attr("data-selected_field")).val(val_conditional_logic_selected_field);
        }
    });


    jQuery(".piereg_registration_form_fields .selected_field_input").each(function() {
        $id = jQuery(this).attr("id");
        if (jQuery(this).val() != "") {
            jQuery("select[data-selected_field=" + $id + "]").val(jQuery(this).val());
        }
    });

    jQuery(".piereg_registration_form_fields .enabel_conditional_logic").on("change", function() {
        if (jQuery("#" + jQuery(this).attr("id")).val() == "1") {
            jQuery("div#" + jQuery(this).attr("data-conditional_area")).fadeIn();
            set_field_dropdown("div#" + jQuery(this).attr("data-conditional_area")); // if conditional logics enable change to yes in fields settings. 
            jQuery(this).parent().parent().find(".required").first().after('<span class="message_required"><strong> Note:</strong> Conditional logic, if used, will override this (required) setting. The field will be viewable only when conditional logic is true. Therefore making the field  \'required\' when conditional logic is false has no effect.</span>');
            jQuery(this).parent().parent().find(".show_on").after('<span class="message_required msg_visibility"><strong> Note:</strong> If Conditional Logic is "Yes" then Field Visibility should be selected accordingly.</span>');

        } else {
            jQuery("div#" + jQuery(this).attr("data-conditional_area")).fadeOut();
            jQuery(this).parent().parent().find(".required").next('.message_required').remove();
            jQuery(this).parent().parent().find(".show_on").next('.message_required').remove();
        }
    });
    jQuery(".piereg_registration_form_fields .enabel_conditional_logic").each(function(i, obj) {
        if (jQuery("#" + jQuery(this).attr("id")).val() == "1") {
            jQuery("div#" + jQuery(this).attr("data-conditional_area")).css("display", "block");
            set_field_dropdown("div#" + jQuery(this).attr("data-conditional_area")); // if conditional logics enabled already in fields settings. 
            jQuery(this).parent().parent().find(".required").first().after('<span class="message_required"><strong> Note:</strong> Conditional logic, if used, will override this (required) setting. The field will be viewable only when conditional logic is true. Therefore making the field  \'required\' when conditional logic is false has no effect.</span>');
        } else {
            jQuery("div#" + jQuery(this).attr("data-conditional_area")).css("display", "none");
            jQuery(this).parent().parent().find(".required").next('.message_required').remove();
        }
    });

    /* Allow Only come */
    jQuery("input[type=text].conditional_value_input").keypress(function(e) {
        if (jQuery(this).val().indexOf(",") >= 0) {
            if (e.which == 44 || e.keyCode == 44) {
                return false;
            }
        }
    });


    jQuery("#formeditor .fields").each(function() {
        var find_class          = jQuery(".field_rule_operator_select");
        var select_rule_field   = jQuery(this).find(find_class);

        jQuery(select_rule_field).each(function() {
            if (jQuery(this).val() == "range") {
                jQuery(this).next(".wrap_cond_value").children(".conditional_value_input").after('<span class="form_editor_quotation">Separate by comma ( , )</span>');
            }
    
            if (jQuery(this).val() == "empty" || jQuery(this).val() == "not_empty") {
                jQuery(this).next(".wrap_cond_value").hide();
            }        
        });        
    });

    jQuery(".piereg_registration_form_fields").on('change', 'select.field_rule_operator_select', function() {
        if (jQuery(this).val() == "range") {
            jQuery(this).next(".wrap_cond_value").children(".conditional_value_input").after('<span class="form_editor_quotation">Separate by comma ( , )</span>');
        } else {
            jQuery(this).next(".wrap_cond_value").children(".conditional_value_input").next('.form_editor_quotation').remove();
        }

        if (jQuery(this).val() == "empty" || jQuery(this).val() == "not_empty") {
            jQuery(this).next(".wrap_cond_value").hide();
        } else {
            jQuery(this).next(".wrap_cond_value").show();
        }
    });


    
    jQuery("select.piereg_field_as").on("change", function() {
        /*
        	1	=	Dropdown
        	0	=	Radio
        */
        if (jQuery(this).val() == 1) {
            jQuery(".piereg_pricing_radio").hide();
            jQuery(".piereg_pricing_select").show();
        } else {
            jQuery(".piereg_pricing_select").hide();
            jQuery(".piereg_pricing_radio").show();
        }
    });

    /*
     *	Form Conditional Logic's Script
     */
    $option = "";
    jQuery(".piereg_registration_form_fields .fields_optionsbg .label_position").each(function(i, obj) {

        $num = jQuery(obj).attr("data-field_id");
        if (piereg.isNumeric($num)) {
            $id = jQuery(obj).attr("id");
            $value = (jQuery("#" + $id + " label").html());
            $option = $option + '<option value="' + $num + '">' + $value + '</option>';
        }
    });

    jQuery(".pie_wrap .enabel_conditional_logic_area .enabel_conditional_logic").on("change", function() {
        if (jQuery(this).val() == "1") {
            jQuery("div#" + jQuery(this).attr("data-conditional_area")).fadeIn();
            set_field_dropdown("div#" + jQuery(this).attr("data-conditional_area")); // if change conditional logics enable change to yes in form settings. 
            jQuery(this).parent().parent().find(".required").after('<span class="message_required"><strong> Note:</strong> Conditional logic, if used, will override this (required) setting. The field will be viewable only when conditional logic is true. Therefore making the field  \'required\' when conditional logic is false has no effect.</span>');
        } else {
            jQuery("div#" + jQuery(this).attr("data-conditional_area")).fadeOut();
            jQuery(this).parent().parent().find(".required").next('.message_required').remove();
        }
    });

    jQuery(".pie_wrap .enabel_conditional_logic_area .selected_field").on("change", function() {
        jQuery("#" + jQuery(this).attr("data-selected_field")).val(jQuery(this).val());
    });

    jQuery(".pie_wrap .enabel_conditional_logic_area .selected_field_input").each(function() {
        $id = jQuery(this).attr("id");
        if (jQuery(this).val() != "") {
            jQuery("select[data-selected_field=" + $id + "]").val(jQuery(this).val());
        }
    });


    $option = "";
    jQuery(".fields_position").each(function(i, obj) {
        $fieldName = "";
        $fieldValue = "";
                       
        // FieldName for Custom Role
        if (jQuery(obj).children().attr("id") == "default_custom_role")
            $fieldName = jQuery(obj).children('select').attr("data-field-post-name")

        // FieldName for other Fields
        if (jQuery(obj).children().attr("data-field-post-name"))
            $fieldName = jQuery(obj).children().attr("data-field-post-name");

        if (jQuery(obj).prev(".label_position").children("label").html()) {
            $fieldValue = jQuery(obj).prev(".label_position").children("label").html();
        } else {
            $id_arr = jQuery(obj).attr("id").split("_");
            $fieldValue = jQuery("#field_label_" + $id_arr[2]).children("label").html();
        }
        if ($fieldName != "" && $fieldValue != "") {
            $selected_opt = "";

            if (jQuery("#form_selected_field_value").val() != "" && jQuery("#form_selected_field_value").val() == $fieldName) {
                $selected_opt = 'selected="selected"';
            }
            $option = $option + '<option value="' + $fieldName + '" ' + $selected_opt + '>' + $fieldValue + '</option>';
		}
		
        //form_selected_field
        jQuery("select.form_selected_field").html($option); // Add options to conditional logics select field if applied in form settings. 
    });

    if (jQuery(".iscCnditionalOn").length) {
        jQuery("select.form_selected_field").each(function(i, obj) {
            var selectedVal = jQuery(this).prev('#form_selected_field_value').val();
            jQuery(this).val(selectedVal);

            var ruleOperator = jQuery(obj).next('#form_field_rule_operator');
            if (ruleOperator.val() == "empty") {
                jQuery(ruleOperator).next(".wrap_cond_value").hide();
            }
        });
    }
// conditional logic update - multiple option
/**
 * Backend multi choicese conditional logics
 * Start
 * 
 */

 jQuery(".conditional_area").on( 'click', '.condition-rule-add', function(e) {
       
    ruleAdd(this, e);
    
});

jQuery(".conditional_area").on( 'click', '.condition-rule-remove', function(e) {
   
    ruleRemove(this, e);
    
});

jQuery(".conditional_area").on( 'click', '.condition-rule-or', function(e) {
   
    GroupAdd(this, e);
    
});

function ruleAdd( el, e ) {
    e.preventDefault();
    var $this = jQuery( el ),
    clone = $this.closest('.condition_group').clone();

    clone.find('input').val('');
    clone.find('option:selected').prop('selected', false);
    var ul = $this.closest('.condition_group_wrapper');

    var field_id        = ul.data('field-id');
    var next_id         = ul.attr('data-next-id');
    var current_group   = ul.attr('data-group');

    var panel_name = 'field['+field_id+']';
    clone.attr('data-row', next_id); 
    
    clone.find('.selected_field_input').attr('id', 'selected_field_' + current_group + '_' + next_id + '_' +field_id);
    clone.find('.selected_field').attr('data-selected_field', 'selected_field_' + current_group + '_' + next_id + '_' +field_id);
    
    clone.find('.selected_field_input').attr('name', ''+panel_name+'[conditional][' + current_group + '][' + next_id + '][selected_field]');
    clone.find('.field_rule_operator_select').attr('name', ''+panel_name+'[conditional][' + current_group + '][' + next_id + '][field_rule_operator]');
    clone.find('.conditional_value_input').attr('name', ''+panel_name+'[conditional][' + current_group + '][' + next_id + '][conditional_value]');        
    $this.closest('.condition_group').after(clone);            
    next_id++;
    $this.closest('.condition_group_wrapper').attr('data-next-id',next_id);         
}

function ruleRemove(el,e){
        
        e.preventDefault();
        var $this = jQuery(el),
            container = $this.closest( '.condition_group_wrapper ' ).parent('.conditional_area'),
            ul = $this.closest( '.condition_group_wrapper ' );

        if( 2 > container.find('.condition_group').length ) {

            alert("This item must contain at least one row.");
                
        } else {
            if( ul.find('.condition_group').length < 2 ) {
                $this.closest( '.condition_group_wrapper' ).remove();
            } else {
                $this.closest( '.condition_group' ).remove();
            }
        }
    
}

function GroupAdd( el, e ){
    e.preventDefault();
    var $this  = jQuery( el ),
            
    lastGroup  = $this.siblings('.condition_group_wrapper').first(),
    clone      = lastGroup.clone();
    var field_id = lastGroup.data('field-id');
    
    var panel_name = 'field['+field_id+']';

    clone.find('.condition_group').not(':first').remove();
    clone.find('input').val('');
    clone.find('option:selected').prop('selected', false);
    clone.attr('data-next-id',2);
    var next_id = clone.attr('data-next-id');
    var prevGroup = $this.siblings('.condition_group_wrapper').last().attr('data-group');
    clone.attr( 'data-group', parseInt(prevGroup) + 1 );
    var group = clone.data( 'group' );
    clone.find('.condition_group').attr('data-row', 1);
    
    clone.find('.selected_field_input').attr('id', 'selected_field_' + group + '_' + (next_id - 1) + '_' +field_id);
    clone.find('.selected_field').attr('data-selected_field', 'selected_field_' + group + '_' + (next_id - 1) + '_' +field_id);

    clone.find('.selected_field_input').attr('name', ''+panel_name+'[conditional][' + group + '][' + (next_id - 1) + '][selected_field]');
    clone.find('.field_rule_operator_select').attr('name', ''+panel_name+'[conditional][' + group + '][' + (next_id - 1) + '][field_rule_operator]');
    clone.find('.conditional_value_input').attr('name', ''+panel_name+'[conditional][' + group + '][' + (next_id - 1) + '][conditional_value]');

    var cloned = clone.insertBefore($this);
    cloned.find('.conditional_or').remove();
    cloned.append('<span class="conditional_or">OR</span>');
}
/**
* 
* Backend multi choicese conditional logics
* End * 
*/
});

jQuery(".edit_btn").on("click", function() {
    var curr_conditional_select_field = jQuery(this).closest(".fields").find("select.selected_field");
    if (curr_conditional_select_field) {

        if ((typeof curr_conditional_select_field.val() !== 'undefined') && (curr_conditional_select_field.val() == "" || curr_conditional_select_field.val() == null)) {
            $field_option = "";
            jQuery(".piereg_registration_form_fields .fields_optionsbg .label_position").each(function(i, obj) {

                $num = jQuery(obj).attr("data-field_id");
                if (piereg.isNumeric($num)) {
                    $id = jQuery(obj).attr("id");
                    $value = (jQuery("#" + $id + " label").html());
                    $field_option = $field_option + '<option value="' + $num + '">' + $value + '</option>';
                }


                curr_conditional_select_field.html($field_option); // add options to condtional select fields when click on edit button if empty. 
            });
            $field_option = "";
        } else if (jQuery(this).closest(".fields").find("select.selected_field").val() != "" && jQuery(this).closest(".fields").find("select.selected_field").val() != null) {
            $num = "";
            if (jQuery(this).closest(".fields").find(".delete_btn").attr("rel")) {
                $num = jQuery(this).closest(".fields").find(".delete_btn").attr("rel");
            } else {
                $num = jQuery(this).closest(".fields").find(".label_position").attr("data-field_id");
            }
            jQuery(this).closest(".fields").find("select.selected_field option").each(function(i, obj) {
                if ($num == jQuery(obj).val()) {
                    jQuery(obj).remove();
                }
            });
        }
    }
});

function set_field_dropdown(id) {
    var conditional_select_fields = jQuery(id + "  select.selected_field");
    if (conditional_select_fields.val() == "" || conditional_select_fields.val() == null) {

        $option = "";
        jQuery(".piereg_registration_form_fields .fields_optionsbg .label_position").each(function(i, obj) {
            $num = jQuery(obj).attr("data-field_id");
            if (piereg.isNumeric($num)) {
                $id = jQuery(obj).attr("id");
                $value = (jQuery("#" + $id + " label").html());
                $option = $option + '<option value="' + $num + '">' + $value + '</option>';
            }
        });

        jQuery(conditional_select_fields).find("select.selected_field").html($option);
    }
}
// End RegFormEdit

// Check Restriction fields on Page/Post - admin meta box.
function checkRestrictionFields()
{
    if ( jQuery(".piereg_input #redirect").is(":checked") )
    {
        piereg_redirect_url = jQuery("#piereg_redirect_url").val();
        piereg_redirect_page = jQuery("#piereg_redirect_page").val();

        if ( ( piereg_redirect_url == '' ) && ( piereg_redirect_page == '-1' ) )
        {
            jQuery(".piereg_restriction_msg").fadeIn(1000);
            jQuery('.piereg_restriction_msg').text('Please Provide Either Redirect Page or Redirect URL.');
        }
        else
        {
            jQuery(".piereg_restriction_msg").fadeOut(1000);
        }
    }
    else if ( jQuery(".piereg_input #block_content").is(":checked") )
    {
        if ( jQuery("#piereg_block_content").val().trim() == "" )
        {
            jQuery(".piereg_restriction_msg").fadeIn(1000);
            jQuery('.piereg_restriction_msg').text('Please Provide Block Content.');
        }
        else
        {
            jQuery(".piereg_restriction_msg").fadeOut(1000);
        }
    }
}

// Import Export page
jQuery(document).ready(function(e) {
    piereg_endingDate = new Date();

    jQuery(".pieregister-admin .selectall").change(function() {
        if (jQuery(this).is(":checked")) {
            jQuery(".meta_key").each(function(){
               jQuery(this).prop("checked", true) ;
            });
        } else {
            jQuery(".meta_key").each(function(){
                jQuery(this).prop("checked", false) ;
             });
        }
    });
    jQuery(".pieregister-admin .meta_key").change(function() {
        if (jQuery('.meta_key:checked').length == jQuery('.meta_key').length) {
            jQuery(".selectall").attr("checked", "checked");
        } else {
            jQuery(".selectall").removeAttr("checked");
        }
    });
    dateFormat = 'yy-mm-dd';
    from = jQuery( ".pieregister-admin #date_start" ).datepicker({
        maxDate: piereg_endingDate,
        changeMonth: true,
    }).on( "change", function() {
        to.datepicker( "option", "minDate", jQuery(this).datepicker('getDate') );
    });

    to   = jQuery( ".pieregister-admin #date_end" ).datepicker({
        maxDate: piereg_endingDate,
        changeMonth: true,
    }).on( "change", function() {
        from.datepicker( "option", "maxDate", jQuery(this).datepicker('getDate') );
    });
    jQuery(".pieregister-admin #start_icon").on("click", function() {
        jQuery("#date_start").datepicker("show");
    });
    jQuery(".pieregister-admin #end_icon").on("click", function() {
        jQuery("#date_end").datepicker("show");
    });
    jQuery(".pieregister-admin #export").on("submit", function() {
        if (jQuery('.meta_key:checked').length < 1) {
            alert("Please select at least one field to export.");
            return false;
        }
    });
});
//End Import Export Page
//Invitation Page
function get_selected_box_ids() {
    var checked_id = "";
    jQuery(".invitaion_fields_class").each(function(i, obj) {
        if ((jQuery(obj).prop('checked')) == true) {
            checked_id = checked_id + jQuery(obj).attr("value") + ",";
        }

    });
    if (checked_id.trim() != "" && jQuery("#invitaion_code_bulk_option").val().trim() != "" && jQuery("#invitaion_code_bulk_option").val() != "0") {
        var status_str = jQuery("#invitaion_code_bulk_option").val();

        if (status_str == "unactive") {
            status_str = "deactivate";
        } else if (status_str == "active") {
            status_str = "activate";
        }

        if (confirm("Are you sure you want to " + status_str + " selected invitation code(s).?") == true) {
            checked_id = checked_id.slice(0, -1);
            jQuery("#select_invitaion_code_bulk_option").val(checked_id);
            return true;
        } else {
            return false;
        }
    } else {
        jQuery("#invitaion_code_error").css("display", "block");
        return false;
    }
}

function select_all_invitaion_checkbox() {
    var status = document.getElementById("select_all_invitaion_checkbox").value;
    if (status.trim() == "true") {
        jQuery(".select_all_invitaion_checkbox").val("false");
        jQuery(".invitaion_fields_class").attr("checked", false);
        jQuery(".select_all_invitaion_checkbox").attr("checked", false);
    } else {
        jQuery(".select_all_invitaion_checkbox").val("true");
        jQuery(".invitaion_fields_class").attr("checked", true);
        jQuery(".select_all_invitaion_checkbox").attr("checked", true);
    }
}

function show_field(crnt, val) {
    jQuery("#" + crnt.id).css("display", "none");
    jQuery("#" + val).css("display", "inline-block"); //AQ
    jQuery("#" + val).focus();
}

function hide_datefield(crnt, val) {
    jQuery("#" + crnt.id).css("display", "none");
    jQuery("#" + val).css("display", "inline-block");
} //AQ
function hide_field(crnt, val) {
    jQuery("#" + crnt.id).css("display", "none");
    jQuery("#" + val).css("display", "inline-block"); //AQ
    current = jQuery("#" + crnt.id).val();
    value = jQuery("#" + val).html();
    jQuery("#" + val).html("Please Wait...");
    id = jQuery("#" + crnt.id).attr("data-id-invitationcode");
    type = jQuery("#" + crnt.id).attr("data-type-invitationcode");

    var inv_code_data = {
        method: "post",
        action: 'pireg_update_invitation_code',
        nonce : pieregister_front_admin.nonce,
        data: ({
            "value": jQuery("#" + crnt.id).val(),
            "id": id,
            "type": type
        })
    };
    piereg.post(ajaxurl, inv_code_data, function(response) {
        if (response.trim() == "done") {
            jQuery("#" + val).html(jQuery("#" + crnt.id).val());
        } else if (response.trim() == "duplicate") {
            if (current != value) {
                alert("This code (" + current + ") already exist");
            }
            jQuery("#" + val).html(value);
            jQuery("#" + crnt.id).val(value);
        } else if(response.trim() == "invalid usage"){
            alert("Usage can not be less than the number of times the code is used.");
            jQuery("#" + val).html(value);
            jQuery("#" + crnt.id).val(value);
        } 
        else {
            jQuery("#" + val).html(value);
            jQuery("#" + crnt.id).val(value);
        }
    });
}

function confirmDelInviteCode(id, code) {
    var conf = window.confirm("Are you sure you want to delete this (" + code + ") code?");
    if (conf) {
        document.getElementById("invi_del_id").value = id;
        document.getElementById("del_form").submit();
    }
}

function changeStatusCode(id, code, status) {
    var conf = window.confirm("Are you sure you want to " + status + " this (" + code + ") code ?");
    if (conf) {
        document.getElementById("status_id").value = id;
        document.getElementById("status_form").submit();
    }
}
// email count
function email_popup(id){
    jQuery("#dialog-message_"+id).dialog({
        dialogClass: "email-dialog",
        closeText  : ''
    });
}

jQuery(document).ready(function() {
    jQuery("#invitation_code_per_page_items").change(function() {
        jQuery("#form_invitation_code_per_page_items").submit();
    });
});
jQuery(document).ready(function() {
    jQuery('select[name=invitaion_code_filter]').on("change", function() {
        if (jQuery(this).val() == "4") 
        {
            jQuery(".pr_invitation_code_filer_date_range").fadeIn(1000);
        }else{
            jQuery(".pr_invitation_code_filer_date_range").fadeOut(1000);
        }
        if (jQuery(this).val() == "5") 
        {
            jQuery(".pr_invitation_code_filer_user_role_dropdown").fadeIn(1000);
        }else{
            jQuery(".pr_invitation_code_filer_user_role_dropdown").fadeOut(1000);
        }
    });

    if ( jQuery('select[name=invitaion_code_filter]').val() == "4" ) 
    {
        jQuery(".pr_invitation_code_filer_date_range").css("display", "block");
    }
    if ( jQuery('select[name=invitaion_code_filter]').val() == "5" ) 
    {
        jQuery(".pr_invitation_code_filer_user_role_dropdown").css("display", "block");
    }
    jQuery(".pieregister-admin .invitation #start_icon").on("click", function() {
        jQuery(".date_start").datepicker("show");
    });
    jQuery(".pieregister-admin .invitation #end_icon").on("click", function() {
        jQuery(".date_end").datepicker("show");
    });
});
//End Invitation Page
//User Role Page
function confirmDelUserRole(id, role, key) {
    var conf = window.confirm("Are you sure you want to delete this (" + role + ") role?");
    if (conf) {
        document.getElementById("role_del_id").value   = id;
        document.getElementById("role_del_key").value  = key;
        document.getElementById("del_role_form").submit();
    }
}
function get_selected_roles_ids() {
    var checked_id = "";
    jQuery(".role_fields_class").each(function(i, obj) {
        if ((jQuery(obj).prop('checked')) == true) {
            checked_id = checked_id + jQuery(obj).attr("value") + ",";
        }

    });
    if (checked_id.trim() != "" && jQuery("#custom_role_bulk_option").val().trim() != "" && jQuery("#custom_role_bulk_option").val() != "0") {
        var status_str = jQuery("#custom_role_bulk_option").val();

        if (confirm("Are you sure you want to " + status_str + " selected user role(s)?") == true) {
            checked_id = checked_id.slice(0, -1);
            jQuery("#select_custom_role_bulk_option").val(checked_id);
            return true;
        } else {
            return false;
        }
    } else {
        jQuery("#custom_role_error").css("display", "block");
        return false;
    }
}
function select_all_roles_checkbox() {
    var status = document.getElementById("select_all_roles_checkbox").value;
    if (status.trim() == "true") {
        jQuery(".select_all_roles_checkbox").val("false");
        jQuery(".role_fields_class").attr("checked", false);
        jQuery(".select_all_roles_checkbox").attr("checked", false);
    } else {
        jQuery(".select_all_roles_checkbox").val("true");
        jQuery(".role_fields_class").attr("checked", true);
        jQuery(".select_all_roles_checkbox").attr("checked", true);
    }
}
//End User Role page
//Notification Page
function changediv() {
    var value = jQuery('#user_email_type').val();
    jQuery(".hide-div").hide();
    jQuery("." + value).show();

    if ((jQuery("." + value).css('display') == 'list-item') || (jQuery("." + value).css('display') == 'block')) {
        jQuery(".btnvisibile").show();
    }
}
jQuery(document).ready(function() {
    jQuery('body').on("click", ".notification-item .notification-item-toggler", function(){
        jQuery(this).siblings('.content').slideToggle();
        jQuery(this).toggleClass('active');
        jQuery(this).parents('.notification-item').siblings().find('.content').slideUp();
        jQuery(this).parents('.notification-item').siblings().find('.notification-item-toggler').removeClass('active');
    })
});
jQuery(document).ready(function() {
    piereg(document).on("change", '.enable_admin_notif_chkbox', function() {
        admin_notif_user_role_div = piereg(piereg(this).closest('.notification-item')).find('.admin-notif-user-role-div');
        if (this.checked) {
            admin_notif_user_role_div.fadeIn(1000);
        } else {
            admin_notif_user_role_div.fadeOut(1000);
        }
    });
    piereg('.enable_admin_notif_chkbox').each(function(i,obj){
        admin_notif_user_role_div = piereg(piereg(obj).closest('.notification-item')).find('.admin-notif-user-role-div');
        if ( piereg(obj).attr('checked') ) {            
            admin_notif_user_role_div.fadeIn(1000);
        }else{
            admin_notif_user_role_div.fadeOut(1000);
        }
    });

    // Delegate has been deprecated
    piereg(document).delegate('.enable_admin_notification_checkbox', 'change', function() {
        admin_notification_user_role_dropdown = piereg(piereg(this).closest('.notification-item')).find('.admin_notification_user_role_select_field');
        if (this.checked) {
            admin_notification_user_role_dropdown.fadeIn(1000);
        } else {
            admin_notification_user_role_dropdown.fadeOut(1000);
        }
 
    });
    piereg('.enable_admin_notification_checkbox').each(function(i,obj){
        admin_notification_user_role_dropdown = piereg(piereg(obj).closest('.notification-item')).find('.admin_notification_user_role_select_field');
        if ( piereg(obj).attr('checked') ) {            
            admin_notification_user_role_dropdown.fadeIn(1000);
        }else{
            admin_notification_user_role_dropdown.fadeOut(1000);
        }
    });
});
if (jQuery('.ckeditor').length) {
    jQuery('.ckeditor').each(function() {
        // From PR ver 3.7.0.5 - ckeditor version updated
        // var $this = this;
        // CKEDITOR.replace(jQuery($this).attr("id"), {
        //     removeButtons: 'About'
        // });
    });
}
jQuery(document).ready(function() {
    jQuery('body').on("change", ".piereg_replacement_keys", function() {
        //get the wp_editor
        var $current_ckeditor_id = jQuery(this).closest(".fields").find("textarea.wp-editor-area").prop("id");
        tinymce.get($current_ckeditor_id ).execCommand('mceInsertContent', false, jQuery(this).val().trim());
        jQuery(this).val('select');
    });
    jQuery(".add_new_admin_template").click(function() {
        
        if(jQuery(this).attr('disabled') != 'disabled'){
            jQuery(this).addClass('disabled-new-template');
            jQuery(this).attr("disabled","disabled");
            jQuery('body').Wload({
                text: ' Loading',
            });
    
            var temp_form_ids = jQuery(this).next().val();
            jQuery.ajax({
                url: ajaxurl,
                type: 'post',
                data: {
                    action: 'pie_add_new_template',
                    temp_form_ids: temp_form_ids
                },
                success: function(response) {
                    jQuery('body').Wload('hide', {
                        time: 200
                    });
    
                    if(response.success == true){
                        appendto_element = jQuery(".add_new_admin_template").parent().parent().find('.notification-accordion');
                        appendto_element.append(response.data[0]);
                    }
                },
            });
        }
    });
    jQuery('body').on("change", ".piereg_admin_notification_form", function(){
        
        jQuery('body').Wload({
            text: ' Loading'
        });

        var form_val  = jQuery(this).val();
        var curr_elem = jQuery(this);
        var temp_form_ids = jQuery('.add_new_admin_template').next().val();

        jQuery.ajax({
            url: ajaxurl,
            type: 'post',
            data: {
                action: 'pie_add_new_template',
                formData : form_val,
                temp_form_ids: temp_form_ids
            },
            success: function(response) {
                jQuery('body').Wload('hide', {
                    time: 200
                });

                if(response.success == true){
                    appendto_element = curr_elem.parents('.notification-accordion').find('.notification-item').last();
                    appendto_element.html(response.data[0]);
                    editor_id = response.data[3];
                    wp.editor.initialize( editor_id, {
                        tinymce: {
                            wpautop: false,
                            plugins : 'charmap colorpicker compat3x directionality fullscreen hr image lists media paste tabfocus textcolor wordpress wpautoresize wpdialogs wpeditimage wpemoji wpgallery wplink wptextpattern wpview',
                            toolbar1: 'formatselect bold italic bullist numlist blockquote alignleft aligncenter alignright link wp_more fullscreen wp_adv',
                        },
                        quicktags: {
                            buttons: 'strong,em,link,block,del,ins,img,ul,ol,li,code,close',
                        },
                        mediaButtons: true,
                    });

                    acc_element = appendto_element.find('.notification-item-toggler');
                    acc_element.siblings('.content').slideToggle();
                    acc_element.toggleClass('active');
                    acc_element.parents('.notification-item').siblings().find('.content').slideUp();
                    acc_element.parents('.notification-item').siblings().find('.notification-item-toggler').removeClass('active');
                }
            },
            error: function(response) {
                console.log(response)
            },
        });
    });
    
});

//End Notification page
//Payment gateway
function numbersonly(myfield, e, dec) {
    var key;
    var keychar;

    if (window.event) {
        key = window.event.keyCode;
    } else if (e) {
        key = e.which;
    } else {
        return true;
    }
    keychar = String.fromCharCode(key);

    // control keys
    if ((key == null) || (key == 0) || (key == 8) ||
        (key == 9) || (key == 13) || (key == 27)) {
        return true;
        // numbers
    } else if ((("0123456789").indexOf(keychar) > -1)) {
        return true;

        /* decimal point jump
        else if (dec && (keychar == "."))
		{
		myfield.form.elements[dec].focus();
		return false;
		} */
    } else {
        return false;
    }
}

jQuery(document).ready(function() {
    jQuery(".piereg-payment-log-table").on("click", "tbody tr", function(e) {
        jQuery("." + jQuery(this).attr("data-piereg-id")).fadeToggle(1000);
    });
});
//End payment gateway
//RegForm
function confrm_box(msg, url) {
    if (confirm(msg) == true) {
        window.location.href = url;
    }
}

function previrw_form(msg, url) {
    if (confirm(msg) == true) {
        window.open(url, "_blank", "toolbar=no,scrollbars=yes,menubar=no,resizable=no,location=no,width=" + screen.width + ",height=" + screen.height + "");
    }
}
//End egForm
//Setting All users
jQuery(document).ready(function() {
    jQuery("#after_login").change(function() {

        if (jQuery(this).val() == "url") {
            jQuery(this).parent().next(".fields").show();
        } else {
            jQuery(this).parent().next(".fields").hide();
        }
    })
    jQuery("#alternate_logout").change(function() {
        if (jQuery(this).val() == "url") {
            jQuery(this).parent().next(".fields").show();
        } else {
            jQuery(this).parent().next(".fields").hide();
        }
    })
})

function validateSettings() {
    var block_wp_login = pie_pr_backend_dec_vars.block_wp_login;
    if (block_wp_login == 1 && document.getElementById("alternate_login").value == "-1") {
        alert("Please select an alternate login page.");
        return false;
    }

    if (block_wp_login == 1 && document.getElementById("alternate_register").value == "-1") {
        alert("Please select an alternate register page.");
        return false;
    }

    if (block_wp_login == 1 && document.getElementById("alternate_forgotpass").value == "-1") {
        alert("Please select an alternate forgot password page.");
        return false;
    }
}
//End Settings All users
//Setting RoleBased
jQuery(document).ready(function(e) {

    var length = jQuery('#piereg_user_role').children('option').length;
    if (length == 0) {
        jQuery('#piereg_user_role').prop('disabled', true);
    }

    jQuery("#invitation_code_per_page_items").change(function() {
        jQuery("#form_invitation_code_per_page_items").submit();
    });

    /*Color Change Disable record*/
    jQuery(".inactive").closest("tr").css({
        "background": "rgb(237, 234, 234)"
    });

    jQuery("#log_in_page").change(function() {

        if (jQuery(this).val() == "0") {
            jQuery(this).parent().next(".fields").show();
        } else {
            jQuery(this).parent().next(".fields").hide();
        }
    })
    jQuery("#log_out_page").change(function() {
        if (jQuery(this).val() == "0") {
            jQuery(this).parent().next(".fields").show();
        } else {
            jQuery(this).parent().next(".fields").hide();
        }
    })

});

function changeStatus(id, code, status) {
    var conf = window.confirm("Are you sure you want to " + status + " this record?");
    if (conf) {
        document.getElementById("redirect_settings_status_id").value = id;
        document.getElementById("redirect_settings_status_form").submit();
    }
}

function confirmDel(id, code) {
    var conf = window.confirm("Are you sure you want to delete this (" + code + ") record?");
    if (conf) {
        document.getElementById("redirect_settings_del_id").value = id;
        document.getElementById("redirect_settings_del_form").submit();
    }
}
//End Setting RoleBased
//Setting Security Basic
function validateSettingsSecurity() {
    return piereg_recaptcha_validate();
}

function piereg_recaptcha_validate() {

    var is_error = false;

    if (!jQuery("#captcha_in_login_value_0").is(":checked") && jQuery("#piereg_capthca_in_login").val() != 2) {
        if(jQuery("#piereg_capthca_in_login").val() == 4){
            if (jQuery("#piereg_hCaptcha_Public_Key").val() == "") {
                jQuery("#piereg_hCaptcha_Public_Key_error").show();
                jQuery("#piereg_hCaptcha_Public_Key").css({
                    "border-color": "red"
                });
                jQuery("#piereg_hCaptcha_Public_Key").focus();
                is_error = true;
            } else if (jQuery("#piereg_hCaptcha_Private_Key").val() == "") {
                jQuery("#piereg_hCaptcha_Public_Key_error").show();
                jQuery("#piereg_hCaptcha_Private_Key").focus();
                is_error = true;
            }
        }else{
            if (jQuery("#piereg_reCAPTCHA_Public_Key").val() == "") {
                jQuery("#piereg_reCAPTCHA_Public_Key_error").show();
                jQuery("#piereg_reCAPTCHA_Public_Key").css({
                    "border-color": "red"
                });
                jQuery("#piereg_reCAPTCHA_Public_Key").focus();
                is_error = true;
            } else if (jQuery("#piereg_reCAPTCHA_Private_Key").val() == "") {
                jQuery("#piereg_reCAPTCHA_Public_Key_error").show();
                jQuery("#piereg_reCAPTCHA_Private_Key").focus();
                is_error = true;
            }
        }
    } else if (!jQuery("#captcha_in_forgot_value_0").is(":checked") && jQuery("#piereg_capthca_in_forgot_pass").val() != 2) {
        if(jQuery("#piereg_capthca_in_login").val() == 4){
            if (jQuery("#piereg_hCaptcha_Public_Key").val() == "") {
                jQuery("#piereg_hCaptcha_Public_Key_error").show();
                jQuery("#piereg_hCaptcha_Public_Key").focus();
                is_error = true;
            } else if (jQuery("#piereg_hCaptcha_Private_Key").val() == "") {
                jQuery("#piereg_hCaptcha_Public_Key_error").show();
                jQuery("#piereg_hCaptcha_Private_Key").css({
                    "border-color": "red"
                });
                jQuery("#piereg_hCaptcha_Private_Key").focus();
                is_error = true;
            }
        }else{
            if (jQuery("#piereg_reCAPTCHA_Public_Key").val() == "") {
                jQuery("#piereg_reCAPTCHA_Public_Key_error").show();
                jQuery("#piereg_reCAPTCHA_Public_Key").focus();
                is_error = true;
            } else if (jQuery("#piereg_reCAPTCHA_Private_Key").val() == "") {
                jQuery("#piereg_reCAPTCHA_Public_Key_error").show();
                jQuery("#piereg_reCAPTCHA_Private_Key").css({
                    "border-color": "red"
                });
                jQuery("#piereg_reCAPTCHA_Private_Key").focus();
                is_error = true;
            }
        }
    } else {
        jQuery("#piereg_reCAPTCHA_Public_Key_error").hide();
        jQuery("#piereg_reCAPTCHA_Private_Key").css({
            "border-color": ""
        });
    }

    if (jQuery("#piereg_reCAPTCHA_Private_Key").val() != "" || jQuery("#piereg_reCAPTCHA_Public_Key").val()) {
        var patt1 = /[0-9a-zA-Z_-]{40}/;


        if (!jQuery("#piereg_reCAPTCHA_Public_Key").val().match(patt1)) {

            if (!jQuery("#tabs_5").is(":visible")) {
                jQuery("#ui-id-5").click();
            }

            jQuery("#piereg_reCAPTCHA_Public_Key").css({
                "color": "red"
            });
            jQuery("#piereg_reCAPTCHA_Public_Key").focus();
            jQuery("#piereg_reCAPTCHA_Public_Key_error").show();
            is_error = true;
        } else if (!jQuery("#piereg_reCAPTCHA_Private_Key").val().match(patt1)) {
            if (!jQuery("#tabs_5").is(":visible")) {
                jQuery("#ui-id-5").click();
            }
            jQuery("#piereg_reCAPTCHA_Private_Key").css({
                "color": "red"
            });
            jQuery("#piereg_reCAPTCHA_Private_Key").focus();
            jQuery("#piereg_reCAPTCHA_Public_Key_error").show();
            is_error = true;
        }
    }

    if (is_error) {
        return false;
    } else {
        return true;
    }
}

function piereg_deactivate_keys_Form(form) {
    if (confirm('Are you sure you want to deactivate the plugin license?')) {
        form.submit_btn.disabled = true;
        form.submit();
        return true;
    }
    return false;
}
jQuery(document).ready(function() {
    /* LockOut User */
    jQuery(".piereg_security_attempts_login_value").on("change", function() {
        if (jQuery(this).is(":checked")) {
            jQuery(".lockout_user_login_form").fadeIn(1000);
        } else {
            jQuery(".lockout_user_login_form").fadeOut(1000);
        }
    });
    jQuery(".piereg_security_attempts_forgot_value").on("change", function() {
        if (jQuery(this).is(":checked")) {
            jQuery(".lockout_user_forgot_pass_form").fadeIn(1000);
        } else {
            jQuery(".lockout_user_forgot_pass_form").fadeOut(1000);
        }
    });

    /* Validate recaptcha error */
    jQuery(".piereg-gs-menu-btn").on("click", function() {
        return piereg_recaptcha_validate();
    });

    /* Login Form Captcha */
    jQuery(".captcha_in_login_value").on("change", function() {
        captcha_show();
    });
    captcha_show();

    function captcha_show() {
        if (jQuery("#captcha_in_login_value_1").is(":checked")) {
            jQuery("#label_captcha_in_login_attempts").fadeIn(1000);
            jQuery(".piereg_captcha_label_show").fadeIn(1000);
            jQuery(".piereg_captcha_type_show").fadeIn(1000);
            if (jQuery("#piereg_capthca_in_login").val() == 1 && !jQuery("#captcha_in_login_value_0").is(":checked")) {
                jQuery(".piereg_recapthca_skin_login").fadeIn(1000);
                jQuery("#note_quotation").fadeIn(1000);
            }
        } else if (jQuery("#captcha_in_login_value_0").is(":checked")) {
            jQuery("#label_captcha_in_login_attempts").fadeOut(1000);
            jQuery(".piereg_captcha_label_show").fadeOut(1000);
            jQuery(".piereg_captcha_type_show").fadeOut(1000);
            jQuery(".piereg_recapthca_skin_login").fadeOut(1000);
            jQuery("#note_quotation").fadeOut(1000);
        }
    }

    /* Login Form Captcha Type */
    jQuery("#piereg_capthca_in_login").on("change", function() {
        if (jQuery(this).val() == 1 && !jQuery("#captcha_in_login_value_0").is(":checked")) {
            jQuery(".piereg_recapthca_skin_login").fadeIn(1000);
            jQuery("#note_quotation").fadeIn(1000);
        } else {
            jQuery(".piereg_recapthca_skin_login").fadeOut(1000);
            jQuery("#note_quotation").fadeOut(1000);
        }
    });

    /* Forgot Password Form Captcha */
    jQuery(".captcha_in_forgot_value").on("change", function() {
        captcha_forgot_show();
    });
    captcha_forgot_show();

    function captcha_forgot_show() {
        if (jQuery("#captcha_in_forgot_value_1").is(":checked")) {
            jQuery(".piereg_capthca_forgot_pass_label_show").fadeIn(1000);
            jQuery(".piereg_captcha_forgot_pass_type_show").fadeIn(1000);
            if (jQuery("#piereg_capthca_in_forgot_pass").val() == 1 && !jQuery("#captcha_in_forgot_value_0").is(":checked")) {
                jQuery(".piereg_recapthca_skin_forgot_pas").fadeIn(1000);
                jQuery("#for_note_quotation").fadeIn(1000);
            }
        } else if (jQuery("#captcha_in_forgot_value_0").is(":checked")) {
            jQuery(".piereg_capthca_forgot_pass_label_show").fadeOut(1000);
            jQuery(".piereg_captcha_forgot_pass_type_show").fadeOut(1000);
            jQuery(".piereg_recapthca_skin_forgot_pas").fadeOut(1000);
            jQuery("#for_note_quotation").fadeOut(1000);
        }
    }

    /* Forgot Password Form Captcha Type */
    jQuery("#piereg_capthca_in_forgot_pass").on("change", function() {
        if (jQuery(this).val() == 1 && !jQuery("#captcha_in_forgot_value_0").is(":checked")) {
            jQuery(".piereg_recapthca_skin_forgot_pas").fadeIn(1000);
            jQuery("#for_note_quotation").fadeIn(1000);
        } else {
            jQuery(".piereg_recapthca_skin_forgot_pas").fadeOut(1000);
            jQuery("#for_note_quotation").fadeOut(1000);
        }
    });
    // Selection of reCAPTCHA v2/v3
    jQuery( 'select.piereg_recaptcha_type' ).change( function() {
        var recaptcha_v2_site_key   = jQuery( '#piereg_reCAPTCHA_Public_Key' ).parents( 'div.fields' ).eq( 0 ),
            recaptcha_v2_secret_key = jQuery( '#piereg_reCAPTCHA_Private_Key' ).parents( 'div.fields' ).eq( 0 ),
            recaptcha_v3_site_key   = jQuery( '#piereg_reCAPTCHA_Public_Key_v3' ).parents( 'div.fields' ).eq( 0 ),
            recaptcha_v3_secret_key = jQuery( '#piereg_reCAPTCHA_Private_Key_v3' ).parents( 'div.fields' ).eq( 0 );
        
        if ( 'v2' === jQuery( this ).val() ) {
            recaptcha_v2_site_key.show();
            recaptcha_v2_secret_key.show();
            recaptcha_v3_site_key.hide();
            recaptcha_v3_secret_key.hide();
        } else {
            recaptcha_v2_site_key.hide();
            recaptcha_v2_secret_key.hide();
            recaptcha_v3_site_key.show();
            recaptcha_v3_secret_key.show();
        }
    }).change();

    /* Notice Slider */
    var current_notice  = jQuery('#wp-admin-bar-pie_register').find('.piereg-notice-num');
    if(current_notice.text() > 1){
        var $slickElement = jQuery('.piereg-notice-slider');

        $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
            //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
            var i = (currentSlide ? currentSlide : 0) + 1;
        
        });
        
        $slickElement.slick({
            slide: 'div',
            swipe: false,
            autoplay: false,
            dots: false,
            adaptiveHeight: true
        });
    }

    jQuery(document.body).on( 'click', '.notice-dismiss', function( event, el ) {
        var $notice         = jQuery(this).parent('.notice.is-dismissible');
        var dismiss_url     = $notice.attr('data-dismiss-url');
        
        current_notice.text(current_notice.text() - 1);
        var current_notice_  = jQuery('.wp-menu-name').find('.piereg-notice-num');
        current_notice_.text(current_notice_.text() - 1);
        var current_notice__  = jQuery('.wp-submenu').find('li:last-child').find('.piereg-notice-num');
        current_notice__.text(current_notice__.text() - 1);
         
        i = jQuery(".piereg-notice.slick-active").attr("data-slick-index");
        if($slickElement != undefined){
            // $slickElement.slick('slickRemove', i);
            $slickElement.not('.slick-initialized').slick();
        }
        var j = 0;
        jQuery(".piereg-notice.slick-slide").each(function(){
            jQuery(this).attr("data-slick-index",j);
            j++;
        });


        if(current_notice.text() == 1){
            jQuery('.piereg-notice-slider').find('.slick-prev.slick-arrow').hide();
            jQuery('.piereg-notice-slider').find('.slick-next.slick-arrow').hide();
        }

        if(current_notice.text() == 0){
            jQuery('.piereg-notice-slider').hide();
            current_notice.hide();
            current_notice_.hide();
            current_notice__.hide();
        }
        if(dismiss_url){
            $.get( dismiss_url );
        }
        
    });

    /* Reason for rejecting user verification */
    jQuery("#pie-unverified-users #bulk-action-selector-top").on("change", function() {
        if (jQuery(this).val() == 'delete' ) {
            jQuery(".piereg_user_verification_rejected_reason_container").fadeIn(1000);
        } else {
            jQuery(".piereg_user_verification_rejected_reason_container").fadeOut(1000);
        }
    });
});
//End Setting Security basic