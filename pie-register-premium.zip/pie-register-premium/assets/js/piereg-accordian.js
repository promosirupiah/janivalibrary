var piereg = jQuery.noConflict();

piereg(document).ready(function($) {
    (function($){
        var $piereg_pro_is_activate = pie_pr_dec_vars.piereg_pro_is_activate;
        // Accordian for CAPTCHA selection and settings
        piereg( ".captcha-settings" ).accordion({
            collapsible: true,
            active : 'none'
        });

        // Enable reCAPTCHA
        recaptcha = piereg('.piereg_enable_recaptcha');

        // Enable hCaptcha
        hcaptcha  = piereg('.piereg_enable_hcaptcha');

        if(recaptcha.is(":checked")){
            hcaptcha.prop("checked", false);
            hcaptcha.prop('disabled', true);
        }else if(hcaptcha.is(":checked")){
            if(!$piereg_pro_is_activate){
                hcaptcha.prop("checked", false);
                hcaptcha.prop('disabled', true);
            }else if($piereg_pro_is_activate){
                recaptcha.prop("checked", false);
                recaptcha.prop('disabled', true);
            }
        }

        if(!$piereg_pro_is_activate){
            hcaptcha.prop("checked", false);
            hcaptcha.prop('disabled', true);
        }

        piereg(recaptcha).on('click', function(){
            if($piereg_pro_is_activate){
                check_captcha_enabled(recaptcha, hcaptcha);
            }
        });

        piereg(hcaptcha).on('click', function(){
            if($piereg_pro_is_activate){
                check_captcha_enabled(hcaptcha, recaptcha);
            }
        });

    })(jQuery);
});

// Only allowing one of the CAPTCHAs to be enabled 
function check_captcha_enabled(captcha_to_check, other_captcha, on_load = ''){
    captcha_stats = captcha_to_check.is(":checked");

    if(captcha_stats){
        other_captcha.prop("checked", false);
        other_captcha.prop('disabled', true);
    }else{
        other_captcha.prop('disabled', false);
    }
}

// Declare jQuery Object to $.
$ = jQuery;