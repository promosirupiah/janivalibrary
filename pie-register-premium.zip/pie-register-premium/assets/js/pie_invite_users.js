 // User Invitation
 var piereg = jQuery.noConflict();

piereg(document).ready(function($) {

    var access_invitation_codes = piereg('#access_invitation_codes').val();

    if (piereg("#enable_user_invitation").is(":checked")) 
    {
        piereg(".user_invitation_settings_div").show();
    } 
    else 
    {
        piereg(".user_invitation_settings_div").hide();
    }
    if (piereg("#user_invitation_add_capability_1").is(":checked")) 
    {
        piereg(".allow_specific_roles_settings_div").show();
        piereg(".allow_specific_users_div").hide();
        piereg(".remove_capability_from_specific_users_div").show();
    } 
    else if (piereg("#user_invitation_add_capability_2").is(":checked")) 
    {
        piereg(".allow_specific_users_div").show();
        piereg(".allow_specific_roles_settings_div").hide();
        piereg(".remove_capability_from_specific_users_div").hide();
    } 
    else 
    {
        piereg(".allow_specific_roles_settings_div").hide();
        piereg(".allow_specific_users_div").hide();
        piereg(".remove_capability_from_specific_users_div").show();
    }
    piereg('#enable_user_invitation').on("change", function() 
    {
        if (piereg(this).is(":checked")) 
        {
            piereg(".user_invitation_settings_div").fadeIn(1000);
        }
        else
        {
            piereg(".user_invitation_settings_div").fadeOut(1000);
        }
    });
    piereg('#user_invitation_add_capability_1').on("change", function() 
    {
        if (piereg(this).is(":checked")) 
        {
            piereg(".allow_specific_roles_settings_div").fadeIn(1000);
            piereg(".allow_specific_users_div").fadeOut(1000);
            piereg(".remove_capability_from_specific_users_div").fadeIn(1000);
        }
        else
        {
            piereg(".allow_specific_roles_settings_div").fadeOut(1000);
        }
    });
    piereg('#user_invitation_add_capability_0').on("change", function() 
    {
        if (piereg(this).is(":checked")) 
        {
            piereg(".allow_specific_roles_settings_div").fadeOut(1000);
            piereg(".allow_specific_users_div").fadeOut(1000);
            piereg(".remove_capability_from_specific_users_div").fadeIn(1000);
        }
    });
    piereg('#user_invitation_add_capability_2').on("change", function() 
    {
        if (piereg(this).is(":checked")) 
        {
            piereg(".allow_specific_users_div").fadeIn(1000);
            piereg(".allow_specific_roles_settings_div").fadeOut(1000);
            piereg(".remove_capability_from_specific_users_div").fadeOut(1000);
        }
    });
    piereg("#access_invitation_codes").change(function() {

        var access_invitation_codes = piereg('#access_invitation_codes').val();
        
        if( (piereg.inArray("allow_user_generate_raw_codes", access_invitation_codes) !== -1) || (piereg.inArray("allow_user_auto_generate_codes", access_invitation_codes) !== -1))
        {
            piereg(".limit_user_invitation_field").fadeIn(1000);
        }
        else
        {
            piereg(".limit_user_invitation_field").fadeOut(1000);
        }
        if( (piereg.inArray("allow_user_invite_through_email", access_invitation_codes) !== -1))
        {
            piereg(".limit_email_invites_field").fadeIn(1000);
            piereg(".registration_page_user_invitation").fadeIn(1000);
        }
        else
        {
            piereg(".limit_email_invites_field").fadeOut(1000);
            piereg(".registration_page_user_invitation").fadeOut(1000);
        }
    });
    if( (piereg.inArray("allow_user_generate_raw_codes", access_invitation_codes) !== -1) || (piereg.inArray("allow_user_auto_generate_codes", access_invitation_codes) !== -1))
    {
        piereg(".limit_user_invitation_field").show();
    }
    else
    {
        piereg(".limit_user_invitation_field").hide();
    }
    if( (piereg.inArray("allow_user_invite_through_email", access_invitation_codes) !== -1))
    {
        piereg(".limit_email_invites_field").show();
        piereg(".registration_page_user_invitation").show();
    }
    else
    {
        piereg(".limit_email_invites_field").hide();
        piereg(".registration_page_user_invitation").hide();
    }
});

function piereg_show_more_registered_users(current_row)
{
    piereg(current_row).closest('tr').find(".hidden_email_address"). css("display", "block");
    piereg(current_row).closest('tr').find(".invite_users_view_more"). css("display", "none");
}

// Declare jQuery Object to $.
$ = jQuery;

