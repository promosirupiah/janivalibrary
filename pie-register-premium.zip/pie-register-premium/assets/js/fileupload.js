 // File Upload - DropZone
 var piereg = jQuery.noConflict();

piereg(document).ready(function($) {
    (function($) {
        piereg('.pr-field-fileupload').each(function(){

            var form_id                 = piereg('form.pie_register_reg_form').attr('data-form');
            var edit_user_id            = piereg('#edit_user_id').attr('value');
            var data                    = piereg(this).find('.dz-clickable');
            var field_id                = data.attr('id');
            var max_file_size           = parseInt(data.attr('data-max-file-size')) / 1000; // KB to MB Conversion
            var max_uploads             = parseInt(data.attr('data-max-files'));
            var required                = parseInt(data.attr('data-required'));
            var allowed_file_ext        = data.attr('data-allowed-file-ext');
            var unique_class            = data.attr('data-unique-class');
            var fileList                = {};

            allowed_file_ext =  allowed_file_ext.split( ',' ).map(function(e){
                return '.'+ $.trim(e);
            }).join(',');

            Dropzone.autoDiscover = false;

            var zdrop = new Dropzone('.'+unique_class, {

                url: pr_data.ajax_url,
                addRemoveLinks: true,
                maxFiles: max_uploads,
                maxFilesize: max_file_size,
                acceptedFiles: allowed_file_ext,
                dictFileTooBig: "File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",

                // On init, fetch User Uploaded files and Refresh Directory
                init: function() {

                    var ajaxdata = {
                        action: 'pie_register_file_upload',
                        request: 'fetch',
                        field_slug: field_id,
                        edit_user_id: edit_user_id,
                    };

                    jQuery.post(pr_data.ajax_url, ajaxdata).done(function(response){

                        response = JSON.parse(response);

                        jQuery.each(response, function(key,value) {

                            var ext = value.name.split('.').pop();
                            var mockFile = { name: value.name, size: value.size, dataURL: value.path, accepted: true};

                            fileList[value.name] = {"serverFileName" : value.name, "fileName" : value.name };
                            piereg(piereg('.'+unique_class).closest('.pr-field-fileupload').find('#pie_register_fileList_' + field_id)).val(JSON.stringify(fileList));

                            zdrop.files.push(mockFile);
                            zdrop.emit("addedfile", mockFile);
                            zdrop.emit("complete", mockFile);

                            // For image files, thumbnail of file is same as image.
                            if ( (ext == "png") || (ext == "PNG") || (ext == "jpeg") || (ext == "jpg") ) {
                                zdrop.emit("thumbnail", mockFile, value.path);
                                zdrop.createThumbnailFromUrl(mockFile,
                                    zdrop.options.thumbnailWidth, zdrop.options.thumbnailHeight,
                                    zdrop.options.thumbnailMethod, true, function (thumbnail) {
                                        zdrop.emit('thumbnail', mockFile, thumbnail);
                                });
                            }

                            // //If readonly enabled disable remove file icon
                            if ( piereg('#'+field_id).hasClass("readonlyEnabled") ) 
                            {
                                piereg(piereg('#'+field_id).find(".dz-remove")).css({'pointer-events': 'none'});
                            }  
                            });
                    }, 'json' );

                    if (typeof edit_user_id === "undefined")
                    {
                        var ajaxcheckDirectory = {
                            action: 'pie_register_file_upload',
                            request: 'checkDirectory',
                            field_slug: field_id,
                        };

                        jQuery.post(pr_data.ajax_url, ajaxcheckDirectory);
                    } 
                    else
                    {
                        var ajaxcheckDirectory = {
                            action: 'pie_register_file_upload',
                            request: 'checkDirectoryEditUser',
                            field_slug: field_id,
                            edit_user_id: edit_user_id,
                        };

                        jQuery.post(pr_data.ajax_url, ajaxcheckDirectory);
                    }
                },

            });

            // Event triggers on uploading file
            zdrop.on("sending", function (file, xhr, formData) {

                request = "uploadOnRegistration";

                if (typeof edit_user_id != "undefined")
                {
                    form_id  = piereg('select[name="pie_form_assign"]').val();
                    request = "uploadOnEditProfile";

                    if (typeof form_id == "undefined")
                    {
                        form_id = piereg('#edit_user_id').attr('data-form-id');
                    }

                    formData.append('user_id', edit_user_id);
                }
                
                formData.append('action', 'pie_register_file_upload');
                formData.append('request',request);
                formData.append('form_id',form_id);
                formData.append('field_slug',field_id);
            });

            // Event triggers on file removal
            zdrop.on("removedfile", function (file, xhr, formData) {


                delete fileList[file.name];
                if ( zdrop.files.length )
                {
                    piereg(piereg('.'+unique_class).closest('.pr-field-fileupload').find('#pie_register_fileList_' + field_id)).val(JSON.stringify(fileList));
                } else {
                    piereg(piereg('.'+unique_class).closest('.pr-field-fileupload').find('#pie_register_fileList_' + field_id)).val('');
                }

            });

            zdrop.on("success", function(file, serverFileName) {
                
                fileList[file.name] = {"serverFileName" : serverFileName, "fileName" : file.name };
                piereg(piereg('.'+unique_class).closest('.pr-field-fileupload').find('#pie_register_fileList_' + field_id)).val(JSON.stringify(fileList));

                if (piereg('#'+field_id).find('.dz-success') ) 
                {
                    piereg( this.element.parentElement ).removeClass( "error" );
                    piereg( this.element.parentElement ).find('span.error').hide();

                    piereg( file.previewElement ).find('.dz-error-message').addClass("upload_completed");
                    piereg( file.previewElement ).find('.dz-error-message').html("Uploaded Successfully");
                }
            });

            // Thumbnail for files other than jpeg, jpg, png
            zdrop.on('addedfile', function(file) {

                var ext = file.name.split('.').pop();

                if (ext == "pdf") {
                    piereg(file.previewElement).find(".dz-image img").attr("src", piereg('.pr-field-fileupload').attr('data-img-src') + "pdf.png" );
                } else if (ext.indexOf("doc") != -1) {
                    piereg(file.previewElement).find(".dz-image img").attr("src", piereg('.pr-field-fileupload').attr('data-img-src') + "doc.png" );
                } else if (ext.indexOf("xls") != -1) {
                    piereg(file.previewElement).find(".dz-image img").attr("src", piereg('.pr-field-fileupload').attr('data-img-src') + "excel.png" );
                }
            });
            zdrop.on("maxfilesexceeded", function(file){
                piereg( this.element.parentElement ).find('.pie-register-upload-limit-exceeded').show();
                zdrop.removeFile(file);
            });

            //If readonly enabled, disable dropzone.
            if ( piereg('#'+field_id).hasClass("readonlyEnabled") ) 
            {
                zdrop.removeEventListeners();
            }
        });

    })(jQuery);
});

// Declare jQuery Object to $.
$ = jQuery;

