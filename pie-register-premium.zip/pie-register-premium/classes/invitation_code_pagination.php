<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( !class_exists( 'WP_List_Table' ) )
    require_once( $this->admin_path  . 'includes/class-wp-list-table.php' );

class Pie_Invitation_Table extends WP_List_Table
{
    private $order;
    private $orderby;
    private $piereg_pro_is_activate = false;
    private $user_tracker_grid = false;
    public function __construct()
    {
        parent :: __construct( array(
            'singular' => 'table example',
            'plural'   => 'table examples',
            'ajax'     => true
        ) );
        $pieregisterClass = new PieRegister();
        $this->piereg_pro_is_activate = $pieregisterClass->piereg_pro_is_activate();

        // Checks if currently on user tracker tab. 
        $this->user_tracker_grid = $this->piereg_on_user_tracker();
    }
    private function get_sql_results()
    {
        global $wpdb;
        $search = "";
        $searchByCodeName = "";
        $prefix=$wpdb->prefix."pieregister_";
        $codetable=$prefix."code";
        $usertable=$this->userInvitationCodeTable(); 
       
        $innerJoin               = $this->apply_inner_join($codetable,$usertable);
        $filterGridByCurrentUser = $this->filterGridByCurrentUser($usertable,$codetable);
        $sql_operator_and        = !empty($filterGridByCurrentUser) ? ' AND ' : '';
        $where_clause            = !empty($filterGridByCurrentUser) ? ' WHERE ' : '';
        $group_by                = !empty($filterGridByCurrentUser) ? "GROUP BY ".$codetable.".id" : '';

        $args = array( $codetable.".id", "`name`","`code_description`", "`code_usage`","`expiry_date`","`code_user_role`", "`count`","`status`" ); 
        
        $sql_select = implode( ', ', $args );

        $update = get_option(OPTION_PIE_REGISTER);
		$order_by 	 = sanitize_sql_orderby("`$this->orderby` $this->order");	// Ensures a string is a valid SQL order by clause.
		if( $order_by === false )
		{
			$order_by = "`id` DESC";
		}
        if ( isset($_POST['btn_submit_invitaion_code_filter']) )
        {
            $update['btn_submit_invitaion_code_filter'] = sanitize_key($_POST['btn_submit_invitaion_code_filter']);
        } 
        else if ( isset($_GET['search']) )
        {
            $update['btn_submit_invitaion_code_filter'] = '0';
        }
        if ( $update['btn_submit_invitaion_code_filter'] !== '0' )
        {
            if ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 1 ) ) { 
                $filterCode   = "WHERE (`count` = `code_usage`) AND (`code_usage` != 0)";
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $filterCode $sql_operator_and $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action");
            } else if ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 2 ) ) {   
                $filterCode   = "WHERE ((`count` != `code_usage`) OR (`code_usage` = 0))";
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $filterCode $sql_operator_and $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action");
            } else if ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 3 ) ) {   
                $filterCode   = 'WHERE ( `expiry_date` < %s ) && ( `expiry_date` > 0000-00-00 )';
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $filterCode $sql_operator_and $filterGridByCurrentUser $group_by  ORDER BY $order_by", "check_box", "email_invite", "action",date("Y-m-d"));    
            } else if ( isset($update['invitaion_code_filter']) && ( intval($update["invitaion_code_filter"]) == 4 ) && ( isset($update['invitaion_code_filter_date_start'] )) && ( isset($update['invitaion_code_filter_date_end'] )) && ( !empty($update['invitaion_code_filter_date_start'] )) && ( !empty($update['invitaion_code_filter_date_end'] )) ) {   
                $date_start 	= date_i18n("Y-m-d",strtotime($update['invitaion_code_filter_date_start']));
                $date_end 		= date_i18n("Y-m-d",strtotime($update['invitaion_code_filter_date_end']));
                $filterCode   = 'WHERE `created` >= %s AND `created` <= %s';
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $filterCode $sql_operator_and $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action",$date_start,$date_end);
            } else if ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 5 ) && isset($update['invitation_code_filer_user_role']) && !empty($update['invitation_code_filer_user_role']) ) {
                $filterCode   = 'WHERE `code_user_role` = %s';
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $filterCode $sql_operator_and $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action",$update['invitation_code_filer_user_role']);    
            }else {
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $searchByCodeName $where_clause $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action");
            }
        } else
        {
            $searchByCodeName   = "WHERE ( `name` LIKE %s )";
            
            if (isset($_GET['search']) && $_GET['search']) {
                $search             = htmlentities(sanitize_text_field(trim( wp_unslash($_GET['search']))));
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $searchByCodeName $sql_operator_and $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action", '%' . $search . '%');
            } else {
                $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,%s as 'email_invite',%s as `action` FROM `$codetable` $innerJoin $searchByCodeName $sql_operator_and $filterGridByCurrentUser $group_by ORDER BY $order_by", "check_box", "email_invite", "action", '%' . $search . '%');
            }
        }
        $sql_results = $wpdb->get_results( $query );

        return $sql_results;
    }
    private function get_sql_results_usertracker()
    {
        global $wpdb;

        $prefix=$wpdb->prefix."pieregister_";
        $codetable=$prefix."code";
        $wp_users_table=$wpdb->prefix."users";
        $usertable=$this->userInvitationCodeTable(); 

        $args = array( $codetable.".`id`","`name`","`code_usage`","`expiry_date`", "`count`","`status`" ); 
        $sql_select = implode( ', ', $args );
        $update   = get_option(OPTION_PIE_REGISTER);
		$order_by = sanitize_sql_orderby("`$this->orderby` $this->order");
        $search   = $this->user_tracker_grid && isset($_POST['user-tracker-search-input']) ? htmlentities(sanitize_text_field(trim( wp_unslash($_POST['user-tracker-search-input'])))) : '';
        $searchByCodeName = $this->user_tracker_grid ? "WHERE ( `name` LIKE %s )" : '';

        if( $order_by === false )
		{
			$order_by = $usertable."`id` DESC";
		}

        $query = $wpdb->prepare("SELECT %s as `check_box`,$sql_select,`user_id` as 'created_by',`registered_user` as 'registered_user',%s as `action` FROM `$codetable` INNER JOIN $usertable ON $codetable.id = $usertable.code_id  $searchByCodeName GROUP BY `code_id` ORDER BY $usertable.id DESC", "check_box","action", '%' . $wpdb->esc_like($search) . '%');

        $sql_results = $wpdb->get_results( $query );

        return $sql_results;
    }
    public function set_order()
    {
        $order = 'DESC';
        if ( isset( $_GET['order'] ) && $_GET['order'] )
            $order = sanitize_key($_GET['order']);
        $this->order = $order;	// Lowercase alphanumeric characters, dashes and underscores are allowed
    }
    public function set_orderby()
    {
        $orderby = 'id';
        if ( isset( $_GET['orderby'] ) && $_GET['orderby'] )
            $orderby = sanitize_key($_GET['orderby']);
        $this->orderby = $orderby;	// Lowercase alphanumeric characters, dashes and underscores are allowed
    }
    public function search_box($text, $input_id)
    {
        if (empty($_REQUEST['search']) && !$this->has_items()){
            return;
        }

        $input_id = $input_id . '-search-input';
        ?>
            <form id="pie-invite-search" class="pie-invite-search" method="GET">
                <?php 

                    if (!empty($_REQUEST['orderby']))
                        echo '<input type="hidden" name="orderby" value="' . esc_attr($_REQUEST['orderby']) . '" />';
                    if (!empty($_REQUEST['order']))
                        echo '<input type="hidden" name="order" value="' . esc_attr($_REQUEST['order']) . '" />';
                    if (!empty($_REQUEST['page']))
                        echo '<input type="hidden" name="page" value="' . esc_attr($_REQUEST['page']) . '" />';      
                ?>
                <p class="search-box">
                    <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html($text); ?>:</label>
                    <input type="search" id="<?php echo esc_attr($input_id); ?>" name="search" value="<?php echo isset( $_REQUEST['search'] ) ? esc_attr( wp_unslash( $_REQUEST['search'] ) ) : ''; ?>" />
                    <?php submit_button($text, '', '', false, array('id' => 'search-submit')); ?>
                </p>
            </form>
        <?php

    }
    public function ajax_user_can() 
    {
        return current_user_can( 'edit_posts' );
    }
    public function no_items() 
    {
         esc_html_e( 'No invitation codes were found.', "pie-register" );
    }
    public function get_views()
    {
        return array();
    }
    function get_table_classes()
    {    
        $classes = array( 'widefat', 'fixed', 'pie-list-table', 'striped', $this->_args['plural'] );
        
        $classes[] = $this->piereg_on_user_tracker() ? 'pr-user-tracker' : 'default_grid';
        
        return $classes;
    }
    public function get_columns()
    {
        $columns = array(
            'cb'              => '<input type="checkbox" />',
			'name'            => __( 'Code Name',"pie-register" ),
            'code_description'=> __( 'Code Description',"pie-register" ),
            'code_usage'      => __( 'Usage' ,"pie-register"),
            'expiry_date'     => __( 'Expiry Date' ,"pie-register"),
            'code_user_role'  => __( 'User Role' ,"pie-register"),
            'email_invite'    => __( 'Sent Through Email' ,"pie-register"),
            'export_users'    => __( 'Export Users Data' ,"pie-register"),
            'action'          => __( 'Action',"pie-register" )
        );

        // Don't show column 'ACTION' if current user is not administrator
        if ( !current_user_can('piereg_manage_cap') ) unset($columns['action']);

        // Show column 'STATUS' if current user is not administrator
        if ( !current_user_can('piereg_manage_cap') ) $columns['status'] = __( 'Status',"pie-register" );

        return $columns;        
    }
    public function get_columns_usertracker()
    {
        $columns = array(
			'name'             => __( 'Code Name',"pie-register" ),
            'code_usage'       => __( 'Usage' ,"pie-register"),
            'expiry_date'      => __( 'Expiry Date' ,"pie-register"),
            'created_by'       => __( 'Created By' ,"pie-register"),
            'user_role'       => __( 'User Role' ,"pie-register"),
            'registered_users' => __( 'Registered Users' ,"pie-register"),
            'email_invite'    => __( 'Sent Through Email' ,"pie-register"),
            'action'          => __( 'Action',"pie-register" )
        );
        return $columns;        
    }
    public function get_sortable_columns()
    {
        $sortable = array(
            'name' => array( 'name', true ),
            'code_description' => array( 'code_description', true ),
            'code_usage'  => array( 'code_usage', true ),
            'expiry_date'  => array( 'expiry_date', true )            
        );

        if ( $this->user_tracker_grid )
        {
            unset($sortable['code_description']);
        }
        return $sortable;
    }
    function column_cb($item) {
        return sprintf(
            '<input type="checkbox" value="%s" class="invitaion_fields_class"  />', intval($item->id)
        ); 
    }
    public function prepare_items( )
    {
        global $wpdb;
        global $wp_roles;

        $prefix     = $wpdb->prefix."pieregister_";
        $userstable = $wpdb->prefix."users";
        $usertable  = $this->userInvitationCodeTable(); 
        $temp_posts_array = array();
        $columns  = $this->user_tracker_grid ? $this->get_columns_usertracker() : $this->get_columns();
        $hidden   = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array( 
            $columns,
            $hidden,
            $sortable 
        );

        // SQL results
        $posts = $this->user_tracker_grid ? $this->get_sql_results_usertracker() : $this->get_sql_results();
        $update = get_option(OPTION_PIE_REGISTER);
        empty( $posts ) AND $posts = array();
        # >>>> Pagination
		
        // All codes other than those generated by currently logged in user, should be visible on user tracker grid
        if ( $this->user_tracker_grid )
        {
            foreach ( $posts as $key => $post )
            { 
                if ( !empty($posts[ $key ]->created_by) )
                {
                    $user = get_userdata( $posts[ $key ]->created_by );					
                   
                    if ( $user ) 
                    {
                        $capabilities = $user->{$wpdb->prefix . 'capabilities'};
    
                        if ( $posts[ $key ]->created_by != get_current_user_id())
                        {
                            $temp_posts_array[] = $post;
                        }  
                    } 
                    else
                    {
                        $temp_posts_array[] = $post;
                    } 
                }
            }
            $posts = $temp_posts_array;
        }

        $opt = get_option(OPTION_PIE_REGISTER);
		$per_page_item = (isset($opt['invitaion_codes_pagination_number']) && ((int)$opt['invitaion_codes_pagination_number']) != 0)? (int)$opt['invitaion_codes_pagination_number'] : 10;
		unset($opt);
        $per_page     = $per_page_item;
        $current_page = $this->get_pagenum();        
        $total_items  = count( $posts );
        $this->set_pagination_args( array (
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil( $total_items / $per_page )
        ) );
        $last_post = $current_page * $per_page;
        $first_post = $last_post - $per_page + 1;
        if ( $last_post > $total_items )
        {
            $last_post = $total_items;

            if ( isset( $_GET['paged'] ) && $_GET['paged'] != ceil( $total_items / $per_page ) )
            {
                $first_post = $total_items -  $last_post + 1;   
            }
        }
        // Setup the range of keys/indizes that contain 
        // the posts on the currently displayed page(d).
        // Flip keys with values as the range outputs the range in the values.
        $range = array_flip( range( $first_post - 1, $last_post - 1, 1 ) );
        // Filter out the posts we're not displaying on the current page.
        $posts_array = array_intersect_key( $posts, $range );
        # <<<< Pagination
        // Prepare the data
        $permalink = __( 'Edit:' );
		$id = 1;

        foreach ( $posts_array as $key => $post )
        {
            $link     = "#";
            $no_title = esc_html__( 'No title set' );
            $title    = ! $post->name ? "<em>{$no_title}</em>" : $post->name;
			$post_name = $post->name;
            $post_description = !empty ( $post->code_description ) ? $post->code_description: 'None' ;
            $code_user_role = !empty ( $post->code_user_role ) ? $wp_roles->roles[$post->code_user_role]['name']: 'None' ;
            $edit_usage     = current_user_can('piereg_manage_cap') ? 'onclick="show_field(this,\'usage_field_id_'.esc_js($id).'\');"' : '';
            $post_expiry_date = $post->expiry_date;
			
            /*
                General grid columns -  On all sub tabs of Invitation Code 
            */

			/*code name*/ 
			$e_title = esc_html__( 'Click here to edit',"pie-register" );
			$posts[ $key ]->name = '<span title="'.esc_attr($e_title).'" onclick="show_field(this,\'field_id_'.esc_js($id).'\');" id="field_id_1_'.esc_attr($id).'">'.$posts[ $key ]->name.'</span><input type="text" id="field_id_'.esc_attr($id).'" value="'.esc_attr($posts[ $key ]->name).'" style="display:none;" onblur="hide_field(this,\'field_id_1_'.esc_js($id).'\');" data-id-invitationcode="'.esc_attr($posts[ $key ]->id).'" data-type-invitationcode="name" />';
			
			/*code usage*/ 
            $posts[ $key ]->code_usage = '<span>'.$posts[ $key ]->count.'/</span><span title="'.esc_attr($e_title).'" '.$edit_usage.' id="usage_field_id_1_'.esc_attr($id).'">' . esc_html($posts[ $key ]->code_usage)  . '</span><input autocomplete="off" type="text" class="code_usage" id="usage_field_id_'.esc_attr($id).'" value="'.esc_attr($posts[ $key ]->code_usage).'" style="display:none;" onblur="hide_field(this,\'usage_field_id_1_'.esc_js($id).'\');" data-id-invitationcode="'.esc_attr($posts[ $key ]->id).'" data-type-invitationcode="code_usage" />';
            
            /*expiry date*/

            if($this->piereg_pro_is_activate) 
            {
                $posts[ $key ]->expiry_date = '<span title="'.$e_title.'" onclick="show_field(this,\'expiry_field_id_'.esc_js($id).'\');" id="expiry_field_id_1_'.esc_attr($id).'">'.$posts[ $key ]->expiry_date.'</span><input autocomplete="off" type="text" id="expiry_field_id_'.esc_attr($id).'" value="'.$posts[ $key ]->expiry_date.'" style="display:none;" class="expiry_datepicker_update" onchange="hide_field(this,\'expiry_field_id_1_'.esc_attr($id).'\');" onblur="hide_datefield(this,\'expiry_field_id_1_'.esc_attr($id).'\');" data-id-invitationcode="'.$posts[ $key ]->id.'" data-type-invitationcode="expiry_date" />';
            } 
            else 
            {
                $posts[ $key ]->expiry_date = '';
            }

                        
            /*email count*/
            $registered_users = [];
            $not_used_codes   = 0;
            $prefix           = $wpdb->prefix."pieregister_";
            $emailtable       = $prefix."invite_code_emails";
            $codetable        = $prefix."code";
            $code_name        = $wpdb->get_results("SELECT `name` FROM ".$codetable." WHERE id=".$posts[ $key ]->id);
            $results          = $wpdb->get_results("SELECT * FROM ".$emailtable." WHERE code_id=".$posts[ $key ]->id);
            
            $total_emails_sent = $wpdb->num_rows; 

            $posts[ $key ]->email_invite  = '<span onclick="email_popup('.esc_js($id).');" id="emailcount_field_id_1_'.esc_attr($id).'">'.esc_html($total_emails_sent).'</span>';
            $posts[ $key ]->email_invite .= '<div title="'.esc_attr($code_name[0]->name).'" id="dialog-message_'.esc_attr($id).'" style="display:none;">';
                    $posts[ $key ]->email_invite .= '<div>';
                    $posts[ $key ]->email_invite .= '<p class="pop-head">Already Sent :</p>';

                if($total_emails_sent > 0){
                    foreach($results as $result){
                        $users      = $wpdb->get_results("SELECT * FROM ".$userstable." WHERE user_email='".$result->email_address."'");
                        
                        if($wpdb->num_rows == 0){
                            $posts[ $key ]->email_invite .= '<p class="email-content">'. esc_html($result->email_address) .'</p>';
                            $not_used_codes++;
                        }else{
                            if ( !in_array( $result->email_address, $registered_users ) )
                            {
                                $registered_users[] =  $result->email_address;
                            }
                        }
                    }
                }
                if($not_used_codes == 0){
                    $posts[ $key ]->email_invite .= '<p class="email-content"> None </p>';
                }
                $posts[ $key ]->email_invite .= '</div>';
                $posts[ $key ]->email_invite .= '<hr>';
                $posts[ $key ]->email_invite .= '<div class="heading-popup">';
            
                    $posts[ $key ]->email_invite .= '<p class="pop-head"> Registered Email Addresses :</p>';

                    if(count($registered_users) > 0){
                        foreach($registered_users as $emails){
                            $posts[ $key ]->email_invite .= '<p class="email-content">'.esc_html($emails).'</p>';
                        }
                    }else{
                        $posts[ $key ]->email_invite .= '<p class="email-content"> None </p>';
                    }

                $posts[ $key ]->email_invite .= '</div>';
            $posts[ $key ]->email_invite .= '</div>';

            $class = ($post->status==1) ? "active"  : "inactive";
            $title = ($class == "active")? "Deactivate" : "Activate";
            
            $posts[ $key ]->action = '<a onclick="changeStatusCode(\''.esc_js($post->id).'\',\''.esc_js($post_name).'\',\''.esc_js($title).'\');" href="javascript:;" title="'.esc_attr__($title,"pie-register").'" class="'.esc_attr($class).'"></a> <a class="delete" href="javascript:;" onclick="confirmDelInviteCode(\''.esc_js($post->id).'\',\''.esc_js($post_name).'\');" title="'.esc_attr__("Delete","pie-register").'"></a>';
            
            // Status of Code
            $status_style = ($class == "active") ? "style='color: green; font-weight: 500;'" : "style='color: red; font-weight: 500;'" ;
            $posts[ $key ]->status = '<span '.$status_style.' class="code_status">'.esc_html($class).'</span>';
            
            /*
                Specific Columns on Default Grid
            */
        
            if ( !$this->piereg_on_user_tracker() )
            {
                $posts[ $key ]->cb = '<input type="checkbox" value="'.esc_attr($posts[ $key ]->id).'" class="invitaion_fields_class" id="invitaion_fields[id_'.esc_attr($id).']" />';

                /*code description */
                $posts[ $key ]->code_description = '<span title="'.esc_attr($e_title).'" onclick="show_field(this,\'code_description_field_id_'.esc_js($id).'\');" class="code_description"  id="code_description_field_id_1_'.esc_attr($id).'">'. $post_description.'</span><input type="text" id="code_description_field_id_'.esc_attr($id).'" value="'.$posts[ $key ]->code_description.'" style="display:none; width:100px;" onblur="hide_field(this,\'code_description_field_id_1_'.esc_js($id).'\');" data-id-invitationcode="'.$posts[ $key ]->id.'" data-type-invitationcode="code_description" />';
                
                /*User Role */
                $posts[ $key ]->code_user_role = '<span title="'.$e_title.'" id="code_user_role_field_id_1_'.esc_attr($id).'">'. $code_user_role .'</span>';
                // $posts[ $key ]->code_user_role = '<span title="'.$e_title.'" onclick="show_field(this,\'code_user_role_field_id_'.esc_attr($id).'\');" id="code_user_role_field_id_1_'.esc_attr($id).'">'. $code_user_role .'</span><input type="text" id="code_user_role_field_id_'.esc_attr($id).'" value="'.$posts[ $key ]->code_user_role.'" style="display:none;" onblur="hide_field(this,\'code_user_role_field_id_1_'.esc_attr($id).'\');" data-id-invitationcode="'.$posts[ $key ]->id.'" data-type-invitationcode="code_user_role" />';

                $posts[ $key ]->export_users ='<form method="post"><input type=hidden name="pie_code_name" value="'.esc_attr($post_name).'" /><input type=hidden name="pie_code_desc" value="'.esc_attr($post_description).'" /><input type=hidden name="pie_expiry_date" value="'.esc_attr($post_expiry_date).'" /><input type="submit" name="invitaion_code_export_data" value="Export Data" class="button button-primary button-large invitaion_code_export_data" /></form>';
            } 
            /*
                Specific Columns on User Tracker Grid
            */ 
            else { 
                /*User Role */
                global $wp_roles;
                $user_meta = get_userdata(intval($post->created_by));
                $posts[ $key ]->user_role = '';
                
                if ($user_meta)
                {
                    $user_roles = $user_meta->roles;
                
                    if(count($user_roles) > 0){
                        foreach($user_roles as $user_role)
                        {
                            $posts[ $key ]->user_role .= '<span class="user_role">'.esc_html($wp_roles->roles[$user_role]['name']).'</span><br/>';
                        }
                    }
                } 
                else
                {
                    $posts[ $key ]->user_role .= '<span class="user_role user_not_exist">'.esc_html( '-', "pie-register" ).'</span><br/>';
                }

                /*Code Created By Whom */
                $user_email_address = $wpdb->get_results("SELECT `user_email` FROM ".$userstable." WHERE ID='".$posts[ $key ]->created_by."'");

                if ( !empty($user_email_address) )
                {
                    $posts[ $key ]->created_by = '<span class="created_by">'. esc_html($user_email_address[0]->user_email) .'</span>';
                } else {
                    $posts[ $key ]->created_by = '<span class="created_by user_not_exist">'. esc_html( 'The user does not exist.', "pie-register" ) .'</span>';
                }

                /*Registered Users*/
                $registered_users = [];
                $not_used_codes   = 0;
                $posts[ $key ]->registered_users = '';
                
                $results          = $wpdb->get_results("SELECT * FROM ".$userstable." INNER JOIN ".$usertable." ON ".$usertable.".registered_user = ".$userstable.".ID WHERE code_id=".$posts[ $key ]->id);
                
                $total_registered_users = $wpdb->num_rows; 

                if($total_registered_users > 0){
                    foreach($results as $result){
                        $registered_users[] =  $result->user_email;
                    }
                    if(count($registered_users) > 0){
                        $count = 1;
                        $style = "";
                        $view_more = false;
                        $class = '';

                        foreach($registered_users as $email_address)
                        {
                            if ( $count > 3)
                            {
                                $style = " style='display: none;' ";
                                $view_more = true;
                                $class = 'hidden_email_address';
                            }

                            $posts[ $key ]->registered_users .= '<p '.$style.'class="registered_users '.$class.'">'.esc_html($email_address).'</p>';

                            $count++;
                        }
                        if ( $view_more )
                        {
                            $posts[ $key ]->registered_users  .= '<p class="invite_users_view_more" onclick="piereg_show_more_registered_users(this)">More</p>';
                        }
                    }
                }
                else {
                    $posts[ $key ]->registered_users .= '<p class="registered_users"> None </p>';
                }
            } 

            $id++;
        }
        $this->items = $posts_array;
		
    }
    public function column_default( $item, $column_name )
    {
        return $item->$column_name;
    }
    public function display_tablenav( $which ) {
        ?>
        <div class="tablenav <?php echo esc_attr( $which ); ?>">
            
            <div class="alignleft actions">
                <?php //Bulk option here ?>
            </div>
             
            <?php
            $this->extra_tablenav( $which );
            $this->pagination( $which );
            ?>
            <br class="piereg_clear" />
        </div>
        <?php
    }
    public function extra_tablenav( $which )
    {
        global $wp_meta_boxes;
        $views = $this->get_views();
        if ( empty( $views ) )
            return;
        $this->views();
    }
    private function apply_inner_join($codetable,$usertable)
    {
        return !current_user_can('piereg_manage_cap') ?  " INNER JOIN ".$usertable." ON ".$codetable.".id = ".$usertable.".code_id " : "";
    }
    private function filterGridByCurrentUser($usertable,$codetable)
    {
        return !current_user_can('piereg_manage_cap') ?  " (".$usertable.".user_id = ".get_current_user_id().") " : " (".$codetable.".id NOT IN ( SELECT code_id FROM ".$usertable." WHERE (user_id != ".get_current_user_id().") && (user_id != 0) ) ) ";
    }
    private function search_by_code_name_usertracker($codename)
    {
        $search = htmlentities(sanitize_text_field(trim( wp_unslash($codename))));
        return $this->user_tracker_grid ? " WHERE name LIKE '%".sanitize_key($search)."%' " : "";
    }
    private function piereg_on_user_tracker()
    {
        return isset($_GET['usertracker']) ? true : false;
    }
    private function userInvitationCodeTable()
    {
        global $wpdb;		
        return $wpdb->prefix."pieregister_user_invitation_code";			
    }
}