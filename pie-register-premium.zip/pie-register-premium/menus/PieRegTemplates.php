<?php 
$img_src     = esc_url(PIEREG_PLUGIN_URL.'assets/images/templates/');
$raw_templates 	= $this->templateJson();
$handle 		= fopen($raw_templates, "r");
$templates 		= fread($handle, filesize($raw_templates));
$templates      = json_decode(  $templates );
$templates      = $templates->templates;
?>
<div class="pieregister-admin" style="width:99%;overflow:hidden;">

<div class="main-dashboard-wrapper">
    <h2 class="pr-templates-header">
        <?php esc_html_e("Pie Register Form Templates",'pie-register') ?>
    </h2>
    <div id="piereg-guide-link">
        <div id="piereg-guide-link-items">
            <div class="piereg-guide-link-icon" data-title="<?php esc_attr_e('Click here for a detailed guide.','pie-register');?>">
                <a href="https://pieregister.com/documentation/how-to-use-built-in-form-templates-in-pie-register/" target="_blank" rel="noopener noreferrer">
                <img src="<?php echo esc_url(PIEREG_PLUGIN_URL . 'assets/images/pr-guide-link-icon.png');?>" alt="">
                </a>
            </div>
        </div>
    </div>  
    <?php 
    if ( empty( $templates ) ) {
        echo '<div id="message" class="error"><p>' . esc_html__( 'Something went wrong. Please refresh your templates.', 'pie-register' ) . '</p></div>';
    } else { 
        foreach ( $templates as $template ) :
    ?>
            <div class="element-item <?php echo esc_attr($template->plan);?>" data-template="<?php echo esc_attr($template->title); ?>">
                <div class="element-image">
                    <img src="<?php echo $img_src.$template->image; ?>" alt="blank">
                </div>
                <div class="title-bar">
                    <div class='icon'>
                        <img src="<?php echo $img_src.$template->type.'-icon.png'; ?>" alt="blank">
                    </div>
                    <div class="title">
                        <h2><?php echo esc_html($template->slug); ?></h2>
                        <h3><?php echo esc_html_e("Registration Form",'pie-register') ?></h3>    
                    </div>
                </div>
            </div>
        <?php endforeach;
    }
    ?>
</div>
</div>
  