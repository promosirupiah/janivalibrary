<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php
global $errors;
$license_key_errors = "";
if(isset($errors->errors['piereg_license_error']) && !empty($errors->errors['piereg_license_error']) && is_array($errors->errors['piereg_license_error']))
{
	foreach($errors->errors['piereg_license_error'] as $error_val){
		$license_key_errors .= "<p><strong>".$error_val."</strong></p>";
	}
}
?>
<div id="container"  class="pieregister-admin">
	<?php
	$piereg = $this->get_pr_global_options();
    if( isset($this->pie_post_array['error']) && !empty($this->pie_post_array['error']) ){
        echo '<div id="error" class="error fade"><p><strong>' . wp_kses_post($this->pie_post_array['error']) . '</strong></p></div>';
    }
	elseif( isset($license_key_errors) && !empty($license_key_errors) ){
        echo '<div id="error" class="error fade">' . wp_kses_post($license_key_errors) . '</div>';
    }
    elseif( isset($this->pie_post_array['success']) && !empty($this->pie_post_array['success']) ){
        echo '<div id="message" class="updated fade"><p><strong>' . wp_kses_post($this->pie_post_array['success']) . '</strong></p></div>';
	}
    ?>
    <div class="right_section">
        <div class="settings">
        	<?php if( $_GET['tab'] != 'license' ){ ?>
	        	<h2><?php esc_html_e("Licence Key Settings",'pie-register') ?></h2>
            <?php } ?>
            <div class="fields"> <?php esc_html_e("Please activate the license key to use premium features.",'pie-register') ?></div>
            <form method="post" action="">
				<?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_license_key_nonce','piereg_license_key_nonce'); ?>
            	<?php if( $_GET['tab'] != 'license' ){ ?>
               	 	<h3><?php esc_html_e("Activation",'pie-register') ?></h3>
            	<?php } ?>
                <div class="fields flex-format">
                    <label for="piereg_license_key"><?php esc_html_e("License Key",'pie-register') ?></label>
                    <input type="text" name="piereg_license_key" id="piereg_license_key" value="<?php echo (isset($piereg['piereg_license_key'])?esc_attr($piereg['piereg_license_key']):""); ?>" class="input_fields" required="required" autocomplete="off">
                    <span class="piereg_license_key_icon_span"><img class="piereg_license_key_icon" title="" src="<?php echo esc_url(plugins_url("assets/images/warning.png", dirname(__FILE__) )); ?>"></span>
                </div>
                <div class="fields notice_license">
                	<span>Enter license key which is provided in your GT Store account under My Keys.</span>
                </div>
                <div class="fields flex-format">
                    <label for="piereg_license_email"><?php esc_html_e("Email Address",'pie-register') ?></label>
                    <input type="email" name="piereg_license_email" id="piereg_license_email" value="<?php echo (isset($piereg['piereg_license_email'])?esc_attr($piereg['piereg_license_email']):""); ?>" class="input_fields" required="required" autocomplete="off">
                    <span class="piereg_license_key_icon_span"><img class="piereg_license_key_icon" title="" src="<?php echo esc_url(plugins_url("assets/images/warning.png", dirname(__FILE__) )); ?>"></span>
                </div>
                <div class="fields notice_license">
                	<span>Enter your GT Store account email address here.</span>
                </div>
                <div class="fields fields2">
	                <input type="submit" class="submit_btn" name="save_license_key_settings" value=" <?php esc_html_e("Activate","pie-register");?> " />
                    <p><a href="https://store.genetech.co/" target="_blank" title="Purchase License Key"><?php esc_html_e("Already purchased.",'pie-register') ?>?</a> or <a href="http://pieregister.com/" target="_blank" title="Purchase License Key"><?php esc_html_e("Click here to purchase.",'pie-register') ?></a></p>
                </div>
    	        <input type="hidden" name="piereg_activate_license_key" value="1" />
    	        <input type="hidden" name="piereg_license_key_redirect_to" value="<?php echo (!empty($_SERVER['REQUEST_URI'])?esc_url_raw($_SERVER['REQUEST_URI']):""); ?>" />
            </form>
        </div>
    </div>
</div>