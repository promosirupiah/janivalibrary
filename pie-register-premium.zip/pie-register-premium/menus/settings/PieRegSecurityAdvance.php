<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php $piereg = $this->get_pr_global_options();

$_available_in_pro 	= "";
$_disable = false;
if(!$this->piereg_pro_is_activate)	{
	$_disable 			= true;
	$_available_in_pro 	= ' - <span style="color:red;">'. esc_html__("Available in premium version","pie-register") . '</span>';
}
$update = get_option(OPTION_PIE_REGISTER);
$restrict_options = ['post','page','category'];
if( !isset($_GET['act']) || !isset($_GET['pie_id']) || !isset($_GET['option']) )
{
	?>
    <form name="frm_settings_security_advanced" action="#restrict_category_area" method="post" novalidate>
    <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_settings_security_advanced','piereg_settings_security_advanced'); ?>
        <div class="fields">
        	<div class="piereg_box_style_1">
             <input <?php disabled($_disable, true); ?> type="checkbox" name="reg_form_submission_time_enable" id="reg_form_submission_time_enable" value="1" <?php checked($piereg['reg_form_submission_time_enable']=="1", true); ?> /> 
             <?php esc_html_e("Time form submission, reject form if submitted within ",'pie-register') ?>
             <input <?php disabled($_disable, true); ?> type="text" name="reg_form_submission_time" 
             		style="width:auto;"
                    id="reg_form_submission_time" 
                    value="<?php echo ( (isset($piereg['reg_form_submission_time']) && !empty($piereg['reg_form_submission_time'])) ? esc_attr($piereg['reg_form_submission_time']) : 0 ); ?>" 
                    class="input_fields submissionfield"
                    />
                    <?php esc_html_e("seconds or less.",'pie-register') ?>
            <span class="quotation" style="margin-left:0px;"><?php esc_html_e("Security enhancement for forms (timed submission)",'pie-register') ?><?php echo wp_kses_post($_available_in_pro); ?></span>
            </div>
        </div>
        <div class="fields">
        	<div class="piereg_box_style_1 limit-submission">
             <?php esc_html_e("Form Submission Limit for a Device ",'pie-register') ?>
             <input <?php disabled($_disable, true); ?> type="text" name="reg_form_submission_limit" 
             		style="width:auto;"
                    id="reg_form_submission_limit" 
                    value="<?php echo ( (isset($piereg['reg_form_submission_limit']) && !empty($piereg['reg_form_submission_limit'])) ? esc_attr($piereg['reg_form_submission_limit']) : 0 ); ?>" 
                    class="input_fields submissionfield" 
                    /><br>
            <span class="quotation" style="margin-left:0px;"><?php esc_html_e("Limits how many times a form can be submitted from a device within a day. Helpful to prevent spams. Set it to zero(0) to disable this feature.",'pie-register') ?><?php echo wp_kses_post($_available_in_pro); ?></span>
            </div>
        </div>
        
        <!--
         - Global Post/Page Restrictions Settings
         - Start
         -->
        <hr class="seperator" />
        <h2 class="hydin_without_bg mar_none">
            <?php esc_html_e("Global Visibility Restrictions",'pie-register') ?>
        </h2>

        <table class="form-table">
            <div style="width:100%;display:inline-block;">
                <tr>
                    <td>
                        <ul class="piereg_rw_list global-restriction-tabs">
                            <ul>
                            <li class="global_restriction_tab">
                                    <div id="global_restriction_posts" class="piereg_input_radio  active-global-restriction-tab">
                                        <a class="global_restriction global_restriction_posts" name="global_restriction">Restrict Posts</a>
                                    </div>
                                </li>
                                <li class="global_restriction_tab">
                                    <div id="global_restriction_pages" class="piereg_input_radio">
                                        <a class="global_restriction global_restriction_pages" name="global_restriction">Restrict Pages</a>
                                    </div>
                                </li>
                                <li class="global_restriction_tab">
                                    <div  id="global_restriction_categories" class="piereg_input_radio">
                                        <a class="global_restriction global_restriction_categories" name="global_restriction">Restrict Categories</a>     
                                    </div>
                                </li>
                            </ul>
                        </ul>
                    </td>
                </tr>
            </div>
        </table>
        <br>

        <!-- RESTRICT POST VISIBILITY CONTENT - LOOP -->
        <?php foreach($restrict_options as $restrict_option){?>
            <div id="<?php echo 'restrict_'.esc_attr($restrict_option).'_area'?>" class="restrict-area" <?php echo ($restrict_option != 'post')?'hidden':''?>>
                <div style="width:100%;display:inline-block;">
                    <fieldset style="margin:15px 0px;">
                        <input <?php disabled($_disable, true); ?> type="checkbox" name="<?php echo 'piereg_restrict_all_'.esc_attr($restrict_option).'_visibility_globally'?>" id="<?php echo 'piereg_restrict_all_'.esc_attr($restrict_option).'_visibility_globally'?>" value="1" <?php echo (isset($piereg['piereg_restrict_all_'.$restrict_option.'_visibility_globally']) && ($piereg['piereg_restrict_all_'.$restrict_option.'_visibility_globally']=="1") )?'checked="checked"':''?>/>
                        <?php
                        if($restrict_option == 'post'){
                            $label = "Posts";
                        }else if($restrict_option == 'page'){
                            $label = "Pages";
                        }else{
                            $label = "Categories";
                        }
                        esc_html_e("Allow Global Restriction For All {$label}",'pie-register') 
                        ?>
                    </fieldset>
                </div>
                <div id="<?php echo 'exclude_'.esc_attr($restrict_option)?>" <?php echo (isset($piereg['piereg_restrict_all_'.$restrict_option.'_visibility_globally']) && ($piereg['piereg_restrict_all_'.$restrict_option.'_visibility_globally']!="1") )?'hidden="hidden"':''?>>
                    <div id="exclude_label">
                        <h4><?php esc_html_e("Exclude ". ucfirst($restrict_option)."(s)"." From Restriction","pie-register"); ?></h4>
                    </div>
                    <div id="<?php echo 'piereg_all_'.esc_attr($restrict_option)?>">
                        <table style="max-height:250px;overflow:auto;display:block;" class="widefat <?php echo 'piereg_all_'.esc_attr($restrict_option)?>" style="width:100%;">
                            <tbody style="display:grid;">
                            <?php if($restrict_option == 'post'){
                                    global $post;
                                    $posts = get_posts(array( 
                                        'numberposts'	=> -1,
                                        'post_type' 	=> 'post'
                                    ));
                                    $alternative = true;
                                    
                                    foreach($posts as $key=>$val){
                                        if($alternative)
                                            $alternative = false;
                                        else
                                            $alternative = true;
                                ?> 
                    
                                <tr class="<?php  echo esc_attr($alternative) ? 'alternate' : false ?>  author-self status-publish ">
                                    <th class="check-column"><input name="<?php echo 'pr_restrict_'.esc_attr($restrict_option).'[]'?>" type="checkbox" id="<?php echo esc_attr($key) ?>" value="<?php echo esc_attr($val->ID)?>" class="pie_register_rw_checkboxs"  <?php echo (isset($piereg['pr_restrict_'.$restrict_option]) && in_array($val->ID, $piereg['pr_restrict_'.$restrict_option]) ? 'checked="checked"' :'' )?>/></th>
                                    <td><label for="<?php echo esc_attr($key) ?>"><?php echo esc_html($val->post_title) ?></label></td>
                                </tr>
                                <?php }
                            } elseif($restrict_option == 'page'){
                                $pages = get_posts(array( 
                                    'numberposts'	=> -1,
                                    'offset'		=> 0,
                                    'post_type' 	=> 'page'
                                ));
                                $alternative = true;
                                
                                foreach($pages as $key=>$val){
                                    if($alternative)
                                        $alternative = false;
                                    else
                                        $alternative = true;
                                ?>
                                    
                                <tr class="<?php  echo esc_attr($alternative) ? 'alternate' : false ?>  author-self status-publish ">
                                    <th class="check-column"><input name="<?php echo 'pr_restrict_'.esc_attr($restrict_option).'[]'?>" type="checkbox" id="<?php echo esc_attr($key) ?>" value="<?php echo esc_attr($val->ID)?>" class="pie_register_rw_checkboxs"  <?php echo ( isset($piereg['pr_restrict_'.$restrict_option]) && in_array($val->ID, $piereg['pr_restrict_'.$restrict_option]) ? 'checked="checked"' :'' )?>/></th>
                                    <td><label for="<?php echo esc_attr($key) ?>"><?php echo esc_html($val->post_title) ?></label></td>
                                </tr>
                                <?php }
                            } else{
                                $categories = get_categories(array( 
                                    'hide_empty'      => false
                                ));

                                $alternative = true;

                                foreach($categories as $key=>$val){
                                    if($alternative)
                                        $alternative = false;
                                    else
                                        $alternative = true;
                                ?>
                                <tr class="<?php  echo esc_attr($alternative) ? 'alternate' : false ?>  author-self status-publish ">
                                    <th class="check-column"><input name="<?php echo 'pr_restrict_'.esc_attr($restrict_option).'[]'?>" type="checkbox" id="<?php echo esc_attr($key) ?>" value="<?php echo esc_attr($val->cat_ID)?>" class="pie_register_rw_checkboxs"  <?php echo ( isset($piereg['pr_restrict_'.$restrict_option]) && in_array($val->cat_ID, $piereg['pr_restrict_'.$restrict_option]) ? 'checked="checked"' :'' )?>/></th>
                                    <td><label for="<?php echo esc_attr($key) ?>"><?php echo esc_html($val->name) ?></label></td>
                                </tr>
                                <?php }
                            } ?>
                            </tbody>
                        </table>

                        <div class="selectAll-unselectAll-btn"  style="padding:5px;">
                            <span><a id="<?php echo 'select_all_'.esc_attr($restrict_option)?>" title="<?php echo 'Select All '.esc_attr($restrict_option)?>">
                                    <?php echo (__("Select All","pie-register")) ?>
                                </a></span>
                            <?php echo "&nbsp;/&nbsp;"; ?>
                            <span><a id="<?php echo 'unselect_all_'.esc_attr($restrict_option)?>" title="<?php echo 'Unselect All '.esc_attr($restrict_option)?>">
                                    <?php echo esc_html(__("Unselect All","pie-register")) ?>
                                </a></span>
                        </div>
                    </div>
                    <hr style="border-color: #ababab;border-width: 0 0 1.5px 0;"/>
                    </div>
                <h4><?php esc_html_e("Global visibility settings ",'pie-register') ?></h4>
                <div class="pie_register-admin-meta piereg_rw_main_table">
                    <div class="piereg_restriction_field_area">
                        <div class="piereg_label">
                            <label for="<?php echo 'piereg_'.esc_attr($restrict_option).'_visibility'?>" ><?php esc_html_e( 'Visibility', 'pie-register' ); ?></label>
                        </div>
                        <div class="piereg_input">
                        <select multiple id="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_visibility'?>" name="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_visibility[]'?>">
                                <option value="default" <?php echo (isset($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && ( (is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && in_array("default" , $piereg['piereg_restrict_'.$restrict_option.'_visibility']) ) || (!is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && $piereg['piereg_restrict_'.$restrict_option.'_visibility']=="default")  ) )?'selected="selected"':''?>><?php esc_html_e(' Default',"pie-register") ?></option>
                                <option value="after_login" <?php echo (isset($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && ( (is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && in_array("after_login" , $piereg['piereg_restrict_'.$restrict_option.'_visibility']) ) || (!is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && $piereg['piereg_restrict_'.$restrict_option.'_visibility']=="after_login")  ) )?'selected="selected"':''?>><?php esc_html_e(' Show to Logged in Users',"pie-register") ?></option>
                                <option value="before_login" <?php echo (isset($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && ( (is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && in_array("before_login" , $piereg['piereg_restrict_'.$restrict_option.'_visibility']) ) || (!is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && $piereg['piereg_restrict_'.$restrict_option.'_visibility']=="before_login")  ) )?'selected="selected"':''?>><?php esc_html_e(' Show to users who have not logged in.',"pie-register") ?></option>
                                <?php
                                global $wp_roles;
                                $role = $wp_roles->roles;
                                
                                foreach($role as $key => $value)
                                { 
                                    $role_name = strtolower(str_replace(" ","_",$value['name']));
                                    ?>
                                <option value="<?php echo esc_attr( $key ) ?>" <?php echo (isset($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && ( (is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && in_array($key , $piereg['piereg_restrict_'.$restrict_option.'_visibility']) ) || (!is_array($piereg['piereg_restrict_'.$restrict_option.'_visibility']) && $piereg['piereg_restrict_'.$restrict_option.'_visibility']==$key) ) )?'selected="selected"':''?>><?php esc_html_e("Show to","pie-register");echo " ".esc_html($value['name']); ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>                         

                    <div class="piereg_restriction_field_area pieregister_restriction_type_area">
                        <div class="piereg_label"><label><?php esc_html_e( 'Restriction Type', 'pie-register' ); ?></label></div>
                        <div class="piereg_input <?php echo 'piereg_input_for_'.esc_attr($restrict_option)?>">
                            <?php $restriction_option = (isset($update['piereg_restrict_'.$restrict_option.'_type_global']) && $update['piereg_restrict_'.$restrict_option.'_type_global'] != "") ? $update['piereg_restrict_'.$restrict_option.'_type_global'] : 0; ?>
                            <div class="piereg_input_radio">
                                <label for="redirect">
                                    <input type="radio" id="redirect" class="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_type_global' ?>" name="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_type_global' ?>" value="0" <?php echo($restriction_option==0)? 'checked="checked"' : '' ?> /><?php esc_html_e( 'Redirect', 'pie-register' ); ?></label>
                            </div>
                            <div class="piereg_input_radio">
                                <label for="block_content">
                                    <input type="radio" id="block_content" class="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_type_global' ?>" name="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_type_global' ?>" value="1" <?php echo($restriction_option==1)? 'checked="checked"' : '' ?> /><?php esc_html_e( 'Block Content', 'pie-register' ); ?></label>
                            </div>
                        </div>
                    </div>
                    <div id="<?php echo 'pieregister_restriction_url_area_for_'.esc_attr($restrict_option) ?>" <?php echo ($restriction_option !=0)? 'style="display:none"': '' ?> >
                        <div class="piereg_restriction_field_area pieregister_restriction_url_area">
                            <?php $option = ((isset($update['piereg_restrict_'.$restrict_option.'_redirect_url']) && $update['piereg_restrict_'.$restrict_option.'_redirect_url'] != "") ? $update['piereg_restrict_'.$restrict_option.'_redirect_url'] : ""); ?>
                            <div class="piereg_label">
                                <label for="piereg_redirect_url"><?php esc_html_e( 'Redirect Url', 'pie-register' ); ?></label>
                            </div>
                            
                            <div class="piereg_input">
                                <input type="url" id="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_redirect_url' ?>" name="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_redirect_url' ?>" value="<?php echo esc_url($option);  ?>" style="width:70%;" class="pieregister_redirect_url" />
                            </div>
                        </div>

                        <div class="piereg_restriction_field_area pieregister_restriction_url_area" style="text-align:center;">
                            <strong> <?php esc_html_e('OR','pie-register'); ?></strong>
                        </div>

                        <div class="piereg_restriction_field_area pieregister_restriction_url_area">
                            <?php $option = ((isset($update['piereg_restrict_'.$restrict_option.'_redirect_page']) && $update['piereg_restrict_'.$restrict_option.'_redirect_page'] != "") ? $update['piereg_restrict_'.$restrict_option.'_redirect_page'] : -1); ?>
                            
                            <div class="piereg_label">
                                <label for="piereg_redirect_page"><?php esc_html_e( 'Redirect Page', 'pie-register' ); ?></label>
                            </div>
                            <div class="piereg_input">
                                <select id="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_redirect_page' ?>" class="piereg_restrict_page_visibility_url_page piereg_redirect_page" name="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_redirect_page' ?>">
                                    <option value = "-1" >None</option>   
                                    <?php foreach(get_pages() as $page) { ?>
                                        <option value="<?php echo esc_attr($page->ID) ?>"<?php echo(isset($piereg['piereg_restrict_'.$restrict_option.'_redirect_page']) && $piereg['piereg_restrict_'.$restrict_option.'_redirect_page']==$page->ID)?'selected="selected"':''?> <?php echo(isset($piereg['piereg_restrict_'.$restrict_option.'_redirect_page' ]) && $piereg['piereg_restrict_'.$restrict_option.'_redirect_page' ]==$page->ID)?'selected="selected"':''?> class="<?php echo(isset($piereg['piereg_restrict_'.esc_attr($restrict_option).'_redirect_page' ]) && $piereg['piereg_restrict_'.$restrict_option.'_redirect_page' ]==$page->ID)?'selected="selected"':''?> <?php echo ( (isset($update['piereg_restrict_all_page_visibility_globally']) && $update['piereg_restrict_all_page_visibility_globally']==0) || (isset($update['pr_restrict_page']) && in_array($page->ID,$update['pr_restrict_page'])))?"":'disabled' ?>"> <?php echo esc_html($page->post_title)?><?php echo ( (isset($update['piereg_restrict_all_page_visibility_globally']) && $update['piereg_restrict_all_page_visibility_globally']==0) || (isset($update['pr_restrict_page']) && in_array($page->ID,$update['pr_restrict_page'])))?"":"(Already Restricted)" ?></option>
                                        <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="piereg_restriction_field_area <?php echo 'pieregister_block_content_area_for_'.esc_attr($restrict_option)?>" <?php echo ($restriction_option != 1)? 'style="display:none"' : '' ?>>
                        <div class="piereg_label">
                            <label for="piereg_block_content"><?php esc_html_e( 'Block Content', 'pie-register' ); ?></label>
                        </div>
                        <div class="piereg_input <?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_visibility_blocked_content'?> ">
                            <textarea id="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_visibility_blocked_content'?>" name="<?php echo 'piereg_restrict_'.esc_attr($restrict_option).'_visibility_blocked_content'?>" placeholder="Enter the block content that you want to set globally"><?php echo isset($piereg['piereg_restrict_'.$restrict_option.'_visibility_blocked_content'])?esc_textarea($piereg['piereg_restrict_'.$restrict_option.'_visibility_blocked_content']):''?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?> 
        <!-- END LOOP -->

        <hr class="seperator" />
        <!--
         - Global Post/Page Restrictions Settings
         - End
         -->
        <div class="pie-save-settings-bar">
            <div class="fields">
                <input name="action" value="pie_reg_settings" type="hidden" />
                <input <?php disabled($_disable, true); ?> type="submit" class="submit_btn" value="<?php esc_attr_e("Save Settings","pie-register"); ?>" />
            </div>
            <div id="piereg-guide-link">
                <div id="piereg-guide-link-items">
                    <div class="piereg-guide-link-icon" data-title="<?php esc_attr_e('Click here for a detailed guide.','pie-register');?>">
                        <a href="https://pieregister.com/documentation/settings/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo esc_url(PIEREG_PLUGIN_URL . 'assets/images/pr-guide-link-icon.png');?>" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
<hr class="seperator" />    
<?php 
}
	?>
<h2 class="hydin_without_bg mar_none"><?php esc_html_e("Restrict Widgets",'pie-register') ?></h2>
    <div class="piereg_clear"></div>        
<?php if( $this->piereg_pro_is_activate ) { ?>
    <?php $this->require_once_file(PIEREG_DIR_NAME.'/restrict_widget/pie_register_widget_class.ini.php'); ?>
<?php } else { ?>
	<p><?php esc_html_e('Upgrade to premium version to use the Restrict Widgets feature. Want to learn about this feature ?','pie-register');?> 
    <a href="https://pieregister.com/manual/pie-register-features/7329-2/" target="_blank"><?php esc_html_e('Click Here','pie-register');?></a>
    </p>
<?php } ?>
