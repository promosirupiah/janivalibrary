<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php $piereg = get_option(OPTION_PIE_REGISTER); ?>
<div class="pieregister-admin" style="width:99%;overflow:hidden;">
  <div id="container">
    <div class="right_section">
      <div class="settings pie_wrap" style="padding-bottom:0px;">
        <h2>
          <?php esc_html_e("Pie Register Registration Form",'pie-register') ?>
        </h2>
        <?php
		if( isset($this->pie_post_array['error_message']) && !empty( $this->pie_post_array['error_message'] ) )
			echo '<div style="clear: both;float: none;"><p class="error">' . wp_kses_post($this->pie_post_array['error_message']) . "</p></div>";
		if(isset( $this->pie_post_array['success_message'] ) && !empty( $this->pie_post_array['success_message'] ))
			echo '<div style="clear: both;float: none;"><p class="success">' . wp_kses_post($this->pie_post_array['success_message']) . "</p></div>";
			?>
      </div>
      <div class="settings" style="padding-bottom:0px;">
        <div class="pieHelpTicket">
          	<?php 
      $formtemplateurl = '';
			$disableanchor 	= "button-disaled";
			$titlehover 	= 'title="With Pie Register Pro you can have an unlimited number of registration forms."';
			if( $this->piereg_pro_is_activate )
			{	
        $formtemplateurl 	= esc_url("admin.php?page=pr_form_templates");
				$disableanchor 	= "button-primary";
				$titlehover 	= "";
			}
			?>
      <a href="<?php echo $formtemplateurl; ?>" <?php echo $titlehover; ?> class="button button-large <?php echo esc_attr($disableanchor); ?>">
        &nbsp; <?php esc_html_e("Add New","pie-register"); ?> &nbsp;
      </a>
      <div id="piereg-guide-link">
        <div id="piereg-guide-link-items">
          <div class="piereg-guide-link-icon" data-title="<?php esc_attr_e('Click here for a detailed guide.','pie-register');?>">
              <a href="https://pieregister.com/documentation/how-to-use-built-in-form-templates-in-pie-register/" target="_blank" rel="noopener noreferrer">
              <img src="<?php echo esc_url(PIEREG_PLUGIN_URL . 'assets/images/pr-guide-link-icon.png');?>" alt="">
              </a>
          </div>
        </div>
      </div>  
		</div>
      </div>
      <div class="pieHelpTicket">
        <div class="settings" style="padding-bottom:0px;">
          <table cellspacing="0" class="piereg_form_table">
            <thead>
              <tr>
                <th></th>
                <th><?php esc_html_e("ID","pie-register"); ?></th>
                <th><?php esc_html_e("Form Title","pie-register"); ?></th>
                <th><?php esc_html_e("Views","pie-register"); ?></th>
                <th><?php esc_html_e("Submissions","pie-register"); ?></th>
                <th><?php esc_html_e("Shortcode","pie-register"); ?></th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th></th>
                <th><?php esc_html_e("ID","pie-register"); ?></th>
                <th><?php esc_html_e("Form Title","pie-register"); ?></th>
                <th><?php esc_html_e("Views","pie-register"); ?></th>
                <th><?php esc_html_e("Submissions","pie-register"); ?></th>
                <th><?php esc_html_e("Shortcode","pie-register"); ?></th>
              </tr>
            </tfoot>
            <tbody class="">
              <?php
if( $this->piereg_pro_is_activate )
{
	$option_asda = get_option("piereg_form_field_option_10");
	
}
$fields_id = get_option("piereg_form_fields_id");
$form_on_free	= get_option("piereg_form_free_id");

$count = 0;
for($a=1;$a<=$fields_id;$a++)
{
	$option = get_option("piereg_form_field_option_".$a);
	if( !empty($option) && is_array($option) && isset($option['Id']) && (!isset($option['IsDeleted']) || trim($option['IsDeleted']) != 1) )
	{			
		?>
              <tr>
                <td><?php if(trim($option['Status']) != "" and $option['Status'] == "enable"): ?>
                  <a href="<?php echo esc_url('admin.php?page=pie-register&prfrmid='. esc_attr($option['Id']).'&status=disenable') ?>"> <img title="Deactivate" alt="Deactivate" src="<?php echo esc_url(plugins_url("../assets/images/active1.png",__FILE__)); ?>"> </a>
          <?php else:  ?>
          <a href="<?php echo esc_url('admin.php?page=pie-register&prfrmid='. esc_attr($option['Id']) .'&status=enable') ?>"> <img title="Activate" alt="Activate" src="<?php echo esc_url(plugins_url("../assets/images/active0.png",__FILE__)); ?>"> </a>
                  <?php endif; ?></td>
                <td class="column-id"><?php echo esc_html($option['Id']); ?></td>
                <?php $pieregister_form_title = !empty( $option['Title'] ) ? $option['Title'] : 'Registration Form - '.$option['Id'] ; ?>
                <td class="column-title"><strong><?php echo esc_html($pieregister_form_title); ?></strong>
                  <div class="piereg-actions">
                    <span class="edit"><a class="underlinenone" href="<?php echo esc_url('admin.php?page=pr_new_registration_form&form_id='. esc_attr($option['Id']) ) ?>" title="Edit this form">Edit</a> | </span>
                    <span class="edit"><a onclick="javascript:confrm_box('Are you sure you want to delete this form?','admin.php?page=pie-register&prfrmid=<?php echo esc_attr($option['Id']); ?>&action=delete');" title="Delete this form">Delete</a> | </span>
                    <?php 
                    $preview_url = add_query_arg(array('pr_preview'=>1,'form_id'=>$option['Id'],'prFormId'=>$option['Id']), get_permalink($piereg['alternate_register']));
                    ?>
                    <span class="edit"><a class="underlinenone" href="<?php echo esc_url($preview_url); ?>" target="_blank" title="Preview this form">Preview</a>
                    <?php
                			// task duplicate form

                      if( $this->piereg_pro_is_activate )
                      {
                    ?>
                      | </span>                      
                      <span class="edit"><a class="underlinenone" href="<?php echo esc_url('admin.php?page=pie-register&form_id='.esc_attr($option['Id']).'&form_action='.esc_attr('duplication')) ?>" title="Duplicate this form">Duplicate</a>
                    <?php
                      }
                    ?>
                    </span>
                  </div>
                </td>
                <td class="column-date"><strong><?php echo esc_html($option['Views']) ?></strong></td>
                <td class="column-date"><strong><?php echo esc_html($option['Entries']); ?></strong></td>
                <td class="column-date" ><div class="style_textarea" onclick="selectText('piereg-select-all-text-onclick_<?php echo esc_js($option['Id']); ?>')" id="piereg-select-all-text-onclick_<?php echo esc_attr($option['Id']); ?>" readonly="readonly"><?php echo '[pie_register_form id="'.esc_html($option['Id']).'" title="true" description="true" ]' ?></div></td>
              </tr>
              <?php 
		$count++;
		
		if( $count == 1 && !$this->piereg_pro_is_activate )
		{
			if( !$form_on_free )
			{
				update_option('piereg_form_free_id', $option['Id']);
				$form_on_free .= $option['Id'];
			}
			break;
		}
	}
}
			if($count == 0){ ?>
              <tr>
                <td colspan="6"><h3>
                    <?php esc_html_e("No Registration Form Found","pie-register"); ?>
                  </h3></td>
              </tr>
            <?php }?>
            </tbody>
          </table>
        </div>
      </div>
      <?php 
      if( current_user_can( 'administrator' ) ){
        do_action( 'admin_notices_specific_pages');	
      }
    ?>
    </div>
  </div>
</div>