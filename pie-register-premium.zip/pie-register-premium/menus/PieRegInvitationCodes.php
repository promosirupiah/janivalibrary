<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php
global $piereg_dir_path;
$update = get_option(OPTION_PIE_REGISTER);
if( file_exists(PIEREG_DIR_NAME."/classes/invitation_code_pagination.php") )
  include_once( PIEREG_DIR_NAME."/classes/invitation_code_pagination.php");
$piereg = get_option(OPTION_PIE_REGISTER);
$view_raw_code           = apply_filters( 'piereg_inv_code_sub_tabs_visibility', true , 'raw_code');
$view_auto_generate_code = apply_filters( 'piereg_inv_code_sub_tabs_visibility', true , 'auto_generate_code');
$view_invite_through_email = apply_filters( 'piereg_inv_code_sub_tabs_visibility', true , 'invite_through_email');
?>
<form method="post" action="" id="del_form">
  <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitation_code_del_form_nonce','piereg_invitation_code_del_form_nonce'); ?>
  <input type="hidden" id="invi_del_id" name="invi_del_id" value="0" />
</form>
<form method="post" action="" id="status_form">
  <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitation_code_status_form_nonce','piereg_invitation_code_status_form_nonce'); ?>
  <input type="hidden" id="status_id" name="status_id" value="0" />
</form>
<div id="container" class="pieregister-admin">
  <div class="right_section">
    <div class="invitation settings">
      <h2 class="fullheading">
        <?php esc_html_e("Invitation Codes",'pie-register'); ?>
      </h2>
      <?php
       // invite_through_email  
       if(isset($this->pie_post_array['notice']) && !empty($this->pie_post_array['notice']) ){

          if(is_array($this->pie_post_array['notice'])) {
            foreach( $this->pie_post_array['notice'] as $msg ) {
              echo '<div id="message" class="updated fade msg_belowheading ext-space"><p><strong>' . wp_kses_post($msg) . '.</strong></p></div>';
            }
          } else {
            echo '<div id="message" class="updated fade msg_belowheading ext-space"><p><strong>' . wp_kses_post($this->pie_post_array['notice']) . '.</strong></p></div>';
          }
       }  
       
       if( isset($this->pie_post_array['error_message']) && !empty( $this->pie_post_array['error_message'] ) )
          echo '<div style="clear: both;float: none;"><p class="error">' . wp_kses_post($this->pie_post_array['error_message'])  . "</p></div>";

       if( isset($this->pie_post_array['error']) && !empty( $this->pie_post_array['error'] ) ){
        if(is_array($this->pie_post_array['error'])) {
            foreach( $this->pie_post_array['error'] as $msg ) {
              echo '<div style="clear: both;float: none;"><p class="error">' . wp_kses_post($msg) . "</p></div>";
            }
          } else {
            echo '<div style="clear: both;float: none;"><p class="error">' . wp_kses_post($this->pie_post_array['error'])  . "</p></div>";
          }
       }
          
       if(isset( $this->pie_post_array['success_message'] ) && !empty( $this->pie_post_array['success_message'] ))
          echo '<div style="clear: both;float: none;"><p class="success">' . wp_kses_post($this->pie_post_array['success_message']) . "</p></div>";
      
      ?>
      
    <div class="<?php echo !isset($_GET['usertracker']) ? 'invite-tab-content' : 'pr-user-tracker' ?>">
      <?php if ( current_user_can('piereg_manage_cap') )
      {
      ?>
       <form method="post" action="">
          <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitation_code_enable_nonce','piereg_invitation_code_enable_nonce'); ?>
          <ul class="clearfix">
            <li>
              <div class="fields">
                <div class="radio_fields">
                  <input type="checkbox" name="enable_invitation_codes" id="enable_invitation_codes" value="1" <?php checked($piereg['enable_invitation_codes']=="1", true); ?> />
                  <input type="hidden" name="hdn_enable_invitation_codes" value="1" />
                </div>
                <label for="enable_invitation_codes" class="labelaligned enable-invite">
                  <?php esc_html_e("Enable Invitation Codes","pie-register");?>
                </label>
              </div>
            </li>
            <li class="no-margin clearfix">
              <div class="fields">
                <p>
                  <i> <?php esc_html_e("Protect your privacy. If you want your blog to be exclusive, enable Invitation Codes to allow users to register by invitation only.",'pie-register'); ?>
                  </i>
                  <br />
                  <strong><?php esc_html_e("Note",'pie-register') ?> :</strong> <?php esc_html_e("You must add the invitation code field to your registration form.",'pie-register') ?></p>
              </div>
            </li>
          </ul>
        </form>
      <?php } ?>

        <div class="invite-tabs clearfix">
          <ul>
            <?php if ($view_raw_code) { ?>
              <li <?php if(!isset($_GET['autogenerate']) && !isset($_GET['inviteemail']) && !isset($_GET['allowuserinvitation'])  && !isset($_GET['usertracker'])){ echo 'class="invite-active"'; } ?>><a href="admin.php?page=pie-invitation-codes&rawcode">Raw Codes</a></li>
            <?php } ?>
            <?php if ($view_auto_generate_code) { ?>
              <li <?php if(isset($_GET['autogenerate'])){ echo 'class="invite-active"'; } ?>><a href="admin.php?page=pie-invitation-codes&autogenerate">Auto Generate Codes</a></li>
            <?php } ?>
            <?php if ($view_invite_through_email) { ?>
              <li <?php if(isset($_GET['inviteemail'])){ echo 'class="invite-active"'; } ?>><a href="admin.php?page=pie-invitation-codes&inviteemail">Invite Through Email</a></li>
            <?php } ?>
            <?php 
            if (current_user_can('piereg_manage_cap')) { ?>
                <li <?php if(isset($_GET['allowuserinvitation'])){ echo 'class="invite-active"'; } ?>><a href="admin.php?page=pie-invitation-codes&allowuserinvitation">Allow Users to Invite</a></li>
                <li <?php if(isset($_GET['usertracker'])){ echo 'class="invite-active"'; } ?>><a href="admin.php?page=pie-invitation-codes&usertracker">User Tracker</a></li>
            <?php
            }
            ?>
          </ul>
        </div>
        <?php 
          if((!isset($_GET['autogenerate']) && !isset($_GET['inviteemail']) && !isset($_GET['allowuserinvitation']) && !isset($_GET['usertracker']) && $view_raw_code) || (!isset($_GET['autogenerate']) && !isset($_GET['inviteemail']) && !current_user_can('piereg_manage_cap') && $view_raw_code) || ($view_raw_code && !$view_auto_generate_code && !$view_invite_through_email)){
            $this->require_once_file(PIEREG_DIR_NAME.'/menus/invitations/custom-code.php');
          } else if((isset($_GET['autogenerate']) && $view_auto_generate_code) || (!isset($_GET['rawcode']) && !isset($_GET['inviteemail']) && !current_user_can('piereg_manage_cap') && $view_auto_generate_code) || (!$view_raw_code && !$view_invite_through_email && $view_auto_generate_code)){
             $this->require_once_file(PIEREG_DIR_NAME.'/menus/invitations/autogenerate.php');
          } else if(isset($_GET['inviteemail']) && $view_invite_through_email || (!isset($_GET['rawcode']) && !isset($_GET['autogenerate']) && !current_user_can('piereg_manage_cap') && $view_invite_through_email) || (!$view_raw_code && !$view_auto_generate_code && $view_invite_through_email)){
             $this->require_once_file(PIEREG_DIR_NAME.'/menus/invitations/inviteemail.php');
          } else if(isset($_GET['allowuserinvitation']) && current_user_can('piereg_manage_cap')){
            $this->require_once_file(PIEREG_DIR_NAME.'/menus/invitations/allowuserinvitation.php');
          } else if(isset($_GET['usertracker']) && current_user_can('piereg_manage_cap')){
            $this->require_once_file(PIEREG_DIR_NAME.'/menus/invitations/usertracker.php');
          }else{
          ?>
            <p><i><?php esc_html_e("You are not allowed to access this page.",'pie-register');?></i></p>
        <?php } ?> 
       
    </div><!-- invite-tab-content -->
  <?php if(!isset($_GET['inviteemail']) && !isset($_GET['allowuserinvitation']) && !isset($_GET['usertracker']) && ($view_raw_code || $view_auto_generate_code)){ ?>
      <div style="float:left;" class="invitaion_code_bulk_action_form_div">
        <form method="post" onsubmit="return get_selected_box_ids();" >
          <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitaion_code_bulk_option_nonce','piereg_invitaion_code_bulk_option_nonce'); ?>
          <input type="hidden" value="" name="select_invitaion_code_bulk_option" id="select_invitaion_code_bulk_option">
            <select name="invitaion_code_bulk_option" id="invitaion_code_bulk_option">
            <option selected="selected" value="0">
            <?php esc_html_e("Bulk Actions","pie-register"); ?>
            </option>
            <?php if ( current_user_can('piereg_manage_cap') ) { ?>
              <option value="delete">
              <?php esc_html_e("Delete","pie-register"); ?>
              </option>
            <?php } ?>
            <option value="active">
            <?php esc_html_e("Activate","pie-register"); ?>
            </option>
            <option value="unactive">
            <?php esc_html_e("Deactivate","pie-register"); ?>
            </option>
          </select>
          <input type="submit" value="<?php esc_attr_e("Apply","pie-register"); ?>" class="button action" id="doaction" name="btn_submit_invitaion_code_bulk_option">
        </form>
        <span style="color:#F00;display:none;" id="invitaion_code_error"><?php esc_html_e("Select invitation codes to perform bulk operation.","pie-register");?></span>
      </div>

      <div>
        <form method="post" id="pr_invitation_code_filter_form">
          <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitaion_code_filter_nonce','piereg_invitaion_code_filter_nonce'); ?>
          <input type="hidden" value="" name="select_invitaion_code_filter" id="select_invitaion_code_filter">
          
          <select name="invitaion_code_filter" id="invitaion_code_filter">
            <option value="0">
            <?php esc_html_e("All Codes","pie-register"); ?>
            </option>
            <option value="1" <?php echo ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 1 ) ) ? 'selected="selected"':'' ?> >
            <?php esc_html_e("Used Codes","pie-register"); ?>
            </option>
            <option value="2" <?php echo ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 2 ) ) ? 'selected="selected"':'' ?> >
            <?php esc_html_e("Unused Codes","pie-register"); ?>
            </option>
            <option value="3" <?php echo ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 3 ) ) ? 'selected="selected"':'' ?> >
            <?php esc_html_e("Expired Codes","pie-register"); ?>
            </option>
            </option>
            <option value="4" <?php echo ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 4 ) ) ? 'selected="selected"':'' ?> >
            <?php esc_html_e("Created Date","pie-register"); ?>
            </option>
            <option value="5" <?php echo ( isset($update["invitaion_code_filter"]) && ( intval($update["invitaion_code_filter"]) == 5 ) ) ? 'selected="selected"':'' ?> >
            <?php esc_html_e("User Role","pie-register"); ?>
            </option>
          </select>
          
          <div hidden class="pr_invitation_code_filer_date_range">
            <div class="start_date_div">
              <div class="start_date">
                <label for="field">
                  <?php esc_html_e("Start","pie-register"); ?>
                </label>
                <input readonly id="date_start" name="date_start" type="text" class="input_fields date_start" value="<?php echo isset( $update['invitaion_code_filter_date_start'] ) && ( intval($update['invitaion_code_filter']) == 4) ? esc_attr(date_i18n("F j, Y",strtotime($update['invitaion_code_filter_date_start']))) : '' ?>" />
                <img id="start_icon" src="<?php echo esc_url(PIEREG_PLUGIN_URL.'assets/images/calendar_img.jpg') ?>" width="22" height="22" alt="calendar" class="calendar_img" /> 
              </div>  
            </div>
            <div class="end_date_div">
              <div class="end_date">
                <label for="field_">
                  <?php esc_html_e("End","pie-register"); ?>
                </label>
                <input readonly id="date_end" name="date_end" type="text" class="input_fields date_end"  value="<?php echo isset( $update['invitaion_code_filter_date_end'] ) && ( intval($update['invitaion_code_filter']) == 4) ? esc_attr(date_i18n("F j, Y",strtotime($update['invitaion_code_filter_date_end']))): '' ?>" />
                <img id="end_icon" src="<?php echo esc_url(PIEREG_PLUGIN_URL.'assets/images/calendar.png') ?>" width="22" height="22" alt="calendar" class="calendar_img"/> 
              </div>
            </div>
          </div>

          <div hidden class="pr_invitation_code_filer_user_role_dropdown">
            <div>
              <select id="invitation_code_filer_user_role" name="invitation_code_filer_user_role">
              <?php
                  $wp_roles = new WP_Roles;
                  $roles = array();
                  foreach ( $wp_roles->roles as $role)
                  {
                    $roles[] = $role['name'];
                  }
                  echo $this->createDropdown($roles,((isset($update['invitation_code_filer_user_role']))?$update['invitation_code_filer_user_role']:""));
              ?>
              </select>
            </div>
          </div>
          
          <input type="submit" value="<?php esc_html_e("Filter","pie-register"); ?>" class="btn_submit_invitaion_code_filter button action" id="doaction" name="btn_submit_invitaion_code_filter">
        </form>
      </div>
      
      <?php 
      $Pie_Invitation_Table = new Pie_Invitation_Table();
      $Pie_Invitation_Table->set_order();
          $Pie_Invitation_Table->set_orderby();
          $Pie_Invitation_Table->prepare_items();
          $Pie_Invitation_Table->search_box("Search", "search_invitaion_code");
      ?>
        <div class="invitaion_code_export_all_data">
          <form method="post" class="invitaion_code_export_all_data_form">
            <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitaion_code_export_all_data_nonce','piereg_invitaion_code_export_all_data_nonce'); ?>
            <input type="submit" name="invitaion_code_export_all_data" value=" <?php esc_attr_e("Bulk Export","pie-register"); ?> " class="button button-primary button-large"  />
          </form>
        </div>
      <?php
      $Pie_Invitation_Table->display();
      ?>
    <?php } ?>
    <?php if(!isset($_GET['inviteemail']) && !isset($_GET['allowuserinvitation']) && ($view_raw_code || $view_auto_generate_code)){ ?>
      <?php if (!current_user_can('piereg_manage_cap')) {?>
      <p><strong><?php esc_html_e("Note",'pie-register') ?> :</strong> <?php esc_html_e("Contact the site administrator, if you want to change the invitation code status.",'pie-register') ?></p>
      <?php } ?>
      <div style="float:right;padding-right:5px;margin-top:11px;">
        <form method="post" id="form_invitation_code_per_page_items">
          <?php if( function_exists( 'wp_nonce_field' )) wp_nonce_field( 'piereg_wp_invitation_code_per_page_nonce','piereg_invitation_code_per_page_nonce'); ?>
          <?php esc_html_e("Items Per Page","pie-register"); ?>
          <select name="invitation_code_per_page_items" id="invitation_code_per_page_items" title="<?php esc_attr_e("Invitation codes to show on a page.","pie-register"); ?>">
            <?php
              //$opt = get_option("pie_register");
              $opt = get_option(OPTION_PIE_REGISTER);
              $per_page = ( isset($opt['invitaion_codes_pagination_number']) && ((int)$opt['invitaion_codes_pagination_number']) != 0) ? (int)$opt['invitaion_codes_pagination_number'] : 10;
              
              for($per_page_item = 10; $per_page_item <= 50; $per_page_item +=10)
              {
                $checked = selected($per_page == $per_page_item, true);
                echo '<option value="'.esc_attr($per_page_item).'" '.$checked.'>'.esc_html($per_page_item).'</option>';
              }
              echo '<option value="75" '.selected($per_page == "75", true, true).' >75</option>';
              echo '<option value="100" '.selected($per_page == "100", true, true).' >100</option>';
            ?>
          </select>
        </form>
      </div>
    <?php } ?>
    </div>
  </div>
</div>