<?php
/* 	<WP plugin data>
 * 	Plugin Name:   Socialize It Pro
 * 	Version:       1.4.1
 * 	Plugin URI:    http://www.wptraffic.com
 * 	Description:   Autoposter for social bookmark site
 * 	Author:        JP Schoeffel
 *	Author URI:    http://www.wptraffic.com
 *
 */
define("LIST_PER_ROW",50);

class SocializeIt{

var $fileName;	
var $reportFile;
var $exportFileName;

//constructor of the plugin
function SocializeIt(){
	$filename=str_replace("\\","/",(__FILE__));
	$filename=preg_replace('/^.*wp-content\/plugins\//i','',$filename);
	$this->fileName=$filename;
	
	$report=str_replace("\\","/",dirname(__FILE__));
	$report=preg_replace('/^.*wp-content\/plugins\//i','',$report);
	
	$this->reportFile=$report."/report.php";
	
	$exportfile=str_replace("\\","/",dirname(__FILE__));
	$exportfile=preg_replace('/^.*wp-content\/plugins\//i','',$exportfile);
	$this->exportFileName="../wp-content/plugins/".$exportfile."/export.php";


	$this->registerHooks();
}

//what will plugin do, if it activated from plugin menu	
function activatePlugin(){
	global  $wpdb;
	   
	$tableName = $wpdb->prefix . 'socialit';
		$sql = "SHOW TABLES LIKE '" . $tableName . "'";
		if($wpdb->get_var ($sql) != $tableName){
		$sql = "
CREATE TABLE IF NOT EXISTS `$tableName` (
  `id` smallint(4) NOT NULL auto_increment,
  `status` int(11) default '1',
  `name` varchar(255) default '',
  `description` text,
  `loginneed` int(11) default '1',
  `loginurl` varchar(255) default NULL,
  `loginaction` varchar(255) default NULL,
  `loginparse` varchar(255) default NULL,
  `loginfields` text,
  `loginremfields` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `passwd` varchar(255) default NULL,
  `tagseparator` varchar(10) default ',',
  `submitsteps` int(11) default '1',
  `submiturl` text,
  `submitaction` text,
  `submitparse` text,
  `submitfields` text,
  `submitremfields` varchar(255) default NULL,
  `submitsuccess` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM";
	  $wpdb->query($sql);	  
	  }
  $sql="delete from $tableName";
  $wpdb->query($sql);

  $sql="INSERT INTO `$tableName` (`id`, `status`, `name`, `description`, `loginneed`, `loginurl`, `loginaction`, `loginparse`, `loginfields`, `loginremfields`, `username`, `passwd`, `tagseparator`, `submitsteps`, `submiturl`, `submitaction`, `submitparse`, `submitfields`, `submitremfields`, `submitsuccess`) VALUES 
(1, 0, 'http://www.stumbleupon.com', NULL, 1, 'http://www.stumbleupon.com/login.php', NULL, 'name=\"formLogin\"', 'username=%username%&password=%password%&Submit=Submit', NULL, '', '', ',', 1, 'http://www.stumbleupon.com/submit?url=http://excelsifikasi.com&title=TITLE%20OK', NULL, 'name=f', 'url=%url%&title=%title%&topic=%tagscomma%&language=EN&submitsite=Submit this Site >>&newcomment=%desc%', '', 'Rating Submitted!'),
(13, 0, 'http://www.netvouz.com', NULL, 1, 'http://netvouz.com/action/logon?uri=002f', NULL, 'name=\"logonForm\"', 'username=%username%&password=%password%&rememberMe=on&type=p', 'org.apache.struts.taglib.html.CANCEL&', '', '', ',', 1, 'http://netvouz.com/action/submitBookmark', NULL, 'name=\"submitBookmarkForm\"', 'url=%url%&name=%title%&description=%desc%&privat=false&category=7259140519018782541&tags=%tagscomma%&rating=5&submit=Submit bookmark&action=submit', 'org.apache.struts.taglib.html.CANCEL', 'successfully updated'),
(3, 0, 'http://technorati.com', NULL, 1, 'http://technorati.com/signup/', NULL, 'action=\"/login.php\"', 'username=%username%&password=%password%&submit=Sign In', NULL, '', '', ',', 1, 'http://technorati.com/faves/', NULL, 'method=\"post\" style=\"margin-top:10px\"', 'add=%url%&tag=%tagscomma%&submit=Add', NULL, '<strong>%url%</strong> has been added to your Favorites.\r\n<strong>%url%</strong> is already one of your Favorites.'),
(4, 0, 'http://www.furl.net', NULL, 1, 'http://www.furl.net/members/login', NULL, 'name=\"theForm\"', 'username=%username%&password=%password%&Submit=Log  in', NULL, '', '', ';', 1, 'http://www.furl.net/savedialog.jsp?p=1&t=mockuptitle&u=http://mockupurl.com&r=5&v=1&c=', NULL, 'name=\"furlForm\"', 'item[url]=%url%&item[title]=%title%&topics=%tagscomma%&item[public]=true&item[isRead]=true&item[rating]=5&from_no_pop=1&item[via]=&item[title_orig]=', '', 'Your item has been saved!\r\nPartial Success.'),
(5, 0, 'http://www.mister-wong.com', NULL, 1, 'http://www.mister-wong.com/index.php?action=login', NULL, 'action=\"index.php?action=login\"', 'user_name=%username%&user_password=%password%&login=Login', NULL, '', '', '', 1, 'http://www.mister-wong.com/add_url/', NULL, 'name=\"addurl\"', 'bm_url=%url%&bm_description=%title%&bm_tags=%tagscomma%&bm_status=public&addurl=Save bookmark', NULL, 'The URL was successfully saved.\r\nYou already have this link saved in your bookmarks. You can edit it here'),
(8, 0, 'http://www.google.com/bookmarks', NULL, 1, 'https://www.google.com/accounts/ServiceLogin', NULL, 'id=\"gaia_loginform\"', 'Email=%username%&Passwd=%password%&PersistentCookie=yes&rmShown=1&signIn=Sign In', '', '', '', ',', 1, 'http://www.google.com/bookmarks/mark?op=add', NULL, 'name=\"add_bkmk_form\"', 'title=%title%&bkmk=%url%&labels=%tagscomma%&annotation=%desc%&prev=/lookup&btnA=Add bookmark', 'btnC', '%title%'),
(11, 0, 'http://faves.com', NULL, 1, 'https://secure.faves.com/signIn', NULL, 'id=\"signInBox\"', 'rUsername=%username%&rPassword=%password%&rememberMe=1&action=Sign In', NULL, '', '', ',', 1, 'http://faves.com/Authoring.aspx', NULL, 'name=\"createDotForm\"', 'rateSelect=5&noteText=%desc%&urlText=%url%&subjectText=%title%&tagsText=%tagscomma%&shareSelect=Public&submit=Publish', NULL, 'Done!'),
(10, 0, 'http://backflip.com', NULL, 1, 'http://www.backflip.com/login_pop.ihtml', NULL, 'name=\"LOGIN\"', 'username=%username%&password=%password%&keep_password=true&Submit=Sign In', 'cancel', '', '', ',', 1, 'http://www.backflip.com/add_page_pop.ihtml', NULL, 'name=\"add_mark_pop\"', 'url=%url%&title=%title%&note=%desc%&folder=0&addtofix=1&close=true&target=&source=B&SubmitUrl=Backflip It!', '', 'self.close()'),
(15, 0, 'http://www.diigo.com', NULL, 1, 'https://secure.diigo.com/sign-in', NULL, 'name=\"loginForm\"', 'username=%username%&password=%password%', NULL, '', '', ',', 1, 'http://www.diigo.com/post?url=http://www.yuhuu.com', NULL, 'name=\"newForm\"', 'url=%url%&title=%title%&tag=%tagscomma%&b_mode=0&c_mode=0&comment=%desc%', '', 'HTTP/1.1 302'),
(16, 0, 'http://www.bibsonomy.org', NULL, 1, 'http://www.bibsonomy.org/login', NULL, 'action=\"/login_process\"', 'userName=%username%&loginPassword=%password%', NULL, '', '', '', 1, 'http://www.bibsonomy.org/ShowBookmarkEntry?c=b&jump=yes&url=http://mockup.url.com&description=Mockup&extended=', NULL, 'action=\"/bookmark_posting_process\"', 'oldurl=%url%&rating=5&url=%url%&description=%title%&extended=%desc%&tags=%tagscomma%&group=public&submit=save', '', 'HTTP/1.1 302'),
(17, 0, 'http://www.folkd.com', NULL, 1, 'http://www.folkd.com/page/login.html', NULL, 'id=\"form_login\"', 'u=%username%&p=%password%', NULL, '', '', ',{[%]}', 1, 'http://www.folkd.com/page/submit.html', NULL, 'id=\"submit_page\"', 'step2_sent=1&check=page&url=%url%&add_title=%title%&add_description=%desc%&add_tags_show=%tagscomma%&add_tags=%tagscomma%&add_state=public&add_brand=checked', NULL, 'Submit new item - Contribution added successfully'),
(20, 0, 'http://taggly.com', NULL, 1, 'http://taggly.com/login/', NULL, 'action=\"http://taggly.com/login/\"', 'username=%username%&password=%password%&keeppass=yes&submitted=Log In', NULL, '', '', ',', 1, 'http://taggly.com/bookmarks/?action=add', NULL, 'action=\"http://taggly.com/bookmarks/', 'address=%url%&title=%title%&tags=%tagscomma%&status=0&submitted=Add Bookmark', 'address&title&description&tags&submitted&status&', 'Bookmark saved'),
(22, 0, 'http://buddymarks.com', NULL, 1, 'http://buddymarks.com/login.php', NULL, 'action=\"/login.php\"', 'action=login&form_username=%username%&form_password=%password%&login_type=permanent', NULL, '', '', ',', 1, 'http://buddymarks.com/add_bookmark.php', NULL, 'action=insert_bookmark', 'form_buddymark=true&form_group_title=%tagscomma%&bookmark_title=%title%&bookmark_url=%url%&form_description=%desc%&form_tags=%tagscomma%&form_private=0&form_group_parent_id=0&form_group_type=new', 'form_public_link&form_group_id&form_cat_id&\r\n', 'Bookmark saved!'),
(24, 0, 'http://www.linkagogo.com', NULL, 1, 'http://www.linkagogo.com/go/Authenticate', NULL, 'name=\"login\"', 'userName=%username%&code=%password%&btnLogin=Login', NULL, '', '', ',', 1, 'http://www.linkagogo.com/go/AddMenu', NULL, 'name=urlEdit', 'title=%title%&url=%url%&keywords=%tagscomma%&comments=%desc%&rating=4&remind=-9&user=%username%&submit=Add&folder=2383733', NULL, 'Bookmark <b>%title%</b> added.'),
(23, 0, 'http://www.connotea.org', NULL, 1, 'http://www.connotea.org/login', NULL, 'name=\"login\"', 'username=%username%&password=%password%&button=login', NULL, '', '', ',', 1, 'http://www.connotea.org/add', NULL, 'name=\"add\"', 'uri=%url%&usertitle=%title%&tags=%tagscomma%&description=%desc%&mywork=1&private=0&comment=%desc%&title=%title%', NULL, '%title%'),
(25, 0, 'http://www.blinklist.com', NULL, 1, 'http://www.blinklist.com/profile/signin.php', NULL, 'action=\"/profile/signin.php\"', 'Username=%username%&Password=%password%&', NULL, '', '', ',', 1, 'http://www.blinklist.com/?Action=Blink/addblink.php', NULL, 'id=\"Form.Bookmarklet\"', 'Name=%title%&Url=%url%&Vote=5&Description=%desc%&Tag=%tagscomma%&submit=Blink', 'Private&Bcc&Justshare', 'HTTP/1.1 302'),
(26, 0, 'http://del.icio.us', NULL, 1, 'https://secure.del.icio.us/login', NULL, 'action=\"https://secure.del.icio.us/login\"', 'user_name=%username%&password=%password%&login=Log  in', NULL, '', '', ',', 1, 'http://del.icio.us/post?url=http://mockupurl.com&title=Mockuptitle', NULL, 'name=\"delForm\"', 'url=%url%&oldurl=http://mockupurl.com&description=%title%&notes=%desc%&tags=%tagscomma%', '', 'HTTP/1.1 302'),
(27, 0, 'http://myweb.yahoo.com', NULL, 1, 'https://login.yahoo.com/config/login_verify2?.intl=us&.src=smw&.done=http%3A%2F%2Fmyweb.yahoo.com%2Fmyresults%2Fjoin%3F', NULL, 'name=\"login_form\"', 'login=%username%&passwd=%password%&.save=Sign In', NULL, '', '', ',', 1, 'http://myweb.yahoo.com/myresults/bookmarklet?t=mockup-url&u=http://www.mockupurl.com&ei=UTF-8', NULL, 'name=form_save', 'u=%url%&t=%title%&note=%desc%&tag=%tagscomma%&v=1', NULL, 'This page has been saved:\r\nThe page was not saved because you have already saved it to My Web.'),
(28, 0, 'http://www.simpy.com', NULL, 1, 'http://www.simpy.com/login', NULL, 'name=\"LoginForm\"', 'username=%username%&password=%password%&rememberme=87600', NULL, '', '', ',', 1, 'http://www.simpy.com/simpy/LinkAdd.do', NULL, 'name=\"LinkAddForm\"\r\n', 'title=%title%&tags=%tagscomma%&accessType=1&href=%url%&note=%desc%', NULL, 'http://www.simpy.com/user/%username%'),
(29, 0, 'http://ma.gnolia.com', NULL, 1, 'http://ma.gnolia.com/signin', NULL, 'id=\"signin_form\"', 'signin=%username%&password=%password%&commit=Sign In', 'private&sendback', '', '', ',', 1, 'http://ma.gnolia.com/bookmarklet/add?url=http://mockupurl.com&title=mockuptitle&description=description', NULL, 'id=\"bookmark_details\"\r\n', 'url=%url%&title=%title%&description=%desc%&rating=5&tags=%tagscomma%&commit=Save', '', 'HTTP/1.1 302'),
(30, 0, 'http://de.lirio.us', NULL, 1, 'http://de.lirio.us/login.php/', NULL, 'action=\"http://de.lirio.us/login.php/\"', 'username=%username%&password=%password%&submitted=Log In', NULL, '', '', ',', 1, 'http://de.lirio.us/bookmarks.php/?action=add', NULL, 'action=\"http://de.lirio.us/bookmarks.php/', 'address=%url%&title=%title%&description=%desc%&tags=%tagscomma%&status=0&submitted=Add Bookmark', NULL, 'Bookmark saved\r\n%title%'),
(31, 0, 'http://www.spurl.net', NULL, 1, 'http://www.spurl.net/login.php', NULL, 'action=\"login.php\"', 'username=%username%&password=%password%&Submit=Login', NULL, '', '', '', 1, 'http://www.spurl.net/spurl.php?v=3&title=%title%&url=%url%', NULL, 'name=\"submit_link\"', 'link_title=%title%&link_href=%url%&title=%title%&-1&keywords=%tagscomma%&description=%desc%&language=en&explicit=0&', 'private', 'Spurl.net - Storing page\r\nSpurl.net: %title%'),
(35, 0, 'http://www.complore.com', NULL, 1, 'http://www.complore.com/?q=user', NULL, 'q=toboggan/login', 'edit[name]=%username%&edit[pass]=%password%&op=Log in', NULL, '', '', ',', 1, 'http://www.complore.com/?q=node/add/flexinode-5', NULL, 'id=\"node-form\"', 'edit[title]=%title%&edit[flexinode_21]=%url%&edit[flexinode_31]=%desc%&edit[tags]=%tagscomma%&op=Submit', NULL, 'Your Bookmarks was created.'),
(37, 0, 'http://www.newsvine.com', NULL, 1, 'https://www.newsvine.com/_tools/user/login', NULL, '_tools/user/login', 'email=%username%&pass=%password%', 'redirect&', '', '', ',', 1, 'http://www.newsvine.com/_tools/seed&save', NULL, 'id=\"seedPostForm\"', 'url=%url%&headline=%title%&newsType=x&categoryTag=world-news&tags=%tagscomma%&blurb=%desc%', '', 'Save Link'),
(39, 0, 'http://www.mister-wong.cn', NULL, 1, 'http://www.mister-wong.cn/index.php?action=login', NULL, 'action=\"index.php?action=login\"', 'user_name=%username%&user_password=%password%&login=Login\r\n', '', '', '', '', 1, 'http://www.mister-wong.cn/add_url/', NULL, 'name=\"addurl\"', 'bm_url=%url%&bm_description=%title%&bm_tags=%tagscomma%&bm_status=public&addurl=Save bookmark', NULL, NULL),
(40, 0, 'http://www.mister-wong.de', NULL, 1, 'http://www.mister-wong.de/index.php?action=login', NULL, 'action=\"index.php?action=login\"', 'user_name=%username%&user_password=%password%&login=Login\r\n', NULL, '', '', '', 1, 'http://www.mister-wong.de/add_url/', NULL, 'name=\"addurl\"', 'bm_url=%url%&bm_description=%title%&bm_tags=%tagscomma%&bm_status=public&addurl=Save bookmark', NULL, 'Die URL wurde erfolgreich gespeichert.'),
(41, 0, 'http://www.mister-wong.es', NULL, 1, 'http://www.mister-wong.es/index.php?action=login', NULL, 'action=\"index.php?action=login\"', 'user_name=%username%&user_password=%password%&login=Login\r\n', NULL, '', '', '', 1, 'http://www.mister-wong.es/add_url/', NULL, 'name=\"addurl\"', 'bm_url=%url%&bm_description=%title%&bm_tags=%tagscomma%&bm_status=public&addurl=Save bookmark', NULL, 'El URL ha sido guardado.'),
(42, 0, 'http://www.mister-wong.fr', NULL, 1, 'http://www.mister-wong.fr/index.php?action=login', NULL, 'action=\"index.php?action=login\"', 'user_name=%username%&user_password=%password%&login=Login\r\n', NULL, '', '', '', 1, 'http://www.mister-wong.fr/add_url/', NULL, 'name=\"addurl\"', 'bm_url=%url%&bm_description=%title%&bm_tags=%tagscomma%&bm_status=public&addurl=Save bookmark', NULL, 'L''adresse de votre favori\r\nVous pouvez le modifier en'),
(43, 0, 'http://www.mister-wong.ru', '', 1, 'http://www.mister-wong.ru/index.php?action=login', NULL, 'action=\"index.php?action=login\"', 'user_name=%username%&user_password=%password%&login=Login', NULL, '', '', '', 1, 'http://www.mister-wong.ru/add_url/', NULL, 'name=\"addurl\"', 'bm_url=%url%&bm_description=%title%&bm_tags=%tagscomma%&bm_status=public&addurl=Save bookmark', NULL, '%title%');
";
	$wpdb->query($sql);
  
	$sql="CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."socialit_reports` (
  `ID` int(11) NOT NULL auto_increment,
  `post_ID` int(11) NOT NULL default '0',
  `reports` text,
  `submitdate` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM ;";
	  $wpdb->query($sql);	  

	add_option('wasb_cookiepath','/tmp/cookies.txt','Cookie Path');
	add_option('wasb_postbookmark','25','Post Bookmark');
	add_option('wasb_email','','Receiver Mail');
}

function deactivatePlugin() {
	global $wpdb;
	$tblName=$wpdb->prefix."socialit";
	$tblName2=$wpdb->prefix."socialit_reports";
	
	$sql="drop table $tblName";
	$wpdb->query($sql);
	$sql="drop table $tblName2";
	$wpdb->query($sql);
	
}
//Register Hooks, like create menu admin
function hookAdminPanel(){

    if ( function_exists('add_menu_page') )
       add_menu_page(__('SocializeIt-Pro'), __('SocializeIt-Pro'), 10, __FILE__,array(&$this,'manageUsersBM'));

    if ( function_exists('add_submenu_page') ) {
      add_submenu_page(__FILE__, __('SocializeIt Manage'), __('SocializeIt Manage'), 10, __FILE__,array(&$this,'manageUsersBM'));
	  add_submenu_page(__FILE__, __('SocializeIt Options'), __('SocializeIt Options'), 10, "admin.php?page=".$this->fileName,array(&$this,'manageOption'));
	  add_submenu_page(__FILE__, __('SocializeIt Reports'), __('SocializeIt Reports'), 10, $this->reportFile,null);
	   }

}

//display option page in WASB->WASB Option
function manageOption(){
	global $wpdb;
	if($_POST["update"]){
		update_option("wasb_cookiepath",$_POST["cookie_path"]);
		update_option("wasb_postbookmark",$_POST["post_bookmark"]);
		update_option("wasb_email",$_POST["receiver_mail"]);
	}
	$cookie_path=get_option("wasb_cookiepath");
	$post_bookmark=get_option("wasb_postbookmark");
	$wasb_email=get_option("wasb_email");
	
?>
<div class="wrap">
<h2><?php echo __("SocializeIt Options"); ?></h2>
	<form method="POST">
		<p><label>
			Cookie Path : <input type=text value="<?php echo $cookie_path?>" name="cookie_path" /> <i>(Cookie used for saving your local variable. please don't change this path if you doesn't understand what it's mean)</i>
		</label></p>
		<p><label>
			How many bookmark site to post? : <input type=text value="<?php echo $post_bookmark?>" name="post_bookmark" size=3 /> % <i>Posting to bookmark site will be randomed, and will get how many BM site from active bookmark site</i>
		</label></p>
		<p><label>
			Send Report Mail To : <input type=text value="<?php echo $wasb_email?>" name="receiver_mail" size=30 /> <i>Will Send Report Status To This Mail Address</i>
		</label></p>
		<p class="submit">
		<input type=submit value="Update Options" name=update />
		</p>
	</form>
</div>
<p>&nbsp;</p>
<div class="wrap">
<?php
		 
		if(function_exists("curl_init"))
		{
				$ch = @curl_init();
				curl_setopt($ch, CURLOPT_URL, "http://news.wptraffic.com.s3.amazonaws.com/news.php");
				curl_setopt($ch, CURLOPT_HEADER, 0);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
				$resp = @curl_exec($ch); 
				$err = curl_errno($ch);

			if($err === false || $resp == "") 
			{
				$newsstr = "";
			} else 
			{
				if (function_exists("curl_getinfo"))
				{
				    $info = curl_getinfo($ch);
					if ($info['http_code']!=200)
						$resp="";
				}
				$newsstr = $resp;
			}
			@curl_close ($ch);
			echo $newsstr;
		}
		else
		{
			 @include("http://news.wptraffic.com.s3.amazonaws.com/news.php"); 
		}
	 ?>
	 
</div>

<?php
$import=$_POST["import"];
if($import){
	$f=$_FILES["importfile"]["tmp_name"];
	$fdata=base64_decode(file_get_contents($f));
	$data=explode("(HDR)",$fdata);
	if($data[0]=="SOCIALITDATA1"){
		$rows=explode("(EOR)",$data[1]);
		$owrite=$_POST["overwrite"];
		if($owrite==2){
			$sql="delete from $wpdb->prefix"."socialit";
			$wpdb->query($sql);
			//echo $sql;
		}
		array_pop($rows);
		foreach($rows as $row){
			$r=explode("(^)",$row);
			$sql="select id from $wpdb->prefix"."socialit where name='$r[1]'";
			$id=$wpdb->get_var($sql);
			$sql="";
			if($id){
				if($owrite){
					$sql="update $wpdb->prefix"."socialit set name='$r[1]',loginneed='$r[2]',loginurl='$r[3]',loginaction='".str_replace("'","\'",$r[4])."',loginparse='".str_replace("'","\'",$r[5])."',loginfields='".str_replace("'","\'",$r[6])."',loginremfields='".str_replace("'","\'",$r[7])."',tagseparator='".str_replace("'","\'",$r[8])."',submitsteps='$r[9]',submiturl='$r[10]',submitaction='".str_replace("'","\'",$r[11])."',submitparse='".str_replace("'","\'",$r[12])."',submitfields='".str_replace("'","\'",$r[13])."',submitremfields='".str_replace("'","\'",$r[14])."',submitsuccess='".str_replace("'","\'",$r[15])."',username='".str_replace("'","\'",$r[16])."',passwd='".str_replace("'","\'",$r[17])."' where id='$id'";
					}
			}
			else{
					$sql="insert into $wpdb->prefix"."socialit(name,loginneed,loginurl,loginaction,loginparse,loginfields,loginremfields,tagseparator,submitsteps,submiturl,submitaction,submitparse,submitfields,submitremfields,submitsuccess,username,passwd) values('$r[1]','$r[2]','$r[3]','".str_replace("'","\'",$r[4])."','".str_replace("'","\'",$r[5])."','".str_replace("'","\'",$r[6])."','".str_replace("'","\'",$r[7])."','".str_replace("'","\'",$r[8])."','$r[9]','$r[10]','".str_replace("'","\'",$r[11])."','".str_replace("'","\'",$r[12])."','".str_replace("'","\'",$r[13])."','".str_replace("'","\'",$r[14])."','".str_replace("'","\'",$r[15])."','".str_replace("'","\'",$r[16])."','".str_replace("'","\'",$r[17])."')";
			}
			if($sql)
				$wpdb->query($sql);
		}
		$msg="<div class=\"updated fade\" id=\"updatenotice\">Data Imported</div>";
	}
	else
	{
		$msg="<div class=\"updated fade\" id=\"updatenotice\">Import Failed, your file is not format of SocializeIt Data</div>";
	}
}
?>
<script language="javascript">
	function validateOption(form){
		if(form.overwrite[2].checked){
			if (confirm("Are You Sure Want To Remove All of Your Bookmark Site Then Change With This Imported File?"))
			return true;
			return false;
		}
		return true;
	}
</script>
<div class="wrap">
<h2><?php echo __("SocializeIt Import"); ?></h2>
<?php
if($msg){
	echo $msg;
};
?>
	<form method="POST" enctype="multipart/form-data" onsubmit="return validateOption(this)">
		<p><label>
			Import File : <input type=file name="importfile" /></label></p>
		<p><label>
		 <input type="radio" name="overwrite" value="0" checked>Only Add New Bookmark Site (old bookmark site will be keep and not overwrited)
		 </label>
		</p>
		<p><label>
		 <input type="radio" name="overwrite" value="1">Add New Data and Overwrite Existing Data
		 </label>
		</p>
		<p><label>
		 <input type="radio" name="overwrite" value="2">Refresh Data (<font color=red><b>All data will be removed first, and change with the new one</b></font>)</label>
		</p>
		<p class="submit">
			<input type=submit value="Import" name=import />
		</p>
	</form>
</div>

<?php
}

//Display list of all bookmarksite and editing username & pwd as well
function manageUsersBM(){
global $wpdb;

//Save username & password for BM site
if($_POST["save"]=="Save"){
	$id=$_POST["id"];
	$username=$_POST["username"];
	$password=$_POST["password"];
	
	if($id){
			$sql="update $wpdb->prefix"."socialit set username='$username',passwd='$password' where id='$id'";
			$wpdb->query($sql);
	}
}

//Batch Disable/Enable 
if($_POST["action"]=="disable" || $_POST["action"]=="enable")
{	
	//when disable action set to 0 and when enable action set to 1
	$action=$_POST["act"]=="disable"?"0":"1";
	
	//get id of the BM site which will be disabled/enabled
	$chk=$_POST["chk"];
	
	//if user check more than 1 BM site
	if(is_array($chk)){
		for($i=0;$i<count($chk);$i++){
			$sql="update $wpdb->prefix"."socialit set status='$action' where id=$chk[$i]";
			$wpdb->query($sql);
		}
	}
	//if user check only 1 BM site
	else if ($chk)
	{	
		$sql="update $wpdb->prefix"."socialit set status='$action' where id=$chk";
		$wpdb->query($sql);
	}
}

//activation from clicking "Enable it /Disable it" link
if(isset($_GET["activate"])){
	$id=$_GET["id"];
	$activate=$_GET["activate"];
	$sql="update $wpdb->prefix"."socialit set status='$activate' where id='$id'";
	$wpdb->query($sql);
}
?>
<!--Javascript for toggle, disable/enable and edit username and password-->
<script language="javascript">
	function editBmSite(id,bmname,username,pwd){
		form=document.getElementById("edtBM");
		form.username.value=username;
		form.password.value=pwd;
		form.bmsite.value=bmname;
		form.id.value=id;
		
	}
	function toggleAll(checks){
		for(var i=0;i<checks.length;i++)
		{
			checks[i].checked=!checks[i].checked;
		}
	}
	function disable(form){
		form.act.value="disable";
		form.submit();
	}
	function enable(form){
		form.act.value="enable";
		form.submit();
	}

	function exportData(form){
		var action=form.action;
		var check=document.getElementsByName("chk[]");
		var checked=false;
		for(var i=0;i<check.length;i++){
			if(check[i].checked){
				checked=true;
				break;
			}
		}
		if(!checked){
			alert("No Checked Bookmark site");
			return false;
		}
		form.action="<?php echo $this->exportFileName;?>"
		form.submit();
		form.action=action;
	}

</script>

<!--List View of the BM site and also the username and password-->
<div class="wrap">
<h2><?php echo __("Manage User of Bookmark Sites"); ?></h2>
<form method=post>
	<p class=submit>
	<input type=button value="Toggle All" onclick="toggleAll(document.getElementsByName('chk[]'))">
	<input type=button value="Export" onclick="exportData(document.getElementById('edtForm'))">
	<input type=button value="Disable" onclick="disable(document.getElementById('edtForm'))">
	<input type=button value="Enable" onclick="enable(document.getElementById('edtForm'))">
	</p>
</form>

<table class="widefat">
	<thead>
	<tr>
		<th scope="col"><div style="text-align: center">ID</div></th>
		<th scope="col">Bookmark Site</th>
		<th scope="col">Username</th>
		<th scope="col">Password</th>
		<th scope="col" colspan="3">Action</th>
	</tr>
	</thead>
<?php
	$sql="select * from $wpdb->prefix"."socialit order by id asc";
	$rows=$wpdb->get_results($sql);
	$bgcolor = '';	
	$class = ('alternate' == $class) ? '' : 'alternate';
	$i=0;
?>
<form id="edtForm" method="POST">
<input type="hidden" name="act" value="" />
	<tbody id="the-list">
<?php
	
	//list all bm site
	foreach($rows as $row){
		print "<tr id='post-{$row->id}' class='$class'>\n";
		?>
		<th scope="row" style="text-align: center"><?php echo ++$i ?></th>
		<td><a href="<?php echo $row->name?>"><?php echo $row->name ?></a></td>
		<td><?php echo $row->username?></td>
		<td><?php echo $row->passwd?></td>
		<td><a onclick="javascript:editBmSite('<?php echo $row->id?>','<?php echo $row->name?>','<?php echo $row->username?>','<?php echo $row->passwd?>')" href="#edit" class='edit'><?php echo __('Edit'); ?></a></td>
		<td><a href="admin.php?page=<?php echo $this->fileName?>&id=<?php echo $row->id?>&activate=<?php echo $row->status==1?"0":"1"?>" class='delete'><?php echo $row->status==1?"Disable":"Enable"?></a>
		</td>
		<td>
		<p class=submit><input type=checkbox name="chk[]" value="<?php echo $row->id?>"/></p>
		</td>
	<?php
		}
	?>
	</tr> 
	</tbody>
</form>
</table>

<!--Form for edit username and password -->
<h2><?php echo __("Edit User and Password of Bookmark Sites"); ?></h2>
<table>
<tr>
<td valign=top>
<a name="edit">
<table>
	<form name="edtBM" id="edtBM" method="POST">
	<tr>
		<td>Bookmark Site
		</td>
		<td>:</td>
		<td><input type=text name="bmsite" readonly size=60/>
		<input type=hidden name="id"/></td>
	</tr>
	<tr>
		<td>Username
		</td>
		<td>:</td>
		<td><input type=text name="username"/>
		</td>
	</tr>
	<tr>
		<td>Password
		</td>
		<td>:</td>
		<td><input type=password name="password"/>
		</td>
	</tr>
	<tr>
		<td colspan=3><p class="submit"><input  type=submit name="save" value="Save"/></p>
		</td>
	</tr>
	</form>
</table>
</a>
</td>
</tr>
</table>
</div>
<p>&nbsp;</p>
<div class="wrap">
<?php
		 
		if(function_exists("curl_init"))
		{
				$ch = @curl_init();
				curl_setopt($ch, CURLOPT_URL, "http://news.wptraffic.com.s3.amazonaws.com/news.php");
				curl_setopt($ch, CURLOPT_HEADER, 0);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
				$resp = @curl_exec($ch); 
				$err = curl_errno($ch);

			if($err === false || $resp == "") 
			{
				$newsstr = "";
			} else 
			{
				if (function_exists("curl_getinfo"))
				{
				    $info = curl_getinfo($ch);
					if ($info['http_code']!=200)
						$resp="";
				}
				$newsstr = $resp;
			}
			@curl_close ($ch);
			echo $newsstr;
		}
		else
		{
			 @include("http://news.wptraffic.com.s3.amazonaws.com/news.php"); 
		}
	 ?>
	 
</div>

<?php	
}

//register hooks for wordpress plugin
function registerHooks(){
	
	  add_action('activate_'.$this->fileName,array(&$this,'activatePlugin'));
      add_action('deactivate_'.$this->fileName,array(&$this,'deactivatePlugin'));
      add_action('admin_menu', array(&$this, 'hookAdminPanel'));
	  add_action('publish_post',array(&$this, 'submitWasb'));
	  add_action('edit_form_advanced',array(&$this, 'addOptionBookmark'));

}

//add option in form post article, this option to specify whether need to autopost or not
function addOptionBookmark(){
	echo '<span style="float:right"><input type="checkbox" name="theme_bookmark" value=1 checked /><strong>Autopost into bookmark site</strong></span>';
}

//main function for submit article posted into bookmark site
function submitWasb($postID){
	global $user_email,$wpdb;
	$post_result=array();
	
	//get info whether need to autopost or not, if not will exit from this function
	$bookmark=$_POST["theme_bookmark"];
	if(!$bookmark) return;
	ini_set("max_execution_time",10000);
	//get wordpress posted
	//echo "Processed";
	query_posts("p=".$postID);
	
	if(have_posts()) 
	{	the_post();
		$permalink=apply_filters('the_permalink', get_permalink());
		$title=get_the_title();
		//$permalink="http://gallery.bookmagsoft.com/female_berapa/";
	}
	//get active bookmark site which will be autoposted
	$rows=$this->_getWasbData();
	$n=0;
	foreach($rows as $row){
		
		//variable for replace data like, variable %title% will be convert into actual title, or tags, desc, etc
		$r_text=array("title"=>$title,"desc" =>get_the_excerpt(),"url"=>$permalink,
							  "email"=>$user_email,"category"=> get_the_category($postID),
							  "tag"=>get_the_tags($postID),"username"=>$row->username,"password"=>$row->passwd,
							  "tagscomma"=>$this->_convertList($row->tagseparator,get_the_tags($postID)));

		$isLogin=true;
		if($row->loginneed){
			$login["url"]=$row->loginurl;
			$login["fields"]=$row->loginfields;
			$login["remfields"]=$row->loginremfields;
			$login["action"]=$row->loginaction;
			$login["parse"]=$row->loginparse;
			
			if(!$this->_login($login,$r_text)){
				$posted["status"]="Login Probably Failed";
				$isLogin=false;
			}
		}
		
		//parsing all data from database which needed for autopost, such us action url, url for post, variable form data, etc
		if($isLogin){
		$url=$row->submiturl;		
		$formparse=explode('<br />',nl2br($row->submitparse));
		$fields=explode('<br />',nl2br($row->submitfields));
		$remFields=explode('<br />',nl2br($row->submitremfields));
		$action=explode('<br />',nl2br($row->submitaction));
		
		$steps=$row->submitsteps;
		$_response="";
		
		for($i=0;$i<$steps;$i++){
			
			//replace unnecessary characters from parsed data
			
			$formparse[$i]=$this->_replaceBracket($formparse[$i]);
			$fields[$i]=$this->_replaceBracket($fields[$i]);
			$remFields[$i]=$this->_replaceBracket($remFields[$i]);
			$action[$i]=$this->_replaceBracket($action[$i]);

			if(!$_response){
				//change variable into actual data, like %url% into real url from posted, etc
				$this->_changeVariable($url,$r_text);
				
				//Do request into bm site, the body response will be returned into variable $_response
				$_response=$this->_doRequest($url);
			}
		
			//if there's response
			if($_response){
				//parse response data and get form data for login or submit url
				
				//echo $_response;
				
				$form=$this->_parseForms($_response,$formparse[$i]);
				
				//print_r($form);
				
				//get action for posting from the form (get action from <form method='post' action='will get this url'>)

				if(!$action[$i])
					$actionUrl=$this->_getAction($form);
				else
					$actionUrl=$action[$i];
				
				if($actionUrl=="") {
					$mockurl=parse_url($url);
					$actionUrl=$mockurl["scheme"]."://".$mockurl["host"].$mockurl["path"];
				}
				
				$parse_action=parse_url($actionUrl);
				
				if($parse_action['scheme']!='http' && $parse_action['scheme']!='https')
				{
					$preurl=parse_url($url);
					$actionUrl=$preurl['scheme']."://".$preurl['host'].(substr($actionUrl,0,1)=="/"?"":"/").$actionUrl;				
				}
				// end get action
				
				//parse fields, will get name and value from <input type=* name= value>
				$formdata=$this->_parseFields($form);
				$this->_fillFields($formdata,$fields[$i]);
				
				$this->_changeVariable($formdata,$r_text);
				$formdata=$this->_removeFields($formdata,$remFields[$i]);
				
				//print_r($formdata);
				//echo $actionUrl;
				
				//end parse fields
			
				//Do Request to the site
				$_response=$this->_doRequest($actionUrl,$formdata,true);
				//echo $_response;
			}			

		}
		$submit_identify=$row->submitsuccess;
		$this->_changeVariable($submit_identify,$r_text);
		$submit_identify=urldecode($submit_identify);
		$submitted=$this->_isSubmitted($_response,$submit_identify);
		
		$posted["status"]=$submitted?"Successfully Submitted":"Submit Failed";
		
		//echo $_response;
		}
		
		$posted["id"]=$row->id;
		$posted["url"]=$row->name;
		$posted["submitted"]=$submitted?1:0;

		$post_result[$n++]=$posted;
	}
	$reports=$this->_create_reports($post_result);
	if($reports){
		$sql="insert into $wpdb->prefix"."socialit_reports(post_ID,submitdate,reports) values('$postID','".date("Y-m-d h:i:s")."','".nl2br($reports)."')";
		$wpdb->query($sql);
		$this->_sendMail($title,$permalink,$reports);
	}
}

//method for parse fields from the form
function _parseFields($form){
	preg_match_all("#<input\s.*?>#",$form,$fields);
	
	for($i=0;$i<count($fields[0]);$i++){	
		$data=$this->_parseFormValue($fields[0][$i]);		
		$formdata[$data["name"]]=$data["value"];		
	}
	preg_match_all("#<select\s.*?>#si",$form,$fields);
	for($i=0;$i<count($fields[0]);$i++){	
		$data=$this->_parseFormValue($fields[0][$i]);
		$formdata[$data["name"]]=$data["value"];
	}
	return $formdata;
}

//remove unnecessary fields
function _removeFields($fields,$removed){
	$r=explode("&",$removed);
	foreach($fields as $key=>$value){
		$isremoved=false;
		for($i=0;$i<count($r);$i++){
			if($r[$i]==$key){
				$isremoved=true;
				break;
			}		
		}
		if(!$isremoved)
		{
			$newfields[$key]=$value;
		}
	}
	return $newfields;
}

//parse action from the form
function _getAction($form){
	$txt[0]=">";
	$txt[1]="<";
	$txt[2]="'";
	$txt[3]="\"";
	$rpl[0]="";
	$rpl[1]="";
	$rpl[2]="";
	$rpl[3]="";
	preg_match("/action=*.*?[\s>]/", $form,$act);
	$action=preg_replace("/^action=/","",$act[0]);
	$action=str_replace($txt,$rpl,$action);
	return trim($action);
}

//parse the form
function _parseForms($response,$parse){
	$s[0]='?';
	$s[1]=']';
	$s[2]='[';
	$s[3]='(';
	$s[4]=')';
	$s[5]='/';
	
	$r[0]='\?';
	$r[1]='\]';
	$r[2]='\[';
	$r[3]='\(';
	$r[4]='\)';
	$r[5]='\/';
	
	$parse=str_replace($s,$r,$parse);
	preg_match('#<\s*form[^>]*'.$parse.'.*?>.*?<\s*/\s*form\s*>#si', $response,$forms);
	return trim($forms[0]);
}

//replace bracket,etc
function _replaceBracket($url){
	$txt[0]='[';
	$txt[1]=']';
	$rpl[0]='';
	$rpl[1]='';
	return trim($url);
}

//change variable with actual value like title,url,username,email,etc
function _changeVariable(&$formdata,$data){
	$text[0]="%title%";
	$text[1]="%url%";
	$text[2]="%desc%";
	$text[3]="%email%";
	$text[4]="%username%";
	$text[5]="%password%";
	$text[6]="%tagscomma%";
	
	$rplc[0]=$data["title"];
	$rplc[1]=$data["url"];
	$rplc[2]=$data["desc"];
	$rplc[3]=$data["email"];
	$rplc[4]=$data["username"];
	$rplc[5]=$data["password"];
	$rplc[6]=$data["tagscomma"];
	
	$rplc1[0]=urlencode($data["title"]);
	$rplc1[1]=urlencode($data["url"]);
	$rplc1[2]=urlencode($data["desc"]);
	$rplc1[3]=urlencode($data["email"]);
	$rplc1[4]=urlencode($data["username"]);
	$rplc1[5]=urlencode($data["password"]);
	$rplc1[6]=urlencode($data["tagscomma"]);

	if(is_array($formdata)){
		foreach($formdata as $key=>$value){
			$formdata[$key]=str_replace($text,$rplc,$value);
			if($value=="%tags%"){
				$i=0;
				if(!empty($data["tag"])){
					foreach($data["tag"] as $tag){
						$tags[$i++]=$tag->name;
					}
					$formdata[$key]=$tags;
				}
				else
				{
					$format[$key]="";
				}
			}
		}
	}
	else
	{
		$formdata=str_replace($text,$rplc1,$formdata);
	}
}

//fill fields into formdata, this formdata will be post into header if post to the site
function _fillFields(&$formdata,$afields){
	$fields=explode("&",$afields);
	for($i=0;$i<count($fields);$i++){
		$tmp=explode("=",$fields[$i]);
		$formdata[$tmp[0]]=($tmp[1]);
	}
	
	/*special for tagly.com*/
	foreach($formdata as $key=>$value){
		for($i=0;$i<count($fields);$i++){
			$tmp=explode("=",$fields[$i]);
			if(preg_match('/^'.$tmp[0].'/',$key)){
				$formdata[$key]=($tmp[1]);
				break;
			}
		}
	}
}

//parse form fields, to get name and value
function _parseFormValue($data){
	$patterns[0]='/"/';
	$patterns[1]='/>/';
	$patterns[2]="/'/";
	$replacements[0]="";
	$replacements[1]="";
	$replacements[2]="";
	
	preg_match("/name=*.*?[\s>]/", $data,$name);
	$name=explode("=",$name[0]);
	$field["name"]=$name[1];
	$field["name"]=trim(preg_replace($patterns,$replacements,$field["name"]));
	$field["name"]=str_replace("/","",$field["name"]);
	
	
	preg_match("/value=*.*?[\s>]/", $data,$value);
	$value=explode("=",$value[0]);
	$field["value"]=$value[1];
	$field["value"]=trim(preg_replace($patterns,$replacements,$field["value"]));
	//special for taggly
	if($field["value"]=="query" && $field["name"]=="query") $field["value"]=$field["value"]."=";
	
	return $field;
}

//get data of BM site, randoming BM site and calculate how many BM site will be automatically post (settting in WASB Option)
function _getWasbData(){
	global $wpdb;
	$sql="select * from $wpdb->prefix"."socialit where status='1'";
	$rows=$wpdb->get_results($sql);
	shuffle($rows);
	$post=get_option('wasb_postbookmark');
	$cnt=count($rows);
	$cnt=$cnt-ceil(($cnt*$post)/100);
	for($i=0;$i<$cnt;$i++){
		array_pop($rows);
	}
	return $rows;
}

//Do Request to the site
function _doRequest($url, $data = null,$isPost=false) {
	
	$protocol=substr($url,0,5);
	if(is_array($data)){
		foreach($data as $key=>$value){
			$post.="$key=".urlencode($value)."&";
		}
	}

	if(!$isPost)
	{
		$url=$url.(strpos($url,'?')?"&":"?").$post;
	}
	
	$cookie=get_option("wasb_cookiepath");
	//$cookie="C:\\temp\\abc.txt";
	$cr = curl_init($url);
	curl_setopt($cr, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($cr, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
	curl_setopt($cr, CURLOPT_COOKIEFILE, $cookie);
	curl_setopt($cr, CURLOPT_COOKIEJAR, $cookie);
	curl_setopt($cr,CURLOPT_REFERER,$url);

	curl_setopt($cr, CURLOPT_HEADER, true);	
	curl_setopt($cr, CURLOPT_FOLLOWLOCATION, true);

	if($isPost){
		curl_setopt($cr, CURLOPT_POST, true); 
		curl_setopt($cr, CURLOPT_POSTFIELDS, $post);
	}
	if($protocol=="https"){
		curl_setopt($cr, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($cr, CURLOPT_SSL_VERIFYHOST,2);
	}

	$output = curl_exec($cr);
	
	curl_close($cr); 
	return $output;
}

//convert from array into string separated, like tags:a,b,c
function _convertList($separator,$data){
	$result="";
	if($separator=="") $separator=" ";
	if(!empty($data)){
	foreach($data as $d){
			$result.=$d->name.$separator;
		}
		$result=substr($result,0,strlen($result)-strlen($separator));
	}
	else
		$result="";
	return $result;
}

function _login($prop,$changed_text){
		$url=$prop["url"];
		$_response=$this->_doRequest($url);
		
		if($_response){
			$form=$this->_parseForms($_response,$prop["parse"]);
			//print_r($form);
			if($form){
			$_response="";			
			if(!$prop["action"]) $action=$this->_getAction($form);
				else $action=$prop["action"];
					
				if($action=="") {
					$mockurl=parse_url($url);
					$action=$mockurl["scheme"]."://".$mockurl["host"].$mockurl["path"];
				}
				
				$parse_action=parse_url($action);
					
				if($parse_action['scheme']!='http' && $parse_action['scheme']!='https')
				{
					$preurl=parse_url($url);
					$action=$preurl['scheme']."://".$preurl['host'].(substr($action,0,1)=="/"?"":"/").$action;				
				}
				// end get action
					
				//parse fields, will get name and value from <input type=* name= value>
				$formdata=$this->_parseFields($form);
				$this->_fillFields($formdata,$prop["fields"]);
					
				$this->_changeVariable($formdata,$changed_text);
				$formdata=$this->_removeFields($formdata,$prop["remfields"]);
				//print_r($formdata);
				$this->_changeVariable($action,$changed_text);
				//echo $action;
				$_response=$this->_doRequest($action,$formdata,true);
				//echo $_response;
				
			}
		}

		if($_response)
			return true;

	return false;
}
function _isSubmitted($response,$sIdentify){
	$s[0]='?';
	$s[1]=']';
	$s[2]='[';
	$s[3]='(';
	$s[4]=')';
	$s[5]='/';
	
	$r[0]='\?';
	$r[1]='\]';
	$r[2]='\[';
	$r[3]='\(';
	$r[4]='\)';
	$r[5]='\/';
	
	$sIdentify=str_replace($s,$r,$sIdentify);
	$parsers=explode('<br />',nl2br($sIdentify));		
	//print_r($parsers);
	//echo $response;
	if($parsers){
		foreach($parsers as $parse){
			preg_match("/".trim($parse)."/",$response,$matches,PREG_OFFSET_CAPTURE);
			if(count($matches)>0)
				break;
		}
	}
	else
		return true;
	//print_r($matches);
	return count($matches)>0?true:false;
}

function _create_reports($posts){
	$msg="";
	foreach($posts as $post){
		$msg .=$post["url"]." : ".$post["status"]."\n";
	}
	return $msg;
}
function _sendMail($title,$url,$reports){
	
	$to=get_option("wasb_email");
	$subject="SocializeIt-Pro: Report of Submit $title";
	$msg="Report of posting $title into social bookmark site\n$url \n".date("d/M/Y h:i:s")."\r\n".$reports;
	@mail($to,$subject,$msg,"From: socializeit-noreply@socializit.com");
}

}

//Initate OBject
$socialIt = new SocializeIt();

 ?>