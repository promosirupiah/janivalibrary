<?php

	$dir=str_replace("\\","/",__FILE__);
	$dir=preg_replace("/wp-content*.*/","",$dir);
	include_once $dir."wp-config.php";

		$chk=$_POST["chk"];
	$ids=implode(",",$chk);
	$sql="select * from $wpdb->prefix"."socialit where id in ($ids)";
	$rows=$wpdb->get_results($sql);
	$data="SOCIALITDATA1(HDR)";
	foreach($rows as $row){
		$data	.="$row->id(^)$row->name(^)$row->loginneed(^)$row->loginurl(^)$row->loginaction(^)$row->loginparse(^)$row->loginfields(^)$row->loginremfields(^)$row->tagseparator(^)$row->submitsteps(^)$row->submiturl(^)$row->submitaction(^)$row->submitparse(^)$row->submitfields(^)$row->submitremfields(^)$row->submitsuccess(^)$row->username(^)$row->passwd(EOR)";
	}
	header("Content-type:application/octet-stream");
	header('Content-Disposition: attachment; filename="socializeit.export"');
	echo base64_encode($data);
?>