<?php
$action=$_REQUEST["action"];
$start=$_REQUEST["start"]?$_REQUEST["start"]:0;
if($action=="delete"){
	$chk=$_REQUEST["chk"];
	
	if(is_array($chk)){
		for($i=0;$i<count($chk);$i++){
			$sql="delete from $wpdb->prefix"."socialit_reports where id=$chk[$i]";
			$wpdb->query($sql);
		}
	}
	else if ($chk)
	{	
		$sql="delete from $wpdb->prefix"."socialit_reports where id=$chk";
		$wpdb->query($sql);
	}

}
?>
<script language="javascript">
	function showReports(report){
		document.getElementById("report").innerHTML=document.getElementById(report).innerHTML;
	}
	function toggleAll(checks){
		for(var i=0;i<checks.length;i++)
		{
			checks[i].checked=!checks[i].checked;
		}
	}
	function deleteReports(form){
		if(confirm("Are You Sure Want To Delete?")){
			form.action.value="delete";
			form.submit();
		}
	}

</script>


<div class="wrap">
<h2><?php echo __("Reports of Social Bookmark Submission"); ?></h2>
<form method=post>
	<p class=submit>
	<input type=button value="Toggle All" onclick="toggleAll(document.getElementsByName('chk[]'))">
	<input type=button value="Delete" onclick="deleteReports(document.getElementById('edtForm'))">
	</p>
</form>
<?
	$sql="select count(*) from ".$wpdb->prefix."socialit_reports";
	$total=$wpdb->get_var($sql);
	$page=ceil($total/LIST_PER_ROW);
	echo "<strong>Page :</strong>";
	for($i=0;$i<$page;$i++){
		echo "<a href='admin.php?page=".$socialIt->reportFile."&start=".($i*LIST_PER_ROW)."'>".($i+1)."</a> ";
	}
?>
<table class="widefat">
	<thead>
	<tr>
		<th scope="col"><div style="text-align: center">ID</div></th>
		<th scope="col">Post Title</th>
		<th scope="col">Submit Date</th>
		<th scope="col" colspan="3">Action</th>
	</tr>
	</thead>
<?php
	$sql="select b.post_title as title,a.submitdate,a.reports,a.id from $wpdb->prefix"."socialit_reports a, $wpdb->posts b where a.post_ID=b.ID order by a.submitdate desc limit $start,".LIST_PER_ROW;
	$rows=$wpdb->get_results($sql);
	$bgcolor = '';	
	$class = ('alternate' == $class) ? '' : 'alternate';
	$i=0;
?>
<form id="edtForm" method="POST">
<input type="hidden" name="action" value="" />
<input type="hidden" name="start" value="<?php echo $start?>" />
	<tbody id="the-list">
<?php
	foreach($rows as $row){
		print "<tr id='post-{$row->id}' class='$class'>\n";
		?>
		<th scope="row" style="text-align: center"><?php echo ++$i ?></th>
		<td><?php echo $row->title ?></td>
		<td><?php echo $row->submitdate?>
		<div id="rep-<?php echo $row->id;?>" style="display:none">
		<h2><?php echo __("Report Status of \"".$row->title."\""); ?></h2>
<?php echo $row->reports?></div>
		</td>
		<td><a onclick="javascript:showReports('rep-<?php echo $row->id;?>')" href="#edit" class='edit'><?php echo __('View Report'); ?></a></td>
		<td><a onclick="return confirm('Are You Sure Want To Delete ?')" href="admin.php?page=<?php echo $socialIt->reportFile?>&chk=<?php echo $row->id?>&action=delete&start=<?php echo $start?>" class='delete'><?php echo __('Delete');?></a>
		</td>
		<td>
		<p class=submit><input type=checkbox name="chk[]" value="<?php echo $row->id?>"/></p>
		</td>
	<?php
		}
	?>
	</tr> 
	</tbody>
</form>
</table>
</div>
<p>&nbsp;</p>
<div class="wrap">
<?php
		 
		if(function_exists("curl_init"))
		{
				$ch = @curl_init();
				curl_setopt($ch, CURLOPT_URL, "http://news.wptraffic.com.s3.amazonaws.com/news.php");
				curl_setopt($ch, CURLOPT_HEADER, 0);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
				$resp = @curl_exec($ch); 
				$err = curl_errno($ch);

			if($err === false || $resp == "") 
			{
				$newsstr = "";
			} else 
			{
				if (function_exists("curl_getinfo"))
				{
				    $info = curl_getinfo($ch);
					if ($info['http_code']!=200)
						$resp="";
				}
				$newsstr = $resp;
			}
			@curl_close ($ch);
			echo $newsstr;
		}
		else
		{
			 @include("http://news.wptraffic.com.s3.amazonaws.com/news.php"); 
		}
	 ?>
	 
</div>

<a name="edit">
<div class="wrap" id="report">
<h2>Report Status</h2>
</div>
</a>