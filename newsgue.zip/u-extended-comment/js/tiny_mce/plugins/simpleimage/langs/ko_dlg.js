tinyMCE.addI18n('ko.simpleimage_dlg',{
dialog_title:"이미지 삽입/편집",
src:"이미지 URL",
alt:"대체 텍스트",
title:"제목"
});