tinyMCE.addI18n('en.simpleimage_dlg',{
dialog_title:"Insert/edit image",
src:"Image URL",
alt:"Image description",
title:"Title"
});