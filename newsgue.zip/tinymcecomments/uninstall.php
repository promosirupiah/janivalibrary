<?php
delete_option('mcecomment_options');
?>
