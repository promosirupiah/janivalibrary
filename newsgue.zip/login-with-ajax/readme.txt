=== Login With Ajax ===

Contributors: netweblogic
Tags: Login, Ajax, Redirect, BuddyPress, MU, WPMU, sidebar, admin, widget
Requires at least: 2.7
Tested up to: 2.8.2
Stable tag: 1.2

Add smooth ajax during login, avoid screen refreshes and choose where users get redirected to upon login/logout. Supports SSL, MU, and BuddyPress.

== Description ==

For sites that need user logins and would like to avoid the normal wordpress login, this plugin adds the capability of placing a login widget in the sidebar with smooth AJAX login effects.

Compatible with Wordpress, Wordpress MU and BuddyPress. Will work with forced SSL logins.

This plugin allows full customization of your widget html by allowing you to create template files within your theme folder.

Another useful feature (which can be used without the widget) is login and logout redirects, so you control where the user is taken upon login and logout.

If you have any problems with the plugins, please leave a comment on the plugin page or at least give feedback before giving a low rating. It's rude to just give low ratings and nothing else.

If you find this plugin useful and would like to donate something, all we ask is you please add a link on your site to the plugin page on our blog or digg our plugin page [http://netweblogic.com/wordpress/plugins/login-with-ajax/](http://netweblogic.com/wordpress/plugins/login-with-ajax/) thanks!

== Changelog ==

= 1.1 =
* Fixed JavaScript for http to https support.
* Added shortcut tag login_with_ajax().

= 1.11 =
* Fixed regular expression issue.

= 1.2 =
* Fixed redirection issue.
* Added link to wp-admin profile page when logged in to default widget template.

== Installation ==

1. Upload this plugin to the `/wp-content/plugins/` directory and unzip it, or simply upload the zip file within your wordpress installation.

2. Activate the plugin through the 'Plugins' menu in WordPress

3. If you want login/logout redirections, go to Settings > Login With Ajax in the admin area and fill out the form.

4. Add the login with ajax widget to your sidebar, or use login_with_ajax() in your template.

5. Happy logging in!

== Notes ==

When creating customized themes for your widget, there are a few points to consider:

* Start by copying the files in the /yourpluginpath/login-with-ajax/widget/ folder to /yourthemepath/plugins/login-with-ajax/
* If you want to customize the login-with-ajax.js javascript, you can also copy that into the same folder above.
* Unless you change the javascript, make sure you wrap your widget with an element with id="login-with-ajax". If you use the $before_widget ... variables, this should be done automatically.
* To force SSL, see [http://codex.wordpress.org/Administration_Over_SSL]("this page"). The plugin will automatically detect the wordpress settings.

== Screenshots ==

1. Add a login widget to your sidebars. Widget html is fully customizable and upgrade safe since they go in your theme files.

2. Smoothen the login process via ajax, avoid screen refreshes on login failures.

3. If your login is unsuccessful, user gets notified without loading a new page!

4. Customizable login/logout redirection settings. Control where users get directed to after login or logout (applicable to normal wp-login pages too).

5. Choose what your users see once logged in.

== Frequently Asked Questions ==

None yet!