<?php 
/*
 * This is the page users will see logged in. 
 * You can edit this, but for upgrade safety you should copy and modify this file into your template folder.
 * The location from within your template folder is plugins/login-with-ajax/ (create these directories if they don't exist)
*/
?>
<?php
	global $current_user;
	echo $before_widget . $before_title . __( 'Hi '. ucwords($current_user->display_name) ) . $after_title;
?>
	<?php 
		global $current_user;
		global $wpmu_version;
		get_currentuserinfo();
		$lwa_data = get_option('lwa_data');
	?>
	<table cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td class="avatar" id="LoginWithAjax_Avatar">
				<?php if ( function_exists('bp_loggedinuser_avatar_thumbnail') ) : ?>
					<?php bp_loggedinuser_avatar_thumbnail() ?>
				<?php else: ?>
					<?php echo get_avatar( $current_user->user_email, $size = '50' );  ?>
				<?php endif; ?>		
			</td>
			<td id="LoginWithAjax_Title">
				<?php
					//Admin URL
					if ( $lwa_data['admin_link'] == '1' ) {
						?>
						<a href="<?php bloginfo('siteurl') ?>/wp-admin/profile.php"><?= strtolower(__('Settings')) ?></a><br/>
						<?php
					}
					//Logout URL
					if ( function_exists( 'wp_logout_url' ) ) {
						?>
						<a id="wp-logout" href="<?= wp_logout_url( site_url() ) ?>"><?= strtolower(__( 'Log Out' )) ?></a>
						<?
					} else {
						?>
						<a id="wp-logout" href="<?= site_url() . '/wp-login.php?action=logout&amp;redirect_to=' . site_url() ?>"><?= strtolower(__( 'Log Out' )) ?></a>
						<?php
					}
				?>
				<?php
					if( !empty($wpmu_version) ) { 
						global $bp;
						foreach($bp->bp_nav as $nav_item){
							if($nav_item['css_id'] == 'settings'){
								?>
								 | <a href="<?= $nav_item['link'] ?>"><?= strtolower($nav_item['name']) ?></a>
								<?
							}
						}
						?>
						 | <a href="/wp-admin/">blog admin</a>
						<?php
					}
				?>
			</td>
		</tr>
	</table>
	<?php if ( !empty($wpmu_version) ) : ?>
	<div id="LoginWithAjax_Notifications">
		<?php
			$notifications = bp_core_get_notifications_for_user( $bp->loggedin_user->id );
		?>
		<h4>Notifications <?php echo ( count($notifications) > 0 && $notifications != false ) ? "(".count($notifications).")" : "" ?></h4>
		<?php				
			echo '<ul>';
			if ( $notifications ) { ?>
				<?php $counter = 0; ?>
				<?php for ( $i = 0; $i < count($notifications); $i++ ) { ?>
					<?php $alt = ( 0 == $counter % 2 ) ? ' class="alt"' : ''; ?>
					<li<?php echo $alt ?>><?php echo $notifications[$i] ?></li>
					<?php $counter++; ?>
				<?php } ?>
			<?php } else { ?>
				<li><?php _e( 'No new notifications.', 'buddypress' ); ?></li>
			<?php
			}
			echo '</ul>';
		?>
	</div>
	<?php endif; ?>
<?php
	echo $after_widget;
?>