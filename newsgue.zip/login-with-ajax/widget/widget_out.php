<?php 
/*
 * This is the page users will see logged out. 
 * You can edit this, but for upgrade safety you should copy and modify this file into your template folder.
 * The location from within your template folder is plugins/login-with-ajax/ (create these directories if they don't exist)
*/
?>
<?php
	echo $before_widget . $before_title . __('Log In') . $after_title;
?>
	<span id="LoginWithAjax_Status"></span>
	<form name="LoginWithAjax_Form" id="LoginWithAjax_Form" action="<?php echo site_url('wp-login.php', 'login_post') ?>" method="post">
		<table width='100%' cellspacing="0" cellpadding="0">
			<tr id="LoginWithAjax_Username">
				<td class="username_label">
					<label><?php _e( 'Username' ) ?></label>
				</td>
				<td class="username_input">
					<input type="text" name="log" id="lwa_user_login" class="input" value="<?php echo attribute_escape(stripslashes($user_login)); ?>" />
				</td>
			</tr>
			<tr id="LoginWithAjax_Password">
				<td class="password_label">
					<label><?php _e( 'Password' ) ?></label>
				</td>
				<td class="password_input">
					<input type="password" name="pwd" id="lwa_user_pass" class="input" value="" />
				</td>
			</tr>
			<tr id="LoginWithAjax_Submit">
				<td id="LoginWithAjax_SubmitButton">
					<input type="submit" name="wp-submit" id="lwa_wp-submit" value="<?php _e('Log In'); ?>" tabindex="100" />
					<input type="hidden" name="redirect_to" value="http://<?php echo $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] ?>" />
					<input type="hidden" name="testcookie" value="1" />
					<input type="hidden" name="login-with-ajax" value="login" />
				</td>
				<td id="LoginWithAjax_Remember">
					<input name="rememberme" type="checkbox" id="lwa_rememberme" value="forever" /> <label><?php _e( 'Remember Me' ) ?></label>
					<br />
					<a href="<?php echo site_url('wp-login.php?action=lostpassword', 'login') ?>" title="<?php _e('Password Lost and Found') ?>"><?php _e('Lost your password?') ?></a>
					<?php
						//Signup Links
						if ( get_option('users_can_register')/*&& get_option('login-with-ajax_register')=='1'*/ ) {
							echo "<br />";  
							// MU FIX
							global $wpmu_version;
							if (empty($wpmu_version)) {
								?>
								<a href="<?php echo site_url('wp-login.php?action=register', 'login') ?>"><?php _e('Register') ?></a>
								<?php 
							} else {
								?>
								<a href="<?php echo site_url('wp-signup.php', 'login') ?>"><?php _e('Register') ?></a>
								<?php 
							}
						} elseif ( true/*&& get_option('login-with-ajax_register')=='1'*/ && function_exists('bp_signup_page') ){
							echo "<br />";
							?>
							<a href="<?php echo bp_signup_page() ?>" title="<?php _e( 'Sign Up' ) ?>" rel="nofollow" /><?php _e( 'Sign Up' ) ?></a>
							<?php
						}
					?>
				</td>
			</tr>
		</table>
	</form>
<?php
	echo $after_widget;
?>