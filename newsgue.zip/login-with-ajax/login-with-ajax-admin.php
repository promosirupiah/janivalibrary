<?php
/*
Copyright (C) 2009 NetWebLogic LLC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// Class initialization
class LWA{
	// action function for above hook
	function LWA() {
		$page = add_options_page('Login With Ajax', 'Login With Ajax', 8, 'login-with-ajax', array(&$this,'options'));
	}
	
	function options() {
		add_option('lwa_data');
		$lwa_data = array();
		
		if( is_admin() and $_POST['lwasubmitted']==1 ){
			//Build the array of options here
			if(!$errors){
				foreach ($_POST as $postKey => $postValue){
					if( substr($postKey, 0, 4) == 'lwa_' ){
						//For now, no validation, since this is in admin area.
						if($postValue != ''){
							$lwa_data[substr($postKey, 4)] = $postValue;
						}
					}
				}
				update_option('lwa_data', $lwa_data);
				?>
				<div class="updated"><p><strong><?php _e('Options saved.'); ?></strong></p></div>
				<?php
			}else{
				?>
				<div class="error"><p><strong><?php _e('There were issues when saving your settings. Please try again.'); ?></strong></p></div>
				<?php				
			}
		}else{
			$lwa_data = get_option('lwa_data');	
		}
		?>
		<div class="wrap">
			<h2>Login With Ajax</h2>
			<p>If you have any suggestions, come over to our plugin page and leave a comment. It may just happen!</p>
			<form method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
				<table class="form-table">
					<tbody id="lwa-body">
						<tr valign="top">
							<td scope="row">
								<label>Custom Login Redirect</label>
							</td>
							<td>
								<input type="text" name="lwa_login_redirect" value='<?= $lwa_data['login_redirect'] ?>' />
								<br/>
								<i>If you'd like to send the user to a specific URL after login, enter it here (e.g. http://wordpress.org/)</i> 
							</td>
						</tr>
						<tr valign="top">
							<td scope="row">
								<label>Custom Logout Redirect</label>
							</td>
							<td>
								<input type="text" name="lwa_logout_redirect" value='<?= $lwa_data['logout_redirect'] ?>' />
								<br/>
								<i>If you'd like to send the user to a specific URL after logout, enter it here (e.g. http://wordpress.org/)</i> 
							</td>
						</tr>
						<tr valign="top">
							<td scope="row">
								<label>Show profile link to wp-admin?</label>
							</td>
							<td>
								<input type="checkbox" name="lwa_admin_link" value='1' <?= ($lwa_data['admin_link'] == '1') ? 'checked="checked"':'' ?> />
								<br/>
								<i>Checking this will show a link to their wp-admin profile in the sidebar widget when the user is logged in.</i>
							</td>
						</tr>
					</tbody>
					<tfoot>
						<tr valign="top">
							<td colspan="2">	
								<input type="hidden" name="lwasubmitted" value="1" />
								<p class="submit">
									<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
								</p>							
							</td>
						</tr>
					</tfoot>
				</table>
			</form>
		</div>
		<?php
	}
}

function LoginWithAjaxAdminInit(){
	global $LoginWithAjaxAdmin; 
	$LoginWithAjaxAdmin = new LWA();
}

// Start this plugin once all other plugins are fully loaded
add_action( 'admin_menu', 'LoginWithAjaxAdminInit' );
?>