<?php
/*
Plugin Name: Login With Ajax
Plugin URI: http://netweblogic.com/wordpress/plugins/login-with-ajax/
Description: Ajax driven login widget. Customisable from within your template folder, and advanced settings from the admin area. 
Author: NetWebLogic
Version: 1.2
Author URI: http://netweblogic.com/
Tags: Login, Ajax, Redirect, BuddyPress, MU, WPMU, sidebar, admin, widget

Copyright (C) 2008 NetWebLogic LLC

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

include_once('login-with-ajax-admin.php');

class LoginWithAjax {
	
	// Class initialization
	function LoginWithAjax() {
		//Make decision on what to display
		if ( function_exists('register_sidebar_widget') && !isset($_GET["login-with-ajax"]) ){
			//Enqueue scripts 
			wp_enqueue_script( "login-with-ajax", path_join(WP_PLUGIN_URL, basename( dirname( __FILE__ ) )."/login-with-ajax.js"), array( 'jquery' ) );
			//Enqueue stylesheets
			if( file_exists(get_template_directory().'/plugins/login-with-ajax/widget.css') ){
				wp_enqueue_style( "login-with-ajax-css", get_template_directory_uri().'/plugins/login-with-ajax/widget.css' );
			}else{
				wp_enqueue_style( "login-with-ajax-css", path_join(WP_PLUGIN_URL, basename( dirname( __FILE__ ) )."/widget/widget.css") );
			}
			//Register widget
			register_sidebar_widget('Login With Ajax', array(&$this, 'widget'));
			//Add logout/in redirection
			add_action('wp_logout', array(&$this, 'logoutRedirect'));
			add_action('wp_login', array(&$this, 'loginRedirect'));	
								
		}elseif ( isset($_GET["login-with-ajax"]) ) {
			$this->ajax();
		}
	}
	
	// Decides what action to take from the ajax request
	function ajax(){
		switch ( $_GET["login-with-ajax"] ) {
			case 'login':
				//A login has been requested
				$this->ajaxLogin();
				break;
			default:
				echo json_encode(array('result'=>0, 'error'=>'Unknown command requested'));
				exit();
				break;
		}
	}
	
	//Calls normal login and JSON encodes it
	function ajaxLogin(){
		$_POST['log'] = $_GET['log'];
		$_POST['pwd'] = $_GET['pwd'];
		$return = json_encode($this->login());
		if( isset($_GET['callback']) ){
			$return = $_GET['callback']."($return)";
		}
		echo $return;
		exit();
	}
	
	// Reads ajax login creds via POSt, calls the login script and interprets the result
	function login(){
		$return = array(); //What we send back
		$loginResult = wp_signon();
		
		if ( get_class($loginResult) == 'WP_User' ) {
			//User login successful
			/* @var $result WP_User */
			if(get_option('login-with-ajax_login-refresh') == 1){
				//Refresh page - todo
			}else{
				//Return true value
				$return['result'] = true;
			}
		} elseif ( get_class($loginResult) == 'WP_Error' ) {
			//User login failed
			/* @var $result WP_Error */
			$return['result'] = false;
			$return['error'] = $loginResult->get_error_message();
		} else {
			//Undefined Error
			$return['result'] = false;
			$return['error'] = 'An undefined error has ocurred';
		}
		$data = get_option('lwa_data');
		if($data['login_redirect'] != ''){
			$return['redirect'] = $data['login_redirect'];
		}
		//Return the result array with errors etc.
		return $return;
	}

	// Generate the login template
	function widget($args = array()) {
		extract($args);
		if(is_user_logged_in()){
			if( file_exists(TEMPLATEPATH.'/plugins/login-with-ajax/widget_in.php') ){
				include(TEMPLATEPATH.'/plugins/login-with-ajax/widget_in.php');
			}else{
				include('widget/widget_in.php');
			}
		}else{
			if( file_exists(TEMPLATEPATH.'/plugins/login-with-ajax/widget_out.php') ){
				include(TEMPLATEPATH.'/plugins/login-with-ajax/widget_out.php');
			}else{
				include('widget/widget_out.php');
			}
		}
	}
	
	function logoutRedirect(){
		$data = get_option('lwa_data');
		if($data['logout_redirect'] != ''){
			wp_redirect($data['logout_redirect']);
			exit();
		}
	}
	
	function loginRedirect(){
		$data = get_option('lwa_data');
		if($data['login_redirect'] != ''){
			wp_redirect($data['login_redirect']);
			exit();
		}
	}
}

function LoginWithAjaxInit(){
	global $LoginWithAjax; 
	$LoginWithAjax = new LoginWithAjax();
}

function login_with_ajax(){
	global $LoginWithAjax; 
	$LoginWithAjax->widget(); 
}

// Start this plugin once all other plugins are fully loaded
add_action( 'init', 'LoginWithAjaxInit' );

?>