<?php
/*
Plugin Name: RSSupplement
Plugin URI: http://wayofthegeek.org/downloads/
Description: Adds WP functions, copyright, and more to your RSS feed items.
Version: 1.3
Author: Jerry Stephens
Author URI: http://wayofthegeek.org/
*/


/*  
	Copyright 2007  Jerry Stephens  (email : migo@wayofthegeek.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


//Hook for adding admin menus
add_action('admin_menu','add_page');

//Add Options Page
function add_page(){
        add_options_page('RSSupplement Options','RSSupplement',10,__FILE__,'supplement_options');
}


function supplement_options(){
        
$newvalue = "";
$autoload = "yes";
$deprecated = " ";
        $option = array('set_checkboxes','set_freetext');
                        add_option($option[0],$newvalue,$deprecated,$autoload);
                        add_option($option[1],'',$deprecated,$autoload);
$check = get_option('set_checkboxes');
$count = count($check);
        ?><div class="wrap">
<h2>RSSupplement Options</h2>
        <form method="post" action="options.php">
        <?php wp_nonce_field('update-options'); 


echo '<table cellpadding="4" cellspacing="0">
<tr>
<td valign="top" rowspan="2" width="200px"><h4 style="padding: 0; margin: 0;">Click To Add</h4>';
echo'   <input type="checkbox" name="set_checkboxes[2]" value="CHECKED" '. $check[2] .' /> Post Author<br />
        <input type="checkbox" name="set_checkboxes[3]" value="CHECKED" '. $check[3] .' /> Copyright<br />
        <input type="checkbox" name="set_checkboxes[4]" value="CHECKED" '. $check[4] .' /> Categories<br />
        <input type="checkbox" name="set_checkboxes[5]" value="CHECKED" '. $check[5] .' /> Comment Link<br />';

echo'</td>
<td valign="top" style="border-left: 1px solid #CCC;">';

        echo'<h4 style="padding: 0; margin: 0;">Anything else you would like to add?</h4>
        <small>HTML and plain-text only. WP &amp; PHP functions are not supported in this release.<br /></small><textarea name="set_freetext" rows="10px" cols="100px">'. get_option($option[1]).'</textarea>';
        
echo'</td>
</tr>
<tr>
<td style="border-left: 1px solid #CCC;" align="right">';        
        echo'<input type="hidden" name="action" value="update" />
<input type="hidden" name="page_options" value="set_checkboxes,set_freetext" />
        <p class="submit">
<input type="submit" name="Submit" value="Update Options » " />
</p>';

echo'</td>
</tr>
</table>
</form>
        </div>';
}


function supplement($notice){
$check = get_option(set_checkboxes);
$freetext = nl2br(get_option('set_freetext'));

    // to be compatible with older PHP4 installations
    // don't use fancy ob_XXX shortcut functions
    ob_start();
    eval("?>$freetext<?php ");
    $freetext = ob_get_contents();
        if($check[2] == "CHECKED"){
                $author = 'by '.ucfirst(get_the_author()).' ';
        }
        else{
                $author = "";
        }
        if($check[3] == "CHECKED"){
                $copyright = '<br />&copy;' . date("Y") . ' <a href="' . get_bloginfo('url') . '">' . get_bloginfo('name') . '</a>. All Rights Reserved.';
        }
        else{
                $copyright = "";
        }
        if($check[4] == "CHECKED"){
                $get_cat = get_the_category();
                $get_cat_link = get_category_link($get_cat[0]->cat_ID);
                $category = 'posted in <a href="'.$get_cat_link.'">' .$get_cat[0]->cat_name.'</a> ';
        }
        else{
                $category = "";
        }
        if($check[5] == "CHECKED"){
                $comment_link = get_permalink();
                $comments = '<a href="'.$comment_link.'#comments">Leave A Comment</a>';
        }
        else{
                $comments = "";
        }
        
    ob_end_clean();

$notice = '<div style="display:block"><small><em>'.$category.$author.$comments.$copyright.$freetext.'</em></small></div>';
return $notice;
}

function content_supplement($addition){
                $addition = the_content()._e(supplement($notice));
                return $addition;
}
function excerpt_supplement($addition){
                $addition = the_excerpt()._e(supplement($notice));
                return $addition;
}
$rss = get_option(rss_use_excerpt);
if($rss == 1){
    add_filter('the_excerpt_rss', 'excerpt_supplement');
}
else{
    add_filter('the_excerpt_rss', 'content_supplement');
}

?>