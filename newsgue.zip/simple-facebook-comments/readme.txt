=== Simple Facebook Comments ===
Contributors: royaldeer
Donate link: http://www.royaldeerdesign.com/
Tags: facebook, comments
Requires at least: 3.3
Tested up to: 3.3
Stable tag: 0.7.6

Simple to implement Facebook Comments.

== Description ==

It is extremely simple to implement this Facebook comments plugin. There are very few options for customizing this plugin, however, thanks to this approach, there are no confusing options and unnecessary settings.

It is very simplified plugin that allows Facebook Comments to be incorporated within your blog in minutes.

This plugin works perfectly with the newest version of WordPress (3.3).

If you have questions, suggestions, or feedback about the plugin, please contact us via email: info[at]royaldeerdesign[dot]com

Sites that use the plugin: http://thehookup.com

Support and contact: http://www.royaldeerdesign.com
== Installation ==


1. To turn off WordPress comments, go to your discussion settings and uncheck the option that states "Allow people to post comments on new articles."

2. To create a Facebook App - the name of the app won't matter, for example, you can use "Website Comments".

3. To edit an app- Go to App Setup, and insert your website URL (for example http://royaldeerdesign.com) into the section Web Site.

4. Copy your App ID and save changes.

5. Paste your App ID in the box on the Plugin Settings Page.

== Frequently Asked Questions ==

= How to get help with this plugin? =

Contact us at www.royaldeerdesign.com

= How to get help with this plugin?  =

For more specific help, feel free to contact us at http://www.royaldeerdesign.com

= Can I expect new versions of the plugin?  =

Yes, new versions are coming. In fact, we plan to publish new version soon that has more options. Don�t worry, it will still be just as easy to set up.


== Screenshots ==

1. step1.jpg

== Changelog ==

= 0.7.6 =
* Major improvements to the functionality, including Comments Counter.