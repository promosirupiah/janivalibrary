=== Ozh' Better Feed ===
Donate link: http://planetozh.com/exit/donate
Tags: ozh, feed, rss, footer, related, atom, feedburner
Requires at least: 2.8
Tested up to: 9.9
Stable tag: trunk

Enhance feed items with anything: ads, copyright, "Add to delicious", "Read More (400 words)" links...

== Description ==

Your feed, on steroids : add a custom footer to RSS items with, for example, a copyright notice, a "Read More (400 words)" links, an "Add to del.icio.us" link, a list of related entries, or anything really (even custom PHP functions). Compatible with Feedburner or similar services.

Improve connectivity between your feed and your site !!

For documentation and tips, please refer to the official plugin page for [Better Feed](http://planetozh.com/blog/my-projects/wordpress-plugin-better-feed-rss/ "Better Feed")

== Installation ==

Installation is, as usual :

1. Upload files to your `/wp-content/plugins/` directory (preserve sub-directory structure if applicable)
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Refer to the official plugin page for documentation, usage and tips