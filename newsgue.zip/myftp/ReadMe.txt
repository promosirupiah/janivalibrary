�2008 Themes-plugins.com

MyFTP is a file management Plugin for WordPress that enables a blog administrator to (much like an FTP client) navigate files and folders on the server where their WordPress installation is hosted. The administrator can then edit, delete or upload files on the fly from within the WordPress administration panel. It is also possible to create new folders and directory structures.

This Software was written by T-roy http://themes-plugins.com. Look, styling and original idea was inspired by Lance http://lancelhoff.com

MyFTP is considered Open Source. Please see the included GPU GPL License for more information.


For additional plugin information, including installation and usage, please visit http://themes-plugins.com/myftp-wordpress-plugin/