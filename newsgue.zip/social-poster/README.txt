//*******************************************************************************//
// Auto Social Poster - version 3.90 (for Wordpress 2.10+)
// Copyright 2006-2008 Interactive Gambit LLC
// http://www.mass-automation.com - All Rights Reserved
// By downloading, installing or using this software you agree to the
// licensing terms contained in the license.txt document. 
//*******************************************************************************//

RESTRICTIONS
==============
You have the right to install this plugin on personal and/or business related wordpress blogs that belong to, or are owned by you. You do not have the license to install the plugin on blogs not owned by you. 

You may not modify, network, rent, lease, make derivative works of, or otherwise distribute the Product unless authorized; nor can you make the Product available by "bulletin boards," online services, or network links of any kind; nor can you create similar works based upon the Product or Physical Version in whole or in part. 
==============


INSTALLATION
--------------------
* Upload the contents of the zip folder to your /wp-content/plugins/ folder.
* CHMOD file mm_conf.php to 777
  - file is located in /wp-content/plugins/social-poster/


ACTIVATE THE PLUGIN
--------------------
Activate your plugin by going to your PLUGINS tab and choosing to activate the plugin called Auto Social Poster.

Next, add your account information at OPTIONS --> AUTO SOCIAL POSTER


USAGE INSTRUCTIONS
--------------------
For complete user instructions please go to: 
http://www.mass-automation.com/documentation/asp/
Contact us at http://www.mass-automation.com/support/
