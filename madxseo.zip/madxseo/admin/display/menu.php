<?php

/**
 * Class madxseoAdminMenus
 *
 * @since 2.3.11.5
 */
class madxseoAdminMenus {

	/**
	 * Constructor to add the actions.
	 */
	function __construct() {
		
		add_action( 'network_admin_menu', array( $this, 'remove_menus' ), 15 );
		
		if ( is_multisite()){
			return;
		}
		
		if ( current_user_can( 'manage_options' ) || current_user_can( 'aiosp_manage_seo' ) ) {
			add_action( 'admin_menu', array( $this, 'add_pro_submenu' ), 11 );
		} else {
			return;
		}
	}

	function remove_menus(){
		remove_menu_page( madxseo_PLUGIN_DIRNAME . '/madxseo_class.php' ); // Remove madxseo menu from the network admin.
	}

	/**
	 * Adds Upgrade link to our menu.
	 *
	 * @since 2.3.11.5
	 */
	function add_pro_submenu() {
		global $submenu;
		$url = 'https://semperplugins.com/madxartwork-seo-pack-pro-version/?loc=aio_menu';
		$upgrade_text = __( 'Upgrade to Pro', 'madxartwork-seo-pack' );
		$submenu['madxartwork-seo-pack/madxseo_class.php'][] = array(
			"<span class='upgrade_menu_link'>$upgrade_text</span>",
			'manage_options',
			$url,
		);
	}
}

	new madxseoAdminMenus();

