<div class="welcome-panel">
	<div class="welcome-panel-content">
		<div class="welcome-panel-column-container">
			<div class="welcome-panel-column">
				<h3><?php echo esc_html( __( 'Support MadxArtwork SEO Pack', 'madxartwork-seo-pack' ) ); ?></h3>
				<p class="message welcome-icon welcome-edit-page"><?php echo esc_html( __( 'There are many ways you can help support MadxArtwork SEO Pack.', 'madxartwork-seo-pack' ) ); ?></p>
				<p class="message madxseo-message welcome-icon welcome-edit-page"><?php echo esc_html( __( 'Upgrade to MadxArtwork SEO Pack Pro to access priority support and premium features.', 'madxartwork-seo-pack' ) ); ?></p>
				<p class="call-to-action"><a
						href="https://semperplugins.com/madxartwork-seo-pack-pro-version/?loc=aio_welcome"
						target="_blank"
						class="button button-primary button-orange"><?php echo __( 'Upgrade', 'madxartwork-seo-pack' ); ?></a>
				</p>
				<p class="message madxseo-message welcome-icon welcome-edit-page"><?php echo esc_html( __( 'Help translate MadxArtwork SEO Pack into your language.', 'madxartwork-seo-pack' ) ); ?></p>
				<p class="call-to-action"><a
						href="https://translate.wordpress.org/projects/wp-plugins/madxartwork-seo-pack"
						class="button button-primary"
						target="_blank"><?php echo __( 'Translate', 'madxartwork-seo-pack' ); ?></a></p>
			</div>

			<div class="welcome-panel-column">
				<h3><?php echo esc_html( __( 'Get Started', 'madxartwork-seo-pack' ) ); ?></h3>
				<ul>
					<li><a href="https://semperplugins.com/documentation/quick-start-guide/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Beginners Guide for MadxArtwork SEO Pack', 'madxartwork-seo-pack' ); ?></a>

					</li>
					<li><a href="https://semperplugins.com/documentation/beginners-guide-to-xml-sitemaps/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Beginners Guide for XML Sitemap module', 'madxartwork-seo-pack' ); ?></a>
					</li>
					<li><a href="https://semperplugins.com/documentation/beginners-guide-to-social-meta/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Beginners Guide for Social Meta module', 'madxartwork-seo-pack' ); ?></a>
					</li>
					<li><a href="https://semperplugins.com/documentation/top-tips-for-good-on-page-seo/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Tips for good on-page SEO', 'madxartwork-seo-pack' ); ?></a>
					</li>
					<li>
						<a href="https://semperplugins.com/documentation/quality-guidelines-for-seo-titles-and-descriptions/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Quality guidelines for SEO titles and descriptions', 'madxartwork-seo-pack' ); ?></a>
					</li>
					<li><a href="https://semperplugins.com/documentation/submitting-an-xml-sitemap-to-google/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Submit an XML Sitemap to Google', 'madxartwork-seo-pack' ); ?></a>
					</li>
					<li><a href="https://semperplugins.com/documentation/setting-up-google-analytics/"
						   target="_blank"
						   class="welcome-icon welcome-add-page"><?php echo __( 'Set up Google Analytics', 'madxartwork-seo-pack' ); ?></a>
					</li>
				</ul>
			</div>

			<div class="welcome-panel-column">
				<h3><?php echo esc_html( __( 'Did You Know?', 'madxartwork-seo-pack' ) ); ?></h3>
				<ul>
					<li><a href="https://semperplugins.com/documentation/"
						   target="_blank"
						   class="welcome-icon welcome-learn-more"><?php echo __( 'We have complete documentation on every setting and feature', 'madxartwork-seo-pack' ); ?></a>

					</li>
					<li><a href="https://semperplugins.com/videos/"
						   target="_blank"
						   class="welcome-icon welcome-learn-more"><?php echo __( 'Access to video tutorials about SEO with the Pro version', 'madxartwork-seo-pack' ); ?></a>
					</li>
					<li><a href="https://semperplugins.com/madxartwork-seo-pack-pro-version/?loc=aio_welcome"
						   target="_blank"
						   class="welcome-icon welcome-learn-more"><?php echo __( 'Control SEO on categories, tags and custom taxonomies with the Pro version', 'madxartwork-seo-pack' ); ?></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<p>
		<a href=" <?php echo get_admin_url( null, 'admin.php?page=' . madxseo_PLUGIN_DIRNAME . '/madxseo_class.php' ); ?>  "><?php _e( 'Continue to the General Settings', 'madxartwork-seo-pack' ); ?></a> &raquo;
	</p>
</div>
