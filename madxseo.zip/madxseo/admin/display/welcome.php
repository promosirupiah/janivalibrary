<?php

if ( ! class_exists( 'madxseo_welcome' ) ) {

	/**
	 * Class madxseo_welcome
	 */
	// @codingStandardsIgnoreStart
	class madxseo_welcome {
	// @codingStandardsIgnoreEnd
		/**
		 * Constructor to add the actions.
		 */
		function __construct() {

			if ( madxseoPRO ) {
				return;
			}

			add_action( 'admin_menu', array( $this, 'add_menus' ) );
			add_action( 'admin_menu', array( $this, 'remove_pages' ), 999 );
			add_action( 'admin_enqueue_scripts', array( $this, 'welcome_screen_assets' ) );

		}

		/**
		 * Enqueues style and script.
		 *
		 * @param $hook
		 */
		function welcome_screen_assets( $hook ) {

			if ( 'dashboard_page_madxseo-about' === $hook ) {

				wp_enqueue_style( 'madxseo_welcome_css', madxseo_PLUGIN_URL . 'css/welcome.css', array(), madxseo_VERSION );
				wp_enqueue_script( 'madxseo_welcome_js', madxseo_PLUGIN_URL . 'js/welcome.js', array( 'jquery' ), madxseo_VERSION, true );
			}
		}

		/**
		 * Removes unneeded pages.
		 *
		 * @since 2.3.12 Called via admin_menu action instead of admin_head.
		 */
		function remove_pages() {
			remove_submenu_page( 'index.php', 'madxseo-about' );
			remove_submenu_page( 'index.php', 'madxseo-credits' );
		}

		/**
		 * Adds (hidden) menu.
		 */
		function add_menus() {
			add_dashboard_page(
				__( 'Welcome to MadxArtwork SEO Pack', 'madxartwork-seo-pack' ),
				__( 'Welcome to MadxArtwork SEO Pack', 'madxartwork-seo-pack' ),
				'manage_options',
				'madxseo-about',
				array( $this, 'about_screen' )
			);

		}

		/**
		 * Initial stuff.
		 *
		 * @param bool $activate
		 */
		function init( $activate = false ) {

			if ( ! is_admin() ) {
				return;
			}

			// Bail if activating from network, or bulk
			if ( is_network_admin() || isset( $_GET['activate-multi'] ) ) {
				return;
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			wp_cache_flush();
			aiosp_common::clear_wpe_cache();

			delete_transient( '_madxseo_activation_redirect' );

			$seen = 0;
			$seen = get_user_meta( get_current_user_id(), 'madxseo_seen_about_page', true );

			update_user_meta( get_current_user_id(), 'madxseo_seen_about_page', madxseo_VERSION );

			if ( madxseoPRO ) {
				return;
			}

			if ( ( madxseo_VERSION === $seen ) || ( true !== $activate ) ) {
				return;
			}

			wp_safe_redirect( add_query_arg( array( 'page' => 'madxseo-about' ), admin_url( 'index.php' ) ) );
			exit;
		}

		/**
		 * Outputs the about screen.
		 */
		function about_screen() {
			aiosp_common::clear_wpe_cache();
			$version = madxseo_VERSION;

			?>

			<div class="wrap about-wrap">
				<h1><?php printf( esc_html__( 'Welcome to MadxArtwork SEO Pack %s', 'madxartwork-seo-pack' ), $version ); ?></h1>
				<div
					class="about-text"><?php printf( esc_html__( 'MadxArtwork SEO Pack %s contains new features, bug fixes, increased security, and tons of under the hood performance improvements.', 'madxartwork-seo-pack' ), $version ); ?></div>

				<h2 class="nav-tab-wrapper">
					<a class="nav-tab nav-tab-active" id="madxseo-about"
					   href="<?php echo esc_url( admin_url( add_query_arg( array( 'page' => 'madxseo-about' ), 'index.php' ) ) ); ?>">
						<?php esc_html_e( 'What&#8217;s New', 'madxartwork-seo-pack' ); ?>
					</a>
					<a class="nav-tab" id="madxseo-credits"
					   href="<?php echo esc_url( admin_url( add_query_arg( array( 'page' => 'madxseo-credits' ), 'index.php' ) ) ); ?>">
						<?php esc_html_e( 'Credits', 'madxartwork-seo-pack' ); ?>
					</a>
				</h2>


				<div id='sections'>
					<section><?php include_once( madxseo_PLUGIN_DIR . 'admin/display/welcome-content.php' ); ?></section>
					<section><?php include_once( madxseo_PLUGIN_DIR . 'admin/display/credits-content.php' ); ?></section>
				</div>

			</div>


			<?php

		}

	}

}
