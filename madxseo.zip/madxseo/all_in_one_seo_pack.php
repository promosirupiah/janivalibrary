<?php

/*
Plugin Name: MadxArtwork SEO Pack Pro
Plugin URI: http://MadxArtwork.net
Description: Out-of-the-box SEO for your WordPress blog. Features like XML Sitemaps, SEO for custom post types, SEO for blogs or business sites, SEO for ecommerce sites, and much more. Over 30 million downloads since 2007.
Version: 2.12
Author: MadxArtwork
Author URI: https://MadxArtwork.net
Text Domain: madxartwork-seo-pack
Domain Path: /i18n/
*/

/*
Copyright (C) 2007-2019 MadxArtwork, https://MadxArtwork.net

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * MadxArtwork SEO Pack.
 * The original WordPress SEO plugin.
 *
 * @package madxartwork-seo-Pack
 * @version 2.12
 */

if ( ! defined( 'madxseoPRO' ) ) {
	define( 'madxseoPRO', true );
}
if ( ! defined( 'madxseo_VERSION' ) ) {
	define( 'madxseo_VERSION', '2.12' );
}
global $madxseo_plugin_name;
$madxseo_plugin_name = 'MadxArtwork SEO Pack Pro';

/*
 * DO NOT EDIT BELOW THIS LINE.
 */

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( madxseoPRO ) {

	add_action( 'admin_head', 'disable_all_in_one_free', 1 );

}

if ( ! function_exists( 'aiosp_add_cap' ) ) {

	function aiosp_add_cap() {
		/*
		 TODO we should put this into an install script. We just need to make sure it runs soon enough and we need to make
		 sure people updating from previous versions have access to it.
		*/

		$role = get_role( 'administrator' );
		if ( is_object( $role ) ) {
			$role->add_cap( 'aiosp_manage_seo' );
		}
	}
}
add_action( 'plugins_loaded', 'aiosp_add_cap' );

if ( ! defined( 'madxseo_PLUGIN_NAME' ) ) {
	define( 'madxseo_PLUGIN_NAME', $madxseo_plugin_name );
}

if ( ! defined( 'madxseo_PLUGIN_DIR' ) ) {
	define( 'madxseo_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
} elseif ( madxseo_PLUGIN_DIR !== plugin_dir_path( __FILE__ ) ) {
	/*
	 This is not a great message.
		add_action( 'admin_notices', create_function( '', 'echo "' . "<div class='error'>" . sprintf(
					__( "%s detected a conflict; please deactivate the plugin located in %s.", 'madxartwork-seo-pack' ),
					$madxseo_plugin_name, madxseo_PLUGIN_DIR ) . "</div>" . '";' ) );
	*/
	return;
}

if ( ! defined( 'madxseo_PLUGIN_BASENAME' ) ) {
	define( 'madxseo_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
}
if ( ! defined( 'madxseo_PLUGIN_DIRNAME' ) ) {
	define( 'madxseo_PLUGIN_DIRNAME', dirname( madxseo_PLUGIN_BASENAME ) );
}
if ( ! defined( 'madxseo_PLUGIN_URL' ) ) {
	define( 'madxseo_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'madxseo_PLUGIN_IMAGES_URL' ) ) {
	define( 'madxseo_PLUGIN_IMAGES_URL', madxseo_PLUGIN_URL . 'images/' );
}
if ( ! defined( 'madxseo_BASELINE_MEM_LIMIT' ) ) {
	define( 'madxseo_BASELINE_MEM_LIMIT', 268435456 );
} // 256MB
if ( ! defined( 'WP_CONTENT_URL' ) ) {
	define( 'WP_CONTENT_URL', site_url() . '/wp-content' );
}
if ( ! defined( 'WP_ADMIN_URL' ) ) {
	define( 'WP_ADMIN_URL', site_url() . '/wp-admin' );
}
if ( ! defined( 'WP_CONTENT_DIR' ) ) {
	define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
}
if ( ! defined( 'WP_PLUGIN_URL' ) ) {
	define( 'WP_PLUGIN_URL', WP_CONTENT_URL . '/plugins' );
}
if ( ! defined( 'WP_PLUGIN_DIR' ) ) {
	define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );
}

global $aiosp, $madxseo_options, $madxseo_modules, $madxseo_module_list, $aiosp_activation, $madxseo_mem_limit, $madxseo_get_pages_start, $madxseo_admin_menu;
$madxseo_get_pages_start = $madxseo_admin_menu = 0;

if ( madxseoPRO ) {
	global $madxseo_update_checker;
}

$madxseo_options = get_option( 'madxseo_options' );

// @codingStandardsIgnoreStart
$madxseo_mem_limit = @ini_get( 'memory_limit' );
// @codingStandardsIgnoreEnd

if ( ! function_exists( 'madxseo_convert_bytestring' ) ) {
	/**
	 * @param $byte_string
	 *
	 * @return int
	 */
	function madxseo_convert_bytestring( $byte_string ) {
		$num = 0;
		preg_match( '/^\s*([0-9.]+)\s*([KMGTPE])B?\s*$/i', $byte_string, $matches );
		if ( ! empty( $matches ) ) {
			$num = (float) $matches[1];
			switch ( strtoupper( $matches[2] ) ) {
				case 'E':
					$num *= 1024;
					// fall through.
				case 'P':
					$num *= 1024;
					// fall through.
				case 'T':
					$num *= 1024;
					// fall through.
				case 'G':
					$num *= 1024;
					// fall through.
				case 'M':
					$num *= 1024;
					// fall through.
				case 'K':
					$num *= 1024;
			}
		}

		return intval( $num );
	}
}

if ( is_array( $madxseo_options ) && isset( $madxseo_options['modules'] ) && isset( $madxseo_options['modules']['aiosp_performance_options'] ) ) {
	$perf_opts = $madxseo_options['modules']['aiosp_performance_options'];
	if ( isset( $perf_opts['aiosp_performance_memory_limit'] ) ) {
		$madxseo_mem_limit = $perf_opts['aiosp_performance_memory_limit'];
	}
	if ( isset( $perf_opts['aiosp_performance_execution_time'] ) && ( '' !== $perf_opts['aiosp_performance_execution_time'] ) ) {
		// @codingStandardsIgnoreStart
		@ini_set( 'max_execution_time', (int) $perf_opts['aiosp_performance_execution_time'] );
		@set_time_limit( (int) $perf_opts['aiosp_performance_execution_time'] );
		// @codingStandardsIgnoreEnd
	}
} else {
	$madxseo_mem_limit = madxseo_convert_bytestring( $madxseo_mem_limit );
	if ( ( $madxseo_mem_limit > 0 ) && ( $madxseo_mem_limit < madxseo_BASELINE_MEM_LIMIT ) ) {
		$madxseo_mem_limit = madxseo_BASELINE_MEM_LIMIT;
	}
}

if ( ! empty( $madxseo_mem_limit ) ) {
	if ( ! is_int( $madxseo_mem_limit ) ) {
		$madxseo_mem_limit = madxseo_convert_bytestring( $madxseo_mem_limit );
	}
	if ( ( $madxseo_mem_limit > 0 ) && ( $madxseo_mem_limit <= madxseo_BASELINE_MEM_LIMIT ) ) {
		// @codingStandardsIgnoreStart
		@ini_set( 'memory_limit', $madxseo_mem_limit );
		// @codingStandardsIgnoreEnd
	}
}

$aiosp_activation    = false;
$madxseo_module_list = array(
	'sitemap',
	'opengraph',
	'robots',
	'file_editor',
	'importer_exporter',
	'bad_robots',
	'performance',
); // list all available modules here

if ( madxseoPRO ) {
	$madxseo_module_list[] = 'video_sitemap';
}

if ( class_exists( 'All_in_One_SEO_Pack' ) ) {
	add_action( 'admin_notices', 'admin_notices_already_defined' );
	function admin_notices_already_defined() {
		echo "<div class=\'error\'>The MadxArtwork SEO Pack class is already defined";
		if ( class_exists( 'ReflectionClass' ) ) {
			$_r = new ReflectionClass( 'All_in_One_SEO_Pack' );
			echo ' in ' . $_r->getFileName();
		}
		echo ', preventing MadxArtwork SEO Pack from loading.</div>';
	}

	return;
}

if ( madxseoPRO ) {

	require( madxseo_PLUGIN_DIR . 'pro/sfwd_update_checker.php' );
	$aiosp_update_url = 'https://semperplugins.com/upgrade_plugins.php';
	if ( defined( 'madxseo_UPDATE_URL' ) ) {
		$aiosp_update_url = madxseo_UPDATE_URL;
	}
	$madxseo_update_checker = new SFWD_Update_Checker(
		$aiosp_update_url,
		__FILE__,
		'madxseo'
	);

	$madxseo_update_checker->plugin_name     = madxseo_PLUGIN_NAME;
	$madxseo_update_checker->plugin_basename = madxseo_PLUGIN_BASENAME;
	if ( ! empty( $madxseo_options['aiosp_license_key'] ) ) {
		$madxseo_update_checker->license_key = $madxseo_options['aiosp_license_key'];
	} else {
		$madxseo_update_checker->license_key = '';
	}
	$madxseo_update_checker->options_page = madxseo_PLUGIN_DIRNAME . '/madxseo_class.php';
	$madxseo_update_checker->renewal_page = 'https://semperplugins.com/madxartwork-seo-pack-pro-version/';

	$madxseo_update_checker->addQueryArgFilter( array( $madxseo_update_checker, 'add_secret_key' ) );
}


if ( ! function_exists( 'madxseo_activate' ) ) {

	function madxseo_activate() {

		// Check if we just got activated.
		global $aiosp_activation;
		if ( madxseoPRO ) {
			global $madxseo_update_checker;
		}
		$aiosp_activation = true;

		// These checks might be duplicated in the function being called.
		if ( ! is_network_admin() || ! isset( $_GET['activate-multi'] ) ) {
			set_transient( '_madxseo_activation_redirect', true, 30 ); // Sets 30 second transient for welcome screen redirect on activation.
		}

		delete_user_meta( get_current_user_id(), 'madxseo_yst_detected_notice_dismissed' );

		if ( madxseoPRO ) {
			$madxseo_update_checker->checkForUpdates();
		}
	}
}

add_action( 'plugins_loaded', 'madxseo_init_class' );

if ( ! function_exists( 'aiosp_plugin_row_meta' ) ) {

	add_filter( 'plugin_row_meta', 'aiosp_plugin_row_meta', 10, 2 );

	/**
	 * @param $actions
	 * @param $plugin_file
	 *
	 * @return array
	 */
	function aiosp_plugin_row_meta( $actions, $plugin_file ) {

			$action_links = array(

				'settings' => array(
					'label' => __( 'Feature Request/Bug Report', 'madxartwork-seo-pack' ),
					'url'   => 'https://github.com/madxartwork/madxartwork-seo-pack/issues/new',
				),

			);

		return aiosp_action_links( $actions, $plugin_file, $action_links, 'after' );
	}
}

if ( ! function_exists( 'aiosp_add_action_links' ) ) {


	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'aiosp_add_action_links', 10, 2 );

	/**
	 * @param $actions
	 * @param $plugin_file
	 *
	 * @return array
	 */
	function aiosp_add_action_links( $actions, $plugin_file ) {
		if ( ! is_array( $actions ) ) {
			return $actions;
		}

		$madxseo_plugin_dirname = madxseo_PLUGIN_DIRNAME;
		$action_links           = array();
		$action_links           = array(
			'settings' => array(
				'label' => __( 'SEO Settings', 'madxartwork-seo-pack' ),
				'url'   => get_admin_url( null, "admin.php?page=$madxseo_plugin_dirname/madxseo_class.php" ),
			),

			'forum' => array(
				'label' => __( 'Support Forum', 'madxartwork-seo-pack' ),
				'url'   => 'https://semperplugins.com/support/',
			),

			'docs' => array(
				'label' => __( 'Documentation', 'madxartwork-seo-pack' ),
				'url'   => 'https://semperplugins.com/documentation/',
			),

		);

		unset( $actions['edit'] );

		if ( ! madxseoPRO ) {
			$action_links['proupgrade'] =
				array(
					'label' => __( 'Upgrade to Pro', 'madxartwork-seo-pack' ),
					'url'   => 'https://semperplugins.com/plugins/madxartwork-seo-pack-pro-version/?loc=plugins',

				);
		}

		return aiosp_action_links( $actions, $plugin_file, $action_links, 'before' );
	}
}

if ( ! function_exists( 'aiosp_action_links' ) ) {

	/**
	 * @param $actions
	 * @param $plugin_file
	 * @param array $action_links
	 * @param string $position
	 *
	 * @return array
	 */
	function aiosp_action_links( $actions, $plugin_file, $action_links = array(), $position = 'after' ) {
		static $plugin;
		if ( ! isset( $plugin ) ) {
			$plugin = plugin_basename( __FILE__ );
		}
		if ( $plugin === $plugin_file && ! empty( $action_links ) ) {
			foreach ( $action_links as $key => $value ) {
				$link = array( $key => '<a href="' . $value['url'] . '">' . $value['label'] . '</a>' );
				if ( 'after' === $position ) {
					$actions = array_merge( $actions, $link );
				} else {
					$actions = array_merge( $link, $actions );
				}
			}//foreach
		}// if
		return $actions;
	}
}

if ( ! function_exists( 'madxseo_init_class' ) ) {
	/**
	 * Inits madxartwork-seo plugin class.
	 *
	 * @since ?? // When was this added?
	 * @since 2.3.12.3 Loads third party compatibility class.
	 */
	function madxseo_init_class() {
		global $aiosp;
		load_plugin_textdomain( 'madxartwork-seo-pack', false, dirname( plugin_basename( __FILE__ ) ) . '/i18n/' );
		require_once( madxseo_PLUGIN_DIR . 'inc/madxseo_functions.php' );
		require_once( madxseo_PLUGIN_DIR . 'madxseo_class.php' );
		require_once( madxseo_PLUGIN_DIR . 'inc/madxseo_updates_class.php' );
		require_once( madxseo_PLUGIN_DIR . 'inc/commonstrings.php' );
		require_once( madxseo_PLUGIN_DIR . 'admin/display/general-metaboxes.php' );
		require_once( madxseo_PLUGIN_DIR . 'inc/aiosp_common.php' );
		require_once( madxseo_PLUGIN_DIR . 'admin/meta_import.php' );
		require_once( madxseo_PLUGIN_DIR . 'inc/translations.php' );
		require_once( madxseo_PLUGIN_DIR . 'public/opengraph.php' );
		require_once( madxseo_PLUGIN_DIR . 'inc/compatability/abstract/aiosep_compatible.php' );
		require_once( madxseo_PLUGIN_DIR . 'inc/compatability/compat-init.php' );
		require_once( madxseo_PLUGIN_DIR . 'public/front.php' );
		require_once( madxseo_PLUGIN_DIR . 'public/google-analytics.php' );
		require_once( madxseo_PLUGIN_DIR . 'admin/display/welcome.php' );
		require_once( madxseo_PLUGIN_DIR . 'admin/display/dashboard_widget.php' );
		require_once( madxseo_PLUGIN_DIR . 'admin/display/menu.php' );

		$madxseo_welcome = new madxseo_welcome(); // TODO move this to updates file.

		if ( madxseoPRO ) {
			require_once( madxseo_PLUGIN_DIR . 'pro/class-aio-pro-init.php' ); // Loads pro files and other pro init stuff.
		}
		aiosp_seometa_import(); // call importer functions... this should be moved somewhere better

		$aiosp = new All_in_One_SEO_Pack();

		$madxseo_updates = new madxseo_Updates();

		if ( madxseoPRO ) {
			$madxseo_pro_updates = new madxseo_Pro_Updates();
			add_action( 'admin_init', array( $madxseo_pro_updates, 'version_updates' ), 12 );
		}

		add_action( 'admin_init', 'madxseo_welcome' );

		if ( madxseo_option_isset( 'aiosp_unprotect_meta' ) ) {
			add_filter( 'is_protected_meta', 'madxseo_unprotect_meta', 10, 3 );
		}

		add_action( 'init', array( $aiosp, 'add_hooks' ) );
		add_action( 'admin_init', array( $madxseo_updates, 'version_updates' ), 11 );

		if ( defined( 'DOING_AJAX' ) && ! empty( $_POST ) && ! empty( $_POST['action'] ) && 'madxseo_ajax_scan_header' === $_POST['action'] ) {
			remove_action( 'init', array( $aiosp, 'add_hooks' ) );
			add_action( 'admin_init', 'madxseo_scan_post_header' );
			add_action( 'shutdown', 'madxseo_ajax_scan_header' ); // if the action doesn't run -- pdb
			include_once( ABSPATH . 'wp-admin/includes/screen.php' );
			global $current_screen;
			if ( class_exists( 'WP_Screen' ) ) {
				$current_screen = WP_Screen::get( 'front' );
			}
		}
	}
}



if ( ! function_exists( 'madxseo_welcome' ) ) {
	function madxseo_welcome() {
		if ( get_transient( '_madxseo_activation_redirect' ) ) {
			$madxseo_welcome = new madxseo_welcome();
			delete_transient( '_madxseo_activation_redirect' );
			$madxseo_welcome->init( true );
		}

	}
}

add_action( 'init', 'madxseo_load_modules', 1 );
// add_action( 'after_setup_theme', 'madxseo_load_modules' );
if ( is_admin() || defined( 'madxseo_UNIT_TESTING' ) ) {
	add_action( 'wp_ajax_madxseo_ajax_save_meta', 'madxseo_ajax_save_meta' );
	add_action( 'wp_ajax_madxseo_ajax_save_url', 'madxseo_ajax_save_url' );
	add_action( 'wp_ajax_madxseo_ajax_delete_url', 'madxseo_ajax_delete_url' );
	add_action( 'wp_ajax_madxseo_ajax_scan_header', 'madxseo_ajax_scan_header' );
	if ( madxseoPRO ) {
		add_action( 'wp_ajax_madxseo_ajax_facebook_debug', 'madxseo_ajax_facebook_debug' );
	}
	add_action( 'wp_ajax_madxseo_ajax_save_settings', 'madxseo_ajax_save_settings' );
	add_action( 'wp_ajax_madxseo_ajax_get_menu_links', 'madxseo_ajax_get_menu_links' );
	add_action( 'wp_ajax_aioseo_dismiss_yst_notice', 'madxseo_update_yst_detected_notice' );
	add_action( 'wp_ajax_aioseo_dismiss_visibility_notice', 'madxseo_update_user_visibilitynotice' );
	add_action( 'wp_ajax_aioseo_dismiss_woo_upgrade_notice', 'madxseo_woo_upgrade_notice_dismissed' );
	add_action( 'wp_ajax_aioseo_dismiss_sitemap_max_url_notice', 'madxseo_sitemap_max_url_notice_dismissed' );
}

if ( ! function_exists( 'madxseo_scan_post_header' ) ) {
	function madxseo_scan_post_header() {
		require_once( ABSPATH . WPINC . '/default-filters.php' );
		global $wp_query;
		$wp_query->query_vars['paged'] = 0;
		query_posts( 'post_type=post&posts_per_page=1' );
		if ( have_posts() ) {
			the_post();
		}
	}
}

require_once( madxseo_PLUGIN_DIR . 'madxseo-init.php' );

if ( ! function_exists( 'madxseo_install' ) ) {
	register_activation_hook( __FILE__, 'madxseo_install' );

	function madxseo_install() {
		madxseo_activate();
	}
}

if ( ! function_exists( 'disable_all_in_one_free' ) ) {
	function disable_all_in_one_free() {
		if ( madxseoPRO && is_plugin_active( 'madxartwork-seo-pack/all_in_one_seo_pack.php' ) ) {
			deactivate_plugins( 'madxartwork-seo-pack/all_in_one_seo_pack.php' );
		}
	}
}
