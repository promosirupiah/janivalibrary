<?php
/**
 * Class AIOSP_Common_Strings
 *
 * This is just for Pro strings to be translated.
 *
 * @package madxartwork-seo-Pack
 */

class AIOSP_Common_Strings {

	/**
	 * AIOSP_Common_Strings constructor.
	 *
	 * We'll just put all the strings in the contruct for lack of a better.
	 */

	private function __construct() {

		// Video sitemap strings.
		__( 'Video Sitemap', 'madxartwork-seo-pack' );
		__( 'Show Only Posts With Videos', 'madxartwork-seo-pack' );
		__( 'Restrict Access to Video Sitemap', 'madxartwork-seo-pack' );
		__( 'If checked, only posts that have videos in them will be displayed on the sitemap.', 'madxartwork-seo-pack' );
		__( 'Enable this option to only allow access to your sitemap by site administrators and major search engines.', 'madxartwork-seo-pack' );
		__( 'You do not have access to this page; try logging in as an administrator.', 'madxartwork-seo-pack' );

		// Update checker strings (incomplete... need to separate out html).
		__( 'Purchase one now', 'madxartwork-seo-pack' );
		__( 'License Key is not set yet or invalid. ', 'madxartwork-seo-pack' );
		/* translators: Please mind the space at the beginning of the string. */
		__( ' Need a license key?', 'madxartwork-seo-pack' );
		__( 'Notice: ', 'madxartwork-seo-pack' );
		__( 'Manage Licenses', 'madxartwork-seo-pack' );

		// These are Pro option strings.
		__( 'Show SEO News', 'madxartwork-seo-pack' );
		__( 'Display Menu In Admin Bar:', 'madxartwork-seo-pack' );
		__( 'Display Menu At The Top:', 'madxartwork-seo-pack' );
		__( 'This displays an SEO News widget on the dashboard.', 'madxartwork-seo-pack' );
		__( 'Check this to add MadxArtwork SEO Pack to the Admin Bar for easy access to your SEO settings.', 'madxartwork-seo-pack' );
		__( 'Check this to move the MadxArtwork SEO Pack menu item to the top of your WordPress Dashboard menu.', 'madxartwork-seo-pack' );
		__( '%s is almost ready.', 'madxartwork-seo-pack' );
		__( 'You must <a href="%s">enter a valid License Key</a> for it to work.', 'madxartwork-seo-pack' );
		__( "There is a new version of %1\$s available. Go to <a href='%2\$s'>the plugins page</a> for details.", 'madxartwork-seo-pack' );
		sprintf( __( 'Your license has expired. Please %1$s click here %2$s to purchase a new one.', 'madxartwork-seo-pack' ), '<a href="https://semperplugins.com/madxartwork-seo-pack-pro-version/" target="_blank">', '</a>' );
		__( 'Track Outbound Forms:', 'madxartwork-seo-pack' );
		__( 'Track Events:', 'madxartwork-seo-pack' );
		__( 'Track URL Changes:', 'madxartwork-seo-pack' );
		__( 'Track Page Visibility:', 'madxartwork-seo-pack' );
		__( 'Track Media Query:', 'madxartwork-seo-pack' );
		__( 'Track Elements Visibility:', 'madxartwork-seo-pack' );
		__( 'Track Page Scrolling:', 'madxartwork-seo-pack' );
		__( 'Track Facebook and Twitter:', 'madxartwork-seo-pack' );
		__( 'Ensure URL Consistency:', 'madxartwork-seo-pack' );
		__( 'Check this if you want to track outbound forms with Google Analytics.', 'madxartwork-seo-pack' );
		__( 'Check this if you want to track events with Google Analytics.', 'madxartwork-seo-pack' );
		__( 'Check this if you want to track URL changes for single pages with Google Analytics.', 'madxartwork-seo-pack' );
		__( 'Check this if you want to track how long pages are in visible state with Google Analytics.', 'madxartwork-seo-pack' );

		/*
		 Translators: 'This option allows users to track media queries, allowing them to find out if users are viewing a responsive layout or not and which layout changes
		have been applied if the browser window has been resized by the user, see https://github.com/googleanalytics/autotrack/blob/master/docs/plugins/media-query-tracker.md.
		*/
		__( 'Check this if you want to track media query matching and queries with Google Analytics.', 'madxartwork-seo-pack' );

		/*
		 Translators: The term 'viewport' refers to the area of the page that is visible to the user, see https://www.w3schools.com/css/css_rwd_viewport.asp.
		 */
		__( 'Check this if you want to track when elements are visible within the viewport with Google Analytics.', 'madxartwork-seo-pack' );
		__( 'Check this if you want to ensure consistency in URL paths reported to Google Analytics.', 'madxartwork-seo-pack' );
		__( 'Check this if you want to track how far down a user scrolls a page with Google Analytics.', 'madxartwork-seo-pack' );
		__( 'Check this if you want to track interactions with the official Facebook and Twitter widgets with Google Analytics.', 'madxartwork-seo-pack' );
	}
}
