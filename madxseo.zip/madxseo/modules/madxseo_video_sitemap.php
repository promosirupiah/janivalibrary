<?php
/**
 * Loads video sitemap class.
 *
 * @package madxartwork-seo-Pack
 *
 */

if ( madxseoPRO ) {
	require_once( madxseo_PLUGIN_DIR . 'pro/video_sitemap.php' );
}
