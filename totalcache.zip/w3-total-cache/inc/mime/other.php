<?php
/**
 * Other mime types.
 *
 * @package W3TC
 */

defined( 'ABSPATH' ) || exit;
if ( ! defined( 'W3TC' ) ) {
	die;
}

return array(
	'asf|asx|wax|wmv|wmx'  => 'video/asf',
	'avi'                  => 'video/avi',
	'avif'                 => 'image/avif',
	'avifs'                => 'image/avif-sequence',
	'bmp'                  => 'image/bmp',
	'class'                => 'application/java',
	'divx'                 => 'video/divx',
	'doc|docx'             => 'application/msword',
	'eot'                  => 'application/vnd.ms-fontobject',
	'exe'                  => 'application/x-msdownload',
	'gif'                  => 'image/gif',
	'gz|gzip'              => 'application/x-gzip',
	'ico'                  => 'image/x-icon',
	'jpg|jpeg|jpe'         => 'image/jpeg',
	'webp'                 => 'image/webp',
	'json'                 => 'application/json',
	'mdb'                  => 'application/vnd.ms-access',
	'mid|midi'             => 'audio/midi',
	'mov|qt'               => 'video/quicktime',
	'mp3|m4a'              => 'audio/mpeg',
	'mp4|m4v'              => 'video/mp4',
	'mpeg|mpg|mpe'         => 'video/mpeg',
	'webm'                 => 'video/webm',
	'mpp'                  => 'application/vnd.ms-project',
	'otf'                  => 'application/x-font-otf',
	'_otf'                 => 'application/vnd.ms-opentype',
	'odb'                  => 'application/vnd.oasis.opendocument.database',
	'odc'                  => 'application/vnd.oasis.opendocument.chart',
	'odf'                  => 'application/vnd.oasis.opendocument.formula',
	'odg'                  => 'application/vnd.oasis.opendocument.graphics',
	'odp'                  => 'application/vnd.oasis.opendocument.presentation',
	'ods'                  => 'application/vnd.oasis.opendocument.spreadsheet',
	'odt'                  => 'application/vnd.oasis.opendocument.text',
	'ogg'                  => 'audio/ogg',
	'ogv'                  => 'video/ogg',
	'pdf'                  => 'application/pdf',
	'png'                  => 'image/png',
	'pot|pps|ppt|pptx'     => 'application/vnd.ms-powerpoint',
	'ra|ram'               => 'audio/x-realaudio',
	'svg|svgz'             => 'image/svg+xml',
	'swf'                  => 'application/x-shockwave-flash',
	'tar'                  => 'application/x-tar',
	'tif|tiff'             => 'image/tiff',
	'ttf|ttc'              => 'application/x-font-ttf',
	'_ttf'                 => 'application/vnd.ms-opentype',
	'wav'                  => 'audio/wav',
	'wma'                  => 'audio/wma',
	'wri'                  => 'application/vnd.ms-write',
	'woff'                 => 'application/font-woff',
	'woff2'                => 'application/font-woff2',
	'xla|xls|xlsx|xlt|xlw' => 'application/vnd.ms-excel',
	'zip'                  => 'application/zip',
);
