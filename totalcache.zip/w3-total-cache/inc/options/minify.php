<?php
/**
 * File: minify.php
 *
 * @package W3TC
 */

namespace W3TC;

defined( 'ABSPATH' ) || exit;
if ( ! defined( 'W3TC' ) ) {
	die();
}
?>
<?php require W3TC_INC_DIR . '/options/common/header.php'; ?>

<?php
$w3tc_minify_doc_url             = 'https://www.boldgrid.com/support/w3-total-cache/minify-cache/';
$w3tc_minify_learn_more_link     = static function ( $anchor, $setting_label ) use ( $w3tc_minify_doc_url ) {
	if ( empty( $anchor ) || empty( $setting_label ) ) {
		return '';
	}

	$title = sprintf(
		/* translators: %s: Minify setting name. */
		__( 'Learn more about %s', 'w3-total-cache' ),
		$setting_label
	);

	return ' <a target="_blank" href="' . esc_url( $w3tc_minify_doc_url . '#' . $anchor ) . '" title="' . esc_attr( $title ) . '">' . esc_html__( 'Learn more', 'w3-total-cache' ) . '<span class="dashicons dashicons-external"></span></a>';
};
$w3tc_minify_config_label_text   = static function ( $config_key ) {
	$w3tc_label = Util_Ui::config_label( $config_key );

	return $w3tc_label ? wp_strip_all_tags( $w3tc_label ) : '';
};
$w3tc_minify_anchor_allowed_tags = array(
	'a'    => array(
		'class'  => array(),
		'href'   => array(),
		'title'  => array(),
		'target' => array(),
	),
	'span' => array(
		'class' => array(),
	),
);
$w3tc_minify_learn_more_output   = static function ( $anchor, $config_key = '', $custom_label = '' ) use ( $w3tc_minify_learn_more_link, $w3tc_minify_config_label_text, $w3tc_minify_anchor_allowed_tags ) {
	$w3tc_label = $custom_label;

	if ( ! $w3tc_label && $config_key ) {
		$w3tc_label = $w3tc_minify_config_label_text( $config_key );
	}

	if ( empty( $w3tc_label ) ) {
		return '';
	}

	return $w3tc_minify_learn_more_link( $anchor, $w3tc_label );
};
?>

<script type="text/javascript">/*<![CDATA[*/
	var minify_templates = {};
	<?php foreach ( $w3tc_templates as $w3tc_theme_key => $w3tc_theme_templates ) : ?>
		minify_templates['<?php echo esc_html( addslashes( $w3tc_theme_key ) ); ?>'] = {};
		<?php foreach ( $w3tc_theme_templates as $w3tc_theme_template_key => $w3tc_theme_template_name ) : ?>
			minify_templates['<?php echo esc_html( addslashes( $w3tc_theme_key ) ); ?>']['<?php echo esc_html( addslashes( $w3tc_theme_template_key ) ); ?>'] = '<?php echo esc_html( addslashes( $w3tc_theme_template_name ) ); ?>';
		<?php endforeach; ?>
	<?php endforeach; ?>
/*]]>*/</script>

<form action="admin.php?page=<?php echo esc_attr( $this->_page ); ?>" method="post">
	<p>
		<?php
		echo wp_kses(
			sprintf(
				// translators: 1 minify engine name, HTML span tag indicating engine enabled/disabled.
				__(
					'Minify via %1$s is currently %2$s.',
					'w3-total-cache'
				),
				Cache::engine_name( $this->_config->get_string( 'minify.engine' ) ),
				'<span class="w3tc-' . ( $minify_enabled ? 'enabled">' . esc_html__( 'enabled', 'w3-total-cache' ) : 'disabled">' . esc_html__( 'disabled', 'w3-total-cache' ) ) . '</span>'
			),
			array(
				'span' => array(
					'class' => array(),
				),
			)
		);
		?>
	</p>
	<p>
		<?php if ( ! $auto ) : ?>
			<?php esc_html_e( 'Get minify hints using the', 'w3-total-cache' ); ?>
			<input type="button" class="button button-minify-recommendations {nonce: '<?php echo esc_attr( Util_Nonce::create_admin( 'w3tc_test_minify_recommendations' ) ); ?>'}" value="<?php esc_attr_e( 'help', 'w3-total-cache' ); ?>" />
			<?php esc_html_e( 'wizard.', 'w3-total-cache' ); ?>
		<?php endif; ?>
		<?php
		echo wp_kses(
			sprintf(
				// translators: %1 HTML input submit.
				__(
					'%1$s to make existing file modifications visible to visitors with a primed cache.',
					'w3-total-cache'
				),
				'<input type="submit" name="w3tc_flush_browser_cache" value="' . esc_attr__( 'Update media query string', 'w3-total-cache' ) . '"' . disabled( ! ( $browsercache_enabled && $browsercache_update_media_qs ), true, false ) . ' class="button" />'
			),
			array(
				'input' => array(
					'type'     => array(),
					'name'     => array(),
					'value'    => array(),
					'disabled' => array(),
					'class'    => array(),
				),
			)
		);
		?>
	</p>

<form id="minify_form" action="admin.php?page=<?php echo esc_attr( $this->_page ); ?>" method="post">
	<?php Util_UI::print_control_bar( 'minify_form_control' ); ?>
	<div class="metabox-holder">
		<?php Util_Ui::postbox_header( esc_html__( 'General', 'w3-total-cache' ), '', 'general' ); ?>
		<table class="form-table">
			<tr>
				<th colspan="2">
					<?php
					$this->checkbox(
						'minify.rewrite',
						$minify_rewrite_disabled,
						'',
						true,
						( ! Util_Rule::can_check_rules() ? false : null )
					);
					?>
					<?php Util_Ui::e_config_label( 'minify.rewrite' ); ?></label>
					<p class="description">
						<?php
						echo wp_kses(
							sprintf(
								// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag,
								// translators: 3 opening HTML acronym tag, 4 closing HTML acronym tag.
								__(
									'If disabled, %1$sCSS%2$s and %3$sJS%4$s embeddings will use GET variables instead of "fancy" links.',
									'w3-total-cache'
								),
								'<acronym title="' . esc_attr__( 'Cascading Style Sheet', 'w3-total-cache' ) . '">',
								'</acronym>',
								'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
								'</acronym>'
							),
							array(
								'acronym' => array(
									'title' => array(),
								),
							)
						);
						?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'rewrite-url-structure', 'minify.rewrite' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</th>
			</tr>
			<tr>
				<th colspan="2">
					<?php $this->checkbox( 'minify.reject.logged' ); ?> <?php Util_Ui::e_config_label( 'minify.reject.logged' ); ?></label>
					<p class="description">
						<?php esc_html_e( 'Authenticated users will not receive minified pages if this option is enabled.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'disable-minify-for-logged-in-users', 'minify.reject.logged' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</th>
			</tr>
			<?php
			Util_Ui::config_item(
				array(
					'key'              => 'minify.error.notification',
					'control'          => 'selectbox',
					'selectbox_values' => array(
						''            => esc_html__( 'Disabled', 'w3-total-cache' ),
						'admin'       => esc_html__( 'Admin Notification', 'w3-total-cache' ),
						'email'       => esc_html__( 'Email Notification', 'w3-total-cache' ),
						'admin,email' => esc_html__( 'Both Admin &amp; Email Notification', 'w3-total-cache' ),
					),
					'description'      => esc_html__( 'Notify when minify cache creation errors occur.', 'w3-total-cache' ) . $w3tc_minify_learn_more_output( 'minify-error-notification', 'minify.error.notification' ),
				)
			);
			?>
		</table>

		<?php Util_Ui::postbox_footer(); ?>

		<?php
		Util_Ui::postbox_header(
			wp_kses(
				sprintf(
					// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag,
					// translators: 3 opening HTML acronym tag, 4 closing HTML acronym tag.
					__(
						'%1$sHTML%2$s &amp; %3$sXML%4$s',
						'w3-total-cache'
					),
					'<acronym title="' . esc_attr__( 'Hypertext Markup Language', 'w3-total-cache' ) . '">',
					'</acronym>',
					'<acronym title="' . esc_attr__( 'eXtensible Markup Language', 'w3-total-cache' ) . '">',
					'</acronym>'
				),
				array(
					'acronym' => array(
						'title' => array(),
					),
				)
			),
			'',
			'html_xml'
		);
		?>
		<table class="form-table">
			<tr>
				<th>
					<?php
					echo wp_kses(
						sprintf(
							// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
							__(
								'%1$sHTML%2$s minify settings:',
								'w3-total-cache'
							),
							'<acronym title="' . esc_attr__( 'Hypertext Markup Language', 'w3-total-cache' ) . '">',
							'</acronym>'
						),
						array(
							'acronym' => array(
								'title' => array(),
							),
						)
					);
					?>
				</th>
				<td>
					<?php $this->checkbox( 'minify.html.enable' ); ?> <?php Util_Ui::e_config_label( 'minify.html.enable' ); ?></label><br />
					<?php $this->checkbox( 'minify.html.inline.css', false, 'html_' ); ?> <?php Util_Ui::e_config_label( 'minify.html.inline.css' ); ?></label><br />
					<?php $this->checkbox( 'minify.html.inline.js', false, 'html_' ); ?> <?php Util_Ui::e_config_label( 'minify.html.inline.js' ); ?></label><br />
					<?php $this->checkbox( 'minify.html.reject.feed', false, 'html_' ); ?> <?php Util_Ui::e_config_label( 'minify.html.reject.feed' ); ?></label><br />
					<?php
					$w3tc_html_engine_file = '';

					switch ( $html_engine ) {
						case 'html':
						case 'htmltidy':
							$w3tc_html_engine_file = W3TC_INC_DIR . '/options/minify/' . $html_engine . '.php';
							break;
					}

					if ( file_exists( $w3tc_html_engine_file ) ) {
						include $w3tc_html_engine_file;
					}
					?>
					<p class="description">
						<?php esc_html_e( 'Enable HTML minification and optionally remove whitespace from inline CSS, JS, and feeds.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'html-minify-settings', 'minify.html.enable' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_html_comments_ignore"><?php Util_Ui::e_config_label( 'minify.html.comments.ignore' ); ?></label></th>
				<td>
					<textarea id="minify_html_comments_ignore"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?>
						name="minify__html__comments__ignore" class="html_enabled" cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $this->_config->get_array( 'minify.html.comments.ignore' ) ) ); ?></textarea>
					<p class="description">
						<?php esc_html_e( 'Do not remove comments that contain these terms.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'ignored-comment-stems', 'minify.html.comments.ignore' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<?php
			$w3tc_html_engine_file2 = '';

			switch ( $w3tc_html_engine_file2 ) {
				case 'html':
				case 'htmltidy':
					$w3tc_html_engine_file = W3TC_INC_DIR . '/options/minify/' . $html_engine . '2.php';
					break;
			}

			if ( file_exists( $w3tc_html_engine_file2 ) ) {
				include $w3tc_html_engine_file2;
			}
			?>
		</table>

		<?php Util_Ui::postbox_footer(); ?>

		<?php
		Util_Ui::postbox_header(
			sprintf(
				// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
				__(
					'%1$sJS%2$s',
					'w3-total-cache'
				),
				'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
				'</acronym>'
			),
			'',
			'js'
		);
		?>
		<table class="form-table">
			<?php
			Util_Ui::config_item(
				array(
					'key'            => 'minify.js.enable',
					'label'          => sprintf(
						// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
						__(
							'%1$sJS%2$s minify settings:',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					'control'        => 'checkbox',
					'checkbox_label' => esc_html__( 'Enable', 'w3-total-cache' ),
					'description'    => esc_html__( 'Minify enqueued and inline JavaScript files according to the settings below.', 'w3-total-cache' ) . $w3tc_minify_learn_more_output( 'js-minify-settings', 'minify.js.enable' ),
				)
			);
			?>
			<?php
			if ( $auto ) :
				Util_Ui::config_item(
					array(
						'key'              => 'minify.js.method',
						'label'            => Util_Ui::config_label( 'minify.js.method' ),
						'control'          => 'selectbox',
						'selectbox_values' => array(
							'both'    => array(
								'label' => esc_html__( 'Combine & Minify', 'w3-total-cache' ),
							),
							'minify'  => array(
								'label' => esc_html__( 'Minify only', 'w3-total-cache' ),
							),
							'combine' => array(
								'label' => esc_html__( 'Combine only', 'w3-total-cache' ),
							),
						),
						'description'      => esc_html__( 'Choose how JavaScript files should be combined or minified when using automatic mode.', 'w3-total-cache' ) . $w3tc_minify_learn_more_output( 'minify-method', 'minify.js.method' ),
					)
				);
			endif;
			?>
			<tr>
				<th>
					<?php esc_html_e( 'Minify engine settings:', 'w3-total-cache' ); ?>
				</th>
				<td>
					<fieldset><legend><?php esc_html_e( 'Operations in areas:', 'w3-total-cache' ); ?></legend>
						<table id="minify_table">
							<tr>
								<td></td>
								<td></td>
								<td class="options"><?php Util_Ui::e_config_label( 'minify.js.header.embed_type' ); ?></td>
							</tr>
							<tr>
								<td class="placement">
									<?php
									echo wp_kses(
										sprintf(
											// translators: 1 opening HTML span tag, 2 closing HTML span tag.
											__(
												'Before %1$s&lt;/head&gt;%2$s',
												'w3-total-cache'
											),
											'<span class="html-tag">',
											'</span>'
										),
										array(
											'span' => array(
												'class' => array(),
											),
										)
									);
									?>
								</td>
								<td class="options">
									<?php if ( ! $auto ) : ?>
										<?php $this->radio( 'minify.js.combine.header', false, false, 'js_' ); ?> <?php esc_html_e( 'Minify', 'w3-total-cache' ); ?> </label> <?php $this->radio( 'minify.js.combine.header', true, false, 'js_' ); ?> <?php Util_Ui::e_config_label( 'minify.js.combine.header' ); ?></label>
									<?php endif; ?>
								</td>
								<td class="options">
									<select id="js_use_type_header" name="minify__js__header__embed_type" class="js_enabled">
										<option value="blocking" <?php selected( 'blocking', $this->_config->get_string( 'minify.js.header.embed_type' ) ); ?>><?php esc_html_e( 'Default (blocking)', 'w3-total-cache' ); ?></option>
										<option value="nb-js" <?php selected( 'nb-js', $this->_config->get_string( 'minify.js.header.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using JS', 'w3-total-cache' ); ?></option>
										<option value="nb-async" <?php selected( 'nb-async', $this->_config->get_string( 'minify.js.header.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "async"', 'w3-total-cache' ); ?></option>
										<option value="nb-defer" <?php selected( 'nb-defer', $this->_config->get_string( 'minify.js.header.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "defer"', 'w3-total-cache' ); ?></option>
										<?php if ( ! $auto ) : ?>
											<option value="extsrc" <?php selected( 'extsrc', $this->_config->get_string( 'minify.js.header.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "extsrc"', 'w3-total-cache' ); ?></option>
											<option value="asyncsrc" <?php selected( 'asyncsrc', $this->_config->get_string( 'minify.js.header.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "asyncsrc"', 'w3-total-cache' ); ?></option>
										<?php endif; ?>
									</select>
								</td>
							<tr>
								<td class="placement"><?php Util_Ui::e_config_label( 'minify.js.body.embed_type' ); ?></td>
								<td class="options">
									<?php if ( ! $auto ) : ?>
										<?php $this->radio( 'minify.js.combine.body', false, $auto, 'js_' ); ?> <?php esc_html_e( 'Minify', 'w3-total-cache' ); ?> </label> <?php $this->radio( 'minify.js.combine.body', true ); ?> <?php Util_Ui::e_config_label( 'minify.js.combine.body' ); ?></label>
									<?php endif; ?>
								</td>
								<td class="options">
									<select id="js_use_type_body" name="minify__js__body__embed_type" class="js_enabled">
										<option value="blocking" <?php selected( 'blocking', $this->_config->get_string( 'minify.js.body.embed_type' ) ); ?>><?php esc_html_e( 'Default (blocking)', 'w3-total-cache' ); ?></option>
										<option value="nb-js" <?php selected( 'nb-js', $this->_config->get_string( 'minify.js.body.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using JS', 'w3-total-cache' ); ?></option>
										<option value="nb-async" <?php selected( 'nb-async', $this->_config->get_string( 'minify.js.body.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "async"', 'w3-total-cache' ); ?></option>
										<option value="nb-defer" <?php selected( 'nb-defer', $this->_config->get_string( 'minify.js.body.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "defer"', 'w3-total-cache' ); ?></option>
										<?php if ( ! $auto ) : ?>
											<option value="extsrc" <?php selected( 'extsrc', $this->_config->get_string( 'minify.js.body.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "extsrc"', 'w3-total-cache' ); ?></option>
											<option value="asyncsrc" <?php selected( 'asyncsrc', $this->_config->get_string( 'minify.js.body.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "asyncsrc"', 'w3-total-cache' ); ?></option>
										<?php endif; ?>
									</select>
								</td>
							</tr>
							<?php if ( ! $auto ) : ?>
								<tr>
									<td class="placement"><?php Util_Ui::e_config_label( 'minify.js.footer.embed_type' ); ?></td>
									<td class="options">
										<?php $this->radio( 'minify.js.combine.footer', false, $auto, 'js_' ); ?> <?php esc_html_e( 'Minify', 'w3-total-cache' ); ?> </label> <?php $this->radio( 'minify.js.combine.footer', true ); ?> <?php Util_Ui::e_config_label( 'minify.js.combine.footer' ); ?></label>
									</td>
									<td class="options">
										<select id="js_use_type_footer" name="minify__js__footer__embed_type" class="js_enabled">
											<option value="blocking" <?php selected( 'blocking', $this->_config->get_string( 'minify.js.footer.embed_type' ) ); ?>><?php esc_html_e( 'Default (blocking)', 'w3-total-cache' ); ?></option>
											<option value="nb-js" <?php selected( 'nb-js', $this->_config->get_string( 'minify.js.footer.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using JS', 'w3-total-cache' ); ?></option>
											<option value="nb-async" <?php selected( 'nb-async', $this->_config->get_string( 'minify.js.footer.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "async"', 'w3-total-cache' ); ?></option>
											<option value="nb-defer" <?php selected( 'nb-defer', $this->_config->get_string( 'minify.js.footer.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "defer"', 'w3-total-cache' ); ?></option>
											<option value="extsrc" <?php selected( 'extsrc', $this->_config->get_string( 'minify.js.footer.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "extsrc"', 'w3-total-cache' ); ?></option>
											<option value="asyncsrc" <?php selected( 'asyncsrc', $this->_config->get_string( 'minify.js.footer.embed_type' ) ); ?>><?php esc_html_e( 'Non-blocking using "asyncsrc"', 'w3-total-cache' ); ?></option>
										</select>
									</td>
								</tr>
							<?php endif; ?>
						</table>
					</fieldset>

					<?php
					$w3tc_js_engine_file = '';

					switch ( $js_engine ) {
						case 'js':
						case 'yuijs':
						case 'ccjs':
							$w3tc_js_engine_file = W3TC_INC_DIR . '/options/minify/' . $js_engine . '.php';
							break;
					}

					if ( file_exists( $w3tc_js_engine_file ) ) {
						include $w3tc_js_engine_file;
					}
					?>

					<p class="description">
						<?php esc_html_e( 'Control where scripts are placed and whether they stay blocking or load asynchronously for each template area.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'minify-engine-settings', 'minify.js.header.embed_type' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<?php
			$w3tc_js_engine_file2 = '';

			switch ( $js_engine ) {
				case 'js':
				case 'yuijs':
				case 'ccjs':
				case 'googleccjs':
					$w3tc_js_engine_file2 = W3TC_INC_DIR . '/options/minify/' . $js_engine . '2.php';
					break;
			}

			if ( file_exists( $w3tc_js_engine_file2 ) ) {
				include $w3tc_js_engine_file2;
			}
			?>
			<?php if ( ! $auto ) : ?>
				<tr>
					<th>
						<?php
						echo wp_kses(
							sprintf(
								// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
								__(
									'%1$sJS%2$s file management:',
									'w3-total-cache'
								),
								'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
								'</acronym>'
							),
							array(
								'acronym' => array(
									'title' => array(),
								),
							)
						);
						?>
					</th>
					<td>
						<p>
							<label>
								<?php esc_html_e( 'Theme:', 'w3-total-cache' ); ?>
								<select id="js_themes" class="js_enabled" name="js_theme"
									<?php Util_Ui::sealing_disabled( 'minify.' ); ?>>
									<?php foreach ( $themes as $w3tc_theme_key => $w3tc_theme_name ) : ?>
										<option value="<?php echo esc_attr( $w3tc_theme_key ); ?>"<?php selected( $w3tc_theme_key, $w3tc_js_theme ); ?>>
											<?php
											echo esc_html( $w3tc_theme_name );
											if ( $w3tc_theme_key === $w3tc_js_theme ) {
												echo ' (active)';
											}
											?>
										</option>
									<?php endforeach; ?>
								</select>
							</label>
							<p class="description"><?php esc_html_e( 'Files are minified by template. First select the theme to manage, then add scripts used in all templates to the "All Templates" group. Use the menu above to manage scripts unique to a specific template. If necessary drag &amp; drop to resolve dependency issues (due to incorrect order).', 'w3-total-cache' ); ?></p>
						</p>
						<ul id="js_files" class="minify-files">
						<?php
						foreach ( $js_groups as $w3tc_js_theme => $w3tc_js_templates ) :
							if ( isset( $w3tc_templates[ $w3tc_js_theme ] ) ) :
								$w3tc_index = 0;
								foreach ( $w3tc_js_templates as $w3tc_js_template => $w3tc_js_locations ) :
									foreach ( (array) $w3tc_js_locations as $w3tc_js_location => $w3tc_js_config ) :
										if ( ! empty( $w3tc_js_config['files'] ) ) :
											foreach ( (array) $w3tc_js_config['files'] as $w3tc_js_file ) :
												++$w3tc_index;
												?>
												<li>
													<table>
														<tr>
															<th>&nbsp;</th>
															<th><?php esc_html_e( 'File URI:', 'w3-total-cache' ); ?></th>
															<th><?php esc_html_e( 'Template:', 'w3-total-cache' ); ?></th>
															<th colspan="3"><?php esc_html_e( 'Embed Location:', 'w3-total-cache' ); ?></th>
														</tr>
														<tr>
															<td><?php echo esc_html( $w3tc_index ); ?>.</td>
															<td>
																<input class="js_enabled" type="text" <?php Util_Ui::sealing_disabled( 'minify.' ); ?>
																	name="js_files[<?php echo esc_attr( $w3tc_js_theme ); ?>][<?php echo esc_attr( $w3tc_js_template ); ?>][<?php echo esc_attr( $w3tc_js_location ); ?>][]"
																	value="<?php echo esc_attr( $w3tc_js_file );  /* search w3tc-url-escaping */ ?>"
																	size="70" />
															</td>
															<td>
																<select class="js_file_template js_enabled" <?php Util_Ui::sealing_disabled( 'minify.' ); ?>>
																	<?php foreach ( $w3tc_templates[ $w3tc_js_theme ] as $w3tc_theme_template_key => $w3tc_theme_template_name ) : ?>
																		<option value="<?php echo esc_attr( $w3tc_theme_template_key ); ?>"<?php selected( $w3tc_theme_template_key, $w3tc_js_template ); ?>>
																			<?php echo esc_attr( $w3tc_theme_template_name ); ?>
																		</option>
																	<?php endforeach; ?>
																</select>
															</td>
															<td>
																<select class="js_file_location js_enabled" <?php Util_Ui::sealing_disabled( 'minify.' ); ?>>
																	<option value="include" <?php selected( $w3tc_js_location, 'include' ); ?>><?php esc_html_e( 'Embed in &lt;head&gt;', 'w3-total-cache' ); ?></option>
																	<option value="include-body" <?php selected( $w3tc_js_location, 'include-body' ); ?>><?php esc_html_e( 'Embed after &lt;body&gt;', 'w3-total-cache' ); ?></option>
																	<option value="include-footer" <?php selected( $w3tc_js_location, 'include-footer' ); ?>><?php esc_html_e( 'Embed before &lt;/body&gt;', 'w3-total-cache' ); ?></option>
																</select>
															</td>
															<td>
																<input class="js_file_delete js_enabled button" type="button" value="<?php esc_html_e( 'Delete', 'w3-total-cache' ); ?>" />
																<input class="js_file_verify js_enabled button" type="button" value="<?php esc_html_e( 'Verify URI', 'w3-total-cache' ); ?>" />
															</td>
														</tr>
													</table>
												</li>
												<?php
											endforeach;
										endif;
									endforeach;
								endforeach;
							endif;
						endforeach;
						?>
						</ul>
						<div id="js_files_empty" class="w3tc-empty" style="display: none;">
							<?php
							echo wp_kses(
								sprintf(
									// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
									__(
										'No %1$sJS%2$s files added',
										'w3-total-cache'
									),
									'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
									'</acronym>'
								),
								array(
									'acronym' => array(
										'title' => array(),
									),
								)
							);
							?>
						</div>
						<input id="js_file_add" class="js_enabled button" type="button" value="<?php esc_html_e( 'Add a script', 'w3-total-cache' ); ?>" />
					</td>
				</tr>
			<?php endif; ?>
			<?php
			Util_Ui::config_item(
				array(
					'key'            => 'minify.js.http2push',
					'label'          => Util_Ui::config_label( 'minify.js.http2push' ),
					'control'        => 'checkbox',
					'checkbox_label' => esc_html__( 'Enable', 'w3-total-cache' ),
					'description'    => wp_kses(
						sprintf(
							// translators: 1 opening HTML acronym tag for HTTP (Hypertext Transfer Protocol), 2 closing HTML acronym tag.
							__(
								'For better performance, send files to browser before they are requested when using the %1$sHTTP%2$s/2 protocol.',
								'w3-total-cache'
							),
							'<acronym title="' . esc_attr__( 'Hypertext Transfer Protocol', 'w3-total-cache' ) . '">',
							'</acronym>'
						),
						array(
							'acronym' => array(
								'title' => array(),
							),
						)
					) . (
						'file_generic' !== $this->_config->get_string( 'pgcache.engine' ) ?
						'' :
						wp_kses(
							sprintf(
								// translators: 1 HTML line break tag followed by opening HTML b tag, 2 closing HTML b tag.
								__(
									' %1$sNot supported by "Disk: Enhanced" page cache method for Nginx%2$s',
									'w3-total-cache'
								),
								'<br /><b>',
								'</b>'
							),
							array(
								'br' => array(),
								'b'  => array(),
							)
						)
					) . $w3tc_minify_learn_more_output( 'http2-push', 'minify.js.http2push' ),
				)
			);
			?>
		</table>

		<?php Util_Ui::postbox_footer(); ?>

		<?php
		Util_Ui::postbox_header(
			sprintf(
				// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
				__(
					'%1$sCSS%2$s',
					'w3-total-cache'
				),
				'<acronym title="' . esc_attr__( 'Cascading Style Sheet', 'w3-total-cache' ) . '">',
				'</acronym>'
			),
			'',
			'css'
		);
		?>
		<table class="form-table">
			<?php
			Util_Ui::config_item(
				array(
					'key'            => 'minify.css.enable',
					'label'          => wp_kses(
						sprintf(
							// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
							__(
								'%1$sCSS%2$s minify settings:',
								'w3-total-cache'
							),
							'<acronym title="' . esc_attr__( 'Cascading Style Sheet', 'w3-total-cache' ) . '">',
							'</acronym>'
						),
						array(
							'acronym' => array(
								'title' => array(),
							),
						)
					),
					'control'        => 'checkbox',
					'checkbox_label' => esc_html__( 'Enable', 'w3-total-cache' ),
					'description'    => esc_html__( 'Minify stylesheets and inline CSS snippets declared in the queues below.', 'w3-total-cache' ) . $w3tc_minify_learn_more_output( 'css-minify-settings', 'minify.css.enable' ),
				)
			);
			?>
			<?php
			Util_Ui::config_item(
				array(
					'key'              => 'minify.css.method',
					'label'            => Util_Ui::config_label( 'minify.css.method' ),
					'control'          => 'selectbox',
					'selectbox_values' => array(
						'both'    => array(
							'label' => esc_html__( 'Combine & Minify', 'w3-total-cache' ),
						),
						'minify'  => array(
							'label' => esc_html__( 'Minify only', 'w3-total-cache' ),
						),
						'combine' => array(
							'label' => esc_html__( 'Combine only', 'w3-total-cache' ),
						),
					),
					'description'      => esc_html__( 'Choose how stylesheets should be combined or minified when using automatic mode.', 'w3-total-cache' ) . $w3tc_minify_learn_more_output( 'minify-method', 'minify.css.method' ),
				)
			);
			?>
			<tr>
				<th>
					<?php esc_html_e( 'Minify engine settings:', 'w3-total-cache' ); ?>
				</th>
				<td>
					<?php
					$w3tc_css_engine_file = '';

					switch ( $css_engine ) {
						case 'css':
						case 'yuicss':
						case 'csstidy':
							$w3tc_css_engine_file = W3TC_INC_DIR . '/options/minify/' . $css_engine . '.php';
							break;
					}

					if ( file_exists( $w3tc_css_engine_file ) ) {
						include $w3tc_css_engine_file;
					}
					?>
					<p class="description">
						<?php esc_html_e( 'Decide where CSS is placed and whether it should load synchronously or asynchronously for each template area.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'minify-engine-settings', 'minify.css.engine' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_css_import"><?php Util_Ui::e_config_label( 'minify.css.imports' ); ?></label></th>
				<td>
					<select id="minify_css_import" class="css_enabled" name="minify__css__imports"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?>>
						<?php foreach ( $css_imports_values as $w3tc_css_imports_key => $w3tc_css_imports_value ) : ?>
							<option value="<?php echo esc_attr( $w3tc_css_imports_key ); ?>"<?php selected( $css_imports, $w3tc_css_imports_key ); ?>>
								<?php echo esc_html( $w3tc_css_imports_value ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description">
						<?php esc_html_e( 'Control how @import rules are handled when combining and minifying stylesheets.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'import-handling', 'minify.css.imports' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<?php
			$w3tc_css_engine_file2 = '';

			switch ( $css_engine ) {
				case 'css':
				case 'yuicss':
				case 'csstidy':
					$w3tc_css_engine_file2 = W3TC_INC_DIR . '/options/minify/' . $css_engine . '2.php';
					break;
			}

			if ( file_exists( $w3tc_css_engine_file2 ) ) {
				include $w3tc_css_engine_file2;
			}
			?>
			<?php if ( ! $auto ) : ?>
				<tr>
					<th>
						<?php
						echo wp_kses(
							sprintf(
								// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
								__(
									'%1$sCSS%2$s file management:',
									'w3-total-cache'
								),
								'<acronym title="' . esc_attr__( 'Cascading Style Sheet', 'w3-total-cache' ) . '">',
								'</acronym>'
							),
							array(
								'acronym' => array(
									'title' => array(),
								),
							)
						);
						?>
					</th>
					<td>
						<p>
							<label>
								<?php esc_html_e( 'Theme:', 'w3-total-cache' ); ?>
								<select id="css_themes" class="css_enabled" name="css_theme"
									<?php Util_Ui::sealing_disabled( 'minify.' ); ?>>
									<?php foreach ( $themes as $w3tc_theme_key => $w3tc_theme_name ) : ?>
										<option value="<?php echo esc_attr( $w3tc_theme_key ); ?>"<?php selected( $w3tc_theme_key, $w3tc_css_theme ); ?>>
											<?php
											echo esc_html( $w3tc_theme_name );
											if ( $w3tc_theme_key === $w3tc_css_theme ) {
												echo ' (active)';
											}
											?>
										</option>
									<?php endforeach; ?>
								</select>
							</label>
							<p class="description"><?php esc_html_e( 'Files are minified by template. First select the theme to manage, then add style sheets used in all templates to the "All Templates" group. Use the menu above to manage style sheets unique to a specific template. If necessary drag &amp; drop to resolve dependency issues (due to incorrect order).', 'w3-total-cache' ); ?></p>
						</p>
						<ul id="css_files" class="minify-files">
							<?php
							foreach ( $css_groups as $w3tc_css_theme => $w3tc_css_templates ) :
								if ( isset( $w3tc_templates[ $w3tc_css_theme ] ) ) :
									$w3tc_index = 0;
									foreach ( $w3tc_css_templates as $w3tc_css_template => $w3tc_css_locations ) :
										foreach ( (array) $w3tc_css_locations as $w3tc_css_location => $w3tc_css_config ) :
											if ( ! empty( $w3tc_css_config['files'] ) ) :
												foreach ( (array) $w3tc_css_config['files'] as $w3tc_css_file ) :
													++$w3tc_index;
													?>
													<li>
														<table>
															<tr>
																<th>&nbsp;</th>
																<th><?php esc_html_e( 'File URI:', 'w3-total-cache' ); ?></th>
																<th colspan="2"><?php esc_html_e( 'Template:', 'w3-total-cache' ); ?></th>
															</tr>
															<tr>
																<td><?php echo esc_html( $w3tc_index ); ?>.</td>
																<td>
																	<input class="css_enabled" type="text" <?php Util_Ui::sealing_disabled( 'minify.' ); ?>
																		name="css_files[<?php echo esc_attr( $w3tc_css_theme ); ?>][<?php echo esc_attr( $w3tc_css_template ); ?>][<?php echo esc_attr( $w3tc_css_location ); ?>][]"
																		value="<?php echo esc_html( $w3tc_css_file );  /* search w3tc-url-escaping */ ?>"
																		size="70" /><br />
																</td>
																<td>
																	<select class="css_file_template css_enabled" <?php Util_Ui::sealing_disabled( 'minify.' ); ?>>
																	<?php foreach ( $w3tc_templates[ $w3tc_css_theme ] as $w3tc_theme_template_key => $w3tc_theme_template_name ) : ?>
																		<option value="<?php echo esc_attr( $w3tc_theme_template_key ); ?>"<?php selected( $w3tc_theme_template_key, $w3tc_css_template ); ?>>
																			<?php echo esc_attr( $w3tc_theme_template_name ); ?>
																		</option>
																	<?php endforeach; ?>
																	</select>
																</td>
																<td>
																	<input class="css_file_delete css_enabled button" type="button" value="<?php esc_html_e( 'Delete', 'w3-total-cache' ); ?>" />
																	<input class="css_file_verify css_enabled button" type="button" value="<?php esc_html_e( 'Verify URI', 'w3-total-cache' ); ?>" />
																</td>
															</tr>
														</table>
													</li>
													<?php
												endforeach;
											endif;
										endforeach;
									endforeach;
								endif;
							endforeach;
							?>
						</ul>
						<div id="css_files_empty" class="w3tc-empty" style="display: none;">
							<?php
							echo wp_kses(
								sprintf(
									// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
									__(
										'No %1$sCSS%2$s files added',
										'w3-total-cache'
									),
									'<acronym title="' . esc_attr__( 'Cascading Style Sheet', 'w3-total-cache' ) . '">',
									'</acronym>'
								),
								array(
									'acronym' => array(
										'title' => array(),
									),
								)
							);
							?>
						</div>
						<input id="css_file_add" class="css_enabled button" type="button" value="<?php esc_html_e( 'Add a style sheet', 'w3-total-cache' ); ?>" />
					</td>
				</tr>
			<?php endif; ?>
			<?php
			Util_Ui::config_item(
				array(
					'key'            => 'minify.css.http2push',
					'label'          => Util_Ui::config_label( 'minify.css.http2push' ),
					'control'        => 'checkbox',
					'checkbox_label' => esc_html__( 'Enable', 'w3-total-cache' ),
					'description'    => wp_kses(
						sprintf(
							// translators: 1 opening HTML acronym tag for HTTP (Hypertext Transfer Protocol), 2 closing HTML acronym tag.
							__(
								'For better performance, send files to browser before they are requested when using the %1$sHTTP%2$s/2 protocol.',
								'w3-total-cache'
							),
							'<acronym title="' . esc_attr__( 'Hypertext Transfer Protocol', 'w3-total-cache' ) . '">',
							'</acronym>'
						),
						array(
							'acronym' => array(
								'title' => array(),
							),
						)
					) . (
						'file_generic' !== $this->_config->get_string( 'pgcache.engine' ) ?
						'' :
						wp_kses(
							sprintf(
								// translators: 1 HTML line break tag, 2 opening HTML b tag, 3 closing HTML b tag.
								__(
									' %1$s%2$sNot supported by "Disk: Enhanced" page cache method for Nginx%3$s',
									'w3-total-cache'
								),
								'<br />',
								'<b>',
								'</b>'
							),
							array(
								'br' => array(),
								'b'  => array(),
							)
						)
					) . $w3tc_minify_learn_more_output( 'http2-push', 'minify.css.http2push' ),
				)
			);
			?>
		</table>

		<?php Util_Ui::postbox_footer(); ?>

		<?php Util_Ui::postbox_header( esc_html__( 'Advanced', 'w3-total-cache' ), '', 'advanced' ); ?>
		<table class="form-table">
			<?php
			if ( 'memcached' === $this->_config->get_string( 'minify.engine' ) ) {
				$w3tc_module = 'minify';
				include W3TC_INC_DIR . '/options/parts/memcached.php';
			} elseif ( 'redis' === $this->_config->get_string( 'minify.engine' ) ) {
				$w3tc_module = 'minify';
				include W3TC_INC_DIR . '/options/parts/redis.php';
			}
			?>
			<tr>
				<th><label for="minify_lifetime"><?php Util_Ui::e_config_label( 'minify.lifetime' ); ?></label></th>
				<td>
					<input id="minify_lifetime" type="text" name="minify__lifetime"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?>
						value="<?php echo esc_attr( $this->_config->get_integer( 'minify.lifetime' ) ); ?>" size="8" /> <?php esc_html_e( 'seconds', 'w3-total-cache' ); ?>
					<p class="description">
						<?php esc_html_e( 'Specify the interval between download and update of external files in the minify cache. Hint: 6 hours is 21600 seconds. 12 hours is 43200 seconds. 24 hours is 86400 seconds.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'update-external-files-every', 'minify.lifetime' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_file_gc"><?php Util_Ui::e_config_label( 'minify.file.gc' ); ?></label></th>
				<td>
					<input id="minify_file_gc" type="text" name="minify__file__gc"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?>
						value="<?php echo esc_attr( $this->_config->get_integer( 'minify.file.gc' ) ); ?>" size="8"
						<?php
						if ( 'file' !== $this->_config->get_string( 'minify.engine' ) ) {
							echo ' disabled="disabled"';
						}
						?>
						/> <?php esc_html_e( 'seconds', 'w3-total-cache' ); ?>
					<p class="description">
						<?php esc_html_e( 'If caching to disk, specify how frequently expired cache data is removed. For busy sites, a lower value is best.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'garbage-collection-interval', 'minify.file.gc' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
					<p class="description">
						<?php
						echo esc_html(
							sprintf(
								// translators: 1 W3TC_CACHE_FILE_EXPIRE_MAX constant name, 2 W3TC_CACHE_FILE_EXPIRE_MAX value.
								__(
									'Max interval is limited by the %1$s constant (%2$s seconds) which can be overridden in wp-config.php.',
									'w3-total-cache'
								),
								'W3TC_CACHE_FILE_EXPIRE_MAX',
								W3TC_CACHE_FILE_EXPIRE_MAX
							)
						);
						?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_reject_uri"><?php Util_Ui::e_config_label( 'minify.reject.uri' ); ?></label></th>
				<td>
					<textarea id="minify_reject_uri" name="minify__reject__uri"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?> cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $this->_config->get_array( 'minify.reject.uri' ) ) ); ?></textarea>
					<p class="description">
						<?php esc_html_e( 'Always ignore the specified pages / directories. Use relative paths. Omit: protocol, hostname, leading forward slash and query strings.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'never-minify-the-following-files', 'minify.reject.uri' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_reject_files_js"><?php Util_Ui::e_config_label( 'minify.reject.files.js' ); ?></label></th>
				<td>
					<textarea id="minify_reject_files_js" name="minify__reject__files__js"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?> cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $this->_config->get_array( 'minify.reject.files.js' ) ) ); ?></textarea>
					<p class="description">
						<?php
						echo wp_kses(
							sprintf(
								// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
								__(
									'Always ignore the specified %1$sJS%2$s files. Use relative paths. Omit: protocol, hostname, leading forward slash and query strings.',
									'w3-total-cache'
								),
								'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
								'</acronym>'
							),
							array(
								'acronym' => array(
									'title' => array(),
								),
							)
						);
						?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'never-minify-the-following-files', 'minify.reject.files.js' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_reject_files_css"><?php Util_Ui::e_config_label( 'minify.reject.files.css' ); ?></label></th>
				<td>
					<textarea id="minify_reject_files_css" name="minify__reject__files__css"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?> cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $this->_config->get_array( 'minify.reject.files.css' ) ) ); ?></textarea>
					<p class="description">
						<?php
						echo wp_kses(
							sprintf(
								// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag.
								__(
									'Always ignore the specified %1$sCSS%2$s files. Use relative paths. Omit: protocol, hostname, leading forward slash and query strings.',
									'w3-total-cache'
								),
								'<acronym title="' . esc_attr__( 'Cascading Style Sheet', 'w3-total-cache' ) . '">',
								'</acronym>'
							),
							array(
								'acronym' => array(
									'title' => array(),
								),
							)
						);
						?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'never-minify-the-following-files', 'minify.reject.files.css' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th><label for="minify_reject_ua"><?php Util_Ui::e_config_label( 'minify.reject.ua' ); ?></label></th>
				<td>
					<textarea id="minify_reject_ua" name="minify__reject__ua"
						<?php Util_Ui::sealing_disabled( 'minify.' ); ?>
						cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $this->_config->get_array( 'minify.reject.ua' ) ) ); ?></textarea>
					<p class="description">
						<?php esc_html_e( 'Specify user agents that will never receive minified content.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'rejected-user-agents', 'minify.reject.ua' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<?php if ( $auto ) : ?>
			<tr>
				<th><label for="minify_cache_files"><?php Util_Ui::e_config_label( 'minify.cache.files' ); ?></label></th>
				<td>
					<textarea id="minify_cache_files" name="minify__cache__files"<?php Util_Ui::sealing_disabled( 'minify.' ); ?> cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $this->_config->get_array( 'minify.cache.files' ) ) ); ?></textarea>
					<p class="description">
						<?php esc_html_e( 'Specify external files/libraries that should be combined.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'include-external-fileslibraries', 'minify.cache.files' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th colspan="2">
					<?php $this->checkbox( 'minify.cache.files_regexp', false, '', true, null ); ?>
					<?php Util_Ui::e_config_label( 'minify.cache.files_regexp' ); ?></label>
					<p class="description">
						<?php esc_html_e( 'If external script file names vary, use regular expressions in the "Include external files/libraries" field to simplify matching.', 'w3-total-cache' ); ?>
						<?php echo wp_kses( $w3tc_minify_learn_more_output( 'use-regular-expressions-for-file-name-matching-if-file-names-vary', 'minify.cache.files_regexp' ), $w3tc_minify_anchor_allowed_tags ); ?>
					</p>
				</th>
			</tr>
			<?php endif; ?>
		</table>

		<?php Util_Ui::postbox_footer(); ?>

		<?php Util_Ui::postbox_header( esc_html__( 'Purge via WP Cron', 'w3-total-cache' ), '', 'minify_wp_cron' ); ?>
		<table class="form-table">
			<p>
				<?php
				esc_html_e(
					'Enabling this will schedule a WP-Cron event that will flush the Minify Cache. If you prefer to use a system cron job instead of WP-Cron, you can schedule the following command to run at your desired interval: "wp w3tc flush minify".',
					'w3-total-cache'
				);
				?>
				<a target="_blank" href="<?php echo esc_url( 'https://www.boldgrid.com/support/w3-total-cache/schedule-cache-purges/' ); ?>" title="<?php esc_attr_e( 'Scheduling Page Cache purges', 'w3-total-cache' ); ?>">
					<?php esc_html_e( 'Learn more', 'w3-total-cache' ); ?>
					<span class="dashicons dashicons-external"></span>
				</a>
			</p>
			<?php
			$w3tc_c           = Dispatcher::config();
			$w3tc_disabled    = ! $w3tc_c->get_boolean( 'minify.enabled' );
			$w3tc_wp_disabled = ! $w3tc_c->get_boolean( 'minify.wp_cron' );

			if ( $w3tc_disabled ) {
				echo wp_kses(
					sprintf(
						// Translators: 1 opening HTML div tag followed by opening HTML p tag, 2 opening HTML a tag,
						// Translators: 3 closing HTML a tag, 4 closing HTML p tag followed by closing HTML div tag.
						__( '%1$sMinify is disabled! Enable it %2$shere%3$s to enable this feature.%4$s', 'w3-total-cache' ),
						'<div class="notice notice-error inline"><p>',
						'<a href="' . esc_url( admin_url( 'admin.php?page=w3tc_general#minify' ) ) . '">',
						'</a>',
						'</p></div>'
					),
					array(
						'div' => array(
							'class' => array(),
						),
						'p'   => array(),
						'a'   => array(
							'href' => array(),
						),
					)
				);
			}

			Util_Ui::config_item(
				array(
					'key'            => 'minify.wp_cron',
					'label'          => Util_Ui::config_label( 'minify.wp_cron' ),
					'checkbox_label' => esc_html__( 'Enable', 'w3-total-cache' ),
					'control'        => 'checkbox',
					'disabled'       => $w3tc_disabled,
				)
			);

			$w3tc_time_options = array();
			for ( $w3tc_hour = 0; $w3tc_hour < 24; $w3tc_hour++ ) {
				foreach ( array( '00', '30' ) as $w3tc_minute ) {
					$w3tc_time_value                       = $w3tc_hour * 60 + intval( $w3tc_minute );
					$w3tc_scheduled_time                   = new \DateTime( "{$w3tc_hour}:{$w3tc_minute}", wp_timezone() );
					$w3tc_time_label                       = $w3tc_scheduled_time->format( 'g:i a' );
					$w3tc_time_options[ $w3tc_time_value ] = $w3tc_time_label;
				}
			}

			Util_Ui::config_item(
				array(
					'key'              => 'minify.wp_cron_time',
					'label'            => Util_Ui::config_label( 'minify.wp_cron_time' ),
					'control'          => 'selectbox',
					'selectbox_values' => $w3tc_time_options,
					'description'      => esc_html__( 'This setting controls the initial start time of the cron job. If the selected time has already passed, it will schedule the job for the following day at the selected time.', 'w3-total-cache' ),
					'disabled'         => $w3tc_disabled || $w3tc_wp_disabled,
				)
			);

			Util_Ui::config_item(
				array(
					'key'              => 'minify.wp_cron_interval',
					'label'            => Util_Ui::config_label( 'minify.wp_cron_interval' ),
					'control'          => 'selectbox',
					'selectbox_values' => array(
						'hourly'     => esc_html__( 'Hourly', 'w3-total-cache' ),
						'twicedaily' => esc_html__( 'Twice Daily', 'w3-total-cache' ),
						'daily'      => esc_html__( 'Daily', 'w3-total-cache' ),
						'weekly'     => esc_html__( 'Weekly', 'w3-total-cache' ),
					),
					'description'      => esc_html__( 'This setting controls the interval that the cron job should occur.', 'w3-total-cache' ),
					'disabled'         => $w3tc_disabled || $w3tc_wp_disabled,
				)
			);
			?>
		</table>
		<?php Util_Ui::postbox_footer(); ?>

		<?php Util_Ui::postbox_header( esc_html__( 'Note(s):', 'w3-total-cache' ), '', 'notes' ); ?>
		<table class="form-table">
			<tr>
				<th colspan="2">
					<ul>
						<li>
							<?php
							echo wp_kses(
								sprintf(
									// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag,
									// translators: 3 opening HTML a tag to W3TC Browsercache admin page, 4 closing HTML a tag.
									__(
										'Enable %1$sHTTP%2$s compression in the "Cascading Style Sheets &amp; JavaScript" section on %3$sBrowser Cache%4$s Settings tab.',
										'w3-total-cache'
									),
									'<acronym title="' . esc_attr__( 'Hypertext Transfer Protocol', 'w3-total-cache' ) . '">',
									'</acronym>',
									'<a href="' . esc_url( admin_url( 'admin.php?page=w3tc_browsercache' ) ) . '">',
									'</a>'
								),
								array(
									'acronym' => array(
										'title' => array(),
									),
									'a'       => array(
										'href' => array(),
									),
								)
							);
							?>
						</li>
						<li>
							<?php
							echo wp_kses(
								sprintf(
									// translators: 1 opening HTML acronym tag, 2 closing HTML acronym tag,
									// translators: 3 opening HTML a tag to W3TC Browsercache admin, 4 closing HTML a tag.
									__(
										'The %1$sTTL%2$s of page cache files is set via the "Expires header lifetime" field in the "Cascading Style Sheets &amp; JavaScript" section on %3$sBrowser Cache%4$s Settings tab.',
										'w3-total-cache'
									),
									'<acronym title="' . esc_attr__( 'Time to Live', 'w3-total-cache' ) . '">',
									'</acronym>',
									'<a href="' . esc_url( admin_url( 'admin.php?page=w3tc_browsercache' ) ) . '">',
									'</a>'
								),
								array(
									'acronym' => array(
										'title' => array(),
									),
									'a'       => array(
										'href' => array(),
									),
								)
							);
							?>
						</li>
					</ul>
				</th>
			</tr>
		</table>
		<?php Util_Ui::postbox_footer(); ?>
	</div>
</form>
