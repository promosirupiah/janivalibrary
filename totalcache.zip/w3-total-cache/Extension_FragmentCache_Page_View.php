<?php
/**
 * File: Extension_FragmentCache_Page_View.php
 *
 * @package W3TC
 */

namespace W3TC;

defined( 'ABSPATH' ) || exit;
if ( ! defined( 'W3TC' ) ) {
	die();
}

$w3tc_engine = $w3tc_config->get_string( array( 'fragmentcache', 'engine' ) );

?>
<p>
	<?php Util_Ui::pro_wrap_maybe_start2(); ?>

	<?php esc_html_e( 'Fragment caching', 'w3-total-cache' ); ?>
	<?php if ( ! empty( $w3tc_engine ) ) : ?>
		<?php esc_html_e( 'via', 'w3-total-cache' ); ?>
		<strong><?php echo esc_html( Cache::engine_name( $w3tc_engine ) ); ?></strong>
	<?php endif; ?>

	<?php esc_html_e( 'is currently', 'w3-total-cache' ); ?>
	<?php if ( $w3tc_config->is_extension_active_frontend( 'fragmentcache' ) ) : ?>
		<span class="w3tc-enabled"><?php esc_html_e( 'enabled', 'w3-total-cache' ); ?></span>.
	<?php else : ?>
		<span class="w3tc-disabled"><?php esc_html_e( 'disabled', 'w3-total-cache' ); ?></span>.
		<?php
		$w3tc_ext = Extensions_Util::get_extension( $w3tc_config, 'fragmentcache' );
		if ( ! empty( $w3tc_ext['requirements'] ) ) {
			echo ' (<p class="description">' . esc_html( $w3tc_ext['requirements'] ) . '</p>)';
		}
		?>
	<?php endif; ?>
	<?php
	if ( empty( $w3tc_engine ) ) {
		?>
		<p>
			<?php
			echo wp_kses(
				sprintf(
					// Translators: 1 opening HTML link to fragment cache block on general settings page, 2 closing HTML link.
					__(
						'To enable this feature please select an engine for Fragment Cache %1$shere%2$s.',
						'w3-total-cache'
					),
					'<a href="' . esc_url( Util_Ui::admin_url( 'admin.php?page=w3tc_general#fragmentcache' ) ) . '">',
					'</a>'
				),
				array(
					'a' => array(
						'href' => array(),
					),
				)
			);
			?>
		</p>
		<?php
	}
	Util_Ui::pro_wrap_maybe_end2( 'fragmentcache_header' );
	?>
</p>

<form action="admin.php?page=w3tc_fragmentcache" method="post">
	<?php Util_UI::print_control_bar( 'extension_fragmentcache_form_control' ); ?>
	<div class="metabox-holder">
		<?php Util_Ui::postbox_header( esc_html__( 'Overview', 'w3-total-cache' ), '', 'overview' ); ?>
		<table class="form-table">
		<tr>
			<th><?php esc_html_e( 'Registered fragment groups:', 'w3-total-cache' ); ?></th>
			<td>
				<?php if ( $registered_groups ) : ?>
					<ul>
						<?php
						foreach ( $registered_groups as $w3tc_group => $w3tc_descriptor ) :
							echo '<li>' . esc_html( $w3tc_group ) . ' (' . esc_html( $w3tc_descriptor['expiration'] ) . ' secs): ' . esc_html( implode( ',', $w3tc_descriptor['actions'] ) ) . '</li>';
						endforeach;
						?>
					</ul>
				<p class="description"><?php esc_html_e( 'The groups above will be flushed upon setting changes.', 'w3-total-cache' ); ?></p>
				<?php else : ?>
				<p class="description"><?php esc_html_e( 'No groups have been registered.', 'w3-total-cache' ); ?></p>
				<?php endif; ?>
			</td>
		</tr>
		</table>
		<?php Util_Ui::postbox_footer(); ?>

		<?php Util_Ui::postbox_header( esc_html__( 'Advanced', 'w3-total-cache' ), '', 'advanced' ); ?>
		<table class="form-table">
			<?php
			if ( 'memcached' === $w3tc_config->get_string( array( 'fragmentcache', 'engine' ) ) ) {
				$w3tc_module = 'fragmentcache';
				include W3TC_INC_DIR . '/options/parts/memcached_extension.php';
			} elseif ( 'redis' === $w3tc_config->get_string( array( 'fragmentcache', 'engine' ) ) ) {
				$w3tc_module = 'fragmentcache';
				include W3TC_INC_DIR . '/options/parts/redis_extension.php';
			}
			?>
			<tr>
				<th style="width: 250px;"><label for="fragmentcache_lifetime"><?php esc_html_e( 'Default lifetime of cached fragments:', 'w3-total-cache' ); ?></label></th>
				<td>
					<input id="fragmentcache_lifetime" type="text" <?php Util_Ui::sealing_disabled( 'fragmentcache.' ); ?> name="fragmentcache___lifetime" value="<?php echo esc_attr( $w3tc_config->get_integer( array( 'fragmentcache', 'lifetime' ) ) ); ?>" size="8" /><?php esc_html_e( 'seconds', 'w3-total-cache' ); ?>
					<p class="description"><?php esc_html_e( 'Determines the natural expiration time of unchanged cache items. The higher the value, the larger the cache.', 'w3-total-cache' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="fragmentcache_file_gc"><?php esc_html_e( 'Garbage collection interval:', 'w3-total-cache' ); ?></label></th>
				<td>
					<input id="fragmentcache_file_gc" type="text" <?php Util_Ui::sealing_disabled( 'fragmentcache.' ); ?> name="fragmentcache___file__gc" value="<?php echo esc_attr( $w3tc_config->get_integer( array( 'fragmentcache', 'file.gc' ) ) ); ?>" size="8" /> <?php esc_html_e( 'seconds', 'w3-total-cache' ); ?>
					<p class="description"><?php esc_html_e( 'If caching to disk, specify how frequently expired cache data is removed. For busy sites, a lower value is best.', 'w3-total-cache' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="fragmentcache_groups"><?php esc_html_e( 'Manual fragment groups:', 'w3-total-cache' ); ?></label></th>
				<td>
					<textarea id="fragmentcache_groups" name="fragmentcache___groups"
						<?php Util_Ui::sealing_disabled( 'fragmentcache.' ); ?>
						cols="40" rows="5"><?php echo esc_textarea( implode( "\r\n", $w3tc_config->get_array( array( 'fragmentcache', 'groups' ) ) ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Specify fragment groups that should be managed by W3 Total Cache. Enter one action per line comma delimited, e.g. (group, action1, action2). Include the prefix used for a transient by a theme or plugin.', 'w3-total-cache' ); ?></p>
				</td>
			</tr>
		</table>

		<?php Util_Ui::postbox_footer(); ?>
	</div>
</form>
