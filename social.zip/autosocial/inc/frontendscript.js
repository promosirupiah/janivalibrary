jQuery(document).ready(function ($) {
    
    $('.make-me-slick').slick();

    $('body').on("click",".autosocial-read-more",function(event) {

        event.preventDefault();

        //show more quote
        $(this).prev().show();

        //hide this
        $(this).hide();

        //show read less
        $(this).next().show();

    });

    $('body').on("click",".autosocial-read-less",function(event) {

        event.preventDefault();

        //hide more quote
        $(this).prev().prev().hide();

        

        //show read more
        $(this).prev().show();

        //hide this
        $(this).hide();

    });



});