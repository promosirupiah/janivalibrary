<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Save Access Token
*/
function autosocial_save_access_token(){

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    $code = sanitize_text_field($_POST['code']);
    $network = sanitize_text_field($_POST['network']);
    $authOptions = get_option('autosocial_auth_settings');

    if($network == 'Facebook'){

        $connectionDetails = autosocial_get_client_id_and_secret($network);

        $client_id = $connectionDetails['client_id'];
        $client_secret = $connectionDetails['client_secret'];
        $redirect_uri = $connectionDetails['redirect_uri'];

        $response = wp_remote_post( 'https://graph.facebook.com/v8.0/oauth/access_token?client_id='.$client_id.'&redirect_uri='.$redirect_uri.'&client_secret='.$client_secret.'&code='.$code );

        if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            $authOptions['facebook_access_token'] = $decodedBody['access_token'];
            // $authOptions['facebook_access_token_expiry'] = $decodedBody['expires_in'];
            $authOptions['facebook_access_token_expiry'] = current_time('timestamp') + 5184000;

            $authOptions['facebook_token_type'] = $decodedBody['token_type'];

            update_option('autosocial_auth_settings', $authOptions);

            echo 'SUCCESS';

        } else {
            echo 'ERROR';  
            // echo wp_remote_retrieve_response_message( $response );
            // echo $url;
        }    
    }   

    if($network == 'Instagram'){

        $connectionDetails = autosocial_get_client_id_and_secret($network);

        $client_id = $connectionDetails['client_id'];
        $client_secret = $connectionDetails['client_secret'];
        $redirect_uri = $connectionDetails['redirect_uri'];

        $response = wp_remote_post( 'https://graph.facebook.com/v8.0/oauth/access_token?client_id='.$client_id.'&redirect_uri='.$redirect_uri.'&client_secret='.$client_secret.'&code='.$code );

        if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            $authOptions['instagram_access_token'] = $decodedBody['access_token'];
            // $authOptions['facebook_access_token_expiry'] = $decodedBody['expires_in'];
            $authOptions['instagram_access_token_expiry'] = current_time('timestamp') + 5184000;

            $authOptions['instagram_token_type'] = $decodedBody['token_type'];

            update_option('autosocial_auth_settings', $authOptions);

            echo 'SUCCESS';

        } else {
            echo 'ERROR';  
            // echo wp_remote_retrieve_response_message( $response );
            // echo $url;
        }    
    }   
    
    
    if($network == 'Google My Business'){

        $connectionDetails = autosocial_get_client_id_and_secret($network);

        $client_id = $connectionDetails['client_id'];
        $client_secret = $connectionDetails['client_secret'];
        $redirect_uri = $connectionDetails['redirect_uri'];

        $response = wp_remote_post('https://www.googleapis.com/oauth2/v4/token?code='.$code.'&client_id='.$client_id.'&client_secret='.$client_secret.'&redirect_uri='.$redirect_uri.'&grant_type=authorization_code', array(
            'headers' => array(
                'Content-Length' => 0,
            ),
        )); 

        if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            // $authOptions['gmb_access_token'] = $decodedBody['access_token'];
            $authOptions['gmb_refresh_token'] = $decodedBody['refresh_token'];

            update_option('autosocial_auth_settings', $authOptions);

            set_transient( 'autosocial_gmb_access_token',$decodedBody['access_token'],MINUTE_IN_SECONDS*45);

            echo 'SUCCESS';
        } else {

            echo 'ERROR';   
            
            // echo ' '.wp_remote_retrieve_response_message( $response );
            
            // echo ' '.wp_remote_retrieve_response_code( $response );
        }    

    }



    if($network == 'LinkedIn'){
        
        $connectionDetails = autosocial_get_client_id_and_secret($network);

        $client_id = $connectionDetails['client_id'];
        $client_secret = $connectionDetails['client_secret'];
        $redirect_uri = $connectionDetails['redirect_uri'];

        $response = wp_remote_post( 'https://www.linkedin.com/oauth/v2/accessToken?grant_type=authorization_code&code='.$code.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id.'&client_secret='.$client_secret, array(
            'headers' => array(
                'Content-Length' => 0,
            ),
        ));


        if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            $authOptions['linkedin_access_token'] = $decodedBody['access_token'];
            $authOptions['linkedin_access_token_expiry'] = current_time('timestamp') + $decodedBody['expires_in'];

            update_option('autosocial_auth_settings', $authOptions);

            echo 'SUCCESS';
        } else {
            echo 'ERROR';   
            
            echo wp_remote_retrieve_response_message( $response );
        }    

    }


    if($network == 'Twitter'){
        
        $connectionDetails = autosocial_get_client_id_and_secret($network);

        $client_id = $connectionDetails['client_id'];
        $client_secret = $connectionDetails['client_secret'];
        $redirect_uri = $connectionDetails['redirect_uri'];

        $response = wp_remote_post( 'https://api.twitter.com/2/oauth2/token?grant_type=authorization_code&code='.$code.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id.'&code_verifier=challenge', array(
            'headers' => array(
                'Content-Length' => 0,
            ),
        ));


        if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            // $authOptions['twitter_access_token'] = $decodedBody['access_token'];
            $authOptions['twitter_refresh_token'] = $decodedBody['refresh_token'];
            // $authOptions['twitter_access_token_expiry'] = current_time('timestamp') + $decodedBody['expires_in'];
            update_option('autosocial_auth_settings', $authOptions);

            set_transient( 'autosocial_twitter_access_token',$decodedBody['access_token'],MINUTE_IN_SECONDS*90);

            echo 'SUCCESS';
        } else {
            echo 'ERROR';   
            
            echo wp_remote_retrieve_response_message( $response );
        }    

    }


    if($network == 'Pinterest'){
        
        $connectionDetails = autosocial_get_client_id_and_secret($network);

        $client_id = $connectionDetails['client_id'];
        $client_secret = $connectionDetails['client_secret'];
        $redirect_uri = $connectionDetails['redirect_uri'];


        $url = 'https://api.pinterest.com/v5/oauth/token';

        $authorization = 'Basic '.base64_encode($client_id.':'.$client_secret);

        $response = wp_remote_post($url , array(
            'headers' => array(
                'Authorization' => $authorization,
                'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
            ),
            'body' => array(
                'code' => $code,
                'redirect_uri' => $redirect_uri,
                'grant_type' => 'authorization_code',
            ),
        ));


        if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
            $authOptions['pinterest_access_token'] = $decodedBody['access_token'];
            $authOptions['pinterest_access_token_expiry'] = current_time('timestamp') + $decodedBody['expires_in'];
            $authOptions['pinterest_refresh_token'] = $decodedBody['refresh_token'];

            update_option('autosocial_auth_settings', $authOptions);
            
            echo 'SUCCESS';
        } else {
            echo 'ERROR';   
            echo wp_remote_retrieve_response_message( $response );
        }    

    }


    //lastly we want to clear the cache to retrieve latest accounts
    $networkNameTranslated = autosocial_translate_network_name($network);
    $transientName = 'autosocial_account_data_'.$networkNameTranslated;

    //delete the transient
    delete_transient($transientName);

    wp_die();

}
add_action( 'wp_ajax_save_access_token', 'autosocial_save_access_token' );
/**
* 
*
*
* Get Google My Business Access Token
*/
function autosocial_get_access_token($network){

    //general authoptions setting
    $authOptions = get_option('autosocial_auth_settings');
    $connectionDetails = autosocial_get_client_id_and_secret($network);

    if($network == 'Google My Business'){

        $getTransient = get_transient('autosocial_gmb_access_token');
        
        //if the transient exists
        if ($getTransient != false){
            
            return $getTransient;
  
        } else {
            
            //the transient doesn't exist therefore do api call

            //current refresh token
            $currentRefreshToken = $authOptions['gmb_refresh_token'];

            

            $client_id = $connectionDetails['client_id'];
            $client_secret = $connectionDetails['client_secret'];


            //do response
            $response = wp_remote_post( 'https://www.googleapis.com/oauth2/v4/token?refresh_token='.$currentRefreshToken.'&client_id='.$client_id.'&client_secret='.$client_secret.'&grant_type=refresh_token' );

            
            if ( 200 == wp_remote_retrieve_response_code($response) ) {

                //get new acess token and refresh token
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                $newAccessToken = $decodedBody['access_token'];

                set_transient( 'autosocial_gmb_access_token',$newAccessToken,MINUTE_IN_SECONDS*45);

                //return the new access token
                return $newAccessToken;

            } //end success
            
     
        } //end existing transient check

    } //end google my business



    if($network == 'Twitter'){

        $getTransient = get_transient('autosocial_twitter_access_token');
        
        //if the transient exists
        if ($getTransient != false){
            
            return $getTransient;
  
        } else {
            
            //the transient doesn't exist therefore do api call

            //current refresh token
            $currentRefreshToken = $authOptions['twitter_refresh_token'];
            
            $client_id = $connectionDetails['client_id'];
            $client_secret = $connectionDetails['client_secret'];

            //do response
            $url = 'https://api.twitter.com/2/oauth2/token?refresh_token='.$currentRefreshToken.'&client_id='.$client_id.'&grant_type=refresh_token';
            $response = wp_remote_post( $url );

            
            if ( 200 == wp_remote_retrieve_response_code($response) ) {

                //get new acess token and refresh token
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                
                $newAccessToken = $decodedBody['access_token'];

                set_transient( 'autosocial_twitter_access_token',$newAccessToken,MINUTE_IN_SECONDS*90);

                //we also need to save the new refresh token as this!!!
                $authOptions['twitter_refresh_token'] = $decodedBody['refresh_token'];

                update_option('autosocial_auth_settings', $authOptions);

                //return the new access token
                return $newAccessToken;

            } //end success 

            if ( 200 !== wp_remote_retrieve_response_code($response) ) {

                $current_time = current_time('Y-m-d H:i:s');

            } //end success 
            
            
     
        } //end existing transient check

    } //end twitter


    if($network == 'Pinterest'){

        //we need to check the time
        $current_time = current_time('timestamp');
        $expiry = intval($authOptions['pinterest_access_token_expiry']);

        if($current_time < $expiry){
            //the access token should still be active
            return $authOptions['pinterest_access_token'];
        } else {
            //we need to get a new access token
            $client_id = $connectionDetails['client_id'];
            $client_secret = $connectionDetails['client_secret'];
            $redirect_uri = $connectionDetails['redirect_uri'];

            $url = 'https://api.pinterest.com/v5/oauth/token';

            $authorization = 'Basic '.base64_encode($client_id.':'.$client_secret);

            $response = wp_remote_post($url , array(
                'headers' => array(
                    'Authorization' => $authorization,
                    'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                ),
                'body' => array(
                    'refresh_token' => $authOptions['pinterest_refresh_token'],
                    'grant_type' => 'refresh_token',
                ),
            ));


            if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                $authOptions['pinterest_access_token'] = $decodedBody['access_token'];
                $authOptions['pinterest_access_token_expiry'] = current_time('timestamp') + $decodedBody['expires_in'];
                // $authOptions['pinterest_refresh_token'] = $decodedBody['refresh_token'];

                update_option('autosocial_auth_settings', $authOptions);
                
                return $decodedBody['access_token'];
            } 
            // else {
            //     echo 'ERROR';   
            //     echo wp_remote_retrieve_response_message( $response );
            // }  

        }


    }



}  //end function  

/**
* 
*
*
* This function enables people to use custom applications got Google My Business, Facebook and LinkedIn
*/
function autosocial_get_client_id_and_secret($network){

    //we need to see if the option for the network for client id and secret are both filled in
    //if so return an array with client id and client secret
    //else return our standard application values
    //we also need to return the redirect URL as this will differ depending on custom application or not

    if($network == 'Google My Business'){
        $returnArray = array(
            'client_id'=>'979275334189-mqphf6kpvpji9km7i6pm0sq5ddvfoa60.apps.googleusercontent.com',
            'client_secret'=>'hENqfr4whG7qs5QxSSzOa9_s',
            'redirect_uri'=>'https://northernbeacheswebsites.com.au/redirectautosocialgoogle/'
        );    
    }

    if($network == 'Facebook'){
        $returnArray = array(
            'client_id'=>'223367198256846',
            'client_secret'=>'7df37701a4251f6a8184ebd1e247624c',
            'redirect_uri'=>'https://northernbeacheswebsites.com.au/redirectautosocialfacebook/'
        );
    }

    if($network == 'Twitter'){
        $returnArray = array(
            'client_id'=>'dUlSV3ZDYU5NZ1V4UVdpZi1lNE86MTpjaQ',
            'client_secret'=>'qo3ApE1c3Df4L_hoUI7EDdLA_ixGZ1BdBsHCl590zUIe8VJ_oN',
            'redirect_uri'=>'https://northernbeacheswebsites.com.au/redirectautosocialtwitter/'
        );    
    }

    if($network == 'LinkedIn'){
        $returnArray = array(
            'client_id'=>'8640n1zn844brm',
            'client_secret'=>'IDRdaazTtBBuREGS',
            'redirect_uri'=>'https://northernbeacheswebsites.com.au/redirectautosociallinkedin/'
        );
    }

    if($network == 'Pinterest'){
        $returnArray = array(
            'client_id'=>'1473020',
            'client_secret'=>'87ca9e6d633f7f64955692225ace6efb1fa6451e',
            'redirect_uri'=>'https://northernbeacheswebsites.com.au/redirectautosocialpinterest/'
        );
    }



    

    if(get_option('autosocial_settings')){

        //get options
        $options = get_option('autosocial_settings');

        //translate the network name
        $networkNameTranslated = autosocial_translate_network_name($network);

       
        if( array_key_exists('autosocial_'.$networkNameTranslated.'_advanced_client_id',$options) && array_key_exists('autosocial_'.$networkNameTranslated.'_advanced_client_secret',$options) ){
            
            //get client id
            $clientId = trim($options['autosocial_'.$networkNameTranslated.'_advanced_client_id']);

            //get client secret
            $clientSecret = trim($options['autosocial_'.$networkNameTranslated.'_advanced_client_secret']);

            if(strlen($clientId)>0  && strlen($clientSecret)>0 ){

                $redirectUri = get_admin_url().'admin.php?page=autosocial';

                $returnArray = array('client_id'=>$clientId,'client_secret'=>$clientSecret,'redirect_uri'=>$redirectUri);   

            } 
        }
    }


    
    



    return $returnArray;

}    






?>