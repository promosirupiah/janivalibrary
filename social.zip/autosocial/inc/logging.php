<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* save to log - post - used for success
*/
function autosocial_save_to_post_log($postId,$network,$profileId,$url){
    
    //declare common variables
    $metaName = 'autosocial_share_history';
    $currentTime = current_time('timestamp');
    $arrayData = array('time'=>$currentTime,'network'=>$network,'url'=>$url,'profile'=>$profileId);

    //check if meta exists
    if(metadata_exists('post',$postId,$metaName)){

        $existingShareHistory = get_post_meta($postId,$metaName,true);

        //lets add our item to the array
        array_push( $existingShareHistory, $arrayData);

        //update the meta
        update_post_meta($postId,$metaName,$existingShareHistory);

    } else {
        //update the meta with a container array
        update_post_meta($postId,$metaName,array($arrayData));    
    } 

}  

/**
* 
*
*
* save to log common - used for errors
*/
function autosocial_save_to_general_log($postId,$network,$profileId,$status){

    //declare common variables
    $optionName = 'autosocial_error_log';
    $currentTime = current_time('timestamp');
    $arrayData = array('time'=>$currentTime,'postId'=>$postId,'network'=>$network,'status'=>$status,'profile'=>$profileId);

    $option = get_option($optionName);

    //check if meta exists
    if($option){

        //lets add our item to the array
        array_push( $option, $arrayData);

        //update the meta
        update_option($optionName,$option);

    } else {

        //update the option with a container array
        update_option($optionName,array($arrayData));   
    } 

}  
?>