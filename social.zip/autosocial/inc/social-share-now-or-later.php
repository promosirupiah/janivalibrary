<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Performs share now
*/
function autosocial_share_now_or_schedule() { 


    

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    //get parameters from javascript
    $data = $_POST['data'];
    $shareWhen = sanitize_text_field($_POST['shareWhen']);
    // $data = json_decode(base64_decode($data),true);




    $data = json_decode(stripslashes($data),true);


    //get options
    $options = get_option( 'autosocial_settings' );





    //start processing of common data

    //convert date format into php time string
    $scheduledDateTime = $data['share-now-or-schedule-setting-schedule-date-time'];

    if(strlen($scheduledDateTime)>0){
        $scheduledDateTime = strtotime($scheduledDateTime);
    } else {
        $scheduledDateTime = '';    
    }

    

    //do link
    $link = $data['share-now-or-schedule-setting-link'];

    if(strlen($link)>0){
        if( isset($options['autosocial_enable_bit_ly']) ){
            $link = autosocial_get_bit_ly_link($link);      
        }
    } else {
        $link = false;   
    }

    //do image
    $image = $data['share-now-or-schedule-setting-image'];

    if(strlen($image)<1){
        $image = false;   
    }

    
    //lets loop through each profile
    $networks = array('Facebook','Google My Business','Twitter','LinkedIn','Instagram','Pinterest');

    foreach($networks as $network){

        $networkNameTranslated = autosocial_translate_network_name($network);

        //get share message
        $shareMessage = $data['autosocial_'.$networkNameTranslated.'_share_message'];

        $shareMessage = autosocial_shorten_message($shareMessage,$network);

        //get the profiles
        $profilesToShareTo = $data['share-now-or-schedule-setting-profile-selection-'.$networkNameTranslated];

        //only do something if there are profiles!
        if( strlen($profilesToShareTo) > 0 ){

            //lets split the profiles and loop through them
            $profilesToShareToExploded = explode(',',$profilesToShareTo);

            //lets loop through each profile
            foreach($profilesToShareToExploded as $profile){

                if(strlen($profile)>0){

                    

                    //lets construct an array which can be used for storage or processing
                    $profileDataArray = array();

                    //create a unique id for this post
                    $shareId = autosocial_share_now_or_schedule_id('share_now_or_schedule');
                    //lets add the share id
                    $profileDataArray['id'] = $shareId;

                    //lets add the network
                    $profileDataArray['network'] = $network;

                    //lets add the profile id
                    $profileDataArray['profileId'] = $profile;

                    //lets add image if it exists
                    if($image !== false){
                        $profileDataArray['image'] = $image;
                    }

                    //lets add link if it exists
                    if($link !== false){
                        $profileDataArray['link'] = $link;
                    }
                  
                    //lets add message
                    $profileDataArray['shareMessage'] = $shareMessage;

                    //lets do google specific stuff
                    if($network == 'Google My Business'){
                        //google specific settings

                        //lets add custom button
                        $profileDataArray['customButton'] = $data['share-now-or-schedule-setting-custom-button-google_my_business'];

                        $isEvent = $data['share-now-or-schedule-setting-enable-event-google_my_business'];

                        if($isEvent == 'true'){
                            //its an event so continue adding data
                            $profileDataArray['eventTitle'] = $data['share-now-or-schedule-setting-event-title-google_my_business'];
                            $profileDataArray['eventStart'] = $data['share-now-or-schedule-setting-event-start-google_my_business'];
                            $profileDataArray['eventEnd'] = $data['share-now-or-schedule-setting-event-end-google_my_business'];

                        }
                    }

                    //lets do pinterest specific stuff
                    if($network == 'Pinterest'){

                        //do board
                        $profileDataArray['pinTitle'] = $data['share-now-or-schedule-setting-pin-title-pinterest'];
                    }


                    //share now?
                    if($shareWhen == 'send'){
                        //send now
                        autosocial_process_array($profileDataArray);
                    } else {
                        //shedule

                        //lets add scheduled time to array before sending it to the options
                        $profileDataArray['scheduledDateTime'] = $scheduledDateTime;

                        autosocial_add_to_schedule_queue($shareId,$profileDataArray);


                    }    


                }
            }

        }

    }

    

    echo 'SUCCESS';


    wp_die();   

}
add_action( 'wp_ajax_share_now_or_schedule', 'autosocial_share_now_or_schedule' );


function autosocial_share_now_or_schedule_id($type){

    $optionName = 'autosocial_counter';

    //get existing option
    $existingValue = get_option($optionName);

    //if the option doesnt even exist we need to create it
    if($existingValue == false){
        //the option doesn't exist so we need to create it
        $existingValue = array($type=>1);  
        $updatedNumber = 1; 
    } else {
        //the option at least exists
        //check to see if the type is in the array
        if(array_key_exists($type,$existingValue)){
            //the item exists so we need to update it
            $typeValue = $existingValue[$type];
            //add one to it
            $typeValue++;
            //now update the option
            $existingValue[$type] = $typeValue;

            $updatedNumber = $typeValue;
            
        } else {
            //the option exists but the type doesnt
            $existingValue[$type] = 1;
            $updatedNumber = 1; 

        }
    }

    update_option($optionName,$existingValue);
    return $updatedNumber;   
}


function autosocial_add_to_schedule_queue($shareId,$profileDataArray){

    $optionName = 'autosocial_schedule_queue';
    //get existing option
    $existingValue = get_option($optionName);

    if($existingValue == false){
        //no option exists
        $existingValue = array($shareId=>$profileDataArray);

    } else {
        //an option exists
        $existingValue[$shareId] = $profileDataArray;
    } 
    
    update_option($optionName,$existingValue);

}    


function autosocial_process_array($profileDataArray){

    //create a unique id for this post
    $shareId = autosocial_share_now_or_schedule_id('share_now_or_schedule');

    // //lets add the share id
    // $profileDataArray['id'] = $shareId;

    //get options
    $options = get_option( 'autosocial_settings' );
    $authOptions = get_option('autosocial_auth_settings');
    

    //get required variables
    // $shareId = $profileDataArray['id'];
    $network = $profileDataArray['network'];
    $profileId = $profileDataArray['profileId'];
    $shareMessage = $profileDataArray['shareMessage'];


    $getAccountData = autosocial_account_data($network);

    //get the access token for the profile
    foreach($getAccountData as $accountItem){
    
        if($accountItem['id'] == $profileId){
            $profileIdExists = true;
            $profileType = $accountItem['type'];
            $profileAccessToken = $accountItem['access_token'];
        }
    }

    if(isset($profileIdExists)){




        if($network == 'Facebook'){

            if(isset($profileAccessToken)){

                //if there's an image and no link, upload the image
                if(isset($profileDataArray['image']) && !isset($profileDataArray['link'])){
                    $url = 'https://graph.facebook.com/v8.0/'.$profileId.'/photos'; 

             
                    // Create JSON body
                    $json = json_encode( array(
                        'url' => $profileDataArray['image'],
                        'caption' => $shareMessage
                    ));

                    $response = wp_remote_post( 'https://graph.facebook.com/v8.0/'.$profileId.'/photos', array(
                        'headers' => array(
                            'Authorization' => 'Bearer '.$profileAccessToken,
                            'Content-Type' => 'application/json; charset=utf-8',
                        ),
                        'body' => $json,
                    ));

                    $status = wp_remote_retrieve_response_code( $response );

                    if($status == 200){
                        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                        $facebookFeedItemId = $decodedBody['id'];

                        $url = 'https://www.facebook.com/'.$facebookFeedItemId;
                    }
                } else {

                    $responseUrl = 'https://graph.facebook.com/v8.0/'.$profileId.'/feed?access_token='.$profileAccessToken.'&published=true';
                

                    $json = array(
                        'message' => $shareMessage
                    );
                    
                    //add link if it is available
                    if(isset($profileDataArray['link'])){
                        $responseUrl .= '&link='.$profileDataArray['link'];
                    }

                    //now share the post
                    $response = wp_remote_post($responseUrl, array(
                        'headers' => array(
                            'Content-Type' => 'application/json; charset=utf-8',
                        ),
                        'body' => json_encode($json),
                    ));

                    //get status
                    $status = wp_remote_retrieve_response_code( $response );

                    if( $status == 200 ){

                        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                        $facebookFeedItemId = $decodedBody['id'];

                        $url = 'https://www.facebook.com/'.$facebookFeedItemId;

                    } 
                }

                

            } //end if access token exists

        } //end facebook





        //do instagram
        if($network == 'Instagram'){



            //only do something if the access token is available
            //this prevents sharing to profiles which may be stuck from old authentications
            if(isset($profileAccessToken)){
                //now share the post

        
                //we need to do 2 steps, first we need to create the image container, and then we need to publish it
                //add image to query if available
                $postImage = $profileDataArray['image'];
                if($postImage !== 'NO IMAGE'){

                    $response = wp_remote_get( $postImage );
                    $status = wp_remote_retrieve_response_code( $response );
                    
                    if($status == 200){
                        $headers = wp_remote_retrieve_headers( $response );

                        $accepted_file_types = array('image/jpeg','image/jpg');

                        if(in_array($headers['Content-Type'],$accepted_file_types) && $headers['Content-Length'] < 8000000 ){
                            //lets continue
                            $response = wp_remote_post( 'https://graph.facebook.com/'.$profileId.'/media?image_url='.$postImage.'&access_token='.$authOptions['facebook_access_token'].'&caption='.$shareMessage );

                            $status = wp_remote_retrieve_response_code( $response );

                            if($status == 200){
                                //we can continue to step 2
                                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                                $id = $decodedBody['id'];

                                //now lets publish
                                $response = wp_remote_post( 'https://graph.facebook.com/'.$profileId.'/media_publish?access_token='.$authOptions['facebook_access_token'].'&creation_id='.$id );

                                $status = wp_remote_retrieve_response_code( $response );

                                if($status == 200){
                                    //do something
                                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                                    //this is all we get back
                                    $id = $decodedBody['id'];

                                    //we now need to get the public URL
                                    $response = wp_remote_get( 'https://graph.facebook.com/v12.0/'.$id.'?access_token='.$authOptions['facebook_access_token'].'&fields=permalink' );

                                    $status = wp_remote_retrieve_response_code( $response );

                                    if($status == 200){
                                        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                                        $url = $decodedBody['permalink'];

                                        // autosocial_save_to_post_log($postId,$network,$profileId,$url);  
                                    } else {
                                        //do some error for the publish URL
                                        // autosocial_save_to_general_log($postId,$network,$profileId,$status); 
                                    }


                                } else {
                                    //do some error for the publish
                                    // autosocial_save_to_general_log($postId,$network,$profileId,$status); 
                                }


                            } else {
                                //do some error for the container
                                // autosocial_save_to_general_log($postId,$network,$profileId,$status); 
                            }
                        }

                    } //end image properties check


                } //end if image exists


            }
        }




        //do google my business
        if($network == 'Google My Business'){

            //lets start with the button
            $actionType = $profileDataArray['customButton'];
           

            //check if the item is an event
            if(isset($profileDataArray['eventTitle'])){
                //event
                $topicType = 'EVENT'; 
            } else {
                //not event
                $topicType = 'STANDARD'; 
            }

            // Create JSON body
            $json = array(
                'topicType' => $topicType,
                'languageCode' => substr(get_locale(), 0, 5),
                'summary' => $shareMessage,
            );


            //add link if its available
            if(isset($profileDataArray['link']) && $actionType !== 'CALL'){
                $json['callToAction'] = array(
                    'url' => $profileDataArray['link'],
                    'actionType' => $actionType,
                );   
            }    

            //do call action type
            if($actionType == 'CALL'){
                $json['callToAction'] = array(
                    'actionType' => $actionType,
                );   
            }

            if(isset($profileDataArray['image'])){


                //do additional check for dimensions
                $imageInfo = getimagesize($profileDataArray['image']);

                //get file size
                $headers = get_headers($profileDataArray['image'], true);
                
                if ( isset($headers['Content-Length']) ) {
                    $imageSize = intval($headers['Content-Length']);
                } else {
                    $imageSize = 10241;
                }


                if( $imageInfo[0] > 250 && $imageInfo[1] > 250 && $imageSize > 10240 ){
                    $json['media'] = array(
                        'sourceUrl' => $profileDataArray['image'],
                        'mediaFormat' => 'PHOTO',
                    ); 
                }



            }    

            
            //check to see if event
            if($topicType == "EVENT"){
                
                $eventTitle = $profileDataArray['eventTitle'];
                $eventStart = $profileDataArray['eventStart'];
                $eventEnd = $profileDataArray['eventEnd'];
                

                $startDate = strtotime($eventStart);
                $endDate = strtotime($eventEnd);
                
                $startDateYear = date('Y',$startDate);
                $endDateYear = date('Y',$endDate);
                
                $startDateMonth = date('n',$startDate);
                $endDateMonth = date('n',$endDate);
                
                $startDateDay = date('j',$startDate);
                $endDateDay = date('j',$endDate);
                
                $startDateHours = date('G',$startDate);
                $endDateHours = date('G',$endDate);
                
                $startDateMinutes = intval(date('i',$startDate));
                $endDateMinutes = intval(date('i',$endDate));
                
                $json['event'] = array('title'=>$eventTitle,'schedule'=> array('startDate'=>array('year'=>$startDateYear,'month'=>$startDateMonth,'day'=>$startDateDay), 'startTime'=>array('hours'=>$startDateHours,'minutes'=>$startDateMinutes),'endDate'=>array('year'=>$endDateYear,'month'=>$endDateMonth,'day'=>$endDateDay), 'endTime'=>array('hours'=>$endDateHours,'minutes'=>$endDateMinutes)));     

            }

            //encode the array before sending
            $json = json_encode($json);


            //do call
            $url = 'https://mybusiness.googleapis.com/v4/'.$profileId.'/localPosts';

            $response = wp_remote_post($url, array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                    'Content-Type' => 'application/json; charset=utf-8',
                ),
                'body' => $json,
            ));  

            $status = wp_remote_retrieve_response_code( $response );

            if( $status == 200 ){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                $url = $decodedBody['searchUrl'];

            } else {
                // $error_message = wp_remote_retrieve_response_message( $response );
            }

        }
        







        //do twitter
        if($network == 'Twitter'){

            if( isset($profileDataArray['link']) ){
                $shareMessage = $shareMessage.' '.$profileDataArray['link'];
            }
            

            // Create JSON body
            $json = json_encode( array(
                'text' => $shareMessage
            ));

            // {@see https://codex.wordpress.org/HTTP_API}
            $response = wp_remote_post( 'https://api.twitter.com/2/tweets', array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                    'Content-Type' => 'application/json; charset=utf-8',
                ),
                'body' => $json,
            ));

            $status = wp_remote_retrieve_response_code( $response );

            if($status == 200 || $status == 201){
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                $decodedBody = $decodedBody['data'];
                $tweet_id = $decodedBody['id'];

                $url = 'https://twitter.com/'.$profileId.'/status/'.$tweet_id;

            }

        }
    






        //do linkedin
        if($network == 'LinkedIn'){

            $subject = html_entity_decode(substr($shareMessage,0,200));

            //do fix for profile id
            if (strpos($profileId, 'urn:li') === false) {
                $profileId = 'urn:li:person:'.$profileId;
            }

            // Create JSON body
            $json = array(
                'commentary' => $shareMessage,
                'author' => $profileId,
                'visibility' => 'PUBLIC',
                'distribution' => array(
                    'thirdPartyDistributionChannels' => array(
                    ),
                    'targetEntities' => array(

                    ),
                    'feedDistribution' => 'MAIN_FEED'
                ),
                'lifecycleState' => 'PUBLISHED',
                'isReshareDisabledByAuthor' => false
            );

            //if just link with no image
            if( isset($profileDataArray['link']) && ! isset($profileDataArray['image']) ){
                $json['content'] = array(
                    'article' => array(
                        'source' => $profileDataArray['link'],
                        'title' => $subject,
                    ),
                );   
            }

            //do we need to upload an image?
            if( isset($profileDataArray['image']) ){
                //lets get the upload URL
                // Create JSON body
                $json_body = array(
                    'initializeUploadRequest' => array(
                        'owner' => $profileId
                    ),
                );

                $response = wp_remote_post( 'https://api.linkedin.com/rest/images?action=initializeUpload', array(
                    'headers' => array(
                        'Linkedin-Version' => '202305',
                        'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                        'Content-Type' => 'application/json',
                    ),
                    'body' => json_encode($json_body),
                ));

                $status = wp_remote_retrieve_response_code( $response );

                if($status == 200){
                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                    $asset = $decodedBody['value']['image'];
                    $upload_url = $decodedBody['value']['uploadUrl'];

                    $c = curl_init();
                    curl_setopt($c, CURLOPT_URL, $profileDataArray['image']);
                    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
                    $image_data = curl_exec($c);
                    curl_close($c);

                    //get the content of the file
                    // $image_data = file_get_contents($profileDataArray['image']);
                    $get_file = wp_remote_get($profileDataArray['image']);
                    $header = wp_remote_retrieve_headers($get_file);
                    $header = (array) $header; //set it to array as it might be an object
                    $header_content = $header['Content-Type'];

                    //now we need to upload the file
                    $response = wp_remote_post( $upload_url, array(
                        'headers' => array(
                            'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                            'Content-Type' => $header_content,
                        ),
                        'body' => $image_data
                    ));

                    $status = wp_remote_retrieve_response_code( $response );

                    //if link and image
                    if( isset($profileDataArray['image']) && isset($profileDataArray['link']) ){ 
                        $json['content'] = array(
                            'article' => array(
                                'source' => $profileDataArray['link'],
                                'title' => $subject,
                                'thumbnail' => $asset,
                            ),
                        );   
                    }

                    //if just image
                    if( isset($profileDataArray['image']) && ! isset($profileDataArray['link']) ){ 
                        $json['content'] = array(
                            'media' => array(
                                // 'source' => $profileDataArray['link'],
                                'title' => $subject,
                                'id' => $asset,
                            ),
                        );   
                    }

                } //end status 200 check for image container

            } //end check if image upload is needed

            $response = wp_remote_post( 'https://api.linkedin.com/rest/posts', array(
                'headers' => array(
                    'Linkedin-Version' => '202305',
                    'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                    'Content-Type' => 'application/json',
                ),
                'body' => json_encode( $json ),
            ));

            $status = wp_remote_retrieve_response_code( $response );

            if( $status == 201 ||  $status == 200){

                $headers = wp_remote_retrieve_headers( $response );

                $activity = $headers['x-linkedin-id'];

                $url = 'https://www.linkedin.com/feed/update/'.$activity;

            }


        } //end linkedin








        //do pinterest
        if($network == 'Pinterest'){

            $postImage = $profileDataArray['image'];

            if($postImage !== 'NO IMAGE'){

                // Create JSON body
                $json = json_encode( array(
                    'media_source' => array(
                        'url' => $postImage,
                        'source_type' => 'image_url'
                    ),
                    'title' => $profileDataArray['pinTitle'],
                    'description' => $shareMessage,
                    'board_id' => $profileId,
                    'link' => $profileDataArray['link']
                ));

                $url = 'https://api.pinterest.com/v5/pins';
                
                $response = wp_remote_post( $url, array(
                    'headers' => array(
                        'Authorization' => 'Bearer '.autosocial_get_access_token('Pinterest'),
                        'Content-Type' => 'application/json; charset=utf-8',
                    ),
                    'body' => $json,
                ));

                $status = wp_remote_retrieve_response_code( $response );

                if( $status == 201 ||  $status == 200){

                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                    $url = 'https://www.pinterest.com.au/pin/'.$decodedBody['id'].'/';

                } 


            }


        } //end pinterest


    
    

        //send to log
        $optionName = 'autosocial_share_now_log';
        //get existing option
        $existingValue = get_option($optionName);

        $logData = array('currentTime'=>current_time('timestamp'),'data'=>$profileDataArray,'status'=>$status);

        //add url if set
        if(isset($url)){
            $logData['url'] = $url; 
        }

        if($existingValue == false){
            //no option exists
            $existingValue = array($shareId=>$logData);

        } else {
            //an option exists
            $existingValue[$shareId] = $logData;
        } 
        
        update_option($optionName,$existingValue);


    } //end if profile exists


}    





/**
* 
*
*
* Performs reshare
*/
function autosocial_reshare_item() { 

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    //get parameters from javascript
    $shareId = intval($_POST['shareId']);

    //get options
    $optionName = 'autosocial_share_now_log';
    //get existing option
    $existingValue = get_option($optionName);

    $profileDataArray = $existingValue[$shareId]['data'];

    //send data to share function
    autosocial_process_array($profileDataArray);

    echo 'SUCCESS';

    wp_die();   

}
add_action( 'wp_ajax_reshare_item', 'autosocial_reshare_item' );

/**
* 
*
*
* Deletes item
*/
function autosocial_delete_scheduled_item() { 

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    //get parameters from javascript
    $shareId = intval($_POST['shareId']);

    //get options
    $optionName = 'autosocial_schedule_queue';

    //get existing option
    $existingValue = get_option($optionName);

    //remove the item from the array
    unset($existingValue[$shareId]);

    //update the option
    update_option($optionName,$existingValue);

    echo 'SUCCESS';

    wp_die();   

}
add_action( 'wp_ajax_delete_scheduled_item', 'autosocial_delete_scheduled_item' );

/**
* 
*
*
* Edits item
*/
function autosocial_edit_scheduled_item() { 

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    //get parameters from javascript
    $shareId = intval($_POST['shareId']);
    $shareDateTimeEdited = strtotime(sanitize_text_field($_POST['shareDateTimeEdited']));
    $shareLinkEdited = sanitize_text_field($_POST['shareLinkEdited']);
    $shareImageEdited = sanitize_text_field($_POST['shareImageEdited']);
    $shareMessageEdited = sanitize_text_field($_POST['shareMessageEdited']);

    //get options
    $optionName = 'autosocial_schedule_queue';

    //get existing option
    $existingValue = get_option($optionName);

    //update values
    $existingValue[$shareId]['scheduledDateTime'] = $shareDateTimeEdited;
    $existingValue[$shareId]['link'] = $shareLinkEdited;
    $existingValue[$shareId]['image'] = $shareImageEdited;
    $existingValue[$shareId]['shareMessage'] = $shareMessageEdited;

    //update the option
    update_option($optionName,$existingValue);

    //we are going to return the date formatted nice so we can update the table row value
    $dateFormat = get_option('date_format');
    $timeFormat = get_option('time_format');

    $niceTime = date($dateFormat.' '.$timeFormat,$shareDateTimeEdited);

    echo $niceTime;

    wp_die();   

}
add_action( 'wp_ajax_edit_scheduled_item', 'autosocial_edit_scheduled_item' );
/**
* 
*
*
* Checks for scheduled posts and sends them
*/
function autosocial_send_scheduled_posts() {

    //we need to create a transient which prevents this running multiple times if the init function is triggered multiple times which I believe can happen
    $transientRunningName = 'autosocial_schedule_running';
    $getTransientRunning = get_transient($transientRunningName);

    if ($getTransientRunning != false){
        //the transient exists do nothing
    } else {
        
        //set the transient straight away
        set_transient($transientRunningName,true, MINUTE_IN_SECONDS*14);  


        //the purpose of this transient is to ensure we aren't trying to send the posts every second
        //get transient
        $transientName = 'autosocial_schedule_check';
        $getTransient = get_transient($transientName);

        //if transient doesn't exist or caching disabled do this
        if ($getTransient != false){
            //transient exists dont do anything
            
        } else {             
            //transient does not exist - check for posts we need to schedule

            //we need to get schedule the data
            $optionName = 'autosocial_schedule_queue';
            //get existing option
            $existingValue = get_option($optionName);

            //only continue if the option exists
            if($existingValue !== false){
                //cycle through each of the schedule data
                foreach($existingValue as $key => $profileDataArray){

                    $scheduledTime = $profileDataArray['scheduledDateTime'];
                    $shareId = $key;

                    //get current time
                    $currentTime = current_time('timestamp');

                    //check if the date is in the past
                    if($scheduledTime <= $currentTime){

                        //and delete from scheduled function
                        //remove the item from the array
                        unset($existingValue[$shareId]);

                        //update the option
                        update_option($optionName,$existingValue);

                        //if it is, send it to our share function
                        autosocial_process_array($profileDataArray);

                    }
                }
            }    

            //set the transient for 15 minutes
            set_transient($transientName,true, MINUTE_IN_SECONDS*15);  
        } 


        //delete the transient so it can run again
        //we may consider removing this code
        delete_transient( $transientRunningName );


    }

    
    
}
add_action( 'init', 'autosocial_send_scheduled_posts', 10, 3 );
?>