jQuery(document).ready(function ($) {
    
    
    //hide the tab section if we aren't sharing the post
    function autosocial_hide_tabbed_section(){

        if($('#autosocial_dont_share_post').is(':checked')){
            $('.social-network-tab-section').slideUp('fast');
        } else {
            $('.social-network-tab-section').slideDown('fast');
        }      

    }
    //run initially
    autosocial_hide_tabbed_section();

    //run on change
    $('#autosocial_add_metabox').on('change','#autosocial_dont_share_post',function(event) {
        event.preventDefault();
        autosocial_hide_tabbed_section();
    });    


    $('#autosocial_add_metabox').on("click",".upload-custom-autosocial-image, #autosocial_override_feature_image",function(event) {
        event.preventDefault();

        var previousInput = $('#autosocial_override_feature_image'); 
       
        var image = wp.media({ 
            title: 'Upload Image',
            // mutiple: true if you want to upload multiple files at once
            multiple: false
        }).open()
        .on('select', function(e){
            // This will return the selected image from the Media Uploader, the result is an object
            var uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            var image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            previousInput.val(image_url);
            previousInput.trigger('imageChange');

            //add image to preview
            $('.autosocial_override_feature_image_preview').attr('src',image_url).show();
            $('.autosocial_override_feature_image_preview_clear').show();
            
        });

    }); 


    //change tabs
    function autosocial_hide_and_show_tabs(){
        //hide tab content
        $('.autosocial-tabs-content > li').not('.active').slideUp('fast');
    }   
    
    //run initially
    autosocial_hide_and_show_tabs();

    $('#autosocial_add_metabox').on("click",".autosocial-tabs-header li",function(event) {
        event.preventDefault();

        //dont do anything if tab already active
        if(!$(this).hasClass('active')){
            //change active tab
            $('.autosocial-tabs-header li').removeClass('active');
            $(this).addClass('active');

            //change tab content
            $('.autosocial-tabs-content > li').slideUp('fast').removeClass('active');

            var clickedTab = $(this).attr('data');

            $('.autosocial-tabs-content .'+clickedTab).slideDown('fast');



        }

    
    });    


    //select and deselect profiles
    //toggle the selection of profiles
    $('#autosocial_add_metabox').on("click",".profile-item", function(event){

        event.preventDefault();
        
        var optionName = $(this).attr('data-option-name');

        var setting = $('#'+optionName);

        var valueOfSetting = setting.val();
        
        var profileId = $(this).attr('data');
        
        if($(this).hasClass('selected')){
            //we need to remove the item
            
            $(this).removeClass('selected');
            $(this).find('.profile-icon').removeClass('fa-check-circle-o').addClass('fa-times-circle-o');            
            
            var settingAsAnArray = valueOfSetting.split(',');
            var positionInArray = settingAsAnArray.indexOf(profileId);
            if (positionInArray > -1) {
                settingAsAnArray.splice(positionInArray, 1);
            }
            
            var newSettingValue = settingAsAnArray.join(",");
            
            
            setting.val(newSettingValue);
            
        } else {
            //we need to add the item

            
            $(this).addClass('selected');
            $(this).find('.profile-icon').removeClass('fa-times-circle-o').addClass('fa-check-circle-o');
            
            if(valueOfSetting == ''){
                setting.val(profileId);    
            } else {
                setting.val(valueOfSetting+','+profileId);      
            }
            
        }
        
   
    });

    //add shortcode to textbox

    $('#autosocial_add_metabox').on("click",".autosocial-shortcodes li", function(event){

        event.preventDefault();

        var thisText = $(this).text();

        var textBox = $(this).parent().next();

        var textBoxValue = textBox.val();

        textBox.val(textBoxValue+thisText);

        textBox.focus();

        //add the event so it can be saved
        var event = new Event('shortcodeAdded');
    });

    $('#autosocial_add_metabox').on("click",".autosocial_override_feature_image_preview_clear", function(event){

        event.preventDefault();

        $(this).hide();
        $(this).prev().hide();

        $(this).parent().prev().prev().val('');


    });
    

    if( $('#autosocial_override_feature_image').length && $('#autosocial_override_feature_image').val().length > 0 ){
        $('.autosocial_override_feature_image_preview_clear').show();
        $('.autosocial_override_feature_image_preview').show();
    }
    
    
    
    //show the event section if checked
    function autosocial_show_event_section(){

        if($('#autosocial_google_my_business_make_post_event').is(':checked')){
            $('.google_my_business_event_content').slideDown('fast');
        } else {
            $('.google_my_business_event_content').slideUp('fast');
        }      

    }
    //run initially
    autosocial_show_event_section();

    //run on change
    $('#autosocial_add_metabox').on('change','#autosocial_google_my_business_make_post_event',function(event) {
        event.preventDefault();
        autosocial_show_event_section();
    });    
    
    
    if($('.autosocial-timedatepicker').length){
        $('.autosocial-timedatepicker').datetimepicker({
            format: 'MMM D, YYYY HH:mm',
            icons: {
                time: 'fa fa-clock-o',
                date: 'fa fa-calendar',
                up: 'fa fa-plus',
                down: 'fa fa-minus',
                next: 'fa fa-chevron-right',
                previous: 'fa fa-chevron-left'
            }
        });
    
        //we are going to minimise the risk of conflicts with bootstrap date time picker and jquery ui
        $(".autosocial-jquery-ui-timedatepicker" ).datetimepicker({
            dateFormat: 'M d, yy',
            timeFormat: 'HH:mm',
        });
    }
    

    

 
    //create custom trigger for list items
    $('#autosocial_add_metabox').on('click','.autosocial-shortcodes li, .profile-activation li',function(event) {

        $(this).parent().next().trigger('listClick');

    });   
    

     //save meta data on change
     $('#autosocial_add_metabox').on('change dp.change listClick imageChange','input, textarea, select',function(event) {

        var name = $(this).attr('name');
        var value = $(this).val();
        var postId = $('.autosocial-tabs-header').attr('data-post-id');

        //if item is a checkbox we want to make the value blank
        if( $(this).is(':checkbox') && !$(this).is(':checked') ){
            value = '';
        }

        var data = {
            'action': 'save_meta_on_change',
            'postId': postId,
            'name': name,
            'value': value,
        };

        // console.log(data);

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);

        });


    }); 




    //do share now
    $('body').on("click",".autosocial-share-now-button,.autosocial-share-now-link",function(event) {

        event.preventDefault();

        var postStatus = $(this).attr('data-status');
        var postId = $(this).attr('data-post-id');

        if(postStatus !== 'publish'){

            alertify
            .okBtn("Continue")
            .cancelBtn("Cancel")
            .confirm($(this).attr('data-warning'), function (ev) {
    
                continueShareNow(postId); 

            }, function(ev) {

                
            });

        } else {
            continueShareNow(postId);   
        }

        function continueShareNow(postId){

            // console.log(postId);

            alertify.log("Please wait while we attempt to share the post");

            var data = {
                'action': 'save_now_autosocial',
                'postId': postId,
                };
    
            jQuery.post(ajaxurl, data, function (response) {
    
                console.log(response);

                if(response == 'SUCCESS'){

                    alertify.success("Share Now action completed");

                }
    
            });



        }

    }); 

    $('body').on("click",".autosocial-share-history-link",function(event) {

        event.preventDefault();

        var postId = $(this).attr('data-post-id');

        alertify.log("Please wait while we get the share history of the post");

        //do ajax request to get data
        var data = {
            'action': 'get_share_history',
            'postId': postId,
        };

        jQuery.post(ajaxurl, data, function (response) {

            var heading = '<h3 class="share-history-heading">Share History</h3></br>';

            var spacing = '<div class="empty-space"></div>';

            alertify.alert(heading+response+spacing);

        });

        


    });    


    
    //save share message as new global template
    $('#autosocial_add_metabox').on('click','.save-global-template',function(event) {

        event.preventDefault();
        
        var network = $(this).attr('data-network');
        var message = $('#autosocial_'+network+'_default_share_message').val();
        // alertify.log("Please wait while we attempt to share the post");

        var data = {
            'action': 'save_share_message_global',
            'network': network,
            'message': message,
            };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);

            if(response == 'SUCCESS'){

                alertify.success("Share message updated");

            }

        });

    });

    //save share message as post type template
    $('#autosocial_add_metabox').on('click','.save-post-type-template',function(event) {

        event.preventDefault();

        var network = $(this).attr('data-network');
        var message = $('#autosocial_'+network+'_default_share_message').val();
        var post_type = $(this).attr('data-post-type');
        // alertify.log("Please wait while we attempt to share the post");

        var data = {
            'action': 'save_share_message_post_template',
            'network': network,
            'post_type': post_type,
            'message': message,
            };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);

            if(response == 'SUCCESS'){

                alertify.success("Share message updated");

            }

        });
        

    });
    
    










});



