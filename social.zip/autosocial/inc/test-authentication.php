<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Test connections
*/
function autosocial_test_connections(){

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    $network = sanitize_text_field($_POST['network']);
    $options = get_option('autosocial_settings');
    $authOptions = get_option('autosocial_auth_settings');


    if($network == 'Twitter'){

        $url = 'https://api.twitter.com/2/users/me';

        $response = wp_remote_get( $url , array(
            'headers' => array(
                'Authorization' => 'Bearer '.autosocial_get_access_token('Twitter'),
            ),
        ));
        
        $json_response = wp_remote_retrieve_response_code($response);

        if($json_response == 200) {
            echo 'SUCCESS';
        } else {
            echo 'ERROR';
        }

    }  
    
    

    if($network == 'Facebook'){
        $response = wp_remote_get( 'https://graph.facebook.com/v8.0/me?access_token='.$authOptions['facebook_access_token'] );

        $json_response = wp_remote_retrieve_response_code($response);

        if($json_response == 200) {
            echo 'SUCCESS';
        } else {
            echo 'ERROR';
        }
    }

    if($network == 'Google My Business'){
        
        $url = 'https://mybusinessaccountmanagement.googleapis.com/v1/accounts?pageSize=100';

        $response = wp_remote_get( $url , array(
            'headers' => array(
                'Authorization' => 'Bearer '.autosocial_get_access_token('Google My Business'),
            ),
        ));
        

        $json_response = wp_remote_retrieve_response_code($response);

        if($json_response == 200) {
            echo 'SUCCESS';
        } else {
            echo 'ERROR';
        }
    }

    if($network == 'LinkedIn'){
        

        $profileUrl = 'https://api.linkedin.com/v2/me?projection=(id,firstName,lastName,vanityName,profilePicture(displayImage~:playableStreams))';

        $response = wp_remote_get($profileUrl, array(
            'headers' => array(
                'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                'X-RestLi-Protocol-Version' => '2.0.0',
            ),
        ));

        $json_response = wp_remote_retrieve_response_code($response);

        if($json_response == 200) {
            echo 'SUCCESS';
        } else {
            echo 'ERROR';
        }
    }

    if($network == 'Pinterest'){
        
        $profileUrl = 'https://api.pinterest.com/v5/user_account/';

        $response = wp_remote_get($profileUrl, array(
            'headers' => array(
                'Authorization' => 'Bearer '.$authOptions['pinterest_access_token'],
            ),
        ));

        $json_response = wp_remote_retrieve_response_code($response);

        if($json_response == 200) {
            echo 'SUCCESS';
        } else {
            echo 'ERROR';
        }

    }
    
    wp_die();

}
add_action( 'wp_ajax_test_connections', 'autosocial_test_connections' );
?>