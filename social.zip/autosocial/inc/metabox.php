<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Add metabox to post
*/
add_action( 'add_meta_boxes', 'autosocial_add_metabox' );
function autosocial_add_metabox($postType){

    $options = get_option( 'autosocial_settings' );

    if(is_array($options) && array_key_exists('autosocial_custom_post_type_and_page_enable',$options) ){
        $explodedPostTypes = explode(",",$options['autosocial_custom_post_type_and_page_enable']);

        $explodedPostTypes = array_map('strtolower', $explodedPostTypes);
        
        if(in_array($postType,$explodedPostTypes)) {
            add_meta_box( 'autosocial_add_metabox',__('AutoSocial', 'autosocial' ), 'autosocial_build_meta_box',$postType,'normal','default');      
        }
    }

}

/**
* 
*
*
* Metabox
*/
function autosocial_build_meta_box($post) {
    //create noonce
    wp_nonce_field( basename( __FILE__ ), 'autosocial_build_meta_box_nonce' );   

    //dont share post

    if( !metadata_exists( 'post', $post->ID, 'autosocial_dont_share_post' ) ){

        $checked_status = apply_filters('autosocial_dont_share_default', false);

        if($checked_status){
            $checked = 'checked="checked"';
        } else {
            $checked = '';   
        }
    } else {
        $autosocial_dont_share_post = get_post_meta( $post->ID, 'autosocial_dont_share_post', true ); 
    
        if($autosocial_dont_share_post == 'yes'){
            $checked = 'checked="checked"';
        } else {
            $checked = '';    
        }
    }

    

    echo '<input type="checkbox" id="autosocial_dont_share_post" name="autosocial_dont_share_post" value="yes" '.$checked.'> '.__('Do not share this post on any network','autosocial');

    //lets create a container div that we will selectively hide
    echo '<div class="social-network-tab-section">';


        //have a setting here to override feature image
        $autosocial_override_feature_image = get_post_meta( $post->ID, 'autosocial_override_feature_image', true );

        if(!isset($autosocial_override_feature_image)){
            $autosocial_override_feature_image = '';
        }

        echo '<label class="feature-image-label">'.__('Override feature image','autosocial').'</label><input type="text" id="autosocial_override_feature_image" name="autosocial_override_feature_image" value="'.$autosocial_override_feature_image.'"> <button class="upload-custom-autosocial-image button-secondary"><i class="fa fa-picture-o" aria-hidden="true"></i> '.__('Upload/Select Image','autosocial').'</button>';



        //render the image
        echo '<div>';
            echo '<img src="'.$autosocial_override_feature_image.'" class="autosocial_override_feature_image_preview">';

            echo '<a class="autosocial_override_feature_image_preview_clear" href="#"><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>';
        echo '</div>';    

        //we need to figure out which networks are activated
        $activatedNetworks = array();

        // $networks = array('Facebook','Google My Business','Twitter','LinkedIn','Pinterest');
        $networks = array('Facebook','Google My Business','Twitter','LinkedIn','Instagram','Pinterest');
        $options = get_option('autosocial_settings');

        foreach($networks as $network){

            $networkTranslated = autosocial_translate_network_name($network);
            $networkProfileSelection = $options['autosocial_'.$networkTranslated.'_profile_selection'];

            if(strlen($networkProfileSelection)>0){
                array_push($activatedNetworks,$network);
            }
        }

        $shortcodes = array(
            '[POST_TITLE]' => 'standard',
            '[POST_LINK]' => 'standard',
            '[POST_EXCERPT]' => 'standard',
            '[POST_CONTENT]' => 'standard',
            '[POST_AUTHOR]' =>'standard' ,
            '[POST_TAGS]' => 'standard',
            '[POST_CATEGORIES]' => 'standard',
            '[WEBSITE_TITLE]' => 'standard'
        );

        //lets also add shortcodes for the post meta
        $custom_post_meta = get_post_meta($post->ID);

        $meta_to_exclude = array('autosocial','edit_lock','edit_last','elementor_controls','wp_page_template');

        // var_dump($custom_post_meta);

        foreach($custom_post_meta as $meta_key => $meta_value) {

            //check if metakey contains any exclusion words
            $exclude_post = false;

            foreach($meta_to_exclude as $exclusion_word){
                if (strpos($meta_key, $exclusion_word) !== false) {
                    $exclude_post = true;
                }
            }

            if($exclude_post == false) {

                $shortcodes['[POSTMETA_'.$meta_key.']'] = 'custom';

                // array_push($shortcodes,'[POSTMETA_'.$meta_key.']');
            } 
        }



        if(count($activatedNetworks)>0){
            echo '<ul data-post-id="'.$post->ID.'" class="autosocial-tabs-header">';
                foreach($activatedNetworks as $index => $network){

                    //get network translated
                    $networkTranslated = autosocial_translate_network_name($network);

                    if($index == 0){
                        $class = 'active';
                    } else {
                        $class = '';    
                    }

                    if($networkTranslated == 'google_my_business'){
                        $icon = 'google';
                    } else {
                        $icon = $networkTranslated;    
                    }

                    echo '<li class="'.$class.'" data="'.$networkTranslated.'"><i class="fa fa-'.$icon.'" aria-hidden="true"></i> '.$network.'</li>';
                } //end for each network

                //lets add our success tab
                echo '<li class="" data="log"><i class="fa fa-sticky-note" aria-hidden="true"></i> '.__('Log','autosocial').'</li>';


            echo '</ul>';

            echo '<ul class="autosocial-tabs-content">';
                foreach($activatedNetworks as $index => $network){

                    //get network translated
                    $networkTranslated = autosocial_translate_network_name($network);

                    if($index == 0){
                        $class = 'active';
                    } else {
                        $class = '';    
                    }

                    echo '<li class="'.$class.' '.$networkTranslated.'">';



                        //do select profiles
                        echo '<strong style="margin-bottom: 10px; display: block;">'.__('Select profiles','autosocial').'</strong>';

                        $profileSelectionSettingName = 'autosocial_'.$networkTranslated.'_default_profile_selection';


                        if( metadata_exists( 'post', $post->ID, $profileSelectionSettingName ) ){
                            $savedProfileSelection = get_post_meta( $post->ID,$profileSelectionSettingName, true );
                        } else {
                            $savedProfileSelection = $options[$profileSelectionSettingName];

                            if(!isset($savedProfileSelection)){
                                $savedProfileSelection = '';    
                            }
                            
                        }

                        //output profiles
                        echo autosocial_render_default_profile_selection($network,$savedProfileSelection);

                        echo '<input style="width: 100%; display: none;" type="text" id="'.$profileSelectionSettingName.'" name="'.$profileSelectionSettingName.'" value="'.$savedProfileSelection.'">';

                        //do custom message
                        echo '<strong style="margin-bottom: 10px; margin-top: 15px; display: block;">'.__('Customise share message','autosocial').'</strong>';

                        $customiseMessageSettingName = 'autosocial_'.$networkTranslated.'_default_share_message';

                        if( metadata_exists( 'post', $post->ID, $customiseMessageSettingName ) ){
                            $customiseMessageOutput = get_post_meta( $post->ID,$customiseMessageSettingName, true );
                        } else {

                            //if there's no share message saved for the post, first see if there's a share message for the post template, and then get the global message and then get nothing

                            $customiseMessageOutput = $options[$customiseMessageSettingName];

                            if(!isset($customiseMessageOutput)){
                                $customiseMessageOutput = '';    
                            }

                            $option_name = 'autosocial_share_message_custom_post_templates';
                            if(get_option($option_name)){

                                $current_option = get_option($option_name);

                                if(array_key_exists($post->post_type.'_'.$networkTranslated,$current_option)){
                                    $customiseMessageOutput = $current_option[$post->post_type.'_'.$networkTranslated]; 
                                }

                            }
                            
                        }

                        echo '<ul class="autosocial-shortcodes">';
                        foreach($shortcodes as $shortcode => $type){

                            if($networkTranslated == 'google_my_business' && $shortcode == '[POST_LINK]'){

                            } else {
                                echo '<li class="'.$type.'">'.$shortcode.'</li>';
                            }

                            
                        }
                        echo '</ul>';

                        echo '<textarea rows="4" style="width: 100%;" type="text" id="'.$customiseMessageSettingName.'" name="'.$customiseMessageSettingName.'">'.$customiseMessageOutput.'</textarea>';

                        //add save buttons
                        echo '<button data-network="'.$networkTranslated.'" class="save-global-template button-secondary"><i class="fa fa-check-square" aria-hidden="true"></i> '.__('Save message as global template','autosocial').'</button>';
                        echo '<button data-post-type="'.$post->post_type.'" data-network="'.$networkTranslated.'" class="save-post-type-template button-secondary"><i class="fa fa-check-square" aria-hidden="true"></i> '.__('Save message as post type template','autosocial').'</button>';

                        //now do google my business stuff only
                        if($networkTranslated == 'google_my_business'){



                            echo '<div style="margin-top: 15px;">';
                                //do action button
                                echo '<label>'.__('Custom button','autosocial').'</label>';

                                $values = array('LEARN_MORE' => 'Learn More','BOOK' => 'Book','ORDER' => 'Order','SHOP' => 'Shop','SIGN_UP' => 'Sign Up','CALL' => 'Call');

                                $selectedButtonOption = 'autosocial_google_my_business_default_action_type';

                                echo '<select name="'.$selectedButtonOption.'" id="'.$selectedButtonOption.'">';


                                if( metadata_exists( 'post', $post->ID, $selectedButtonOption ) ){
                                    $selectedButtonOptionValue = get_post_meta( $post->ID,$selectedButtonOption, true );
                                } else {
                                    $selectedButtonOptionValue = $options[$selectedButtonOption];

                                    if(!isset($selectedButtonOptionValue)){
                                        $selectedButtonOptionValue = '';    
                                    }
                                    
                                }

                                    foreach($values as $key => $value){

                                        if($key == $selectedButtonOptionValue){
                                            echo '<option value="'.$key.'" selected="selected">'.$value.'</option>'; 
                                        } else {
                                            echo '<option value="'.$key.'">'.$value.'</option>';     
                                        }

                                    }

                                echo '</select>';
                            echo '</div>';


                            echo '<div style="margin-top: 15px;">';
                                //do event
                                $makePostAnEventOptionName = 'autosocial_google_my_business_make_post_event';                                

                                $makePostAnEvent = get_post_meta( $post->ID, $makePostAnEventOptionName, true ); 
                                
                                if($makePostAnEvent == 'yes'){
                                    $checked = 'checked="checked"';
                                } else {
                                    $checked = '';    
                                }

                                echo '<input type="checkbox" id="'.$makePostAnEventOptionName.'" name="'.$makePostAnEventOptionName.'" value="yes" '.$checked.'> '.__('Make post an event','autosocial');
                            echo '</div>';

                            //do conditional content
                            echo '<div class="google_my_business_event_content" style="display: none; margin-top: 15px;">';

                                echo '<div style="margin-bottom: 15px;">';
                                    //do event title
                                    $eventTitleOptionName = 'autosocial_google_my_business_event_title'; 

                                    $eventTitle = get_post_meta( $post->ID, $eventTitleOptionName, true );

                                    if(!isset($eventTitle)){
                                        $eventTitle = '';
                                    }

                                    echo '<label>'.__('Event title','autosocial').'</label><input type="text" id="'.$eventTitleOptionName.'" name="'.$eventTitleOptionName.'" value="'.$eventTitle.'">';

                                echo '</div>';
                                echo '<div style="margin-bottom: 15px;">';

                                    //do event start date
                                    $eventStartDateOptionName = 'autosocial_google_my_business_event_start_date'; 

                                    $eventStartDate = get_post_meta( $post->ID, $eventStartDateOptionName, true );

                                    if(!isset($eventStartDate)){
                                        $eventStartDate = '';
                                    }

                                    //do class
                                    $options = get_option('autosocial_settings');

                                    if(isset($options['autosocial_enable_datetimepicker_no_conflict']) ){
                                       $date_time_picker_class = 'autosocial-jquery-ui-timedatepicker';
                                    } else {
                                        $date_time_picker_class = 'autosocial-timedatepicker';   
                                    }

                                    echo '<label>'.__('Event start','autosocial').'</label><input type="text" id="'.$eventStartDateOptionName.'" class="'.$date_time_picker_class.'" name="'.$eventStartDateOptionName.'" value="'.$eventStartDate.'">';

                                echo '</div>';
                                echo '<div>';
                                    //do event end date
                                    $eventEndDateOptionName = 'autosocial_google_my_business_event_end_date'; 

                                    $eventEndDate = get_post_meta( $post->ID, $eventEndDateOptionName, true );

                                    if(!isset($eventEndDate)){
                                        $eventEndDate = '';
                                    }

                                    echo '<label>'.__('Event end','autosocial').'</label><input type="text" id="'.$eventEndDateOptionName.'" class="'.$date_time_picker_class.'" name="'.$eventEndDateOptionName.'" value="'.$eventEndDate.'">';
                                echo '</div>';


                            echo '</div>';
                                
                        } //end just google


                        //do pinterest stuff
                        if($networkTranslated == 'pinterest'){

                            echo '<div style="margin-top: 15px; margin-bottom: 10px; margin-top: 15px; display: block;">';
                                //do board
                                echo '<label style="font-weight: bold;">'.__('Customise the pin title','autosocial').'</label>';

                                // $values = autosocial_get_pinterest_boards();

                                $pinterestTitle = 'autosocial_pinterest_default_share_title';

                                echo '<ul class="autosocial-shortcodes">';

                                    foreach($shortcodes as $shortcode => $type){

                                        echo '<li class="'.$type.'">'.$shortcode.'</li>';
                                    
                                    }
                                echo '</ul>';

                                if( metadata_exists( 'post', $post->ID, $pinterestTitle ) ){
                                    $customiseMessageOutput = get_post_meta( $post->ID,$pinterestTitle, true );
                                } else {
        
                                    //if there's no share message saved for the post, first see if there's a share message for the post template, and then get the global message and then get nothing
        
                                    $customiseMessageOutput = $options[$pinterestTitle];
        
                                    if(!isset($customiseMessageOutput)){
                                        $customiseMessageOutput = '';    
                                    }
                                    
                                }

                                echo '<textarea rows="4" style="width: 100%;" type="text" id="'.$pinterestTitle.'" name="'.$pinterestTitle.'">'.$customiseMessageOutput.'</textarea>';


                            echo '</div>';

                        } //end pinterest


                    
                    echo '</li>';
                } //end for each network

                //do log
                echo '<li class="log">';

                    //only show log if meta item exists
                    $metaName = 'autosocial_share_history';

                    

                    //check if meta exists
                    if(metadata_exists('post',$post->ID,$metaName)){

                        echo autosocial_share_history_table($post->ID);

                    }    


                echo '</li>';


            echo '</ul>';



        }

        
        


    echo '</div>';
    
    //do share now
    //get current post status
    $postStatus = get_post_status($post->ID);

    echo '<button class="autosocial-share-now-button button-primary" data-warning="'.htmlentities(__('We noticed that you are clicking the "Share Now" button but the post is not published. Did you know that when you first publish a post, and providing that the "Do not share this post on any network" checkbox is unchecked that AutoSocial will automatically send your post to your chosen social networks? By clicking "Share Now" you have to be careful that you do not accidently share the post twice - once now and once again when the post is published. Please click continue to share the post now.','autosocial')).'" data-status="'.$postStatus.'" data-post-id="'.$post->ID.'"><i class="fa fa-paper-plane" aria-hidden="true"></i> '.__('Share Now','autosocial').'</button>';

}    
/**
* 
*
*
* Function to save meta box information
*/
function autosocial_save_meta_box($post_id,$post){

    //check noonce
    if ( !isset( $_POST['autosocial_build_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['autosocial_build_meta_box_nonce'], basename( __FILE__ ) ) ){
        return;
    }

    //don't do anything for autosaves 
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){
		return;
	}

    //check if user has permission to edit posts otherwise don't do anything 
    if ( ! current_user_can( 'edit_post', $post_id ) ){
		return;
    }

    //solves issues on classic editor
    if( $post->post_status == 'inherit' ){
        return;
    }

    //get and set options

    //lets check if the do not share meta exists
    if( metadata_exists( 'post', $post_id, 'autosocial_dont_share_post' ) ){
        if ( isset( $_REQUEST['autosocial_dont_share_post'] ) ) {
            update_post_meta( $post_id, 'autosocial_dont_share_post', $_POST['autosocial_dont_share_post']);
        } else {
            update_post_meta( $post_id, 'autosocial_dont_share_post', 'no');
            // delete_post_meta( $post_id, 'autosocial_dont_share_post');
        }    
    } elseif($post->post_status == 'publish') {
        update_post_meta( $post_id, 'autosocial_dont_share_post', 'yes');    
    } else {
        // do nothing   
    }

    

    

    update_post_meta( $post_id, 'autosocial_override_feature_image', $_POST['autosocial_override_feature_image']);

    //do settings which are variables
    $activatedNetworks = array();
    $networks = array('Facebook','Google My Business','Twitter','LinkedIn','Pinterest','Instagram');
    $options = get_option('autosocial_settings');

    foreach($networks as $network){

        $networkTranslated = autosocial_translate_network_name($network);
        $networkProfileSelection = $options['autosocial_'.$networkTranslated.'_profile_selection'];

        if(strlen($networkProfileSelection)>0){
            array_push($activatedNetworks,$network);
        }
    }

    foreach($activatedNetworks as $network){

        $networkTranslated = autosocial_translate_network_name($network);

        update_post_meta( $post_id, 'autosocial_'.$networkTranslated.'_default_profile_selection', $_POST['autosocial_'.$networkTranslated.'_default_profile_selection']);

        update_post_meta( $post_id, 'autosocial_'.$networkTranslated.'_default_share_message', $_POST['autosocial_'.$networkTranslated.'_default_share_message']);  
        
        //google specific meta
        if($networkTranslated == 'google_my_business'){
            
            update_post_meta( $post_id, 'autosocial_google_my_business_default_action_type', $_POST['autosocial_google_my_business_default_action_type']);   

            if ( isset( $_REQUEST['autosocial_google_my_business_make_post_event'] ) ) {
                update_post_meta( $post_id, 'autosocial_google_my_business_make_post_event', $_POST['autosocial_google_my_business_make_post_event']); 
            } else {
                delete_post_meta( $post_id, 'autosocial_google_my_business_make_post_event');
            }  

            update_post_meta( $post_id, 'autosocial_google_my_business_event_title', $_POST['autosocial_google_my_business_event_title']); 

            update_post_meta( $post_id, 'autosocial_google_my_business_event_start_date', $_POST['autosocial_google_my_business_event_start_date']); 

            update_post_meta( $post_id, 'autosocial_google_my_business_event_end_date', $_POST['autosocial_google_my_business_event_end_date']); 
            
        }

        //do pinterest
        if($networkTranslated == 'pinterest'){

            update_post_meta( $post_id, 'autosocial_pinterest_default_share_title', $_POST['autosocial_pinterest_default_share_title']);   

        }
    }


}    
add_action( 'save_post', 'autosocial_save_meta_box',10,2);
/**
* 
*
*
* Function to save meta box information
*/
function autosocial_save_meta_on_change() { 

    $postId = sanitize_text_field($_POST['postId']);

	if ( ! current_user_can( 'edit_post', $postId ) ){
        wp_die();    
    }
    
    //get the variables
    $name = sanitize_text_field($_POST['name']);
    $value = sanitize_textarea_field($_POST['value']);

    //update the meta
    update_post_meta($postId,$name,$value);
    
    echo 'SUCCESS';
    wp_die();   

}
add_action( 'wp_ajax_save_meta_on_change', 'autosocial_save_meta_on_change' );





?>