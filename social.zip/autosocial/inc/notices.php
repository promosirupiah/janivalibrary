<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Display warning message that the access token is about to expire for Facebook and LinkedIn
*/
function autosocial_token_expiry_warning() {

    //wordpress time and date formats
    // $wordPressDateFormat = get_option( 'date_format' );
    // $wordPressTimeFormat = get_option( 'time_format' );

    //get options
    // $options = get_option('autosocial_settings');
    $authOptions = get_option('autosocial_auth_settings');

    $arrayOfNetworksToCheck = array();

    if(isset($authOptions['facebook_access_token_expiry']) && strlen($authOptions['facebook_access_token_expiry'])>0){
        $arrayOfNetworksToCheck['Facebook'] = $authOptions['facebook_access_token_expiry'];
    }

    if(isset($authOptions['linkedin_access_token_expiry']) && strlen($authOptions['linkedin_access_token_expiry'])>0){
        $arrayOfNetworksToCheck['LinkedIn'] = $authOptions['linkedin_access_token_expiry'];
    }


    //loop through each network
    foreach($arrayOfNetworksToCheck as $networkName => $expiry){


        //only do this if an expiry is set
        if(isset($expiry)){

            $networkNameTranslated = autosocial_translate_network_name($networkName);

            $daysBetweenTwoDates = floor(($expiry - current_time('timestamp')) / 86400);

            //do developer action so people can send out emails for example about expiry
            do_action('autosocial_authentication_expiry', $daysBetweenTwoDates, $networkName, $expiry);

            //sort out days plural
            if(abs($daysBetweenTwoDates) == 1){
                $dayPlural = 'day';
            } else {
                $dayPlural = 'days';    
            }

            //messages and heading variables
            $headingExpired = __('AutoSocial - '.$networkName.' authentication has expired','autosocial');
            $headingAboutToExpire = __('AutoSocial - '.$networkName.' needs to be reauthenticated','autosocial');

            $messageExpired = __('Your authentication with '.$networkName.' has expired '.abs($daysBetweenTwoDates).' '.$dayPlural.' ago and you will not be able to publish to '.$networkName.' successfully without reauthenticating.','autosocial');

            $messageAboutToExpire = __('Your authentication with '.$networkName.' is going to expire in '.$daysBetweenTwoDates.' '.$dayPlural.'. Please reauthenticate now to maintain the connection.','autosocial');

            $current_screen = get_current_screen();
            $current_screen = $current_screen->base;
            // var_dump($currentScreen);

            if($current_screen == 'toplevel_page_autosocial'){
                $url = '#tab-content';
            } else {
                $url = get_admin_url().'admin.php?page=autosocial&tab='.$networkNameTranslated.'#tab-content';
            }
            
            $button = '<a style="margin-bottom: 15px;" class="button-secondary" href="'.$url.'">'.__('Reauthenticate','autosocial').'</a>';

            //lets check if about to expire in 7 days
            if($daysBetweenTwoDates < 7 && $daysBetweenTwoDates >= 0){
                echo '<div class="notice notice-error autosocial-authentication-message">';
                    echo '<h3>'.$headingAboutToExpire.'</h3>';
                    echo '<p>'.$messageAboutToExpire.'</p>';
                    echo $button;
                echo '</div>';
            }

            //lets check if already expired
            if($daysBetweenTwoDates < 0){
                echo '<div class="notice notice-error autosocial-authentication-message">';
                    echo '<h3>'.$headingExpired.'</h3>';
                    echo '<p>'.$messageExpired.'</p>';
                    echo $button;
                echo '</div>';
            }

        }
    }
    
}
add_action( 'admin_notices', 'autosocial_token_expiry_warning' );
?>