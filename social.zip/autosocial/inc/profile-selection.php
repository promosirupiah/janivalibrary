<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Profile selection for options
*/
function autosocial_render_profile_selection($network){

    //start output
    $html = '';

    //get account data for the network
    $getAccountData = autosocial_account_data($network);

    if(get_option('autosocial_settings')){

        //get options
        $options = get_option('autosocial_settings');

        //translate name
        $networkNameTranslated = autosocial_translate_network_name($network);

        //selectedProfiles
        $optionName = 'autosocial_'.$networkNameTranslated.'_profile_selection';

        if (array_key_exists($optionName, $options)) {
            $selectedProfiles = $options[$optionName];
        } else {
            $selectedProfiles = '';    
        }    

        $selectedProfilesAsArray = explode(',',$selectedProfiles);

        //start output
        $html .= '<ul class="profile-activation" data="'.$networkNameTranslated.'">';

            foreach($getAccountData as $profile){

                if(in_array($profile['id'],$selectedProfilesAsArray)){
                    $listClass = 'selected';
                    $icon = 'fa-check-circle-o';
                } else {
                    $listClass = '';
                    $icon = 'fa-times-circle-o';
                }

                $html .= '<li class="profile-item '.$listClass.'" data="'.$profile['id'].'" data-option-name="'.$optionName.'">';

                    //display image if set
                    if(isset($profile['image']) && strlen($profile['image'])>0){
                        $html .= '<img src="'.$profile['image'].'" class="profile-image" height="42" width="42">';
                    }

                    //information
                    $html .= '<div class="profile-information">';
                        $html .= '<span class="profile-name">'.$profile['name'].'</span>';
                        $html .= '<span class="profile-type">'.ucfirst($profile['type']).'</span>'; 
                    $html .= '</div>';

                    //icon
                    $html .= '<i class="profile-icon fa '.$icon.'" aria-hidden="true"></i>';

                
                $html .= '</li>';   

            }

        $html .= '</ul>';

    }
    return $html;

    

}





/**
* 
*
*
* Default profile selection for options
*/
function autosocial_render_default_profile_selection($network,$selectionOfSelectionProfiles){

    $networkOriginal = $network;
    $network = str_replace('_snos','',$network);

    //get account data for the network
    $getAccountData = autosocial_account_data($network);

    $getAccountDataRefactored = array();

    //refactor account data so we can get things by id
    foreach($getAccountData as $profile){
        $getAccountDataRefactored[$profile['id']] = array('id'=>$profile['id'],'name'=>$profile['name'],'type'=>$profile['type'],'image'=>$profile['image']);    
    }  

    $html = '';

    if(get_option('autosocial_settings')){

        //get options
        $options = get_option('autosocial_settings');
        
        //network name translated
        $networkNameTranslated = autosocial_translate_network_name($network);

        //if the translated name has snos replace it with nothing - we do this to make the share now or schedule work
        $networkNameTranslatedOriginal = autosocial_translate_network_name($networkOriginal);



        $optionNameProfile = 'autosocial_'.$networkNameTranslated.'_profile_selection';

        if (array_key_exists($optionNameProfile, $options)) {
            $selectedProfiles = $options[$optionNameProfile];
        } else {
            $selectedProfiles = '';
        }    

        //selectedProfiles
        
        $selectedProfilesAsArray = explode(',',$selectedProfiles);

        //selectionOfSelection
        $optionName = 'autosocial_'.$networkNameTranslatedOriginal.'_default_profile_selection';
        $selectionOfSelectionProfilesAsArray = explode(',',$selectionOfSelectionProfiles);

        

        //start output
        $html .= '<ul class="profile-activation" data="'.$networkNameTranslated.'">';

            // var_dump($selectedProfilesAsArray);

            if(count(array_filter($selectedProfilesAsArray))>0){

                foreach($selectedProfilesAsArray as $profile){

                    if(!empty($getAccountDataRefactored[$profile])){
                        $profileId = $getAccountDataRefactored[$profile]['id'];
                        $profileName = $getAccountDataRefactored[$profile]['name'];
                        $profileType = $getAccountDataRefactored[$profile]['type'];
                        $profileImage = $getAccountDataRefactored[$profile]['image'];

                        if(strlen($profileName)>0){

                            if(in_array($profileId,$selectionOfSelectionProfilesAsArray)){
                                $listClass = 'selected';
                                $icon = 'fa-check-circle-o';
                            } else {
                                $listClass = '';
                                $icon = 'fa-times-circle-o';
                            }

                            $html .= '<li class="profile-item '.$listClass.'" data="'.$profileId.'" data-option-name="'.$optionName.'">';

                                //display image if set
                                if(isset($profileImage) && strlen($profileImage)>0 ){
                                    $html .= '<img src="'.$profileImage.'" class="profile-image" height="42" width="42">';
                                }

                                //information
                                $html .= '<div class="profile-information">';
                                    $html .= '<span class="profile-name">'.$profileName.'</span>';
                                    $html .= '<span class="profile-type">'.$profileType.'</span>'; 
                                $html .= '</div>';

                                //icon
                                $html .= '<i class="profile-icon fa '.$icon.'" aria-hidden="true"></i>';

                            
                            $html .= '</li>';   
                        }
                    }

                    
                }
            } else {
                $html .= '<li>'.__('Please activate at least one profile above.','autosocial').'</li>';    
            }


        $html .= '</ul>';
    }
    return $html;

}
?>