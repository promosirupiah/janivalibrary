<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
?>

<div id="autosocial-settings-page" class="wrap">
    <div id="poststuff" style="padding-top:0px;">


    
        <!-- main heading - we are going to keep this heading here as this is where WordPress outputs notices for some strange reason -->
        <h1></h1>


        <!-- do logo -->
        <img class="autosocial-logo" src="<?php echo plugins_url( 'images/AutoSocial-Logo.svg', __FILE__ ); ?>">





        <!-- start form -->
        <form id='autosocial_settings_form' action='options.php' method='post'>

            <?php

                // $getAuthOptions = get_option('autosocial_auth_settings');

                // echo autosocial_get_access_token('Google My Business');

      
                if(isset($_GET["tab"])){
                    $lastTab = $_GET["tab"];
                    //update the transient
                    set_transient('autosocial_tab_memory',$lastTab,DAY_IN_SECONDS*3 );
                } else {
                    //get last tab
                    $lastTab = get_transient('autosocial_tab_memory');
                }

                

                //do tabs
                $tabs = array(
                    
                    array('tab name'=>'Facebook', 'icon'=>'fa-facebook', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'Google My Business', 'icon'=>'fa-google', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'Twitter', 'icon'=>'fa-twitter', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'LinkedIn', 'icon'=>'fa-linkedin', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'Instagram', 'icon'=>'fa-instagram', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'Pinterest', 'icon'=>'fa-pinterest', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'General Settings', 'icon'=>'fa-wrench', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'Share Now or Schedule', 'icon'=>'fa-paper-plane', 'save settings'=>false,'active'=>true),
                    array('tab name'=>'Manage Posts', 'icon'=>'fa-cog', 'save settings'=>false,'active'=>true),
                    array('tab name'=>'Review Shortcode', 'icon'=>'fa-commenting-o', 'save settings'=>true,'active'=>true),
                    array('tab name'=>'Help', 'icon'=>'fa-question-circle', 'save settings'=>false,'active'=>true),
                    array('tab name'=>'Error Log', 'icon'=>'fa-sticky-note', 'save settings'=>false,'active'=>true)
                
                );

                echo '<div class="tab-heading-container">';

                    foreach($tabs as $tab){

                        //only output if active
                        if($tab['active'] == true){

                            if($lastTab !== false && $lastTab == autosocial_tab_name_translation($tab['tab name'])){
                                $class = 'active';
                            } else {
                                $class = '';    
                            }

                            echo '<a data="'.autosocial_tab_name_translation($tab['tab name']).'" class="tab-heading '.$class.'"><i class="fa '.$tab['icon'].'" aria-hidden="true"></i>'.$tab['tab name'].'</a>';
                        }
                    }

                echo '</div>';






                function autosocial_tab_name_translation($name){

                    $name = strtolower($name);
                    $name = str_replace(' ','_',$name);

                    return $name;

                }

                echo '<div id="tab-content" class="tab-content-container">';


                    

                    

                    //do tab content
                    foreach($tabs as $tab){

                        //don't show anything for Twitter if CURL is disabled
                        if($tab['tab name'] == 'Twitter' && !function_exists('curl_version')){
                            echo 'You need to have CURL installed on your server to use Twitter';
                        } else {
                            if($lastTab !== false && $lastTab == autosocial_tab_name_translation($tab['tab name'])){
                                $class = 'active';
                            } else {
                                $class = '';    
                            }
    
                            echo '<div class="tab-content '.autosocial_tab_name_translation($tab['tab name']).' '.$class.'">';
    
                                //do settings
                                
                                settings_fields(autosocial_tab_name_translation($tab['tab name']).'_autosocial');
                                do_settings_sections(autosocial_tab_name_translation($tab['tab name']).'_autosocial');
    
    
                                if(autosocial_tab_name_translation($tab['save settings']) == true){
                                    echo '<button type="submit" name="submit" id="submit" class="button button-primary save-settings-autosocial"><i class="fa fa-check-square" aria-hidden="true"></i> '.__('Save All Settings','autosocial').'</button>';
                                }
                                
    
                            echo '</div>';

                        }


                    }
                echo '</div>';


            ?>


        </form>





        <!-- ad -->
        <?php
        if (!function_exists('northernbeacheswebsites_information')) {
            require('nbw.php');  
        }
        echo northernbeacheswebsites_information();
        ?>



    </div>
</div>