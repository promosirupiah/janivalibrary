<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Check if it's necessary to add a column to the all pages listing
*/
function autosocial_column_required(){
    
    if(get_option('autosocial_settings')){
        //get options
        $options = get_option( 'autosocial_settings' );

        $explodedPostTypes = explode(",",$options['autosocial_custom_post_type_and_page_enable']);
        $explodedPostTypes = array_map('strtolower', $explodedPostTypes);

        if(in_array("page",$explodedPostTypes)){
            return true;    
        }
    }

    return false;

}
/**
* 
*
*
* Create new column on the posts page
*/
function autosocial_additional_posts_column($columns) {
    
    $options = get_option( 'autosocial_settings' );
    
    if(isset($options['autosocial_hide_posts_column'])){
        return $columns;
    } else {
        $new_columns = array(
        'autosocial' => __( 'AutoSocial', 'autosocial' ),
        );
        $filtered_columns = array_merge( $columns, $new_columns );
        return $filtered_columns;       
    }
}
add_filter('manage_posts_columns', 'autosocial_additional_posts_column');

if(autosocial_column_required()==true){
    add_filter('manage_page_posts_columns', 'autosocial_additional_posts_column');   
}
/**
* 
*
*
* Add content to the new posts page column
*/
function autosocial_column_data( $column ) {
    
    $options = get_option( 'autosocial_settings' );
    
    // Get the post object for this row so we can output relevant data
    global $post;
  
    // Check to see if $column matches our custom column names
    switch ( $column ) {

    case 'autosocial' :


        //show share history link if it exists
        if(metadata_exists('post', $post->ID, 'autosocial_share_history')) {
            echo '<a class="autosocial-share-history-link" href="#" data-post-id="'.$post->ID.'">'.__('Share History','autosocial').'</a>';
            echo '</br>';
        }    


        //show share now link
        echo '<a class="autosocial-share-now-link" href="#" data-status="publish" data-post-id="'.$post->ID.'">'.__('Share Now','autosocial').'</a>'; 

        // if(metadata_exists('post', $post->ID, 'autosocial_share_history')) {
        //     foreach(array_reverse(get_post_meta($post->ID, 'autosocial_share_history', true )) as $share){
        //             echo $share.'</br>';
        //     }   
        // } else {
        
        //     echo 'Not shared <a class="send-to-google" href="" data="'.$post->ID.'">Share now</a>';    
                    
        // //edit_post_link( 'share now', 'Not shared ', '', $post->ID, '');
            
            
        // } 



      break;    
    }
}
add_action( 'manage_posts_custom_column', 'autosocial_column_data' );
// if pages have been opted not to be shared hide the column on the all pages listing
if(autosocial_column_required()==true){
    add_action('manage_page_posts_custom_column', 'autosocial_column_data');
}
/**
* 
*
*
* gets share history
*/
function autosocial_get_share_history() { 

    $postId = sanitize_text_field($_POST['postId']);

    if ( ! current_user_can( 'edit_post', $postId ) ){
        return;
    }


    echo autosocial_share_history_table($postId);
    wp_die();   

}
add_action( 'wp_ajax_get_share_history', 'autosocial_get_share_history' );






?>