<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Function share post to social networks
*/
add_filter( 'autosocial_post_id_filter', 'autosocial_filter_posts_to_share', 10, 1);
function autosocial_filter_posts_to_share($post_id){
    return $post_id;
}


/**
* 
*
*
* Function share post to social networks
*/
function autosocial_post_transition($new_status, $old_status, $post) {

    //this code here is a specific fix for gutenberg which prevents the post being shared 2 times.
    if ( empty($_POST) && $old_status !== 'future') {
        return;
    }

    //check 1 - only send the post if the new post status is publish
    if ('publish' === $new_status) {

        //check 2 - we are going to see if the user has enabled to share the post as per the meta
        $dontSharePost = get_post_meta($post->ID, 'autosocial_dont_share_post', true );
           
        if($dontSharePost !== 'yes'){

            //check 3 - only share the post if the custom post type is enabled
            //get options
            $options = get_option( 'autosocial_settings' );
            $postTypeEnable = $options['autosocial_custom_post_type_and_page_enable'];
            $postTypeEnableExploded = explode(',',$postTypeEnable);
            $postTypeEnableExploded = array_map('strtolower', $postTypeEnableExploded);

            $postType = $post->post_type;

            if( in_array($postType,$postTypeEnableExploded) ){


                //now also check categories
                //get categories
                if(isset($options['autosocial_categories_disable'])){
                    $explodedCategories = explode(",",$options['autosocial_categories_disable']);

                    $thePostCategory = get_the_category($post->ID);
                    $thePostCategoryArray = array();

                    foreach($thePostCategory as $categoryName){
                        array_push($thePostCategoryArray,$categoryName->name);       
                    }

                    $thePostCategoryComparison = count(array_intersect($explodedCategories,$thePostCategoryArray));

                } else {
                    $thePostCategoryComparison = 0;
                }

                if($thePostCategoryComparison == 0){
                    //call common function

                    $post_id = apply_filters( 'autosocial_post_id_filter', $post->ID );

                    //before posting sleep for some seconds
                    //this can help with some servers and working with networks like LinkedIn
                    $sleep_time = apply_filters( 'autosocial_sleep_before_post', 0 );

                    sleep($sleep_time);

                    //check if delayed mode active
                    //delayed mode is similar to sleep time but makes it easier for non-developers as it is settings activated
                    if( isset($options['autosocial_activate_delayed_mode']) ){
                        //add post to option
                        $option_name = 'autosocial_delayed_mode_posts';

                        if( !get_option($option_name) ){
                            update_option($option_name, array());
                        }

                        $current_option = get_option($option_name);

                        //add the current post to the option
                        array_push($current_option,$post_id);

                        //now update the option
                        update_option($option_name, $current_option);

                    } else {
                        //we are all good to do the share
                        autosocial_send_post($post_id); 
                    }

                    
                }
                
                   
            }

        }

    } 
}
add_action( 'transition_post_status', 'autosocial_post_transition', 10, 3 );
/**
* 
*
*
* Here we are going to remove the action just above if set in the settings
*/
if(get_option( 'autosocial_settings' )){
    
    $options = get_option( 'autosocial_settings' );

    if( isset($options['autosocial_prevent_auto_sharing']) ){
        remove_action( 'transition_post_status','autosocial_post_transition',10 );
    }

}






/**
* 
*
*
* Common share function to actually do the calls
*/
function autosocial_send_post($postId) {

    //only continue if the id exists - this makes the filter work
    if(strlen($postId)>0){

        //get options
        $options = get_option( 'autosocial_settings' );

        //get the post link and do API call to bitly if necessary
        $postLink = get_permalink($postId);

        //check to see if bit.ly enabled
        if( isset($options['autosocial_enable_bit_ly']) ){
            $postLink = autosocial_get_bit_ly_link($postLink);      
        }

        //find out what social networks we need to post to by getting the meta
        $networks = array('Facebook'=>'autosocial_facebook_default_profile_selection','Google My Business'=>'autosocial_google_my_business_default_profile_selection','Twitter'=>'autosocial_twitter_default_profile_selection','LinkedIn'=>'autosocial_linkedin_default_profile_selection','Instagram'=>'autosocial_instagram_default_profile_selection','Pinterest'=>'autosocial_pinterest_default_profile_selection');

        //for each network get the meta, if the meta does not exist then get the default settings
        foreach($networks as $networkname => $networkSetting){

            //check if metadata exists
            if(metadata_exists('post', $postId, $networkSetting) ){
                $profileSelection = get_post_meta($postId,$networkSetting,true);
            } else {
                $profileSelection = $options[$networkSetting];
            }
            
            //if theres data continue
            if(strlen($profileSelection)>0){

                $profileSelectionExploded = explode(',',$profileSelection);

                //now loop through each post
                foreach($profileSelectionExploded as $networkToShareWith){
                    //calls function to share with network
                    //create filter to disable sharing to a particular profile
                    $share_to_profile = apply_filters('autosocial_profile_id_filter', true, $postId, $networkname, $networkToShareWith );

                    if($share_to_profile){
                        autosocial_share_to_network($postId,$networkname,$networkToShareWith,$postLink);
                    }
                }

            }

        }
    }

}
/**
* 
*
*
* Do bit.ly link
*/
function autosocial_get_bit_ly_link($longUrl){

    //get options
    $options = get_option( 'autosocial_settings' );

    if( isset($options['autosocial_bit_ly_access_token']) && strlen($options['autosocial_bit_ly_access_token'])>0 && isset($options['autosocial_bit_ly_group_guid']) && strlen($options['autosocial_bit_ly_group_guid'])>0 ){
        $group_guid = $options['autosocial_bit_ly_group_guid'];
        $access_token = $options['autosocial_bit_ly_access_token'];
    } else {
        $group_guid = 'Bb5jlgw1Kl3';
        $access_token = '28caa64047004b3d2ed8590ddc80b40a3e564aad';    
    }

    $json = json_encode(array(
        'group_guid' => $group_guid,
        'long_url' => $longUrl
    ));
    
    $response = wp_remote_post( 'https://api-ssl.bitly.com/v4/shorten', array(
        'headers' => array(
            'Authorization' => 'Bearer '.$access_token,
            'Content-Type' => 'application/json',
        ),
        'body' => $json,
    ));

    if(200 == wp_remote_retrieve_response_code( $response ) || 201 == wp_remote_retrieve_response_code( $response )){
        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);  return $decodedBody['link'];
    } else {
        return $longUrl;
    }

}  
/**
* 
*
*
* Gets the post feature image
*/
function autosocial_get_post_image($postId){


    //first check if there's an image override in the post meta
    $overrideImage = get_post_meta($postId,'autosocial_override_feature_image',true);

    if(isset($overrideImage) && strlen($overrideImage)>0){
        $postImage = $overrideImage; 
    } else {
        if(has_post_thumbnail($postId)){

            if(get_the_post_thumbnail_url($postId, 'full') !== false){
                $postImage = get_the_post_thumbnail_url($postId, 'full');
            } elseif(get_the_post_thumbnail_url($postId, 'large') !== false){
                $postImage = get_the_post_thumbnail_url($postId, 'large');
            } else {
                $postImage = get_the_post_thumbnail_url($postId);
            } 
    
        } else {
            $postImage = apply_filters( 'autosocial_default_image', 'NO IMAGE', $postId);
            
        }
    }

    $postImage = apply_filters( 'autosocial_change_image', $postImage, $postId);

    return $postImage;
}   
/**
* 
*
*
* Share to an individual network
*/
function autosocial_share_to_network($postId,$network,$profileId,$link){

    //get options
    $options = get_option( 'autosocial_settings' );
    $authOptions = get_option('autosocial_auth_settings');

    //get the share message by getting the meta
    $networks = array('Facebook'=>'autosocial_facebook_default_share_message','Google My Business'=>'autosocial_google_my_business_default_share_message','Twitter'=>'autosocial_twitter_default_share_message','LinkedIn'=>'autosocial_linkedin_default_share_message','Instagram'=>'autosocial_instagram_default_share_message','Pinterest'=>'autosocial_pinterest_default_share_message');

    //try and get the share message as set in the post meta/post settings
    //if it should not exist get the global template
    //and as a bonus if a post type template should exist for the post get that instead
    if(metadata_exists('post', $postId, $networks[$network]) ){
        $shareMessage = get_post_meta($postId,$networks[$network],true);

    } else {
        $shareMessage = $options[$networks[$network]];

        //try and get share message for post type if it exists and use this instead of the global share message
        $option_name = 'autosocial_share_message_custom_post_templates';
        if(get_option($option_name)){

            $current_option = get_option($option_name);

            $post_type = get_post_type($postId);

            $network_translated = autosocial_translate_network_name($network);

            if(array_key_exists($post_type.'_'.$network_translated,$current_option)){
                $shareMessage = $current_option[$post_type.'_'.$network_translated]; 
            }

        }


    }

    //process the share
    //preserve line breaks
    $shareMessage = nl2br($shareMessage);

    $shareMessage = strip_tags($shareMessage,'<p><br>'); //this extra parameter is the solution to fix line breaks

    $shareMessage = str_replace('<br />','',$shareMessage);

    //do shortcode replacement
    $shareMessage = autosocial_shortcode_replacement($postId,$shareMessage,$link);

    //limit the length
    $shareMessage = autosocial_shorten_message($shareMessage,$network);

    //enable filtering of the message
    $shareMessage = apply_filters( 'autosocial_message_filter',$shareMessage,$postId,$network,$profileId);

    //get the post image
    $postImage = autosocial_get_post_image($postId);

    //get the post type
    $postType = get_post_type( $postId );


    //before we do anything lets check that the profile sent to the function actually is in our account data
    //we need to do this because there could be previous data in the share profile input box which won't dissapear

    $getAccountData = autosocial_account_data($network);

    //get the access token for the profile
    foreach($getAccountData as $accountItem){
    
        if($accountItem['id'] == $profileId){
            $profileIdExists = true;
            $profileType = $accountItem['type'];

            //we are going to create this condition as some networks like twitter dont have an access token
            if( array_key_exists('access_token',$accountItem) ){
                $profileAccessToken = $accountItem['access_token'];
            }

            
        }
    }

    if(isset($profileIdExists)){





        //Facebook
        if($network == 'Facebook'){

            //only do something if the access token is available
            //this prevents sharing to profiles which may be stuck from old authentications
            if(isset($profileAccessToken)){
                //now share the post

                //check if share message contains a link and if enabled in settings
                if( isset($options['autosocial_dont_share_if_no_link']) && strpos($shareMessage, $link) === false){
                    $responseUrl = 'https://graph.facebook.com/v8.0/'.$profileId.'/feed?access_token='.$profileAccessToken.'&published=true';   
                } else {
                    $responseUrl = 'https://graph.facebook.com/v8.0/'.$profileId.'/feed?access_token='.$profileAccessToken.'&link='.$link.'&published=true';
                }


                $json = json_encode(array(
                    'message' => $shareMessage
                ));

                $response = wp_remote_post($responseUrl, array(
                    'headers' => array(
                        'Content-Type' => 'application/json; charset=utf-8',
                    ),
                    'body' => $json,
                ));



                $status = wp_remote_retrieve_response_code( $response );

                if( $status == 200 ){

                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                    $facebookFeedItemId = $decodedBody['id'];

                    $url = 'https://www.facebook.com/'.$facebookFeedItemId;

                    autosocial_save_to_post_log($postId,$network,$profileId,$url);  
                    do_action( 'autosocial_post_succeeded', $postId,$network,$profileId,$url );
                } else {
                    autosocial_save_to_general_log($postId,$network,$profileId,$status);      
                    do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );
                }
            }
        }



        //Instagram
        if($network == 'Instagram'){
            //only do something if the access token is available
            //this prevents sharing to profiles which may be stuck from old authentications
            if(isset($profileAccessToken)){
                //now share the post

        
                //we need to do 2 steps, first we need to create the image container, and then we need to publish it
                //add image to query if available
                if($postImage !== 'NO IMAGE'){

                    $response = wp_remote_get( $postImage );
                    $status = wp_remote_retrieve_response_code( $response );
                    
                    if($status == 200){
                        $headers = wp_remote_retrieve_headers( $response );

                        $accepted_file_types = array('image/jpeg','image/jpg');

                        if(in_array($headers['Content-Type'],$accepted_file_types) && $headers['Content-Length'] < 8000000 ){
                            //lets continue

                            $url = 'https://graph.facebook.com/'.$profileId.'/media?image_url='.$postImage.'&access_token='.$authOptions['facebook_access_token'].'&caption='.urlencode($shareMessage);

                            $response = wp_remote_post( $url );

                            $status = wp_remote_retrieve_response_code( $response );

                            if($status == 200){
                                //we can continue to step 2
                                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                                $id = $decodedBody['id'];

                                //now lets publish
                                $response = wp_remote_post( 'https://graph.facebook.com/'.$profileId.'/media_publish?access_token='.$authOptions['facebook_access_token'].'&creation_id='.$id );

                                $status = wp_remote_retrieve_response_code( $response );

                                if($status == 200){
                                    //do something
                                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                                    //this is all we get back
                                    $id = $decodedBody['id'];

                                    //we now need to get the public URL
                                    $response = wp_remote_get( 'https://graph.facebook.com/v12.0/'.$id.'?access_token='.$authOptions['facebook_access_token'].'&fields=permalink' );

                                    $status = wp_remote_retrieve_response_code( $response );

                                    if($status == 200){
                                        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                                        $url = $decodedBody['permalink'];

                                        autosocial_save_to_post_log($postId,$network,$profileId,$url);  
                                        do_action( 'autosocial_post_succeeded', $postId,$network,$profileId,$url );
                                    } else {
                                        //do some error for the publish URL
                                        autosocial_save_to_general_log($postId,$network,$profileId,$status); 
                                        do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );
                                    }


                                } else {
                                    //do some error for the publish
                                    autosocial_save_to_general_log($postId,$network,$profileId,$status);
                                    do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status ); 
                                }


                            } else {
                                //do some error for the container
                                autosocial_save_to_general_log($postId,$network,$profileId,$status); 
                                do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );
                            }
                        }

                    } //end image properties check


                } //end if image exists


            }
        }








        //Google My Business
        if($network == 'Google My Business'){

            //lets start with the button
            //have fallback option for custom button
            $postMetaButton = get_post_meta($postId, 'autosocial_google_my_business_default_action_type', true );

            if(strlen($postMetaButton) > 1) {
                $actionType = $postMetaButton;
            } elseif(isset($options['autosocial_google_my_business_default_action_type'])) {
                $actionType = $options['autosocial_google_my_business_default_action_type'];  
            } else {
                $actionType = 'LEARN_MORE';
            }

            if($postType == 'product' && isset($options['autosocial_enable_google_my_business_woocommerce_integration'])){
                $actionType = 'SHOP';          
            }


            //do topic type
            //check if the item is an event
            $eventEnabled = get_post_meta($postId, '_make_an_event', true );

            if($eventEnabled !== "yes"){
                //its a standard post
                $topicType = 'STANDARD';
            } else {
                $topicType = 'EVENT';    
            }

            if($postType == 'product' && isset($options['autosocial_enable_google_my_business_woocommerce_integration'])){
                $topicType = 'PRODUCT';          
            }

            if($postType == 'tribe_events' && isset($options['autosocial_enable_google_my_business_the_events_calendar_integration'])){
                $topicType = 'EVENT';          
            }




            // Create JSON body
            $json = array(
                'topicType' => $topicType,
                'languageCode' => substr(get_locale(), 0, 5),
                'summary' => $shareMessage,
            );

            //add link if its available
            if($actionType == 'CALL'){
                $json['callToAction'] = array(
                    'actionType' => $actionType,
                );      
            } else {
                if( isset($options['autosocial_dont_share_if_no_link']) && strpos($shareMessage, $link) === false){

                } else {
                    $json['callToAction'] = array(
                        'url' => $link,
                        'actionType' => $actionType,
                    ); 
                }  
            }  

            //add image to query if available
            if($postImage !== 'NO IMAGE'){

                //do additional check for dimensions
                $imageInfo = getimagesize($postImage);

                //get file size
                $headers = get_headers($postImage, true);
                
                if ( isset($headers['Content-Length']) ) {
                    $imageSize = intval($headers['Content-Length']);
                } else {
                    $imageSize = 10241;
                }

                //we also want to make an exception if allow_url_fopen is not set to on
                if( ($imageInfo[0] > 250 && $imageInfo[1] > 250 && $imageSize > 10240) || ( $imageSize > 10240 && strlen($imageInfo[0])<1 ) ){
                    $json['media'] = array(
                        'sourceUrl' => $postImage,
                        'mediaFormat' => 'PHOTO',
                    ); 
                }

            }   
            
            //check to see if event
            if($eventEnabled == "yes"){
                
                $eventTitle = get_post_meta($postId, 'autosocial_google_my_business_event_title', true );
                $eventStart = get_post_meta($postId, 'autosocial_google_my_business_event_start_date', true );
                $eventEnd = get_post_meta($postId, 'autosocial_google_my_business_event_end_date', true );
                

                $startDate = strtotime($eventStart);
                $endDate = strtotime($eventEnd);
                
                $startDateYear = date('Y',$startDate);
                $endDateYear = date('Y',$endDate);
                
                $startDateMonth = date('n',$startDate);
                $endDateMonth = date('n',$endDate);
                
                $startDateDay = date('j',$startDate);
                $endDateDay = date('j',$endDate);
                
                $startDateHours = date('G',$startDate);
                $endDateHours = date('G',$endDate);
                
                $startDateMinutes = intval(date('i',$startDate));
                $endDateMinutes = intval(date('i',$endDate));
                
                $json['event'] = array('title'=>$eventTitle,'schedule'=> array('startDate'=>array('year'=>$startDateYear,'month'=>$startDateMonth,'day'=>$startDateDay), 'startTime'=>array('hours'=>$startDateHours,'minutes'=>$startDateMinutes),'endDate'=>array('year'=>$endDateYear,'month'=>$endDateMonth,'day'=>$endDateDay), 'endTime'=>array('hours'=>$endDateHours,'minutes'=>$endDateMinutes)));     

            }

            if($postType == 'tribe_events' && isset($options['autosocial_enable_google_my_business_the_events_calendar_integration'])){

                $eventTitle = html_entity_decode(get_the_title($postId));
                $eventStart = get_post_meta($postId, '_EventStartDate', true );
                $eventEnd = get_post_meta($postId, '_EventEndDate', true );
                

                $startDate = strtotime($eventStart);
                $endDate = strtotime($eventEnd);
                
                $startDateYear = date('Y',$startDate);
                $endDateYear = date('Y',$endDate);
                
                $startDateMonth = date('n',$startDate);
                $endDateMonth = date('n',$endDate);
                
                $startDateDay = date('j',$startDate);
                $endDateDay = date('j',$endDate);
                
                $startDateHours = date('G',$startDate);
                $endDateHours = date('G',$endDate);
                
                $startDateMinutes = intval(date('i',$startDate));
                $endDateMinutes = intval(date('i',$endDate));
                
                $json['event'] = array('title'=>$eventTitle,'schedule'=> array('startDate'=>array('year'=>$startDateYear,'month'=>$startDateMonth,'day'=>$startDateDay), 'startTime'=>array('hours'=>$startDateHours,'minutes'=>$startDateMinutes),'endDate'=>array('year'=>$endDateYear,'month'=>$endDateMonth,'day'=>$endDateDay), 'endTime'=>array('hours'=>$endDateHours,'minutes'=>$endDateMinutes)));  
            }    


            //add additional product info
            if($postType == 'product' && isset($options['autosocial_enable_google_my_business_woocommerce_integration'])){

                $product = wc_get_product( $postId );
                $productPrice = $product->get_price();
                $woocommerceCurrency = get_option('woocommerce_currency');

                $json['product'] = array(
                    'upperPrice' => array(
                        'currencyCode' => $woocommerceCurrency,
                        'units' => $productPrice
                    ),
                    'productName' => html_entity_decode(get_the_title($postId)),
                    'lowerPrice' => array(
                        'currencyCode' => $woocommerceCurrency,
                        'units' => $productPrice
                    ),
                );  

            }



            //encode the array before sending
            $json = json_encode($json);

            $url = 'https://mybusiness.googleapis.com/v4/'.$profileId.'/localPosts';

            //do call
            $response = wp_remote_post( $url, array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                    'Content-Type' => 'application/json; charset=utf-8',
                ),
                'body' => $json,
            ));  

            
            $status = wp_remote_retrieve_response_code( $response );

            if( $status == 200 ){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                $url = $decodedBody['searchUrl'];

                autosocial_save_to_post_log($postId,$network,$profileId,$url);  
                do_action( 'autosocial_post_succeeded', $postId,$network,$profileId,$url );
            } else {
                autosocial_save_to_general_log($postId,$network,$profileId,$status);      
                do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );
            }

        }







        //Twitter
        if($network == 'Twitter'){


            //NOTE, right now, there's no media uplod in v2 API, so we can't do images

            // Create JSON body
            $json = json_encode( array(
                'text' => $shareMessage
            ));

            // {@see https://codex.wordpress.org/HTTP_API}
            $response = wp_remote_post( 'https://api.twitter.com/2/tweets', array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                    'Content-Type' => 'application/json; charset=utf-8',
                ),
                'body' => $json,
            ));

            $status = wp_remote_retrieve_response_code( $response );

            if($status == 200 || $status == 201){
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                $decodedBody = $decodedBody['data'];
                $tweet_id = $decodedBody['id'];

                $url = 'https://twitter.com/'.$profileId.'/status/'.$tweet_id;

                autosocial_save_to_post_log($postId,$network,$profileId,$url); 

                do_action( 'autosocial_post_succeeded', $postId,$network,$profileId,$url );

            } else {
                autosocial_save_to_general_log($postId,$network,$profileId,$status);      
                do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );  
            }

            
        }









        //LinkedIn
        if($network == 'LinkedIn'){

            if( isset($options['autosocial_dont_share_if_no_link']) && strpos($shareMessage, $link) === false){
                $sharing_a_link = false;
            } else {
                $sharing_a_link = true;
            } 

            $subject = html_entity_decode(get_the_title($postId));

            //do fix for profile id
            if (strpos($profileId, 'urn:li') === false) {
                $profileId = 'urn:li:person:'.$profileId;
            }

            // Create JSON body
            $json = array(
                'commentary' => $shareMessage,
                'author' => $profileId,
                'visibility' => 'PUBLIC',
                'distribution' => array(
                    'thirdPartyDistributionChannels' => array(
                    ),
                    'targetEntities' => array(

                    ),
                    'feedDistribution' => 'MAIN_FEED'
                ),
                'lifecycleState' => 'PUBLISHED',
                'isReshareDisabledByAuthor' => false
            );

            //if just link with no image
            if( $sharing_a_link && $postImage == 'NO IMAGE' ){
                $json['content'] = array(
                    'article' => array(
                        'source' => $link,
                        'title' => $subject,
                    ),
                );   
            }

            //do we need to upload an image?
            if( $postImage !== 'NO IMAGE' ){
                //lets get the upload URL
                // Create JSON body
                $json_body = array(
                    'initializeUploadRequest' => array(
                        'owner' => $profileId
                    ),
                );

                $response = wp_remote_post( 'https://api.linkedin.com/rest/images?action=initializeUpload', array(
                    'headers' => array(
                        'Linkedin-Version' => '202305',
                        'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                        'Content-Type' => 'application/json',
                    ),
                    'body' => json_encode($json_body),
                ));

                $status = wp_remote_retrieve_response_code( $response );

                if($status == 200){
                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                    $asset = $decodedBody['value']['image'];
                    $upload_url = $decodedBody['value']['uploadUrl'];

                    $c = curl_init();
                    curl_setopt($c, CURLOPT_URL, $postImage);
                    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
                    $image_data = curl_exec($c);
                    curl_close($c);

                    //get the content of the file
                    $get_file = wp_remote_get($postImage);
                    $header = wp_remote_retrieve_headers($get_file);
                    $header = (array) $header; //set it to array as it might be an object

                    $header_content = $header['Content-Type'];

                    //now we need to upload the file
                    $response = wp_remote_post( $upload_url, array(
                        'headers' => array(
                            'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                            'Content-Type' => $header_content,
                        ),
                        'body' => $image_data
                    ));

                    $status = wp_remote_retrieve_response_code( $response );

                    //if link and image
                    if( $postImage !== 'NO IMAGE' && $sharing_a_link ){ 
                        $json['content'] = array(
                            'article' => array(
                                'source' => $link,
                                'title' => $subject,
                                'thumbnail' => $asset,
                            ),
                        );   
                    }

                    //if just image
                    if( $postImage !== 'NO IMAGE' && ! $sharing_a_link ){ 
                        $json['content'] = array(
                            'media' => array(
                                // 'source' => $profileDataArray['link'],
                                'title' => $subject,
                                'id' => $asset,
                            ),
                        );   
                    }

                } //end status 200 check for image container

            } //end check if image upload is needed

            $response = wp_remote_post( 'https://api.linkedin.com/rest/posts', array(
                'headers' => array(
                    'Linkedin-Version' => '202305',
                    'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                    'Content-Type' => 'application/json',
                ),
                'body' => json_encode( $json ),
            ));

            $status = wp_remote_retrieve_response_code( $response );

            if( $status == 201 ||  $status == 200){

                $headers = wp_remote_retrieve_headers( $response );

                $activity = $headers['x-linkedin-id'];

                $url = 'https://www.linkedin.com/feed/update/'.$activity;

                autosocial_save_to_post_log($postId,$network,$profileId,$url);  
                do_action( 'autosocial_post_succeeded', $postId,$network,$profileId,$url );

            } else {
                autosocial_save_to_general_log($postId,$network,$profileId,$status);   
                do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );
            }


        } //end linkedin




        //do pinterest
        if($network == 'Pinterest'){


            //we need to do 2 steps, first we need to create the image container, and then we need to publish it
            //add image to query if available
            if($postImage !== 'NO IMAGE'){

                if( metadata_exists( 'post', $postId, 'autosocial_pinterest_default_share_title' ) ){
                    $title = get_post_meta( $postId,'autosocial_pinterest_default_share_title', true );
                } else {

                    //if there's no share message saved for the post, first see if there's a share message for the post template, and then get the global message and then get nothing
                    $title = $options['autosocial_pinterest_default_share_title'];
                    
                }

                //do shortcode replacement
                $title = autosocial_shortcode_replacement($postId,$title,$link);

                //enable filtering of the message
                $title = apply_filters( 'autosocial_pinterest_title_filter',$title,$postId,$profileId);


               // Create JSON body
                $json =  array(
                    'media_source' => array(
                        'url' => $postImage,
                        'source_type' => 'image_url'
                    ),
                    'title' => $title,
                    'description' => $shareMessage,
                    'board_id' => $profileId,
                    'link' => $link
                );

                $json = apply_filters('autosocial_pinterest_filter_data_before_send', $json, $postId, $profileId);

                $url = 'https://api.pinterest.com/v5/pins';
                
                $response = wp_remote_post( $url, array(
                    'headers' => array(
                        'Authorization' => 'Bearer '.autosocial_get_access_token('Pinterest'),
                        'Content-Type' => 'application/json; charset=utf-8',
                    ),
                    'body' => json_encode($json),
                ));

                $status = wp_remote_retrieve_response_code( $response );

                if( $status == 201 ||  $status == 200){

                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                    $url = 'https://www.pinterest.com.au/pin/'.$decodedBody['id'].'/';

                    autosocial_save_to_post_log($postId,$network,$profileId,$url); 
                    do_action( 'autosocial_post_succeeded', $postId,$network,$profileId,$url );

                } else {
                    autosocial_save_to_general_log($postId,$network,$profileId,$status); 
                    do_action( 'autosocial_post_failed', $postId,$network,$profileId,$status );
                }
            } //end if image exists
        }






    }

}      
/**
* 
*
*
* do shortcode replacement
*/
function autosocial_shortcode_replacement($postId,$message,$link){

    //declare variables
    //do standard variable replacement

    //we need to do some pre work for post tags
    $post_tags = get_the_tags( $postId );

    $refined_tags = array();

    if($post_tags){
        foreach($post_tags as $tag){
            $tag_name = $tag->name;
            $tag_name = str_replace(' ','',$tag_name);
            $tag_name = strtolower($tag_name);
            $tag_name = '#'.$tag_name;
            array_push($refined_tags, $tag_name);
        }
    }

    //we need to some pre work for post categories
    $post_categories = get_the_category( $postId );

    $refined_categories = array();

    if($post_categories){
        foreach($post_categories as $post_category){
            $category_name = $post_category->name;
            $category_name = str_replace(' ','',$category_name);
            $category_name = strtolower($category_name);
            $category_name = '#'.$category_name;
            array_push($refined_categories, $category_name);
        }
    }

    $variables = array(
        "[POST_TITLE]"       => html_entity_decode(get_the_title($postId)),
        "[POST_LINK]"        => $link,
        "[POST_EXCERPT]"     => get_the_excerpt($postId),
        "[POST_CONTENT]"     => preg_replace("~(?:\[/?)[^/\]]+/?\]~s", '',strip_tags(get_post_field('post_content',$postId))),
        "[POST_AUTHOR]"      => get_the_author_meta('display_name',get_post_field('post_author',$postId)),
        "[POST_TAGS]"        => implode(' ',$refined_tags),
        "[POST_CATEGORIES]"  => implode(' ',$refined_categories),
        "[WEBSITE_TITLE]"    => html_entity_decode(get_bloginfo('name'))                  
    );     
    
    $returnMessage = $message;

    foreach($variables as $key => $value){
        $returnMessage = str_replace($key,$value,$returnMessage); 
    }

    //do custom field replacement
    // [POSTMETA_
    $find = '[POSTMETA_';
    $last_position = 0;
    $matches = array();


    while (($last_position = strpos($returnMessage, $find, $last_position))!== false) {
        $matches[] = $last_position;
        $last_position = $last_position + strlen($find);
    }

    $replacement_array = array();

    foreach ($matches as $match) {
        
        $next_end_bracket = strpos( $returnMessage , ']', $match);
            
        $meta_name = substr ( $returnMessage ,$match + strlen($find), $next_end_bracket - ($match + strlen($find)) );
        
        $meta_value = get_post_meta($postId,$meta_name,true);

        $replacement_array['[POSTMETA_'.$meta_name.']'] = $meta_value;
        
        // //replace the string with shortcode
        // $returnMessage = str_replace('[POSTMETA_'.$meta_name.']',$meta_value,$returnMessage);
        
    }

    //loop through array
    foreach($replacement_array as $key => $value){
        $returnMessage = str_replace($key,$value,$returnMessage);    
    }

    //return value
    return $returnMessage;

}    
/**
* 
*
*
* shorten message
*/
function autosocial_shorten_message($shareMessage,$network){

    //lets do some extra passing for linkedin to work with it's littletext format
    if( $network == 'LinkedIn' ){
        $shareMessage = str_replace('[','\\[',$shareMessage);
        $shareMessage = str_replace('(','\\(',$shareMessage);
        $shareMessage = str_replace('{','\\{',$shareMessage);
        $shareMessage = str_replace(']','\\]',$shareMessage);
        $shareMessage = str_replace(')','\\)',$shareMessage);
        $shareMessage = str_replace('}','\\}',$shareMessage);
        $shareMessage = str_replace('@','\\@',$shareMessage);
        $shareMessage = str_replace('<','\\<',$shareMessage);
        $shareMessage = str_replace('>','\\>',$shareMessage);
    }


    $networksShareMessageLength = array('Facebook'=>19999,'Google My Business'=>1499,'Twitter'=>280,'LinkedIn'=>3000,'Pinterest'=>500,'Instagram'=>2200);

    $messageLength = $networksShareMessageLength[$network];

    $shareMessage = substr($shareMessage, 0, $messageLength); 

    return $shareMessage;

}    
/**
* 
*
*
* Performs share now
*/
function autosocial_save_now() { 

    $postId = sanitize_text_field($_POST['postId']);

    if ( ! current_user_can( 'edit_post', $postId ) ){
        return;
    }

    autosocial_send_post($postId);

    echo 'SUCCESS';
    wp_die();   

}
add_action( 'wp_ajax_save_now_autosocial', 'autosocial_save_now' );
?>