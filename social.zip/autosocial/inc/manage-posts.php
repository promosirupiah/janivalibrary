<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Performs some function
*/
function autosocial_post_data($profileId,$network) { 

    //lets first check whether there's existing data
    //if there is return it
    //otherwise fetch the data


    //get transient
    $transientName = 'autosocial_mp_'.$profileId;
    $getTransient = get_transient($transientName);

    //if transient doesn't exist or caching disabled do this
    if ($getTransient != false){
        
        //transient exists dont do anything but return data
        return $getTransient;
        
    } else { 

        //get options
        $options = get_option( 'autosocial_settings' );
        $authOptions = get_option('autosocial_auth_settings');

        $getAccountData = autosocial_account_data($network);

        //get the access token for the profile
        foreach($getAccountData as $accountItem){
            if($accountItem['id'] == $profileId){
                $profileIdExists = true;
                $profileType = $accountItem['type'];

                if( array_key_exists('access_token', $accountItem) ){
                    $profileAccessToken = $accountItem['access_token'];
                }
            }
        }

        
        //transient does not exist - check for posts we need to schedule
        if($network == 'Google My Business'){
            //get posts
            $response = wp_remote_get( 'https://mybusiness.googleapis.com/v4/'.$profileId.'/localPosts', array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                ),
            ));


            if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true); 

                if(!empty($decodedBody['localPosts'])){

                    $data = $decodedBody['localPosts'];

                } else {
                    return 'ERROR';    
                }    

          
            } else {
                return 'ERROR';
            }
        }
    
        if($network == 'Twitter'){

            //this is only available to paid users

            $response = wp_remote_get( 'https://api.twitter.com/2/users/'.$profileId.'/tweets?tweet.fields=created_at&max_results=100&media.fields=preview_image_url,url&exclude=retweets,replies&expansions=attachments.media_keys', array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                    'Content-Type' => 'text/plain; charset=utf-8',
                ),
            ));


            if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true); 

                if(!empty($decodedBody['data'])){

                    $data = $decodedBody['data'];

                } else {
                    return 'ERROR';    
                }    

          
            } else {
                return 'ERROR';
            } 

            // return 'ERROR';
        }
    
        if($network == 'Facebook'){

            $responseUrl = 'https://graph.facebook.com/v9.0/'.$profileId.'/posts?access_token='.$profileAccessToken.'&fields=id,message,attachments,picture,published,created_time';

            $response = wp_remote_get($responseUrl);

            if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true); 

                $data = $decodedBody['data'];

            } else {
                return 'ERROR';     
            }    

        }


        if($network == 'Instagram'){


            $responseUrl = 'https://graph.facebook.com/v12.0/'.$profileId.'/media?access_token='.$authOptions['facebook_access_token'].'&fields=id,caption,media_url,thumbnail_url,timestamp,permalink';

            $response = wp_remote_get($responseUrl);

            if ( 200 == wp_remote_retrieve_response_code( $response ) ) {

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true); 

                $data = $decodedBody['data'];

            } else {
                return 'ERROR';     
            }    

        }
    
        if($network == 'LinkedIn'){

            //only do something if it's a LinkedIn company because at the moment we don't have the r_member_social permission on the app :(
            if($profileType == 'organization'){
                //get access token
                $accessToken = $authOptions['linkedin_access_token'];

                $url = 'https://api.linkedin.com/rest/posts?author='.urlencode($profileId).'&q=author&count=100&sortBy=LAST_MODIFIED';

                $response = wp_remote_get($url, array(
                    'headers' => array(
                        'Linkedin-Version' => '202305',
                        'Authorization' => 'Bearer '.$accessToken,
                        'X-Restli-Protocol-Version' => '2.0.0',
                    ),
                ));

                $status = wp_remote_retrieve_response_code( $response );

                if($status == 200){
                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true); 

                    if(!empty($decodedBody['elements'])){
                        $data = $decodedBody['elements'];
                    } else {
                        return 'ERROR';    
                    }  
                } else {
                    return 'ERROR';    
                }

            }

        }


        if($network == 'Pinterest'){
            
            $url = 'https://api.pinterest.com/v5/boards/'.$profileId.'/pins?page_size=100'; //in the future we may need to loop through the pages if people have a lot of pins...

            $response = wp_remote_get($url, array(
                'headers' => array(
                                'Authorization' => 'Bearer '.autosocial_get_access_token('Pinterest'),
                            ),  
            ));

            $status = wp_remote_retrieve_response_code($response);

            if($status == 200) {

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true); 

                if(!empty($decodedBody['items'])){

                    $data = $decodedBody['items'];

                } else {
                    return 'ERROR';    
                }    

            } else {
                return 'ERROR';    
            }

        }

        //set the transient for 15 minutes
        set_transient($transientName,$data, DAY_IN_SECONDS*7);  

        return $data;
    
    } 
}
/**
* 
*
*
* Renders table
*/
function autosocial_render_post_data($profileId,$network) { 

    $getData = autosocial_post_data($profileId,$network);

    // var_dump($getData);


    $networkInfo = array(
        'Google My Business'=>array('edit'=>true,'delete'=>true),
        'Facebook'=>array('edit'=>true,'delete'=>true),
        'Twitter'=>array('edit'=>false,'delete'=>true),
        'LinkedIn'=>array('edit'=>false,'delete'=>true), //according to the documentation we should be able to edit shares but it doesn't actually seem to be working
        'Pinterest'=>array('edit'=>false,'delete'=>true),
        'Instagram'=>array('edit'=>false,'delete'=>false), //you can only view 
    );

    //start output
    $html = '';

    $html .= '<table class="autosocial-manage-posts-table">';

        $html .= '<colgroup>';

            if($network == 'Pinterest'){
                $html .= '<col class="medium-column">';
                $html .= '<col class="pinterest-large-column">';
                $html .= '<col class="pinterest-large-column">';
                $html .= '<col class="small-column">';
                $html .= '<col class="small-column">';
            } else {
                $html .= '<col class="medium-column">';
                $html .= '<col class="large-column">';
                $html .= '<col class="small-column">';
                $html .= '<col class="small-column">';
            }

            
        $html .= '</colgroup>';
        

        $html .= '<thead>';
            $html .= '<tr>';
                $html .= '<th>'.__('Date Posted','autosocial').'</th>'; 
                if($network == 'Pinterest'){
                    $html .= '<th>'.__('Title','autosocial').'</th>';      
                }
                $html .= '<th>'.__('Message','autosocial').'</th>';   
                $html .= '<th>'.__('Image','autosocial').'</th>';  
                $html .= '<th>'.__('Actions','autosocial').'</th>';     
            $html .= '</tr>';   
        $html .= '</thead>';
        $html .= '<tbody>';


        if(!empty($getData) && $getData !== 'ERROR'){
            //loop through the data
            foreach($getData as $post){

                //get common variables
                if($network == 'Google My Business'){
                    //get name
                    $id = $post['name'];



                    //get date posted
                    $timeZone = autosocial_get_timezone_string();
                    $date = new DateTime($post['createTime']); 
                    $date->setTimeZone(new DateTimeZone($timeZone));
                    $datePosted = $date->format(get_option('date_format').' '.get_option('time_format'));

                    // $datePosted = strtotime($post['createTime']);
                    // $datePosted = date(get_option('date_format').' '.get_option('time_format'),$datePosted);


                    //get message
                    $message = $post['summary'];
                    //get image url
                    $image = $post['media'][0]['googleUrl'];
                    //get link
                    $link = $post['searchUrl'];


                    //check if an event
                    if(array_key_exists('event',$post)){

                        $postEvent = $post['event'];
                        $postEventStartTime = $postEvent['schedule']['startTime'];
                        $postEventEndTime = $postEvent['schedule']['endTime'];

                        if(array_key_exists('hours',$postEventStartTime) && array_key_exists('minutes',$postEventStartTime)){
                            $startHours = $postEvent['schedule']['startTime']['hours'];
                            $startMinutes = $postEvent['schedule']['startTime']['minutes'];
                        } else {
                            $startHours = '00';
                            $startMinutes = '00';
                        }

                        if(array_key_exists('hours',$postEventEndTime) && array_key_exists('minutes',$postEventEndTime)){
                            $endHours = $postEvent['schedule']['endTime']['hours'];
                            $endMinutes = $postEvent['schedule']['endTime']['minutes'];
                        } else {
                            $endHours = '00';
                            $endMinutes = '00';
                        }

                        //get date info
                        $postEventStart = strtotime($postEvent['schedule']['startDate']['year'].'-'.$postEvent['schedule']['startDate']['month'].'-'.$postEvent['schedule']['startDate']['day'].' '.$startHours.':'.$startMinutes);
            
                        $postEventEnd = strtotime($postEvent['schedule']['endDate']['year'].'-'.$postEvent['schedule']['endDate']['month'].'-'.$postEvent['schedule']['endDate']['day'].' '.$endHours.':'.$endMinutes);


                        $postEventStart = date('F j, Y h:i',$postEventStart);
                        $postEventEnd = date('F j, Y h:i',$postEventEnd);
                        $postEventTitle = $post['event']['title'];

                  

                    } else {
                        $postEventStart = '';
                        $postEventEnd = '';
                        $postEventTitle = '';    
                    }

                    //check call to action
                    if(array_key_exists('callToAction',$post)){
                        $callToActionUrl = $post['callToAction']['url'];
                        $callToActionType = $post['callToAction']['actionType'];
                    } else {
                        $callToActionUrl = '';
                        $callToActionType = '';
                    }

                    //build edit string which is used in javascript to construct the form
                    $formString = 'textarea^^summary^^Message^^'.$message.' 
                        |||input^^url^^Link^^'.$callToActionUrl.'
                        |||select^^actionType^^Custom Button^^'.$callToActionType.' 
                        |||image^^image^^Image^^'.$image.'
                        |||checkbox^^topicType^^Make post an event^^'.$post['topicType'].'    
                        |||eventtitle^^eventTitle^^Event Title^^'.$postEventTitle.'
                        |||date^^eventStart^^Event Start^^'.$postEventStart.'
                        |||date^^eventEnd^^Event End^^'.$postEventEnd.'';

                }




                if($network == 'Facebook'){
                    //get id
                    $id = $post['id'];

                    //get date posted
                    $timeZone = autosocial_get_timezone_string();

                    // var_dump($timeZone);

                    $date = new DateTime($post['created_time']); 
                    $date->setTimeZone(new DateTimeZone($timeZone));
                    $datePosted = $date->format(get_option('date_format').' '.get_option('time_format'));

                    //get message
                    $message = $post['message'];

                    //image
                    $image = $post['picture'];
            
                    $link = 'https://www.facebook.com/'.$id;

                    //unfortunately the link can not be updated
                    // $formString = 'textarea^^summary^^Message^^'.$message.' 
                    //     |||input^^url^^Link^^'.$post['link'];
                    $formString = 'textarea^^summary^^Message^^'.$message;

                }  




                if($network == 'Instagram'){
                    //get id
                    $id = $post['id'];

                    //get date posted
                    $timeZone = autosocial_get_timezone_string();

                    // var_dump($timeZone);

                    $date = new DateTime($post['timestamp']); 
                    $date->setTimeZone(new DateTimeZone($timeZone));
                    $datePosted = $date->format(get_option('date_format').' '.get_option('time_format'));

                    //get message
                    $message = $post['caption'];

                    //image
                    $image = $post['media_url'];
            
                    $link = $post['permalink'];

                    //unfortunately the link can not be updated
                    // $formString = 'textarea^^summary^^Message^^'.$message.' 
                    //     |||input^^url^^Link^^'.$post['link'];
                    $formString = 'textarea^^summary^^Message^^'.$message;

                }  



                if($network == 'LinkedIn'){
                    //get id
                    $id = $post['id'];


                    //get date posted
                    $timeZone = autosocial_get_timezone_string();
                    $date = new DateTime(); 
                    $date->setTimestamp($post['createdAt']/1000);
                    $date->setTimeZone(new DateTimeZone($timeZone));
                    $datePosted = $date->format(get_option('date_format').' '.get_option('time_format'));

        
                    //get message
                    $message = $post['commentary'];
                    // $image = $post['content']['contentEntities'][0]['thumbnails'][0]['resolvedUrl'];
                    // $image = '';

                    $link = 'https://www.linkedin.com/feed/update/'.urlencode($post['id']);

                    $formString = 'textarea^^summary^^Message^^'.$message;

                }  
                
                if($network == 'Twitter'){
                    //get id
                    $id = $post['id'];

                    //get date posted
                    $timeZone = autosocial_get_timezone_string();
                    $date = new DateTime($post['created_at']); 
                    $date->setTimeZone(new DateTimeZone($timeZone));
                    $datePosted = $date->format(get_option('date_format').' '.get_option('time_format'));

                    //get message
                    $message = $post['text'];

                    // $image = $post->entities->media[0]->media_url_https;

                    // var_dump($image);

                    $link = 'https://twitter.com/'.$profileId.'/status/'.$id;

                } 


                if($network == 'Pinterest'){
                    //get id
                    $id = $post['id'];


                    //get date posted
                    $timeZone = autosocial_get_timezone_string();
                    $date = new DateTime($post['created_at']); 
                    $datePosted = $date->format(get_option('date_format').' '.get_option('time_format'));

        
                    //get message
                    $title = $post['title'];
                    $message = $post['description'];
                    $image = $post['media']['images']['150x150']['url'];

                    // var_dump(stripslashes(json_encode($post['media'])));

                    $link = 'https://www.pinterest.com.au/pin/'.$id.'/';

                    // $formString = 'textarea^^summary^^Message^^'.$message;

                }  


                $html .= '<tr data="'.$id.'">';
                    //do date
                    $html .= '<td class="datePosted">'.$datePosted.'</td>';   
                    //do title (for pinterest only)
                    if($network == 'Pinterest'){
                        $html .= '<td class="title">'.$title.'</td>'; 
                    }

                    //do message 
                    $html .= '<td class="message">'.$message.'</td>';   
                    //do image
                    $html .= '<td class="image">';

                        if(isset($image)){
                            $html .= '<a target="_blank" href="'.$image.'"><img style="object-fit: cover;" src="'.$image.'" height="50" width="50"></a>';
                        }

                    $html .= '</td>';
                    
                    
                    //do action items
                    $html .= '<td class="actionItems">';
                        
                        
                        $html .= '<a target="_blank" href="'.$link.'"><i title="View Post" class="manage-post-view fa fa-link" aria-hidden="true"></i></a>'; 

                        
                        

                        if($networkInfo[$network]['edit']==true){
                            $html .= '<i data="'.$id.'" data-network="'.$network.'" data-profile-id="'.$profileId.'" data-form="'.$formString.'" title="Edit Post" class="manage-post-edit fa fa-pencil" aria-hidden="true"></i>';       
                        }

                        if($networkInfo[$network]['delete']==true){
                            $html .= '<i data="'.$id.'" data-network="'.$network.'" data-profile-id="'.$profileId.'" title="Delete Post" class="manage-post-delete fa fa-trash-o" aria-hidden="true"></i>'; 
                        }

                    $html .= '</td>';    
                $html .= '</tr>'; 

            }
        }
        $html .= '</tbody>';
    $html .= '</table>';    

    // var_dump($getData);

    return $html;

}    
/**
* 
*
*
* Refresh account data
*/
function autosocial_refresh_manage_profile_table(){

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    $network = sanitize_text_field($_POST['network']);
    $profileId = sanitize_text_field($_POST['profileId']);

    //delete existing data
    $transientName = 'autosocial_mp_'.$profileId;

    //delete the transient
    delete_transient($transientName);

    echo autosocial_render_post_data($profileId,$network);
    wp_die();

}
add_action( 'wp_ajax_refresh_manage_profile_table', 'autosocial_refresh_manage_profile_table' );
/**
* 
*
*
* Delete post
*/
function autosocial_manage_post_delete_item(){

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    //get javascript variables
    $postId = sanitize_text_field($_POST['postId']);
    $network = sanitize_text_field($_POST['network']);
    $profileId = sanitize_text_field($_POST['profileId']);

    //get options
    $options = get_option( 'autosocial_settings' );
    $authOptions = get_option('autosocial_auth_settings');

    $getAccountData = autosocial_account_data($network);

    //get the access token for the profile
    foreach($getAccountData as $accountItem){
    
        if($accountItem['id'] == $profileId){
            // $profileIdExists = true;
            // $profileType = $accountItem['type'];
            $profileAccessToken = $accountItem['access_token'];
        }
    }



    if($network == 'Google My Business'){

        $response = wp_remote_request( 'https://mybusiness.googleapis.com/v4/'.$postId, array(
            'headers' => array(
                'Authorization' => 'Bearer '.autosocial_get_access_token($network),
            ),
            'method' => 'DELETE',
        ));

    }



    if($network == 'Twitter'){

        $response = wp_remote_request( 'https://api.twitter.com/2/tweets/'.$postId, array(
            'method' => 'DELETE',
            'headers' => array(
                'Authorization' => 'Bearer '.autosocial_get_access_token($network),
            ),
        ) );
    }




    if($network == 'Facebook'){
 

        $response = wp_remote_request('https://graph.facebook.com/v8.0/'.$postId.'?access_token='.$profileAccessToken, array(
            'method' => 'DELETE',
        ));

    }




    if($network == 'LinkedIn'){

        $url = 'https://api.linkedin.com/rest/posts/'.urlencode($postId);

        // var_dump($url);

        $response = wp_remote_request($url, array(
            'method' => 'DELETE',
            'headers' => array(
                'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                'X-Restli-Protocol-Version' => '2.0.0',
                'Linkedin-Version' => '202305',
            ), 
        )); 
        
        $status = wp_remote_retrieve_response_code($response);

        // var_dump($status);

    }



    if($network == 'Pinterest'){

        $url = 'https://api.pinterest.com/v5/pins/'.$postId;

        $response = wp_remote_request( $url, array(
            'headers' => array(
                'Authorization' => 'Bearer '.autosocial_get_access_token('Pinterest'),
            ),
            'method' => 'DELETE',
        ));

        $status = wp_remote_retrieve_response_code($response);

        //a success status is 204 here FYI


    }




    //lets delete the transient so upon refresh the post disapears without the user having to refresh the data
    $transientName = 'autosocial_mp_'.$profileId;

    //delete the transient
    delete_transient($transientName);

    echo 'SUCCESS';
    wp_die();

}
add_action( 'wp_ajax_manage_post_delete_item', 'autosocial_manage_post_delete_item' );
/**
* 
*
*
* Edit post
*/
function autosocial_manage_post_edit_item(){

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    $postId = sanitize_text_field($_POST['postId']);
    $network = sanitize_text_field($_POST['network']);
    $profileId = sanitize_text_field($_POST['profileId']);
    $data = sanitize_text_field($_POST['data']);
    $originalImage = sanitize_text_field($_POST['originalImage']);

    //get options
    $options = get_option( 'autosocial_settings' );
    $authOptions = get_option('autosocial_auth_settings');

    $getAccountData = autosocial_account_data($network);

    //get the access token for the profile
    foreach($getAccountData as $accountItem){
    
        if($accountItem['id'] == $profileId){
            // $profileIdExists = true;
            // $profileType = $accountItem['type'];
            $profileAccessToken = $accountItem['access_token'];
        }
    }

    //reformat the data so its nice
    $niceData = array();
    $dataExploded = explode('||||',$data);

    foreach($dataExploded as $field){
        if( strlen($field)>0 ){

            $fieldProperties = explode('^^^',$field);
            $fieldName = $fieldProperties[0];
            $fieldValue = $fieldProperties[1];
            
            $niceData[$fieldName] = $fieldValue;

        }
    }






    if($network == 'Google My Business'){

        //example of data
        // ||||summary^^^We are offering our new plugin AutoSocial at a special introductory price until the end of the year.||||url^^^https://northernbeacheswebsites.com.au/autosocial/||||actionType^^^LEARN MORE||||image^^^https://lh3.googleusercontent.com/eNuvxjo3sDHFMHrgpKscntzeZB1WUY6UD1MOsnQ8GlS1YoUgUfYyha4y4ZGlhz9rhBgqGkx36Q||||topicType^^^true||||eventTitle^^^Until 2019||||eventStart^^^Jan 1, 1970 12:00||||eventEnd^^^Dec 31, 2018 11:55

        

        //START PROCESSING FROM HERE MARTIN
        $postContent = $niceData['summary'];
        $postLink = $niceData['url'];
        $postAction = $niceData['actionType'];
        $originalPostImage = $originalImage;
        $postImage = $niceData['image'];
        $eventEnable = $niceData['topicType'];
        $eventName = $niceData['eventTitle'];
        $eventStart = $niceData['eventStart'];
        $eventEnd = $niceData['eventEnd'];
        
        // echo $postImage;

        if($eventEnable !== "true"){
            //its a standard post
            $topicType = 'STANDARD';
        } else {
            $topicType = 'EVENT';    
        }
        
        
        //do actual API call
        // Create JSON body
        $json = array(
            'topicType' => $topicType,
            'languageCode' => get_locale(),
            'summary' => $postContent,
        );
        
        
        //check if we need to add a link
        if(strlen($postLink) > 7 && $postLink !== 'https://'){
            $json['callToAction'] = array(
                'url' => $postLink,
                'actionType' => $postAction,
            );      
        }
        

        //check to see if there's a post thumbnail
        if( strlen($postImage) > 7 && strpos($postImage, 'http') !== false){

            //do additional check for dimensions
            $imageInfo = getimagesize($postImage);

            //get file size
            $headers = get_headers($postImage, true);
            
            if ( isset($headers['Content-Length']) ) {
                $imageSize = intval($headers['Content-Length']);
            } else {
                $imageSize = 10241;
            }


            if( $imageInfo[0] > 250 && $imageInfo[1] > 250 && $imageSize > 10240 ){


                $json['media'] = array(
                    'sourceUrl' => $postImage,
                    'mediaFormat' => 'PHOTO',
                ); 

                //if the original image is a good image lets put that into the update make
                if (strpos($originalPostImage, 'googleusercontent.com') !== false) {
                    
                    //get the image identifier
                    $lastSlashInString = strrpos($originalPostImage, "/")+1;
                    $imageIdentifier = substr($originalPostImage,$lastSlashInString);
                    
                    $imageUpdateMask = ',media.'.$imageIdentifier.'.mediaFormat,media.'.$imageIdentifier.'.googleUrl';
                    
                } else {
                    $imageUpdateMask = ',media.a.mediaFormat,media.a.googleUrl';    
                }


            }
  
        } else {
            $imageUpdateMask = '';     
        }
        
        //echo $imageUpdateMask;

        
        //check to see if event
        if($eventEnable == "true"){

            $startDate = strtotime($eventStart);
            $endDate = strtotime($eventEnd);
            
            $startDateYear = date('Y',$startDate);
            $endDateYear = date('Y',$endDate);
            
            $startDateMonth = date('n',$startDate);
            $endDateMonth = date('n',$endDate);
            
            $startDateDay = date('j',$startDate);
            $endDateDay = date('j',$endDate);
            
            $startDateHours = date('G',$startDate);
            $endDateHours = date('G',$endDate);
            
            $startDateMinutes = intval(date('i',$startDate));
            $endDateMinutes = intval(date('i',$endDate));
            
            
            $json['event'] = array('title'=>$eventName,'schedule'=> array('startDate'=>array('year'=>$startDateYear,'month'=>$startDateMonth,'day'=>$startDateDay), 'startTime'=>array('hours'=>$startDateHours,'minutes'=>$startDateMinutes),'endDate'=>array('year'=>$endDateYear,'month'=>$endDateMonth,'day'=>$endDateDay), 'endTime'=>array('hours'=>$endDateHours,'minutes'=>$endDateMinutes)));   

        }
            

        //encode the array 
        $json = json_encode($json);
        
        // echo $json;

        $response = wp_remote_request( 'https://mybusiness.googleapis.com/v4/'.$postId.'?updateMask=languageCode,summary,callToAction.actionType,callToAction.url,event.title,event.schedule.startDate.year,event.schedule.startDate.month,event.schedule.startDate.day,event.schedule.startTime.hours,event.schedule.startTime.minutes'.$imageUpdateMask, array(
            'headers' => array(
                'Authorization' => 'Bearer '.autosocial_get_access_token($network),
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'method' => 'PATCH',
            'body' => $json,
        ));

        // echo wp_remote_retrieve_response_code( $response );
        // echo wp_remote_retrieve_response_message( $response );

        

    }

    // if($network == 'Twitter'){
        
    // }

    if($network == 'Facebook'){

        //example of data
        // ||||summary^^^We are offering our new plugin AutoSocial at a special introductory price until the end of the year.||||url^^^https://northernbeacheswebsites.com.au/autosocial/
        $postContent = $niceData['summary'];
        //unfortunately the link can not be updated
        // $postLink = $niceData['url'];
     
        // echo $postContent;
        // wp_die();

        $response = wp_remote_post('https://graph.facebook.com/v8.0/'.$postId.'?access_token='.$profileAccessToken.'&message='.$postContent);

    }




    // if($network == 'Instagram'){

    //     //example of data
    //     // ||||summary^^^We are offering our new plugin AutoSocial at a special introductory price until the end of the year.||||url^^^https://northernbeacheswebsites.com.au/autosocial/
    //     $postContent = $niceData['summary'];
    //     //unfortunately the link can not be updated
    //     // $postLink = $niceData['url'];
     
    //     // echo $postContent;
    //     // wp_die();

    //     $response = wp_remote_post('https://graph.facebook.com/v8.0/'.$postId.'?access_token='.$profileAccessToken.'&message='.$postContent);

    // }

    if($network == 'LinkedIn'){

        $postContent = $niceData['summary'];

        // $json = json_encode( array(
        //     'patch' => array(
        //         '$set' => array(
        //             'text' => array(
        //                 'annotations' => array(),
        //                 'text' => $postContent
        //             ),
        //         ),
        //     ),
        // ));

        $json = json_encode( array(
            'patch' => array(
                '$set' => array(
                    'commentary' => $postContent,
                ),
            ),
        ));

        $response = wp_remote_post( 'https://api.linkedin.com/rest/posts/'.$postId, array(
            'headers' => array(
                'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                'Content-Type' => 'application/json; charset=utf-8',
                'Linkedin-Version' => '202305',
                'X-Restli-Protocol-Version' => '2.0.0',
            ),
            'body' => $json,
        ));

    }


    if($network == 'Pinterest'){

        $postContent = $niceData['summary'];

        $url = 'https://api.pinterest.com/v1/pins/'.$postId.'/?note='.$postContent;

        $response = wp_remote_request( $url, array(
            'headers' => array(
                'Authorization' => 'Bearer '.$authOptions['pinterest_access_token'],
            ),
            'method' => 'PATCH',
        ));

        $status = wp_remote_retrieve_response_code($response);

    }



    //lets delete the transient so upon refresh the post disapears without the user having to refresh the data
    $transientName = 'autosocial_mp_'.$profileId;

    //delete the transient
    delete_transient($transientName);

    echo 'SUCCESS';
    wp_die();

}
add_action( 'wp_ajax_manage_post_edit_item', 'autosocial_manage_post_edit_item' );
?>