jQuery(document).ready(function ($) {

    //change tabs
    $('#autosocial-settings-page').on("click",".tab-heading",function(event) {
        event.preventDefault();

        //if the tab is already active do nothing
        if(!$(this).hasClass('active')){
            //remove all active classes
            $('.tab-heading').removeClass('active');
            //add class to clicked tab
            $(this).addClass('active');

            //hide all tab content
            $('.tab-content').slideUp().removeClass('active');

            var tab = $(this).attr('data');

            //show the current tab
            $('.tab-content-container > .'+tab).slideDown('fast').addClass('active');


            //now save the tab into memory
            var data = {
                'action': 'tab_memory',
                'tab': tab,
                };

            jQuery.post(ajaxurl, data, function (response) {
                // console.log(response);
            });
        }

    });    

    //show only active tab initially
    $('.tab-content').not('.active').hide();





    //save settings using ajax    
    $('#autosocial_settings_form').submit(function(event) {
        
        event.preventDefault();
        
        //lets refresh the page if we are on a social network
        if( $('.tab-content.active').find('.test-connection-button').length){
            var refreshPage = true;
        } else {
            var refreshPage = false;    
        }

        

        alertify.log("Please wait while we save the settings...");

        //do twitter presave routine
        twitterPresaveRoutine();
        
        //delete plugin update transient
        deletepluginupdatetransient();
        //tinyMCE.triggerSave();

        $(this).ajaxSubmit({
            success: function(){

                alertify.success("Settings saved");

                if(refreshPage == true){
                    window.location.href = getCurrentPageUrlAutoSocial();
                }

            }
        });

        return false; 

    });

    //make accordion work
    $('#autosocial-settings-page').on("click",".faq-item-question",function(event) {
        event.preventDefault();

        $(this).next().slideToggle(50);
        

    });  


    function deletepluginupdatetransient(){
        //_site_transient_update_plugins

        var data = {
            'action': 'delete_plugin_updates_transient',
        };

        jQuery.post(ajaxurl, data, function (response) {
            // console.log(response);
        });    
    }



    function twitterPresaveRoutine(){
        
        var settingValue = '';

        //loop through each Twitter connection detail
        $( ".twitter-account-detail-builder li" ).each(function( index ) {
            
            if(index == 0){
                var preValue = '';
            } else {
                preValue = '|||';    
            }

            //get the 5 settings
            var accountName = $(this).find('.twitterAccountName').val();
            var consumerKey = $(this).find('.twitterConsumerKey').val();
            var consumerSecret = $(this).find('.twitterconsumerSecret').val();
            var accessToken = $(this).find('.twitteraccessToken').val();
            var accessTokenSecret = $(this).find('.twitteraccessTokenSecret').val();




            //construct the setting
            settingValue += preValue+accountName+'^^'+consumerKey+'^^'+consumerSecret+'^^'+accessToken+'^^'+accessTokenSecret;
            
        });


        //put the setting value into the setting
        $('#autosocial_twitter_connection_details').val(settingValue);


    }
     



    //test connection
    $('#autosocial-settings-page').on("click",".test-connection-button",function(event) {

        event.preventDefault();

        var network = $(this).attr('data');

        alertify.log("The test has started for "+network);

        //now save the tab into memory
        var data = {
            'action': 'test_connections',
            'network': network,
            };

        jQuery.post(ajaxurl, data, function (response) {
            // console.log(response);

            if(response == 'SUCCESS'){
                alertify.success("Things are working fine for "+network);
            } else {
                alertify.error("The test was not successful, please double check the settings or try reauthenticating again for "+network);   
            }

        });


    });  

    //returns current page url minus any query strings
    function getCurrentPageUrlAutoSocial(){
        
        var currentPage = window.location.href;
   
        //the following 3 variables are used to create the redirect URL
        var pluginName = "autosocial";
        var findWhereParamatersStart = currentPage.indexOf(pluginName);
        var redirect = currentPage.substr(0,findWhereParamatersStart+pluginName.length);
        
        return redirect;
        
    }

    //function to get parameters from URL
    function getParameterByNameAutoSocial(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    //complete authentication for the networks
    var currentPage = window.location.href;
    if (currentPage.indexOf("code") !== -1) {

        var network = getParameterByNameAutoSocial('network');
        var code = getParameterByNameAutoSocial('code');

        //if network is null then lets get the active tab
        //we do this if people are using their own application because their redirect URL won't have a network defined
        //in heinsight we probably didnt need to add the network parameter to our redirect URL because our application could have done this as well
        //but at least when the redirect url comes from our own app we can be 1000% sure the network is correct rather than relying on tabs
        if(network == null){
            network = $('.tab-heading-container .tab-heading.active').text();
        }

        


        alertify.log("Please wait as we finish up the authentication process for  "+network);

        var data = {
            'action': 'save_access_token',
            'code': code,
            'network': network,
        };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);

            if(response == 'SUCCESS'){
                alertify.success("Authentication have been successfully completed for "+network+". We will now refresh the page.");

                window.location.href = getCurrentPageUrlAutoSocial();

            } else {

                alertify.alert("There was an error completing authentication for "+network+". Please try again.");

                //alertify.error("There was an error completing authentication for "+network+". Please try again.");
            }


        });    
        
    } //finish if page has network and code    


    //toggle the selection of profiles
    $('#autosocial-settings-page').on("click",".profile-item", function(event){

        event.preventDefault();
        
        var optionName = $(this).attr('data-option-name');

        //because we designed the function stupidly, we need to do this code to check what tab we are on to change where the change is inputted into
        if($('a.tab-heading.active').attr('data') == 'review_shortcode'){
            var setting = $('#'+optionName+'_review');
        } else {
            var setting = $('#'+optionName);
        }

        

        var valueOfSetting = setting.val();
        
        var profileId = $(this).attr('data');
        
        if($(this).hasClass('selected')){
            //we need to remove the item
            
            $(this).removeClass('selected');
            $(this).find('.profile-icon').removeClass('fa-check-circle-o').addClass('fa-times-circle-o');            
            
            var settingAsAnArray = valueOfSetting.split(',');
            var positionInArray = settingAsAnArray.indexOf(profileId);
            if (positionInArray > -1) {
                settingAsAnArray.splice(positionInArray, 1);
            }
            
            var newSettingValue = settingAsAnArray.join(",");
            
            
            setting.val(newSettingValue);
            
        } else {
            //we need to add the item

            
            $(this).addClass('selected');
            $(this).find('.profile-icon').removeClass('fa-times-circle-o').addClass('fa-check-circle-o');
            
            if(valueOfSetting == ''){
                setting.val(profileId);    
            } else {
                setting.val(valueOfSetting+','+profileId);      
            }
            
        }
        
   
    });


    //refresh aka delete profile and account info
    $('#autosocial-settings-page').on("click",".refresh-data",function(event) {

        event.preventDefault();

        var network = $(this).attr('data');

        alertify.log("Please wait while we refresh the data for "+network);

        //now save the tab into memory
        var data = {
            'action': 'refresh_account_data',
            'network': network,
            };

            jQuery.post(ajaxurl, data, function (response) {

                console.log(response);

                if(response == 'SUCCESS'){
                    alertify.success("Data has been refreshed for "+network);
                    //refresh the page
                    window.location.href = getCurrentPageUrlAutoSocial();
                } 

            });


    });

    //adds button text to text area
    $('.autosocial_append_buttons').click(function () {
        $(this).parent().next().children().val($(this).parent().next().children().val() + $(this).attr("value"));
        $(this).parent().next().children().focus();
    });



    //hides and then shows on click help tooltips
    $(".hidden").hide();
    $(".fa-info-circle").click(function (event) {
        event.preventDefault();
        $(this).next(".hidden").slideToggle();
    });

    //makes image upload field an image upload field
    $('body').on("click",".share-now-or-schedule-setting-upload, #share-now-or-schedule-setting-image",function(event) {
        event.preventDefault();

        var previousInput = $('#share-now-or-schedule-setting-image'); 
       
        var image = wp.media({ 
            title: 'Upload Image',
            // mutiple: true if you want to upload multiple files at once
            multiple: false
        }).open()
        .on('select', function(e){
            // This will return the selected image from the Media Uploader, the result is an object
            var uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            var image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            previousInput.val(image_url);

            //add image to preview
            $('.autosocial_image_preview').attr('src',image_url).show();
            $('.autosocial_image_preview_clear').show();
            
        });

    }); 

    //clear image
    $('body').on("click",".autosocial_image_preview_clear", function(event){

        event.preventDefault();

        $(this).hide();
        $(this).prev().hide();

        $(this).parent().prev().prev().val('');


    });


    //change tabs
    function autosocial_hide_and_show_tabs(){
        //hide tab content
        $('.share-now-or-schedule-tabs-content > li').not('.active').slideUp('fast');
    }   
    
    //run initially
    autosocial_hide_and_show_tabs();

    $('body').on("click",".share-now-or-schedule-tabs-header li",function(event) {
        event.preventDefault();

        //dont do anything if tab already active
        if(!$(this).hasClass('active')){
            //change active tab
            $('.share-now-or-schedule-tabs-header li').removeClass('active');
            $(this).addClass('active');

            //change tab content
            $('.share-now-or-schedule-tabs-content > li').slideUp('fast').removeClass('active');

            var clickedTab = $(this).attr('data');

            $('.share-now-or-schedule-tabs-content .'+clickedTab).slideDown('fast');



        }

    });  


    function urlify(text) {
        var urlRegex = /(https?:\/\/[^\s]+)/g;
        return text.replace(urlRegex, function(url) {
            return '12345678912345678912345'; //this just needs to be 23 characters long
        })
        // or alternatively
        // return text.replace(urlRegex, '<a href="$1">$1</a>')
    }


    //update counter
    $('body').on("keyup",".share-now-or-schedule-setting-share-message",function(event) {
        event.preventDefault();

        //get the length of the textarea
        var message = $(this).val();
        var network = $(this).attr('name');

        // if(network == 'autosocial_twitter_share_message'){
        //     var message = urlify(message);
        // }

        var length = message.length;

        //the minus 20 is arbitruary, it's just an amount to warn about getting close to the limit
        var maxLength = parseInt($(this).next().find('.max-length').text());


        //add the lenth to the counter
        $(this).next().find('.dynamic-counter').text(length);

        if(length >= maxLength){
            $(this).next().addClass('over-the-limit');   
        } else {
            $(this).next().removeClass('over-the-limit');       
        }



    });    



    //copy share message to all networks
    $('body').on("click",".copy-share-message",function(event) {
        event.preventDefault();
        var textAreaValue = $(this).parent().next().val();
        
        $( ".share-now-or-schedule-setting-share-message").each(function( index ) {
            $(this).val(textAreaValue);
        });

        alertify.success("Message copied to all networks");

    });  




    //toggle display of events section
    $('body').on('change','#share-now-or-schedule-setting-enable-event',function(event) {
        
        $('.share-now-or-schedule-section-event').slideToggle();

    });  


    //add date time picker
    $('.autosocial-timedatepicker').datetimepicker({
        format: 'MMM D, YYYY HH:mm',
        icons: {
            time: 'fa fa-clock-o',
            date: 'fa fa-calendar',
            up: 'fa fa-plus',
            down: 'fa fa-minus',
            next: 'fa fa-chevron-right',
            previous: 'fa fa-chevron-left'
        }
    });



    //lets do share now and schedule
    //lets do schedule first
    $('body').on("click",".schedule-share-now",function(event) {

        event.preventDefault();

        var scheduledDateInput = $('.share-now-or-schedule-setting-schedule-date-time');

        var scheduledDate = scheduledDateInput.val();
        
        if(scheduledDate.length < 1){
            //show alert
            // alertify.log('Please select a scheduled date/time');
            scheduledDateInput.addClass('input-error').parent().show();
            
        } else {
            shareNowOrSchedule('schedule');
        }

    });  

    $('body').on("click",".send-share-now",function(event) {

        event.preventDefault();

        shareNowOrSchedule('send');

    });  



    function shareNowOrSchedule(shareWhen){

        alertify.log("Please wait while we "+shareWhen+" your post");

        var optionsData = {};

        $( ".share-now-or-schedule-setting" ).each(function( index ) {
            
            var thisOptionName = $(this).attr('name');


            var thisValue = $(this).val();

            if($(this).is(':checkbox')){

                if($(this).is(':checked')){
                    thisValue = 'true';    
                } else {
                    thisValue = 'false';       
                }
            } 

            optionsData[thisOptionName] = thisValue;

        });

        optionsData = JSON.stringify(optionsData);
        console.log(optionsData);
        //remove non latin characters
        // optionsData = optionsData.replace(/[\u0250-\ue007]/g, '');

        // optionsData = btoa(optionsData);
        // console.log(optionsData);

        //send data via ajax
        var data = {
            'action': 'share_now_or_schedule',
            'data': optionsData,
            'shareWhen': shareWhen,
            };

        jQuery.post(ajaxurl, data, function (response) {
            console.log(response);
            if(response == 'SUCCESS'){

                if(shareWhen == 'schedule'){
                    var successMessage = 'Messaged added to the queue successfully';
                } else {
                    var successMessage = 'Messaged shared successfully';
                }
                alertify.success(successMessage);   
            } else {
                alertify.error("There's been some kind of error");      
            }
        });


    }


    //do reshare
    $('body').on("click",".reshare-item",function(event) {

        event.preventDefault();

        var shareId = $(this).attr('data');

       

        alertify
        .okBtn("Continue")
        .cancelBtn("Cancel")
        .confirm('Are you sure you want to reshare this content?', function (ev) {

            alertify.log("Please wait while we reshare the content");

            // console.log('hey');
            var data = {
                'action': 'reshare_item',
                'shareId': shareId,
                };
    
            jQuery.post(ajaxurl, data, function (response) {
                console.log(response);
                if(response == 'SUCCESS'){
    
                    
                    var successMessage = 'Messaged reshared successfully';
                    
                    alertify.success(successMessage); 

                } else {
                    alertify.error("There's been some kind of error");      
                }
            });



        });

    });


    //delete scheduled posts
    $('body').on("click",".delete-scheduled-item",function(event) {

        event.preventDefault();

        var thisRow = $(this).parent().parent();
        var shareId = $(this).attr('data');

        alertify
        .okBtn("Continue")
        .cancelBtn("Cancel")
        .confirm('Are you sure you want to delete this scheduled item?', function (ev) {

            alertify.log("Please wait while we delete the item");

            // console.log('hey');
            var data = {
                'action': 'delete_scheduled_item',
                'shareId': shareId,
                };
    
            jQuery.post(ajaxurl, data, function (response) {
                console.log(response);
                if(response == 'SUCCESS'){
                    
                    //hide the row
                    thisRow.slideUp();

                    var successMessage = 'Item deleted successfully';
                    
                    alertify.success(successMessage); 

                } else {
                    alertify.error("There's been some kind of error");      
                }
            });



        });

    });


    //edit scheduled posts
    $('body').on("click",".edit-scheduled-item",function(event) {

        event.preventDefault();


        var thisRow = $(this).parent().parent();
        var shareId = $(this).attr('data');
        var shareMessage = $(this).attr('data-message');
        var shareLink = $(this).attr('data-link');
        var shareImage = $(this).attr('data-image');
        var shareDateTime = $(this).attr('data-scheduled');

        if(shareMessage == undefined){
            shareMessage = '';
        }

        if(!thisRow.next().hasClass('schedule-post-edit-item')){
            var editData = '';
            editData += '<tr class="schedule-post-edit-item">';
                editData += '<td colspan="5">';

                    editData += '<label style="" class="edit-scheduled-item-label">Scheduled Date/Time</label></br>';
                    editData += '<input type="text" class="autosocial-timedatepicker edit-scheduled-item-input edit-scheduled-item-input-schedule" value="'+shareDateTime+'"></br>';

                    editData += '<label class="edit-scheduled-item-label">Link</label></br>';
                    editData += '<input type="text" class="edit-scheduled-item-input edit-scheduled-item-input-link" value="'+shareLink+'"></br>';

                    editData += '<label class="edit-scheduled-item-label">Image</label></br>';
                    editData += '<input type="text" class="edit-scheduled-item-input edit-scheduled-item-input-image" value="'+shareImage+'"><button class="button button-secondary edit-scheduled-item-input-image-upload"><i class="fa fa-picture-o" aria-hidden="true"></i> Upload/Select Image</button></br>';

                    editData += '<label class="edit-scheduled-item-label">Message</label></br>';
                    editData += '<textarea class="edit-scheduled-item-input edit-scheduled-item-input-message">'+shareMessage+'</textarea></br>';

                    editData += '<button data="'+shareId+'" style="margin-right: 5px;" class="submit-edit-item button button-primary"><i class="fa fa-check-square" aria-hidden="true"></i> Submit</button><button class="cancel-edit-item button button-primary"><i class="fa fa-ban" aria-hidden="true"></i> Cancel</button>';

                editData += '</td>';
            editData += '</tr>';

            thisRow.after(editData);
        } else {
            thisRow.next().remove();    
        }

        
        //lets add a row after the current one 

        

    });



    //edit scheduled posts continued
    $('body').on("click",".submit-edit-item",function(event) {

        event.preventDefault();



        alertify.log("Please wait while we edit the item");

        //get the variables
        var shareId = $(this).attr('data');
        var thisActualRow = $(this).parent().parent();
        var thisRow = thisActualRow.prev();
        var thisEditItem = thisRow.find('.edit-scheduled-item');
        var shareDateTimeEdited = $('.edit-scheduled-item-input-schedule').val();
        var shareLinkEdited = $('.edit-scheduled-item-input-link').val();
        var shareImageEdited = $('.edit-scheduled-item-input-image').val();
        var shareMessageEdited = $('.edit-scheduled-item-input-message').val();

        // console.log(shareDateTimeEdited);
        // console.log(shareLinkEdited);
        // console.log(shareImageEdited);
        // console.log(shareMessageEdited);
        // console.log(shareId);

        var data = {
            'action': 'edit_scheduled_item',
            'shareId': shareId,
            'shareDateTimeEdited': shareDateTimeEdited,
            'shareLinkEdited': shareLinkEdited,
            'shareImageEdited': shareImageEdited,
            'shareMessageEdited': shareMessageEdited,
            };

        jQuery.post(ajaxurl, data, function (response) {


            console.log(response);


            // if(response == 'SUCCESS'){
                
                //inject the values into the row
                thisRow.find('.shareDateTime').text(response);
                thisRow.find('.shareMessage').text(shareMessageEdited);

                //inject the values to 
                thisEditItem.attr('data-message',shareMessageEdited);
                thisEditItem.attr('data-link',shareLinkEdited);
                thisEditItem.attr('data-image',shareImageEdited);
                thisEditItem.attr('data-scheduled',shareDateTimeEdited);



                var successMessage = 'Item edited successfully';
                
                alertify.success(successMessage); 

                thisActualRow.remove();

            // } else {
            //     alertify.error("There's been some kind of error");      
            // }
        });
    });   
    
    //edit scheduled posts cancel
    $('body').on("click",".cancel-edit-item",function(event) {
        event.preventDefault();   
        $(this).parent().parent().remove();
    }); 
    
    //edit scheduled posts cancel
    $('body').on("click",".manage-post-edit-item-cancel",function(event) {
        event.preventDefault();   
        $(this).parent().parent().parent().remove();
    }); 

    //makes image upload field an image upload field
    $('body').on("click",".edit-scheduled-item-input-image-upload, .edit-scheduled-item-input-image",function(event) {
        event.preventDefault();

        var previousInput = $('.edit-scheduled-item-input-image'); 
       
        var image = wp.media({ 
            title: 'Upload Image',
            // mutiple: true if you want to upload multiple files at once
            multiple: false
        }).open()
        .on('select', function(e){
            // This will return the selected image from the Media Uploader, the result is an object
            var uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            var image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            previousInput.val(image_url);
            
        });

    });

    $('body').on("click",".manage-post-edit-input-image-upload, .manage-post-edit-input-image-upload-input",function(event) {
        event.preventDefault();

        var previousInput = $('.manage-post-edit-input-image-upload-input'); 
       
        var image = wp.media({ 
            title: 'Upload Image',
            // mutiple: true if you want to upload multiple files at once
            multiple: false
        }).open()
        .on('select', function(e){
            // This will return the selected image from the Media Uploader, the result is an object
            var uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            var image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            previousInput.val(image_url);
            
        });

    });

    //makes date picker work on popup
    $('body').on("focus",".edit-scheduled-item-input-schedule",function(event) {


        event.preventDefault();

        console.log('HEY');

         //add date time picker
        $('.autosocial-timedatepicker').datetimepicker({
            format: 'MMM D, YYYY HH:mm',
            icons: {
                time: 'fa fa-clock-o',
                date: 'fa fa-calendar',
                up: 'fa fa-plus',
                down: 'fa fa-minus',
                next: 'fa fa-chevron-right',
                previous: 'fa fa-chevron-left'
            }
        });


    });


    //change tabs
    function autosocial_hide_and_show_tabs_manage_posts(){
        //hide tab content
        $('.manage-posts-tabs-content > li').not('.active').slideUp('fast');
    }   
    
    //run initially
    autosocial_hide_and_show_tabs_manage_posts();

    $('body').on("click",".manage-posts-tabs-header li",function(event) {
        event.preventDefault();

        //dont do anything if tab already active
        if(!$(this).hasClass('active')){
            //change active tab
            $('.manage-posts-tabs-header li').removeClass('active');
            $(this).addClass('active');

            //change tab content
            $('.manage-posts-tabs-content > li').slideUp('fast').removeClass('active');

            var clickedTab = $(this).attr('data');

            $('.manage-posts-tabs-content .'+clickedTab).slideDown('fast');



        }

    }); 


    //refresh table data
    $('body').on("click",".manage-posts-refresh-data",function(event) {
        event.preventDefault();

        var network = $(this).attr('data-network');
        var profileId = $(this).attr('data-profile-id');
        var tableContainer = $(this).parent().next();

        alertify.log("Please wait as we refresh the data");

        var data = {
            'action': 'refresh_manage_profile_table',
            'profileId': profileId,
            'network': network,
        };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);
            
            //empty the container
            tableContainer.empty();
            tableContainer.append(response);

            //re-add readmore
            addReadMoreLinks();

            alertify.success("Data has been successfully refreshed");




        });    

        

    }); 


    //do read more
    if($('.autosocial-manage-posts-table .message').length){
        addReadMoreLinks();
    }

    
    function addReadMoreLinks(){

        var showChar = 100;  // How many characters are shown by default
        var ellipsestext = "...";
        var moretext = "Read more";
        var lesstext = "Read less";
        

        $('.autosocial-manage-posts-table .message').each(function() {
            var content = $(this).html();
    
            if(content.length > showChar) {
    
                var c = content.substr(0, showChar);
                var h = content.substr(showChar, content.length - showChar);
    
                var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';
    
                $(this).html(html);
            }
    
        });
    
        $(".morelink").click(function(){
            if($(this).hasClass("less")) {
                $(this).removeClass("less");
                $(this).html(moretext);
            } else {
                $(this).addClass("less");
                $(this).html(lesstext);
            }
            $(this).parent().prev().toggle();
            $(this).prev().toggle();
            return false;
        });
    }




    //delete post
    $('body').on("click",".manage-post-delete",function(event) {

        event.preventDefault();

        var thisRow = $(this).parent().parent();
        var postId = $(this).attr('data');
        var network = $(this).attr('data-network');
        var profileId = $(this).attr('data-profile-id');

        alertify
        .okBtn("Continue")
        .cancelBtn("Cancel")
        .confirm('Are you sure you want to delete this post?', function (ev) {

            alertify.log("Please wait while we delete the post");

            // console.log('hey');
            var data = {
                'action': 'manage_post_delete_item',
                'postId': postId,
                'network': network,
                'profileId': profileId,
                };
    
            jQuery.post(ajaxurl, data, function (response) {
                console.log(response);
                if(response == 'SUCCESS'){
                    
                    //hide the row
                    thisRow.slideUp();

                    var successMessage = 'Post deleted successfully';
                    
                    alertify.success(successMessage); 

                } else {
                    alertify.error("There's been some kind of error");      
                }
            });
        });

    });

    //edit managed posts
    $('body').on("click",".manage-post-edit",function(event) {

        event.preventDefault();

        var thisRow = $(this).parent().parent();

        var postId = $(this).attr('data');
        var network = $(this).attr('data-network');
        var profileId = $(this).attr('data-profile-id');
        var formData = $(this).attr('data-form');
        

        if(!thisRow.next().hasClass('manage-post-edit-item')){
            var editData = '';
            editData += '<tr class="manage-post-edit-item">';
                editData += '<td colspan="4">';

                    //split form data
                    var formDataFields = formData.split('|||');

                    //declare empty image
                    var originalImage = '';

                    for(var i=0; i<formDataFields.length; i++){

                        //split again
                        var fieldProperties = formDataFields[i].split('^^');

                        var fieldType = fieldProperties[0].trim();
                        var fieldname = fieldProperties[1].trim();
                        var fieldLabel = fieldProperties[2].trim();
                        var fieldValue = fieldProperties[3].trim();

                        //do label
                        if(fieldType == 'date' || fieldType == 'eventtitle'){
                            var fieldClass = 'manage-post-event-input';
                        } else {
                            var fieldClass = '';
                        }

                        editData += '<label class="manage-post-edit-label '+fieldClass+'" for="'+fieldname+'">'+fieldLabel+'</label>';

                        if(fieldType == 'textarea'){
                            editData += '<textarea class="manage-post-edit-input manage-post-edit-textarea" name="'+fieldname+'">'+fieldValue+'</textarea>';   
                        }

                        if(fieldType == 'input'){

                            editData += '<input type="text" class="manage-post-edit-input" value="'+fieldValue+'" name="'+fieldname+'">';   
                        }

                        if(fieldType == 'eventtitle'){

                            editData += '<input type="text" class="manage-post-event-input manage-post-edit-input" value="'+fieldValue+'" name="'+fieldname+'">';   
                        }

                        if(fieldType == 'select'){
                            var actionTypes = ['Learn More','Book','Order','Shop','Sign Up','Call'];

                            editData += '<select class="manage-post-edit-input" name="'+fieldname+'">';

                            for(var j=0; j<actionTypes.length; j++){

                                var buttonName = actionTypes[j];
                                var buttonNameUpperCase = buttonName.toUpperCase();
                                buttonNameUpperCase = buttonNameUpperCase.replace(/ /g,"_");

                                if(buttonNameUpperCase == fieldValue){
                                    editData += '<option selected="selected" value="'+buttonNameUpperCase+'">'+buttonName+'</option>';
                                } else {
                                    editData += '<option value="'+buttonNameUpperCase+'">'+buttonName+'</option>';
                                }

                            } 
                            
                            editData += '</select>';

                        }

                        if(fieldType == 'image'){
                            editData += '<input type="text" class="manage-post-edit-input manage-post-edit-input-image-upload-input" value="'+fieldValue+'" name="'+fieldname+'"><button style="margin-left: 5px;" class="button button-secondary manage-post-edit-input-image-upload"><i class="fa fa-picture-o" aria-hidden="true"></i> Upload/Select Image</button>';  
                            
                            originalImage = fieldValue;
                        }

                        if(fieldType == 'checkbox'){

                            if(fieldValue == 'EVENT'){
                                var checked = 'checked';    
                            } else {
                                var checked = '';      
                            }

                            editData += '<input type="checkbox" class="manage-post-edit-input manage-post-edit-input-checkbox" name="'+fieldname+'" '+checked+'>';   
                        }


                        if(fieldType == 'date'){
                            editData += '<input type="text" class="manage-post-event-input autosocial-timedatepicker manage-post-edit-input" value="'+fieldValue+'" name="'+fieldname+'">';   
                        }




                        // console.log(fieldProperties);
                    }


                    //do submit button
                    editData += '<div style="margin-bottom: 15px;"><button data="'+postId+'" data-network="'+network+'" data-profile-id="'+profileId+'" data-original-image="'+originalImage+'" style="margin-right: 5px;" class="manage-post-edit-item-proceed button button-primary"><i class="fa fa-check-square" aria-hidden="true"></i> Submit</button><button class="manage-post-edit-item-cancel button button-primary"><i class="fa fa-ban" aria-hidden="true"></i> Cancel</button></div>';

                editData += '</td>';
            editData += '</tr>';

            thisRow.after(editData);
            
            //reinitialise date picker
            $('.autosocial-timedatepicker').datetimepicker({
                format: 'MMM D, YYYY HH:mm',
                icons: {
                    time: 'fa fa-clock-o',
                    date: 'fa fa-calendar',
                    up: 'fa fa-plus',
                    down: 'fa fa-minus',
                    next: 'fa fa-chevron-right',
                    previous: 'fa fa-chevron-left'
                }
            });

            //hide event options if checkbox is unchecked
            autosocial_hide_event_options();

        } else {
            thisRow.next().remove();    
        }

        
        //lets add a row after the current one 

        

    });

    function autosocial_hide_event_options(){
        if( $('.manage-post-edit-input-checkbox').is(':checked') ){
            $('.manage-post-event-input').show();
        } else {
            $('.manage-post-event-input').hide();    
        }
    }

    $('body').on('change','.manage-post-edit-input-checkbox',function(event) {
        
        autosocial_hide_event_options();

    });  


    //update the post
    //edit scheduled posts continued
    $('body').on("click",".manage-post-edit-item-proceed",function(event) {

        event.preventDefault();

        alertify.log("Please wait while we edit the post");

        //get the variables
        var postId = $(this).attr('data');
        var network = $(this).attr('data-network');
        var profileId = $(this).attr('data-profile-id');
        var originalImage = $(this).attr('data-original-image');

        

        var thisActualRow = $(this).parent().parent().parent();
        var thisRow = thisActualRow.prev();

        //lets loop through the inputs and add the name value to a string
        var data = '';

        $( '.manage-post-edit-input' ).each(function( index ) {

            var fieldName = $(this).attr('name');
            var fieldValue = $(this).val();

            //if field is checkbox change the values
            if( $(this).is(':checkbox') ){

                if( $(this).is(':checked') ){
                    fieldValue = 'true';
                } else {
                    fieldValue = 'false';      
                }
            }

            //add field to string
            data += '||||'+fieldName+'^^^'+fieldValue;

        });

        // console.log(data);
    

        var data = {
            'action': 'manage_post_edit_item',
            'postId': postId,
            'network': network,
            'profileId': profileId,
            'data': data,
            'originalImage': originalImage,
            };

        jQuery.post(ajaxurl, data, function (response) {


            console.log(response);

            //remove editing row
            thisActualRow.remove();

            //show success message
            var successMessage = 'Post edited successfully. Please wait as we refresh the page.';
            alertify.success(successMessage); 

            //reload the page because injecting data back into the row is a little tricky
            location.reload();

        
        });
    });  





    //edit twitter connection details
    $('#autosocial-settings-page').on("click",".edit-twitter-connection-details",function(event) {

        event.preventDefault();
        $(this).parent().next().slideToggle('fast');


    });    
    
    //add twitter connection details
    $('#autosocial-settings-page').on("click",".add-twitter-connection-details",function(event) {

        event.preventDefault();
        
        var thisItem = $(this).parent().parent();

        thisItem.clone().appendTo( ".twitter-account-detail-builder" );

        //clear the inputs of the new item
        var newItem = thisItem.next();
        
        newItem.find('input').each(function() {
            $(this).val('');
        });

    });  

    //delete twitter connection details
    $('#autosocial-settings-page').on("click",".delete-twitter-connection-details",function(event) {

        event.preventDefault();
        var thisItem = $(this).parent().parent();

        alertify
        .okBtn("Continue")
        .cancelBtn("Cancel")
        .confirm('Are you sure you want to delete this item?', function (ev) {

            thisItem.remove();

        });

    });   
    

    //deletes all plugin settings
    //test connection
    $('#autosocial-settings-page').on("click","#delete-all-plugin-settings-autosocial",function(event) {

        event.preventDefault();

        alertify.log("Please wait while we delete the plugin settings.");

        //now save the tab into memory
        var data = {
            'action': 'delete_autosocial_plugin_settings',
        };

        jQuery.post(ajaxurl, data, function (response) {

            console.log(response);

            alertify.success("The plugin settings have been removed."); 
            location.reload();

        });
    }); 








    //copy shortcode to clipboard on click
    $(document).on("click", "#copy-shortcode", function (event) {
        event.preventDefault();
        
        /* Get the text field */
        var copyText = document.getElementById("autosocial_review_shortcode");

        /* Select the text field */
        copyText.select();

        /* Copy the text inside the text field */
        document.execCommand("copy");

        $('#copy-shortcode').html('<i class="fa fa-check-circle-o" aria-hidden="true"></i> Copied'); 
        
        setTimeout(function() {
            
            $('#copy-shortcode').html('<i class="fa fa-clipboard" aria-hidden="true"></i> Copy Shortcode');     
        }, 2000);
  

    });
    






    

    function autosocial_shortcode_construction(){

        //facebook
        var facebook = $('#autosocial_facebook_default_profile_selection_review').val();
        //google my business
        var googleMyBusiness = $('#autosocial_google_my_business_default_profile_selection_review').val();
        //type
        var type = $('#autosocial_review_type').val();
        //minimum stars
        var minimumStars = $('#autosocial_review_minimum_stars').val();
        //sort by
        var sortBy = $('#autosocial_review_sort_by').val();
        //sort order
        var sortOrder = $('#autosocial_review_sort_order').val();
        //amount of reviews
        var amountOfReviews = $('#autosocial_review_amount_of_reviews').val();
        //visible slides
        var visibleSlides = $('#autosocial_review_visible_slides').val();
        //slides to scroll
        var slidesScroll = $('#autosocial_review_slides_to_scroll').val();
        //autoplay
        if($('#autosocial_review_autoplay').is(':checked')){
            var autoplay = 'true';
        } else {
            var autoplay = 'false';
        }
        //autoplay speed
        var autoplaySpeed = $('#autosocial_review_autoplay_speed').val();

        //transition
        var transition = $('#autosocial_review_slide_transition').val();



        //read more
        if($('#autosocial_review_read_more').is(':checked')){
            var readMore = 'true';
        } else {
            var readMore = 'false';
        }

        //amount of words for read more
        var readMoreWords = $('#autosocial_review_read_more_words').val();

        //show stars
        if($('#autosocial_review_show_stars').is(':checked')){
            var showStars = 'true';
        } else {
            var showStars = 'false';
        }

        //show date
        if($('#autosocial_review_show_date').is(':checked')){
            var showDate = 'true';
        } else {
            var showDate = 'false';
        }
        //show quote
        if($('#autosocial_review_show_quote_symbols').is(':checked')){
            var showQuote = 'true';
        } else {
            var showQuote = 'false';
        }

        //show photos
        if($('#autosocial_review_show_photos').is(':checked')){
            var showPhotos = 'true';
        } else {
            var showPhotos = 'false';
        }

        //show social network icons
        if($('#autosocial_review_show_social_network_icons').is(':checked')){
            var showSocialNetworkIcons = 'true';
        } else {
            var showSocialNetworkIcons = 'false';
        }


        //text colour
        var textColor = $('#autosocial_review_text_colour').val();

        //structured data enable
        if($('#autosocial_review_enable_structured_data').is(':checked')){
            var structuredDataEnable = 'true';
        } else {
            var structuredDataEnable = 'false';
        }

        //structured data name
        var structuredDataName = $('#autosocial_review_structured_data_name').val();

        //structured data logo
        var structuredDataLogo = $('#autosocial_review_structured_data_logo').val();

        //put options into input field
        $('#autosocial_review_shortcode').val('[autosocial-reviews facebook="'+facebook+'" google-my-business="'+googleMyBusiness+'" type="'+type+'" minimum-stars="'+minimumStars+'" sort-by="'+sortBy+'" sort-order="'+sortOrder+'" review-amount="'+amountOfReviews+'" slides-page="'+visibleSlides+'" slides-scroll="'+slidesScroll+'" autoplay="'+autoplay+'" speed="'+autoplaySpeed+'" transition="'+transition+'" read-more="'+readMore+'" read-more-words="'+readMoreWords+'" show-stars="'+showStars+'" show-date="'+showDate+'" show-quotes="'+showQuote+'" show-photos="'+showPhotos+'" show-social-network-icons="'+showSocialNetworkIcons+'" text-color="'+textColor+'" structured-data-enable="'+structuredDataEnable+'" structured-data-name="'+structuredDataName+'" structured-data-logo="'+structuredDataLogo+'" ]');


        //$location,$type,$minimumStars,$sortBy,$sortOrder,$reviewAmount,$slidesPage,$slidesScroll,$autoplay,$speed,$transition,$readMore,$showStars,$showDate,$showQuotes

        //do ajax call to update preview
        // var data = {
        //     'action': 'update_shortcode_preview',
        //     'location': location,
        //     'type': type,
        //     'minimumStars': minimumStars,
        //     'sortBy': sortBy,
        //     'sortOrder': sortOrder,
        //     'reviewAmount': amountOfReviews,
        //     'slidesPage': visibleSlides,
        //     'slidesScroll': slidesScroll,
        //     'autoplay': autoplay,
        //     'speed': autoplaySpeed,
        //     'transition': transition,
        //     'readMore': readMore,
        //     'showStars': showStars,
        //     'showDate': showDate,
        //     'showQuotes': showQuote,
        //     };

        //     jQuery.post(ajaxurl, data, function (response) {

        //         // console.log(response);

        //         $('#shortcode-preview').empty();

        //         $('#shortcode-preview').append(response);

        //         //instantiate slick slider
        //         $('.make-me-slick').slick();
        //         //instantiate readmore
        //         readmoreActivationSlick();

        //     });


        //we are also going to hide and show applicable options
        if ($('#autosocial_review_read_more').is(":checked")) {
            $('.read-more-setting').show();       
        } else {
            $('.read-more-setting').hide();     
        }

        if ($('#autosocial_review_type').val() == 'slider') {
            $('.slider-setting').show();       
        } else {
            $('.slider-setting').hide();     
        }

        if ($('#autosocial_review_enable_structured_data').is(":checked")) {
            $('.structured-data-setting').show();       
        } else {
            $('.structured-data-setting').hide();     
        }

        



        

    }

    //run function when any input is changed
    $('body').on('change', '.review-setting select, .review-setting input', function(event) { 
        autosocial_shortcode_construction();   
    });

    //and when a profile item is clicked
    $('body').on('click', '.review_shortcode .profile-item', function(event) { 
        autosocial_shortcode_construction();   
    });

    //we are also going to run this initially
    if($('.review_shortcode').length){
        autosocial_shortcode_construction();  
    }


    //hide and show reviews
    //toggle location of reviews
    $('body').on("click",".review-list-item", function(event){

        event.preventDefault();
        
        var valueOfSetting = $('#autosocial_review_block_reviews').val();
        
        var reviewId = $(this).attr('data');
        
        if(!$(this).hasClass('selected')){
            
            //the item is currently hidden so we need to remove the review from the array
            var itemSelected = true;
            
            $(this).addClass('selected');
            
            $(this).find('.review-selected-icon').removeClass('fa-eye-slash');
            $(this).find('.review-selected-icon').addClass('fa-eye');
            
            var settingAsAnArray = valueOfSetting.split(',');
            var positionInArray = settingAsAnArray.indexOf(reviewId);
            if (positionInArray > -1) {
                settingAsAnArray.splice(positionInArray, 1);
            }
            
            var newSettingValue = settingAsAnArray.join(",");
            
            
            $('#autosocial_review_block_reviews').val(newSettingValue);
            
        } else {
            
            //we need to add the item

            var itemSelected = false;  
            
            $(this).removeClass('selected');
            $(this).find('.review-selected-icon').removeClass('fa-eye');
            $(this).find('.review-selected-icon').addClass('fa-eye-slash');
            
            if(valueOfSetting == ''){
                $('#autosocial_review_block_reviews').val(reviewId);    
            } else {
                $('#autosocial_review_block_reviews').val(valueOfSetting+','+reviewId);      
            }

        }
        
        //lets change the class
        
        
        //console.log(itemSelected);
        
        
    });


    //initiate colour picker if exists
    if($('.autosocial-color-field').length){
        $('.autosocial-color-field').wpColorPicker();
    }



    //conditionally hide and show delayed mode setting
    function autosocial_hide_delayed_mode_option(){
        if( $('#autosocial_activate_delayed_mode').is(':checked') ){
            $('.delayed-mode-setting').show();
        } else {
            $('.delayed-mode-setting').hide();    
        }
    }

    //run initially
    if($('#autosocial_activate_delayed_mode').length){
        autosocial_hide_delayed_mode_option();  
    }

    //run on change
    $('body').on('change','#autosocial_activate_delayed_mode',function(event) {
        
        autosocial_hide_delayed_mode_option();  

    });  



});