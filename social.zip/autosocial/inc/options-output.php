<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 

//define all the settings in the plugin
function autosocial_settings_init() { 
    
    //facebook
    register_setting( 'facebook_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'facebook_autosocial_section','', 
		'facebook_autosocial_section_callback', 
		'facebook_autosocial'
    );

    add_settings_field( 
		'autosocial_facebook_profile_selection','', 
		'autosocial_facebook_profile_selection_render', 
		'facebook_autosocial', 
		'facebook_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_facebook_default_profile_selection','', 
		'autosocial_facebook_default_profile_selection_render', 
		'facebook_autosocial', 
		'facebook_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_facebook_default_share_message','', 
		'autosocial_facebook_default_share_message_render', 
		'facebook_autosocial', 
		'facebook_autosocial_section' 
    );

    // add_settings_field( 
	// 	'autosocial_facebook_dont_share_if_no_link','', 
	// 	'autosocial_facebook_dont_share_if_no_link_render', 
	// 	'facebook_autosocial', 
	// 	'facebook_autosocial_section' 
    // );

    add_settings_field( 
		'autosocial_facebook_advanced_client_id','', 
		'autosocial_facebook_advanced_client_id_render', 
		'facebook_autosocial', 
		'facebook_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_facebook_advanced_client_secret','', 
		'autosocial_facebook_advanced_client_secret_render', 
		'facebook_autosocial', 
		'facebook_autosocial_section' 
    );

    
    
    //google my business
    register_setting( 'google_my_business_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'google_my_business_autosocial_section','', 
		'google_my_business_autosocial_section_callback', 
		'google_my_business_autosocial'
    );


    add_settings_field( 
		'autosocial_google_my_business_profile_selection','', 
		'autosocial_google_my_business_profile_selection_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_google_my_business_default_profile_selection','', 
		'autosocial_google_my_business_default_profile_selection_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_google_my_business_default_share_message','', 
		'autosocial_google_my_business_default_share_message_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_google_my_business_default_action_type','', 
		'autosocial_google_my_business_default_action_type_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );
    add_settings_field( 
		'autosocial_enable_google_my_business_woocommerce_integration','', 
		'autosocial_enable_google_my_business_woocommerce_integration_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );
    add_settings_field( 
		'autosocial_enable_google_my_business_the_events_calendar_integration','', 
		'autosocial_enable_google_my_business_the_events_calendar_integration_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_google_my_business_advanced_client_id','', 
		'autosocial_google_my_business_advanced_client_id_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_google_my_business_advanced_client_secret','', 
		'autosocial_google_my_business_advanced_client_secret_render', 
		'google_my_business_autosocial', 
		'google_my_business_autosocial_section' 
    );
    
    //twitter
    register_setting( 'twitter_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'twitter_autosocial_section','', 
		'twitter_autosocial_section_callback', 
		'twitter_autosocial'
    );

    add_settings_field( 
		'autosocial_twitter_advanced_client_id','', 
		'autosocial_twitter_advanced_client_id_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_twitter_advanced_client_secret','', 
		'autosocial_twitter_advanced_client_secret_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_twitter_connection_details','', 
		'autosocial_twitter_connection_details_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );

    // add_settings_field( 
	// 	'autosocial_twitter_consumer_key','', 
	// 	'autosocial_twitter_consumer_key_render', 
	// 	'twitter_autosocial', 
	// 	'twitter_autosocial_section' 
    // );

    // add_settings_field( 
	// 	'autosocial_twitter_consumer_secret','', 
	// 	'autosocial_twitter_consumer_secret_render', 
	// 	'twitter_autosocial', 
	// 	'twitter_autosocial_section' 
    // );

    // add_settings_field( 
	// 	'autosocial_twitter_access_token','', 
	// 	'autosocial_twitter_access_token_render', 
	// 	'twitter_autosocial', 
	// 	'twitter_autosocial_section' 
    // );

    // add_settings_field( 
	// 	'autosocial_twitter_access_token_secret','', 
	// 	'autosocial_twitter_access_token_secret_render', 
	// 	'twitter_autosocial', 
	// 	'twitter_autosocial_section' 
    // );

    add_settings_field( 
		'autosocial_twitter_profile_selection','', 
		'autosocial_twitter_profile_selection_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_twitter_default_profile_selection','', 
		'autosocial_twitter_default_profile_selection_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_twitter_default_share_message','', 
		'autosocial_twitter_default_share_message_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_twitter_share_as_link','', 
		'autosocial_twitter_share_as_link_render', 
		'twitter_autosocial', 
		'twitter_autosocial_section' 
    );


    
    //linkedin
    register_setting( 'linkedin_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'linkedin_autosocial_section','', 
		'linkedin_autosocial_section_callback', 
		'linkedin_autosocial'
    );

    add_settings_field( 
		'autosocial_linkedin_profile_selection','', 
		'autosocial_linkedin_profile_selection_render', 
		'linkedin_autosocial', 
		'linkedin_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_linkedin_default_profile_selection','', 
		'autosocial_linkedin_default_profile_selection_render', 
		'linkedin_autosocial', 
		'linkedin_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_linkedin_default_share_message','', 
		'autosocial_linkedin_default_share_message_render', 
		'linkedin_autosocial', 
		'linkedin_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_linkedin_advanced_client_id','', 
		'autosocial_linkedin_advanced_client_id_render', 
		'linkedin_autosocial', 
		'linkedin_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_linkedin_advanced_client_secret','', 
		'autosocial_linkedin_advanced_client_secret_render', 
		'linkedin_autosocial', 
		'linkedin_autosocial_section' 
    );

    //google plus
    register_setting( 'google_plus_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'google_plus_autosocial_section','', 
		'google_plus_autosocial_section_callback', 
		'google_plus_autosocial'
    );

    // instagram
    register_setting( 'instagram_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'instagram_autosocial_section','', 
		'instagram_autosocial_section_callback', 
		'instagram_autosocial'
    );

    add_settings_field( 
		'autosocial_instagram_profile_selection','', 
		'autosocial_instagram_profile_selection_render', 
		'instagram_autosocial', 
		'instagram_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_instagram_default_profile_selection','', 
		'autosocial_instagram_default_profile_selection_render', 
		'instagram_autosocial', 
		'instagram_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_instagram_default_share_message','', 
		'autosocial_instagram_default_share_message_render', 
		'instagram_autosocial', 
		'instagram_autosocial_section' 
    );



    //pinterest
    register_setting( 'pinterest_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'pinterest_autosocial_section','', 
		'pinterest_autosocial_section_callback', 
		'pinterest_autosocial'
    );

    add_settings_field( 
		'autosocial_pinterest_profile_selection','', 
		'autosocial_pinterest_profile_selection_render', 
		'pinterest_autosocial', 
		'pinterest_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_pinterest_default_profile_selection','', 
		'autosocial_pinterest_default_profile_selection_render', 
		'pinterest_autosocial', 
		'pinterest_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_pinterest_default_share_message','', 
		'autosocial_pinterest_default_share_message_render', 
		'pinterest_autosocial', 
		'pinterest_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_pinterest_default_share_title','', 
		'autosocial_pinterest_default_share_title_render', 
		'pinterest_autosocial', 
		'pinterest_autosocial_section' 
    );

    // add_settings_field( 
	// 	'autosocial_pinterest_default_board','', 
	// 	'autosocial_pinterest_default_board_render', 
	// 	'pinterest_autosocial', 
	// 	'pinterest_autosocial_section' 
    // );

    // add_settings_field( 
	// 	'autosocial_pinterest_advanced_client_id','', 
	// 	'autosocial_pinterest_advanced_client_id_render', 
	// 	'pinterest_autosocial', 
	// 	'pinterest_autosocial_section' 
    // );

    // add_settings_field( 
	// 	'autosocial_pinterest_advanced_client_secret','', 
	// 	'autosocial_pinterest_advanced_client_secret_render', 
	// 	'pinterest_autosocial', 
	// 	'pinterest_autosocial_section' 
    // );






    //general settings
	register_setting( 'general_settings_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'general_settings_autosocial_section','', 
		'general_settings_autosocial_section_callback', 
		'general_settings_autosocial'
    );

    add_settings_field( 
		'autosocial_order_id','', 
		'autosocial_order_id_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_order_email','', 
		'autosocial_order_email_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_custom_post_type_and_page_enable','', 
		'autosocial_custom_post_type_and_page_enable_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_categories_disable','', 
		'autosocial_categories_disable_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_enable_bit_ly','', 
		'autosocial_enable_bit_ly_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_bit_ly_access_token','', 
		'autosocial_bit_ly_access_token_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_bit_ly_group_guid','', 
		'autosocial_bit_ly_group_guid_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_enable_datetimepicker_no_conflict','', 
		'autosocial_enable_datetimepicker_no_conflict_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_dont_share_if_no_link','', 
		'autosocial_dont_share_if_no_link_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_prevent_auto_sharing','', 
		'autosocial_prevent_auto_sharing_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_activate_delayed_mode','', 
		'autosocial_activate_delayed_mode_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_delayed_mode_delay','', 
		'autosocial_delayed_mode_delay_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_enable_og_image','', 
		'autosocial_enable_og_image_render', 
		'general_settings_autosocial', 
		'general_settings_autosocial_section' 
    );
    
    //review shortcode
    register_setting( 'review_shortcode_autosocial', 'autosocial_settings' );

	add_settings_section(
		'review_shortcode_autosocial_section','', 
		'review_shortcode_autosocial_section_callback', 
		'review_shortcode_autosocial'
    );

    add_settings_field( 
		'autosocial_review_shortcode','', 
		'autosocial_review_shortcode_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_facebook_default_profile_selection_review','', 
		'autosocial_facebook_default_profile_selection_review_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_google_my_business_default_profile_selection_review','', 
		'autosocial_google_my_business_default_profile_selection_review_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_type','', 
		'autosocial_review_type_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_minimum_stars','', 
		'autosocial_review_minimum_stars_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_sort_by','', 
		'autosocial_review_sort_by_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_sort_order','', 
		'autosocial_review_sort_order_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_amount_of_reviews','', 
		'autosocial_review_amount_of_reviews_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_visible_slides','', 
		'autosocial_review_visible_slides_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_slides_to_scroll','', 
		'autosocial_review_slides_to_scroll_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_autoplay','', 
		'autosocial_review_autoplay_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_autoplay_speed','', 
		'autosocial_review_autoplay_speed_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_slide_transition','', 
		'autosocial_review_slide_transition_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_read_more','', 
		'autosocial_review_read_more_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_read_more_words','', 
		'autosocial_review_read_more_words_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_show_stars','', 
		'autosocial_review_show_stars_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_show_date','', 
		'autosocial_review_show_date_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_show_quote_symbols','', 
		'autosocial_review_show_quote_symbols_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_show_photos','', 
		'autosocial_review_show_photos_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_show_social_network_icons','', 
		'autosocial_review_show_social_network_icons_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_text_colour','', 
		'autosocial_review_text_colour_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_enable_structured_data','', 
		'autosocial_review_enable_structured_data_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_structured_data_name','', 
		'autosocial_review_structured_data_name_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_structured_data_logo','', 
		'autosocial_review_structured_data_logo_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );

    add_settings_field( 
		'autosocial_review_block_reviews','', 
		'autosocial_review_block_reviews_render', 
		'review_shortcode_autosocial', 
		'review_shortcode_autosocial_section' 
    );


    //help
    register_setting( 'help_autosocial', 'autosocial_settings' );
    
	add_settings_section(
		'help_autosocial_section','', 
		'help_autosocial_section_callback', 
		'help_autosocial'
    );
    
     //error log
     register_setting( 'error_log_autosocial', 'autosocial_settings' );
    
     add_settings_section(
         'error_log_autosocial_section','', 
         'error_log_autosocial_section_callback', 
         'error_log_autosocial'
     );

     
     //share now or schedule
     register_setting( 'share_now_or_schedule_autosocial', 'autosocial_settings' );
    
     add_settings_section(
         'share_now_or_schedule_autosocial_section','', 
         'share_now_or_schedule_autosocial_section_callback', 
         'share_now_or_schedule_autosocial'
     );

     //manage posts
     register_setting( 'manage_posts_autosocial', 'autosocial_settings' );
    
     add_settings_section(
         'manage_posts_autosocial_section','', 
         'manage_posts_autosocial_section_callback', 
         'manage_posts_autosocial'
     );
 
    
   
    
}

/**
* 
*
*
* The following functions output the callback of the sections
*/

function facebook_autosocial_section_callback(){}
function google_my_business_autosocial_section_callback(){}
function twitter_autosocial_section_callback(){}
function linkedin_autosocial_section_callback(){}
function pinterest_autosocial_section_callback(){}
function manage_posts_autosocial_section_callback(){

    if(get_option('autosocial_settings')){

        //get options
        $options = get_option('autosocial_settings');

        //tabs
        echo '<div class="manage-posts-section">';

            $tabs = array(
                array('tab name'=>'Facebook', 'icon'=>'fa-facebook', 'activated'=>true),
                array('tab name'=>'Google My Business', 'icon'=>'fa-google', 'activated'=>true),
                array('tab name'=>'Twitter', 'icon'=>'fa-twitter', 'activated'=>true),
                array('tab name'=>'LinkedIn', 'icon'=>'fa-linkedin', 'activated'=>true), 
                array('tab name'=>'Instagram', 'icon'=>'fa-instagram', 'activated'=>true), 
                array('tab name'=>'Pinterest', 'icon'=>'fa-pinterest', 'activated'=>true),      
            );

            //do tab heading
            echo '<ul class="manage-posts-tabs-header">';

                foreach($tabs as $index => $tab){

                    //only do tab if activated
                    if($tab['activated']==true){
                        $networkTranslated = autosocial_translate_network_name($tab['tab name']);

                        if($index == 0){
                            $class = 'active';
                        } else {
                            $class = '';    
                        }

                        echo '<li class="'.$class.'" data="'.$networkTranslated.'"><i class="fa '.$tab['icon'].'" aria-hidden="true"></i> '.$tab['tab name'].'</li>';
                    }

                }
        
            echo '</ul>';


            //do tab content
            echo '<ul class="manage-posts-tabs-content">';
                foreach($tabs as $index => $tab){


                if($tab['activated']==true){

                    $networkTranslated = autosocial_translate_network_name($tab['tab name']);

                    //get network data
                    $networkData = autosocial_account_data($tab['tab name']);

                    // var_dump($networkData);

                    $networkDataReformed = array();

                    //lets put data into a nicer associative array
                    foreach($networkData as $networkDataItem){
                        $networkDataReformed[$networkDataItem['id']] = array('name'=>$networkDataItem['name'],'type'=>$networkDataItem['type'],'image'=>$networkDataItem['image']);
                    }


                    // var_dump($networkData);

                    if($index == 0){
                        $class = 'active';
                    } else {
                        $class = '';    
                    }

                    echo '<li class="'.$class.' '.$networkTranslated.'">';



                        $profileOptionName = 'autosocial_'.$networkTranslated.'_profile_selection';

                        if (array_key_exists($profileOptionName, $options)) {
                    
                            //here we need to get all social profiles for the network and loop through them
                            $profiles = $options[$profileOptionName];

                            //split the profiles
                            $profilesExploded = explode(',',$profiles);

                            //now lets loop through the profiles
                            foreach($profilesExploded as $profileId){

                                //only do profiles where theres account data
                                if(isset($networkDataReformed[$profileId]['name'])){

                                    //dont do linkedin profile because it's not supported
                                    if($networkDataReformed[$profileId]['type'] == 'Profile' && $tab['tab name'] == 'LinkedIn'){
                                        
                                        echo '<div class="notice notice-warning inline"><p>'.__('Currently LinkedIn does not enable the fetching of a users feed.' ,'autosocial').'</p></div>';
                                        
                                    } else {
                                        echo '<div class="manage-post-profile">';

                                            echo '<h3>'.$networkDataReformed[$profileId]['name'].' <i data-profile-id="'.$profileId.'" data-network="'.$tab['tab name'].'" class="manage-posts-refresh-data fa fa-refresh" aria-hidden="true"></i></h3>';
                                            
                                            if($networkTranslated == 'Twitter'){
                                                echo '<h3>'.__('Unfortunately due to the introduction of Twitter\'s paid API tiers we no longer offer this functionality.','autosocial').'</h3>';    
                                            }

                                            //lets get posts
                                            echo '<div class="manage-posts-profile-table-container">';
                                                echo autosocial_render_post_data($profileId,$tab['tab name']);
                                            echo '</div>';                            

                                        echo '</div>';
                                    }

                                }

                            } 
                        
                        }

                    echo '</li>';

                }


                }

            echo '</ul>';

        echo '</div>';

    }

}
function google_plus_autosocial_section_callback(){
    echo '<div class="notice notice-warning inline"><p>Coming soon hopefully...sorry to get you excited</p></div>';
}
function instagram_autosocial_section_callback(){
    // echo '<div class="notice notice-warning inline"><p>Coming soon hopefully...sorry to get you excited</p></div>';
}
function general_settings_autosocial_section_callback(){}

function review_shortcode_autosocial_section_callback(){}

function help_autosocial_section_callback(){

    $options = get_option('autosocial_settings');

    //show which networks are activated
    if( isset($options['autosocial_facebook_profile_selection']) && strlen($options['autosocial_facebook_profile_selection'])>0 ){
        $facebookActivated = 'Yes';
    } else {
        $facebookActivated = 'No';    
    }

    if( isset($options['autosocial_google_my_business_profile_selection']) && strlen($options['autosocial_google_my_business_profile_selection'])>0 ){
        $googleMyBusinessActivated = 'Yes';
    } else {
        $googleMyBusinessActivated = 'No';    
    }

    if( isset($options['autosocial_twitter_profile_selection']) && strlen($options['autosocial_twitter_profile_selection'])>0 ){
        $twitterActivated = 'Yes';
    } else {
        $twitterActivated = 'No';    
    }

    if( isset($options['autosocial_linkedin_profile_selection']) && strlen($options['autosocial_linkedin_profile_selection'])>0 ){
        $linkedinActivated = 'Yes';
    } else {
        $linkedinActivated = 'No';    
    }

    //check whether user is using custom application for each profile
    if( isset($options['autosocial_linkedin_advanced_client_id']) && strlen($options['autosocial_linkedin_advanced_client_id'])>0 &&  isset($options['autosocial_linkedin_advanced_client_secret']) && strlen($options['autosocial_linkedin_advanced_client_secret'])>0){
        $linkedinCustomApplication = 'Yes';
    } else {
        $linkedinCustomApplication = 'No';    
    }

    if( isset($options['autosocial_facebook_advanced_client_id']) && strlen($options['autosocial_facebook_advanced_client_id'])>0 &&  isset($options['autosocial_facebook_advanced_client_secret']) && strlen($options['autosocial_facebook_advanced_client_secret'])>0){
        $facebookCustomApplication = 'Yes';
    } else {
        $facebookCustomApplication = 'No';    
    }

    if( isset($options['autosocial_twitter_advanced_client_id']) && strlen($options['autosocial_twitter_advanced_client_id'])>0 &&  isset($options['autosocial_twitter_advanced_client_secret']) && strlen($options['autosocial_twitter_advanced_client_secret'])>0){
        $twitterCustomApplication = 'Yes';
    } else {
        $twitterCustomApplication = 'No';    
    }

    if( isset($options['autosocial_google_my_business_advanced_client_id']) && strlen($options['autosocial_google_my_business_advanced_client_id'])>0 &&  isset($options['autosocial_google_my_business_advanced_client_secret']) && strlen($options['autosocial_google_my_business_advanced_client_secret'])>0){
        $googleMyBusinessCustomApplication = 'Yes';
    } else {
        $googleMyBusinessCustomApplication = 'No';    
    }

    //do gmb diagnostic info
    $gmbDiagnosticInfo = '';

    //get transient
    if(get_transient('autosocial_account_data_google_my_business_diagnostic')){

        $locations = get_transient('autosocial_account_data_google_my_business_diagnostic');

        // var_dump($locations);

        foreach($locations['locations'] as $location){
            
            $gmbDiagnosticInfo .= ' <strong>'.$location['title'].'</strong> '.json_encode($location['openInfo']['status']).' ';    

        }

    }


    $faq = array(

        // array('question'=>'This is my question?','answer'=>'This is my answer!!!'),

        array('question'=>'Posts with images are not being sent to Twitter?','answer'=>'Please ensure you do not use external images in the custom image field, make sure you select an image that is located on your WordPress installation.'),

        array('question'=>'I have entered my Order ID and Purchase Email but I am seeing a red notice on the plugin page?','answer'=>'WordPress caches plugin updates every several hours. So please <a href="'.get_admin_url().'update-core.php">click here</a> to manually check for updates by clicking the button at the top of the page and this should clear the error message.'),

        // array('question'=>'I am unable to connect to Twitter?','answer'=>'I am going to assume you have already followed the instructions on the Twitter tab and you have created your Twitter application. Now in the account name field on this tab enter an identifier for the account (note this can be anything it doesn\'t have to be your Twitter handle or anything). Then click the edit/pencil icon and this will expand the settings section so you can now enter your consumer key/secret and access token and access token secret. Please be super careful to make sure there are no trailing spaces at the end of your credentials when copying and pasting as this can cause an issue. When done, make sure you click the "Save All Settings" button at the bottom.'),

        array('question'=>'Images are not being shared to Facebook as intended?','answer'=>'Facebook can be a little tricky as they try and get an image from the URL and sometimes they do not respect the image we request to share - this is not a fault of the plugin. There are a couple of things that can be done to assist this. First make sure your current theme outputs the featured image on your posts (or whatever content type you happen to be sharing). You can also use a plugin to help set the og image tag that Facebook likes to read here: <a href="https://wordpress.org/plugins/simple-facebook-og-image/">https://wordpress.org/plugins/simple-facebook-og-image/</a> or try <a href="https://wordpress.org/plugins/fb-opengraph-tags/">https://wordpress.org/plugins/fb-opengraph-tags/</a>.'),

        array('question'=>'Images are not being shared to Instagram','answer'=>'Instagram has some specific rules around the image. It\'s important the image complies with the following specifications:
            <ul>
                <li>Maximum file size: 8MiB</li>
                <li>Aspect ratio: Must be within a 4:5 to 1.91:1 range</li>
                <li>Minimum width: 320 (will be scaled up to the minimum if necessary)</li>
                <li>Maximum width: 1440 (will be scaled down to the maximum if necessary)</li>
                <li>Height: Varies, depending on width and aspect ratio</li>
                <li>Formats: JPEG</li>
            </ul>
            Also note, you can only publish a maximum of 25 images in 24 hours. 
            
            '),

        array('question'=>'Images are not being shared to Google My Business as intended?','answer'=>'Google My Business has unusual image requirements and we enforce these requirements in the plugin. If your image does not meet Google\'s standards we will still share the post but it will just have no image. You need to make sure that the width AND height of the image is at least 250px AND the file size is greater then 10kb. Please ensure the file type of your image is standard like a jpg or png. If you are absolutely sure your image meets these requirements and it still is not being shared please raise a support request.'),

        // array('question'=>'Pins are not being created in Pinterest?','answer'=>'Please ensure you have both text content and an image to share to Pinterest.'),

        array('question'=>'How frequently do checks occur for scheduled posts created from the plugin settings?','answer'=>'For performance reasons we don\'t check for posts that need to be scheduled every minute instead we do this every 15 minutes. So if you schedule a post for 10am it may actually be sent at 10:15am at worse. However the plugins ability to send these scheduled posts is dependant on someone hitting your website either from the backend or frontend. So if your website has had no activity whatsoever for a week then no notifications will be sent in this period. So if sending notifications at a specific period is important what I recommen using a tool like <a href="https://uptimerobot.com/">Uptime Robot</a> which pings your website at a regular interval.'),

        array('question'=>'Scheduled posts aren\'t being sent on time?','answer'=>'Make sure your WordPress time is set to your local time or account for the WordPress time when scheduling your posts. Also please read the above question regarding the checking of scheduled posts.'),

        array('question'=>'Posts are being shared multiple times on my social networks?','answer'=>'This issue gets raised a lot and it normally comes down to not understanding how the plugin works. Let\'s say it is your goal to publish a post to your social networks once. What you need to do is very little! First in the plugin settings setup the accounts/profiles you want to share to by default. Then write your new post/page/custom post and then just click the "Publish" button just like you normally would. The post will now be shared to your selected profiles automatically, awesome. So in everyday use, that\'s all you need to do.....nothing. Now if you didn\'t want to publish that post to social networks you would click the "Do not share this post on any network" link on the metabox on your post before clicking the "Publish" button. Now where people can go wrong, and what can cause publishing the post multiple times is when they are on the post, they click the "Share Now" button on the meta box, and then they publish the post. This will share the post once when clicking "Share Now" and then again when clicking "Publish". The "Share Now" button should be used as an ad hoc way to share a post again, it\'s not necessarily something you need to do everytime you write a post. Now another issue which can share a post multiple times is not understanding how the tabs work in the metabox. Let\'s assume you know what you are doing and you want to press the "Share Now" button, before you do this go through each tab for each network and ensure that the profiles you want to share with are selected. When you press the "Share Now" button it will share the post to all selected profiles across all the networks. You don\'t need to click the Facebook tab and then click "Share Now" and then go to the Twitter tab and click "Share Now" as this will share the content twice.'),


        array('question'=>'How does AutoSocial work with WooCommerce and The Events Calendar in regard to Google My Business?','answer'=>'AutoSocial provides a way to create product posts in Google My Business from WooCommerce products, and events in Google My Business from The Events Calendar events. To do this, go to the "Google My Business" tab on this settings page and check the boxes "Enable WooCommerce Integration" and/or "Enable The Events Calendar Integration". By doing this, you are signalling to the plugin to send additional data to Google My Business, more specifically, price information from WooCommerce and event start and end dates from The Events Calendar. Now the last step, which you might have aready done, is you need to go to the "General Settings" tab on this settings page and enable AutoSocial for the custom post types. More specifically, enable "Product" for WooCommerce and "Tribe_events" for The Events Calendar. Now when you publish/share event or product posts from these 2 plugins this additional information will be sent. Please note, the main start and end date in The Event Calendar event will be the start and end date sent to Google My Business, not the elected start and date in the AutoSocial meta box.'),
        
        array('question'=>'Can I include custom fields (post meta) in my share message template?','answer'=>'Yes! Let\'s say you have custom post meta called "my_city", simply use the shortcode [POSTMETA_my_city] and the shortcode will be replaced with your custom field.'),

        array('question'=>'How do the share message templates work?','answer'=>'With AutoSocial there\'s a share message template hierarchy. So let\'s start at the top, by default the share message shared for each post will be the global template which is specific to each social network and can be updated from this plugin settings page by going to the relevant network tab (this message can also be updated from the individual posts edit page by clicking on the button "Save message as global template" inside the AutoSocial metabox). The next level is a template for each network for each post type. So you may want a custom template for reviews, a different template for pages and a different template for regular posts let\s say. This can be updated by going to any post for the relevant post type, settings the share message as you desire in the AutoSocial metabox, and then click the "Save message as post type template". Then the next time you create a post of this post type that share message template will be used. Lastly, each post itself has a share message template, and this is updated from the posts edit page and is saved automatically. So how does this all work together? So if you have an existing post, the share message shown will be the saved share message stored for that specific post, if that does not exist, then the post type template will be used, and if this does not exist the global share message template will be used.'),

        array('question'=>'Can I use my own application for Facebook, Google and LinkedIn?','answer'=>'To make the connection to your social profiles as easy as possible for Facebook, Google My Business and LinkedIn we recommend using our application as it just requires a one click process by just clicking the "Connect with XXX" button on the social profile tab in the plugin settings. 

        We understand that some people may feel uncomfortable using our application. There is a risk for example that if our application was to be blocked by a given social network that all posts created by our application will be removed from your social profile and that would really suck. Also posts created by our application may contain a disclosure like "Post created by AutoSocial" for the given network. This is why we also provide a way to enter your own application details for each network which can be found at the bottom of the Facebook, Google My Business and LinkedIn tabs in the plugin settings. This is recommended for advanced users only and we provide no support on how to setup your application. My only instruction is to make sure you enter the URL: '.get_admin_url().'admin.php?page=autosocial as your redirect URI in your custom application. Just to warn you, if you plan on creating your own Facebook application this requires HEAPS of effort, like a few hours of effort plus approval time as you need to create a video for your application to be approved. Although it is relatively easy to create a LinkedIn application you may find it really difficult to get the correct permissions to make this plugin work correctly (w_organization_social,r_organization_social,w_member_social,r_basicprofile,r_liteprofile,rw_organization_admin) as this needs to be approved by LinkedIn/Microsoft and they are pretty strict who they give this out to. Creating a custom application for Google My Business is a lot easier.'),

        array('question'=>'Some of the interactive elements are not working in your plugin like tabs and the initial connection to my social networks?','answer'=>'This could be caused by a javascript issue caused by another plugin. AutoSocial relies on javascript to do authentication and to render interactive elements. I recommend ensuring you are using the latest version of WordPress and AutoSocial and other plugins you have installed also. If the issue persists please try deactivating all plugins and just try using AutoSocial and see if things work ok. Also try using a standard theme like "Twenty Sixteen" and see if this solves the issue. Granted these two things are not good long term solutions but they are necessary to identify what is causing the issue.'),

        array('question'=>'How do I delete all plugin settings?','answer'=>'Please click <a id="delete-all-plugin-settings-autosocial" href="#">here</a>.'),

        array('question'=>'Do you provide any filters','answer'=>'Yes, please see below:<br><br>

        <strong>Prevent particular posts being shared to your selected social networks</strong><br>
        <em>The below example filter checks whether the post title contains the word "Good" and if it does it will share the post, otherwise it won\'t share the post. Returning $post_id will share, returning \'\' won\'t share the post.</em><br><br>
        <code>
        add_filter( \'autosocial_post_id_filter\', \'autosocial_filter_posts_to_share_custom\', 99, 1);<br>
        function autosocial_filter_posts_to_share_custom($post_id){<br>
            <br>
            //get the post title<br>
            $post_title = get_the_title($post_id);<br>
            <br>
            //check if the post title contains the word \'Good\'<br>
            if(strpos($post_title, \'Good\') !== false){<br>
                //lets share the post<br>
                return $post_id;<br>
            } else {<br>
                //lets not share the post<br>
                return \'\';<br>
            }<br>
        }<br>
        </code><br></br>


        <strong>Set a default share image for posts when there isn\'t one available</strong><br>
        <em>The below example enables you to set a default or fallback image if there\'s no feature image or image in the AutoSocial metabox selected for a particular post.</em><br><br>
        <code>
        add_filter( \'autosocial_default_image\', \'autosocial_set_default_image\', 99, 2);<br>
        function autosocial_set_default_image($string,$post_id){<br>
            <br>
            if($post_id == 123){<br>
                return \'https://mydomain.com/my-image.jpg\';<br>
            }<br>
            <br>
        }<br>
        </code><br></br>



        <strong>Filter the share message before sending (used for post shares - not the share now or schedule feature in these plugin settings)</strong><br>
        <em>The below example enables you to add a prefix to the share message</em><br><br>
        <code>
        add_filter( \'autosocial_message_filter\', \'autosocial_message_filter_function\', 10, 4);<br>
        function autosocial_message_filter_function($shareMessage,$postId,$network,$profileId){<br>
            <br>
            return \'Some message before...\'.$shareMessage;<br>
            <br>
        }<br>
        </code><br></br>
        

        
        '),

        array('question'=>'How can I enable non-admin users the ability to edit AutoSocial main plugin settings?','answer'=>'You can add the following code to your themes functions.php file to enable an editor for example the ability to edit the settings you can use the following code:<br></br>
        
        <code>
        function autosocial_enable_editor_to_edit_settings() {<br>
            <br>
            $role = get_role(\'editor\');<br>
            <br>
            $role->add_cap(\'autosocial_manage_options\', true);<br>
            <br>
        }<br>
        add_action(\'init\', \'autosocial_enable_editor_to_edit_settings\',1);
        </code><br></br>


        You can also use the free <a target="_blank" href="https://en-au.wordpress.org/plugins/user-role-editor/">User Role Editor</a> plugin to add the capability "autosocial_manage_options" to your desired role.'),
  
        array('question'=>'I have read the FAQ but I still have a question or issue!','answer'=>'Please create a ticket <a href="https://northernbeacheswebsites.com.au/support/">here</a> and include the following information:</br>

        <ul class="diagnostic-information">
            <li>PHP Version: '.phpversion().'</li>
            <li>CURL Exists: '.function_exists('curl_version').'</li>
            <li>WordPress Version: '.get_bloginfo('version').'</li>
            <li>Plugin Version: '.autosocial_get_version().'</li>
            <li>Facebook Activated: '.$facebookActivated.'</li>
            <li>Google My Business Activated: '.$googleMyBusinessActivated.'</li>
            <li>Twitter Activated: '.$twitterActivated.'</li>
            <li>LinkedIn Activated: '.$linkedinActivated.'</li>
            <li>Facebook Custom Application: '.$facebookCustomApplication.'</li>
            <li>Twitter Custom Application: '.$twitterCustomApplication.'</li>
            <li>Google My Business Custom Application: '.$googleMyBusinessCustomApplication.'</li>
            <li>LinkedIn Custom Application: '.$linkedinCustomApplication.'</li>

            

            <li>Google My Business Location Diagnostic Information: '.$gmbDiagnosticInfo.'</li>

            

        </ul>')
    );


    foreach($faq as $item){

        echo '<h3 class="faq-item-question"><i class="fa fa-question-circle-o" aria-hidden="true"></i> '.__($item['question'],'autosocial').'</h3>';

        echo '<article class="faq-item-answer">'.__($item['answer'],'autosocial').'</article>';

    }


}

function error_log_autosocial_section_callback(){

    //only do error log if an error log item exists
    $errorLog = get_option('autosocial_error_log');

    if($errorLog){

        echo '<div class="notice notice-warning inline"><p>'.__('Please do not report issues shown in the log as support requests as items shown in this log are mainly caused on the social networks end. This log is for informational purposes only.','autosocial').'</p></div>';

        //get wordpress date and time options
        $dateFormat = get_option('date_format');
        $timeFormat = get_option('time_format');

        echo '<table class="autosocial-log-table">';
            echo '<thead>';

                echo '<tr>';

                    echo '<th>'.__('Time','autosocial').'</th>';
                    echo '<th>'.__('Network','autosocial').'</th>';
                    echo '<th>'.__('Profile','autosocial').'</th>';
                    echo '<th>'.__('Status','autosocial').'</th>';

                echo '</tr>';

            echo '</thead>';
            echo '<tbody>';

            foreach($errorLog as $key => $logItem){

                if($key > 600){
                    break;
                }

                $time = $logItem['time'];
                $network = $logItem['network'];
                $profile = $logItem['profile'];
                $status = $logItem['status'];

                //get nice time
                $niceTime = date($dateFormat.' '.$timeFormat,$time);

                //get nice profile name
                $accountData = autosocial_account_data($network);

                foreach($accountData as $profileItem){
                    
                    if($profileItem['id'] == $profile){
                        $niceProfileName = $profileItem['name'];
                    }

                }

                if(!isset($niceProfileName)){
                    $niceProfileName = '';
                }

                echo '<tr>';

                    echo '<td>'.$niceTime.'</td>';
                    echo '<td>'.$network.'</td>';
                    echo '<td>'.$niceProfileName.'</td>';
                    echo '<td>'.$status.'</td>';

                echo '</tr>';

            }

            echo '</tbody>';
        echo '</table>';



    }

}
function share_now_or_schedule_autosocial_section_callback(){

    //get options
    $options = get_option('autosocial_settings');

    echo '<div id="share_now_or_schedule_autosocial_container">';

        //link
        echo '<div class="share-now-or-schedule-section">';

            echo '<label>'.__('Link','autosocial').'
                <i class="fa fa-info-circle" aria-hidden="true"></i>
                <p class="hidden" style="display: none;"><em>Recommended but optional</em></p>
            </label>';

            echo '<input type="text" class="regular-text share-now-or-schedule-setting" name="share-now-or-schedule-setting-link" placeholder="https://">';

        echo '</div>';






        //image
        echo '<div class="share-now-or-schedule-section">';

            echo '<label>'.__('Image','autosocial').'
                <i class="fa fa-info-circle" aria-hidden="true"></i>
                <p class="hidden" style="display: none;"><em>Recommended but optional</em></p>
            </label>';

            echo '<input id="share-now-or-schedule-setting-image" type="text" class="regular-text share-now-or-schedule-setting" name="share-now-or-schedule-setting-image"><button class="button-secondary share-now-or-schedule-setting-upload"><i class="fa fa-picture-o" aria-hidden="true"></i> '.__('Upload/Select Image','autosocial').'</button>';

            //render the image
            echo '<div style="margin-top: 25px;">';
                echo '<img src="" class="autosocial_image_preview">';

                echo '<a class="autosocial_image_preview_clear" href="#"><i class="fa fa-times-circle-o" aria-hidden="true"></i></a>';

            echo '</div>';  

        echo '</div>';







        //tabs
        echo '<div class="share-now-or-schedule-section">';

            $tabs = array(
                array('tab name'=>'Facebook', 'icon'=>'fa-facebook', 'content-length'=>19999),
                array('tab name'=>'Google My Business', 'icon'=>'fa-google', 'content-length'=>1499),
                array('tab name'=>'Twitter', 'icon'=>'fa-twitter', 'content-length'=>279),
                array('tab name'=>'LinkedIn', 'icon'=>'fa-linkedin', 'content-length'=>3000),   
                array('tab name'=>'Instagram', 'icon'=>'fa-instagram', 'content-length'=>2200),   
                array('tab name'=>'Pinterest', 'icon'=>'fa-pinterest', 'content-length'=>500),      
            );

            //do tab heading
            echo '<ul class="share-now-or-schedule-tabs-header">';

                foreach($tabs as $index => $tab){

                    $networkTranslated = autosocial_translate_network_name($tab['tab name']);

                    if($index == 0){
                        $class = 'active';
                    } else {
                        $class = '';    
                    }

                    echo '<li class="'.$class.'" data="'.$networkTranslated.'"><i class="fa '.$tab['icon'].'" aria-hidden="true"></i> '.$tab['tab name'].'</li>';

                }

                
            echo '</ul>';





            //do tab content
            echo '<ul class="share-now-or-schedule-tabs-content">';
                foreach($tabs as $index => $tab){

                    $networkTranslated = autosocial_translate_network_name($tab['tab name']);

                    if($index == 0){
                        $class = 'active';
                    } else {
                        $class = '';    
                    }

                    echo '<li class="'.$class.' '.$networkTranslated.'">';

                        //do label for text area
                        echo '<label>'.__('Share Message','autosocial').'<button class="button-secondary copy-share-message"><i class="fa fa-files-o" aria-hidden="true"></i> '.__('Copy share message to all networks','autosocial').'</button></label>';

                        //do text area
                        //if twitter make max length actually larger so URL's can be put in it
                        if($tab['tab name'] == 'Twitter'){
                            $max_content = 600;
                        } else {
                            $max_content = $tab['content-length'];  
                        }

                        echo '<textarea maxlength="'.$max_content.'" class="share-now-or-schedule-setting share-now-or-schedule-setting-share-message" rows="4" style="width: 100%;" type="text" name="autosocial_'.$networkTranslated.'_share_message"></textarea>';

                        //do counter
                        echo '<span class="counter-container">   <span class="dynamic-counter">0</span>/<span class="max-length">'.$tab['content-length'].'</span>   </span>';


                        //do profile selection
                        echo '<label>'.__('Select Profiles','autosocial').'</label>';
                        

                        if(isset($options['autosocial_'.$networkTranslated.'_default_profile_selection'])){
                            $selectionOfSelectionProfiles = $options['autosocial_'.$networkTranslated.'_default_profile_selection'];
                        } else {
                            $selectionOfSelectionProfiles = '';   
                        }

                        echo autosocial_render_default_profile_selection($tab['tab name'].'_snos',$selectionOfSelectionProfiles);


                        //do text input for social network selection
                        if(isset($options['autosocial_'.$networkTranslated.'_default_profile_selection'])){
                            $inputValue = $options['autosocial_'.$networkTranslated.'_default_profile_selection'];
                        } else {
                            $inputValue = '';
                        }
                        
                        echo '<input style="display:none;" id="autosocial_'.$networkTranslated.'_snos_default_profile_selection" type="text" class="regular-text share-now-or-schedule-setting" name="share-now-or-schedule-setting-profile-selection-'.$networkTranslated.'" value="'.$inputValue.'">';

                        //do google my business content only
                        if($tab['tab name'] == 'Google My Business'){


                            //do custom button
                            echo '<label style="margin-top: 20px;">'.__('Custom Button','autosocial').'</label>';

                            $values = array('LEARN_MORE' => 'Learn More','BOOK' => 'Book','ORDER' => 'Order','SHOP' => 'Shop','SIGN_UP' => 'Sign Up','CALL' => 'Call');

                            echo '<select class="share-now-or-schedule-setting" name="share-now-or-schedule-setting-custom-button-'.$networkTranslated.'">';
                            
                                //set default option
                                if(isset($options['autosocial_google_my_business_default_action_type'])){
                                    $selectedOption = $options['autosocial_google_my_business_default_action_type'];
                                } else {
                                    $selectedOption = '';    
                                }

                                foreach($values as $value => $name){

                                    if($value == $selectedOption){
                                        echo '<option selected="selected" value="'.$value.'">'.$name.'</option>';
                                    } else {
                                        echo '<option value="'.$value.'">'.$name.'</option>';
                                    }

                                    
                                }
                            
                            echo '</select>';


                            //do event activation
                            echo '<div style="margin-top: 20px;">';
                                echo '<input id="share-now-or-schedule-setting-enable-event" type="checkbox" class="share-now-or-schedule-setting" name="share-now-or-schedule-setting-enable-event-'.$networkTranslated.'" value="yes"> Make post an event';
                            echo '</div>';

                            //do event details
                            //link
                            echo '<div class="share-now-or-schedule-section-event">';

                                //event title
                                echo '<label style="margin-top: 15px;">'.__('Event Title','autosocial').'</label>';

                                echo '<input type="text" class="regular-text share-now-or-schedule-setting" name="share-now-or-schedule-setting-event-title-'.$networkTranslated.'" >';

                                //event start
                                echo '<label style="margin-top: 15px;">'.__('Event Start','autosocial').'</label>';

                                echo '<input type="text" class="autosocial-timedatepicker regular-text share-now-or-schedule-setting" name="share-now-or-schedule-setting-event-start-'.$networkTranslated.'" >';

                                //event end
                                echo '<label style="margin-top: 15px;">'.__('Event End','autosocial').'</label>';

                                echo '<input type="text" class="autosocial-timedatepicker regular-text share-now-or-schedule-setting" name="share-now-or-schedule-setting-event-end-'.$networkTranslated.'" >';
                                

                            echo '</div>';
              
                        }

                        //do pinterest board selection
                        if($tab['tab name'] == 'Pinterest'){

                            //label
                            echo '<label style="margin-top: 20px;">'.__('Pin Title','autosocial').'</label>';

                            echo '<textarea style="width: 100%;" class="share-now-or-schedule-setting" name="share-now-or-schedule-setting-pin-title-'.$networkTranslated.'"></textarea>';

                        }


                    echo '</li>';
                }

            echo '</ul>';

        echo '</div>';






        //button
        echo '<div style="margin-top: -40px; margin-bottom: 60px;" class="share-now-or-schedule-section">';

            echo '<button class="send-share-now button button-primary"><i class="fa fa-paper-plane" aria-hidden="true"></i> '.__('Send Now','autosocial').'</button>';

            echo '<button style="margin-left: 5px;" class="schedule-share-now button button-primary"><i class="fa fa-clock-o" aria-hidden="true"></i> '.__('Schedule for Later','autosocial').'</button>';

            // echo '<button style="margin-left: 5px;" class="auto-post button button-primary"><i class="fa fa-bolt" aria-hidden="true"></i> '.__('Auto Post','autosocial').'</button>';
            
            echo '<div style="margin-top: 15px; display:none;">';
                echo '<input type="text" class="autosocial-timedatepicker regular-text share-now-or-schedule-setting share-now-or-schedule-setting-schedule-date-time" name="share-now-or-schedule-setting-schedule-date-time" placeholder="Please select a date">';
            echo '</div>';
        echo '</div>';

    echo '</div>';














    //now we will show scheduled posts

    $optionName = 'autosocial_schedule_queue';
    //get existing option
    $existingValue = get_option($optionName);

    if($existingValue !== false && count($existingValue)>0){

        //lets sort through these items
        $sortArray = array();
        foreach($existingValue as $sortKey => $sortValue){
            $sortArray[$sortKey] = $sortValue['scheduledDateTime'];   
        }
        asort($sortArray);



        //get wordpress date and time options
        $dateFormat = get_option('date_format');
        $timeFormat = get_option('time_format');

        echo '<h3>'.__('Scheduled Posts','autosocial').'</h3>';
       
        echo '<table style="margin-bottom: 45px;" class="autosocial_schedule_queue">';
            echo '<thead>';

                echo '<tr>';
                    echo '<th>'.__('Scheduled Date/Time','autosocial').'</th>';
                    echo '<th>'.__('Network','autosocial').'</th>';
                    echo '<th>'.__('Profile','autosocial').'</th>';
                    echo '<th>'.__('Share Message','autosocial').'</th>';
                    echo '<th>'.__('Actions','autosocial').'</th>';
                echo '</tr>';

            echo '</thead>';
            echo '<tbody>';


                foreach($sortArray as $sortKeyLoop => $sortValueLoop){

                    $key = $sortKeyLoop;
                    $share = $existingValue[$sortKeyLoop];

                // foreach($existingValue as $key=>$share){

                    

                    echo '<tr data="'.$share['id'].'">';

                        //get nice time
                        $niceTime = date($dateFormat.' '.$timeFormat,$share['scheduledDateTime']);

                        echo '<td class="shareDateTime">'.$niceTime.'</td>';
                        echo '<td>'.$share['network'].'</td>';

                        //get nice profile name
                        $accountData = autosocial_account_data($share['network']);

                        foreach($accountData as $profileItem){
                            
                            if($profileItem['id'] == $share['profileId']){
                                $niceProfileName = $profileItem['name'];
                            }

                        }

                        echo '<td>'.$niceProfileName.'</td>';
                        echo '<td class="shareMessage">'.$share['shareMessage'].'</td>';

                        if(isset($share['link'])){
                            $shareLink = $share['link'];
                        } else {
                            $shareLink = '';    
                        }

                        if(isset($share['image'])){
                            $shareImage = $share['image'];
                        } else {
                            $shareImage = '';    
                        }

                        echo '<td><i title="edit item" data="'.$share['id'].'" data-link="'.$shareLink.'" data-image="'.$shareImage.'" data-scheduled="'.date('M j, Y  H:i',$share['scheduledDateTime']).'" data-message="'.$share['shareMessage'].'" class="edit-scheduled-item fa fa-pencil" aria-hidden="true"></i><i title="delete item" data="'.$share['id'].'" class="delete-scheduled-item fa fa-trash-o" aria-hidden="true"></i></td>';
                    echo '</tr>';



                }

            echo '</tbody>';

        echo '</table>';




        // var_dump($existingValue);
    } 









    //now we will show sent posts

    $optionName = 'autosocial_share_now_log';
    //get existing option
    $existingValue = get_option($optionName);

    if($existingValue !== false){


        $sortArray = array();

        //lets sort through this array
        foreach( $existingValue as $sortKey => $sortValue ){
            $sortArray[$sortKey] = $sortValue['currentTime'];
        }

        //sort by array key
        arsort($sortArray);

        //get wordpress date and time options
        $dateFormat = get_option('date_format');
        $timeFormat = get_option('time_format');


        echo '<h3>'.__('Shared Posts','autosocial').'</h3>';
        
        echo '<table class="autosocial_shared_posts">';

            echo '<colgroup>';
                echo '<col class="medium-column-shared">';
                echo '<col class="medium-column-shared">';
                echo '<col class="medium-column-shared">';
                echo '<col class="large-column-shared">';
                echo '<col class="small-column-shared">';
                echo '<col class="medium-column-shared">';
            echo '</colgroup>';

            echo '<thead>';

                echo '<tr>';
                    echo '<th>'.__('Sent Date/Time','autosocial').'</th>';
                    echo '<th>'.__('Network','autosocial').'</th>';
                    echo '<th>'.__('Profile','autosocial').'</th>';
                    echo '<th>'.__('Share Message','autosocial').'</th>';
                    // echo '<th>'.__('URL','autosocial').'</th>';
                    echo '<th>'.__('Status','autosocial').'</th>';
                    echo '<th>'.__('Actions','autosocial').'</th>';
                echo '</tr>';

            echo '</thead>';
            echo '<tbody>';

                $counter = 0;

                foreach($sortArray as $sortKeyLoop => $sortValueLoop){

                    $shareId = $sortKeyLoop;
                    $shareArray = $existingValue[$sortKeyLoop];

                    if($counter > 600){
                        break;    
                    }

                    echo '<tr data="'.$shareId.'">';

                        //get nice time
                        $niceTime = date($dateFormat.' '.$timeFormat,$shareArray['currentTime']);

                        echo '<td>'.$niceTime.'</td>';
                        echo '<td>'.$shareArray['data']['network'].'</td>';

                        //get nice profile name
                        $accountData = autosocial_account_data($shareArray['data']['network']);

                        foreach($accountData as $profileItem){
                            
                            if($profileItem['id'] == $shareArray['data']['profileId']){
                                $niceProfileName = $profileItem['name'];
                            }

                        }

                        if(!isset($niceProfileName)){
                            $niceProfileName = '';
                        }

                        echo '<td>'.$niceProfileName.'</td>';
                        echo '<td>'.$shareArray['data']['shareMessage'].'</td>';

                        // echo '<td>';
                        //     if(isset($shareArray['url'])){
                        //         echo $shareArray['url'];
                        //     }
                        // echo '</td>';

                        echo '<td>'.$shareArray['status'].'</td>';
                        echo '<td><i title="reshare item" data="'.$shareId.'" class="reshare-item fa fa-retweet" aria-hidden="true"></i>';
                        if(isset($shareArray['url'])){
                            
                            echo '<a target="_blank" href="'.$shareArray['url'].'"><i class="share-link-item fa fa-link" aria-hidden="true"></i></a>';

                        }      
                
                        echo '</td>';
                    echo '</tr>';    
                    $counter++;
                }

            echo '</tbody>';


        echo '</table>';


    }

}














/**
* 
*
*
* The following functions output the settings of the sections
*/
function autosocial_facebook_enable_render(){
    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_enable','Enable Facebook','','checkbox','','','','eventually-hidden');
}

function autosocial_twitter_enable_render(){
    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_enable','Enable Twitter','','checkbox','','','','eventually-hidden');
}

function autosocial_linkedin_enable_render(){
    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_linkedin_enable','Enable LinkedIn','','checkbox','','','','eventually-hidden');
}

function autosocial_google_my_business_enable_render(){
    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_enable','Enable Google My Business','','checkbox','','','','eventually-hidden');
}

function autosocial_google_my_business_profile_selection_render(){

    //do connect button
    $state = urlencode (get_admin_url()); 

    $connectionDetails = autosocial_get_client_id_and_secret('Google My Business');
    $client_id = $connectionDetails['client_id'];
    $redirect_uri = $connectionDetails['redirect_uri'];

    echo '<tr class="autosocial_settings_row" valign="top">
            <td scope="row" colspan="2">';
            
                echo '<a style="margin-top:20px;" href="https://accounts.google.com/o/oauth2/v2/auth?scope=https://www.googleapis.com/auth/plus.business.manage&access_type=offline&include_granted_scopes=true&state='.$state.'&redirect_uri='.$redirect_uri.'&response_type=code&client_id='.$client_id.'&prompt=consent" class="button-secondary"><i class="fa fa-google" aria-hidden="true"></i> '.__('Connect with Google My Business', 'autosocial' ).'</a>';

                echo '<a data="Google My Business" class="test-connection-button button-secondary">Test Connection</a>';

        echo '</td>';
    
    echo '</tr>';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Activate the locations you want to use','autosocial').' <a class="button-secondary refresh-data" data="Google My Business" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

            echo autosocial_render_profile_selection('Google My Business');

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_profile_selection','Select Account','','text','','','','hidden-setting');

}


function autosocial_google_my_business_default_profile_selection_render(){



    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Set the default locations you want to use','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_google_my_business_default_profile_selection'])){
                $selectionOfSelectionProfiles = $options['autosocial_google_my_business_default_profile_selection'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Google My Business',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_default_profile_selection','Select Default Account','','text','','','','hidden-setting');

}


function autosocial_google_my_business_default_share_message_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default share message','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_default_share_message','','','shortcode','New Post: [POST_TITLE] - [POST_CONTENT]',$values,'','');

}

function autosocial_google_my_business_default_action_type_render(){


    $values = array('LEARN_MORE' => 'Learn More','BOOK' => 'Book','ORDER' => 'Order','SHOP' => 'Shop','SIGN_UP' => 'Sign Up','CALL' => 'Call');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_default_action_type','Set the default action type (button text)','','select','',$values,'','');

}


function autosocial_enable_google_my_business_woocommerce_integration_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_enable_google_my_business_woocommerce_integration','Enable WooCommerce Integration (currently not in operation, please don\'t check this checkbox)','With this checkbox checked when you publish WooCommerce products they will be created as a product post in Google My Business and the price and currency will be included in the post.','checkbox','','','','');

}

function autosocial_enable_google_my_business_the_events_calendar_integration_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_enable_google_my_business_the_events_calendar_integration','Enable The Events Calendar Integration','With this checkbox checked when you publish events using The Events Calendar plugin they will be created as an event post in Google My Business and the start and end dates and time will be included in the post.','checkbox','','','','');

}










function autosocial_facebook_profile_selection_render(){

    //do connect button
    $state = urlencode (get_admin_url()); 

    $connectionDetails = autosocial_get_client_id_and_secret('Facebook');
    $client_id = $connectionDetails['client_id'];
    $redirect_uri = $connectionDetails['redirect_uri'];
    // $scope = 'email,pages_read_engagement,pages_manage_posts,pages_manage_metadata,pages_read_user_content,public_profile,business_management';

    $scope = 'email,pages_read_engagement,pages_show_list,pages_manage_posts,pages_read_user_content,public_profile,business_management,instagram_basic,instagram_content_publish';


    echo '<tr class="autosocial_settings_row" valign="top">
            <td scope="row" colspan="2">';
            
                echo '<a style="margin-top:20px;" href="https://www.facebook.com/v16.0/dialog/oauth?scope='.$scope.'&state='.$state.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id.'" class="button-secondary"><i class="fa fa-facebook" aria-hidden="true"></i> '.__('Connect with Facebook', 'autosocial' ).'</a>';

                echo '<a data="Facebook" class="test-connection-button button-secondary">Test Connection</a>';

        echo '</td>';
    
    echo '</tr>';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Activate the profile and/or pages you want to use','autosocial').' <a class="button-secondary refresh-data" data="Facebook" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

            echo autosocial_render_profile_selection('Facebook');

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_profile_selection','Select Profile','','text','','','','hidden-setting');

}

// function autosocial_instagram_profile_selection_render(){

//     //do connect button
//     $state = urlencode (get_admin_url()); 

//     $connectionDetails = autosocial_get_client_id_and_secret('Instagram');
//     $client_id = $connectionDetails['client_id'];
//     $redirect_uri = $connectionDetails['redirect_uri'];

//     echo '<tr class="autosocial_settings_row" valign="top">
//             <td scope="row" colspan="2">';
            
//                 echo '<a style="margin-top:20px;" href="https://www.facebook.com/v8.0/dialog/oauth?scope=instagram_basic&state='.$state.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id.'" class="button-secondary"><i class="fa fa-instagram" aria-hidden="true"></i> '.__('Connect with Instagram', 'autosocial' ).'</a>';

//                 echo '<a data="Instagram" class="test-connection-button button-secondary">Test Connection</a>';

//         echo '</td>';
    
//     echo '</tr>';

//     echo '<tr class="autosocial_settings_row" valign="top">';
//         echo '<td scope="row" colspan="2">';

//             //lets output profile selection
//             echo '<h3>'.__('Activate the profile and/or pages you want to use','autosocial').' <a class="button-secondary refresh-data" data="Instagram" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

//             // echo autosocial_render_profile_selection('Instagram');

//         echo '</td>';
//     echo '</tr>';

//     //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
//     autosocial_settings_code_generator('autosocial_instagram_profile_selection','Select Profile','','text','','','','hidden-setting');

// }

function autosocial_facebook_default_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Set the default profile and/or pages you want to use','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_facebook_default_profile_selection'])){
                $selectionOfSelectionProfiles = $options['autosocial_facebook_default_profile_selection'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Facebook',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_default_profile_selection','Select Default Profile','','text','','','','hidden-setting');

}

function autosocial_facebook_default_share_message_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default share message','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_LINK','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_default_share_message','','','shortcode','New Post: [POST_TITLE]',$values,'','');

}


// function autosocial_facebook_dont_share_if_no_link_render(){

//     echo '<tr class="autosocial_settings_row" valign="top">';
//         echo '<td scope="row" colspan="2">';

//             //lets output profile selection
//             echo '<h3 style="margin-bottom: -30px;">'.__('Other settings','autosocial').'</h3>';

//         echo '</td>';
//     echo '</tr>';

//     //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
//     autosocial_settings_code_generator('autosocial_facebook_dont_share_if_no_link','If the share message does not contain the post link then do not share the post link to Facebook.','If you do not know what this means, we recommend leaving this unchecked.','checkbox','','','','');

// }


function autosocial_dont_share_if_no_link_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_dont_share_if_no_link','If the share message does not contain the post link then do not share the post link to social networks','If you are sharing custom posts which don\'t have public permalinks you can check this box so the posts links aren\'t shared to Facebook, Google My Business and LinkedIn. If you do not know what this means, we recommend leaving this unchecked.','checkbox','','','','');

}

function autosocial_prevent_auto_sharing_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_prevent_auto_sharing','Prevent the plugin from sharing automatically','By enabling this setting no automatic publishing will occur. This means the only way to share a post is by clicking on a share button or share link. This can be a good option if you are using some 3rd party plugin which updates posts or imports posts and you don\'t want to share potentially tens or hundreds of posts at the same time from that plugins publish/update routine.','checkbox','','','','');

}

function autosocial_activate_delayed_mode_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_activate_delayed_mode','Activate delayed mode','By enabling this setting we won\'t attempt to share a post/page/custom post at the published or scheduled time and instead share the item as part of a batch every few minutes (the amount of delay minutes can be set in the next setting). So at most the post should be shared to your selected social media profile(s) no more than # minutes after the published/scheduled time. The reason to activate this is sometimes when sharing a post instantly the social network will attempt to crawl your site but due to caching, server configuration/resources or CDN networks the post is still building/processing and images and other data might be missing from the share on the profile. So if you are experiencing this kind of issue, we recommend activating this feature.','checkbox','','','','');

}

function autosocial_delayed_mode_delay_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_delayed_mode_delay','Delayed mode delay in minutes','If you activated the previous setting, set the amount of delay minutes. If you are not sure, we recommend around 30 minutes.','number','30','','','delayed-mode-setting');

}

function autosocial_enable_og_image_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_enable_og_image','Enable og:image header tag','Some social networks need the og_image header tag to correctly pull the right image for a post. We may ask you to check this checkbox via our support or feel free to check this if the right image isn\'t being shared on the social network.','checkbox','','','','');

}



function autosocial_facebook_advanced_client_id_render(){

    $redirectUrl = get_admin_url().'admin.php?page=autosocial';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Advanced - Custom Application','autosocial').'</h3>';

            echo '<em>'.__('Please ensure you set the redirect URL of your application to: ','autosocial').$redirectUrl.'</em>';

        echo '</td>';
    echo '</tr>';

    


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_advanced_client_id','Client Id','','text','','','','');

}

function autosocial_facebook_advanced_client_secret_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_advanced_client_secret','Client Secret','','text','','','','');

}






function autosocial_twitter_advanced_client_id_render(){

    $redirectUrl = get_admin_url().'admin.php?page=autosocial';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            echo '<div class="notice notice-error inline">
                <p><strong>'.__('We strongly recommend setting up a custom application for Twitter to ensure the upmost reliability. Before clicking the "Connect with Twitter" button below, please create a custom application <a target="_blank" href="https://developer.twitter.com/en/portal/dashboard">here</a>, and once you have created your application, enter in your client id and secret below, save the settings (important), and then click the "Connect with Twitter" button which will establish a connection between your Twitter application and your website so you can start sending tweets.','autosocial').'</strong></p>
            </div>';

            //lets output profile selection
            // echo '<h3>'.__('Advanced - Custom Application','autosocial').'</h3>';

            echo '<em>'.__('Please ensure that in your "User authentication settings/User authentication set up" (this is found at the bottom of the Settings tab of your Twitter application) that you have Read and write app permissions granted. Please ensure that for the "Type of App" that this is set to <strong>"Native App"</strong>. ','autosocial').'</em>';

            echo '<em>'.__('Please ensure you set the callback URI/redirect URL of your application to: ','autosocial').'<strong>'.$redirectUrl.'</strong></em> ';

            echo '<em>'.__('The free tier is fine. However, if you go on the basic tier this will enable you to manage tweets from the "Manage Posts" tab.','autosocial').'</em>';

        echo '</td>';
    echo '</tr>';

    


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_advanced_client_id','Client Id','','text','','','','');

}

function autosocial_twitter_advanced_client_secret_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_advanced_client_secret','Client Secret','','text','','','','');

}




function autosocial_google_my_business_advanced_client_id_render(){

    $redirectUrl = get_admin_url().'admin.php?page=autosocial';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Advanced - Custom Application','autosocial').'</h3>';

            echo '<em>'.__('Please ensure you set the redirect URL of your application to: ','autosocial').$redirectUrl.'</em>';

        echo '</td>';
    echo '</tr>';


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_advanced_client_id','Client Id','','text','','','','');

}

function autosocial_google_my_business_advanced_client_secret_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_advanced_client_secret','Client Secret','','text','','','','');

}





function autosocial_linkedin_advanced_client_id_render(){

    $redirectUrl = get_admin_url().'admin.php?page=autosocial';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Advanced - Custom Application','autosocial').'</h3>';

            echo '<em>'.__('Please ensure you set the redirect URL of your application to: ','autosocial').$redirectUrl.'</em>';

        echo '</td>';
    echo '</tr>';


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_linkedin_advanced_client_id','Client Id','','text','','','','');

}

function autosocial_linkedin_advanced_client_secret_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_linkedin_advanced_client_secret','Client Secret','','text','','','','');

}






function autosocial_linkedin_profile_selection_render(){

    //do connect button
    $state = urlencode (get_admin_url()); 
    
    $connectionDetails = autosocial_get_client_id_and_secret('LinkedIn');
    $client_id = $connectionDetails['client_id'];
    $redirect_uri = $connectionDetails['redirect_uri'];
    $scope = array('w_organization_social','r_organization_social','w_member_social','r_basicprofile','r_liteprofile','rw_organization_admin');
    $scope = implode('%20',$scope);


    echo '<tr class="autosocial_settings_row" valign="top">
            <td scope="row" colspan="2">';
            
                echo '<a style="margin-top:20px;" href="https://www.linkedin.com/oauth/v2/authorization?response_type=code&state='.$state.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id.'&scope='.$scope.'" class="button-secondary"><i class="fa fa-linkedin" aria-hidden="true"></i> '.__('Connect with LinkedIn', 'autosocial' ).'</a>';

                // echo '<a style="margin-top:20px;" href="https://www.linkedin.com/oauth/v2/authorization?response_type=code&state='.$state.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id.'&scope=w_member_social%20r_emailaddress%20r_liteprofile" class="button-secondary"><i class="fa fa-linkedin" aria-hidden="true"></i> '.__('Connect with LinkedIn', 'autosocial' ).'</a>';
                // $authOptions = get_option('autosocial_auth_settings');
                // var_dump($authOptions['linkedin_access_token']);

                echo '<a data="LinkedIn" class="test-connection-button button-secondary">Test Connection</a>';

        echo '</td>';
    
    echo '</tr>';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Activate the profile and/or companies you want to use','autosocial').' <a class="button-secondary refresh-data" data="LinkedIn" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

            echo autosocial_render_profile_selection('LinkedIn');

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_linkedin_profile_selection','Select Profile','','text','','','','hidden-setting');

}

function autosocial_linkedin_default_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Set the default profile and/or companies you want to use','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_linkedin_default_profile_selection'])){
                $selectionOfSelectionProfiles = $options['autosocial_linkedin_default_profile_selection'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('LinkedIn',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_linkedin_default_profile_selection','Select Default Profile','','text','','','','hidden-setting');

}


function autosocial_linkedin_default_share_message_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default share message','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_LINK','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_linkedin_default_share_message','','','shortcode','New Post: [POST_TITLE] - [POST_LINK]',$values,'','');

}








//do instagram

function autosocial_instagram_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">
            <td scope="row" colspan="2">';
            echo '<div class="notice notice-warning inline">
                <p><strong>'.__('Instagram\'s connection is taken directly from your Facebook accounts authentication. Note, only Business Instagram accounts will show up and work. Images shared to Instagram must follow Instagram image guidelines which are quite specific. For further details please go the "Help" tab and the question "Images are not being shared to Instagram".','autosocial').'</strong></p>
            </div>';

        echo '</td>';
    
    echo '</tr>';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Activate the profile and/or companies you want to use','autosocial').' <a class="button-secondary refresh-data" data="Instagram" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

            echo autosocial_render_profile_selection('Instagram');

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_instagram_profile_selection','Select Profile','','text','','','','hidden-setting');

}

function autosocial_instagram_default_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Set the default profile and/or companies you want to use','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_instagram_default_profile_selection'])){
                $selectionOfSelectionProfiles = $options['autosocial_instagram_default_profile_selection'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Instagram',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_instagram_default_profile_selection','Select Default Profile','','text','','','','hidden-setting');

}


function autosocial_instagram_default_share_message_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default share message','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_LINK','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_instagram_default_share_message','','','shortcode','New Post: [POST_TITLE] - [POST_LINK]',$values,'','');

}







function autosocial_twitter_connection_details_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //do connect button
            $state = urlencode (get_admin_url()); 

            $connectionDetails = autosocial_get_client_id_and_secret('Twitter');
            $client_id = $connectionDetails['client_id'];
            $redirect_uri = $connectionDetails['redirect_uri'];

            $scopes = array(
                'tweet.read',
                'tweet.write',
                'tweet.moderate.write',
                'users.read',
                'offline.access',
            );

            $scopes = implode('%20', $scopes);

            echo '<a style="margin-top:20px;" href="https://twitter.com/i/oauth2/authorize?response_type=code&client_id='.$client_id.'&redirect_uri='.$redirect_uri.'&scope='.$scopes.'&state='.$state.'&code_challenge=challenge&code_challenge_method=plain" class="button-secondary"><i class="fa fa-twitter" aria-hidden="true"></i> '.__('Connect with Twitter', 'autosocial' ).'</a>';

            echo '<a data="Twitter" class="test-connection-button button-secondary">Test Connection</a>';

        echo '</td>';
    
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_connection_details','Twitter Connection Details','','text','','','','hidden-setting');
}

// function autosocial_twitter_consumer_key_render(){
    
//     //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
//     autosocial_settings_code_generator('autosocial_twitter_consumer_key','Consumer Key','','text','','','','');
// }

// function autosocial_twitter_consumer_secret_render(){
//     //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
//     autosocial_settings_code_generator('autosocial_twitter_consumer_secret','Consumer Secret','','text','','','','');
// }

// function autosocial_twitter_access_token_render(){
//     //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
//     autosocial_settings_code_generator('autosocial_twitter_access_token','Access Token','','text','','','','');
// }

// function autosocial_twitter_access_token_secret_render(){
//     //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
//     autosocial_settings_code_generator('autosocial_twitter_access_token_secret','Access Token Secret','','text','','','','');
// }

function autosocial_twitter_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Activate the profile you want to use','autosocial').' <a class="button-secondary refresh-data" data="Twitter" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

            echo autosocial_render_profile_selection('Twitter');

        echo '</td>';
    echo '</tr>';


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_profile_selection','Select Profile','','text','','','','hidden-setting');

}

function autosocial_twitter_default_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Set the default profile you want to use','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_twitter_default_profile_selection'])){
                $selectionOfSelectionProfiles = $options['autosocial_twitter_default_profile_selection'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Twitter',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_default_profile_selection','Select Default Profile','','text','','','','hidden-setting');

}

function autosocial_twitter_default_share_message_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default share message','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_LINK','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_default_share_message','','','shortcode','New Post: [POST_TITLE] - [POST_LINK]',$values,'','');

}

function autosocial_twitter_share_as_link_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_twitter_share_as_link','Share posts as links even if there\'s an image','When sharing posts, pages and custom posts to Twitter, if your post has an image, it means that the link preview won\'t work in Twitter because the image will be displayed instead. If you want to always show the link preview instead of the image, check this box.','checkbox','','','','');

}






//do pinterest
function autosocial_pinterest_profile_selection_render(){

    //do connect button
    $state = urlencode (get_admin_url()); 

    $connectionDetails = autosocial_get_client_id_and_secret('Pinterest');
    $client_id = $connectionDetails['client_id'];
    $redirect_uri = $connectionDetails['redirect_uri'];

    // $url = 'https://api.pinterest.com/oauth/?response_type=code&scope=read_public,write_public&state='.$state.'&redirect_uri='.$redirect_uri.'&client_id='.$client_id;

    $url = 'https://www.pinterest.com/oauth/?client_id='.$client_id.'&redirect_uri='.$redirect_uri.'&response_type=code&scope=boards:read,boards:write,pins:read,pins:write,user_accounts:read&state='.$state;
    

    echo '<tr class="autosocial_settings_row" valign="top">
            <td scope="row" colspan="2">';



                echo '<a style="margin-top:20px;" href="'.$url.'" class="button-secondary"><i class="fa fa-pinterest" aria-hidden="true"></i> '.__('Connect with Pinterest', 'autosocial' ).'</a>';

                echo '<a data="Pinterest" class="test-connection-button button-secondary">Test Connection</a>';

        echo '</td>';
    
    echo '</tr>';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Activate the boards you want to use','autosocial').' <a class="button-secondary refresh-data" data="Pinterest" href="#"><i class="fa fa-refresh" aria-hidden="true"></i> '.__('Refresh Data','autosocial').'</a></h3>';

            echo autosocial_render_profile_selection('Pinterest');

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_profile_selection','Select Profile','','text','','','','hidden-setting');

}

function autosocial_pinterest_default_profile_selection_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Set the default boards you want to use','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_pinterest_default_profile_selection'])){
                $selectionOfSelectionProfiles = $options['autosocial_pinterest_default_profile_selection'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Pinterest',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_default_profile_selection','Select Default Profile','','text','','','','hidden-setting');

}

function autosocial_pinterest_default_share_message_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default pin content','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_LINK','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_default_share_message','','','shortcode','[POST_CONTENT]',$values,'','');

}


function autosocial_pinterest_default_share_title_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3 style="margin-bottom: -30px;">'.__('Set the default pin title','autosocial').'</h3>';

        echo '</td>';
    echo '</tr>';

    $values = array('POST_TITLE','POST_LINK','POST_EXCERPT','POST_CONTENT','POST_AUTHOR','POST_TAGS','POST_CATEGORIES','WEBSITE_TITLE');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_default_share_title','','','shortcode','[POST_TITLE]',$values,'','');

}


function autosocial_pinterest_default_board_render(){

    //get existing data should it exist
    $values = autosocial_get_pinterest_boards();

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_default_board','Select the Default Board','','select','',$values,'','');

}



function autosocial_pinterest_advanced_client_id_render(){

    $redirectUrl = get_admin_url().'admin.php?page=autosocial';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Advanced - Custom Application','autosocial').'</h3>';

            echo '<em>'.__('Please ensure you set the redirect URL of your application to: ','autosocial').$redirectUrl.'</em>';

        echo '</td>';
    echo '</tr>';

    


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_advanced_client_id','Client Id','','text','','','','');

}

function autosocial_pinterest_advanced_client_secret_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_pinterest_advanced_client_secret','Client Secret','','text','','','','');

}






function autosocial_order_id_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';
            
            echo '<div class="notice notice-warning inline"><p>'.__('Enter your order id and email below to receive automatic updates and support. One purchase of AutoSocial is limited to use on one website only.','autosocial').'</p></div>';        

        echo '</td>';
    
    echo '</tr>';



    

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_order_id','Order ID','You recieved this in your purchase confirmation email.','text','','','','');

}

function autosocial_order_email_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_order_email','Order Email','This is the email address you entered into the billing section upon checkout.','text','','','','');

}





function autosocial_hide_posts_column_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_hide_posts_column','Hide Posts Column','On your all posts/page/custom post page by default there\'s a handy new column which shows which posts/pages/custom post types have been shared and which ones haven\'t. You can use this setting to hide this column.','checkbox','','','','');

}

function autosocial_custom_post_type_and_page_enable_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Select what post types you want to share with','autosocial').'</h3>';

            echo '<div class="post_type_and_page_enable_wrapper">';
                echo autosocial_render_post_types();
            echo '</div>';    

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_custom_post_type_and_page_enable','','','text','Post','','','hidden-setting');

}


function autosocial_categories_disable_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Select what categories you want to disable sharing for','autosocial').'</h3>';

            echo '<div class="post_type_and_page_enable_wrapper">';
                echo autosocial_render_categories();
            echo '</div>';    

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_categories_disable','','','text','','','','hidden-setting');

}



function autosocial_enable_bit_ly_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_enable_bit_ly','Enable Bit.ly','Enable Bit.ly to shorten URL\'s','checkbox','','','','');

}

function autosocial_enable_datetimepicker_no_conflict_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_enable_datetimepicker_no_conflict','If you are using a date/time/datetime picker with ACF on your post edit page check this checkbox to ensure no conflicts','If you don\'t know what this means just leave this unchecked','checkbox','','','','');

}


function autosocial_bit_ly_access_token_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_bit_ly_access_token','Bit.ly Access Token (optional)','Enter your Bit.ly access token, otherwise leave blank to use our application.','text','','','','');

}

function autosocial_bit_ly_group_guid_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_bit_ly_group_guid','Bit.ly Group GUID (required if using your own application)','If you plan on using your own Bit.ly application enter in the Group GUID of your group. This is best found in the URL of the page when you login to Bit.ly and appears after "app.bitly.com/".','text','','','','');

}






//review settings



function autosocial_review_shortcode_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_shortcode','Your Shortcode','Copy and paste the following shortcode on any post or page to display reviews','html','','','','');

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';
            
        echo '<button style="margin-top: -5px; margin-bottom: 30px;" type="button" id="copy-shortcode" class="button-secondary"><i class="fa fa-clipboard" aria-hidden="true"></i> Copy Shortcode</button>';    

        echo '</td>';
    
    echo '</tr>';

    

}



function autosocial_facebook_default_profile_selection_review_render(){


    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';
            
            echo '<div style="margin-bottom: -10px;"class="notice notice-info inline"><p>'.__('Select the options below to build your shortcode','autosocial').'</p></div>';        

        echo '</td>';
    
    echo '</tr>';

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Select Facebook Pages','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_facebook_default_profile_selection_review'])){
                $selectionOfSelectionProfiles = $options['autosocial_facebook_default_profile_selection_review'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Facebook',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_facebook_default_profile_selection_review','Select Facebook Pages','','text','','','','review-setting hidden-setting');

}

function autosocial_google_my_business_default_profile_selection_review_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';

            //lets output profile selection
            echo '<h3>'.__('Select Google My Business Locations','autosocial').'</h3>';

            $options = get_option('autosocial_settings');
            if(isset($options['autosocial_google_my_business_default_profile_selection_review'])){
                $selectionOfSelectionProfiles = $options['autosocial_google_my_business_default_profile_selection_review'];
            } else {
                $selectionOfSelectionProfiles = '';   
            }

            echo autosocial_render_default_profile_selection('Google My Business',$selectionOfSelectionProfiles);

        echo '</td>';
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_google_my_business_default_profile_selection_review','Select Google My Business Locations','','text','','','','review-setting hidden-setting');

}







function autosocial_review_type_render(){

    $values = array('slider' => 'Slider','grid' => 'Grid');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_type','Type','Do you want the reviews displayed as a slider of grid','select','Slider',$values,'','review-setting');

}

function autosocial_review_minimum_stars_render(){


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_minimum_stars','Minimum Stars','','number','5','','','review-setting');

}

function autosocial_review_sort_by_render(){

    $values = array('date' => 'Date','random' => 'Random','stars' => 'Stars');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_sort_by','Sort By','','select','Date',$values,'','review-setting');

}

function autosocial_review_sort_order_render(){

    $values = array('desc' => 'Descending','asc' => 'Ascending');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_sort_order','Sort Order','','select','Descending',$values,'','review-setting');

}


function autosocial_review_amount_of_reviews_render(){


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_amount_of_reviews','Amount of Reviews','','number','5','','','review-setting');

}

function autosocial_review_visible_slides_render(){


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_visible_slides','Visible Slides','','number','1','','','review-setting slider-setting');

}

function autosocial_review_slides_to_scroll_render(){


    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_slides_to_scroll','Slides to Scroll','','number','1','','','review-setting slider-setting');

}

function autosocial_review_autoplay_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_autoplay','Autoplay','','checkbox','','','','review-setting slider-setting');

}


function autosocial_review_autoplay_speed_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_autoplay_speed','Slide Autoplay Speed (Milliseconds)','','number','5000','','','review-setting slider-setting');

}

function autosocial_review_slide_transition_render(){

    $values = array('slide' => 'Slide','fade' => 'Fade');

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_slide_transition','Slide Transition','','select','Slide',$values,'','review-setting slider-setting');

}

function autosocial_review_read_more_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_read_more','Read More','If you have very large reviews you may want to enable the read more option which will reduce the size of long reviews and provide a read more link','checkbox','','','','review-setting');

}

function autosocial_review_read_more_words_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_read_more_words','Amount of words to show','The amount of words you want to show initially before the read more kicks in','number','10','','','review-setting read-more-setting');

}

function autosocial_review_show_stars_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_show_stars','Show Stars','','checkbox','','','','review-setting');

}

function autosocial_review_show_date_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_show_date','Show Date','','checkbox','','','','review-setting');

}

function autosocial_review_show_quote_symbols_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_show_quote_symbols','Show Quote Symbols','','checkbox','','','','review-setting');

}

function autosocial_review_show_photos_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_show_photos','Show Photos','','checkbox','','','','review-setting');

}

function autosocial_review_show_social_network_icons_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_show_social_network_icons','Show Social Network Icons','','checkbox','','','','review-setting');

}

function autosocial_review_text_colour_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_text_colour','Text Color','','color','','','','review-setting');

}


function autosocial_review_enable_structured_data_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_enable_structured_data','Enable Structured Data','Structured data helps with SEO, learn more about this <a target="_blank" href="https://yoast.com/what-is-structured-data/">here</a>','checkbox','','','','review-setting');

}

function autosocial_review_structured_data_name_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_structured_data_name','Business/Product Name','Enter the name of the business or product that is going to be reviewed','text','','','','review-setting structured-data-setting');

}

function autosocial_review_structured_data_logo_render(){

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_structured_data_logo','Business Logo or Product Image','This should contain a URL of the file','text','','','','review-setting structured-data-setting');

}



function autosocial_review_block_reviews_render(){

    echo '<tr class="autosocial_settings_row" valign="top">';
        echo '<td scope="row" colspan="2">';
            
            echo '<div style="margin-top: 30px;"class="notice notice-info inline"><p>'.__('Select the reviews you want to manually exclude from the display','autosocial').'</p></div>';      
            

            //get selected profiles
            $settingsName = 'autosocial_settings';

            //get options
            $options = get_option($settingsName);
    
            if(isset($options['autosocial_review_block_reviews'])){
                $settingToArray = explode(",",$options['autosocial_review_block_reviews']);     
            } else {
                $settingToArray = array();    
            }


            if(isset($options['autosocial_facebook_default_profile_selection_review']) || isset($options['autosocial_google_my_business_default_profile_selection_review'])){

                $facebook_profiles = $options['autosocial_facebook_default_profile_selection_review'];
                $google_profiles = $options['autosocial_google_my_business_default_profile_selection_review'];

                if(strlen($facebook_profiles) > 0 || strlen($google_profiles) > 0){

                    $all_reviews = array();

                    //lets do facebook reviews to start with
                    if(strlen($facebook_profiles)>0){

                        //explode the data
                        $facebook_exploded = explode(',',$facebook_profiles);

                        foreach($facebook_exploded as $profile){

                            $review_data = autosocial_get_reviews($profile,'facebook');

                            foreach($review_data as $key => $value){
                                $all_reviews[$key] = $value;
                            }
                            

                        }
                    }

                    //lets do GoogleMyBusiness reviews
                    if(strlen($google_profiles)>0){

                        //explode the data
                        $google_my_business_exploded = explode(',',$google_profiles);

                        foreach($google_my_business_exploded as $profile){

                            $review_data = autosocial_get_reviews($profile,'google my business');

                            foreach($review_data as $key => $value){
                                $all_reviews[$key] = $value;
                            }

                        }
                    }

                    // var_dump($all_reviews);

                    //first we need to check whether the array is empty
                    if(!empty($all_reviews)){

                        // var_dump($all_reviews);

                        //show reviews
                        $html = '<ul class="autosocial-reviews">';

                            foreach($all_reviews as $review_key => $review_data){

                                //establish the right class
                                if(in_array($review_key, $settingToArray)){
                                    $listClass = '';
                                    $iconClass = 'fa-eye-slash';
                                } else {
                                    $listClass = 'selected'; 
                                    $iconClass = 'fa-eye';
                                }

                                $quote = $review_data['quote'];

                                if(strlen($quote)>0){
                                    $html .= '<li class="review-list-item '.$listClass.'" data="'.$review_key.'">';

                                        $html .= '<div class="review-image">';
                                            //image
                                            if(strlen($review_data['photo'])>0){
                                                $html .= '<span class="review-image"><img src="'.$review_data['photo'].'" /></span>';
                                            }
                                        $html .= '</div>';


                                        $html .= '<div class="review-information">';

                                            


                                            //name
                                            $html .= '<span class="review-reviewer">'.$review_data['name'].'</span>';


                                            //show network
                                            if($review_data['network'] == 'facebook'){
                                                $html .= '<i class="review-network fa fa-facebook" aria-hidden="true"></i>';
                                            }

                                            if($review_data['network'] == 'google my business'){
                                                $html .= '<i class="review-network fa fa-google" aria-hidden="true"></i>';
                                            }


                                            //date
                                            $niceDate = strtotime($review_data['date']);
                                            $niceDate = date_i18n(get_option('date_format'),$niceDate);
                                            $html .= '<span class="review-date">'.$niceDate.'</span>';

                                            //stars
                                            $stars = '';

                                            for ($i = 0 ; $i < $review_data['rating']; $i++){ 
                                                $stars .= '<i class="fa fa-star" aria-hidden="true"></i>'; 
                                            }

                                            $html .= '<span class="review-rating">'.$stars.'</span>';

                                            
                                            //quote
                                            $html .= '<span class="review-comment">'.$quote.'</span>';
                            
                                        $html .= '</div>';
                            
                                        //render appropriate icon
                                        $html .= '<i class="review-selected-icon fa '.$iconClass.'" aria-hidden="true"></i>';


                                    $html .= '</li>';
                                }

                                    

                            }

                        $html .= '</ul>';  

                        echo $html;

                    } //if not empty

                } else {
                    echo '<div style="margin-top: 30px;"class="notice notice-error inline"><p>'.__('You need to select a profile first before being able to block our reviews. Please select a profile, save the settings and then refresh the page.','autosocial').'</p></div>';    
                }


            } else {
                echo '<div style="margin-top: 30px;"class="notice notice-error inline"><p>'.__('You need to save the settings first before being able to block our reviews','autosocial').'</p></div>';       
            }

    

        echo '</td>';
    
    echo '</tr>';

    //$id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass
    autosocial_settings_code_generator('autosocial_review_block_reviews','Blocked Reviews','','text','','','','review-setting hidden-setting');

}





//function to generate settings rows
function autosocial_settings_code_generator($id,$label,$description,$type,$default,$parameter,$importantNote,$rowClass) {
    

    $settingsName = 'autosocial_settings';

    //get options
    $options = get_option($settingsName);
    
    //value
    if(isset($options[$id])){  
        $value = $options[$id];    
    } elseif(strlen($default)>0) {
        $value = $default;   
    } else {
        $value = '';
    }
    
    
    //the label
    echo '<tr class="'.$settingsName.'_row '.$rowClass.'" valign="top">';
    echo '<td scope="row">';
    echo '<label for="'.$id.'">'.__($label, 'autosocial' );
    if(strlen($description)>0){
        echo ' <i class="fa fa-info-circle" aria-hidden="true"></i>';
        echo '<p class="hidden"><em>'.$description.'</em></p>';
    }
    if(strlen($importantNote)>0){
        echo '</br><span style="color: #CC0000;">';
        echo $importantNote;
        echo '</span>';
    } 
    echo '</label>';
    
    
    
    if($type == 'shortcode') {
        echo '</br>';
        
        foreach($parameter as $shortcodevalue){
            echo '<a value="['.$shortcodevalue.']" class="autosocial_append_buttons">['.$shortcodevalue.']</a>';
        }       
    }
    
    if($type == 'textarea-advanced') {
        echo '</br>';
        
        foreach($parameter as $shortcodevalue){
            echo '<a value="['.$shortcodevalue.']" data="'.$id.'" class="autosocial_append_buttons_advanced">['.$shortcodevalue.']</a>';
        }       
    }
    
    
    if($type == 'shortcode-advanced') {
        echo '</br>';
        
        foreach($parameter as $shortcodevalue){
            echo '<a value="'.$shortcodevalue[1].'" class="autosocial_append_buttons">'.$shortcodevalue[0].'</a>';
        }       
    }
    
    

    //the setting    
    echo '</td><td>';
    
    //text
    if($type == "text"){
        echo '<input type="text" class="regular-text" name="'.$settingsName.'['.$id.']" id="'.$id.'" value="'.$value.'">';     
    }

    //html
    if($type == "html"){
        echo '<input type="text" class="regular-text" name="'.$settingsName.'['.$id.']" id="'.$id.'" value="'.htmlentities($value).'">';     
    }
    
    //select
    if($type == "select"){
        echo '<select name="'.$settingsName.'['.$id.']" id="'.$id.'">';
        
        foreach($parameter as $x => $xvalue){
            echo '<option value="'.$x.'" ';
            if($x == $value) {
                echo 'selected="selected"';    
            }
            echo '>'.$xvalue.'</option>';
        }
        echo '</select>';
    }
    
    
    //checkbox
    if($type == "checkbox"){
        echo '<label class="switch">';
        echo '<input type="checkbox" id="'.$id.'" name="'.$settingsName.'['.$id.']" ';
        echo checked($value,1,false);
        echo 'value="1">';
        echo '<span class="slider round"></span></label>';
    }
        
    //color
    if($type == "color"){ 
        echo '<input name="'.$settingsName.'['.$id.']" id="'.$id.'" type="text" value="'.$value.'" class="autosocial-color-field" data-default-color="'.$default.'"/>';    
    }
    
    //page
    if($type == "page"){
        $args = array(
            'echo' => 0,
            'selected' => $value,
            'name' => $settingsName.'['.$id.']',
            'id' => $id,
            'show_option_none' => $default,
            'option_none_value' => "default",
            'sort_column'  => 'post_title',
            );
        
            echo wp_dropdown_pages($args);     
    }
    
    //textarea
    if($type == "textarea" || $type == "shortcode" || $type == "shortcode-advanced"){
        echo '<textarea cols="46" rows="3" name="'.$settingsName.'['.$id.']" id="'.$id.'">'.$value.'</textarea>';
    }
    
    
    //textarea-advanced
//    if($type == "textarea-advanced"){
//        wp_editor(html_entity_decode(stripslashes($value)), $id, $settings = array(
//            'textarea_name' => 'idea_push_settings['.$id.']',
//            'drag_drop_upload' => true,
//            'textarea_rows' => 7,  
//            )
//        );
//    }  
    
    
    if($type == "textarea-advanced"){
        if(isset($value)){    
            wp_editor(html_entity_decode(stripslashes($value)), $id, $settings = array(
            'wpautop' => false,    
            'textarea_name' => $settingsName.'['.$id.']',
            'drag_drop_upload' => true,
            'textarea_rows' => 7, 
            ));    
        } else {
            wp_editor("", $id, $settings = array(
            'wpautop' => false,    
            'textarea_name' => $settingsName.'['.$id.']',
            'drag_drop_upload' => true,
            'textarea_rows' => 7,
            ));         
        }
    }
    
    //number
    if($type == "number"){
        echo '<input type="number" class="regular-text" name="'.$settingsName.'['.$id.']" id="'.$id.'" value="'.$value.'">';     
    }

    echo '</td></tr>';

}









?>