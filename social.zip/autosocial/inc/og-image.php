<?php
    /**
    * 
    *
    *
    * Adds the og:image header tag if enabled in the settings.
    */
    add_action('wp_head', 'autosocial_add_header_tag');

    function autosocial_add_header_tag(){
        //get options
        $options = get_option('autosocial_settings');

        if( isset($options['autosocial_enable_og_image']) ){
            if( !is_archive() ){
                global $post;
                $post_id = $post->ID;
                $post_image = autosocial_get_post_image($post_id);
                echo '<meta property="og:image" content="'.$post_image.'" />';  
            }
        }
    }
?>