<?php

    /**
    * 
    *
    *
    * The below function runs code every 30 minutes and shares and posts that need to be shared if delayed mode is active
    */
    add_action( 'admin_init', 'autosocial_delayed_mode_process' );
    function autosocial_delayed_mode_process() { 

        //get options
        $options = get_option('autosocial_settings');

        //check transient
        $transient_name = 'autosocial_delayed_mode_check';

        if( !get_transient($transient_name) ){

            //set the transient immidiately to prevent re-running
            if( isset($options['autosocial_delayed_mode_delay']) && $options['autosocial_delayed_mode_delay'] > 0  ){
                $minutes_to_run = $options['autosocial_delayed_mode_delay'];
            } else {
                $minutes_to_run = 30;
            }

            set_transient($transient_name, true, 60 * $minutes_to_run);

            //check if delayed mode is active
            if( isset($options['autosocial_activate_delayed_mode']) ){

                $option_name = 'autosocial_delayed_mode_posts';

                if( !get_option($option_name) ){
                    update_option($option_name, array());
                }

                $current_option = get_option($option_name);

                //only run if there's posts
                if( $current_option ){

                    foreach($current_option as $key => $value){
                        //we want to delete the item from the array
                        unset($current_option[$key]);
                        //now we want to do the share
                        autosocial_send_post($value); 

                    } //end foreach

                    //update the option with what should be a blank array
                    update_option($option_name, $current_option);

                } //end current option check
            } //end if delayed mode active
        } //end if transient exists
    }
    

?>