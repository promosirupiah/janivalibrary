<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/**
* 
*
*
* Tab memory
*/
function autosocial_tab_memory() { 

	if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }
    
    $tab = sanitize_text_field($_POST['tab']);
    
    set_transient('autosocial_tab_memory', $tab, DAY_IN_SECONDS*3 );
    
    echo $tab;
    wp_die();   

}
add_action( 'wp_ajax_tab_memory', 'autosocial_tab_memory' );
/**
* 
*
*
* Get accounts/profiles/locations etc.
*/
function autosocial_account_data($network){

    // $returnArray = array();
    $sortArray = array();
    $dataArray = array();

    $options = get_option('autosocial_settings');
    $authOptions = get_option('autosocial_auth_settings');
    $networkNameTranslated = autosocial_translate_network_name($network);
    $transientName = 'autosocial_account_data_'.$networkNameTranslated;
    $existingData = get_transient($transientName);

    if($existingData !== false){
        //the data exists so return it
        return $existingData;
    } else {


        if($network == 'Facebook'){


            //unfortunately publishing to personal profiles is now deprecated as Facebook only allows sharing to pages.

            //do profile
            // $response = wp_remote_get( 'https://graph.facebook.com/v8.0/me?access_token='.$authOptions['facebook_access_token']);

            // if(wp_remote_retrieve_response_code($response) == 200){

            //     $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            //     $pushArray = array('id'=>$decodedBody['id'],'name'=>$decodedBody['name'],'type'=>'Profile');

            //     //lets try and get profile image
            //     $response = wp_remote_get( 'https://graph.facebook.com/v8.0/'.$decodedBody['id'].'/picture?access_token='.$authOptions['facebook_access_token'].'&redirect=0');


            //     if(wp_remote_retrieve_response_code($response) == 200){
            //         $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

            //         $profileImage = $decodedBody['data']['url'];

            //         if(isset($profileImage) && strlen($profileImage)>0){
            //             $pushArray['image'] = $profileImage;
            //         } else {
            //             $pushArray['image'] = '';    
            //         }

            //     }    

            //     array_push($returnArray,$pushArray);

            // }


            //do company
            $response = wp_remote_get( 'https://graph.facebook.com/v16.0/me/accounts?access_token='.$authOptions['facebook_access_token'].'&limit=99999');

            if(wp_remote_retrieve_response_code($response) == 200){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                foreach($decodedBody['data'] as $page){

                    $pushArray = array('id'=>$page['id'],'name'=>$page['name'],'type'=>'Page','access_token'=>$page['access_token']);
                    

                    //lets try and get profile image
                    $response = wp_remote_get( 'https://graph.facebook.com/v8.0/'.$page['id'].'/picture?access_token='.$authOptions['facebook_access_token'].'&redirect=0');


                    if(wp_remote_retrieve_response_code($response) == 200){
                        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                        $profileImage = $decodedBody['data']['url'];

                        if(isset($profileImage) && strlen($profileImage)>0){
                            $pushArray['image'] = $profileImage;
                        } else {
                            $pushArray['image'] = '';      
                        }

                    }   

                    // array_push($returnArray,$pushArray);
                    //add to sort array
                    $sortArray[$page['id']] = $page['name'];
                    //add to data array
                    $dataArray[$page['id']] = $pushArray;

                }
                // var_dump($decodedBody);
            }    
        } //end facebook




        //do instagram
        if($network == 'Instagram'){

            //do company
            $response = wp_remote_get( 'https://graph.facebook.com/v12.0/me/accounts?access_token='.$authOptions['facebook_access_token'].'&limit=99999&fields=instagram_business_account,name,access_token');

            if(wp_remote_retrieve_response_code($response) == 200){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                foreach($decodedBody['data'] as $page){

                    //only continue if we can find an Instagram Business account
                    if(array_key_exists('instagram_business_account',$page)){
                        $instagram_id = $page['instagram_business_account']['id'];


                        //now that we have the id, we need to get the name of the page
                        $pushArray = array('id'=>$instagram_id,'name'=>$page['name'],'type'=>'Page','access_token'=>$page['access_token']);


                        //lets try and get profile image
                        $response = wp_remote_get( 'https://graph.facebook.com/v8.0/'.$page['id'].'/picture?access_token='.$authOptions['facebook_access_token'].'&redirect=0');


                        if(wp_remote_retrieve_response_code($response) == 200){
                            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                            $profileImage = $decodedBody['data']['url'];

                            if(isset($profileImage) && strlen($profileImage)>0){
                                $pushArray['image'] = $profileImage;
                            } else {
                                $pushArray['image'] = '';      
                            }

                        }  

                        //add to sort array
                        $sortArray[$instagram_id] = $page['name'];
                        //add to data array
                        $dataArray[$instagram_id] = $pushArray;
                    }

                    
                    

                     
                    

                }
                // var_dump($decodedBody);
            }    
        } //end instagram







        if($network == 'Google My Business'){

            //get accounts
            $url = 'https://mybusinessaccountmanagement.googleapis.com/v1/accounts?pageSize=100';

            $response = wp_remote_get( $url , array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token('Google My Business'),
                ),
            ));

            

            if(wp_remote_retrieve_response_code($response) == 200){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                foreach($decodedBody['accounts'] as $account){

                    $accountName = $account['name'];



                    //someone may have more than 100 locations, so we need to loop through the locations using a do while loop

                    $next_page_token_query = '';

                    do {
                    
                        //get locations for each account
                        $url = 'https://mybusinessbusinessinformation.googleapis.com/v1/'.$accountName.'/locations?readMask=storeCode,regularHours,name,languageCode,title,phoneNumbers,categories,storefrontAddress,websiteUri,regularHours,specialHours,serviceArea,labels,adWordsLocationExtensions,latlng,openInfo,metadata,profile,relationshipData,moreHours&pageSize=100'.$next_page_token_query;

                        $response = wp_remote_get( $url, array(
                            'headers' => array(
                                'Authorization' => 'Bearer '.autosocial_get_access_token('Google My Business'),
                            ),
                        ));

                        if(wp_remote_retrieve_response_code($response) == 200){

                            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                            if(array_key_exists('nextPageToken',$decodedBody)){
                                $next_page_token_query = '&pageToken='.$decodedBody['nextPageToken'];
                            } else {
                                $next_page_token_query = '';
                            }

                            
                            //we are going to collect some diagnostic info here we can use for diagnosing issues with particular accounts
                            set_transient($transientName.'_diagnostic',$decodedBody,YEAR_IN_SECONDS*5);

                            //add each location to array
                            if(array_key_exists('locations',$decodedBody)){
                                foreach($decodedBody['locations'] as $location){


                                    //check to see if api enabled
                                    // if( array_key_exists('isLocalPostApiDisabled',$location['locationState']) && $location['locationState']['isLocalPostApiDisabled'] == true ){
                                    //     //do nothing
                                    // } else {

                                        $locationName = $accountName.'/'.$location['name'];

                                        $pushArray = array('id'=>$locationName,'name'=>$location['title'],'type'=>'Location','image'=>'');

                                        // array_push($returnArray,$pushArray); 
                                        //add to sort array
                                        $sortArray[$locationName] = $location['title'];
                                        //add to data array
                                        $dataArray[$locationName] = $pushArray;
                                    } //end isLocalPostApiDisabled check

                        

                                // } //end for each location
                            }
                        } else {//end if 200 success 
                            $next_page_token_query = '';
                        }

                    } while (strlen($next_page_token_query)>0);


                } //end foreach account
            } //end if 200 success  
        } //end google my business


        if($network == 'LinkedIn'){


            $profileUrl = 'https://api.linkedin.com/v2/me?projection=(id,firstName,lastName,vanityName,profilePicture(displayImage~:playableStreams))';

            $response = wp_remote_get($profileUrl, array(
                'headers' => array(
                    'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                    'X-RestLi-Protocol-Version' => '2.0.0',
                ),
            ));

            $status = wp_remote_retrieve_response_code($response);

            if($status == 200){
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                $pushArray = array(
                    'id'=>$decodedBody['id'],
                    'name'=>$decodedBody['firstName']['localized']['en_US'].' '.$decodedBody['lastName']['localized']['en_US'],
                    'type'=>'person',
                    'image'=>$decodedBody['profilePicture']['displayImage~']['elements'][0]['identifiers'][0]['identifier']
                );

                // array_push($returnArray,$pushArray);

                //add to sort array
                $sortArray[$decodedBody['id']] = $decodedBody['firstName']['localized']['en_US'].' '.$decodedBody['lastName']['localized']['en_US'];
                //add to data array
                $dataArray[$decodedBody['id']] = $pushArray;

            }  



            //do companies
            // $companyUrl = 'https://api.linkedin.com/rest/organizationAcls?q=roleAssignee&projection=(elements*(*,roleAssignee~(localizedFirstName,%20localizedLastName),%20organization~(localizedName,%20logoV2(original~%3AplayableStreams))))&role=ADMINISTRATOR&count=100';

            $companyUrl = 'https://api.linkedin.com/rest/organizationAcls?q=roleAssignee&role=ADMINISTRATOR&count=100';
            $response = wp_remote_get($companyUrl, array(
                'headers' => array(
                    'Linkedin-Version' => '202305',
                    'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                    'X-RestLi-Protocol-Version' => '2.0.0',
                ),
            ));

            $status = wp_remote_retrieve_response_code($response);

            if($status == 200){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);


                $company_ids = array();


                foreach($decodedBody['elements'] as $company){


                    $organisation_id = $company['organization'];

                    //we need to parse this
                    $organisation_exploded = explode(':', $organisation_id);

                    array_push($company_ids,$organisation_exploded[3]);

                }   


                if(!empty($company_ids)){

                    $companies_as_comma_list = implode(',',$company_ids);

                    //now lets get further info
                    $url = 'https://api.linkedin.com/rest/organizations?ids=List('.$companies_as_comma_list.')';
                    $response = wp_remote_get( $url, array(
                        'headers' => array(
                            'Authorization' => 'Bearer '.$authOptions['linkedin_access_token'],
                            'Linkedin-Version' => '202310',
                            'X-Restli-Protocol-Version' => '2.0.0',
                        ),
                    ));

                    $status = wp_remote_retrieve_response_code($response);

                    if($status == 200){
                        $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                        foreach($decodedBody['results'] as $company_id => $company_info){

                            $pushArray = array(
                                'id' => 'urn:li:organization:'.$company_id,
                                'name' => $company_info['localizedName'],
                                'type' => 'organization',
                            );

                            //lets not worry about images for now
                            // if( array_key_exists('logoV2', $company['organization~']) ){
                            //     $pushArray['image'] = $company['organization~']['logoV2']['original~']['elements'][0]['identifiers'][0]['identifier'];
                            // } else {
                                $pushArray['image'] = '';    
                            // }
                            
                            //add to sort array
                            $sortArray['urn:li:organization:'.$company_id] = $company_info['localizedName'];
                            //add to data array
                            $dataArray['urn:li:organization:'.$company_id] = $pushArray;


                        }
                        
                    }



                }


                

                
                



            } 

        } //end linkedin


        if($network == 'Twitter'){


            if (is_array($options) && array_key_exists('autosocial_twitter_connection_details', $options)) {


                $url = 'https://api.twitter.com/2/users/me?user.fields=id,username,profile_image_url';

                $response = wp_remote_get( $url , array(
                    'headers' => array(
                        'Authorization' => 'Bearer '.autosocial_get_access_token('Twitter'),
                    ),
                ));
                
                $json_response = wp_remote_retrieve_response_code($response);
        
                if($json_response == 200) {

                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                    
                    $decodedBody = $decodedBody['data'];

                    $id = $decodedBody['id'];
                    $username = $decodedBody['username'];
                    $profile_image_url = $decodedBody['profile_image_url'];

                    $pushArray = array(
                        'id' => $id,
                        'name' => $username,
                        'type' => 'Profile',
                        'image' => $profile_image_url
                    );

                    //add to sort array
                    $sortArray[$id] = $username;
                    //add to data array
                    $dataArray[$id] = $pushArray;
                }
            }
        } //end twitter


        if($network == 'Pinterest'){

            // $profileUrl = 'https://api.pinterest.com/v1/me/?fields=id,first_name,last_name,username,image';

            //we are going to get boards not accounts
            $url = 'https://api.pinterest.com/v5/boards';

            $response = wp_remote_get($url, array(
                'headers' => array(
                                'Authorization' => 'Bearer '.autosocial_get_access_token('Pinterest'),
                            ),  
            ));

            $status = wp_remote_retrieve_response_code($response);

            if($status == 200){

                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

                foreach($decodedBody['items'] as $boards){
                    $pushArray = array(
                        'id'=> $boards['id'],
                        'name'=> $boards['name'].' - '.$boards['description'],
                        'type'=> 'board',
                        'image'=> '',
                        // 'image'=> $decodedBody['data']['image']['60x60']['url']
                    );
    
                    // array_push($returnArray,$pushArray);
                    //add to sort array
                    $sortArray[$boards['id']] = $boards['name'];
                    //add to data array
                    $dataArray[$boards['id']] = $pushArray;
                }
                
            }  


        } //end pinterest





        $transientExpiry = YEAR_IN_SECONDS*5;

        //lets be a bit smarter and sort the array alphabetically by value
        asort($sortArray);
        //create the return array
        $returnArray = array();
        //loop through the sort array
        foreach($sortArray as $key => $value){
            //key is identifier, value is name
            //lets get the data for this item and add it to the return array
            $data_for_key = $dataArray[$key];
            array_push($returnArray,$data_for_key);
        }

        set_transient($transientName,$returnArray,$transientExpiry);

    }

    

    return $returnArray;

}    
/**
* 
*
*
* Refresh account data
*/
function autosocial_refresh_account_data(){

    if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    $network = sanitize_text_field($_POST['network']);

    $networkNameTranslated = autosocial_translate_network_name($network);
    $transientName = 'autosocial_account_data_'.$networkNameTranslated;

    //delete the transient
    delete_transient($transientName);

    echo 'SUCCESS';


    wp_die();

}
add_action( 'wp_ajax_refresh_account_data', 'autosocial_refresh_account_data' );
/**
* 
*
*
* render post types
*/
function autosocial_render_post_types(){

    $html = '';

    if(get_option('autosocial_settings')){

        //get options
        $options = get_option('autosocial_settings');
        $selectedOptions = $options['autosocial_custom_post_type_and_page_enable'];

        if(isset($selectedOptions)){
            $selectedOptionsAsArray = explode(',',$selectedOptions);
        } else {
            $selectedOptionsAsArray = array('Post');      
        }

        $postTypes = array('Post','Page');

        $args = array(
            'public'   => true,
            '_builtin' => false
        );

        $output = 'names'; // 'names' or 'objects' (default: 'names')
        $operator = 'and'; // 'and' or 'or' (default: 'and')

        $customPostTypes = get_post_types( $args, $output, $operator );

        // var_dump($customPostTypes);

        foreach($customPostTypes as $key=>$value){
            array_push($postTypes,ucwords($key));
        }

        //enable this to be filtered
        $postTypes = apply_filters('autosocial_change_post_types', $postTypes);


        //start output
        $html .= '<ul class="profile-activation">';

            foreach($postTypes as $postType){


                if(in_array($postType,$selectedOptionsAsArray)){
                    $listClass = 'selected';
                    $icon = 'fa-check-circle-o';
                } else {
                    $listClass = '';
                    $icon = 'fa-times-circle-o';
                }

                $html .= '<li class="profile-item '.$listClass.'" data="'.$postType.'" data-option-name="autosocial_custom_post_type_and_page_enable">';

                    //information
                    $html .= '<div class="profile-information">';
                        $html .= '<span class="profile-name">'.$postType.'</span>';
                    $html .= '</div>';

                    //icon
                    $html .= '<i class="profile-icon fa '.$icon.'" aria-hidden="true"></i>';

                $html .= '</li>';   

            }

        $html .= '</ul>';
    }

    return $html;

}
/**
* 
*
*
* render categories
*/
function autosocial_render_categories(){

    $html = '';

    if(get_option('autosocial_settings')){
        //get options
        $options = get_option('autosocial_settings');
        $selectedOptions = $options['autosocial_categories_disable'];

        if(isset($selectedOptions)){
            $selectedOptionsAsArray = explode(',',$selectedOptions);
        } else {
            $selectedOptionsAsArray = array('');      
        }

        $categories = get_categories( array(
            'orderby' => 'name',
            'hide_empty' => 0,
        ));
        

        //start output
        $html .= '<ul class="profile-activation">';

            foreach($categories as $category){

                $categoryName = $category->name;
                // $categoryId = $category->term_id;

                if(in_array($categoryName,$selectedOptionsAsArray)){
                    $listClass = 'selected';
                    $icon = 'fa-check-circle-o';
                } else {
                    $listClass = '';
                    $icon = 'fa-times-circle-o';
                }

                $html .= '<li class="profile-item '.$listClass.'" data="'.$categoryName.'" data-option-name="autosocial_categories_disable">';

                    //information
                    $html .= '<div class="profile-information">';
                        $html .= '<span class="profile-name">'.$categoryName.'</span>';
                    $html .= '</div>';

                    //icon
                    $html .= '<i class="profile-icon fa '.$icon.'" aria-hidden="true"></i>';

                $html .= '</li>';   

            }

        $html .= '</ul>';
    }

    return $html;

}
/**
* 
*
*
* Function to translate network name
*/
function autosocial_translate_network_name($network){

    $network = strtolower($network);
    $network = str_replace(' ','_',$network);   

    return $network;
}   
/**
* 
*
*
* Function to render share history - used on post page and post edit page
*/
function autosocial_share_history_table($postId){

    //start output
    $html = '';

    $html .= '';

    $existingLog = get_post_meta($postId,'autosocial_share_history',true);

    //loop through log items
    //makeup array('time'=>$currentTime,'network'=>$network,'url'=>$url);

    //get wordpress date and time options
    $dateFormat = get_option('date_format');
    $timeFormat = get_option('time_format');

    $html .= '<table class="autosocial-log-table">';
        $html .= '<thead>';

            $html .= '<tr>';

                $html .= '<th>'.__('Time','autosocial').'</th>';
                $html .= '<th>'.__('Network','autosocial').'</th>';
                $html .= '<th>'.__('Profile','autosocial').'</th>';
                $html .= '<th>'.__('Link','autosocial').'</th>';

            $html .= '</tr>';

        $html .= '</thead>';
        $html .= '<tbody>';

        foreach($existingLog as $logItem){

            $time = $logItem['time'];
            $network = $logItem['network'];
            $profile = $logItem['profile'];
            $url = $logItem['url'];

            //get nice time
            $niceTime = date($dateFormat.' '.$timeFormat,$time);

            //get nice profile name
            $accountData = autosocial_account_data($network);

            foreach($accountData as $profileItem){
                
                if($profileItem['id'] == $profile){
                    $niceProfileName = $profileItem['name'];
                }

            }


            $html .= '<tr>';

                $html .= '<td>'.$niceTime.'</td>';
                $html .= '<td>'.$network.'</td>';
                $html .= '<td>'.$niceProfileName.'</td>';
                $html .= '<td><a target="_blank" href="'.$url.'"><i class="log-item-link fa fa-external-link" aria-hidden="true"></i></a></td>';

            $html .= '</tr>';

        }

        $html .= '</tbody>';
    $html .= '</table>';

    

    return $html;
}   
/**
* 
*
*
* Function to build the Twitter account detail list items
*/
function autosocial_twitter_account_builder($optionValue){

    //start output 
    $html = '';

    // $html .= $optionValue;

    $html .= '<ul class="twitter-account-detail-builder">';

    
    if(strlen($optionValue)>0){
        //explode the options
        $optionExploded = explode('|||',$optionValue);

        foreach($optionExploded as $twitterAccount){
            //explode the details into individual parameters
            $twitterAccountConnectionParameters = explode('^^',$twitterAccount);

            $html .= autosocial_twitter_account_builder_item_render($twitterAccountConnectionParameters[0],$twitterAccountConnectionParameters[1],$twitterAccountConnectionParameters[2],$twitterAccountConnectionParameters[3],$twitterAccountConnectionParameters[4]);

        }


    } else {
        //just create a blank item
        $html .= autosocial_twitter_account_builder_item_render('Put some name/identifier here for the account','','','','');
    }

    $html .= '</ul>';

    return $html;

}   
/**
* 
*
*
* Function to render the Twitter list item
*/
function autosocial_twitter_account_builder_item_render($accountName,$consumerKey,$consumerSecret,$accessToken,$accessTokenSecret){

    //create list item with 4 options
    //start outout
    $html = '';

    $html .= '<li>';

        $html .= '<span class="twitter-connection-detail-input-container">';

                $html .= '<label for="accountName">'.__('Account Name','autosocial').'</label>';       

                $html .= '<input type="text" class="twitterAccountName regular-text" name="twitter-connection-detail-input" name="accountName" value="'.$accountName.'">';

                //lets add our icons here to edit, add and delete options
                $html .= '<i class="twitter-connection-details-icon edit-twitter-connection-details fa fa-pencil" aria-hidden="true"></i>';
                $html .= '<i class="twitter-connection-details-icon delete-twitter-connection-details fa fa-trash" aria-hidden="true"></i>';
                $html .= '<i class="twitter-connection-details-icon add-twitter-connection-details fa fa-plus" aria-hidden="true"></i>';

        $html .= '</span>';



        $html .= '<div class="twitter-connection-details-hidden">';
            $html .= '<span class="twitter-connection-detail-input-container">';

                $html .= '<label for="consumerKey">'.__('Consumer Key','autosocial').'</label>';       

                $html .= '<input type="text" class="twitterConsumerKey regular-text" name="twitter-connection-detail-input" name="consumerKey" value="'.$consumerKey.'">';

            $html .= '</span>';

            $html .= '<span class="twitter-connection-detail-input-container">';

                $html .= '<label for="consumerSecret">'.__('Consumer Secret','autosocial').'</label>';

                $html .= '<input type="text" class="twitterconsumerSecret regular-text" name="twitter-connection-detail-input" name="consumerSecret" value="'.$consumerSecret.'">';
            
            $html .= '</span>';

            $html .= '<span class="twitter-connection-detail-input-container">';

                $html .= '<label for="accessToken">'.__('Access Token','autosocial').'</label>';

                $html .= '<input type="text" class="twitteraccessToken regular-text" name="twitter-connection-detail-input" name="accessToken" value="'.$accessToken.'">';

            $html .= '</span>';    

            $html .= '<span class="twitter-connection-detail-input-container">';

                $html .= '<label for="accessTokenSecret">'.__('Access Token Secret','autosocial').'</label>';

                $html .= '<input type="text" class="twitteraccessTokenSecret regular-text" name="twitter-connection-detail-input" name="accessTokenSecret" value="'.$accessTokenSecret.'">';

            $html .= '</span>'; 
        $html .= '</div>';


    $html .= '</li>';

    return $html;

}    
/**
* 
*
*
* this function returns an associative array with the profile id as the key and the connection details in the array
* We do this because we don't associate the connection details with profile selection and it helps backward compatibility
*/
// function autosocial_twitter_connection_details_for_profile(){

//     //get the settings
//     $options = get_option('autosocial_settings');
//     //get twitter options
//     $twitterOptions = $options['autosocial_twitter_connection_details'];

//     //create return array with details
//     $returnArray = array();

//     $optionExploded = explode('|||',$twitterOptions);

//     foreach($optionExploded as $twitterAccount){

//         //do further explosion
//         $twitterAccountConnectionParameters = explode('^^',$twitterAccount);

//         $consumer_key = $twitterAccountConnectionParameters[1];
//         $consumer_secret = $twitterAccountConnectionParameters[2];
//         $access_token = $twitterAccountConnectionParameters[3];
//         $access_token_secret = $twitterAccountConnectionParameters[4];  

//         $connection = new TwitterOAuth($consumer_key, $consumer_secret, $access_token, $access_token_secret);   
//         $content = $connection->get("account/verify_credentials"); 

//         if ($connection->getLastHttpCode() == 200) {

//             $returnArray[$content->id] = array('consumer_key'=>$consumer_key,'consumer_secret'=>$consumer_secret,'access_token'=>$access_token,'access_token_secret'=>$access_token_secret);

//         }

//     }    

//     return $returnArray;
// }    
/**
* 
*
*
* Delete Plugin Updates transient/option
*/
function autosocial_delete_plugin_updates_transient() { 

	if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }

    delete_option('_site_transient_update_plugins');
    // delete_transient('_site_transient_update_plugins');

    echo 'SUCCESS';
    wp_die();   

}
add_action( 'wp_ajax_delete_plugin_updates_transient', 'autosocial_delete_plugin_updates_transient' );
/**
* 
*
*
* Gets timezone
*/
function autosocial_get_timezone_string() { 

    $timeZoneString = get_option('timezone_string');

    if( empty($timeZoneString) ){

        //we need to lookup GMT offset and convert it to a string
        $gmtOffset = get_option('gmt_offset');

        $time_zone_list = array("Pacific/Tongatapu"=>'13', "Pacific/Fiji"=>'12', "Asia/Magadan"=>'11', "Asia/Vladivostok"=>'10', "Australia/Darwin"=>'9.5', "Asia/Yakutsk"=>'9', "Asia/Taipei"=>'8', "Asia/Krasnoyarsk"=>'7', "Asia/Rangoon"=>'6.5', "Asia/Colombo"=>'6', "Asia/Katmandu"=>'5.75', "Asia/Calcutta"=>'5.5', "Asia/Karachi"=>'5',  "Asia/Kabul"=>'4.5', "Asia/Tbilisi"=>'4',  "Asia/Tehran"=>'3.5', "Africa/Nairobi"=>'3',  "Asia/Jerusalem"=>'2', "Africa/Malabo"=>'1', "Europe/London"=>'0', "Atlantic/Cape_Verde"=>'-1', "America/Buenos_Aires"=>'-3',  "America/Santiago"=>'-4', "America/Indianapolis"=>-'5', "America/Mexico_City"=>'-6', "America/Denver"=>'-7', "America/Los_Angeles"=>'-8', "America/Anchorage"=>'-9', "Pacific/Honolulu"=>'-10', "Pacific/Midway"=>'-11');
        

        //flip the array
        $time_zone_listFlipped = array_flip($time_zone_list);

        return $time_zone_listFlipped[$gmtOffset];

    } else {
        return $timeZoneString;
    }

}   
/**
* 
*
*
* Delete plugin settings
*/
function autosocial_delete_autosocial_plugin_settings() { 

	if (!current_user_can('manage_options')) {
        wp_die();    
    }
    

    //delete options
    delete_option( 'autosocial_settings' );
    delete_option( 'autosocial_auth_settings' );

    //delete transients
    delete_transient( 'autosocial_gmb_access_token' );
    delete_transient( 'autosocial_schedule_check' );

    delete_transient( 'autosocial_account_data_linkedin' );
    delete_transient( 'autosocial_account_data_google_my_business' );
    delete_transient( 'autosocial_account_data_twitter' );
    delete_transient( 'autosocial_account_data_facebook' );
    delete_transient( 'autosocial_account_data_instagram' );
    delete_transient( 'autosocial_account_data_pinterest' );

    delete_transient( 'autosocial_account_data_linkedin_snos' );
    delete_transient( 'autosocial_account_data_twitter_snos' );
    delete_transient( 'autosocial_account_data_google_my_business_snos' );
    delete_transient( 'autosocial_account_data_facebook_snos' );
    delete_transient( 'autosocial_account_data_instagram_snos' );
    delete_transient( 'autosocial_account_data_pinterest_snos' );

    //lets reset the options
    add_option( 'autosocial_settings', array() );
    add_option( 'autosocial_auth_settings', array() );

    echo 'SUCCESS';

    wp_die();   

}
add_action( 'wp_ajax_delete_autosocial_plugin_settings', 'autosocial_delete_autosocial_plugin_settings' ); 
/**
* 
*
*
* Get Pinterest Board
*/
function autosocial_get_pinterest_boards(){

    $transientName = 'autosocial_board_data_pinterest';
    $values = get_transient($transientName);

    if($values !== false){
        
    } else {
    
        $authOptions = get_option('autosocial_auth_settings');
    
        if(get_option('autosocial_auth_settings') && strlen($authOptions['pinterest_access_token']) > 0){
    
            $profileUrl = 'https://api.pinterest.com/v1/me/boards/';
    
            $response = wp_remote_get($profileUrl, array(
                'headers' => array(
                    'Authorization' => 'Bearer '.$authOptions['pinterest_access_token'],
                ),
            ));
        
            $status = wp_remote_retrieve_response_code($response);
    
    
            //below is for testing purposes to get around pinterest api limit
            // $values = array('Portfolio' => 'Portfolio');
            // $transientExpiry = HOUR_IN_SECONDS*1;
            // set_transient($transientName,$values,$transientExpiry);
    
            if($status == 200){
    
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
    
                $values = array();
    
                //loop through data
                foreach($decodedBody['data'] as $board){
                    $board_name = $board['name'];
                    $values[$board_name] = $board_name;
                }
    
                $transientExpiry = HOUR_IN_SECONDS*1;
    
                set_transient($transientName,$values,$transientExpiry);
        
            } else {
                $values = array();
            }
        }
    }

    return $values;
}
/**
* 
*
*
* Save global share message
*/
function autosocial_save_global_share_message() { 

	if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }
    
    $network = sanitize_text_field($_POST['network']);
    $message = sanitize_text_field($_POST['message']);
    
    //now lets update the AutoSocial settings
    $option_name = 'autosocial_settings';
    $current_option = get_option($option_name);

    $current_option['autosocial_'.$network.'_default_share_message'] = $message;

    update_option($option_name,$current_option);

    echo 'SUCCESS';
    wp_die();   

}
add_action( 'wp_ajax_save_share_message_global', 'autosocial_save_global_share_message' );
/**
* 
*
*
* Save post type share message
*/
function autosocial_save_post_type_share_message() { 

	if (!current_user_can('autosocial_manage_options')) {
        wp_die();    
    }
    
    $network = sanitize_text_field($_POST['network']);
    $message = sanitize_text_field($_POST['message']);
    $post_type = sanitize_text_field($_POST['post_type']);
    
    //now lets update the AutoSocial settings
    $option_name = 'autosocial_share_message_custom_post_templates';

    if(!get_option($option_name)){
        add_option($option_name, array());
    }

    $current_option = get_option($option_name);

    $current_option[$post_type.'_'.$network] = $message;

    update_option($option_name,$current_option);

    echo 'SUCCESS';
    wp_die();   

}
add_action( 'wp_ajax_save_share_message_post_template', 'autosocial_save_post_type_share_message' );









?>