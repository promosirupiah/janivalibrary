<?php

/**
* 
*
*
* function to get reviews for a particular location
*/
function autosocial_get_reviews($profile,$network) {

    if($network == 'facebook'){

        //do something
        $transientName = 'autosocial_reviews_facebook_'.$profile;
        
        $getTransient = get_transient($transientName);
            
        //if the transient exists
        if ($getTransient != false){

            return $getTransient;

        } else {

            //get options
            $options = get_option( 'autosocial_settings' );
            $authOptions = get_option('autosocial_auth_settings');
            

            $getAccountData = autosocial_account_data('facebook');

            //get the access token for the profile
            foreach($getAccountData as $accountItem){
            
                if($accountItem['id'] == $profile){
                    $profileAccessToken = $accountItem['access_token'];
                }
            }

            //get new reviews
            $url = 'https://graph.facebook.com/v4.0/'.$profile.'/ratings?access_token='.$profileAccessToken;

            $response = wp_remote_get( $url );

            if(200 == wp_remote_retrieve_response_code( $response )) {

                $jsondata = json_decode($response['body'],true); 
                $reviews = $jsondata['data'];

                $data_to_store = array();

                $counter = 1;

                //loop through reviews
                foreach($reviews as $review){

                    
                    $temp_data =  array(
                        'date' => $review['created_time'], //2018-03-12T05:17:09+0000
                        'name' => $review['reviewer']['name'], //Michael Francis McDermott
                        'quote' => $review['review_text'], //The process of building the website with Martin
                        'rating' => $review['rating'], //5
                        'network' => 'facebook',
                    );

                    //try and get photo
                    $transientNameProfileImage = 'autosocial_facebook_'.$review['reviewer']['id'];
                    
                    $getTransient = get_transient($transientNameProfileImage);
                        
                    //if the transient exists
                    if ($getTransient != false){

                        $reviewer_image = $getTransient;

                    } else {

                        $response = wp_remote_get( 'https://graph.facebook.com/v4.0/'.$review['reviewer']['id'].'/picture?type=normal&access_token='.$profileAccessToken.'&redirect=0' ); 
                        
                        if(200 == wp_remote_retrieve_response_code( $response )) {
                            $jsondata = json_decode($response['body'],true); 
                            $reviewer_image = $jsondata['data']['url'];

                            set_transient($transientNameProfileImage,$reviewer_image,DAY_IN_SECONDS*365);
                        }    
                    }   

                    //if the image exists
                    if(isset($reviewer_image)){
                        //then add to the array
                        $temp_data['photo'] = $reviewer_image;
                    }

                    //facebook doesn't give us an id so we will create one using a counter and the profile id
                    $data_to_store[$profile.'-'.$review['reviewer']['id']] = $temp_data;

                    $counter++;
                        
                }

                set_transient($transientName,$data_to_store,DAY_IN_SECONDS*1);
                
                return $data_to_store;



            }    



        }
    }


    if($network == 'google my business'){

        //parse location
        $locationParsed = explode('/',$profile);
        $justLocation = $locationParsed[3];

        $transientName = 'autosocial_reviews_gmb_'.$justLocation;
        
        $getTransient = get_transient($transientName);
            
        //if the transient exists
        if ($getTransient != false){

            return $getTransient;

        } else {

            //we need to get the review

            $url = 'https://mybusiness.googleapis.com/v4/'.$profile.'/reviews?pageSize=200';

            $response = wp_remote_get($url, array(
                'headers' => array(
                    'Authorization' => 'Bearer '.autosocial_get_access_token('Google My Business'),
                ),
            ));

            if(200 == wp_remote_retrieve_response_code( $response )) {

                //create return variable
                $data_to_store = array();

                $jsondata = json_decode($response['body'],true); 

                if(is_array($jsondata)){
                    $reviews = $jsondata['reviews'];

                    if($reviews){
                        //loop through reviews
                        foreach($reviews as $review){

                            //lets translate the rating because GMB stores it funny
                            $rating = $review['starRating'];

                            if($rating == 'FIVE'){
                                $rating = 5;
                            } elseif ($rating == 'FOUR'){
                                $rating = 4;
                            } elseif ($rating == 'THREE'){
                                $rating = 3;
                            } elseif ($rating == 'TWO'){
                                $rating = 2;
                            } else {
                                $rating = 1;
                            }

                            $data_to_store[$review['reviewId']] = array(
                                'date' => $review['createTime'], //2019-07-29T10:43:20.397Z
                                'name' => $review['reviewer']['displayName'], //Michael Francis McDermott
                                'quote' => $review['comment'], //The process of building the website with Martin
                                'rating' => $rating, //5
                                'network' => 'google my business',
                                'photo' => $review['reviewer']['profilePhotoUrl'], //https://lh6.googleusercontent.com/-HsSUxw3hs74/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rfMblDJX5yb2gzJDHZiXozPwLfhkw/c0x00000000-cc-rp-mo/photo.jpg
                            );
                                
                        }

                        set_transient($transientName,$data_to_store,DAY_IN_SECONDS*1);
                    }
                }
    
                return $data_to_store;

            }


        }    

    }



}


// shortcode
function autosocial_review_shortcode( $atts ) {

    //enqueue scripts and styles
    //scripts
    wp_enqueue_script( 'autosocial-slick-script');
    wp_enqueue_script( 'autosocial-script');
    // wp_enqueue_script('autosocial-read-more');

    //styles
    wp_enqueue_style( 'autosocial-style');
    wp_enqueue_style( 'autosocial-font-awesome');
    wp_enqueue_style( 'autosocial-slick-style');

    //sample data below
    // [autosocial-reviews facebook="543741625743839" google-my-business="accounts/118011856790315060764/locations/3025353635870429896" type="slider" minimum-stars="5" sort-by="date" sort-order="descending" review-amount="10" slides-page="1" slides-scroll="1" autoplay="true" speed="5000" transition="slide" read-more="true" show-stars="true" show-date="true" show-quotes="true" show-photos="true"]
    // [autosocial-reviews facebook="" google-my-business="accounts/118011856790315060764/locations/3025353635870429896" type="slider" minimum-stars="5" sort-by="date" sort-order="desc" review-amount="5" slides-page="3" slides-scroll="3" autoplay="true" speed="5000" transition="slide" read-more="true" read-more-words="10" show-stars="true" show-date="true" show-quotes="true" show-photos="true" show-social-network-icons="true" text-color="" structured-data-enable="false" structured-data-name="" structured-data-logo="" ]

    $a = shortcode_atts( array(
        'facebook' => '',
        'google-my-business' => '', 
        'type' => 'slider', //also accepts false 
        'minimum-stars' => 5,
        'sort-by' => 'date', //also accepts random and stars
        'sort-order' => 'desc', //also accepts asc
        'review-amount' => 200,
        'slides-page' => 1, 
        'slides-scroll' => 1, 
        'autoplay' => 'false', //also accepts true 
        'speed' => 5000,
        'transition' => 'slide', //also accepts fade
        'read-more' => 'true', //also accepts false 
        'read-more-words' => 30, //also accepts false 
        'show-stars' => 'true', //also accepts false 
        'show-date' => 'true', //also accepts false 
        'show-quotes' => 'true', //also accepts false 
        'show-photos' => 'true', //also accepts false 
        'show-social-network-icons' => 'false', //also accepts true 
        'text-color' => '', 
        'structured-data-enable' => 'false', //also accepts true 
        'structured-data-name' => get_bloginfo('name'), 
        'structured-data-logo' => '', 
    ), $atts );

    return autosocial_review_shortcode_content($a['facebook'],$a['google-my-business'],$a['type'],intval($a['minimum-stars']),$a['sort-by'],$a['sort-order'],intval($a['review-amount']),intval($a['slides-page']),intval($a['slides-scroll']),$a['autoplay'],intval($a['speed']),$a['transition'],$a['read-more'],intval($a['read-more-words']),$a['show-stars'],$a['show-date'],$a['show-quotes'],$a['show-photos'],$a['text-color'],$a['structured-data-enable'],$a['structured-data-name'],$a['structured-data-logo'],$a['show-social-network-icons']);

}
add_shortcode('autosocial-reviews', 'autosocial_review_shortcode');







function autosocial_review_shortcode_content($facebook,$GoogleMyBusiness,$type,$minimumStars,$sortBy,$sortOrder,$reviewAmount,$slidesPage,$slidesScroll,$autoplay,$speed,$transition,$readMore,$readMoreWords,$showStars,$showDate,$showQuotes,$showPhotos,$textColor,$structuredDataEnable,$structuredDataName,$structuredDataLogo,$showSocialNetworkIcons) {
    
    $html = '';


    //foreach review we want to get: the name, the picture, the quote, the star rating, the date

    //store all review data in one place
    $all_reviews = array();


    //lets do facebook reviews to start with
    if(strlen($facebook)>0){

        //explode the data
        $facebook_exploded = explode(',',$facebook);

        foreach($facebook_exploded as $profile){

            $review_data = autosocial_get_reviews($profile,'facebook');

            foreach($review_data as $key => $value){
                $all_reviews[$key] = $value;
            }
            

        }
    }

    //lets do GoogleMyBusiness reviews
    if(strlen($GoogleMyBusiness)>0){

        //explode the data
        $google_my_business_exploded = explode(',',$GoogleMyBusiness);

        foreach($google_my_business_exploded as $profile){

            $review_data = autosocial_get_reviews($profile,'google my business');

            foreach($review_data as $key => $value){
                $all_reviews[$key] = $value;
            }

        }
    }

    // var_dump($all_reviews);

    //first we need to check whether the array is empty
    if(!empty($all_reviews)){





        //create sorting array
        $sorting_array = array();

        //get blocked reviews
        $settings_name = 'autosocial_settings';
        $options = get_option($settings_name);

        if(isset($options['autosocial_review_block_reviews'])){
            $blocked_reviews = $options['autosocial_review_block_reviews'];
            $blocked_reviews = explode(',',$blocked_reviews);
        } else {
            $blocked_reviews = array();
        }
        



        //lets loop through the reviews
        foreach($all_reviews as $review_key => $review_data){
            //lets first exclude reviews which don't meet the minimum star requirements
            if($review_data['rating'] >= $minimumStars){

                //now lets remove reviews which have been manually blocked
                if(!in_array($review_key,$blocked_reviews)){
                    if($sortBy == 'date' || $sortBy == 'random'){
                        $sorting_array[$review_key] = $review_data['date'];
                    } else {
                        //we are going to sort by stars
                        $sorting_array[$review_key] = $review_data['rating'];  
                    }
                }
            }
        }

        //lets sort the array - this can work for sorting by date and stars
        if($sortOrder == 'desc'){
            arsort($sorting_array);
        } else {
            asort($sorting_array);
        }


        //if the order is random lets shuffle things around
        if($sortBy == 'random'){
            $shuffleKeys = array_keys($sorting_array);
            shuffle($shuffleKeys);
            $sortedReviews = array();
            foreach($shuffleKeys as $key) {
                $sortedReviews[$key] = $sorting_array[$key];
            } 
            $sorting_array = $sortedReviews;
        }

        // var_dump($sorting_array);


        //if fade is necessary
        if($transition == 'fade'){
            $transition = '"fade": true,"cssEase": "linear",';
        } else {
            $transition = '"fade": false,';    
        }

        //output custom css for readmore version
        if($readMore == 'true'){
            $html .= '<style>.autosocial-reviews .slick-list {height: auto !important;}</style>';
        }

        if(strlen($textColor)>0){
            $html .= '<style>.autosocial-review-text-color {color: '.$textColor.' !important;}</style>';       
        }

        if($type == "slider"){
            $html .= '<div class="autosocial-reviews make-me-slick" data-slick=\'{"adaptiveHeight": true,"arrows": false,"dots": true,"infinite": true,"autoplaySpeed":'.$speed.',"slidesToShow":'.$slidesPage.', "slidesToScroll":'.$slidesScroll.', "autoplay":'.$autoplay.'    }\'>';
        } else {
            $html .= '<div class="autosocial-reviews">';    
        }


        $count = 1;
        $count_of_reviews = 0;
        $sum_of_review_ratings = 0;

        $ld_json_reviews = array();

        //now lets actually output the reviews
        foreach($sorting_array as $key => $value){

            if($count++ > $reviewAmount) break;

            

            //only show comment if comment has a length
            if(strlen($all_reviews[$key]['quote']) > 0){

                $html .= '<div class="autosocial-review" data="'.$key.'" data-network="'.$all_reviews[$key]['network'].'">';
                    $html .= '<div class="autosocial-review-inner">';
                        //show quotes
                        if($showQuotes == 'true'){
                            $quoteLeft = '<i class="review-quotes fa fa-quote-left" aria-hidden="true"></i>';
                            $quoteRight = '<i class="review-quotes fa fa-quote-right" aria-hidden="true"></i>';
                        } else {
                            $quoteLeft = '';
                            $quoteRight = '';    
                        }

                        //do readmore and quote
                        $quote = $all_reviews[$key]['quote'];

                        if($readMore == 'true'){
                            
                            //turn the quote into an array
                            $quote_exploded = explode(' ',$quote);
                            $quote_shown = array();
                            $quote_hidden = array();

                            foreach($quote_exploded as $word_number => $word){
                                if($word_number < $readMoreWords){
                                    array_push($quote_shown,$word);
                                } else {
                                    array_push($quote_hidden,$word);
                                }
                            }

                            //put the arrays back to sentences
                            $quote_shown_imploded = implode(' ',$quote_shown);
                            $quote_hidden_imploded = implode(' ',$quote_hidden);

                            $quote = $quote_shown_imploded;
                            $quote .= ' <span class="autosocial-read-more-text">'.$quote_hidden_imploded.'</span>';
                            $quote .= ' <a href="#" class="autosocial-read-more">'.__('Read more','autosocial').'</a>';
                            $quote .= ' <a href="#" class="autosocial-read-less">'.__('Read less','autosocial').'</a>';


                        }
                        
                        $html .= '<span class="review-comment autosocial-review-text-color">'.$quoteLeft.apply_filters( 'autosocial_change_review_text', $quote ).$quoteRight.'</span>';
                            

                        //display stars only if we have to
                        if($showStars == "true"){

                            $stars = '';
                            for ($i = 0 ; $i < $all_reviews[$key]['rating']; $i++){ 
                                $stars .= '<i class="fa fa-star" aria-hidden="true"></i>'; 
                            }

                            $html .= '<span class="review-rating">'.$stars.'</span>';
                        }

                        //we will show the social network icon here...i am not sure if this is the best spot but we will await feedback
                        if($showSocialNetworkIcons == "true"){
                            if($all_reviews[$key]['network'] == 'google my business'){
                                $html .= '<img class="review-social-network-icon review-social-network-icon-google" src="'.plugins_url( '/images/google-icon.png', __FILE__ ).'">';
                            }
                            
                            if($all_reviews[$key]['network'] == 'facebook'){
                                $html .= '<img class="review-social-network-icon review-social-network-icon-facebook" src="'.plugins_url( '/images/facebook-icon.png', __FILE__ ).'">';
                            }
                        }
                        

                        //we will show image here i think
                        if($showPhotos == "true"){
                            $html .= '<span class="review-image"><img src="'.$all_reviews[$key]['photo'].'" /></span>';
                        }

                        //display reviewer name
                        $html .= '<span class="review-reviewer autosocial-review-text-color">'.$all_reviews[$key]['name'].'</span>';

                        //display date only if we have to
                        if($showDate == "true"){

                            $niceDate = strtotime($all_reviews[$key]['date']);
                            $niceDate = date_i18n(get_option('date_format'),$niceDate);

                            $html .= '<span class="review-date autosocial-review-text-color">'.$niceDate.'</span>';
                        }  
                
                        $html .= '</div>';
                $html .= '</div>';

                //put date in the right format
                $original_date = strtotime($all_reviews[$key]['date']);
                $original_date = date('Y-m-d',$original_date);
                
                array_push($ld_json_reviews,array(
                    '@type' => 'Review',
                    'author' => $all_reviews[$key]['name'],
                    'datePublished' => $original_date,
                    'description' => $all_reviews[$key]['quote'],
                    'reviewRating' => array(
                        '@type' => 'Rating',
                        'bestRating' => '5',
                        'ratingValue' => ''.$all_reviews[$key]['rating'],
                        'worstRating' => '1',
                    ),
                ));

                //add to count of reviews for json
                $count_of_reviews++;
                $sum_of_review_ratings += $all_reviews[$key]['rating'];

            } //end if quote exists

        }


        $html .= '</div>'; //end autosocial-reviews wrapper
    }

    if($count_of_reviews == 0){
        $rating_value = 5;            
    } else {
        $rating_value =  $sum_of_review_ratings/$count_of_reviews;
    }

    $ld_json = array(
        '@context' => 'http://schema.org',
        '@type' => 'LocalBusiness',
        'name' => $structuredDataName,
        'url' => get_home_url(),
        'aggregateRating' => array(
            '@type' => 'AggregateRating',  
            'ratingValue' => ''.$rating_value,  
            'reviewCount' => ''.$count_of_reviews,   
        ),
        'review' => $ld_json_reviews,
    );

    //only add image if it exists
    if(strlen($structuredDataLogo)>0){
        $ld_json['image'] = $structuredDataLogo;
    }

    //only output structured data if enabled
    if($structuredDataEnable == 'true'){
        //here is we will output the ld+json
        $html .= '<script type="application/ld+json">';
            $html .= json_encode($ld_json);
        $html .= '</script>';
    }

    

    return $html;

}    


?>