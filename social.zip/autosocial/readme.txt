=== AutoSocial ===
* Contributors: northernbeacheswebsites
* Donate link: https://northernbeacheswebsites.com.au/product/donate-to-northern-beaches-websites/
* Tags: social media auto publish, social network auto publish
* Requires at least: 4.0
* Requires PHP: 5.2.4
* Tested up to: 6.2.2
* Stable tag: 7.14
* License: GPLv2 or later
* License URI: http://www.gnu.org/licenses/gpl-2.0.html


Automatically publish your posts, pages and custom posts to a range of social networks.

== Description ==

Automatically publish your posts, pages and custom posts to a range of social networks.


== Installation ==

There are a couple of methods for installing and setting up this plugin.

= Upload Manually =

1. Download and unzip the plugin
2. Upload the 'autosocial' folder into the '/wp-content/plugins/' directory
3. Go to the Plugins admin page and activate the plugin


== Frequently Asked Questions ==

Frequently asked questions can be found under the help tab on the plugin settings page. 

== Screenshots ==


== Changelog ==

= 7.14 =
* Fix for LinkedIn pages

= 7.13 =
* Updating of Facebook permissions

= 7.12 =
* Fix for LinkedIn manage posts

= 7.11 =
* Filter to change the image shared for a post

= 7.10 =
* Fix to hold Twitter authentication longer

= 7.9 =
* Respect for original characters using little text format for LinkedIn Shares

= 7.8 =
* Better parsing of LinkedIn share message into little text format

= 7.7 =
* Support for new shortcode tag [POST_CATEGORIES]

= 7.6 =
* More work fine tuning LinkedIn posting

= 7.5 =
* Gets more LinkedIn companies

= 7.4 =
* Bug fix for square brackets in share message for LinkedIn

= 7.3 =
* Bug fix for LinkedIn Company sharing

= 7.2 =
* Fix for when sharing to personal LinkedIn profiles

= 7.1 =
* Bug fixes for LinkedIn shares

= 7.0 =
* Major update for latest LinkedIn API
* Major update for latest Twitter API - please read instructions in Twitter tab for the latest instructions

= 6.32 =
* Fix for 6.31

= 6.31 =
* Removal of quirk around Twitter upload directory

= 6.30 =
* Fix for LinkedIn when sharing no link, but still sharing an image

= 6.29 =
* Fix for bug when trying to share to LinkedIn with no link and specific general setting enabled

= 6.28 =
* Updated Twitter count when using the share now or share later feature

= 6.27 =
* New option to output og:image header tag
* Bug fix for featureimage override

= 6.26 =
* Addition of classes so shortcode tags can be hidden in admin interface to save space in metabox on edit page

= 6.25 =
* Removal of temporary diagnostic info

= 6.24 =
* Bug fixes for scheduled post functionality caused by 6.22 update

= 6.23 =
* Bug fixes for Pinterest

= 6.22 =
* Fix for multiple shares with Gutenberg

= 6.21 =
* Updated instructions for Twitter

= 6.20 =
* Big fix caused by version 6.18 and working with draft posts and the do not share checkbox

= 6.19 =
* Filter to allow do not share checkbox to be checked by default

= 6.18 =
* Resolves dont share issues with Gutenberg

= 6.17 =
* Further fixing of PHP errors caused by review shortcode

= 6.16 =
* Fixing potential fatal error caused by review shortcode with no reviews

= 6.15 =
* Improved instructions for creating a Twitter app

= 6.14 =
* New setting to share links to Twitter as oppose to images 

= 6.13 =
* Addition of new action for the purpose of sending emails when authentication is about to expire

= 6.12 =
* Addition of new filter

= 6.11 =
* Bug fixes

= 6.10 =
* Force checking of plugin updates

= 6.9 =
* Makes hashtags work in Instagram

= 6.8 =
* Finally a working solution for line breaks in the plugin!

= 6.7 =
* Addition of fail and success actions when a post share fails or succeeds to post.

= 6.6 =
* Fix for version 6.5

= 6.5 =
* Addition of line break support

= 6.4 =
* Addition of new delayed mode feature - please see the general settings tab for more information

= 6.3 =
* Important error fixes for Google My Business caused by version 6.2

= 6.2 =
* Support for API changes to Google My Business
* PHP bug fixes for metabox

= 6.1 =
* PHP bug fixes
* Addition of new shortcode [POST_TAGS] which outputs post tags as hashtags

= 6.0 =
* Support for Pinterest!

= 5.2 =
* New setting to prevent autosharing if desired

= 5.1 =
* Small fix so delete all settings includes the deleting of Instagram settings
* Ensures caption works for posts for Instagram

= 5.0 =
* Support for Instagram
* Increased text length to 3000 for LinkedIn

= 4.30 =
* Updated messaging regarding WooCommerce integration with the plugin

= 4.29 =
* Filter to delay sharing

= 4.28 =
* Link sharing fix for LinkedIn

= 4.27 =
* Fix for -11 GMT timezone

= 4.26 =
* Fix for sharing images to Facebook without a link when using the Share Now and Schedule feature

= 4.25 =
* Fix for sharing images to LinkedIn without a link when using the Share Now and Schedule feature

= 4.24 =
* Fix for Facebook manage posts

= 4.23 =
* New filter to filter the message before sending - please see faq for more details

= 4.22 =
* Fix for structured data output on page when the user elects it to be false

= 4.21 =
* Updates to the latest Facebook Graph API 

= 4.20 =
* Fix for error messages when authenticating with GMB

= 4.19 =
* Ability to set default image via filter

= 4.18 =
* Tested with WordPress 5.5.1
* Removal of Google My Business profile images to keep within API limits and to improve performance
* Support for more than 100 Google My Business locations

= 4.17 =
* Allowance of foreign characters via the share now function

= 4.16 =
* new review shortcode option so you can display the social network of the review

= 4.15 =
* Bug fix caused by 4.13 where locations/profiles with the same name would be ignored

= 4.14 =
* Further compatibility improvements with bootstrap date time picker

= 4.13 =
* Now you can get more than 25 Facebook pages
* All pages are now listed alphabetically

= 4.12 =
* Further refinement to Twitter message count

= 4.11 =
* Ignores URLs in character count for Twitter

= 4.10 =
* Ability to share longer tweets which may have URLs

= 4.9 =
* Further bug fixes

= 4.8 =
* Fixed bug with multiple custom meta data in share message

= 4.7 =
* We now show custom fields in the metabox on the post page to make life easier
* You can now set share message templates for different post types

= 4.6 =
* Now support for custom fields (meta) in the share message template! Read the FAQ for more info.

= 4.5 =
* Added a new capability so you can give other user roles the ability to edit AutoSocial settings

= 4.4 =
* Extension of the update in version 4.3 to cover GMB and LinkedIn

= 4.3 =
* If the facebook post does not contain a link, then we won't send a link with the Facebook post

= 4.2 =
* Better translation support

= 4.1 =
* Now the plugin is translatable - we have included a .pot file in the languages folder

= 4.0 =
* Now the plugin has Pinterest support - however still waiting for app to be approved

= 3.2 =
* Introduced a no conflict mode for those using the ACF date/time/datetime picker on their posts

= 3.1 =
* Improved read more functionality
* More logical review settings
* You can now change the text colour of the reviews
* Now supports structured data for reviews to help improve SEO

= 3.0 =
* New review functionality

= 2.4 =
* Added a new filter so advanced users can specify which posts they want to share or not share to social networks

= 2.3 =
* Fixed up LinkedIn test connection button issue

= 2.2 =
* Changes to the notice buttons so it's more obvious you need to click the original connection buttons when re-authenticating not the buttons on the notice itself

= 2.1 =
* New features for Google My Business to create product posts from WooCommerce and event posts from The Events Calendar plugin

= 2.0 =
* We now use version 2.0 of LinkedIn's API! This means LinkedIn profiles and companies now show images in the UI which is nice and you can delete LinkedIn posts from the manage posts section
* Testing with WordPress 5.2.1

= 1.27 =
* We now send the facebook message in the body of the request so special characters will have better support

= 1.26 =
* Supports sharing of LinkedIn messages from the plugin settings when there's no link or image to be shared

= 1.25 =
* Removal of some errors when things aren't set

= 1.24 =
* Support for people who are an admin of over 10 pages in LinkedIn

= 1.23 =
* Updates to language code for Google My Business

= 1.22 =
* Updates to prevent scheduled posts being published more then once

= 1.21 =
* Better error checking for notices

= 1.20 =
* Added new image size 'large' to check for when sharing post images

= 1.19 =
* Fix for Twitter display posts for manage posts
* Fix for GMB image if PHP server not setup typically
* More FAQ items
* More defensive UI for people who don't have CURL installed on server which can cause Twitter issues

= 1.18 =
* Removal of diagnostic info
* CURL info in diagnostic info

= 1.17 =
* Further testing and compatibility with Twitter

= 1.16 =
* Better error checking with Twitter

= 1.15 =
* Fixing of bugs particularly around Twitter which can cause settings issue for new users

= 1.14 =
* Much needed updated FAQ

= 1.13 =
* WordPress 5.0 compatibility

= 1.12 =
* We now provide better diagnostic information for Google My Business in the help tab to find specific location API issues

= 1.11 =
* Now supports Google My Business "Call" call to application
* You can now enter custom application details for the Bit.ly integration

= 1.10 =
* Bug fixes

= 1.9 =
* Now removes latin characters to improve the possibility of sharing posts

= 1.8 =
* You can now specify in the plugin settings categories you don't want to share with upon publishing of a standard post

= 1.7 =
* Now you can remove all plugin settings from the help tab

= 1.6 =
* bug fix for images that are too small for Google My Business to accept by just sharing the post without an image

= 1.5 =
* removal of locations which are not API enabled for Google My Business

= 1.4 =
* fixed timzone issue

= 1.3 =
* You can now use your own applications for Facebook, LinkedIn and Google My Business if you should dare!
* Better diagnostic information for when creating support requests

= 1.2 =
* Now you can add multiple Twitter profiles

= 1.1 =
* Now you can manage posts for all networks in one place!

= 1.0 =
* Initial launch of the plugin




== Upgrade Notice ==

= 7.14 =
* Fix for LinkedIn pages

= 7.13 =
* Updating of Facebook permissions

= 7.12 =
* Fix for LinkedIn manage posts

= 7.11 =
* Filter to change the image shared for a post

= 7.10 =
* Fix to hold Twitter authentication longer

= 7.9 =
* Respect for original characters using little text format for LinkedIn Shares

= 7.8 =
* Better parsing of LinkedIn share message into little text format

= 7.7 =
* Support for new shortcode tag [POST_CATEGORIES]

= 7.6 =
* More work fine tuning LinkedIn posting

= 7.5 =
* Gets more LinkedIn companies

= 7.4 =
* Bug fix for square brackets in share message for LinkedIn

= 7.3 =
* Bug fix for LinkedIn Company sharing

= 7.2 =
* Fix for when sharing to personal LinkedIn profiles

= 7.1 =
* Bug fixes for LinkedIn shares

= 7.0 =
* Major update for latest LinkedIn API
* Major update for latest Twitter API - please read instructions in Twitter tab for the latest instructions

= 6.32 =
* Fix for 6.31

= 6.31 =
* Removal of quirk around Twitter upload directory

= 6.30 =
* Fix for LinkedIn when sharing no link, but still sharing an image

= 6.29 =
* Fix for bug when trying to share to LinkedIn with no link and specific general setting enabled

= 6.28 =
* Updated Twitter count when using the share now or share later feature

= 6.27 =
* New option to output og:image header tag
* Bug fix for featureimage override

= 6.26 =
* Addition of classes so shortcode tags can be hidden in admin interface to save space in metabox on edit page

= 6.25 =
* Removal of temporary diagnostic info

= 6.24 =
* Bug fixes for scheduled post functionality caused by 6.22 update

= 6.23 =
* Bug fixes for Pinterest

= 6.22 =
* Fix for multiple shares with Gutenberg

= 6.21 =
* Updated instructions for Twitter

= 6.20 =
* Big fix caused by version 6.18 and working with draft posts and the do not share checkbox

= 6.19 =
* Filter to allow do not share checkbox to be checked by default

= 6.18 =
* Resolves dont share issues with Gutenberg

= 6.17 =
* Further fixing of PHP errors caused by review shortcode

= 6.16 =
* Fixing potential fatal error caused by review shortcode with no reviews

= 6.15 =
* Improved instructions for creating a Twitter app

= 6.14 =
* New setting to share links to Twitter as oppose to images 

= 6.13 =
* Addition of new action for the purpose of sending emails when authentication is about to expire

= 6.12 =
* Addition of new filter

= 6.11 =
* Bug fixes

= 6.10 =
* Force checking of plugin updates

= 6.9 =
* Makes hashtags work in Instagram

= 6.8 =
* Finally a working solution for line breaks in the plugin!

= 6.7 =
* Addition of fail and success actions when a post share fails or succeeds to post.

= 6.6 =
* Fix for version 6.5

= 6.5 =
* Addition of line break support

= 6.4 =
* Addition of new delayed mode feature - please see the general settings tab for more information

= 6.3 =
* Important error fixes for Google My Business caused by version 6.2

= 6.2 =
* Support for API changes to Google My Business
* PHP bug fixes for metabox

= 6.1 =
* PHP bug fixes
* Addition of new shortcode [POST_TAGS] which outputs post tags as hashtags

= 6.0 =
* Support for Pinterest!

= 5.2 =
* New setting to prevent autosharing if desired

= 5.1 =
* Small fix so delete all settings includes the deleting of Instagram settings
* Ensures caption works for posts for Instagram

= 5.0 =
* Support for Instagram
* Increased text length to 3000 for LinkedIn

= 4.30 =
* Updated messaging regarding WooCommerce integration with the plugin

= 4.29 =
* Filter to delay sharing

= 4.28 =
* Link sharing fix for LinkedIn

= 4.27 =
* Fix for -11 GMT timezone

= 4.26 =
* Fix for sharing images to Facebook without a link when using the Share Now and Schedule feature

= 4.25 =
* Fix for sharing images to LinkedIn without a link when using the Share Now and Schedule feature

= 4.24 =
* Fix for Facebook manage posts

= 4.23 =
* New filter to filter the message before sending - please see faq for more details

= 4.22 =
* Fix for structured data output on page when the user elects it to be false

= 4.21 =
* Updates to the latest Facebook Graph API 

= 4.20 =
* Fix for error messages when authenticating with GMB

= 4.19 =
* Ability to set default image via filter

= 4.18 =
* Tested with WordPress 5.5.1
* Removal of Google My Business profile images to keep within API limits and to improve performance
* Support for more than 100 Google My Business locations

= 4.17 =
* Allowance of foreign characters via the share now function

= 4.16 =
* new review shortcode option so you can display the social network of the review

= 4.15 =
* Bug fix caused by 4.13 where locations/profiles with the same name would be ignored

= 4.14 =
* Further compatibility improvements with bootstrap date time picker

= 4.13 =
* Now you can get more than 25 Facebook pages
* All pages are now listed alphabetically

= 4.12 =
* Further refinement to Twitter message count

= 4.11 =
* Ignores URLs in character count for Twitter

= 4.10 =
* Ability to share longer tweets which may have URLs

= 4.9 =
* Further bug fixes

= 4.8 =
* Fixed bug with multiple custom meta data in share message

= 4.7 =
* We now show custom fields in the metabox on the post page to make life easier
* You can now set share message templates for different post types

= 4.6 =
* Now support for custom fields (meta) in the share message template! Read the FAQ for more info.

= 4.5 =
* Added a new capability so you can give other user roles the ability to edit AutoSocial settings

= 4.4 =
* Extension of the update in version 4.3 to cover GMB and LinkedIn

= 4.3 =
* If the facebook post does not contain a link, then we won't send a link with the Facebook post

= 4.2 =
* Betetr translation support

= 4.1 =
* Now the plugin is translatable - we have included a .pot file in the languages folder

= 4.0 =
* Now the plugin has Pinterest support - however still waiting for app to be approved

= 3.2 =
* Introduced a no conflict mode for those using the ACF date/time/datetime picker on their posts

= 3.1 =
* Improved read more functionality
* More logical review settings
* You can now change the text colour of the reviews
* Now supports structured data for reviews to help improve SEO

= 3.0 =
* New review functionality

= 2.4 =
* Added a new filter so advanced users can specify which posts they want to share or not share to social networks

= 2.3 =
* Fixed up LinkedIn test connection button issue

= 2.2 =
* Changes to the notice buttons so it's more obvious you need to click the original connection buttons when re-authenticating not the buttons on the notice itself

= 2.1 =
* New features for Google My Business to create product posts from WooCommerce and event posts from The Events Calendar plugin

= 2.0 =
* We now use version 2.0 of LinkedIn's API! This means LinkedIn profiles and companies now show images in the UI which is nice and you can manage LinkedIn posts
* Testing with WordPress 5.2.1
* If you are using LinkedIn, it's important you re-authenticate 

= 1.27 =
* We now send the facebook message in the body of the request so special characters will have better support

= 1.26 =
* Supports sharing of LinkedIn messages from the plugin settings when there's no link or image to be shared

= 1.25 =
* Removal of some errors when things aren't set

= 1.24 =
* Support for people who are an admin of over 10 pages in LinkedIn

= 1.23 =
* Updates to language code for Google My Business

= 1.22 =
* Updates to prevent scheduled posts being published more then once

= 1.21 =
* Better error checking for notices

= 1.20 =
* Added new image size 'large' to check for when sharing post images

= 1.19 =
* Fix for Twitter display posts for manage posts
* Fix for GMB image if PHP server not setup typically
* More FAQ items
* More defensive UI for people who don't have CURL installed on server which can cause Twitter issues

= 1.18 =
* Removal of diagnostic info
* CURL info in diagnostic info

= 1.17 =
* Further testing and compatibility with Twitter

= 1.16 =
* Better error checking with Twitter

= 1.15 =
* Fixing of bugs particularly around Twitter which can cause settings issue for new users

= 1.14 =
* Much needed updated FAQ

= 1.13 =

* WordPress 5.0 compatibility

= 1.12 =
* We now provide better diagnostic information for Google My Business in the help tab to find specific location API issues

= 1.11 =
* Now supports Google My Business "Call" call to application
* You can now enter custom application details for the Bit.ly integration

= 1.10 =
* Bug fixes

= 1.9 =
* Now removes latin characters to improve the possibility of sharing posts

= 1.8 =
* You can now specify in the plugin settings categories you don't want to share with upon publishing of a standard post

= 1.7 =
* Now you can remove all plugin settings from the help tab

= 1.6 =
* bug fix for images that are too small for Google My Business to accept by just sharing the post without an image

= 1.5 =
* removal of locations which are not API enabled for Google My Business

= 1.4 =
* fixed timzone issue

= 1.3 =
* You can now use your own applications for Facebook, LinkedIn and Google My Business if you should dare!
* Better diagnostic information for when creating support requests

= 1.2 =
* Now you can add multiple Twitter profiles - if you have added Twitter already to the plugin before this update you will need to re-enter your application details in the settings - sorry about that!

= 1.1 =
* Now you can manage posts for all networks in one place!

= 1.0 =
* This is the first version of the plugin.