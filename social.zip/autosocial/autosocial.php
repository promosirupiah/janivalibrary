<?php

/*
*		Plugin Name: AutoSocial
*		Plugin URI: https://www.northernbeacheswebsites.com.au
*		Description: Publish your latest posts to a range of social networks automatically. 
*		Version: 7.14
*		Author: Martin Gibson
*		Text Domain: autosocial 
*		Support: https://www.northernbeacheswebsites.com.au/contact
*		Licence: GPL2
*/

/**
* 
*
*
* Gets version number of plugin
*/
function autosocial_get_version() {
	if ( ! function_exists( 'get_plugins' ) )
        require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	$plugin_folder = get_plugins( '/' . plugin_basename( dirname( __FILE__ ) ) );
	$plugin_file = basename( ( __FILE__ ) );
	return $plugin_folder[$plugin_file]['Version'];
}
/**
* 
*
*
* Runs on plugin activate
*/
function autosocial_activate() {
    //add an option initially to minimise error messages on plugin
    add_option('autosocial_settings');
}
register_activation_hook( __FILE__, 'autosocial_activate' );

/**
* 
*
*
* Create new capability
*/
function autosocial_create_new_capability() {
    
    $role = get_role('administrator');

    $role->add_cap('autosocial_manage_options', true);
    
}
add_action('init', 'autosocial_create_new_capability',1);



/**
* 
*
*
* Enable capability to save plugin settings
*/
function autosocial_save_settings(){
    return 'autosocial_manage_options';
}
add_filter( 'option_page_capability_facebook_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_google_my_business_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_twitter_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_linkedin_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_google_plus_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_pinterest_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_general_settings_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_review_shortcode_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_help_autosocial', 'autosocial_save_settings');

add_filter( 'option_page_capability_error_log_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_share_now_or_schedule_autosocial', 'autosocial_save_settings');
add_filter( 'option_page_capability_manage_posts_autosocial', 'autosocial_save_settings');



/**
* 
*
*
* Add menu item
*/
function autosocial_add_admin_menu() { 

    $menu_icon_svg = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDIyLjEuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMiIgYmFzZVByb2ZpbGU9InRpbnkiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIgoJIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMjAgMjAiIHhtbDpzcGFjZT0icHJlc2VydmUiPgo8Zz4KCTxnPgoJCTxwYXRoIGZpbGw9IiM5RUEzQTciIGQ9Ik0xMi41LDE3Yy0wLjUsMC0wLjgtMC40LTAuOC0wLjhjMC0wLjUsMC40LTAuOCwwLjgtMC44YzAuNCwwLDAuOCwwLjQsMC44LDAuOEMxMy4zLDE2LjYsMTMsMTcsMTIuNSwxN3oiCgkJCS8+Cgk8L2c+Cgk8Zz4KCQk8cGF0aCBmaWxsPSIjOUVBM0E3IiBkPSJNNy4zLDE3Yy0wLjUsMC0wLjgtMC40LTAuOC0wLjhjMC0wLjQsMC40LTAuOCwwLjgtMC44YzAuNCwwLDAuOCwwLjQsMC44LDAuOEM4LjEsMTYuNiw3LjgsMTcsNy4zLDE3eiIvPgoJPC9nPgoJPGc+CgkJPHBhdGggZmlsbD0iIzlFQTNBNyIgZD0iTTkuOCw2LjRjLTEuNiwwLTMtMS4zLTMtM3MxLjMtMywzLTNzMywxLjMsMywzUzExLjUsNi40LDkuOCw2LjR6IE05LjgsMS42Yy0xLDAtMS44LDAuOC0xLjgsMS44CgkJCXMwLjgsMS44LDEuOCwxLjhzMS44LTAuOCwxLjgtMS44UzEwLjgsMS42LDkuOCwxLjZ6Ii8+Cgk8L2c+Cgk8Zz4KCQk8cGF0aCBmaWxsPSIjOUVBM0E3IiBkPSJNMi43LDguN2MtMS4xLDAtMi0wLjktMi0yczAuOS0yLDItMnMyLDAuOSwyLDJTMy44LDguNywyLjcsOC43eiBNMi43LDUuNmMtMC42LDAtMS4xLDAuNS0xLjEsMS4xCgkJCXMwLjUsMS4xLDEuMSwxLjFzMS4xLTAuNSwxLjEtMS4xUzMuMyw1LjYsMi43LDUuNnoiLz4KCTwvZz4KCTxnPgoJCTxwYXRoIGZpbGw9IiM5RUEzQTciIGQ9Ik0xNy4zLDguN2MtMS4xLDAtMi0wLjktMi0yczAuOS0yLDItMnMyLDAuOSwyLDJTMTguNCw4LjcsMTcuMyw4Ljd6IE0xNy4zLDUuNmMtMC42LDAtMS4xLDAuNS0xLjEsMS4xCgkJCXMwLjUsMS4xLDEuMSwxLjFjMC42LDAsMS4xLTAuNSwxLjEtMS4xUzE3LjksNS42LDE3LjMsNS42eiIvPgoJPC9nPgoJPHBhdGggZmlsbD0iIzlFQTNBNyIgZD0iTTE0LjgsMTEuNWMwLjEtMC4xLDAuMi0wLjIsMC40LTAuMmMwLjUsMCwwLjgtMC40LDAuOS0wLjhjMC4xLTAuNS0wLjEtMC45LTAuNS0xLjEKCQljLTAuNC0wLjItMC45LTAuMS0xLjIsMC4xYy0wLjMsMC4zLTAuNCwwLjctMC4zLDEuMmMwLjEsMC4xLDAsMC4yLDAsMC40Yy0wLjEsMC4xLTAuNiwwLjktMC43LDEuMmMtMC45LTAuNi0xLjktMS0zLTEuMQoJCWMwLTAuNCwwLTEuMSwwLTEuMmMwLTAuMiwwLTAuMiwwLjItMC4zYzAuNC0wLjMsMC41LTAuNywwLjQtMS4xYy0wLjEtMC40LTAuNS0wLjctMC45LTAuN0M5LjUsNy43LDkuMSw4LDksOC40CgkJYy0wLjEsMC40LDAsMC45LDAuNCwxLjJDOS41LDkuNyw5LjUsOS44LDkuNSwxMGMwLDAuMSwwLDAuOSwwLDEuMmMtMC4yLDAtMC41LDAuMS0wLjcsMC4xYy0wLjgsMC4yLTEuNiwwLjUtMi4yLDEKCQljLTAuMi0wLjMtMC43LTEuMS0wLjctMS4yYy0wLjEtMC4xLTAuMS0wLjIsMC0wLjRjMC4yLTAuNCwwLjEtMC45LTAuMy0xLjJDNS4yLDkuMiw0LjcsOS4yLDQuMyw5LjRDMy45LDkuNiwzLjcsMTAsMy44LDEwLjUKCQljMC4xLDAuNCwwLjQsMC44LDAuOSwwLjhjMC4yLDAsMC4zLDAuMSwwLjQsMC4yYzAsMC4xLDAuNiwxLDAuNywxLjFzMC4xLDAuMSwwLjEsMC4xYy0xLjEsMS4xLTEuOCwyLjYtMS44LDQuMmMwLDAuNSwwLDEuMSwwLDEuNgoJCXYxLjdoMTEuN3YtMS43YzAtMC41LDAtMSwwLTEuNWMwLTEtMC4yLTItMC43LTIuOWMtMC4zLTAuNS0wLjYtMS0xLTEuNGMwLDAsMC4xLTAuMSwwLjEtMC4yUzE0LjgsMTEuNiwxNC44LDExLjV6IE0xMy44LDE3CgkJYy0wLjEsMC42LTAuNSwwLjktMSwxLjFjLTAuNCwwLjEtMC45LDAuMS0xLjQsMC4xbC00LDBjLTAuMiwwLTAuMywwLTAuNS0wLjFjLTAuNy0wLjItMS0wLjYtMS4xLTEuMmMtMC4yLTIsMC45LTMuMywyLjYtMy43CgkJYzEuMi0wLjMsMi41LTAuMiwzLjYsMC40YzEsMC41LDEuNiwxLjQsMS43LDIuNUMxMy45LDE2LjMsMTMuOSwxNi43LDEzLjgsMTd6Ii8+CjwvZz4KPC9zdmc+Cg==';
    
    global $autosocial_settings_page;
    
	$autosocial_settings_page = add_menu_page( 'AutoSocial', 'AutoSocial', 'autosocial_manage_options', 'autosocial', 'autosocial_options_page',$menu_icon_svg);
}
add_action( 'admin_menu', 'autosocial_add_admin_menu' );
add_action( 'admin_init', 'autosocial_settings_init',10 );
/**
* 
*
*
* Menu page
*/
function autosocial_options_page() { 
    require('inc/options-page-wrapper.php');
}
/**
* 
*
*
* Get and Set Options
*/
require('inc/options-output.php');
/**
* 
*
*
* Include core files
*/
require('inc/authentication.php');
require('inc/test-authentication.php');
require('inc/profile-selection.php');
require('inc/post-columns.php');
require('inc/notices.php');
require('inc/metabox.php');
require('inc/social-share.php');
require('inc/social-share-now-or-later.php');
require('inc/logging.php');
require('inc/common-functions.php');
require('inc/manage-posts.php');
require('inc/review-shortcode.php');
require('inc/delayed-mode.php');
require('inc/og-image.php');
/**
* 
*
*
* Load admin styles and scripts
*/
function autosocial_admin_styles_and_scripts($hook)
{
    
    //get settings page
    global $autosocial_settings_page;
    
    
    if(in_array($hook, array('post.php', 'post-new.php' , 'edit.php') )){
        
        // //scripts
        wp_enqueue_script( 'moment-autosocial', plugins_url( '/inc/external/moment.min.js', __FILE__ ), array( 'jquery'));


        //get options
        $options = get_option('autosocial_settings');

        if( !isset($options['autosocial_enable_datetimepicker_no_conflict']) ){
            wp_enqueue_script( 'timedatepicker-script', plugins_url( '/inc/external/bootstrap-datetimepicker.min.js', __FILE__ ), array( 'jquery'),'4.17.47',true);
        }


        wp_enqueue_script( 'custom-admin-post-script-autosocial', plugins_url( '/inc/postscript.js', __FILE__ ), array( 'jquery'),autosocial_get_version());
        wp_enqueue_media();  
        wp_enqueue_script('alertify-autosocial', plugins_url('/inc/external/alertify.js', __FILE__ ), array( 'jquery'),null,true);
        
        // //styles
        wp_enqueue_style( 'timedatepicker-style', plugins_url( '/inc/external/bootstrap-datetimepicker.min.css', __FILE__ ));
        wp_enqueue_style( 'custom-style-autosocial', plugins_url( '/inc/poststyle.css', __FILE__ ), array(),autosocial_get_version());
        wp_enqueue_style( 'font-awesome-icons-autosocial', plugins_url( '/inc/external/font-awesome.min.css', __FILE__ )); 

        
    } elseif($autosocial_settings_page == $hook){
        
        //scripts

        wp_enqueue_script( 'custom-admin-script-autosocial', plugins_url( '/inc/adminscript.js', __FILE__ ), array( 'jquery','wp-color-picker' ),autosocial_get_version());
        wp_enqueue_script('jquery-form');
        wp_enqueue_script( 'moment-autosocial', plugins_url( '/inc/external/moment.min.js', __FILE__ ), array( 'jquery'));
        wp_enqueue_script( 'timedatepicker-script', plugins_url( '/inc/external/bootstrap-datetimepicker.min.js', __FILE__ ), array( 'jquery'));
        
        wp_enqueue_media(); 
        // wp_enqueue_script('read-more-gmb', plugins_url('/inc/external/readmore.min.js', __FILE__ ), array( 'jquery'));
        wp_enqueue_script('alertify-autosocial', plugins_url('/inc/external/alertify.js', __FILE__ ), array( 'jquery'),null,true);
        

        //styles
        wp_enqueue_style( 'custom-admin-style-autosocial', plugins_url( '/inc/adminstyle.css', __FILE__ ),array(),autosocial_get_version());
        wp_enqueue_style( 'font-awesome-icons-autosocial', plugins_url( '/inc/external/font-awesome.min.css', __FILE__ ));
        wp_enqueue_style( 'timedatepicker-style', plugins_url( '/inc/external/bootstrap-datetimepicker.min.css', __FILE__ )); 
        wp_enqueue_style( 'wp-color-picker' );

        
    } else {
        return;
    }
    

}
add_action( 'admin_enqueue_scripts', 'autosocial_admin_styles_and_scripts' );
/**
* 
*
*
* Load frontend styles and scripts
*/
function autosocial_frontend_styles_and_scripts(){


    //scripts
    wp_register_script( 'autosocial-slick-script', plugins_url( '/inc/external/slick.min.js', __FILE__ ), array( 'jquery'));
    wp_register_script( 'autosocial-script', plugins_url( '/inc/frontendscript.js', __FILE__ ), array( 'jquery'),autosocial_get_version());
    // wp_register_script('autosocial-read-more', plugins_url('/inc/external/readmore.min.js', __FILE__ ), array( 'jquery'));

    //styles
    wp_register_style( 'autosocial-style', plugins_url( '/inc/frontendstyle.css', __FILE__ ),array(),autosocial_get_version());
    wp_register_style( 'autosocial-font-awesome', plugins_url( '/inc/external/font-awesome.min.css', __FILE__ ));
    wp_register_style( 'autosocial-slick-style', plugins_url( '/inc/external/slick.css', __FILE__ ));

}
add_action( 'wp_enqueue_scripts', 'autosocial_frontend_styles_and_scripts' );
/**
* 
*
*
* Add custom links to plugin on plugins page
*/
function autosocial_plugin_links( $links, $file ) {
    if ( strpos( $file, 'wp-google-my-business-auto-publish.php' ) !== false ) {
       $new_links = array(
                '<a href="https://northernbeacheswebsites.com.au/support/" target="_blank">' . __('Support','autosocial') . '</a>',
             );
       $links = array_merge( $links, $new_links );
    }
    return $links;
 }
 add_filter( 'plugin_row_meta', 'autosocial_plugin_links', 10, 2 );
 /**
 * 
 *
 *
 * Add settings link to plugin on plugins page
 */
 function autosocial_settings_link( $links ) {
     $settings_link = '<a href="admin.php?page=autosocial">' . __( 'Settings','autosocial' ) . '</a>';
     array_unshift( $links, $settings_link );
       return $links;
 }
 $plugin = plugin_basename( __FILE__ );
 add_filter( "plugin_action_links_$plugin", 'autosocial_settings_link' );
 /**
 * 
 *
 *
 * Make the plugin translatable 
 */
function autosocial_languages() {
    load_plugin_textdomain( 'autosocial', false, 'autosocial/inc/languages' );
}
add_action('init', 'autosocial_languages');

?>