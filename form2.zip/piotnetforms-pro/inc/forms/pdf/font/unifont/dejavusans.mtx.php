<?php
$name='DejaVuSans';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-1021 -463 1793 1232]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile= __DIR__ . '/DejaVuSans.ttf';
$originalsize=757076;
$fontkey='dejavu';
?>