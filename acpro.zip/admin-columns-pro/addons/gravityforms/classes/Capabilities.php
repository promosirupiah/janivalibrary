<?php

namespace ACA\GravityForms;

interface Capabilities {

	const EDIT_ENTRIES = 'gravityforms_edit_entries';

}