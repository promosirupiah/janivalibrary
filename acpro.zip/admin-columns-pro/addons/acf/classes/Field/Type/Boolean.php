<?php

namespace ACA\ACF\Field\Type;

use ACA\ACF\Field;

class Boolean extends Field {

}