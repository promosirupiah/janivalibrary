=== Use-your-Drive ===
Requires at least: 5.3 
Tested up to: 6.2
Requires PHP: 7.4

Say hello to the most popular WordPress Google Drive plugin! Use-your-Drive is a user-friendly, highly customizable, innovative Google Drive integration plugin for WordPress that displays your Google Drive files in a beautiful way. No coding skills required!

== Description ==

Say hello to the most popular WordPress Google Drive plugin! Use-your-Drive is a user-friendly, highly customizable, innovative Google Drive integration plugin for WordPress that displays your Google Drive files in a beautiful way. No coding skills required!

This plugin will help you to easily integrate Google Drive into your WordPress website or blog. Use-your-Drive allows you to view, download, delete, rename files & folders stored in the cloud directly from a WordPress page. You can use Use-your-Drive as a File browser, Upload Box, Gallery, Audio- or Video-Player!

== Changelog ==
You can find the Changelog in the [Documentation](https://www.wpcloudplugins.com/wp-content/plugins/use-your-drive/_documentation/index.html#releasenotes).

== Upgrade Notices ==

In case you have multiple WP Cloud Plugins active, please make sure they are all up to date to prevent compatibility issues between the plugins.

= 2.0 = 
IMPORTANT (For Developers): This 2.0 update contains many changes to the core classes and functions of the plugin. If you have code that hook into the plugin classes or use custom addons, you might need to update that code. See the API documentation for more information.