<?php
defined('ABSPATH') || die('No direct script access allowed!');

use League\Flysystem\Filesystem;

class Cloudfiles_Wordpress_Media_Library_System_Filesystem extends Filesystem
{
    
}
?>