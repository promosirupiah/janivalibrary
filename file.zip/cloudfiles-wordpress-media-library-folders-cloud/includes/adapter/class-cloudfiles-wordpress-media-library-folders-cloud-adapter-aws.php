<?php
defined('ABSPATH') || die('No direct script access allowed!');

use League\Flysystem\AwsS3v3\AwsS3Adapter;

class Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Adapter_Aws extends AwsS3Adapter
{
    
}
?>