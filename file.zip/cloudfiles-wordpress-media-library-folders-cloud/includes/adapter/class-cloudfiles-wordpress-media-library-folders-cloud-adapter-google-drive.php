<?php
defined('ABSPATH') || die('No direct script access allowed!');

use Hypweb\Flysystem\GoogleDrive\GoogleDriveAdapter;

class Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Adapter_Google_Drive extends GoogleDriveAdapter
{
    
}
?>