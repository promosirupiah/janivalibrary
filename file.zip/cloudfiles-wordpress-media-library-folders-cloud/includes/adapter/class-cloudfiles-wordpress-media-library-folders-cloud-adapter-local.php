<?php
defined('ABSPATH') || die('No direct script access allowed!');

use League\Flysystem\Adapter\Local;

class Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Adapter_Local extends Local
{
    /**
     * {@inheritdoc}
     */
    public function listContents($directory=0, $recursive = false)
    {
        return [];
    }
}
?>