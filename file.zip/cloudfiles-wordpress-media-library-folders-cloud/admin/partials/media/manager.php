<?php 
$sidebar_splitter_width = get_option('noucloudfiles_splitter_width', '284');
$isCallModal = isset($_POST['action']) && $_POST['action'] == 'noucloudfiles_ajax_treeview_folder';
?>
<div class="hidden">
	<div id="noucloudfiles-sidebar" class="noucloudfiles" style="display: none;">
		<div class="noucloudfiles-sidebar panel-left" <?php echo ($sidebar_splitter_width && !$isCallModal ? ' style="width: ' . $sidebar_splitter_width . 'px;"' : '') ?>>
			<div class="noucloudfiles-sidebar_fixed" <?php echo ($sidebar_splitter_width && !$isCallModal ? ' style="width: ' . $sidebar_splitter_width . 'px;"' : '') ?>>

				<input type="hidden" id="noucloudfiles-terms">
				<h1 class="noucloudfiles-main_title"><?php echo esc_html__('Folders', 'cloudfiles-wordpress-media-library-folders-cloud');?></h1>
				<!-- .noucloudfiles-main_title -->
				<div class="noucloudfiles-add_new_container">
					<button type="button" class="noucloudfiles-main_add_new new-folder uk-button uk-button-primary uk-button-small" href="#modal-create-folder" uk-toggle disabled><span uk-icon="icon: plus"></span> <?php echo esc_html__('New Folder', 'cloudfiles-wordpress-media-library-folders-cloud');?></button>
				</div>
				<div id="modal-create-folder" class="uk-flex-top" uk-modal>
					<div class="uk-modal-dialog">
						<form id="folder-form">
							<button class="uk-modal-close-default" type="button" uk-close></button>
							<div class="uk-modal-header">
								<h3 class="uk-modal-title"><?php echo esc_html__('Create Folder', 'cloudfiles-wordpress-media-library-folders-cloud');?></h3>
							</div>
							<div class="uk-modal-body">
								<div class="uk-margin">
									<input class="uk-input" type="text" placeholder="<?php echo esc_html__('Folder name', 'cloudfiles-wordpress-media-library-folders-cloud');?>">
								</div>
							</div>
							<div class="uk-modal-footer uk-text-right">
								<button class="uk-button uk-button-default uk-modal-close uk-button-small" type="button"><?php echo esc_html__('Cancel', 'cloudfiles-wordpress-media-library-folders-cloud');?></button>
								<button type="button" class="uk-button uk-button-primary uk-button-small create"><?php echo esc_html__('Create', 'cloudfiles-wordpress-media-library-folders-cloud');?></button>
							</div>
						</form>
					</div>
				</div>
				<!-- .noucloudfiles-add_new_container -->
				<div class="noucloudfiles-toolbar">
					<button type="button" class="uk-button uk-button-primary js__noucloudfiles-sync uk-button-small" data-title="<?php echo esc_html__('Sync', 'cloudfiles-wordpress-media-library-folders-cloud');?>" disabled><span uk-icon="icon: refresh"></span> <?php echo esc_html__('Sync', 'cloudfiles-wordpress-media-library-folders-cloud');?></button>
					<button type="button" class="uk-button uk-button-secondary js__noucloudfiles-rename uk-button-small" data-title="<?php echo esc_html__('Rename', 'cloudfiles-wordpress-media-library-folders-cloud');?>" disabled><span uk-icon="icon: pencil"></span> <?php echo esc_html__('Rename', 'cloudfiles-wordpress-media-library-folders-cloud');?></button>
					<button type="button" class="uk-button uk-button-danger js__noucloudfiles-delete uk-button-small" disabled><span uk-icon="icon: trash"></span> <?php echo esc_html__('Delete', 'cloudfiles-wordpress-media-library-folders-cloud');?></button>

				</div>
				<div class="noucloudfiles-loader"></div>
				<!-- /.noucloudfiles-toolbar -->
				<div id="noucloudfiles-defaultTree" class="noucloudfiles_tree">
					<ul></ul>
				</div>
				<!-- /#noucloudfiles-defaultTree -->
				<div id="noucloudfiles-folderTree" class="noucloudfiles-tree jstree-default">
					<form action="javascript:void(0);" id="update-folders" enctype="multipart/form-data" method="POST">
						<ul id="folders-to-edit" class="menu"></ul>
					</form>
				</div>
			</div>
			<!-- #njt-filebird-folderTree -->
		</div>
		<div class="noucloudfiles-splitter"></div>
	</div>
</div>