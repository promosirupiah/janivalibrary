<div class="js-upload-to-folder uk-placeholder uk-text-center">
    <div uk-form-custom>
        <input type="file" multiple>
    </div>
</div>