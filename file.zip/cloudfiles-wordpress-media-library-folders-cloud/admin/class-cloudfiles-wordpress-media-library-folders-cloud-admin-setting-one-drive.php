<?php
/**
 * One Drive Settings
 *
 * @link       https://themeforest.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Cloudfiles_Wordpress_Media_Library_Folders_Cloud
 * @subpackage Cloudfiles_Wordpress_Media_Library_Folders_Cloud/admin
 */

defined( 'ABSPATH' ) || exit;

class Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Admin_Setting_One_Drive extends Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Admin_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id    = CLOUDFILES_WORDPRESS_MEDIA_LIBRARY_FOLDERS_CLOUD_ONEDRIVE;
		$this->label = esc_html__( 'One Drive', 'cloudfiles-wordpress-media-library-folders-cloud' );

		parent::__construct();

		add_action('noucloudfiles_after_submit_'.$this->id, array( $this, 'html_authorize'));
	}

	public function html_authorize(){
		$client_id = get_option('onedrive_client_id');
		$client_secret = get_option('onedrive_client_secret');
		if(!empty($client_id) && !empty($client_secret)):
		?>
		<button name="authorize" class="uk-button uk-button-primary noucloudfiles-authorize-button" type="button" value="<?php echo esc_attr($this->id);?>"><?php echo esc_html__( 'Authorize account', 'cloudfiles-wordpress-media-library-folders-cloud' ); ?></button>
		<?php
		endif;
	}

	/**
	 * Get settings array.
	 *
	 * @return array
	 */
	public function get_settings() {
		$erasure_text = sprintf( '<a href="%s" target="_blank">%s</a>', esc_url( 'https://go.microsoft.com/fwlink/?linkid=2094263' ), esc_html__('Learn more about redirect URIs and the restrictions', 'cloudfiles-wordpress-media-library-folders-cloud') );
		$value = get_option('noucloudfiles_enable_onedrive', 'yes');
		$settings = apply_filters(
			'noucloudfiles_dropbox_settings',
			array(
				array(
					'title' => esc_html__( 'One Drive API Client', 'cloudfiles-wordpress-media-library-folders-cloud' ),
					'type'  => 'title',
					'desc'  => '',
					'id'    => 'onedrive_section',
				),
				array(
					'title' => esc_html__( 'Enable', 'cloudfiles-wordpress-media-library-folders-cloud' ),
					'type'  => 'checkbox',
					'value'  => $value,
					'id'    => 'noucloudfiles_enable_onedrive',
					'desc_tip' => false,
				),
				array(
					'title' => esc_html__( 'Client ID', 'cloudfiles-wordpress-media-library-folders-cloud' ),
					'type'  => 'text',
					'desc'  => '',
					'id'    => 'onedrive_client_id',
					'class' => 'client_id',
					'desc_tip' => false,
				),
				array(
					'title' => esc_html__( 'Client Secret', 'cloudfiles-wordpress-media-library-folders-cloud' ),
					'type'  => 'password',
					'desc'  => '',
					'id'    => 'onedrive_client_secret',
					'class' => 'client_secret',
					'desc_tip' => false,
				),
				array(
					'title' => esc_html__( 'Authorize redirect url', 'cloudfiles-wordpress-media-library-folders-cloud' ),
					'type'  => 'url',
					'readonly' => true,
					'desc'  => $erasure_text,
					'value' => admin_url(),
					'default' => admin_url(),
					'id'    => 'onedrive_redirect_url',
					'desc_tip' => false,
				),
				array(
					'type' => 'sectionend',
					'id'   => 'onedrive_section',
				),

			)
		);

		return apply_filters( 'noucloudfiles_get_settings_' . $this->id, $settings );
	}

	/**
	 * Output a color picker input box.
	 *
	 * @param mixed  $name Name of input.
	 * @param string $id ID of input.
	 * @param mixed  $value Value of input.
	 * @param string $desc (default: '') Description for input.
	 */
	public function color_picker( $name, $id, $value, $desc = '' ) {
		echo '<div class="color_box">' . noucloudfiles_help_tip( $desc ) . '
			<input name="' . esc_attr( $id ) . '" id="' . esc_attr( $id ) . '" type="text" value="' . esc_attr( $value ) . '" class="colorpick" /> <div id="colorPickerDiv_' . esc_attr( $id ) . '" class="colorpickdiv"></div>
		</div>';
	}

	/**
	 * Output the settings.
	 */
	public function output() {
		$settings = $this->get_settings();
		Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Admin_Settings::output_fields( $settings );
	}

	/**
	 * Save settings.
	 */
	public function save() {
		$settings = $this->get_settings();
		Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Admin_Settings::save_fields( $settings );

		$provider = new Cloudfiles_Wordpress_Media_Library_Folders_Cloud_Pro($this->id);
		if($provider->is_enable()){
			$provider->get_folder_cloud();
		}
	}
}
