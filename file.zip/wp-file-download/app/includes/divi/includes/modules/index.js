import Category from "./Category/Category";
import File from "./File/File";
import Search from "./Search/Search";

export default [
    Category,
    File,
    Search
];