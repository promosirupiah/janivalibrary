import WpfdCategoryButton from './WpfdCategoryButton/WpfdCategoryButton';
import WpfdFile from "./WpfdFile/WpfdFile";

export default [
    WpfdCategoryButton,
    WpfdFile
];
