<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

//-- No direct access
defined('ABSPATH') || die();

require_once(dirname(WPFD_PLUGIN_FILE) . '/app/site/models/filefront.php');
