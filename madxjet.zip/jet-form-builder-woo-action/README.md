# JetFormBuilder Woocommerce Cart & Checkout Action
Premium Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.0.4
* FIX: Use product price by default
* UPD: Delay redirect to Woo Checkout

## 1.0.3
* Tweak: Removed unnecessary hook

## 1.0.2
* ADD: View order details on checkout
* Tweak: add license manager

## 1.0.1
* FIX: php notices

## 1.0.0
* Initial release