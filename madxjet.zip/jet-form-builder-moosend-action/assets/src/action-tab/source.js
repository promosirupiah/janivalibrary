import { helpLink } from '../help';

const { __ } = wp.i18n;

const label = {
	api_key: __( 'API key', 'jet-form-builder' ),
};

const help = { ...helpLink };

export { label, help };