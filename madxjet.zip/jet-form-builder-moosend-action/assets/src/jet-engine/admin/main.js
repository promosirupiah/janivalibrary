import * as actionTab from '@/action-tab';

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.engine.formTabs.register', 'jet-engine', tabs => {
	tabs.push( actionTab );

	return tabs;
} );