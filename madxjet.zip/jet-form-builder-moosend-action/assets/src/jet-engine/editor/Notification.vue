<template>
	<div class="jet-fb-moosend-notification">
		<JetFormEditorRow :label="label( 'use_global' )">
			<input type="checkbox" v-model="instance.use_global"/>
		</JetFormEditorRow>
		<JetFormEditorRow :label="label( 'api_key' )">
			<div class="jet-form-editor__input-group">
				<input
					type="text"
					@input="setField( $event.target.value, 'api_key' )"
					:disabled="instance.use_global"
					:value="getApiKey()"
				>
				<button type="button"
						class="button button-default button-large jet-form-validate-button"
						:class="{
								'loading': isLoading,
								'is-valid': true === instance.isValidAPI && ! isLoading,
								'is-invalid': false === instance.isValidAPI && ! isLoading
							}"
						@click="validateAPI"
				>
					<i class="dashicons"></i>
					{{ instance.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }}
				</button>
			</div>
			<div class="jet-form-editor__row-notice">
				{{ help( 'help_prefix' ) }}
				<a :href="help( 'help_link' )" target="_blank">{{ help( 'help_suffix' ) }}</a>
			</div>
		</JetFormEditorRow>

		<template v-if="instance.isValidAPI">
			<JetFormEditorRow :label="label( 'double_opt_in' )">
				<input type="checkbox" v-model="instance.double_opt_in"/>
			</JetFormEditorRow>
			<JetFormEditorRow :label="label( 'mailing_list' )">
				<select v-model="instance.mailing_list">
					<option value="">--</option>
					<option v-for="({ value, label }) in instance.response.mailing_list" :value="value">
						{{ label }}
					</option>
				</select>
			</JetFormEditorRow>
			<div class="jet-form-editor__row" v-if="instance.mailing_list">
				<div class="jet-form-editor__row-label">{{ label( 'fields_map' ) }}</div>
				<div class="jet-form-editor__row-control">
					<div class="jet-form-editor__row-notice">{{ help( 'fields_map' ) }}</div>
					<div class="jet-form-editor__row-fields">
						<div class="jet-form-editor__row-map"
							 v-for="( fieldData, fieldId ) in mailingFields">
                <span>{{ fieldData.label }} <span class="jet-form-editor-required"
												  v-if="fieldData.required">*</span></span>
							<select @input="changeFieldMap( $event.target.value, fieldId )"
									:value="getFieldMap( fieldId )">
								<option value="">--</option>
								<option v-for="field in fields" :value="field">{{ field }}</option>
							</select>
						</div>
					</div>
				</div>
			</div>
		</template>
	</div>
</template>

<script>
import { getLocalizedFullPack } from '@/source'
import { JetFormEditorRow } from "jfb-editor"

Vue.config.devtools = true;

const { source, label, help } = getLocalizedFullPack;
const globalKey = JEBookingFormNotifications.globalTab( 'moosend' );

export default {
	name: 'moosend',
	components: {
		JetFormEditorRow,
	},
	props: {
		value: Object,
		fields: Array,
		jsonSource: Array,
	},
	data: function() {
		return {
			instance: {},
			isLoading: false,
			requestProcessing: '',
			response: {},
		};
	},
	created: function() {
		this.instance = this.value || {};
	},
	watch: {
		instance( newResponse ) {
			this.$emit( 'input', newResponse );
		},
	},
	computed: {
		mailingFields() {
			return this.instance.response.fields[ this.instance.mailing_list ];
		},
	},
	methods: {
		label: attr => label( attr ),
		help: attr => help( attr ),

		validateAPI: function() {
			const self = this;

			self.$set( self, 'isLoading', true );

			self.requestAPI()
				.always( () => {
					self.$set( self, 'isLoading', false );
				} );

		},
		requestAPI: function() {
			return ( jQuery.ajax( {
				url: ajaxurl,
				type: 'POST',
				data: {
					action: source.action,
					api_key: this.getApiKey(),
				},
			} ).done( response => {
				if ( response.success ) {
					this.setField( true, 'isValidAPI' );
					this.setField( response.data, 'response' );
				} else {
					this.setField( false, 'isValidAPI' );
				}
			} ) );
		},
		setField: function( value, key ) {
			this.$set( this.instance, key, value );
			this.$emit( 'input', this.instance );
		},
		changeFieldMap: function( value, key ) {
			if ( ! this.instance.fields_map ) {
				this.$set( this.instance, 'fields_map', {} );
			}
			this.$set( this.instance.fields_map, key, value );
			this.setField( this.instance.fields_map, 'fields_map' );
		},
		getFieldMap: function( key ) {
			return this.instance.fields_map && this.instance.fields_map[ key ] ? this.instance.fields_map[ key ] : '';
		},
		getApiKey: function() {
			return this.instance.use_global ? globalKey.api_key : this.instance.api_key;
		},
	},

}
</script>