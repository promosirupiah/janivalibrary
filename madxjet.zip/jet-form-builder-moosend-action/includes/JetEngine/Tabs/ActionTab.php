<?php


namespace Jet_FB_MooSend\JetEngine\Tabs;


use Jet_Engine\Modules\Forms\Tabs\Base_Form_Tab;
use Jet_FB_MooSend\ActionTabTrait;
use Jet_FB_MooSend\Plugin;


class ActionTab extends Base_Form_Tab {

	use ActionTabTrait;

	public function render_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug . "-{$this->slug()}",
			Plugin::instance()->plugin_url( 'assets/js/engine.admin.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}
}