<?php


namespace Jet_FB_MailerLite\Jet_Engine\Tabs;


use Jet_Engine\Modules\Forms\Tabs\Base_Form_Tab;
use Jet_FB_MailerLite\Mailer_Lite_Tab_Trait;
use Jet_FB_MailerLite\Plugin;


class Mailer_Lite_Tab extends Base_Form_Tab {

	use Mailer_Lite_Tab_Trait;

	public function render_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug . "-{$this->slug()}",
			Plugin::instance()->plugin_url( 'assets/js/engine.admin.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}
}