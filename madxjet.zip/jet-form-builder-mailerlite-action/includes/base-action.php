<?php


namespace Jet_FB_MailerLite;


use JetMailerLiteCore\Exceptions\BaseHandlerException;
use JetMailerLiteCore\JetFormBuilder\ActionCompatibility;

trait Base_Action {

	use ActionCompatibility;

	public function get_name() {
		return __( 'MailerLite', 'jet-form-builder-mailerlite-action' );
	}

	public function get_id() {
		return 'mailer_lite';
	}

	public function getGlobalOptionName() {
		return 'mailer-lite-tab';
	}

	/**
	 * @param $api_key
	 *
	 * @return mixed
	 */
	public function api_handler( $api_key ) {
		return Handler::instance()->api_key( $api_key );
	}

	/**
	 * @throws BaseHandlerException
	 */
	public function run_action() {
		$settings = $this->getSettingsWithGlobal();

		if ( empty( $settings['api_key'] ) || empty( $settings['group_id'] ) ) {
			throw new BaseHandlerException( 'invalid_api_key' );
		}

		$handler = $this->api_handler( $settings['api_key'] );

		if ( is_wp_error( $handler ) ) {
			throw new BaseHandlerException( 'invalid_api_key' );
		}
		$fields_map = $this->prepare_fields_map( $settings );

		$end_point = sprintf( 'groups/%d/subscribers', (int) $settings['group_id'] );

		$request_args = array(
			'method'  => 'POST',
			'body'    => json_encode( $fields_map ),
			'headers' => array(
				'Content-Type' => 'application/json; charset=utf-8',
			),
		);

		$response = $handler->request( $end_point, $request_args );

		if ( isset( $response['error'] ) ) {
			throw new BaseHandlerException(
				$this->parseDynamicException( 'error', $response['error']['message'] )
			);
		}
	}

	/**
	 * @param $settings
	 *
	 * @return array
	 * @throws BaseHandlerException
	 */
	public function prepare_fields_map( $settings ) {
		$response = array();
		$request = $this->getRequestData();

		if ( empty( $settings['fields_map'] ) ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		foreach ( $settings['fields_map'] as $param => $field ) {

			if ( empty( $field ) || empty( $request[ $field ] ) ) {
				continue;
			}
			if ( in_array( $param, array( 'email', 'name' ) ) ) {
				$response[ $param ] = $request[ $field ];
			} else {
				$response['fields'][ $param ] = $request[ $field ];
			}
		}

		return $response;
	}


}