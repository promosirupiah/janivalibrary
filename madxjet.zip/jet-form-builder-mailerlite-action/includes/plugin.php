<?php

namespace Jet_FB_MailerLite;

// If this file is called directly, abort.
use Jet_FB_MailerLite\Jet_Engine\Tabs\Manager_Tabs as JEF_Tab_Manager;
use Jet_FB_MailerLite\Jet_Form_Builder\Tabs\Manager_Tabs as JFB_Tab_Manager;
use Jet_FB_MailerLite\Jet_Form_Builder\Actions\Manager as JFB_Manager;
use Jet_FB_MailerLite\Jet_Engine\Notifications\Manager as JEF_Manager;

if ( ! defined( 'WPINC' ) ) {
	die();
}

class Plugin {
	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	public $slug = 'jet-form-builder-mailerlite-action';

	public function __construct() {
		$this->register_autoloader();
		$this->init_components();
	}

	public function init_components() {
		JFB_Manager::register();
		JEF_Manager::register();

		JEF_Tab_Manager::register();
		JFB_Tab_Manager::register();

		Handler::instance();

		$can_init_license = (
			is_admin()
			&& function_exists( 'jet_form_builder' )
			&& array_key_exists( 'addons_manager', get_object_vars( jet_form_builder() ) )
		);

		if ( $can_init_license ) {
			require $this->plugin_dir( 'includes/class-jfb-license-manager.php' );

			new \JFB_License_Manager();
		}
	}

	/**
	 * Register autoloader.
	 */
	public function register_autoloader() {
		require JET_FB_MAILERLITE_ACTION_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}

	public function get_version() {
		return JET_FB_MAILERLITE_ACTION_VERSION;
	}

	public function plugin_url( $path ) {
		return JET_FB_MAILERLITE_ACTION_URL . $path;
	}

	public function plugin_dir( $path = '' ) {
		return JET_FB_MAILERLITE_ACTION_PATH . $path;
	}

	public function get_template_path( $template ) {
		$path = JET_FB_MAILERLITE_ACTION_PATH . 'templates' . DIRECTORY_SEPARATOR;

		return ( $path . $template . '.php' );
	}

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @return Plugin An instance of the class.
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}

Plugin::instance();