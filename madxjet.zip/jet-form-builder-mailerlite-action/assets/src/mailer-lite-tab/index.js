import MailerLiteTab from './MailerLiteTab.vue';

const { __ } = wp.i18n;

const title = __( 'MailerLite API', 'jet-form-builder' );
const component = MailerLiteTab;

export {
	title,
	component
}