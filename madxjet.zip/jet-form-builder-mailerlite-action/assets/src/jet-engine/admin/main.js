import * as mailerLiteTab from '@/mailer-lite-tab';

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.engine.formTabs.register', 'jet-engine', tabs => {
	tabs.push( mailerLiteTab );

	return tabs;
} );