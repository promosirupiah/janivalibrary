# JetFormBuilder MailerLite Action
Addon for JetFormBuilder

# ChangeLog

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager