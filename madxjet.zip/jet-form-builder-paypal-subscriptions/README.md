# JetFormBuilder Paypal Subscriptions
A tweak that allows you to create subscriptions and accept recurring payments via PayPal-integrated forms.

# ChangeLog

## 1.0.1
* Tweak: Return queried resources in webhooks

## 1.0.0
* Initial release.