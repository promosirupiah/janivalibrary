<?php


namespace Jet_FB_Paypal;

trait SubscribeNowConnector {

	public static function scenario_id() {
		return 'SUBSCRIBE_NOW';
	}
}
