<?php


namespace Jet_FB_Paypal\QueryViews;


use Jet_Form_Builder\Db_Queries\Views\View_Base_Count_Trait;

class PaymentsWithSalesCount extends PaymentsWithSales {

	use View_Base_Count_Trait;

}