<?php


namespace Jet_FB_Stripe_Gateway\Compatibility\Jet_Form_Builder;


use Jet_FB_Stripe_Gateway\Compatibility\Base_Stripe;
use Jet_FB_Stripe_Gateway\Plugin;
use Jet_Form_Builder as JFB;
use Jet_FB_Stripe_Gateway\Api_Methods\Checkout_Session;

class Controller extends JFB\Gateways\Base_Gateway {

	use Base_Stripe;

	protected $token_query_name = 'order_token';

	protected function retrieve_gateway_meta() {
		$this->encode_fields_rollback();

		return jet_form_builder()->post_type->get_gateways( $this->data['form_id'] );
	}

	protected function retrieve_payment_instance() {
		return $this->request( array(), '/' . $this->data['payment_id'], false );
	}

	/**
	 * @throws JFB\Exceptions\Gateway_Exception
	 */
	protected function set_gateway_data_on_result() {
		$this->set_payment_status();
		$this->set_amount();
		$this->set_customer_details();
	}

	protected function set_payment_status() {
		if ( isset( $this->payment_instance['error'] ) ) {
			throw new JFB\Exceptions\Gateway_Exception( $this->payment_instance['error']['message'] );
		}

		if ( empty( $this->payment_instance['payment_status'] ) ) {
			throw new JFB\Exceptions\Gateway_Exception( 'Empty payment status' );
		}

		$this->data['status'] = $this->payment_instance['payment_status'];
	}

	private function set_amount() {
		$this->data['amount'] = array(
			'value'         => $this->get_formated_amount( $this->payment_instance['amount_total'] ),
			'currency_code' => $this->payment_instance['currency']
		);
	}

	private function set_customer_details() {
		$this->data['payer']['email'] = $this->payment_instance['customer_details']['email'];
	}

	protected function encode_fields_rollback() {
		$decoded_fields = $this->data['decoded'] ?? array();

		foreach ( $decoded_fields as $field ) {
			$value = $this->data['form_data'][ $field ] ?? array();

			$this->data['form_data'][ $field ] = JFB\Classes\Tools::encode_json( $value );
		}
	}

	protected function get_prepared_request( JFB\Actions\Action_Handler $action_handler ): array {
		$changed = array();

		foreach ( $action_handler->request_data as $field => $value ) {
			if ( ! is_scalar( $value ) ) {
				continue;
			}
			$decoded = JFB\Classes\Tools::decode_json( $value );
			if ( is_null( $decoded ) ) {
				continue;
			}
			$changed[ $field ] = $decoded;
		}

		return array(
			array_keys( $changed ),
			array_merge( $action_handler->request_data, $changed )
		);
	}

	/**
	 * Process gateway payment
	 *
	 * @param $action_handler
	 *
	 * @return void [description]
	 * @throws JFB\Exceptions\Action_Exception
	 */
	public function after_actions( JFB\Actions\Action_Handler $action_handler ) {

		if ( ! $this->set_gateway_data( $action_handler ) ) {
			return;
		}
		$additional_args = array( 'order_token' => $this->order_token );

		$payment = $this->get_checkout_session( array(
			'success_url' => $this->get_refer_url( self::SUCCESS_TYPE, $additional_args ),
			'cancel_url'  => $this->get_refer_url( self::FAILED_TYPE, $additional_args ),
		) );

		if ( ! $payment || isset( $payment['error'] ) ) {
			throw new JFB\Exceptions\Action_Exception(
				JFB\Form_Messages\Manager::dynamic_error( $payment['error']['message'] ),
				$this->gateways_meta,
				$payment
			);
		}

		list( $decoded_fields, $request ) = $this->get_prepared_request( $action_handler );

		update_post_meta(
			$this->order_id,
			self::GATEWAY_META_KEY,
			json_encode( array(
				'payment_id'  => $payment['id'],
				'order_token' => $this->order_token,
				'form_id'     => $action_handler->form_id,
				'form_data'   => $request,
				'decoded'     => $decoded_fields,
			), JSON_UNESCAPED_UNICODE )
		);

		$action_handler->add_response( array(
			'stripe_session_id' => $payment['id'],
			'stripe_public_key' => $this->options['public']
		) );
	}


	public function request( $params, $endpoint = '', $post = true ) {
		if ( empty( $this->gateways_meta[ $this->get_id() ]['secret'] ) ) {
			return false;
		}
		$secret = $this->gateways_meta[ $this->get_id() ]['secret'];

		$checkout = new Checkout_Session( $secret );

		$checkout->create( $params, $endpoint, $post );

		return $checkout->get_response( 'create' );
	}
}