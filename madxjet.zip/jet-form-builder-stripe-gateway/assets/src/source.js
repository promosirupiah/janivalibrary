const { __ } = wp.i18n;

const label = {
	public: __( 'Public Key', 'jet-form-builder' ),
	secret: __( 'Secret Key', 'jet-form-builder' )
};

const help = {};

export { label, help };