# JetFormBuilder MailPoet Action
Addon for JetFormBuilder & JetEngine

# ChangeLog

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager