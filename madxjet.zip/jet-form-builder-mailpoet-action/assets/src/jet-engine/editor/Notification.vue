<template>
	<div class="jet-fb-mailpoet-notification">
		<JetFormEditorRow :label="label( 'sync' )">
			<button type="button"
					class="button button-default button-large jet-form-validate-button"
					:class="{
								'loading': isLoading,
							}"
					@click="validateAPI"
			>
				<i class="dashicons"></i>
				{{ label( 'make_request' ) }}
			</button>
		</JetFormEditorRow>

		<template v-if="instance.isValidAPI">
			<div class="jet-form-editor__row">
				<div class="jet-form-editor__row-label">{{ label( 'list_ids' ) }}</div>
				<div class="jet-form-editor__row-control">
					<div class="jet-form-editor__row-fields">
						<div class="jet-form-editor__row-map"
							 v-for="listData in instance.response.lists">
							<span>{{ listData.label }}</span>
							<input
								type="checkbox"
								@change="changeFieldMap( $event.target.checked, listData.value, 'list_ids' )"
								:checked="getFieldMap( listData.value, 'list_ids' )"
							/>
							<div
								class="jet-form-editor__row-notice"
								style="padding-left: 2em;"
								v-if="listData.desc"
							>
								{{ listData.desc }}
							</div>
						</div>
					</div>
				</div>
			</div>
			<JetFormEditorRow :label="label( 'send_confirmation_email' )">
				<input type="checkbox" v-model="instance.send_confirmation_email"/>
			</JetFormEditorRow>
			<JetFormEditorRow :label="label( 'schedule_welcome_email' )">
				<input type="checkbox" v-model="instance.schedule_welcome_email"/>
			</JetFormEditorRow>
			<JetFormEditorRow :label="label( 'skip_subscriber_notification' )">
				<input type="checkbox" v-model="instance.skip_subscriber_notification"/>
			</JetFormEditorRow>
			<div class="jet-form-editor__row">
				<div class="jet-form-editor__row-label">{{ label( 'fields_map' ) }}</div>
				<div class="jet-form-editor__row-control">
					<div class="jet-form-editor__row-notice">{{ help( 'fields_map' ) }}</div>
					<div class="jet-form-editor__row-fields">
						<div class="jet-form-editor__row-map"
							 v-for="( fieldData, fieldId ) in subscriberFields">
                <span>{{ fieldData.label }} <span class="jet-form-editor-required"
												  v-if="fieldData.required">*</span></span>
							<select @input="changeFieldMap( $event.target.value, fieldId )"
									:value="getFieldMap( fieldId )">
								<option value="">--</option>
								<option v-for="field in fields" :value="field">{{ field }}</option>
							</select>
						</div>
					</div>
				</div>
			</div>
		</template>
	</div>
</template>

<script>
import { getLocalizedFullPack } from '@/source'
import { JetFormEditorRow } from "jfb-editor"

Vue.config.devtools = true;

const { source, label, help } = getLocalizedFullPack;

export default {
	name:       'mailpoet',
	components: {
		JetFormEditorRow,
	},
	props:      {
		value:      Object,
		fields:     Array,
		jsonSource: Array,
	},
	data:       function() {
		return {
			instance:          {},
			isLoading:         false,
			requestProcessing: '',
			response:          {},
		};
	},
	created:    function() {
		this.instance = this.value || {};
	},
	watch:      {
		instance( newResponse ) {
			this.$emit( 'input', newResponse );
		},
	},
	computed:   {
		subscriberFields() {
			return this.instance.response.fields;
		},
	},
	methods:    {
		label: attr => label( attr ),
		help:  attr => help( attr ),

		validateAPI:    function() {
			const self = this;

			self.$set( self, 'isLoading', true );

			self.requestAPI()
			.always( () => {
				self.$set( self, 'isLoading', false );
			} );

		},
		requestAPI:     function() {
			return ( jQuery.ajax( {
				url:  ajaxurl,
				type: 'POST',
				data: {
					action: source.action,
				},
			} ).done( response => {
				if ( response.success ) {
					this.setField( true, 'isValidAPI' );
					this.setField( response.data, 'response' );
				} else {
					this.setField( false, 'isValidAPI' );
				}
			} ) );
		},
		setField:       function( value, key ) {
			this.$set( this.instance, key, value );
			this.$emit( 'input', this.instance );
		},
		changeFieldMap: function( value, key, source = 'fields_map' ) {
			if ( ! this.instance[ source ] ) {
				this.$set( this.instance, source, {} );
			}
			this.$set( this.instance[ source ], key, value );
			this.setField( this.instance[ source ], source );
		},
		getFieldMap:    function( key, source = 'fields_map' ) {
			return this.instance[ source ] && this.instance[ source ][ key ] ? this.instance[ source ][ key ] : '';
		},
	},

}
</script>