import { Actions } from "jfb-editor";

const { __ } = wp.i18n;

const getLocalizedFullPack = new Actions.EditorData( 'mailpoet' )
.setLabels( {
	sync: __( 'Synchronize data' ),
	make_request: __( 'Make a request' ),
	list_ids: __( 'Lists' ),
	fields_map: __( 'Fields Map' ),
	send_confirmation_email: __( 'Send Confirmation Email' ),
	schedule_welcome_email: __( 'Schedule Welcome Email' ),
	skip_subscriber_notification: __( 'Skip Subscriber Notification' )
} )
.setHelp( {
	fields_map: __( 'Set form fields names to to get user data from' ),
} )
.setGatewayAttrs( [
	"tag_id"
] )
.setSource( {
	action: 'jet_form_builder_get_mailpoet_data',
} )
.exportAll();

export { getLocalizedFullPack };