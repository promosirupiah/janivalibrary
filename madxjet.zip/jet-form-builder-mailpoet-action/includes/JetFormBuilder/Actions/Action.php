<?php


namespace Jet_FB_MailPoet\JetFormBuilder\Actions;


use Jet_FB_MailPoet\BaseAction;
use JetMailPoetCore\JetFormBuilder\SmartBaseAction;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Action extends SmartBaseAction {

	use BaseAction;

}

