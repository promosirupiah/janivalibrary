<?php


namespace Jet_FB_Schedule_Forms\Jet_Engine;


use Jet_FB_Schedule_Forms\Schedule_Form;
use JetScheduleFormsCore\JetEngine\PreventFormSubmit;

class Prevent_Form_Submit extends PreventFormSubmit {

	public function prevent_process_ajax_form( $handler ) {
		Schedule_Form::get_jef_settings( $handler->form );

		$type = Schedule_Form::get_schedule_type();

		if ( ! $type ) {
			return;
		}
		//$message = Schedule_Form::get_message( $type );

		$handler->redirect( array(
			'status' => 'failed',
		) );
	}

	public function prevent_process_reload_form( $handler ) {
		Schedule_Form::get_jef_settings( $handler->form );

		$type = Schedule_Form::get_schedule_type();

		if ( ! $type ) {
			return;
		}

		$handler->redirect( array(
			'status' => 'failed',
		) );
	}

}