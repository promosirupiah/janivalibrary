import {
	help,
	labels,
	options
} from "@/source";

const {
	ToggleControl,
	SelectControl,
	TextareaControl,
	__experimentalNumberControl,
} = wp.components;

let { NumberControl } = wp.components;

if ( typeof NumberControl === 'undefined' ) {
	NumberControl = __experimentalNumberControl;
}

const { useMetaState } = JetFBHooks;
const { HorizontalLine } = JetFBComponents;

export default function PluginLimitFormResponses() {

	const [ limitOptions, setLimitOptions ] = useMetaState( '_jf_limit_responses' );

	return <>
		<ToggleControl
			label={ labels.enable }
			checked={ limitOptions.enable }
			onChange={ enable => {
				setLimitOptions( prev => ( { ...prev, enable } ) );
			} }
		/>
		{ limitOptions.enable && <>
			<NumberControl
				label={ labels.limit }
				value={ limitOptions.limit || 1 }
				min={ 1 }
				onChange={ limit => setLimitOptions( prev => ( { ...prev, limit } ) ) }
			/>
			<TextareaControl
				label={ labels.closed_message }
				help={ help.closed_message }
				value={ limitOptions.closed_message }
				onChange={ closed_message => {
					setLimitOptions( prev => ( { ...prev, closed_message } ) );
				} }
			/>
		</> }
		<HorizontalLine/>
		<ToggleControl
			label={ labels.restrict_users }
			checked={ limitOptions.restrict_users }
			help={ help.restrict_users }
			onChange={ restrict_users => {
				setLimitOptions( prev => ( { ...prev, restrict_users } ) );
			} }
		/>
		{ limitOptions.restrict_users && <>
			<SelectControl
				label={ labels.restrict_by }
				options={ options.restrict_by }
				value={ limitOptions.restrict_by }
				onChange={ restrict_by => setLimitOptions( prev => ( { ...prev, restrict_by } ) ) }
			/>
			<TextareaControl
				label={ labels.restricted_message }
				value={ limitOptions.restricted_message }
				help={ help.restricted_message }
				onChange={ restricted_message => {
					setLimitOptions( prev => ( { ...prev, restricted_message } ) );
				} }
			/>
			{ 'user' === limitOptions.restrict_by && <TextareaControl
				label={ labels.guest_message }
				value={ limitOptions.guest_message }
				onChange={ guest_message => setLimitOptions( prev => ( { ...prev, guest_message } ) ) }
			/> }
		</> }
		{ ( limitOptions.restrict_users || limitOptions.enable ) && <>
			<HorizontalLine/>
			<TextareaControl
				label={ labels.error_message }
				help={ help.error_message }
				value={ limitOptions.error_message }
				onChange={ error_message => {
					setLimitOptions( prev => ( { ...prev, error_message } ) );
				} }
			/>
		</> }
	</>;
}