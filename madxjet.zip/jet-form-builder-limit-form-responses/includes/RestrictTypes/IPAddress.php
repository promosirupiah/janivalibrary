<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;


class IPAddress extends RestrictTypeBase {

	private $client_ip;

	const RESTRICT_META_KEY = '_restrict_client_ip_addresses';

	public function get_id() {
		return 'id_address';
	}

	public function count_submissions( $settings, $form_id ) {
		$this->set_ip(
			sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
		);

		$addresses = $this->get_restricted_addresses( $form_id );

		if ( empty( $addresses ) ) {
			return 0;
		}

		return isset( $addresses[ $this->client_ip ] )
			? filter_var( $addresses[ $this->client_ip ], FILTER_VALIDATE_INT )
			: 0;
	}

	/**
	 * @param $settings
	 * @param $form_id
	 *
	 * @return boolean
	 */
	public function increment_submissions( $settings, $form_id ) {
		$counters = self::counters( $form_id );
		$counters[ self::RESTRICT_META_KEY ][ $this->client_ip ] = 1;

		return $this->update_counters_json_meta( $counters, $form_id );
	}

	private function set_ip( $ip ) {
		$this->client_ip = $ip;
	}

	private function get_restricted_addresses( $form_id ) {
		$counters = self::counters( $form_id );

		return isset( $counters[ self::RESTRICT_META_KEY ] )
			? $counters[ self::RESTRICT_META_KEY ]
			: array();
	}
}