<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;


use Jet_FB_Limit_Form_Responses\LimitResponses;

class Cookie extends RestrictTypeBase {

	private $cookie_val;

	public function get_id() {
		return 'cookie';
	}

	/**
	 * @inheritDoc
	 */
	public function count_submissions( $settings, $form_id ) {
		$key = LimitResponses::PLUGIN_META_KEY;

		$this->cookie_val = ( ! empty( $_COOKIE ) && isset( $_COOKIE[ $key ] ) && isset( $_COOKIE[ $key ][ $form_id ] ) )
			? $_COOKIE[ $key ]
			: array( $form_id => 0 );

		return $this->cookie_val[ $form_id ];
	}

	public function increment_submissions( $settings, $form_id ) {
		return $this->set_cookie( $form_id, ++ $this->cookie_val[ $form_id ] );
	}

	public function set_cookie( $form_id, $value ) {
		$cookie_name = LimitResponses::PLUGIN_META_KEY . "[$form_id]";
		$expire      = time() + YEAR_IN_SECONDS * 100;
		$secure      = ( false !== strstr( get_option( 'home' ), 'https:' ) && is_ssl() );

		return setcookie(
			$cookie_name,
			$value,
			$expire,
			COOKIEPATH ? COOKIEPATH : '/',
			COOKIE_DOMAIN,
			$secure,
			true
		);
	}
}