<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;

use Jet_FB_Limit_Form_Responses\LimitResponses;
use JetLimitResponsesCore\Common\MetaQuery;

abstract class RestrictTypeBase {

	abstract public function get_id();

	/**
	 * Return 0 inside, if you want to update the submissions
	 *
	 * @param $settings
	 * @param $form_id
	 *
	 * @return integer
	 */
	abstract public function count_submissions( $settings, $form_id );

	abstract public function increment_submissions( $settings, $form_id );

	public function limit_submissions( $settings, $form_id ) {
		return apply_filters( 'jet-fb/limit-form-responses/user-limit-responses', 1, $settings, $form_id );
	}

	public function check_submissions( $settings, $form_id ) {
		$submissions = $this->count_submissions( $settings, $form_id );
		$limit       = $this->limit_submissions( $settings, $form_id );

		return ( $submissions >= $limit );
	}

	final public function is_reached_limit( $run_increment ) {
		$settings = self::settings();
		$form_id  = self::Limit()->form_id();

		/**
		 * If count of submissions exceeded or reached the limit
		 */
		if ( $this->check_submissions( $settings, $form_id ) ) {
			return true;
		}

		if ( ! $run_increment ) {
			return false;
		}

		return ( ! $this->increment_submissions( $settings, $form_id ) );
	}

	public static function settings( $form_id = 0 ) {
		return LimitResponses::instance()->get_settings( $form_id );
	}

	public static function counters( $form_id = 0 ) {
		return LimitResponses::instance()->get_counters( $form_id );
	}

	public static function Limit() {
		return LimitResponses::instance();
	}

	public function update_json_meta( $settings, $form_id ) {
		return MetaQuery::set_json_meta(
			array(
				'id'    => $form_id,
				'value' => $settings,
				'key'   => LimitResponses::PLUGIN_META_KEY,
			)
		);
	}

	public function update_counters_json_meta( $settings, $form_id ) {
		return MetaQuery::set_json_meta(
			array(
				'id'    => $form_id,
				'value' => $settings,
				'key'   => LimitResponses::PLUGIN_META_COUNTER_KEY,
			)
		);
	}

}
