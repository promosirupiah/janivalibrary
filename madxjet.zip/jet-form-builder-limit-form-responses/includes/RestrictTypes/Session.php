<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;

use Jet_FB_Limit_Form_Responses\LimitResponses;

class Session extends RestrictTypeBase {

	private $session = array();

	public function get_id() {
		return 'session';
	}

	/**
	 * @inheritDoc
	 */
	public function count_submissions( $settings, $form_id ) {
		$this->start_session();

		$key = LimitResponses::PLUGIN_META_KEY;

		$this->session = isset( $_SESSION[ $key ][ $form_id ] )
			? $_SESSION[ $key ]
			: array( $form_id => 0 );

		return $this->session[ $form_id ];
	}

	public function increment_submissions( $settings, $form_id ) {
		$this->start_session();

		$this->session[ $form_id ] ++;

		$key              = LimitResponses::PLUGIN_META_KEY;
		$_SESSION[ $key ] = $this->session;

		return true;
	}

	/**
	 * Maybe start session
	 */
	public function start_session() {
		if ( headers_sent() ) {
			return;
		}

		if ( ! session_id() ) {
			session_start();
		}
	}

}
