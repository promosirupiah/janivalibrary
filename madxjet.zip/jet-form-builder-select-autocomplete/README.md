# JetFormBuilder Select Autocomplete
Premium Addon for JetFormBuilder &amp; JetEngine Forms

# ChangeLog

## 1.0.3
* Tweak: Removed unnecessary hook

## 1.0.2
* Tweak: add license manager

## 1.0.1
* FIX: allowed guests to use autocomplete
* Tweak: added js hook `jet.fb.select_autocomplete.options`

## 1.0.0
* Initial release
