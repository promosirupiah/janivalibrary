import Modifier from "./Modifier.vue";

const { addFilter } = wp.hooks;

addFilter( 'jet.engine.register.fields', 'jet-engine', fields => {
	fields.push( Modifier );

	return fields;
} );
