<?php


namespace Jet_FB_SelectAutocomplete\JetFormBuilder;


use Jet_FB_SelectAutocomplete\BaseAjaxHandler;
use Jet_Form_Builder\Blocks\Types\Select_Field;
use Jet_Form_Builder\Plugin as JFBPlugin;

class AjaxHandler extends BaseAjaxHandler {

	public function type(): string {
		return 'jfb';
	}

	public function get_field_options(): array {
		$field = JFBPlugin::instance()->form->get_field_by_name( $this->form_id, $this->field_name );

		if ( ! $field ) {
			wp_send_json_error();
		}

		$block = JFBPlugin::instance()->blocks->get_field_by_name( $field['blockName'] );

		if ( ! $block ) {
			wp_send_json_error();
		}
		/** @var Select_Field $block */
		$block->set_block_data( $field['attrs'] );

		return $block->get_field_options();
	}


}