<?php


namespace Jet_FB_SelectAutocomplete\JetFormBuilder;


use Jet_FB_SelectAutocomplete\BaseSelectModifier;
use Jet_FB_SelectAutocomplete\Plugin;
use JetSelectAutocompleteCore\JetFormBuilder\BaseFieldModifier;

class SelectModifier extends BaseFieldModifier {

	use BaseSelectModifier;

	public function type(): string {
		return 'select-field';
	}

	public function blockAttributes( $args ): array {
		$args['attributes']['autocomplete_enable']   = array(
			'type'    => 'boolean',
			'default' => '',
		);
		$args['attributes']['autocomplete_via_ajax'] = array(
			'type'    => 'boolean',
			'default' => '',
		);

		return $args;
	}

	public function editorAssets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/js/builder.editor.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Select Autocomplete</b> needs <b>JetFormBuilder</b> update.',
			'jet-form-builder-select-autocomplete'
		) );
	}

	public function on_base_need_install() {
	}
}