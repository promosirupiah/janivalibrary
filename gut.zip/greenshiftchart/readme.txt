=== Greenshift Chart Addon ===
Contributors: wpsoul
Tags: gutenberg, block, query, full site editor, chart
Author: GreenshiftWP
Author URI: https://greenshiftwp.com/
Requires at least: 5.9
Tested up to: 6.1
Requires PHP: 7.0
Stable tag: 1.2

Add different types of diagrams on your site

== Changelog ==

= 1.1 =
* Removed: Freemius