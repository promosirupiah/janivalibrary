=== Greenshift Woocommerce Addon ===
Contributors: wpsoul
Tags: gutenberg, block, query, full site editor
Author: Wpsoul
Author URI: https://greenshiftwp.com
Requires at least: 6.2
Tested up to: 6.3
Requires PHP: 7.0
Stable tag: 1.4.8

Addon for Greenshift for Woocommerce