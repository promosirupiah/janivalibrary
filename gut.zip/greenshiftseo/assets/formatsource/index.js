"use strict";
let gspbsources = document.getElementsByClassName("gspb-ext-source");
for (let i = 0; i < gspbsources.length; i++) {
    let itemtext = gspbsources[i].innerHTML;
    let iteml = gspbsources[i].dataset.dest;
    let a = document.createElement('a'); 
    let atext = document.createTextNode(itemtext);
    a.appendChild(atext); 
    a.href = iteml; 
    a.setAttribute("target", "_blank");
    a.setAttribute("rel", "nofollow");
    gspbsources[i].replaceWith(a);
}