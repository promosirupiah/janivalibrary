"use strict";

var popuptrigger = document.getElementsByClassName('gspbcsspopuptrigger');
for (let i = 0; i < popuptrigger.length; i++) {
    let togglerobj= popuptrigger[i];
    togglerobj.addEventListener('click', function (ev) {
        ev.preventDefault();
        let destination = togglerobj.dataset.popup;
        document.getElementById(destination).classList.toggle('active');
        document.body.classList.add('gspbflowhidden');
    });
}

var popupclose = document.getElementsByClassName('gspbcpopupclose');
for (let i = 0; i < popupclose.length; i++) {
    let togglerobj= popupclose[i];
    togglerobj.addEventListener('click', function (ev) {
        ev.preventDefault();
        togglerobj.closest('.gspbcsspopup').classList.remove('active');
        document.body.classList.remove('gspbflowhidden');
    });
}