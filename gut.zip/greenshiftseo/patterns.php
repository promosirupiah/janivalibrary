<?php

// Exit if accessed directly.
if (!defined('ABSPATH')) {
	exit;
}

register_block_pattern_category(
    'greenshiftseoelements',
    array( 'label' => __( 'Greenshift SEO Elements', 'greenshiftseo' ) )
);

// 	'blockTypes'    => array( 'greenshift-blocks/button' ), 
register_block_pattern(
    'greenshiftseo/versustwo',
    array(
        'title'       => __( 'Versus 2 items table', 'greenshift' ),
        'categories' => array('greenshiftseoelements'),
		'keywords' => array('comparison', 'versus'),
		'description' => _x( 'Versus table with 2 items', 'Block pattern description', 'greenshift' ),
        'content'     => '<!-- wp:greenshift-blocks/container {"id":"gsbp-5140977d-832a"} -->
        <div id="gspb_container-id-gsbp-5140977d-832a" class="gspb_container gspb_container-gsbp-5140977d-832a wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/row {"id":"gsbp-fdb209e2-c844","rowLayout":"2","columnPosition":"center","displayStyles":false,"background":{"color":"#f7f7f7"},"spacing":{"margin":{"values":{"top":[30]},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":false}}} -->
        <div id="gspb_row-id-gsbp-fdb209e2-c844" class="gspb_row gspb_row-id-gsbp-fdb209e2-c844 wp-block-greenshift-blocks-row gspb_row-id-gsbp-fdb209e2-c844"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-2e55696d-bd12","columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-2e55696d-bd12" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-2e55696d-bd12"><!-- wp:greenshift-blocks/heading {"id":"gsbp-814ac46d-1bc1","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003eMavic 2 Pro vs Mavic Air2\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Epic battle"} -->
        <div id="gspb_heading-id-gsbp-814ac46d-1bc1" class="gspb_heading gspb_heading-id-gsbp-814ac46d-1bc1 "><strong><strong>Mavic 2 Pro vs Mavic Air2</strong></strong><span class="gspb_heading_subtitle">Epic battle</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-0a19dfd1-a3be","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-0a19dfd1-a3be" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-0a19dfd1-a3be"><!-- wp:greenshift-blocks/container {"id":"gsbp-da1129d7-9f92","flexbox":{"type":"grid","enable":false,"gridcolumns":[3,null,null,3],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-da1129d7-9f92" class="gspb_container gspb_container-gsbp-da1129d7-9f92 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-077c9fe9-f377","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-077c9fe9-f377" class="gspb_container gspb_container-gsbp-077c9fe9-f377 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/image {"id":"gsbp-5fe7c517-dae5","width":["custom",null,null,null],"customWidth":[70,null,null,null],"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"mediaurl":"https://via.placeholder.com/300","alt":""} -->
        <div id="gspb_image-id-gsbp-5fe7c517-dae5" class="gspb_image gspb_image-id-gsbp-5fe7c517-dae5 wp-block-greenshift-blocks-image"><img src="https://via.placeholder.com/300" data-src="" alt="" width="70" /></div>
        <!-- /wp:greenshift-blocks/image --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-fbc5b91c-13f7","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-fbc5b91c-13f7" class="gspb_container gspb_container-gsbp-fbc5b91c-13f7 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-8b98cb66-93df","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-8b98cb66-93df" class="gspb_heading gspb_heading-id-gsbp-8b98cb66-93df ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-96419b3b-3eb1","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-96419b3b-3eb1" class="gspb_container gspb_container-gsbp-96419b3b-3eb1 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/image {"id":"gsbp-8cf86be5-ef18","width":["custom",null,null,null],"customWidth":[70,null,null,null],"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"mediaurl":"https://via.placeholder.com/300","alt":""} -->
        <div id="gspb_image-id-gsbp-8cf86be5-ef18" class="gspb_image gspb_image-id-gsbp-8cf86be5-ef18 wp-block-greenshift-blocks-image"><img src="https://via.placeholder.com/300" data-src="" alt="" width="70" /></div>
        <!-- /wp:greenshift-blocks/image --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-11bbf406-ffa4","rowLayout":"2","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-11bbf406-ffa4" class="gspb_row gspb_row-id-gsbp-11bbf406-ffa4 wp-block-greenshift-blocks-row gspb_row-id-gsbp-11bbf406-ffa4"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-36064c61-c9b4","columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-36064c61-c9b4" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-36064c61-c9b4"><!-- wp:greenshift-blocks/heading {"id":"gsbp-979d5ddf-45cc","headingTag":"div","headingContent":"\u003cstrong\u003eHD Video\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"4k and 8k"} -->
        <div id="gspb_heading-id-gsbp-979d5ddf-45cc" class="gspb_heading gspb_heading-id-gsbp-979d5ddf-45cc "><strong>HD Video</strong><span class="gspb_heading_subtitle">4k and 8k</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-5fc436b8-aa8d","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-5fc436b8-aa8d" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-5fc436b8-aa8d"><!-- wp:greenshift-blocks/container {"id":"gsbp-a0fbcb4c-cc53","flexbox":{"type":"grid","enable":false,"gridcolumns":[3,null,null,3],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-a0fbcb4c-cc53" class="gspb_container gspb_container-gsbp-a0fbcb4c-cc53 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-8119fe70-c5f7","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-8119fe70-c5f7" class="gspb_container gspb_container-gsbp-8119fe70-c5f7 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-5055abb4-948f","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-5055abb4-948f" class="gspb_iconBox gspb_iconBox-id-gsbp-5055abb4-948f wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-fb72a4f6-3cdf","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-fb72a4f6-3cdf" class="gspb_container gspb_container-gsbp-fb72a4f6-3cdf wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-5d44076d-1532","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-5d44076d-1532" class="gspb_heading gspb_heading-id-gsbp-5d44076d-1532 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-916865d3-6ab1","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-916865d3-6ab1" class="gspb_container gspb_container-gsbp-916865d3-6ab1 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-dfadb7f2-8da4","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-dfadb7f2-8da4" class="gspb_iconBox gspb_iconBox-id-gsbp-dfadb7f2-8da4 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-c2c11f99-a48d","rowLayout":"2","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-c2c11f99-a48d" class="gspb_row gspb_row-id-gsbp-c2c11f99-a48d wp-block-greenshift-blocks-row gspb_row-id-gsbp-c2c11f99-a48d"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-54cc78fd-4a38","columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-54cc78fd-4a38" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-54cc78fd-4a38"><!-- wp:greenshift-blocks/heading {"id":"gsbp-0fc16408-2e47","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003eSmartFocus\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Focus and tracking"} -->
        <div id="gspb_heading-id-gsbp-0fc16408-2e47" class="gspb_heading gspb_heading-id-gsbp-0fc16408-2e47 "><strong><strong>SmartFocus</strong></strong><span class="gspb_heading_subtitle">Focus and tracking</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-e5ddcc16-34e9","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-e5ddcc16-34e9" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-e5ddcc16-34e9"><!-- wp:greenshift-blocks/container {"id":"gsbp-9fc11bde-1919","flexbox":{"type":"grid","enable":false,"gridcolumns":[3,null,null,3],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-9fc11bde-1919" class="gspb_container gspb_container-gsbp-9fc11bde-1919 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-29716ed9-d551","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-29716ed9-d551" class="gspb_container gspb_container-gsbp-29716ed9-d551 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-48bd4e90-93dd","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-48bd4e90-93dd" class="gspb_iconBox gspb_iconBox-id-gsbp-48bd4e90-93dd wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-85474eae-f9dd","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-85474eae-f9dd" class="gspb_container gspb_container-gsbp-85474eae-f9dd wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-77fd7579-5860","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-77fd7579-5860" class="gspb_heading gspb_heading-id-gsbp-77fd7579-5860 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-87c5e176-b315","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-87c5e176-b315" class="gspb_container gspb_container-gsbp-87c5e176-b315 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-08a240b8-021c","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-08a240b8-021c" class="gspb_iconBox gspb_iconBox-id-gsbp-08a240b8-021c wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-fead564e-3627","rowLayout":"2","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-fead564e-3627" class="gspb_row gspb_row-id-gsbp-fead564e-3627 wp-block-greenshift-blocks-row gspb_row-id-gsbp-fead564e-3627"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-a03d6bc6-ad02","columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-a03d6bc6-ad02" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-a03d6bc6-ad02"><!-- wp:greenshift-blocks/heading {"id":"gsbp-8271fab2-2de0","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003eQuick Shots\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Functional blocks"} -->
        <div id="gspb_heading-id-gsbp-8271fab2-2de0" class="gspb_heading gspb_heading-id-gsbp-8271fab2-2de0 "><strong><strong><strong>Quick Shots</strong></strong></strong><span class="gspb_heading_subtitle">Functional blocks</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-085a9ece-c7e3","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-085a9ece-c7e3" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-085a9ece-c7e3"><!-- wp:greenshift-blocks/container {"id":"gsbp-650e3f1a-a1a7","flexbox":{"type":"grid","enable":false,"gridcolumns":[3,null,null,3],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-650e3f1a-a1a7" class="gspb_container gspb_container-gsbp-650e3f1a-a1a7 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-6162ebd3-a1bd","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-6162ebd3-a1bd" class="gspb_container gspb_container-gsbp-6162ebd3-a1bd wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-cfd660ef-47e5","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-cfd660ef-47e5" class="gspb_iconBox gspb_iconBox-id-gsbp-cfd660ef-47e5 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-46f73b17-662d","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-46f73b17-662d" class="gspb_container gspb_container-gsbp-46f73b17-662d wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-8c4d1a21-0e1d","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-8c4d1a21-0e1d" class="gspb_heading gspb_heading-id-gsbp-8c4d1a21-0e1d ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-bac2cfb4-9e64","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-bac2cfb4-9e64" class="gspb_container gspb_container-gsbp-bac2cfb4-9e64 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-1504e61d-54f7","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-1504e61d-54f7" class="gspb_iconBox gspb_iconBox-id-gsbp-1504e61d-54f7 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-0d6608cf-08ea","rowLayout":"2","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-0d6608cf-08ea" class="gspb_row gspb_row-id-gsbp-0d6608cf-08ea wp-block-greenshift-blocks-row gspb_row-id-gsbp-0d6608cf-08ea"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-d131b6db-2f7a","columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-d131b6db-2f7a" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-d131b6db-2f7a"><!-- wp:greenshift-blocks/heading {"id":"gsbp-57b27c4a-9948","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003eFlight Time\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Average flight time"} -->
        <div id="gspb_heading-id-gsbp-57b27c4a-9948" class="gspb_heading gspb_heading-id-gsbp-57b27c4a-9948 "><strong><strong><strong><strong>Flight Time</strong></strong></strong></strong><span class="gspb_heading_subtitle">Average flight time</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-17757558-f63b","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"6","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-17757558-f63b" class="gspb_row__col--6 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-17757558-f63b"><!-- wp:greenshift-blocks/container {"id":"gsbp-f5e688e6-900f","flexbox":{"type":"grid","enable":false,"gridcolumns":[3,null,null,3],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-f5e688e6-900f" class="gspb_container gspb_container-gsbp-f5e688e6-900f wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-961a612c-8b2d","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-961a612c-8b2d" class="gspb_container gspb_container-gsbp-961a612c-8b2d wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-0be88768-cdfb","headingTag":"div","headingContent":"40min","typography":{"textShadow":{},"color":"#13b579"}} -->
        <div id="gspb_heading-id-gsbp-0be88768-cdfb" class="gspb_heading gspb_heading-id-gsbp-0be88768-cdfb ">40min</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-dc6c5ed9-b584","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-dc6c5ed9-b584" class="gspb_container gspb_container-gsbp-dc6c5ed9-b584 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-f383cb83-fa7b","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-f383cb83-fa7b" class="gspb_heading gspb_heading-id-gsbp-f383cb83-fa7b ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-f5325e86-71fd","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-f5325e86-71fd" class="gspb_container gspb_container-gsbp-f5325e86-71fd wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-d0de433a-67a0","headingTag":"div","headingContent":"30min","typography":{"textShadow":{},"color":""}} -->
        <div id="gspb_heading-id-gsbp-d0de433a-67a0" class="gspb_heading gspb_heading-id-gsbp-d0de433a-67a0 ">30min</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row --></div>
        <!-- /wp:greenshift-blocks/container -->
        ',
    )
);
register_block_pattern(
    'greenshiftseo/versusthree',
    array(
        'title'       => __( 'Versus 3 items table', 'greenshift' ),
        'categories' => array('greenshiftseoelements'),
		'keywords' => array('versus', 'comparison'),
		'description' => _x( 'Versus table with 3 items', 'Block pattern description', 'greenshift' ),
        'content'     => '<!-- wp:greenshift-blocks/container {"id":"gsbp-6e2303c3-eb98","border":{"borderRadius":{"values":{},"unit":"px","locked":true},"style":{"all":["solid"]},"size":{"all":[2]},"color":{"all":["#e0e0e0"]},"styleHover":{},"sizeHover":{},"colorHover":{}},"align":"wide"} -->
        <div id="gspb_container-id-gsbp-6e2303c3-eb98" class="gspb_container gspb_container-gsbp-6e2303c3-eb98 wp-block-greenshift-blocks-container alignwide"><!-- wp:greenshift-blocks/row {"id":"gsbp-d3fe8922-b98f","rowLayout":"6","columnPosition":"center","displayStyles":false,"background":{"color":"#f7f7f7"},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":true},"padding":{"values":{},"unit":["px","px","px","px"],"locked":false}}} -->
        <div id="gspb_row-id-gsbp-d3fe8922-b98f" class="gspb_row gspb_row-id-gsbp-d3fe8922-b98f wp-block-greenshift-blocks-row gspb_row-id-gsbp-d3fe8922-b98f"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-32c161d9-efa4","columnSize":"4","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-32c161d9-efa4" class="gspb_row__col--4 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-32c161d9-efa4"><!-- wp:greenshift-blocks/heading {"id":"gsbp-0fe2a48b-3944","headingTag":"div","headingContent":"\u003cstrong\u003e2 Pro vs Air2 vs Air3\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Epic battle"} -->
        <div id="gspb_heading-id-gsbp-0fe2a48b-3944" class="gspb_heading gspb_heading-id-gsbp-0fe2a48b-3944 "><strong>2 Pro vs Air2 vs Air3</strong><span class="gspb_heading_subtitle">Epic battle</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-de63594e-9fce","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"8","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-de63594e-9fce" class="gspb_row__col--8 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-de63594e-9fce"><!-- wp:greenshift-blocks/container {"id":"gsbp-c6db2057-955a","flexbox":{"type":"grid","enable":false,"gridcolumns":[5,null,null,5],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-c6db2057-955a" class="gspb_container gspb_container-gsbp-c6db2057-955a wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-9fa6dbff-8867","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-9fa6dbff-8867" class="gspb_container gspb_container-gsbp-9fa6dbff-8867 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/image {"id":"gsbp-4a47f8b4-abbb","width":["custom",null,null,null],"customWidth":[70,null,null,null],"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"mediaurl":"https://via.placeholder.com/300","alt":""} -->
        <div id="gspb_image-id-gsbp-4a47f8b4-abbb" class="gspb_image gspb_image-id-gsbp-4a47f8b4-abbb wp-block-greenshift-blocks-image"><img src="https://via.placeholder.com/300" data-src="" alt="" width="70" /></div>
        <!-- /wp:greenshift-blocks/image --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-7091a476-6d78","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-7091a476-6d78" class="gspb_container gspb_container-gsbp-7091a476-6d78 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-148ff9c2-fc40","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-148ff9c2-fc40" class="gspb_heading gspb_heading-id-gsbp-148ff9c2-fc40 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-25712626-afd3","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-25712626-afd3" class="gspb_container gspb_container-gsbp-25712626-afd3 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/image {"id":"gsbp-2120134c-0df0","width":["custom",null,null,null],"customWidth":[70,null,null,null],"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"mediaurl":"https://via.placeholder.com/300","alt":""} -->
        <div id="gspb_image-id-gsbp-2120134c-0df0" class="gspb_image gspb_image-id-gsbp-2120134c-0df0 wp-block-greenshift-blocks-image"><img src="https://via.placeholder.com/300" data-src="" alt="" width="70" /></div>
        <!-- /wp:greenshift-blocks/image --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-3ab59198-6766","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-3ab59198-6766" class="gspb_container gspb_container-gsbp-3ab59198-6766 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-6cba6963-dca0","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-6cba6963-dca0" class="gspb_heading gspb_heading-id-gsbp-6cba6963-dca0 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-ff6945c3-61d6","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-ff6945c3-61d6" class="gspb_container gspb_container-gsbp-ff6945c3-61d6 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/image {"id":"gsbp-3398f97b-98f3","width":["custom",null,null,null],"customWidth":[70,null,null,null],"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"mediaurl":"https://via.placeholder.com/300","alt":""} -->
        <div id="gspb_image-id-gsbp-3398f97b-98f3" class="gspb_image gspb_image-id-gsbp-3398f97b-98f3 wp-block-greenshift-blocks-image"><img src="https://via.placeholder.com/300" data-src="" alt="" width="70" /></div>
        <!-- /wp:greenshift-blocks/image --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-fa7e6914-8f19","rowLayout":"6","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-fa7e6914-8f19" class="gspb_row gspb_row-id-gsbp-fa7e6914-8f19 wp-block-greenshift-blocks-row gspb_row-id-gsbp-fa7e6914-8f19"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-3b272cc6-f180","columnSize":"4","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-3b272cc6-f180" class="gspb_row__col--4 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-3b272cc6-f180"><!-- wp:greenshift-blocks/heading {"id":"gsbp-244d161d-c06a","headingTag":"div","headingContent":"\u003cstrong\u003eHD Video\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"4k and 8k"} -->
        <div id="gspb_heading-id-gsbp-244d161d-c06a" class="gspb_heading gspb_heading-id-gsbp-244d161d-c06a "><strong>HD Video</strong><span class="gspb_heading_subtitle">4k and 8k</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-ebbdad1c-f9cc","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"8","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-ebbdad1c-f9cc" class="gspb_row__col--8 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-ebbdad1c-f9cc"><!-- wp:greenshift-blocks/container {"id":"gsbp-93fceeb0-58f7","flexbox":{"type":"grid","enable":false,"gridcolumns":[5,null,null,5],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-93fceeb0-58f7" class="gspb_container gspb_container-gsbp-93fceeb0-58f7 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-1c4a4bf4-b2aa","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-1c4a4bf4-b2aa" class="gspb_container gspb_container-gsbp-1c4a4bf4-b2aa wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-3326f536-6ac7","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-3326f536-6ac7" class="gspb_iconBox gspb_iconBox-id-gsbp-3326f536-6ac7 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-b82f4c76-74f5","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-b82f4c76-74f5" class="gspb_container gspb_container-gsbp-b82f4c76-74f5 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-be39e926-fe01","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-be39e926-fe01" class="gspb_heading gspb_heading-id-gsbp-be39e926-fe01 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-f4a11eea-c6c3","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-f4a11eea-c6c3" class="gspb_container gspb_container-gsbp-f4a11eea-c6c3 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-6d465006-2bab","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-6d465006-2bab" class="gspb_iconBox gspb_iconBox-id-gsbp-6d465006-2bab wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-5ec389f2-12fe","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-5ec389f2-12fe" class="gspb_container gspb_container-gsbp-5ec389f2-12fe wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-83d6f689-b4df","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-83d6f689-b4df" class="gspb_heading gspb_heading-id-gsbp-83d6f689-b4df ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-d5ead722-973e","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-d5ead722-973e" class="gspb_container gspb_container-gsbp-d5ead722-973e wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-acca959a-8e0a","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-acca959a-8e0a" class="gspb_iconBox gspb_iconBox-id-gsbp-acca959a-8e0a wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-4e8e7340-4bdb","rowLayout":"6","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-4e8e7340-4bdb" class="gspb_row gspb_row-id-gsbp-4e8e7340-4bdb wp-block-greenshift-blocks-row gspb_row-id-gsbp-4e8e7340-4bdb"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-c1197023-a601","columnSize":"4","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-c1197023-a601" class="gspb_row__col--4 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-c1197023-a601"><!-- wp:greenshift-blocks/heading {"id":"gsbp-dfb4f360-2fa4","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003eSmartFocus\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Focus and tracking"} -->
        <div id="gspb_heading-id-gsbp-dfb4f360-2fa4" class="gspb_heading gspb_heading-id-gsbp-dfb4f360-2fa4 "><strong><strong><strong>SmartFocus</strong></strong></strong><span class="gspb_heading_subtitle">Focus and tracking</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-7a9e961c-547e","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"8","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-7a9e961c-547e" class="gspb_row__col--8 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-7a9e961c-547e"><!-- wp:greenshift-blocks/container {"id":"gsbp-742cd127-98dd","flexbox":{"type":"grid","enable":false,"gridcolumns":[5,null,null,5],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-742cd127-98dd" class="gspb_container gspb_container-gsbp-742cd127-98dd wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-0a2e09c0-1ba8","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-0a2e09c0-1ba8" class="gspb_container gspb_container-gsbp-0a2e09c0-1ba8 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-2c921319-b434","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-2c921319-b434" class="gspb_iconBox gspb_iconBox-id-gsbp-2c921319-b434 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-6339ea4a-ca98","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-6339ea4a-ca98" class="gspb_container gspb_container-gsbp-6339ea4a-ca98 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-d0356d75-094a","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-d0356d75-094a" class="gspb_heading gspb_heading-id-gsbp-d0356d75-094a ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-20e14bfe-1a30","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-20e14bfe-1a30" class="gspb_container gspb_container-gsbp-20e14bfe-1a30 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-3fa9ac4d-ad64","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-3fa9ac4d-ad64" class="gspb_iconBox gspb_iconBox-id-gsbp-3fa9ac4d-ad64 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-33784f7d-6997","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-33784f7d-6997" class="gspb_container gspb_container-gsbp-33784f7d-6997 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-09a2c316-7c09","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-09a2c316-7c09" class="gspb_heading gspb_heading-id-gsbp-09a2c316-7c09 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-2cf12fea-6a21","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-2cf12fea-6a21" class="gspb_container gspb_container-gsbp-2cf12fea-6a21 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-e6755fcc-6f4f","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-e6755fcc-6f4f" class="gspb_iconBox gspb_iconBox-id-gsbp-e6755fcc-6f4f wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-e80e2dfb-53c3","rowLayout":"6","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-e80e2dfb-53c3" class="gspb_row gspb_row-id-gsbp-e80e2dfb-53c3 wp-block-greenshift-blocks-row gspb_row-id-gsbp-e80e2dfb-53c3"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-cd93d809-53bc","columnSize":"4","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-cd93d809-53bc" class="gspb_row__col--4 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-cd93d809-53bc"><!-- wp:greenshift-blocks/heading {"id":"gsbp-0bb0511f-55a4","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003eQuick Shots\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Functional blocks"} -->
        <div id="gspb_heading-id-gsbp-0bb0511f-55a4" class="gspb_heading gspb_heading-id-gsbp-0bb0511f-55a4 "><strong><strong><strong><strong><strong><strong>Quick Shots</strong></strong></strong></strong></strong></strong><span class="gspb_heading_subtitle">Functional blocks</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-114d19c7-5a7d","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"8","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-114d19c7-5a7d" class="gspb_row__col--8 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-114d19c7-5a7d"><!-- wp:greenshift-blocks/container {"id":"gsbp-a7934d22-623c","flexbox":{"type":"grid","enable":false,"gridcolumns":[5,null,null,5],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-a7934d22-623c" class="gspb_container gspb_container-gsbp-a7934d22-623c wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-b7ec0e20-f795","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-b7ec0e20-f795" class="gspb_container gspb_container-gsbp-b7ec0e20-f795 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-5ecdbeb5-b5b7","iconBox_icon":{"icon":{"font":"rhicon rhi-check-circle-solid","svg":"","image":""},"fill":"#00d285","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-5ecdbeb5-b5b7" class="gspb_iconBox gspb_iconBox-id-gsbp-5ecdbeb5-b5b7 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M1008 512c0 273.934-222.066 496-496 496s-496-222.066-496-496 222.066-496 496-496 496 222.066 496 496zM454.628 774.628l368-368c12.496-12.496 12.496-32.758 0-45.254l-45.254-45.254c-12.496-12.498-32.758-12.498-45.256 0l-300.118 300.116-140.118-140.118c-12.496-12.496-32.758-12.496-45.256 0l-45.254 45.254c-12.496 12.496-12.496 32.758 0 45.254l208 208c12.498 12.498 32.758 12.498 45.256 0.002z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-f1083bb3-5b79","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-f1083bb3-5b79" class="gspb_container gspb_container-gsbp-f1083bb3-5b79 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-3f3d882e-ba3c","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-3f3d882e-ba3c" class="gspb_heading gspb_heading-id-gsbp-3f3d882e-ba3c ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-10d75bc1-3497","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-10d75bc1-3497" class="gspb_container gspb_container-gsbp-10d75bc1-3497 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-7ec19764-7b99","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-7ec19764-7b99" class="gspb_iconBox gspb_iconBox-id-gsbp-7ec19764-7b99 wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-11ecdb61-f0bf","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-11ecdb61-f0bf" class="gspb_container gspb_container-gsbp-11ecdb61-f0bf wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-45e1a745-aba4","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-45e1a745-aba4" class="gspb_heading gspb_heading-id-gsbp-45e1a745-aba4 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-a081a8ed-5827","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-a081a8ed-5827" class="gspb_container gspb_container-gsbp-a081a8ed-5827 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/iconbox {"id":"gsbp-42859b48-c5df","iconBox_icon":{"icon":{"font":"rhicon rhi-ban","svg":"","image":""},"fill":"#f20d0d","fillhover":"","type":"font","iconSize":[28]}} -->
        <div id="gspb_iconBox-id-gsbp-42859b48-c5df" class="gspb_iconBox gspb_iconBox-id-gsbp-42859b48-c5df wp-block-greenshift-blocks-iconbox"><div class="gspb_iconBox__wrapper" style="display:inline-flex"><svg class="" style="display:inline-block;vertical-align:middle" width="72" height="72" viewbox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path style="fill:#565D66" d="M512 16c-273.934 0-496 222.066-496 496s222.066 496 496 496 496-222.066 496-496-222.066-496-496-496zM206.53 817.47c-161.244-161.244-168.298-417.914-21.8-587.486l609.288 609.286c-169.608 146.528-426.276 139.412-587.488-21.8zM839.27 794.016l-609.286-609.286c169.608-146.526 426.274-139.41 587.486 21.8 161.244 161.242 168.298 417.914 21.8 587.486z"></path></svg></div></div>
        <!-- /wp:greenshift-blocks/iconbox --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row -->
        
        <!-- wp:greenshift-blocks/row {"id":"gsbp-5215e31c-3de8","rowLayout":"6","columnPosition":"center","displayStyles":false} -->
        <div id="gspb_row-id-gsbp-5215e31c-3de8" class="gspb_row gspb_row-id-gsbp-5215e31c-3de8 wp-block-greenshift-blocks-row gspb_row-id-gsbp-5215e31c-3de8"><div class="gspb_row__content"> <!-- wp:greenshift-blocks/row-column {"id":"gsbp-149d1ddc-325b","columnSize":"4","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-149d1ddc-325b" class="gspb_row__col--4 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-149d1ddc-325b"><!-- wp:greenshift-blocks/heading {"id":"gsbp-6ed39e58-48b3","headingTag":"div","headingContent":"\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003e\u003cstrong\u003eQuick Shots\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e\u003c/strong\u003e","typography":{"textShadow":{},"alignment":[null,null,null,"center"]},"enablesubTitle":true,"subTitle":"Functional blocks"} -->
        <div id="gspb_heading-id-gsbp-6ed39e58-48b3" class="gspb_heading gspb_heading-id-gsbp-6ed39e58-48b3 "><strong><strong><strong><strong><strong><strong>Quick Shots</strong></strong></strong></strong></strong></strong><span class="gspb_heading_subtitle">Functional blocks</span></div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/row-column -->
        
        <!-- wp:greenshift-blocks/row-column {"id":"gsbp-7813a29e-a37d","flexbox":{"type":"","flexDirection":["column"],"justifyContent":["center"],"alignItems":["center"],"enable":false},"columnSize":"8","spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{},"unit":["px","px","px","px"],"locked":true}}} -->
        <div id="gspb_col-id-gsbp-7813a29e-a37d" class="gspb_row__col--8 wp-block-greenshift-blocks-row-column  gspb_col-id-gsbp-7813a29e-a37d"><!-- wp:greenshift-blocks/container {"id":"gsbp-32fd18af-bc33","flexbox":{"type":"grid","enable":false,"gridcolumns":[5,null,null,5],"columngap":[20],"rowgap":[20]}} -->
        <div id="gspb_container-id-gsbp-32fd18af-bc33" class="gspb_container gspb_container-gsbp-32fd18af-bc33 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/container {"id":"gsbp-7d176d88-9806","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"],"shrinkzero":false}} -->
        <div id="gspb_container-id-gsbp-7d176d88-9806" class="gspb_container gspb_container-gsbp-7d176d88-9806 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-0bcd00fc-d444","headingTag":"div","headingContent":"40min","typography":{"textShadow":{},"color":"#13b579"}} -->
        <div id="gspb_heading-id-gsbp-0bcd00fc-d444" class="gspb_heading gspb_heading-id-gsbp-0bcd00fc-d444 ">40min</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-6cbaa51d-328b","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-6cbaa51d-328b" class="gspb_container gspb_container-gsbp-6cbaa51d-328b wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-eba9a298-5c16","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-eba9a298-5c16" class="gspb_heading gspb_heading-id-gsbp-eba9a298-5c16 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-fd9bbab4-fd2f","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-fd9bbab4-fd2f" class="gspb_container gspb_container-gsbp-fd9bbab4-fd2f wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-80c2d9bc-ef51","headingTag":"div","headingContent":"30min","typography":{"textShadow":{},"color":""}} -->
        <div id="gspb_heading-id-gsbp-80c2d9bc-ef51" class="gspb_heading gspb_heading-id-gsbp-80c2d9bc-ef51 ">30min</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-8def87fa-857b","flexbox":{"type":"flexbox","justifyContent":["center"],"alignItems":["center"],"flexDirection":["column"]}} -->
        <div id="gspb_container-id-gsbp-8def87fa-857b" class="gspb_container gspb_container-gsbp-8def87fa-857b wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-62b9398c-0e52","headingTag":"div","headingContent":"VS","background":{"color":"#efefef"},"border":{"borderRadius":{"values":{"topLeft":50,"topRight":50,"bottomRight":50,"bottomLeft":50},"unit":"px","locked":true},"style":{},"size":{},"color":{},"styleHover":{},"sizeHover":{},"colorHover":{}},"spacing":{"margin":{"values":{},"unit":["px","px","px","px"],"locked":false},"padding":{"values":{"top":[11],"right":[9],"bottom":[11],"left":[9]},"unit":["px","px","px","px"],"locked":false}},"typography":{"alignment":["center"],"textShadow":{},"size":[13],"line_height":[13]}} -->
        <div id="gspb_heading-id-gsbp-62b9398c-0e52" class="gspb_heading gspb_heading-id-gsbp-62b9398c-0e52 ">VS</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container -->
        
        <!-- wp:greenshift-blocks/container {"id":"gsbp-78ffacb4-e3e8","flexbox":{"type":"flexbox","flexDirection":["column"],"alignItems":["center"],"justifyContent":["center"]}} -->
        <div id="gspb_container-id-gsbp-78ffacb4-e3e8" class="gspb_container gspb_container-gsbp-78ffacb4-e3e8 wp-block-greenshift-blocks-container"><!-- wp:greenshift-blocks/heading {"id":"gsbp-4df4857e-016d","headingTag":"div","headingContent":"30min","typography":{"textShadow":{},"color":""}} -->
        <div id="gspb_heading-id-gsbp-4df4857e-016d" class="gspb_heading gspb_heading-id-gsbp-4df4857e-016d ">30min</div>
        <!-- /wp:greenshift-blocks/heading --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/container --></div>
        <!-- /wp:greenshift-blocks/row-column --> </div></div>
        <!-- /wp:greenshift-blocks/row --></div>
        <!-- /wp:greenshift-blocks/container -->',
    )
);