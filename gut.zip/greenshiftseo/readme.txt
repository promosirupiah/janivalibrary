=== Greenshift Marketing and Seo Addon ===
Contributors: wpsoul
Tags: gutenberg, block, marketing, seo
Author: GreenshiftWP
Author URI: https://greenshiftwp.com/
Requires at least: 5.9
Tested up to: 6.1
Requires PHP: 7.0
Stable tag: 0.9.9.1

Add additional marketing, SEO and CTA blocks and earn money