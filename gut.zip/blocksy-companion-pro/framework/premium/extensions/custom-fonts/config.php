<?php

$config = blc_exts_get_preliminary_config('custom-fonts');

