<?php

$autoload = [
	'LogoEnhancements' => 'includes/logo-enhancements.php'
];

