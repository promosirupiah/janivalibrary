<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

if(!defined('EDD_CONSTANTS')) {
  require_once 'edd_constants.php';
}

require_once 'EddLicensePage.php';