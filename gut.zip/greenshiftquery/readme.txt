=== Greenshift Query and Meta Addon ===
Contributors: wpsoul
Tags: gutenberg, block, query, full site editor
Author: GreenshiftWP
Author URI: https://greenshiftwp.com/
Requires at least: 6.2
Tested up to: 6.3
Requires PHP: 7.0
Stable tag: 3.4

Get values from any custom meta, attributes or custom taxonomy. Use better query block. Add post views, thumbs counter.