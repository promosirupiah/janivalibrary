<?php


namespace Greenshift\Blocks;
defined('ABSPATH') OR exit;


class PageList{

	public function __construct(){
		add_action('init', array( $this, 'init_handler' ));
	}

	public function init_handler(){
		register_block_type(__DIR__, array(
                'render_callback' => array( $this, 'render_block' ),
                'attributes'      => $this->attributes
            )
		);
	}

	public $attributes = array(
		'id' => array(
			'type'    => 'string',
			'default' => null,
		),
		'inlineCssStyles' => array(
			'type'    => 'string',
			'default' => '',
		),
		'animation' => array(
			'type' => 'object',
			'default' => array(),
		),
        'postType' => array(
            'type' => 'string',
            'default' => 'page'
        ),
        'depth' => array(
            'type' => 'string',
            'default' => 'grid'
        ),
        'orderBy' => array(
            'type' => 'string',
            'default' => 'post_title'
        ),
        'order' => array(
            'type' => 'string',
            'default' => 'ASC'
        ),
        'child_of' => array(
            'type' => 'number',
            'default' => ''
        ),
        'include' => array(
            'type' => 'string',
            'default' => ''
        ),
        'exclude' => array(
            'type' => 'string',
            'default' => ''
        ),
        'link_after' => array(
            'type' => 'string',
            'default' => ''
        ),
        'link_before' => array(
            'type' => 'string',
            'default' => ''
        ),
	);

	public function render_block($settings = array(), $inner_content=''){
		extract($settings);

		$blockId = 'gspb_id-'.$id;
		$blockClassName = 'gspb-pagelistbox '.$blockId.' '.(!empty($className) ? $className : '').' ';

		$out = '<div id="'.$blockId.'" class="'.$blockClassName.'"'.gspb_AnimationRenderProps($animation).'>';
            $out .= '<ul class="gspagelist">';
            $args = [
                'post_type' => $postType ? esc_attr($postType) : 'page',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'sort_column' => esc_attr($orderBy),
                'title_li' => '',
                'echo'=> false,
                'exclude' => $exclude ? esc_attr($exclude) : '',
                'include' => $include ? esc_attr($include) : '',
                'link_after' => $link_after ? wp_kses_post($link_after) : '',
                'link_before' => $link_before ? wp_kses_post($link_before) : '',
            ];
            if($child_of){
                $args['child_of'] = (int)$child_of;
            }
            $out .= wp_list_pages($args);
            $out .= '</ul>';
		$out .='</div>';
		return $out;
	}

}

new PageList;