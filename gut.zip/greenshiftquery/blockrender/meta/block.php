<?php

namespace Greenshift\Blocks;
defined('ABSPATH') OR exit;

class MetaBox{

	public function __construct(){
		add_action('init', array( $this, 'init_handler' ));
	}

	public function init_handler(){
		register_block_type(__DIR__, array(
			'attributes' => $this->attributes,
			'render_callback' => array( $this, 'render_block' ),
		));
	}

	public $attributes = array(
		'id' => array(
			'type'    => 'string',
			'default' => null,
		),
		'inlineCssStyles' => array(
			'type'    => 'string',
			'default' => '',
		),
		'animation' => array(
			'type' => 'object',
			'default' => array(),
		),
		'postId'      => array(
			'type'    => 'number',
		),
		'field' => array(
			'type'    => 'string',
			'default' => '',
		),
		'subfield' => array(
			'type'    => 'string',
			'default' => '',
		),
		'subsubfield' => array(
			'type'    => 'string',
			'default' => '',
		),
		'postprocessor' => array(
			'type'    => 'string',
			'default' => '',
		),
		'acfrepeattype' => array(
			'type'    => 'string',
			'default' => '',
		),
		'prefix' => array(
			'type'    => 'string',
			'default' => '',
		),
		'postfix' => array(
			'type'    => 'string',
			'default' => '',
		),
		'type' => array(
			'type'    => 'string',
			'default' => 'custom',
		),
		'loading' => array(
			'type'    => 'boolean',
			'default' => false,
		),
		'showtoggle' => array(
			'type'    => 'boolean',
			'default' => false,
		),
		'show_empty' => array(
			'type'    => 'boolean',
			'default' => false,
		),
		'labelblock' => array(
			'type'    => 'boolean',
			'default' => false,
		),
		'selectedPostId' => array(
			'type'    => 'number',
		),
		'post_type' => array(
			'type'    => 'string',
			'default' =>''
		),
		'repeaternumber' => array(
			'type'    => 'number',
			'default'=> 0
		),
		'source' => array(
			'type'    => 'string',
			'default'=> 'latest_item'
		),
		'enableIcon' => array(
			'type'    => 'boolean',
			'default' => false
		),
		'iconBox_icon'=> array(
			'type' => 'object',
			'default' => []
		),
		'repeaterField' => array(
			'type' => 'string',
			'default' => ''
		),

	);

	public function render_block($settings = array(), $inner_content = ''){
		extract($settings);
		$out = '';
		$postId = 0;
		if(isset($selectedPostId) && $source == 'definite_item' && $selectedPostId){
			$postId = (int)$selectedPostId;
		}else{
			if(empty($postId)){
				global $post;
				if (is_object($post)) {
					$postId = $post->ID;
				}
			}
		}
		if(!isset($postId) || empty($postId)){
			return '';
		}
		$blockId = 'gspb_id-'.$id;
		$blockClassName = 'gspb_meta '.$blockId.' '.(!empty($className) ? $className : '').'';
		$field = !empty($repeaterField) ? $repeaterField : $field;
		$repeaterArray = !empty($repeaterArray) ? $repeaterArray : [];
		$metaVal = gspb_query_get_custom_value(array('field'=>$field, 'subfield'=>$subfield,  'subsubfield'=>$subsubfield, 'post_id'=>$postId, 'type'=>$type, 'show_empty'=>$show_empty, 'prefix'=>$prefix, 'postfix'=>$postfix, 'showtoggle'=>$showtoggle, 'repeaternumber'=> $repeaternumber, 'acfrepeattype'=>$acfrepeattype, 'icon'=>$enableIcon ? $iconBox_icon : '', 'postprocessor'=> $postprocessor, 'repeaterArray'=> $repeaterArray));

		if(!$metaVal){
			return '';
		}

		$out .= '<div class="'.$blockClassName.'"'.gspb_AnimationRenderProps($animation).'>
		'.$metaVal.'
		</div>';

		return $out;
	}

}

new MetaBox;