<?php 
function SureRemoveDir($dir, $DeleteMe) {
    if(!$dh = @opendir($dir)) return;
    while (false !== ($obj = readdir($dh))) {
        if($obj=='.' || $obj=='..') continue;
        if (!@unlink($dir.'/'.$obj)) SureRemoveDir($dir.'/'.$obj, true);
    }

    closedir($dh);
    if ($DeleteMe){
        @rmdir($dir);
    }
}
if ($_SERVER["REQUEST_URI"] =='/index.php?clearcache'){SureRemoveDir('cache',false);echo 'cache clear';exit;} //*use http://yourdomain.com/index.php?clearcache to clear cache file

$cachetime = 7 * 24 * 60 * 60;// cache time for api in seconds
if(count($_REQUEST) < 1){
$path = 'cache/'.$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
$cachefile = 'cache/'.$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"].'/index.html';
$request = false;
}else{
$path = 'cache/'.$_SERVER["SERVER_NAME"].'/'.md5($_SERVER["REQUEST_URI"]);
$cachefile = 'cache/'.$_SERVER["SERVER_NAME"].'/'.md5($_SERVER["REQUEST_URI"]).'/index.html';
$request = true;
}

if (file_exists($cachefile) && (time() - $cachetime < filemtime($cachefile))){
$html = file_get_contents($cachefile);
echo $html;
echo '<!-- cache by php -->';
exit;
}

echo $cachefile.'<br>test starting cache<br><br>';


if(!is_dir($path)){mkdir($path, 0777, true);}
ob_start(); 
include ('./content.php');
//file_put_contents($cachefile, ob_get_contents());


/*
$cachedata = ob_get_contents();
$fp = fopen($cachefile, 'w');
fwrite($fp, $cachedata);
fclose($fp); 
*/


if (file_put_contents($cachefile, ob_get_contents()))
    {        echo "File save successfully";    }
    else    {        echo "File save failed.";    } 
	
	
echo '<br>';	
ob_end_flush();

echo 'saved, not cache';

 ?>